#!/usr/bin/env python3
"""Dev entrypoint: python run.py  (or: uvicorn app.main:app --reload)"""
import uvicorn
from app.core.config import get_config
cfg = get_config()
uvicorn.run("app.main:app", host=cfg.get("app", "host", default="127.0.0.1"),
            port=int(cfg.get("app", "port", default=8000)), reload=False)
