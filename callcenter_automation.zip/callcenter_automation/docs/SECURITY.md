# Security

- **No secrets in code/config**: credentials only via `.env` (gitignored), loaded by name.
- **Phone masking** in all logs (XXXXXX1234); rotating log files, 5×5MB.
- **Input sanitization**: control chars stripped, lengths clamped; uploads capped at 25MB.
- **Auth**: optional dashboard token, verified in constant time; webhook endpoint isolated.
- **DB**: parameterized queries only; WAL; file permissions via normal OS controls.
- **Audit log**: every import, call result, export, and recovery is recorded.
- **Data safety**: source Excel files are never modified; exports are timestamped with backup.
- **Compliance boundary**: the codebase contains no scraping, number generation, CAPTCHA
  bypass, or impersonation logic. Real calling requires an authorized provider; calling
  window (09:00–20:00) and no-retry-on-not-interested defaults prevent abusive patterns.
- **Transport**: use TLS in production (nginx/Caddy); never expose the app on plain HTTP.
