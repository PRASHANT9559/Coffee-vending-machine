# Architecture

## Layers
```
UI (app/web/static/index.html, Hindi dashboard, WebSocket live updates)
  → FastAPI app (app/main.py): REST + /ws + /webhooks/call-events
    → Engine (app/services/engine.py): orchestrates the call workflow, crash recovery
      → Services: importer, validation, script_generator, queue_manager (retry policy),
        exporter (safe Excel output + backup)
        → Provider interfaces:
            TTSProvider     (voice/tts.py)     — mock | gtts | pyttsx3
            STTProvider     (speech/stt.py)    — mock (plug Whisper/Vosk later)
            TelephonyProvider (telephony/)     — mock | http_webhook (authorized provider)
        → Intents: rule-based Hindi/English classifier (app/intents/classifier.py)
    → SQLite (app/models/db.py): customers, call_attempts, callbacks, audit_log, configuration
```

## Key decisions
- SQLite (WAL, transactional): zero operational overhead, survives restart, easy backup.
- Provider abstractions: the app never hard-codes a vendor; switching providers is one
  config key. Everything runs with mocks for development and CI.
- Rule-based intent engine: auditable, offline, conservative — ambiguous speech returns
  UNKNOWN instead of guessing.
- Safe Excel strategy: source files are never modified. Results are written to a new
  timestamped `processed_output_*.xlsx`, with the previous output auto-backed-up.
