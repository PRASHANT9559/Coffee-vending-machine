# Setup

```bash
cd callcenter_automation
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scriptsctivate
pip install -r requirements.txt
python run.py
```
Open http://127.0.0.1:8000

## Production serve
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
```
Put behind nginx/Caddy with TLS. Set `security.dashboard_token` in `config/settings.yaml`
and access the dashboard as `https://your-host/?token=YOUR_TOKEN`.

## Input file format
Minimum columns: `Name, Mobile, Recharge_Status, Offer, Validity, Benefits, Call_Status`
Optional: `Customer_ID, Language, Preferred_Call_Time, Last_Call_Time, Max_Attempts, Remarks, Callback_Time`
Tolerates: missing optional fields, extra columns, empty rows, duplicates, invalid numbers,
Hindi/Unicode text, ₹ symbols, any column order. See `sample_data/customers.xlsx`.
