# Troubleshooting

| Symptom | Fix |
|---|---|
| Import fails "Unsupported file type" | Use `.xlsx` or `.csv` (UTF-8 with BOM for Hindi CSV) |
| Customers imported as Invalid | Check mobile format (10 digits, starts 6–9); see `invalid` list in import response |
| TTS failure / empty audio | Switch `tts.provider` to `mock` or `gtts`; pyttsx3 needs an installed Hindi voice |
| "missing API key in env" | Add `TELEPHONY_API_KEY`/`TELEPHONY_FROM_NUMBER` to `.env`, or set `telephony.provider: mock` |
| "telephony authentication failed" | Wrong/expired API key at the provider |
| "rate limit hit" | Reduce campaign pace; increase `failed_retry_after_minutes` |
| Queue seems stuck | Check `/api/status` and `/api/callbacks`; due callbacks are prioritized; verify calling window hours |
| App crashed mid-campaign | Just restart — orphaned attempts are auto-finalized as Failed and retried per policy |
| Excel file locked (Windows) | Close it in Excel before re-exporting; exports always write NEW files, so this is rare |
| Want a clean slate | Stop the app, delete `data/callcenter.db*` and `data/exports/` |
