# API Integration

## Telephony (authorized provider only)
`app/telephony/http_provider.py` implements a Twilio-style adapter:
- `POST /v1/calls` with `{to, from, audio_url, status_webhook, record:false}` — TTS audio
  is served from the app; the provider must be able to fetch it (expose `data/tts/` via
  your reverse proxy in production).
- Provider reports events to `POST /webhooks/call-events` with `{call_ref, event, dtmf|speech, duration}`.
- Map `api_key_env` / `from_number_env` to your `.env` names.
- Auth failure → 401/403 surfaces as `TelephonyError`; 429 → rate-limit error; timeouts handled.

## TTS
`gtts`: online, good Hindi, no key needed. `pyttsx3`: fully local, Hindi voice depends on
OS voices. `mock`: writes the script to `.txt` + marker file — full pipeline testable offline.

## STT
Interface ready (`STTProvider.transcribe`). Default mock returns no speech; DTMF path is
the primary channel. To add Whisper/Vosk: subclass `STTProvider`, return `STTResult`, and
wire events into the engine like the mock does.

## Dashboard/REST (token via `?token=` when configured)
`POST /api/import` (multipart file) · `GET /api/stats` · `GET /api/customers` ·
`GET /api/next-script` · `POST /api/call-next` · `POST /api/simulate {scenario}` ·
`GET /api/export` · `GET /api/callbacks` · `GET /api/status` · `GET /api/attempts/{id}` ·
`WS /ws`.
