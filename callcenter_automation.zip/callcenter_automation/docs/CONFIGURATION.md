# Configuration

Everything lives in `config/settings.yaml`. No secrets in this file — only env var NAMES.

| Key | Default | Meaning |
|---|---|---|
| `app.environment` | development | dev / production |
| `security.dashboard_token` | "" | if set, UI requires `?token=` |
| `security.mask_phone_in_logs` | true | mask mobiles in logs |
| `retry_policy.*` | 3 attempts, 60/30/120 min backoff | retry behavior |
| `retry_policy.retry_not_interested` | false | never auto-retry final statuses |
| `calling.allowed_hours_start/end` | 09:00 / 20:00 | respectful calling window |
| `tts.provider` | mock | mock \| gtts \| pyttsx3 |
| `stt.provider` | mock | mock (future: whisper/vosk adapter) |
| `telephony.provider` | mock | mock \| http_webhook |

## Secrets (.env — never commit)
```
TELEPHONY_API_KEY=
TELEPHONY_FROM_NUMBER=
TELEPHONY_ACCOUNT_SID=
```
These are only needed when using a real authorized telephony provider.
