# Testing

```bash
pytest tests/ -v
```

| Module | Covers |
|---|---|
| test_validation.py | mobile normalization (+91/0/91 prefixes), invalid formats, required fields, Unicode/₹, column reordering |
| test_intents.py | 20+ Hindi/English utterances → correct intent, ambiguous → UNKNOWN |
| test_script.py | personalized Hindi script: name, expiry line, ₹→words (दो सौ निन्यानवे), validity (अठ्ठाईस दिनों), 1/2/3 prompts |
| test_engine.py | all 11 scenarios end-to-end; callback stored; no retry after Not Interested; retry then finalize; import dedup + invalid flag + Hindi row + empty row; crash recovery |
| test_exporter.py | Excel roundtrip, headers, backup file on re-export |

## Manual test mode
Dashboard **Sim** buttons run the complete pipeline against the next queued customer with
zero real calls: Excel → script → mock call → simulated response → intent → DB update.
