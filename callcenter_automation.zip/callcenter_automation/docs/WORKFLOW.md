# Call Workflow

```
Import Excel/CSV
  → Validate (mobile regex, required fields, dedup; invalid rows flagged as 'Invalid')
  → Create calling queue (SQLite)
  → Select next eligible customer (due callbacks first)
  → Generate personalized Hindi script (script_generator)
  → TTS synthesis (configured provider)
  → Initiate call (authorized provider / mock)
  → Wait for events: DTMF 1/2/3, Hindi speech, busy, no-answer, failed
  → Classify response (intent engine)
  → Take action: record result, schedule callback if requested
  → Update customer record + call attempt + audit log
  → Retry decision (respecting retry policy)
  → Export results to Excel
```

## Retry policy (configurable in settings.yaml)
- No Answer → retry after 60 min (configurable)
- Busy → retry after 30 min
- Failed → retry after 120 min
- Not Interested / Interested → NEVER auto-retried (final statuses)
- Max attempts default: 3 (per-customer override via `Max_Attempts` column)
- Calling window: 09:00–20:00 by default
