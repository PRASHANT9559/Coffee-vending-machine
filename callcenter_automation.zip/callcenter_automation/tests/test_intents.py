from app.intents.classifier import classify
from app.models.schemas import Intent

CASES = [
    ("1", Intent.INTERESTED), ("हाँ कर दीजिए", Intent.INTERESTED),
    ("हां, रिचार्ज करना है", Intent.INTERESTED), ("yes, interested", Intent.INTERESTED),
    ("ऑफर बताइए", Intent.INTERESTED),
    ("2", Intent.CALLBACK), ("बाद में फोन करना", Intent.CALLBACK),
    ("अभी व्यस्त हूँ, शाम को फोन करना", Intent.CALLBACK),
    ("कल फोन करना", Intent.CALLBACK), ("call me later", Intent.CALLBACK),
    ("3", Intent.NOT_INTERESTED), ("नहीं चाहिए", Intent.NOT_INTERESTED),
    ("नहीं करना", Intent.NOT_INTERESTED), ("no thanks", Intent.NOT_INTERESTED),
    ("xyzzy blorp gibberish", Intent.UNKNOWN), ("", Intent.NO_ANSWER),
]
def test_intent_cases():
    for text, expected in CASES:
        got, conf = classify(text)
        assert got == expected, f"{text!r}: got {got}, want {expected}"
