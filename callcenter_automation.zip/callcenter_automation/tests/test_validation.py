from app.services.validation import validate_mobile, validate_record, map_columns

def test_valid_mobile_variants():
    assert validate_mobile("9876543210")[1] == "9876543210"
    assert validate_mobile("+91 98765 43210")[1] == "9876543210"
    assert validate_mobile("919876543210")[1] == "9876543210"
    assert validate_mobile("09876543210")[1] == "9876543210"

def test_invalid_mobiles():
    for bad in ["12345", "1234567890", "876543210", "abcdefghij", ""]:
        ok, _ = validate_mobile(bad)
        assert not ok, bad

def test_validate_record_and_unicode():
    ok, problems, cleaned = validate_record({
        "name": "प्रशांत", "mobile": "9876543210", "offer": "₹299",
        "benefits": "Unlimited calling, 100 SMS daily and more"})
    assert ok and problems == []
    assert cleaned["mobile"] == "9876543210"

def test_missing_required():
    ok, problems, _ = validate_record({"mobile": "9876543210"})
    assert not ok and "missing_name" in problems

def test_column_mapping_reordered():
    m = map_columns(["Mobile", "Name", "Offer", "Validity", "Benefits", "Recharge_Status", "Extra Col"])
    assert m["Mobile"] == "mobile" and m["Name"] == "name" and m["Extra Col"] not in m.values()
