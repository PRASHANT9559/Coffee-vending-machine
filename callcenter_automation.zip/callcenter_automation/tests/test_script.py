from app.services.script_generator import generate_script, speak_amount, speak_validity

CUSTOMER = {"name": "Prashant", "mobile": "9876543210", "recharge_status": "Expired",
            "offer": "₹299", "validity": "28 Days",
            "benefits": "Unlimited calling, 100 SMS daily and more"}

def test_script_contains_key_parts():
    s = generate_script(CUSTOMER)
    assert "नमस्ते Prashant जी" in s
    assert "रिचार्ज समाप्त हो गया है" in s
    assert "दो सौ निन्यानवे" in s and "रुपये" in s
    assert "अठ्ठाईस दिनों" in s
    assert "Unlimited calling" in s
    assert "1 दबाएँ" in s and "2 दबाएँ" in s and "3 दबाएँ" in s

def test_amount_fallback():
    assert "रुपये" in speak_amount("₹777")
    assert speak_validity("84 days") == "चौरासी दिनों"
