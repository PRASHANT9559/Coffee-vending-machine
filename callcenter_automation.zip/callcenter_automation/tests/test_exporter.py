import tempfile, pathlib, openpyxl
from app.models.db import Database
from app.services.exporter import export_customers

def test_export_roundtrip():
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    db.upsert_customer({"name": "Asha", "mobile": "9876500001", "offer": "₹299"})
    out = export_customers(db, tmp / "exports")
    assert out.exists() and out.suffix == ".xlsx"
    ws = openpyxl.load_workbook(out).active
    headers = [c.value for c in ws[1]]
    assert "Call_Status" in headers and "Mobile" in headers and "Intent" in headers
    row2 = [c.value for c in ws[2]]
    assert "Asha" in row2 and "9876500001" in row2
    # backup created on second export
    export_customers(db, tmp / "exports")
    assert list((tmp / "exports").glob("backup_*.xlsx"))
