import pathlib, tempfile
from app.core.config import Config
from app.models.db import Database
from app.services.engine import Engine
from app.services.importer import import_file

CFG = Config({"database": {"path": ":memory:"},
              "tts": {"provider": "mock", "output_dir": "data/tts_test"},
              "telephony": {"provider": "mock"},
              "retry_policy": {"max_attempts_default": 3}})

def make_db():
    import sqlite3
    # Database() uses pathlib; use temp file to keep WAL happy
    tmp = tempfile.mkdtemp()
    return Database(pathlib.Path(tmp) / "t.db")

CUSTOMERS = [
    {"name": "Asha", "mobile": "9876500001", "recharge_status": "Expired", "offer": "₹299",
     "validity": "28 Days", "benefits": "Unlimited calling"},
    {"name": "Ravi", "mobile": "9876500002", "recharge_status": "Expired", "offer": "₹199",
     "validity": "30 Days", "benefits": "2GB daily"},
]

def run_scenario(scenario, expected):
    db = make_db()
    for c in CUSTOMERS: db.upsert_customer(c)
    eng = Engine(db, CFG)
    r = eng.simulate(scenario)
    assert r["result"] == expected, f"{scenario}: {r}"
    cust = db.all_customers()[0]
    assert cust["call_status"] == expected
    assert cust["attempt_count"] == 1
    assert len(db.attempts_for(cust["id"])) == 1
    return db

def test_all_scenarios():
    run_scenario("interested", "Interested")
    run_scenario("callback", "Callback")
    run_scenario("not_interested", "Not Interested")
    run_scenario("no_answer", "No Answer")
    run_scenario("busy", "Busy")
    run_scenario("failed", "Failed")
    run_scenario("speech_interested", "Interested")
    run_scenario("speech_callback", "Callback")
    run_scenario("speech_not_interested", "Not Interested")
    run_scenario("speech_unknown", "Unknown")

def test_callback_scheduled():
    db = run_scenario("callback", "Callback")
    assert len(db.due_callbacks_list()) == 1

def test_no_retry_after_not_interested():
    db = run_scenario("not_interested", "Not Interested")
    eng = Engine(db, CFG)
    assert eng.queue.next_customer()["mobile"] != db.all_customers()[0]["mobile"]

def test_retry_no_answer_then_final():
    db = run_scenario("no_answer", "No Answer")
    eng = Engine(db, CFG)
    nxt = eng.queue.next_customer()
    assert nxt["mobile"] == db.all_customers()[0]["mobile"]  # retried first
    r = eng.simulate("interested")
    assert r["result"] == "Interested"
    eng2 = Engine(db, CFG)
    assert eng2.queue.next_customer()["mobile"] == "9876500002"  # moves on

def test_import_dedup_and_invalid(tmp_path=None):
    import openpyxl, tempfile
    tmp = pathlib.Path(tempfile.mkdtemp())
    wb = openpyxl.Workbook(); ws = wb.active
    ws.append(["Mobile", "Name", "Offer", "Validity", "Benefits", "Recharge_Status"])
    ws.append(["9876500001", "Asha", "₹299", "28 Days", "Unlimited calling", "Expired"])
    ws.append(["9876500001", "Asha dup", "₹299", "28 Days", "x", "Expired"])  # dup in file
    ws.append(["12345", "Bad", "₹99", "7 Days", "x", "Expired"])              # invalid
    ws.append([None, None, None, None, None, None])                            # empty row
    ws.append(["9876500002", "रवि", "₹199", "30 Days", "2GB daily", "Expired"]) # hindi
    f = tmp / "in.xlsx"; wb.save(f)
    db = make_db()
    res = import_file(db, f)
    assert res.inserted == 2 and res.duplicates == 1 and len(res.invalid) == 1

def test_recovery_after_crash():
    db = make_db()
    for c in CUSTOMERS: db.upsert_customer(c)
    eng = Engine(db, CFG)
    # simulate a crash: open attempt never finished
    eng.db.add_attempt(1, 1, "2026-01-01T10:00:00")
    eng2 = Engine(db, CFG)
    assert eng2.recover() == 1
    assert db.get_customer(1)["call_status"] == "Failed"
