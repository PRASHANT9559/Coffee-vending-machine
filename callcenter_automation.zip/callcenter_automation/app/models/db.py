"""SQLite data layer: schema, connection, CRUD. Stdlib only, transactional."""
from __future__ import annotations
import json, sqlite3, threading, datetime, pathlib

_SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id TEXT DEFAULT '',
    name TEXT DEFAULT '',
    mobile TEXT NOT NULL UNIQUE,
    recharge_status TEXT DEFAULT '',
    offer TEXT DEFAULT '',
    validity TEXT DEFAULT '',
    benefits TEXT DEFAULT '',
    language TEXT DEFAULT 'hi',
    preferred_call_time TEXT DEFAULT '',
    callback_time TEXT DEFAULT '',
    max_attempts INTEGER DEFAULT 0,
    remarks TEXT DEFAULT '',
    call_status TEXT DEFAULT 'Pending',
    call_time TEXT DEFAULT '',
    call_duration INTEGER DEFAULT 0,
    customer_response TEXT DEFAULT '',
    intent TEXT DEFAULT '',
    attempt_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT '',
    updated_at TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    source_file TEXT DEFAULT '',
    status TEXT DEFAULT 'active',
    created_at TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS call_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_pk INTEGER NOT NULL,
    campaign_id INTEGER DEFAULT 0,
    attempt_no INTEGER DEFAULT 1,
    started_at TEXT DEFAULT '',
    ended_at TEXT DEFAULT '',
    duration INTEGER DEFAULT 0,
    result TEXT DEFAULT '',
    intent TEXT DEFAULT '',
    transcript TEXT DEFAULT '',
    provider_ref TEXT DEFAULT '',
    FOREIGN KEY(customer_pk) REFERENCES customers(id)
);
CREATE TABLE IF NOT EXISTS callbacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_pk INTEGER NOT NULL,
    scheduled_for TEXT NOT NULL,
    status TEXT DEFAULT 'scheduled',   -- scheduled | done | cancelled
    created_at TEXT DEFAULT '',
    FOREIGN KEY(customer_pk) REFERENCES customers(id)
);
CREATE TABLE IF NOT EXISTS configuration (
    key TEXT PRIMARY KEY,
    value TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT DEFAULT '',
    actor TEXT DEFAULT 'system',
    action TEXT DEFAULT '',
    detail TEXT DEFAULT ''
);
"""

_local = threading.local()

def connect(db_path: pathlib.Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.executescript(_SCHEMA)
    return conn

class Database:
    def __init__(self, db_path: pathlib.Path):
        self.conn = connect(db_path)
        self.lock = threading.RLock()

    # -- customers --
    CUSTOMER_COLS = ["customer_id","name","mobile","recharge_status","offer","validity",
        "benefits","language","preferred_call_time","callback_time","max_attempts","remarks"]

    def upsert_customer(self, data: dict) -> tuple[int, bool]:
        """Insert or (on mobile conflict) skip. Returns (id, inserted)."""
        now = datetime.datetime.now().isoformat(timespec="seconds")
        row = self.conn.execute("SELECT id FROM customers WHERE mobile=?", (data["mobile"],)).fetchone()
        if row:
            return row["id"], False
        cols = [c for c in self.CUSTOMER_COLS if c in data]
        vals = [data[c] for c in cols]
        sql = f"INSERT INTO customers ({','.join(cols)},created_at,updated_at) VALUES ({','.join('?'*len(cols))},?,?)"
        with self.lock:
            cur = self.conn.execute(sql, vals + [now, now])
            self.conn.commit()
        return cur.lastrowid, True

    def get_customer(self, pk: int) -> dict | None:
        row = self.conn.execute("SELECT * FROM customers WHERE id=?", (pk,)).fetchone()
        return dict(row) if row else None

    def update_customer_call(self, pk: int, fields: dict) -> None:
        fields["updated_at"] = datetime.datetime.now().isoformat(timespec="seconds")
        sets = ",".join(f"{k}=?" for k in fields)
        with self.lock:
            self.conn.execute(f"UPDATE customers SET {sets} WHERE id=?", list(fields.values()) + [pk])
            self.conn.commit()

    def all_customers(self) -> list[dict]:
        return [dict(r) for r in self.conn.execute("SELECT * FROM customers ORDER BY id").fetchall()]

    def next_pending(self, allowed_statuses=("Pending",)) -> dict | None:
        qs = ",".join("?" * len(allowed_statuses))
        row = self.conn.execute(
            f"SELECT * FROM customers WHERE call_status IN ({qs}) AND call_status!='Invalid' ORDER BY id LIMIT 1",
            allowed_statuses).fetchone()
        return dict(row) if row else None

    def next_due_callback(self) -> dict | None:
        now = datetime.datetime.now().isoformat(timespec="seconds")
        row = self.conn.execute(
            """SELECT c.* FROM callbacks cb JOIN customers c ON c.id=cb.customer_pk
               WHERE cb.status='scheduled' AND cb.scheduled_for<=? ORDER BY cb.scheduled_for LIMIT 1""",
            (now,)).fetchone()
        return dict(row) if row else None

    # -- attempts / callbacks / audit --
    def add_attempt(self, customer_pk: int, attempt_no: int, started_at: str, provider_ref: str = "") -> int:
        with self.lock:
            cur = self.conn.execute(
                "INSERT INTO call_attempts (customer_pk,attempt_no,started_at,provider_ref) VALUES (?,?,?,?)",
                (customer_pk, attempt_no, started_at, provider_ref))
            self.conn.commit()
        return cur.lastrowid

    def finish_attempt(self, attempt_pk: int, ended_at: str, duration: int, result: str, intent: str, transcript: str) -> None:
        with self.lock:
            self.conn.execute(
                "UPDATE call_attempts SET ended_at=?,duration=?,result=?,intent=?,transcript=? WHERE id=?",
                (ended_at, duration, result, intent, transcript, attempt_pk))
            self.conn.commit()

    def add_callback(self, customer_pk: int, scheduled_for: str) -> int:
        now = datetime.datetime.now().isoformat(timespec="seconds")
        with self.lock:
            cur = self.conn.execute(
                "INSERT INTO callbacks (customer_pk,scheduled_for,created_at) VALUES (?,?,?)",
                (customer_pk, scheduled_for, now))
            self.conn.commit()
        return cur.lastrowid

    def complete_callback(self, customer_pk: int) -> None:
        with self.lock:
            self.conn.execute("UPDATE callbacks SET status='done' WHERE customer_pk=? AND status='scheduled'",
                              (customer_pk,))
            self.conn.commit()

    def audit(self, action: str, detail: str = "", actor: str = "system") -> None:
        ts = datetime.datetime.now().isoformat(timespec="seconds")
        with self.lock:
            self.conn.execute("INSERT INTO audit_log (ts,actor,action,detail) VALUES (?,?,?,?)",
                              (ts, actor, action, detail[:1000]))
            self.conn.commit()

    def stats(self) -> dict:
        rows = self.conn.execute("SELECT call_status, COUNT(*) n FROM customers GROUP BY call_status").fetchall()
        counts = {r["call_status"]: r["n"] for r in rows}
        counts["total"] = sum(counts.values())
        return counts

    def due_callbacks_list(self) -> list[dict]:
        rows = self.conn.execute(
            """SELECT cb.id cb_id, cb.scheduled_for, cb.status, c.id, c.name, c.mobile
               FROM callbacks cb JOIN customers c ON c.id=cb.customer_pk
               WHERE cb.status='scheduled' ORDER BY cb.scheduled_for""").fetchall()
        return [dict(r) for r in rows]

    def attempts_for(self, customer_pk: int) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM call_attempts WHERE customer_pk=? ORDER BY id", (customer_pk,)).fetchall()]
