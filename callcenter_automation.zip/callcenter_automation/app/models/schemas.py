"""Pydantic models for API boundaries + domain enums."""
from __future__ import annotations
from enum import Enum
from pydantic import BaseModel, Field

class CallStatus(str, Enum):
    PENDING = "Pending"
    CALLED = "Called"
    INTERESTED = "Interested"
    NOT_INTERESTED = "Not Interested"
    CALLBACK = "Callback"
    NO_ANSWER = "No Answer"
    BUSY = "Busy"
    FAILED = "Failed"
    UNKNOWN = "Unknown"
    INVALID = "Invalid"          # data validation failure

class Intent(str, Enum):
    INTERESTED = "Interested"
    NOT_INTERESTED = "Not Interested"
    CALLBACK = "Callback"
    NO_ANSWER = "No Answer"
    BUSY = "Busy"
    FAILED = "Failed"
    UNKNOWN = "Unknown"

class CustomerIn(BaseModel):
    name: str = ""
    mobile: str
    recharge_status: str = ""
    offer: str = ""
    validity: str = ""
    benefits: str = ""
    customer_id: str = ""
    language: str = "hi"
    preferred_call_time: str = ""
    callback_time: str = ""
    max_attempts: int = 0
    remarks: str = ""

class CustomerOut(CustomerIn):
    id: int
    call_status: str = "Pending"
    call_time: str = ""
    call_duration: int = 0
    customer_response: str = ""
    intent: str = ""
    attempt_count: int = 0
    created_at: str = ""
    updated_at: str = ""

class StatsOut(BaseModel):
    total: int = 0
    pending: int = 0
    called: int = 0
    interested: int = 0
    not_interested: int = 0
    callback: int = 0
    no_answer: int = 0
    busy: int = 0
    failed: int = 0
    unknown: int = 0
    invalid: int = 0

class CallResultIn(BaseModel):
    customer_id: int
    intent: Intent
    transcript: str = ""
    duration: int = 0
    callback_time: str = ""
    remarks: str = ""

class SimulateIn(BaseModel):
    scenario: str = Field(default="interested")   # see tests for scenario names
