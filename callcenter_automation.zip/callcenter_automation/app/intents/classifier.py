"""Rule-based Hindi/English intent classifier.
Not exact string matching: keyword + phrase scoring, conservative defaults."""
from __future__ import annotations
from app.models.schemas import Intent

RULES: list[tuple[Intent, list[str]]] = [
    (Intent.INTERESTED, [
        "1", "हाँ", "हां", "haan", "ha", "yes", "yup", " interested", "interested",
        "रिचार्ज करना है", "रिचार्ज कर दो", "कर दीजिए", "कर दो", "करना है",
        "चाहिए", "लेना है", "बताइए ऑफर", "ऑफर बताइए", "अभी करें", "कर देना",
    ]),
    (Intent.NOT_INTERESTED, [
        "3", "नहीं", "नही", "nahi", "no", "nope", "not interested",
        "नहीं चाहिए", "नही चाहिए", "बंद करो", "मत करो", "नहीं करना", "नही करना",
    ]),
    (Intent.CALLBACK, [
        "2", "बाद में", "baad mein", "later", "कल फोन", "शाम को", "सुबह करना",
        "अभी व्यस्त", "व्यस्त", "busy now", "बाद में फोन", "कॉल बैक", "callback",
        "थोड़ी देर बाद", "कल बात",
    ]),
]

GENERIC_POSITIVE = {"हाँ", "हां", "haan", "yes", "ha"}
GENERIC_NEGATIVE = {"नहीं", "नही", "nahi", "no", "nope"}

def classify(text: str) -> tuple[Intent, float]:
    """Returns (intent, confidence). Conservative: ambiguous -> UNKNOWN."""
    t = (text or "").strip().lower()
    if not t:
        return Intent.NO_ANSWER, 0.5
    scores: dict[Intent, int] = {}
    for intent, phrases in RULES:
        score = sum(1 for p in phrases if p in t)
        if score:
            scores[intent] = scores.get(intent, 0) + score
    if scores:
        best = max(scores, key=scores.get)
        total = sum(scores.values())
        conf = round(scores[best] / total, 2) if total else 0.0
        if conf >= 0.5:
            return best, conf
    # single-word fallback: bare हाँ/नहीं with no other signal
    words = t.split()
    if len(words) == 1:
        if t in GENERIC_POSITIVE:
            return Intent.INTERESTED, 0.6
        if t in GENERIC_NEGATIVE:
            return Intent.NOT_INTERESTED, 0.6
    return Intent.UNKNOWN, 0.3
