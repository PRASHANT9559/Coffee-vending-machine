"""FastAPI application: REST API + WebSocket dashboard + static UI."""
from __future__ import annotations
import asyncio, pathlib
from fastapi import FastAPI, UploadFile, File, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import get_config
from app.core.logging_setup import setup_logging
from app.core.security import verify_dashboard_token
from app.models.db import Database
from app.models.schemas import StatsOut, SimulateIn
from app.services.importer import import_file
from app.services.exporter import export_customers
from app.services.engine import Engine

cfg = get_config()
log = setup_logging(cfg.get("logging", "level", default="INFO"),
                    str(cfg.path("logging", "dir", default="logs")))
db = Database(cfg.path("database", "path", default="data/callcenter.db"))
engine = Engine(db, cfg)
recovered = engine.recover()
if recovered:
    log.warning("Recovered %s orphaned attempt(s) after restart", recovered)

app = FastAPI(title=cfg.get("app", "name", default="CallCenter"), docs_url="/docs")
STATIC = pathlib.Path(__file__).parent / "web" / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")

clients: set[WebSocket] = set()

async def broadcast(payload: dict):
    dead = []
    for ws in clients:
        try: await ws.send_json(payload)
        except Exception: dead.append(ws)
    for ws in dead: clients.discard(ws)

def _check_token(token: str | None):
    if not verify_dashboard_token(token, cfg.get("security", "dashboard_token", default="")):
        raise HTTPException(401, "invalid dashboard token")

@app.get("/")
def index(token: str | None = Query(default=None)):
    _check_token(token)
    return FileResponse(STATIC / "index.html")

@app.post("/api/import")
async def api_import(file: UploadFile = File(...), token: str | None = Query(default=None)):
    _check_token(token)
    upload_dir = cfg.base_dir / "data" / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    dest = upload_dir / pathlib.Path(file.filename).name
    content = await file.read()
    if len(content) > 25 * 1024 * 1024:
        raise HTTPException(413, "file too large (max 25MB)")
    dest.write_bytes(content)
    try:
        res = await asyncio.to_thread(import_file, db, dest)
    except ValueError as e:
        raise HTTPException(400, str(e))
    out = {"inserted": res.inserted, "duplicates": res.duplicates, "invalid": res.invalid}
    await broadcast({"type": "import", **out})
    return out

@app.get("/api/customers")
def api_customers(token: str | None = Query(default=None)):
    _check_token(token)
    return db.all_customers()

@app.get("/api/stats", response_model=StatsOut)
def api_stats(token: str | None = Query(default=None)):
    _check_token(token)
    c = db.stats()
    def g(k): return c.get(k, 0)
    return StatsOut(total=g("total"), pending=g("Pending"), called=g("Called"),
        interested=g("Interested"), not_interested=g("Not Interested"),
        callback=g("Callback"), no_answer=g("No Answer"), busy=g("Busy"),
        failed=g("Failed"), unknown=g("Unknown"), invalid=g("Invalid"))

@app.get("/api/next-script")
def api_next_script(token: str | None = Query(default=None)):
    _check_token(token)
    nxt = db.next_pending() or db.next_due_callback()
    if not nxt: return {"empty": True}
    return {"empty": False, "customer": nxt, "script": engine.generate_script_for(nxt)}

@app.post("/api/call-next")
async def api_call_next(token: str | None = Query(default=None)):
    _check_token(token)
    result = await asyncio.to_thread(engine.call_next)
    await broadcast({"type": "call", "result": result})
    return result

@app.post("/api/simulate")
async def api_simulate(body: SimulateIn, token: str | None = Query(default=None)):
    _check_token(token)
    result = await asyncio.to_thread(engine.simulate, body.scenario)
    await broadcast({"type": "call", "result": result})
    return result

@app.post("/api/call/{pk}/respond")
async def api_manual_response(pk: int, body: SimulateIn, token: str | None = Query(default=None)):
    """Manual/mock mode: push a response into the active mock call."""
    _check_token(token)
    from app.telephony.mock_provider import scenario_events
    if isinstance(engine.tel, type(engine.tel).__mro__[0]) and hasattr(engine.tel, "active"):
        for h in engine.tel.active.values():
            if h.customer_pk == pk:
                engine.tel.push_events(h.provider_ref, scenario_events(body.scenario)[1:])
                return {"ok": True}
    return {"ok": False, "message": "no active mock call for this customer"}

@app.get("/api/export")
def api_export(token: str | None = Query(default=None)):
    _check_token(token)
    path = export_customers(db, cfg.base_dir / "data" / "exports")
    return FileResponse(path, filename=path.name)

@app.get("/api/callbacks")
def api_callbacks(token: str | None = Query(default=None)):
    _check_token(token)
    return db.due_callbacks_list()

@app.get("/api/status")
def api_status(token: str | None = Query(default=None)):
    _check_token(token)
    return engine.status()

@app.get("/api/attempts/{pk}")
def api_attempts(pk: int, token: str | None = Query(default=None)):
    _check_token(token)
    return db.attempts_for(pk)

@app.post("/webhooks/call-events")
async def telephony_webhook(payload: dict):
    """Inbound events from the authorized telephony provider."""
    ref = str(payload.get("call_ref", ""))
    if isinstance(engine.tel, __import__("app.telephony.http_provider", fromlist=["HttpWebhookTelephony"]).HttpWebhookTelephony):
        ev = engine.tel.ingest_webhook(ref, payload)
        await broadcast({"type": "telephony", "ref": ref, "event": ev.kind})
        return {"ok": True}
    return JSONResponse({"ok": False, "message": "telephony provider is mock"}, status_code=400)

@app.websocket("/ws")
async def ws(ws: WebSocket, token: str | None = Query(default=None)):
    _check_token(token)
    await ws.accept()
    clients.add(ws)
    try:
        while True:
            await ws.receive_text()   # keepalive
    except WebSocketDisconnect:
        clients.discard(ws)

if __name__ == "__main__":
    import uvicorn
    app_ = app
    uvicorn.run(app_, host=cfg.get("app", "host", default="127.0.0.1"),
                port=int(cfg.get("app", "port", default=8000)))
