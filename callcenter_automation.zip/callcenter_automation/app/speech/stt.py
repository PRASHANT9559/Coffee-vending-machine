"""Speech-to-text abstraction + intent detection entry point."""
from __future__ import annotations
from app.intents.classifier import classify
from app.models.schemas import Intent

class STTResult:
    def __init__(self, ok: bool, text: str = "", error: str = ""):
        self.ok, self.text, self.error = ok, text, error

class STTProvider:
    name = "base"
    def transcribe(self, audio_path: str, language: str = "hi") -> STTResult:
        raise NotImplementedError

class MockSTT(STTProvider):
    """Deterministic stub: transcribes nothing by itself; used with scripted responses."""
    name = "mock"
    def transcribe(self, audio_path: str, language: str = "hi") -> STTResult:
        return STTResult(True, "")

def detect_intent(text: str) -> tuple[Intent, float]:
    return classify(text)
