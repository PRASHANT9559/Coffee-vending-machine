"""TTS abstraction. Providers: gTTS (online), pyttsx3 (local), Mock (silent file)."""
from __future__ import annotations
import pathlib
from app.core.security import sanitize_text

class TTSResult:
    def __init__(self, ok: bool, audio_path: str = "", error: str = ""):
        self.ok, self.audio_path, self.error = ok, audio_path, error

class TTSProvider:
    name = "base"
    def synthesize(self, text: str, out_path: pathlib.Path, language: str = "hi") -> TTSResult:
        raise NotImplementedError

class MockTTS(TTSProvider):
    """Writes the script text to a .txt sidecar; produces a zero-byte marker file.
    Keeps the pipeline fully testable offline."""
    name = "mock"
    def synthesize(self, text, out_path, language="hi"):
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.with_suffix(".txt").write_text(sanitize_text(text, 2000), encoding="utf-8")
            out_path.touch()
            return TTSResult(True, str(out_path))
        except Exception as e:
            return TTSResult(False, error=str(e))

class GTTSTTS(TTSProvider):
    name = "gtts"
    def synthesize(self, text, out_path, language="hi"):
        try:
            from gtts import gTTS
            out_path.parent.mkdir(parents=True, exist_ok=True)
            gTTS(text=sanitize_text(text, 2000), lang="hi", slow=False).save(str(out_path))
            return TTSResult(True, str(out_path))
        except Exception as e:
            return TTSResult(False, error=str(e))

class Pyttsx3TTS(TTSProvider):
    name = "pyttsx3"
    def __init__(self, rate: int = 165):
        self.rate = rate
    def synthesize(self, text, out_path, language="hi"):
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty("rate", self.rate)
            engine.save_to_file(sanitize_text(text, 2000), str(out_path))
            engine.runAndWait()
            engine.stop()
            if not out_path.exists() or out_path.stat().st_size == 0:
                return TTSResult(False, error="pyttsx3 produced empty audio (Hindi voice may be unavailable)")
            return TTSResult(True, str(out_path))
        except Exception as e:
            return TTSResult(False, error=str(e))

def get_tts_provider(name: str, rate: int = 165) -> TTSProvider:
    return {"mock": MockTTS, "gtts": GTTSTTS, "pyttsx3": lambda: Pyttsx3TTS(rate)}.get(name, MockTTS)()
