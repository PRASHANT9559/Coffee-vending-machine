"""Personalized Hindi script generation from customer record."""
from __future__ import annotations
import re
from app.core.security import sanitize_text

_NUM_WORDS = {"299": "दो सौ निन्यानवे", "199": "एक सौ निन्यानवे", "399": "तीन सौ निन्यानवे",
              "499": "चार सौ निन्यानवे", "666": "छह सौ छियासठ", "1": "एक", "2": "दो", "3": "तीन"}

def speak_amount(offer: str) -> str:
    """₹299 -> 'दो सौ निन्यानवे रुपये' (fallback: digits spoken as-is)."""
    offer = sanitize_text(offer, 50)
    m = re.search(r"(\d+)", offer)
    if not m:
        return offer
    digits = m.group(1)
    if digits in _NUM_WORDS:
        return _NUM_WORDS[digits] + " रुपये"
    return " ".join(_NUM_WORDS.get(d, d) for d in digits) + " रुपये"

def speak_validity(validity: str) -> str:
    validity = sanitize_text(validity, 50)
    m = re.search(r"(\d+)", validity)
    if not m:
        return validity or "पूरी वैधता"
    n = m.group(1)
    days_word = {"28": "अठ्ठाईस", "30": "तीस", "56": "छप्पन", "84": "चौरासी", "7": "सात", "14": "चौदह"}
    dw = days_word.get(n, n)
    return f"{dw} दिनों"

def generate_script(c: dict, language: str = "hi") -> str:
    """Builds the personalized Hindi IVR script."""
    name = sanitize_text(c.get("name") or "ग्राहक", 60)
    offer = sanitize_text(c.get("offer") or "", 50)
    validity = sanitize_text(c.get("validity") or "", 50)
    benefits = sanitize_text(c.get("benefits") or "", 200)
    status = (c.get("recharge_status") or "").lower()

    status_line = ("आपके मोबाइल नंबर पर रिचार्ज समाप्त हो गया है" if status == "expired"
                   else "आपके नंबर पर एक शानदार ऑफर उपलब्ध है")
    parts = [f"नमस्ते {name} जी, {status_line}।"]
    if offer:
        parts.append(f"अभी आपके नंबर पर {speak_amount(offer)} का {speak_validity(validity)} वाला ऑफर उपलब्ध है।")
    if benefits:
        parts.append(f"इसमें {benefits} की सुविधा है।")
    parts.append("अगर आप रिचार्ज करना चाहते हैं तो 1 दबाएँ। बाद में कॉल करने के लिए 2 दबाएँ। ऑफर नहीं चाहिए तो 3 दबाएँ।")
    return " ".join(parts)
