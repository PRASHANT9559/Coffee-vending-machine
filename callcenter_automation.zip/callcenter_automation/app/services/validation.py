"""Data validation engine: phone numbers, required fields, duplicates."""
from __future__ import annotations
import re
from app.core.security import sanitize_text

MOBILE_RE = re.compile(r"^(\+?91)?[6-9]\d{9}$")

def normalize_mobile(raw: str) -> str:
    digits = re.sub(r"\D", "", str(raw or ""))
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    if len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    return digits

def validate_mobile(raw: str) -> tuple[bool, str]:
    m = normalize_mobile(raw)
    if not m:
        return False, "empty"
    if not MOBILE_RE.match(m):
        return False, "invalid_format"
    return True, m

REQUIRED = ["name", "mobile"]

def validate_record(rec: dict) -> tuple[bool, list[str], dict]:
    """Returns (ok, problems, cleaned_record). Never raises."""
    problems: list[str] = []
    cleaned = {k: sanitize_text(v, 300) for k, v in rec.items()}
    for field in REQUIRED:
        if not cleaned.get(field):
            problems.append(f"missing_{field}")
    if cleaned.get("mobile"):
        ok, norm = validate_mobile(cleaned["mobile"])
        if ok:
            cleaned["mobile"] = norm
        else:
            problems.append(f"mobile_{norm}")
    else:
        problems.append("mobile_empty")
    return (len(problems) == 0), problems, cleaned

# Column-name aliases -> canonical field (handles reordering & variants)
COLUMN_MAP = {
    "name": "name", "customer_name": "name", "नाम": "name",
    "mobile": "mobile", "phone": "mobile", "mobile_number": "mobile", "मोबाइल": "mobile",
    "recharge_status": "recharge_status", "rechargestatus": "recharge_status",
    "offer": "offer", "ऑफर": "offer", "plan": "offer",
    "validity": "validity", "वैधता": "validity",
    "benefits": "benefits", "लाभ": "benefits",
    "call_status": "call_status",
    "customer_id": "customer_id", "customerid": "customer_id",
    "language": "language", "भाषा": "language",
    "preferred_call_time": "preferred_call_time",
    "last_call_time": "call_time",
    "max_attempts": "max_attempts",
    "remarks": "remarks", "टिप्पणी": "remarks",
    "callback_time": "callback_time",
}

def map_columns(headers: list[str]) -> dict[str, str]:
    """excel_header -> canonical field"""
    out = {}
    for h in headers:
        if h is None:
            continue
        key = str(h).strip().lower().replace(" ", "_")
        if key in COLUMN_MAP:
            out[str(h)] = COLUMN_MAP[key]
    return out
