"""Campaign/queue manager + retry policy + callback scheduling."""
from __future__ import annotations
import datetime
from app.core.logging_setup import setup_logging

FINAL_STATUSES = {"Interested", "Not Interested"}   # no auto-retry

class QueueManager:
    def __init__(self, db, cfg):
        self.db, self.cfg = db, cfg
        self.log = setup_logging()

    def next_customer(self) -> dict | None:
        """Priority: due callbacks first, then Pending queue."""
        cb = self.db.next_due_callback()
        if cb:
            self.db.complete_callback(cb["id"])
            return cb
        return self.db.next_pending()

    def _within_calling_window(self) -> bool:
        s = self.cfg.get("calling", "allowed_hours_start", default="00:00")
        e = self.cfg.get("calling", "allowed_hours_end", default="23:59")
        now = datetime.datetime.now().time()
        return datetime.time(*map(int, s.split(":"))) <= now <= datetime.time(*map(int, e.split(":")))

    def record_result(self, customer: dict, result: str, intent: str, transcript: str,
                      duration: int, callback_time: str = "", remarks: str = "") -> None:
        pk = customer["id"]
        attempts = customer.get("attempt_count", 0) + 1
        fields = {
            "call_status": result, "intent": intent,
            "customer_response": transcript[:300], "call_duration": duration,
            "call_time": datetime.datetime.now().isoformat(timespec="seconds"),
            "attempt_count": attempts, "remarks": (remarks or customer.get("remarks", ""))[:300],
        }
        if callback_time:
            fields["callback_time"] = callback_time
            self.db.add_callback(pk, callback_time)
        self.db.update_customer_call(pk, fields)
        self.db.audit("call_result", f"customer_pk={pk} result={result}")

    def should_retry(self, customer: dict) -> tuple[bool, str]:
        """Respects FINAL_STATUSES, max attempts, and spacing policy."""
        status = customer.get("call_status", "Pending")
        if status in FINAL_STATUSES:
            return False, "final_status"
        max_att = customer.get("max_attempts") or self.cfg.get("retry_policy", "max_attempts_default", default=3)
        if customer.get("attempt_count", 0) >= max_att:
            return False, "max_attempts_reached"
        retry_map = {
            "No Answer": "no_answer_retry_after_minutes",
            "Busy": "busy_retry_after_minutes",
            "Failed": "failed_retry_after_minutes",
        }
        key = retry_map.get(status)
        if key:
            mins = int(self.cfg.get("retry_policy", key, default=60))
            last = customer.get("call_time", "")
            if last:
                try:
                    gap = datetime.datetime.now() - datetime.datetime.fromisoformat(last)
                    if gap < datetime.timedelta(minutes=mins):
                        return False, "retry_backoff"
                except ValueError:
                    pass
            return True, "retry_scheduled"
        return status == "Pending", "pending"
