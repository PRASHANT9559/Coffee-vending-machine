"""CallSessionManager / automation engine: drives the workflow end to end,
with crash recovery (interrupted attempts are finalized on startup)."""
from __future__ import annotations
import datetime, threading
from app.core.logging_setup import setup_logging
from app.services.script_generator import generate_script
from app.services.queue_manager import QueueManager
from app.voice.tts import get_tts_provider
from app.telephony.mock_provider import MockTelephony, scenario_events
from app.telephony.http_provider import HttpWebhookTelephony
from app.telephony.base import TelephonyError
from app.speech.stt import detect_intent

class Engine:
    def __init__(self, db, cfg, tts=None, telephony=None):
        self.db, self.cfg = db, cfg
        self.log = setup_logging()
        self.tts = tts or get_tts_provider(cfg.get("tts", "provider", default="mock"),
                                           int(cfg.get("tts", "speech_rate", default=165)))
        if telephony is not None:
            self.tel = telephony
        elif cfg.get("telephony", "provider", default="mock") == "http_webhook":
            self.tel = HttpWebhookTelephony(
                cfg.get("telephony", "base_url", default=""),
                cfg.get("telephony", "api_key_env", default="TELEPHONY_API_KEY"),
                cfg.get("telephony", "from_number_env", default="TELEPHONY_FROM_NUMBER"))
        else:
            self.tel = MockTelephony()
        self.queue = QueueManager(db, cfg)
        self.current: dict | None = None
        self.state = "idle"   # idle | calling | done
        self.last_error = ""
        self._lock = threading.Lock()

    # ---- crash recovery: close out attempts that never finished ----
    def recover(self) -> int:
        rows = self.db.conn.execute(
            "SELECT id, customer_pk FROM call_attempts WHERE ended_at=''").fetchall()
        now = datetime.datetime.now().isoformat(timespec="seconds")
        for r in rows:
            self.db.finish_attempt(r["id"], now, 0, "Failed", "Failed", "recovered after restart")
            self.db.update_customer_call(r["customer_pk"], {"call_status": "Failed"})
        if rows:
            self.db.audit("recovery", f"finalized {len(rows)} orphaned attempt(s)")
        return len(rows)

    def generate_script_for(self, customer: dict) -> str:
        return generate_script(customer, customer.get("language", "hi"))

    def _run_call(self, customer: dict, scenario: str = "") -> dict:
        with self._lock:
            self.current, self.state = customer, "calling"
        script = self.generate_script_for(customer)
        out_dir = self.cfg.path("tts", "output_dir", default="data/tts")
        audio = out_dir / f"customer_{customer['id']}.mp3"
        tts_res = self.tts.synthesize(script, audio, customer.get("language", "hi"))
        if not tts_res.ok:
            self.last_error = f"TTS failure: {tts_res.error}"
            self.queue.record_result(customer, "Failed", "Failed", "", 0, remarks="TTS failure")
            self._finish(); return {"result": "Failed", "error": self.last_error}

        started = datetime.datetime.now().isoformat(timespec="seconds")
        attempt_pk = self.db.add_attempt(customer["id"], customer.get("attempt_count", 0) + 1, started)
        try:
            handle = self.tel.initiate(customer, tts_res.audio_path,
                                       self.cfg.get("telephony", "callback_webhook_path", default=""))
        except TelephonyError as e:
            self.last_error = str(e)
            self.db.finish_attempt(attempt_pk, datetime.datetime.now().isoformat(timespec="seconds"),
                                   0, "Failed", "Failed", str(e))
            self.queue.record_result(customer, "Failed", "Failed", str(e), 0)
            self._finish(); return {"result": "Failed", "error": self.last_error}

        events = list(handle.events)
        if isinstance(self.tel, MockTelephony):
            events = scenario_events(scenario) if scenario else self._interactive_mock(handle)
        result = self._classify_events(events)

        ended = datetime.datetime.now().isoformat(timespec="seconds")
        self.db.finish_attempt(attempt_pk, ended, result["duration"], result["result"],
                               result["intent"].value, result.get("transcript", ""))
        if result["callback_time"]:
            self.queue.record_result(customer, result["result"], result["intent"].value,
                                     result.get("transcript", ""), result["duration"],
                                     callback_time=result["callback_time"])
        else:
            self.queue.record_result(customer, result["result"], result["intent"].value,
                                     result.get("transcript", ""), result["duration"])
        self._finish()
        return result

    def _interactive_mock(self, handle) -> list:
        """Manual/test mode without a scenario: waits briefly for dashboard-pushed events."""
        import time
        for _ in range(90):   # up to 45s for a dashboard-injected response
            evs = [e for e in handle.events if e.kind not in ("initiated",)]
            if any(e.kind in ("ended", "dtmf", "speech", "busy", "no_answer", "failed") for e in evs):
                return evs
            time.sleep(0.5)
        return [type("E", (), {"kind": "no_answer", "duration": 0})()]

    def _classify_events(self, events) -> dict:
        for e in events:
            k = e.kind
            if k == "dtmf" and e.dtmf:
                intent, conf = detect_intent(e.dtmf)
                return {"result": intent.value, "intent": intent, "duration": e.duration or 30,
                        "transcript": f"DTMF {e.dtmf}", "callback_time": self._default_callback() if intent.value == "Callback" else ""}
            if k == "speech" and e.speech_text:
                intent, conf = detect_intent(e.speech_text)
                cb = self._extract_callback_time(e.speech_text)
                return {"result": intent.value, "intent": intent, "duration": e.duration,
                        "transcript": e.speech_text, "callback_time": cb}
            if k == "busy":
                return {"result": "Busy", "intent": type("I", (), {"value": "Busy"})(), "duration": 0, "transcript": ""}
            if k == "no_answer":
                return {"result": "No Answer", "intent": type("I", (), {"value": "No Answer"})(), "duration": 0, "transcript": ""}
            if k == "failed":
                return {"result": "Failed", "intent": type("I", (), {"value": "Failed"})(), "duration": 0, "transcript": e.error}
        return {"result": "Unknown", "intent": type("I", (), {"value": "Unknown"})(), "duration": 0, "transcript": ""}

    def _default_callback(self) -> str:
        return (datetime.datetime.now() + datetime.timedelta(hours=4)).isoformat(timespec="seconds")

    def _extract_callback_time(self, text: str) -> str:
        t = text.lower()
        base = datetime.datetime.now()
        if "कल" in t: base += datetime.timedelta(days=1)
        if "शाम" in t: base = base.replace(hour=18, minute=0)
        elif "सुबह" in t: base = base.replace(hour=10, minute=0)
        else: base += datetime.timedelta(hours=4)
        return base.isoformat(timespec="seconds")

    def call_next(self, scenario: str = "") -> dict:
        customer = self.queue.next_customer()
        if not customer:
            self.state = "idle"
            return {"result": "EMPTY", "message": "Queue is empty"}
        return self._run_call(customer, scenario)

    def call_specific(self, pk: int, scenario: str = "") -> dict:
        c = self.db.get_customer(pk)
        if not c:
            return {"result": "ERROR", "message": "customer not found"}
        return self._run_call(c, scenario)

    def simulate(self, scenario: str) -> dict:
        """Full test-mode pipeline for the next pending customer."""
        return self.call_next(scenario=scenario)

    def _finish(self):
        with self._lock:
            self.state, self.current = "idle", None

    def status(self) -> dict:
        return {"state": self.state,
                "current": self.current,
                "last_error": self.last_error,
                "queue_empty": self.db.next_pending() is None and self.db.next_due_callback() is None}
