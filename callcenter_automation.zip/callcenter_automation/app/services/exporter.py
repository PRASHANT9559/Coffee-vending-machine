"""Excel export/update. Never touches the source file; writes processed_output.xlsx
with backup of any previous output."""
from __future__ import annotations
import pathlib, shutil, datetime

COLUMNS = ["Customer_ID","Name","Mobile","Recharge_Status","Offer","Validity","Benefits",
           "Call_Status","Call_Time","Call_Duration","Customer_Response","Intent",
           "Callback_Time","Attempt_Count","Remarks"]

def export_customers(db, out_dir: pathlib.Path) -> pathlib.Path:
    import openpyxl
    from openpyxl.styles import Font
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"processed_output_{datetime.datetime.now():%Y%m%d_%H%M%S}.xlsx"
    prev = sorted(out_dir.glob("processed_output_*.xlsx"))
    if prev:
        backup = out_dir / f"backup_{prev[-1].name}"
        shutil.copy2(prev[-1], backup)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "CallResults"
    ws.append(COLUMNS)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for c in db.all_customers():
        ws.append([
            c["customer_id"], c["name"], c["mobile"], c["recharge_status"], c["offer"],
            c["validity"], c["benefits"], c["call_status"], c["call_time"],
            c["call_duration"], c["customer_response"], c["intent"],
            c["callback_time"], c["attempt_count"], c["remarks"],
        ])
    wb.save(target)
    db.audit("export", f"file={target.name}")
    return target
