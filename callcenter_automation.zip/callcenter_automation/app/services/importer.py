"""Excel/CSV import: tolerant of missing columns, extra columns, empty rows,
duplicates, Hindi text, ₹ symbols, and column reordering."""
from __future__ import annotations
import csv, pathlib
from app.services.validation import map_columns, validate_record
from app.core.logging_setup import mask_phone

def _iter_xlsx(path: pathlib.Path):
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    try:
        headers = [str(h) if h is not None else "" for h in next(rows)]
    except StopIteration:
        wb.close(); return
    colmap = map_columns(headers)
    for row in rows:
        if row is None or all(c is None or str(c).strip() == "" for c in row):
            continue  # skip empty rows
        rec = {}
        for header, value in zip(headers, row):
            field = colmap.get(header)
            if field and value is not None:
                rec[field] = str(value)
        yield rec
    wb.close()

def _iter_csv(path: pathlib.Path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        colmap = map_columns(reader.fieldnames or [])
        for row in reader:
            if not row or all(not (v or "").strip() for v in row.values()):
                continue
            yield {colmap[h]: v for h, v in row.items() if h in colmap and v is not None}

def iter_records(path: pathlib.Path):
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm"):
        yield from _iter_xlsx(path)
    elif suffix == ".csv":
        yield from _iter_csv(path)
    else:
        raise ValueError(f"Unsupported file type: {suffix} (use .xlsx or .csv)")

class ImportResult:
    def __init__(self):
        self.inserted = 0
        self.duplicates = 0
        self.invalid: list[dict] = []

def import_file(db, path: pathlib.Path, campaign_id: int = 0) -> ImportResult:
    """Imports into DB; invalid rows flagged (not silently dropped), duplicates skipped."""
    from app.core.logging_setup import setup_logging
    log = setup_logging()
    res = ImportResult()
    seen_in_file: set[str] = set()
    for raw in iter_records(path):
        ok, problems, cleaned = validate_record(raw)
        if ok:
            if cleaned["mobile"] in seen_in_file:
                res.duplicates += 1
                continue
            seen_in_file.add(cleaned["mobile"])
            try:
                _, inserted = db.upsert_customer(cleaned)
                res.inserted += int(inserted)
                res.duplicates += int(not inserted)
            except Exception as e:  # DB-level conflict etc.
                log.warning("Insert failed for %s: %s", cleaned.get("mobile"), e)
                res.duplicates += 1
        else:
            res.invalid.append({"mobile": mask_phone(cleaned.get("mobile", "")), "problems": problems})
    db.audit("import", f"file={path.name} inserted={res.inserted} dup={res.duplicates} invalid={len(res.invalid)}")
    return res
