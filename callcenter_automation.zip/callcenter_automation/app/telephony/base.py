"""Telephony abstraction. Only authorized, company-approved providers go here."""
from __future__ import annotations
from dataclasses import dataclass, field

@dataclass
class CallEvent:
    kind: str            # initiated | answered | dtmf | speech | ended | failed | busy | no_answer
    dtmf: str = ""
    speech_text: str = ""
    duration: int = 0
    error: str = ""
    extra: dict = field(default_factory=dict)

@dataclass
class CallHandle:
    provider_ref: str
    customer_pk: int
    events: list = field(default_factory=list)

class TelephonyProvider:
    name = "base"
    def initiate(self, customer: dict, audio_path: str, webhook: str = "") -> CallHandle:
        raise NotImplementedError
    def hangup(self, handle: CallHandle) -> None:
        pass

class TelephonyError(Exception):
    pass
