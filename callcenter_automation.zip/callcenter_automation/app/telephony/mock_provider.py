"""Mock telephony: simulates full call lifecycle, DTMF, hangups.
Test mode uses scripted scenarios; manual mode plays out via the dashboard."""
from __future__ import annotations
import time, itertools
from app.telephony.base import TelephonyProvider, CallHandle, CallEvent

_counter = itertools.count(1)

class MockTelephony(TelephonyProvider):
    name = "mock"
    def __init__(self):
        self.scripted: dict[str, list[CallEvent]] = {}   # scenario name -> events
        self.active: dict[str, CallHandle] = {}

    def initiate(self, customer: dict, audio_path: str, webhook: str = "") -> CallHandle:
        ref = f"mock-{next(_counter)}"
        h = CallHandle(provider_ref=ref, customer_pk=customer.get("id", 0))
        h.events = [CallEvent("initiated")]
        self.active[ref] = h
        return h

    def push_events(self, ref: str, events: list[CallEvent]) -> None:
        h = self.active.get(ref)
        if h:
            h.events.extend(events)

    def hangup(self, handle: CallHandle) -> None:
        handle.events.append(CallEvent("ended"))

# Scenario scripts for simulation mode
def scenario_events(scenario: str) -> list[CallEvent]:
    s = scenario.lower()
    if s in ("interested", "1", "yes"):
        return [CallEvent("answered"), CallEvent("dtmf", dtmf="1"), CallEvent("ended", duration=42)]
    if s in ("callback", "2", "later"):
        return [CallEvent("answered"), CallEvent("dtmf", dtmf="2"), CallEvent("ended", duration=35)]
    if s in ("not_interested", "3", "no"):
        return [CallEvent("answered"), CallEvent("dtmf", dtmf="3"), CallEvent("ended", duration=20)]
    if s in ("speech_interested",):
        return [CallEvent("answered"), CallEvent("speech", speech_text="हाँ, रिचार्ज कर दीजिए"), CallEvent("ended", duration=50)]
    if s in ("speech_callback",):
        return [CallEvent("answered"), CallEvent("speech", speech_text="अभी व्यस्त हूँ, शाम को फोन करना"), CallEvent("ended", duration=30)]
    if s in ("speech_not_interested",):
        return [CallEvent("answered"), CallEvent("speech", speech_text="नहीं चाहिए"), CallEvent("ended", duration=15)]
    if s in ("speech_unknown", "unknown"):
        return [CallEvent("answered"), CallEvent("speech", speech_text="कुछ समझ नहीं आया blabla"), CallEvent("ended", duration=25)]
    if s in ("no_answer",):
        return [CallEvent("no_answer", duration=0)]
    if s in ("busy",):
        return [CallEvent("busy", duration=0)]
    if s in ("failed",):
        return [CallEvent("failed", error="provider rejected call", duration=0)]
    return [CallEvent("unknown", duration=0)]
