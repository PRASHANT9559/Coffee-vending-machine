"""HTTP webhook telephony provider for an AUTHORIZED company-approved provider.
Implements the full adapter; credentials come only from environment variables.
This adapter targets a Twilio-style API shape; adjust paths to your provider's docs."""
from __future__ import annotations
import json, urllib.request, urllib.error
from app.telephony.base import TelephonyProvider, CallHandle, CallEvent, TelephonyError
from app.core.security import get_secret

class HttpWebhookTelephony(TelephonyProvider):
    name = "http_webhook"
    def __init__(self, base_url: str, api_key_env: str, from_number_env: str, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.api_key = get_secret(api_key_env)
        self.from_number = get_secret(from_number_env)
        self.timeout = timeout
        self.pending_events: dict[str, list[CallEvent]] = {}

    def _post(self, path: str, payload: dict) -> dict:
        if not self.base_url:
            raise TelephonyError("telephony.base_url not configured")
        if not self.api_key:
            raise TelephonyError(f"missing API key in env (see {self.api_key_env})")
        req = urllib.request.Request(
            self.base_url + path,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",   # never logged
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8") or "{}")
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                raise TelephonyError("telephony authentication failed (check API key)")
            if e.code == 429:
                raise TelephonyError("telephony provider rate limit hit")
            raise TelephonyError(f"telephony HTTP {e.code}")
        except TimeoutError:
            raise TelephonyError("telephony request timed out")
        except Exception as e:
            raise TelephonyError(f"telephony request failed: {e}")

    def initiate(self, customer: dict, audio_path: str, webhook: str = "") -> CallHandle:
        resp = self._post("/v1/calls", {
            "to": customer["mobile"],
            "from": self.from_number,
            "audio_url": audio_path,          # provider must fetch the TTS audio
            "status_webhook": webhook,
            "record": False,
        })
        ref = resp.get("call_ref") or resp.get("sid") or ""
        if not ref:
            raise TelephonyError("provider did not return a call reference")
        return CallHandle(provider_ref=str(ref), customer_pk=customer.get("id", 0),
                          events=[CallEvent("initiated")])

    def hangup(self, handle: CallHandle) -> None:
        try:
            self._post(f"/v1/calls/{handle.provider_ref}/hangup", {})
        except TelephonyError:
            pass  # call may already be over

    # Called by the FastAPI webhook endpoint when the provider reports events.
    def ingest_webhook(self, provider_ref: str, payload: dict) -> CallEvent:
        kind = payload.get("event", "unknown")
        ev = CallEvent(
            kind=kind,
            dtmf=str(payload.get("dtmf", "")),
            speech_text=str(payload.get("speech", "")),
            duration=int(payload.get("duration", 0) or 0),
            error=str(payload.get("error", "")),
        )
        self.pending_events.setdefault(provider_ref, []).append(ev)
        return ev
