"""Central configuration. Loads YAML + environment, never hard-codes secrets."""
from __future__ import annotations
import os, pathlib, yaml
from functools import lru_cache

BASE_DIR = pathlib.Path(__file__).resolve().parents[2]


def _load_env_file() -> None:
    """Minimal .env loader (no dependency): KEY=VALUE lines."""
    env_path = BASE_DIR / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())


class Config:
    def __init__(self, data: dict):
        self._d = data

    def get(self, *keys, default=None):
        node = self._d
        for k in keys:
            if not isinstance(node, dict) or k not in node:
                return default
            node = node[k]
        return node

    def path(self, *keys, default=""):
        p = self.get(*keys, default=default)
        pp = pathlib.Path(str(p))
        return pp if pp.is_absolute() else BASE_DIR / pp

    @property
    def base_dir(self) -> pathlib.Path:
        return BASE_DIR


@lru_cache
def get_config() -> Config:
    _load_env_file()
    cfg_path = BASE_DIR / "config" / "settings.yaml"
    if not cfg_path.exists():
        raise RuntimeError(f"Config file not found: {cfg_path}")
    with open(cfg_path, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return Config(data)
