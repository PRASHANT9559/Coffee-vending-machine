"""Security helpers: input sanitization, token auth for dashboard, secret access."""
from __future__ import annotations
import hmac, os, re, secrets

SAFE_TEXT_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

def sanitize_text(value: str, max_len: int = 500) -> str:
    """Strip control chars, clamp length. Prevents log/DB injection oddities."""
    if value is None:
        return ""
    v = SAFE_TEXT_RE.sub("", str(value))
    return v.strip()[:max_len]

def get_secret(env_name: str) -> str:
    """Read a secret from the environment only. Returns '' if missing."""
    return os.environ.get(env_name, "")

def constant_time_eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())

def verify_dashboard_token(provided: str | None, expected: str) -> bool:
    if not expected:  # token not configured -> open (dev mode, warn in docs)
        return True
    if not provided:
        return False
    return constant_time_eq(provided, expected)

def new_idempotency_key() -> str:
    return secrets.token_hex(16)
