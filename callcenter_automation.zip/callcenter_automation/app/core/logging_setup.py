"""Safe logging: masked phones, no secrets, rotating files."""
from __future__ import annotations
import logging, re, sys, pathlib
from logging.handlers import RotatingFileHandler

_PHONE_RE = re.compile(r"(\+?91)?[6-9]\d{9}")

def mask_phone(value: str) -> str:
    if not value:
        return value
    v = str(value)
    digits = re.sub(r"\D", "", v)
    if len(digits) >= 10:
        return "XXXXXX" + digits[-4:]
    return v[:2] + "***" if len(v) > 2 else "***"

class PhoneMaskingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = _PHONE_RE.sub(lambda m: mask_phone(m.group(0)), record.msg)
        if record.args:
            record.args = tuple(
                mask_phone(a) if isinstance(a, str) and _PHONE_RE.search(a) else a
                for a in record.args
            )
        return True


def setup_logging(level: str = "INFO", log_dir: str = "logs") -> logging.Logger:
    logger = logging.getLogger("callcenter")
    if logger.handlers:
        return logger
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    fmt = logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    sh.addFilter(PhoneMaskingFilter())
    logger.addHandler(sh)

    pathlib.Path(log_dir).mkdir(parents=True, exist_ok=True)
    fh = RotatingFileHandler(
        pathlib.Path(log_dir) / "app.log", maxBytes=5_000_000, backupCount=5, encoding="utf-8"
    )
    fh.setFormatter(fmt)
    fh.addFilter(PhoneMaskingFilter())
    logger.addHandler(fh)
    return logger
