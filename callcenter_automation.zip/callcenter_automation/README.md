# Hindi Call-Center Automation System

Excel/CSV-driven Hindi call-center automation: import customers, generate personalized Hindi
IVR scripts, synthesize speech, place calls through an AUTHORIZED telephony provider (or the
built-in mock), detect DTMF/speech responses, classify intent, schedule callbacks, update
Excel results — with full test mode that requires zero real calls or credentials.

## Legal Boundary
This system operates only on customer data the operator/company is authorized to process.
It does not scrape numbers, generate random numbers, bypass telecom/security controls, or
impersonate anyone. Real outbound calls require a legitimate, company-approved telephony
provider configured via environment variables.

## Quick Start
```bash
pip install -r requirements.txt
python run.py                 # opens http://127.0.0.1:8000
```
1. Dashboard → choose `sample_data/customers.xlsx` → Import.
2. Click any **Sim** button (e.g. "Sim: 1 Interested") — full pipeline runs, no real call.
3. **Export Results (Excel)** downloads `processed_output_*.xlsx`.

## Tests
```bash
pytest tests/ -v
```
Covers validation, intent classification (Hindi + English), script generation, all call
scenarios (Interested/Callback/Not Interested/No Answer/Busy/Failed/Unknown + speech),
callbacks, dedup on import, retry policy, crash recovery, and Excel export roundtrip.

## Docs
See `docs/` for ARCHITECTURE, WORKFLOW, SETUP, CONFIGURATION, API_INTEGRATION, TESTING,
SECURITY, and TROUBLESHOOTING.
