# Spatial Audio & Haptics

## VR 3D Sound (Spatial Audio)

VR me sound ka ek feature hota hai: **Spatial Audio (3D Sound)**.

- Jab Giant Beastman bolega → player ko lagega ki awaaz **15 feet ki
  unchai se niche** aa rahi hai.
- Jab wo haath uthakar nishana lagayega → uski **bhari saans** player ke
  kaano ke paas goonjegi.
- Beastman kabab paka raha hoga → paas se **aag ke jalne (crackling)**
  aur **meat ke pakne** ki awaaz clear sunai degi.

## Haptics

| Event | Haptic |
|-------|--------|
| Boss dialogue (heavy bass) | Controllers vibrate |
| Boss roar | Strong pulse |
| Player hit | Sharp jolt |
| Upgrade mutation | Rapid vibration |
| Death scene | Low rumble |

## Dialogue Selection Logic

```cpp
void playBossIntroDialogue(PlayerRecord last5Fights, String userLocation) {
    String selectedDialogue;

    if (last5Fights.mostUsedWeapon == "Bow") {
        selectedDialogue = "Kab tak chhup-chhup kar teer chalaoge...";
    } else if (isNightTime()) {
        selectedDialogue = "Ayodhya mein andhera ho chuka hai...";
    } else {
        selectedDialogue = getRandomDialogueFromPool([
            "I am waiting for your new fight...",
            "Aaj ka sunset tumhara aakhri sunset hoga!"
        ]);
    }

    // Engine command: Play 3D Audio from Boss Head Location
    play3DSoundAtLocation(
        "Boss_Voice_Asset",
        bossHeadComponent.position,
        selectedDialogue
    );

    // Controller feedback
    triggerHapticFeedback("Heavy_Bass_Vibration");
}
```

## Audio Settings

| Setting | Value |
|---------|-------|
| Attenuation | 3D spatial |
| Reverb | Cave/Ruin reverb |
| Doppler | Moving attacks |
| Occlusion | Walls ke piche muffled |
| HRTF | Head-related transfer function |

## VR Audio Best Practices

- Player ke head position se audio calculate.
- Important sounds (snake hiss) ko directional rakho.
- Background music low, diegetic sounds high.
- Sudden loud sounds se bacho (ear fatigue).

## 💡 Immersion

Agar boss ki awaaz sach me 15 feet upar se aaye, to player ka dimaag
believes kar lega ki wo giant hai — visual se zyada audio matter karta hai.
