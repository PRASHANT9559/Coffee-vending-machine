# Boss Taunt Dialogues

Boss apni situation ke hisaab se dialogue badal-badal kar bolega, jisse
player ka excitement aur gussa aakhri level par pahunch jaye.

## Dialogue Schema

| Column | Type | Example |
|--------|------|---------|
| `Dialogue_ID` | Integer | D-12 |
| `Condition` | String | Night / BowSpam / EasyWin / Default |
| `Language` | String | Hindi / English / Hinglish |
| `Emotion` | String | Angry / Mocking / Threatening |
| `Audio_Asset` | String | Boss_Voice_01 |

## 1. Night Time (Dark & Creepy Mode)

> 🎙 *"Ayodhya mein andhera ho chuka hai insaan... aur meri is andheri
> duniya mein tumhara aakhri waqt shuru ho gaya hai! I am waiting for
> your new fight... aao, mujhe niraash mat karna!"*

**VR Effect:** 4 hathon ke weapons andhere me chamkenge, aankhein neon
red glow karengi.

## 2. Bow Spam (Player Door Se Shikar Karta Hai)

> 🎙 *"Kab tak chhup-chhup kar teer chalaoge makkhi ki tarah? Is baar
> mere paas 4 hath hain aur tumhare har teer ko rokne ke liye meri shield
> kaafi hai! Paas aao aur ek asli Beastman ki tarah lado!"*

**VR Effect:** Heavy shield 🛡 chaati par thok kar bhari dahaad (roar).

## 3. Easy Win Last Level (Aggressive Taunt)

> 🎙 *"Pichla level to ek hadsa tha... meri asli taqat tumne abhi dekhi
> kahan hai? Aao, apne panjo (🦧) ko lekar aage badho, dekhta hoon is baar
> mujhe kaise knockout karte ho!"*

## 4. General Hot Excitement Dialogues

- *"Suna hai tumne is island par bohot suraj dekhe hain, par aaj ka
  sunset tumhari zindagii ka aakhri sunset hoga!"*
- *"Tumhare piche jo ye tiger (🐅) ghum raha hai, iska meat mera aaj ka
  dinner banega! Prepare yourself!"*
- *"I am waiting for your new fight..."*

## Emotion Design

| Emotion | Player Reaction |
|---------|-----------------|
| Mocking | Gussa (anger) |
| Threatening | Darr (fear) |
| Dismissive | Excitement (prove them wrong) |
| Personal | Revenge loop |

## 💡 Design Goal

Player ko lage: **"Is baar to tujhe chhodunga nahi!"**
Yeh emotional hook game ko memorable banata hai.
