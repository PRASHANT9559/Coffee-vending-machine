# Dialogues — Random Parts

Har dialogue kitne parts se banta hai aur kaise select hota hai.

## Dialogue Ke Parts

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Dialogue_ID` | Integer | Unique | D-12 |
| 2 | `Condition` | Enum | Night, Day, BowSpam, EasyWin, PetUse, Default | Night |
| 3 | `Emotion` | Enum | Mocking, Threatening, Angry, Calm | Threatening |
| 4 | `Language` | Enum | Hindi, English, Hinglish | Hinglish |
| 5 | `Text` | String | Random from pool | "Ayodhya mein andhera..." |
| 6 | `Duration` | Float | 2–10 sec | 6 |
| 7 | `Audio_Asset` | String | Voice file | Boss_Voice_01 |
| 8 | `Voice_Pitch` | Float | 0.3–1.0 | 0.4 |
| 9 | `Haptic` | Enum | None, Light, Heavy | Heavy |
| 10 | `Subtitle` | Boolean | True/False | True |
| 11 | `Gesture` | Enum | Roar, ShieldSlam, Point, Laugh | Roar |
| 12 | `Priority` | Integer | 1–10 | 9 |

## Selection Logic

```
if (Player_Strategy == "BowSpam"):
    condition = "BowSpam"
elif (Time == "Night"):
    condition = "Night"
elif (Last_Win_Time < 30):
    condition = "EasyWin"
else:
    condition = "Default"

pool = dialogues.where(d => d.condition == condition)
selected = RandomFromPool(pool)
play3DSound(selected.audio, bossHead)
triggerHaptic(selected.haptic)
```

## Example Dialogues

### Dialogue 1 — Night Taunt
```
Condition: Night | Emotion: Threatening
Text: "Ayodhya mein andhera ho chuka hai insaan...
       aur meri is andheri duniya mein tumhara aakhri
       waqt shuru ho gaya hai!"
Duration: 8s | Pitch: 0.4 | Haptic: Heavy
Gesture: Roar | Priority: 9
```

### Dialogue 2 — Bow Spam Mock
```
Condition: BowSpam | Emotion: Mocking
Text: "Kab tak chhup-chhup kar teer chalaoge makkhi ki
       tarah? Paas aao aur ek asli Beastman ki tarah lado!"
Duration: 7s | Pitch: 0.5 | Haptic: Light
Gesture: ShieldSlam | Priority: 8
```

### Dialogue 3 — Easy Win Taunt
```
Condition: EasyWin | Emotion: Angry
Text: "Pichla level to ek hadsa tha... meri asli taqat
       tumne abhi dekhi kahan hai?"
Duration: 6s | Pitch: 0.4 | Haptic: Heavy
Gesture: Point | Priority: 7
```

### Dialogue 4 — Default Random
```
Condition: Default | Emotion: Calm
Text: "I am waiting for your new fight..."
Duration: 4s | Pitch: 0.5 | Haptic: Light
Gesture: Laugh | Priority: 5
```

## Balance Rules

- Same dialogue repeat na ho (last 2 avoid).
- Night dialogue sirf night me.
- Player strategy match = priority high.
- Har boss ke 4–6 dialogues minimum.

## Related

- [workflow.md](workflow.md)
- [taunts.md](taunts.md)
- [audio.md](audio.md)
