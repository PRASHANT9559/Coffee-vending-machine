# Dialogues — Workflow

Boss dialogue select aur play hone ka flow.

```mermaid
flowchart TD
    A["Boss spawn"] --> B["Load player records"]
    B --> C["Check time of day"]
    B --> D["Check player strategy"]
    B --> E["Check difficulty"]
    C --> F["Condition match"]
    D --> F
    E --> F
    F --> G["Random dialogue from pool"]
    G --> H["Play 3D spatial audio"]
    H --> I["Trigger haptic feedback"]
    I --> J["Subtitle display"]
    J --> K["Fight starts"]
```

## Selection Priority

1. **Strategy-based** (player pattern) — highest.
2. **Time-based** (night/day).
3. **Difficulty-based** (easy win taunt).
4. **Random default** — fallback.

## Playback

1. Boss head location se 3D audio.
2. Heavy bass par controller vibration.
3. Subtitle on screen.
4. Fight start.

## Related

- [taunts.md](taunts.md)
- [audio.md](audio.md)
- [random-parts.md](random-parts.md)
