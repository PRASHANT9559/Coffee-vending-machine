# Level Generation Formulas

## Core Formulas

### 1. Snake Count

```
Snakes_Count = (Level_Number * 0.05) + 3
```

- Level 1 → 3 snakes
- Level 1000 → 53 snakes
- Level 10000 → 503 snakes

### 2. Snake Speed

```
Snake_Speed = Base_Speed + (Level_Number * 0.1)
```

Har level par speed thodi badhti hai.

### 3. Mission Type

```
Mission_Type = Level_Number % 5
```

- 0 → Rescue
- 1 → Collect
- 2 → Survive
- 3 → Decode
- 4 → Hunt

### 4. Attack Power / Difficulty Modifier

```
Difficulty = 1 + (Level_Number / 1000)
```

Level 5000 par difficulty 6x.

## Pseudocode (UE5 Adaptation)

```cpp
// Aapki Flutter wali logic ka 3D backend adaptation
void generateLevel(int levelNumber) {
    // Level number ke hisaab se coordinates automatically change honge
    int randomX = (levelNumber * 150) % maxIslandWidth;
    int randomY = (levelNumber * 230) % maxIslandLength;

    // Dushman ki sankhya aur speed
    int snakeCount = (levelNumber / 10) + 2;
    double snakeSpeed = 300.0 + (levelNumber * 0.5);

    // Engine command: is jagah par is speed wala snake spawn karo
    spawnEnemy("SnakeClass", Position(randomX, randomY), snakeSpeed);
}
```

## Blueprint Alternative (No Code)

- **Random Stream** node → Seed = Level Number
- **Modulo (%)** node → Mission type
- **Vector Math** → random coordinates
- **Spawn Actor from Class** → enemies, fruits, tools

## Important Notes

- Ek hi level dobara khelne par **same layout** milega (seed fixed).
- Level 501 par sab kuch badal jayega.
- Engine ko har frame recalculate nahi karna — sirf level start par.
