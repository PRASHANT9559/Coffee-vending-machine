# Levels — Random Parts

Ek level kai random layers se banta hai. Yeh file batati hai ki level ko
kitne parts me divide kiya gaya hai.

## Level Ke Parts

| Part | Type | Options / Range | Example |
|------|------|-----------------|---------|
| `Level_Number` | Integer | 1–10000 | 752 |
| `Seed` | Integer | = Level_Number | 752 |
| `Biome` | Enum | Jungle, Swamp, Rocky, Ocean, Mixed | Jungle |
| `Time_Of_Day` | Enum | Dawn, Day, Sunset, Night | Night |
| `Weather` | Enum | Clear, Rain, Storm, Fog | Storm |
| `Terrain_Seed` | Integer | Random | 4821 |
| `Island_Size` | Float | 500–5000 | 2600 |
| `Cave_Count` | Integer | 1–10 | 5 |
| `Floating_Mountains` | Integer | 0–8 | 4 |
| `Ruins_Count` | Integer | 0–5 | 2 |
| `Snake_Count` | Integer | Formula | 40 |
| `Snake_Speed` | Float | Formula | 375 |
| `Predator_Count` | Integer | 0–20 | 12 |
| `Fruit_Count` | Integer | 10–100 | 55 |
| `Poison_Fruit_Ratio` | Float | 0.0–0.5 | 0.25 |
| `Tool_Loot_Count` | Integer | 2–15 | 7 |
| `Mission_Type` | Enum | Level % 5 | Collect |
| `Boss_Present` | Boolean | Every 10th / mission end | True |
| `Cataclysm` | Boolean | Level % 500 == 0 | False |
| `Difficulty` | Float | 1 + N/1000 | 1.75 |

## Formulas

```
Snake_Count   = (N * 0.05) + 3
Snake_Speed   = 300 + (N * 0.1)
Predator_Count= (N / 500) + Random(0, 5)
Poison_Ratio  = Min(0.5, N / 20000)
Difficulty    = 1 + (N / 1000)
Mission_Type  = N % 5
Cataclysm     = (N % 500 == 0)
```

## Example Level 752 — Generated

```
Biome: Jungle | Time: Night | Weather: Storm
Island: 2600 units | Caves: 5 | Floating: 4
Snakes: 40 | Speed: 375 | Predators: 12
Fruits: 55 | Poison ratio: 25%
Mission: Collect (N % 5 = 2 → Survive? check table)
Boss: False | Cataclysm: False | Difficulty: 1.75
```

## Level Bands

| Range | Biome | Time | Weather | Enemies |
|-------|-------|------|---------|---------|
| 1–100 | Jungle | Day | Clear | 3–8 |
| 100–1000 | Mixed | Day/Sunset | Rain | 8–53 |
| 1000–5000 | Mixed | Night | Storm | 53–253 |
| 5000–10000 | Harsh | Night | Storm | 253–503 |

## Related

- [workflow.md](workflow.md)
- [formulas.md](formulas.md)
- [progression.md](progression.md)
- [../Game-Concept/random-parts.md](../Game-Concept/random-parts.md)
