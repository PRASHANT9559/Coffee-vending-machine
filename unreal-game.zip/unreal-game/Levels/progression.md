# Level Progression — 0 se 10,000

## Level 1–100 — The Dawn 🌅

- Island par mausam saaf hai (Journey 2 style).
- Sirf 2–3 **green snakes** hain, wo bhi slow.
- Mangoes aur apples aasani se mil jate hain.
- Player VR controls se familiar hota hai.
- **Focus:** Tutorial + exploration + comfortable VR.

## Level 100–1000 — The Explorer 🧭

- Snakes ki sankhya badhne lagti hai.
- Naye animals appear hote hain.
- Random missions ka variety samajh aati hai.
- Crafting aur pet system unlock hota hai.

## Level 1000–5000 — The Pandora Shift 🌌

- **Raat ka waqt shuru** ho chuka hai.
- Bioluminescent plants chamak rahe hain.
- Code ne bade predators (Avatar ke wild animals) active kar diye hain.
- Fruits **poisonous** bhi ho sakte hain — scan karke khana hoga.
- **Focus:** Night survival + poison risk + stronger enemies.

## Level 5000–10000 — The Extreme Survival 🌊⚡

- Island par har waqt **toofan, baarish aur bijli**.
- Samundar me giant creatures hain.
- Snakes ki sankhya **50+** aur poison 2x tezi se health kam karta hai.
- Floating mountains par chalne ke liye **Glider Suit** ka perfect use.
- **Focus:** Hardcore survival, boss fights, tsunami events.

## Every 500th Level — Cataclysm 🌊

- Har 500th level ek **"Maha-toofan"** level hoga.
- Giant tsunami uthti hai aur island doobne lagta hai.
- Player ko bhagna nahi hai — paani me tairna ya floating mountains par
  koodna hai.
- **Optimization:** Naya map load nahi hota, sirf water height vector
  badhta hai.

## Progression Summary Table

| Range | Name | Mood | Difficulty |
|-------|------|------|------------|
| 1–100 | The Dawn | Sunny, calm | ⭐ |
| 100–1000 | The Explorer | Adventure | ⭐⭐ |
| 1000–5000 | Pandora Shift | Night, magical | ⭐⭐⭐ |
| 5000–10000 | Extreme Survival | Storm, chaos | ⭐⭐⭐⭐⭐ |
| Every 500th | Cataclysm | Tsunami | ⭐⭐⭐⭐ |

## 💡 Replay Value

Ek hi level alag samay par alag experience dega — Level 500 subah aasan,
raat ko darawna.
