# Levels — Workflow

Level number se poora 3D world generate hone ka pipeline.

```mermaid
flowchart TD
    A["Level Number N"] --> B["Seed = N"]
    B --> C["Island generator"]
    B --> D["Difficulty calculator"]
    B --> E["Mission generator"]
    C --> F["Terrain + water + caves"]
    C --> G["Props + vegetation"]
    D --> H["Enemy count + speed"]
    D --> I["Loot rarity"]
    E --> J["Objective + reward"]
    F --> K["Spawn player"]
    G --> K
    H --> L["Spawn enemies"]
    I --> L
    J --> L
    K --> M["Gameplay"]
    L --> M
    M --> N{"Level clear?"}
    N -->|No| M
    N -->|Yes| O["Save + N = N + 1"]
    O --> A
```

## Generation Order (Important)

1. **Seed set** — `RandomStream(N)`.
2. **Terrain first** — island shape, water, caves.
3. **Props** — trees, rocks, crystals.
4. **Spawn points** — 20–30 empty actors.
5. **Enemies** — difficulty ke hisaab se.
6. **Mission** — type + target + location.
7. **Player spawn** — safe zone.
8. **Validate** — koi objective unreachable na ho.

## Determinism Rule

Same seed = same level. Isliye:

- Level 500 dobara khelo → same layout.
- Level 501 → bilkul naya.
- Save file me sirf level number + player state — poora map nahi.

## Related

- [10k-levels.md](10k-levels.md)
- [formulas.md](formulas.md)
- [progression.md](progression.md)
- [random-parts.md](random-parts.md)
