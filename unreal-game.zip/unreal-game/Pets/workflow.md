# Pets — Workflow

Pet tame karne se combat assistance tak ka flow.

```mermaid
flowchart TD
    A["Random animal spawn<br/>wounded / hungry"] --> B{"Player action?"}
    B -->|Attack| C["Kill + loot"]
    B -->|Feed| D["Taming roll"]
    D --> E{"Tamed?"}
    E -->|No| F["Animal runs away"]
    E -->|Yes| G["Pet joins player"]
    G --> H["Follow mode"]
    H --> I{"Command?"}
    I -->|Stay| J["Wait"]
    I -->|Go| K["Move to point"]
    I -->|Attack| L["Attack target"]
    I -->|Whistle| M["Return to player"]
    J --> H
    K --> H
    L --> H
    M --> H
    H --> N{"Pet injured?"}
    N -->|Yes| O["Feed → health + loyalty"]
    O --> H
    N -->|No| P["Ability active"]
```

## Taming Steps

1. Wounded/hungry animal mile.
2. Feed fruit/meat.
3. Random taming roll (60%).
4. Success → pet join.
5. Loyalty build (feed, pet, protect).

## Commands

| Command | Action |
|---------|--------|
| Stay | Wahin ruko |
| Go There | Point par jao |
| Attack | Target par hamla |
| Whistle | Player ke paas aao |

## Related

- [pet-types.md](pet-types.md)
- [taming.md](taming.md)
- [commands.md](commands.md)
- [random-parts.md](random-parts.md)
