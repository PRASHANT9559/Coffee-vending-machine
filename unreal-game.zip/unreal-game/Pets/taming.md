# Taming & Loyalty System

## Taming Logic (Dost Kaise Banayein?)

- Game ke kisi random level par ek **zakhmi ya bhookha** tiger milega.
- Agar aapne use maarne ke bajaye **apple ya meat khila diya**:
  - Database me `Is_Tamed = True` ho jayega.
  - Ab wo hamesha ke liye aapka pet ban gaya.

## Feeding Mechanic (Khana Khilana)

- Agar pet ladaai me zakhmi ho jaye ya health kam ho:
  - Use apna toda hua mango ya fish (🐟) **physically uske muh ke paas**
    le ja kar khilani hogi.
  - Isse **loyalty aur health** badhegi.

## Loyalty System

| Loyalty | Effect |
|---------|--------|
| 0–30 | Pet kabhi-kabhi command ignore karega |
| 31–70 | Normal follow + basic attacks |
| 71–100 | Full combat support + special ability |

Loyalty badhane ke tareeqe:
- Feeding
- Petting (physical)
- Combat me bachana
- Treat/fruit dena

## Dynamic Level Scaling

Agar player ke paas tagda pet (tiger) hai:
- Engine automatic enemies (snakes/predators) ki difficulty thodi badha
  dega.
- Game challenging rehta hai, boring nahi.

## Pet Backend Logic

```cpp
void onPlayerAttacked(Enemy currentEnemy) {
    if (player.hasPet && player.currentPet.isAlive) {
        if (player.currentPet.type == "Tiger") {
            player.currentPet.attackTarget(currentEnemy);
        } else if (player.currentPet.type == "Dog") {
            player.currentPet.distractEnemy(currentEnemy);
        }
    }
}
```

## Taming Rules

1. Aggressive animal ko pehle **weak** karo (health low).
2. Phir food offer karo.
3. Random chance: 60% tame, 40% bhaag jayega.
4. Rare animals ke liye special fruit chahiye.

## 💡 Replay Hook

Jab player ko pata hoga ki Level 2000 par uske tiger ke liye
"Neon Fire Skin" unlock hone wali hai, to wo game chhodega nahi.
