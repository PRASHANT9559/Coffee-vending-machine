# Pets — Random Parts

Har pet bhi random parts se banega — species, color, size, ability, etc.

## Pet Ke Parts

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Pet_ID` | Integer | Unique | 301 |
| 2 | `Species` | Enum | Dog, Tiger, Eagle, Dolphin, Turtle | Tiger |
| 3 | `Breed` | Enum | Random per species | Bengal |
| 4 | `Primary_Color` | Color | Random RGB | Orange |
| 5 | `Secondary_Color` | Color | Random RGB | Black |
| 6 | `Pattern` | Enum | Stripes, Spots, Solid, None | Stripes |
| 7 | `Size` | Float | 0.5–3.0x | 1.4 |
| 8 | `Ear_Style` | Enum | Pointed, Floppy, Tufted | Pointed |
| 9 | `Tail_Style` | Enum | Long, Short, Bushy, Fin | Long |
| 10 | `Eye_Color` | Color | Random | Amber |
| 11 | `Ability` | Enum | Scent, Combat, Scout, Swim | Combat |
| 12 | `Health` | Float | 50–500 | 300 |
| 13 | `Speed` | Float | 200–800 | 500 |
| 14 | `Loyalty` | Float | 0–100 | 70 |
| 15 | `Rarity` | Enum | Common, Rare, Epic, Legendary | Rare |
| 16 | `Tame_Difficulty` | Enum | Easy, Normal, Hard | Normal |
| 17 | `Diet` | Enum | Fruits, Meat, Fish | Meat |
| 18 | `Skin_ID` | Integer | Unlocked cosmetic | 12 |
| 19 | `Luminescent` | Boolean | True/False | False |
| 20 | `Sound_Pitch` | Float | 0.5–2.0 | 0.8 |

## Generation Formula

```
Species   = RandomEnum(Dog, Tiger, Eagle, Dolphin, Turtle)
Breed     = RandomBreed(Species)
Color     = RandomRGB()
Pattern   = RandomEnum(Stripes, Spots, Solid, None)
Size      = RandomFloat(0.5, 3.0)
Ability   = AbilityBySpecies(Species)
Loyalty   = RandomFloat(20, 60)  // taming ke baad badhta hai
Rarity    = WeightedRandom(Common 60%, Rare 25%, Epic 12%, Legendary 3%)
```

## Example Pets

### Pet 1 — Combat Tiger
```
Species: Tiger | Breed: Bengal | Color: Orange / Black
Pattern: Stripes | Size: 1.4 | Ears: Pointed | Tail: Long
Ability: Combat | Health: 300 | Speed: 500
Loyalty: 70 | Rarity: Rare | Tame: Normal
Diet: Meat | Glow: False
```

### Pet 2 — Scout Eagle
```
Species: Eagle | Breed: Golden | Color: Brown / White
Pattern: None | Size: 0.8 | Ears: None | Tail: Fan
Ability: Scout | Health: 120 | Speed: 700
Loyalty: 55 | Rarity: Epic | Tame: Hard
Diet: Meat | Glow: False
```

### Pet 3 — Glow Turtle
```
Species: Turtle | Breed: Sea | Color: Neon Green
Pattern: Scales | Size: 1.8 | Tail: Fin
Ability: Swim | Health: 400 | Speed: 250
Loyalty: 60 | Rarity: Rare | Tame: Easy
Diet: Fruits | Glow: True
```

## Ability by Species

| Species | Ability | Effect |
|---------|---------|--------|
| Dog | Scent | Rare items dhoondna |
| Tiger | Combat | Player ki defence |
| Eagle | Scout | Mini-radar |
| Dolphin | Swim | Shark se bachana |
| Turtle | Swim | Tez tairna |

## Balance Rules

- Legendary pet = 3% chance, Level 1000+.
- Loyalty 71+ = full ability unlock.
- Glowing pets raat me visibility dete hain.
- Combat pet se enemy difficulty auto-scale.

## Related

- [workflow.md](workflow.md)
- [pet-types.md](pet-types.md)
- [taming.md](taming.md)
- [commands.md](commands.md)
