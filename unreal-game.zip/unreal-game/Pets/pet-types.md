# Pet System — Types & Abilities

VR me "Pet System" player ko game se **emotionally** bandh deta hai.
Gaming me companion system ek bahut bada retention factor hai.

## Possible Pets & Abilities

### 🐕 Dog — Scent Tracking
- Island par chhupe rare fruits (apple/mango) aur crafting tools
  **naak se soongh kar** dhoond nikalega.
- Danger Alert: Ghaas me chhupa snake dekh kar **bhaunkega** (Bark),
  player pehle hi alert ho jayega.

### 🐅 Tiger / Panther — Combat Support
- Player par aggressive animal/crocodile attack kare to aage aakar
  **ladega** aur health bachayega.
- Player `Target Attack` ka ishaara kar sakta hai.

### 🦅 Eagle / Bird — Aerial Scout
- Aakash me udkar poore map ka jaiza lega.
- Mini-radar / signal dega: kis taraf dushman kam, kis taraf raasta saaf.

### 🐬 Dolphin / 🐢 Sea Turtle — Sea Navigation
- Ocean zone me saath tairega.
- Shark ko player se door bhagayega.
- Turtle ki peeth pakad kar tezi se tair sakte hain.

## Pet Ability Table (Database)

| Column | Type | Example |
|--------|------|---------|
| `Pet_ID` | Integer | 301 |
| `Pet_Type` | String | Dog / Tiger / Eagle / Dolphin |
| `Ability` | String | Scent / Combat / Scout / Swim |
| `Is_Tamed` | Boolean | True/False |
| `Health` | Float | 100 |
| `Loyalty` | Float | 0–100 |
| `Speed` | Float | 300 |

## VR Bonding

- Physically haath se pet ke sir par haath pherna (petting).
- Wo gardan hila kar khush hoga.
- Feeding, high-five, hug — sab physical gestures.

## Pet Selection

Player ek time par **ek active pet** rakh sakta hai, ya situation ke
hisaab se switch kar sakta hai (land/sea/air).
