# Pet Commands & VR Interaction

## 3 Main Command Types

### 1. Hand Gestures (Ishaare) 👋
- Player VR controllers ke haath se ishaara karega:
  - 👋 `Stay` — wahin ruko
  - 👉 `Go There` — us direction me jao
  - ✋ `Come` — paas aao
- Pet us direction me chala jayega.

### 2. Feeding (Khana Khilana) 🍎
- Zakhmi/bhookhe pet ko physically fruit ya fish khilao.
- Health + loyalty badhegi.

### 3. Whistle Command (Seeti Bajana) 🔔
- Island par rasta bhatak gaya ya pet door chala gaya?
- Button dabakar seeti bajao → pet doudta hua paas aayega.

## Combat Commands

| Command | Kaam |
|---------|------|
| `Attack` | Pet ko target par bhejo |
| `Defend` | Player ke paas rakho, block kare |
| `Distract` | Dushman ka dhyaan bhatkao |
| `Scout` | Aage ja kar area check kare |

## VR Interaction Details

- Pet ko **physically** touch karke command do.
- High-five (✋), hug, treat dena — sab gestures.
- Voice command (optional): "Bhaunk!", "Attack!", "Come!"

## Backend Structure

```cpp
class PetController {
    String state; // "Follow", "Stay", "Attack", "Scout"
    float loyalty;
    float health;

    void onGesture(String gesture) {
        if (gesture == "Stay")  state = "Stay";
        if (gesture == "Go")    moveTo(raycastTarget);
        if (gesture == "Feed")  health += 20;
        if (gesture == "Whistle") teleportNearPlayer();
    }
}
```

## Pet Animation States

- **Follow:** Player ke piche bhaagna, mudna, rukna (same speed).
- **Alert:** Ghaas me khatra dekh kar khada hona, kaan khade karna,
  ishaara karna.
- **Attack:** Dushman par jhapatna, kaatna.
- **Hurt:** Zakhmi hone par karahna (whimper).

## Failure Cases

- Pet door ho jaye → whistle se wapas.
- Pet mar jaye → revive mission / special fruit.
- Pet stuck ho jaye → auto-teleport behind player.
