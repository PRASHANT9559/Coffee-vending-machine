# Beastman — Upgrade System

## The Mutation Chamber (Gufa Ke Andar Transformation)

1. Player level clear karke resources jama karega.
2. Ek special cave me jayega.
3. Upgrade button dabayega.
4. VR controllers me tezi se **vibration** hoga.
5. Screen par jaadui light chamkegi.
6. Jab player apne hathon ko dekhega → normal hath ab **Tiger ke panjo**
   me badal chuke honge!

## Upgrade Levels

Har body part **Level 1 se 5** tak upgrade hota hai.

| Level | Cost | Visual | Power |
|-------|------|--------|-------|
| 1 | Basic DNA | Halka change | +10% |
| 2 | Common DNA | Claws visible | +25% |
| 3 | Rare DNA | Fur/scales | +50% |
| 4 | Epic DNA | Full beast part | +100% |
| 5 | Legendary DNA | Glowing/mutated | +200% |

## Upgrade Materials

- **DNA Samples** — dushman animal ko harane par milta hai.
- **Rare Fruits** — Blue Mango, Glowing Apple.
- **Crystals** — caves se mining.
- **Boss Drops** — 4-armed boss se.

## Backend Logic

```cpp
void upgradeBodyPart(String partName, String beastType) {
    int currentLevel = player.bodyParts[partName].level;

    if (currentLevel < 5) {
        player.bodyParts[partName].level += 1;

        // Material aur 3D model badlo bina game roke
        applyBeastMesh(partName, beastType, currentLevel);

        // Power calculations
        if (partName == "Legs") {
            player.walkSpeed += 150.0;
            player.jumpZVelocity += 300.0;
        }
        if (partName == "Hands") {
            player.attackPower += 50.0;
        }
        if (partName == "Eyes") {
            player.nightVision = true;
        }
        if (partName == "Skin") {
            player.poisonResistance += 0.3;
        }
        if (partName == "Back") {
            player.canGlide = true;
        }
    }
}
```

## Skeletal Mesh Merge

- Poora character badalne ki zaroorat nahi.
- Sirf us **part ka mesh** badlo (Dynamic Materials + Skeletal Mesh Merge).
- VR me performance bachti hai.

## Mutation Combinations

| Combo | Result |
|-------|--------|
| Snake DNA + Eagle DNA | Flying Venomous Wings |
| Tiger DNA + Crocodile DNA | Armored Claws |
| Cheetah DNA + Banshee DNA | Sky Runner |

## 💡 Attraction

Har player ka character dekhne me aur khelne me **ekdam alag** hoga.
