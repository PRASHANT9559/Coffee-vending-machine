# Beastman — Body Parts

## Concept

Character ek **Beastman** hai — aadha insaan, aadha jaanwar (jaise
Wolverine ya Beastars characters).

Kyunki wo pehle se Beastman hai, isliye body upgrades ajeeb nahi lagte —
balki aur **khunkhar aur cool** lagte hain.

## Body Part Upgrade Table

| Body Part | Level | Beast Type | Power / Ability |
|-----------|-------|------------|-----------------|
| **Hands (Hath)** 🦧 | 1–5 | Tiger 🐅 / Bear 🐻 | Attack Power: kulhaadi/talwar ke bina panjo se snakes aur crocodiles ko maar sakta hai. Mining tezi se hogi. |
| **Legs (Pair)** 🐆 | 1–5 | Cheetah 🐆 / Kangaroo | Movement Speed +150%: Bhaagne ki speed badhegi, jump height badhegi, floating mountains par jana aasan. |
| **Eyes (Aankhein)** 🦅 | 1–5 | Eagle 🦅 / Snake 🐍 | Night Vision + Scan: Andhere me ya raat ko (Avatar mode) flashlight ke bina dushman ki heat signature deewar ke paar dikhegi. |
| **Skin/Chest (Chaati)** 🐊 | 1–5 | Crocodile 🐊 / Rhino | Defense/Armor +300%: Snake ka poison kam asar karega, bade attacks se kam damage. |
| **Back (Peeth)** 🦅 | 1–5 | Banshee (Avatar) / Falcon | Gliding / Flying: Unche pahadon se glide kar sakta hai, glider suit ki zaroorat nahi, hawa me ud sakta hai. |

## Visual Upgrades

- **Level 1:** Normal human-like hands.
- **Level 3:** Beast characteristics start (claws, scales).
- **Level 5:** Full transformation (tiger paws, wings, glowing eyes).

## Sound Design

- Level 5 hands se attack → insaan ki nahi, **sher ki dahaad** (Roar).
- Chhote animals (frogs, snakes) darr ke bhaag jayenge.

## Custom Playstyles

| Build | Upgrades | Playstyle |
|-------|----------|-----------|
| **Hunter Beastman** | Eyes + Hands | Andhere me shikar |
| **Sky Beastman** | Legs + Back | Floating mountains par udna |
| **Tank Beastman** | Skin + Hands | Head-on combat |
| **Speed Beastman** | Legs + Eyes | Hit-and-run |

> Next: [upgrades.md](upgrades.md) — mutation system.
