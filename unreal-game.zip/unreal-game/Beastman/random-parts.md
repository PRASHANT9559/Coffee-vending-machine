# Beastman — Random Parts

Beastman ka har body part random generate ho sakta hai — beast type,
color, level, mutation, etc.

## Body Part Ke Random Parts

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Slot` | Enum | Hands, Legs, Eyes, Skin, Back | Hands |
| 2 | `Beast_Type` | Enum | Tiger, Bear, Cheetah, Kangaroo, Eagle, Snake, Crocodile, Rhino, Banshee, Falcon | Tiger |
| 3 | `Level` | Integer | 1–5 | 4 |
| 4 | `Fur_Color` | Color | Random RGB | Orange |
| 5 | `Fur_Pattern` | Enum | Stripes, Spots, Scales, Solid | Stripes |
| 6 | `Claw_Style` | Enum | Short, Long, Curved, Serrated | Curved |
| 7 | `Eye_Style` | Enum | Normal, Slit, Glowing, Multi | Glowing |
| 8 | `Wing_Type` | Enum | None, Feather, Bat, Energy | None |
| 9 | `Tail_Type` | Enum | None, Long, Spiked, Energy | Long |
| 10 | `Mutation_Combo` | String | DNA1 + DNA2 | Tiger + Crocodile |
| 11 | `Power_Multiplier` | Float | 1.0–5.0 | 2.4 |
| 12 | `Visual_Effect` | Enum | None, Glow, Smoke, Sparks | Glow |

## Generation Formula

```
Slot          = PlayerSelectedSlot
Beast_Type    = RandomEnum(validBeasts[Slot])
Level         = RandomInt(1, 5)  // capped by player progress
Fur_Color     = RandomRGB()
Fur_Pattern   = RandomEnum(Stripes, Spots, Scales, Solid)
Claw_Style    = RandomEnum(Short, Long, Curved, Serrated)
Eye_Style     = RandomEnum(Normal, Slit, Glowing, Multi)
Wing_Type     = (Slot == Back) ? RandomEnum(Feather, Bat, Energy) : None
Power         = 1 + (Level * 0.4) + (MutationBonus)
```

## Example Builds

### Build 1 — Hunter Beastman
```
Hands: Tiger Lv5 | Curved claws | Orange/Black stripes
Eyes: Eagle Lv4 | Glowing slit | Night vision
Skin: Leopard Lv3 | Spots
Power: 3.2 | Effect: Glow
Playstyle: Andhere me shikar
```

### Build 2 — Sky Beastman
```
Legs: Cheetah Lv5 | Speed +150%
Back: Banshee Lv5 | Energy wings | Glide
Eyes: Eagle Lv5 | Heat scan
Power: 4.0 | Effect: Sparks
Playstyle: Floating mountains par udna
```

### Build 3 — Tank Beastman
```
Skin: Rhino Lv5 | Armored | Defense +300%
Hands: Bear Lv5 | Serrated claws
Legs: Kangaroo Lv3 | Jump
Power: 3.8 | Effect: None
Playstyle: Head-on combat
```

## Mutation Combinations

| DNA 1 | DNA 2 | Result | Rarity |
|-------|-------|--------|--------|
| Snake | Eagle | Flying Venomous Wings | Epic |
| Tiger | Crocodile | Armored Claws | Rare |
| Cheetah | Banshee | Sky Runner | Epic |
| Shark | Turtle | Aquatic Armor | Rare |
| Eagle | Snake | Night Vision + Poison | Legendary |

## Balance Rules

- Level 5 = max, legendary DNA chahiye.
- Power multiplier 5.0 = endgame only.
- Slot ke hisaab se hi valid beasts.
- Visual effect rarity ke saath.

## Related

- [workflow.md](workflow.md)
- [body.md](body.md)
- [upgrades.md](upgrades.md)
- [work.md](work.md)
