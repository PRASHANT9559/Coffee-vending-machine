# Beastman — Workflow

Beastman body upgrade ka poora flow.

```mermaid
flowchart TD
    A["Hunt animal / boss"] --> B["DNA sample collect"]
    B --> C["Resources check<br/>DNA + crystal + fruit"]
    C --> D["Mutation Chamber (Cave)"]
    D --> E["Select body part"]
    E --> F{"Level < 5?"}
    F -->|No| G["Max level reached"]
    F -->|Yes| H{"Enough resources?"}
    H -->|No| I["Farming"]
    I --> A
    H -->|Yes| J["Mutation animation<br/>VFX + haptics"]
    J --> K["Mesh swap<br/>Skeletal Mesh Merge"]
    K --> L["Recalculate stats"]
    L --> M["New playstyle"]
    M --> N["Save profile"]
```

## Upgrade Slots

| Slot | Beast Options | Stat |
|------|---------------|------|
| Hands | Tiger, Bear | Attack |
| Legs | Cheetah, Kangaroo | Speed/Jump |
| Eyes | Eagle, Snake | Vision |
| Skin | Crocodile, Rhino | Defense |
| Back | Banshee, Falcon | Glide |

## Requirements

- DNA sample (animal/boss se).
- Crystal (mining).
- Rare fruit (night zones).
- Level requirement (1 per tier).

## Related

- [body.md](body.md)
- [upgrades.md](upgrades.md)
- [work.md](work.md)
- [random-parts.md](random-parts.md)
