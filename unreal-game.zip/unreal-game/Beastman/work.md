# Beastman — Work / Backend Implementation

## Overview

Beastman system ko 10K procedural levels aur database logic ke saath
integrate karna.

## Data Structure

```cpp
struct FBodyPart {
    String partName;      // "Hands", "Legs", "Eyes", "Skin", "Back"
    int level;            // 1–5
    String beastType;     // "Tiger", "Cheetah", "Eagle", ...
    float powerMultiplier;
    bool isMutated;
};

class ABeastmanCharacter : public ACharacter {
    TMap<String, FBodyPart> bodyParts;
    float walkSpeed;
    float jumpZVelocity;
    float attackPower;
    float poisonResistance;
    bool canGlide;
    bool nightVision;
};
```

## Upgrade Flow

```
Player collects DNA
        ↓
Enters Mutation Chamber (special cave)
        ↓
Selects body part + beast type
        ↓
Check resources (DNA, crystals, fruits)
        ↓
Play mutation animation + haptics + VFX
        ↓
Apply mesh change (Skeletal Mesh Merge)
        ↓
Recalculate stats
        ↓
Save to player profile
```

## Stat Calculation

```cpp
void recalculateStats() {
    walkSpeed      = baseSpeed + (bodyParts["Legs"].level * 150.0);
    jumpZVelocity  = baseJump  + (bodyParts["Legs"].level * 300.0);
    attackPower    = baseAtk   + (bodyParts["Hands"].level * 50.0);
    poisonResistance = bodyParts["Skin"].level * 0.3;
    canGlide       = bodyParts["Back"].level > 0;
    nightVision    = bodyParts["Eyes"].level > 0;
}
```

## VR Experience Layer

1. **Haptics:** Upgrade ke waqt controllers vibrate.
2. **VFX:** Jaadui light, particles, camera flash.
3. **Audio:** Beast roar + heartbeat sound.
4. **Body Inspection:** Player apne hathon ko VR me dekh sakta hai.

## Persistence

- Player profile me har body part ka level save.
- New game+ me upgrades carry forward (optional).
- Death ke baad upgrades retain (progression loss nahi).

## Integration With 10K Levels

- Har level par mutation materials spawn.
- Boss levels par guaranteed rare DNA drop.
- Level 1000+ par level 4–5 upgrades possible.
- Random mutation events (rare) — temporary boost.

## Performance Notes

- Mesh swap **async** karo (game freeze na ho).
- Sirf visible part update karo.
- LOD versions of beast meshes.
- Materials shared rakho.

## Testing Checklist

- [ ] Har part level 1–5 upgrade ho sake
- [ ] Stats sahi recalculate hon
- [ ] Mesh swap bina hitch ke
- [ ] Haptics/VFX sync
- [ ] Save/load works
- [ ] VR comfort maintained
