# 📁 Project Structure — Deep Folder Convention

> Rule: **jab bhi koi cheez random ho ya uske andar multiple parts ho,
> usse apna folder do.** File ko us folder ke andar rakho, aur us folder
> ka apna `workflow.md` + `random_combination.md` banao.

## The Pattern

```
docs/
└── <section>/
    ├── README.md          # section index
    ├── workflow.md        # section ka flow (Mermaid)
    ├── <file>.md          # shared/global files
    └── <part>/            # ek random entity / subsystem
        ├── README.md
        ├── workflow.md
        ├── random_combination.md
        └── <file>.md
```

Deep example:

```
docs/
└── animals/
    ├── README.md
    ├── workflow.md
    ├── friend-or-foe.md
    ├── damage-system.md
    ├── random-combinations.md
    ├── data-schema.md
    ├── sea.md
    ├── land.md
    ├── behavior.md
    └── snake/
        ├── README.md
        ├── random_combination.md
        ├── friend_or_foe.md
        ├── attack.md
        ├── loot.md
        ├── spawn.md
        └── animation.md
```

## Why So Deep?

| Level | Kya milta hai |
|-------|---------------|
| `docs/section/` | System ka overview |
| `docs/section/part/` | Ek entity ke saare rules ek jagah |
| `docs/section/part/file.md` | Ek hi topic, chhoti aur focused file |

Chhoti files ka fayda:

- Merge conflict kam.
- Search fast.
- Naya developer sirf apna part padhe.
- Har file ka clear owner hota hai.
- Documentation game code ke saath parallel chalti hai.

## Naming Rules

| Cheez | Rule | Example |
|-------|------|---------|
| Folder | lowercase, underscore | `electric_eel/` |
| File | lowercase, underscore | `random_combination.md` |
| Index file | always `README.md` | `snake/README.md` |
| Flow file | always `workflow.md` | `animals/workflow.md` |
| Random file | `random_combination.md` | `tiger/random_combination.md` |
| Boolean/system file | descriptive | `friend_or_foe.md` |
| Section folder | Title-Case (legacy) / lowercase (new) | `Levels/`, `animals/` |

> Naye folders lowercase me banao. Purane Title-Case folders tab tak
> reh sakte hain jab tak unhe migrate na kiya jaye.

## Animal Folder — 8 Files

Har animal ke liye ye 8 files mandatory hain:

| File | Kya likhna hai |
|------|----------------|
| `README.md` | Overview, quick stats, variant examples |
| `workflow.md` | Spawn → friend/foe → outcome flow |
| `random_combination.md` | Parts + options + total combinations |
| `friend_or_foe.md` | `is_friend = true/false` → benefit ya damage |
| `attack.md` | Attack table, damage formula, VR counter |
| `loot.md` | Drop table, DNA, crafting |
| `spawn.md` | Zone, level, rarity, day/night |
| `animation.md` | Animation states, sound, VFX, haptics |

### `is_friend` Rule

```cpp
if (animal.is_friend == false) {
    // Foe — player health down
    player.health -= animal.damage * animal.sizeScale;
} else {
    // Friend — player ko benefit
    animal.giveBenefit(player);
}
```

Har animal ke `friend_or_foe.md` me ye dono cases hone chahiye:

- **Foe:** kitna HP damage, poison chance, counter.
- **Friend:** kya benefit (pet, guide, mount, resource, buff).

## Random Combination Rule

Agar kisi cheez ke multiple random parts hain, to `random_combination.md`
me ye table banao:

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Species | Cobra, Viper, Python | Cobra | 5 |
| Length | 0.5–15 m | 6.5 m | 146 |
| Colour | 24-color palette | Neon Blue | 24 |

Phir total:

```
Total = Common_Factors × Species_Factors
```

Detail: [animals/random-combinations.md](animals/random-combinations.md).

## Naya Animal Add Karne Ka Tarika

1. `scripts/generate_animals.py` kholo.
2. `ANIMALS` list me naya `animal(...)` block add karo.
3. `parts`, `attacks`, `loot`, `variants`, `damage`, `benefit` bharo.
4. Script run karo:

```bash
python3 scripts/generate_animals.py
```

5. Verify karo:

```bash
ls docs/animals/<new_animal>/
```

Script khud hi 8 files + index + global math update kar dega.

## Kahan Naya Folder Banao?

| Situation | Folder banao? |
|-----------|---------------|
| Naya animal | Haan — `animals/<name>/` |
| Naya biome | Haan — `animals/` me overview ya alag section |
| Naya boss | Haan — `Boss-Fight/<boss>/` |
| Naya weapon type | Haan — `Extra-Ideas/living-weapons/<type>/` |
| Sirf ek chhota rule | Nahi — existing file me section add karo |
| Ek hi topic ke 5+ files | Haan — apna folder |

## Depth Checklist

Kisi bhi naye folder ke liye:

- [ ] `README.md` hai
- [ ] `workflow.md` hai
- [ ] Random hai? → `random_combination.md` hai
- [ ] Boolean/system hai? → dedicated file hai
- [ ] Har file me `Related` links hain
- [ ] Links relative hain (`../`, `./`)
- [ ] Folder/file names lowercase + underscore

## Related

- [README.md](README.md) — main docs index
- [workflow.md](workflow.md) — master game workflow
- [animals/README.md](animals/README.md) — reference implementation
- [animals/snake/README.md](animals/snake/README.md) — reference animal
