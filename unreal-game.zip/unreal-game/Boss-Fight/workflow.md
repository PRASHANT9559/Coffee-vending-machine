# Boss-Fight — Workflow

Boss encounter ka poora flow — spawn se reward tak.

```mermaid
flowchart TD
    A["Mission final point"] --> B["Boss room enter"]
    B --> C["Load last 5 fight records"]
    C --> D["Counter strategy calculate"]
    D --> E["4 weapons random attach"]
    E --> F["Taunt dialogue + roar"]
    F --> G["Fight start"]
    G --> H{"Player action?"}
    H -->|Attack| I["Boss block / counter"]
    H -->|Dodge| J["Boss miss"]
    H -->|Pet assist| K["Pet distract"]
    I --> L{"Arm cut?"}
    L -->|Yes| M["Weapon drop + speed down"]
    L -->|No| N["Boss attack"]
    J --> G
    K --> G
    M --> G
    N --> O{"Player health > 0?"}
    O -->|No| P["Death cinematic"]
    O -->|Yes| Q{"Boss health > 0?"}
    Q -->|Yes| G
    Q -->|No| R["Boss death + diamond"]
    R --> S["Save fight record"]
```

## Fight Phases

| Phase | HP | Behavior |
|-------|-----|----------|
| 1 | 100–70% | Slow attacks |
| 2 | 70–40% | Combos + shield |
| 3 | 40–0% | Enraged, fast |

## Player Options

- Weapon strategy (side/back attack).
- Arm cutting.
- Pet assistance.
- Shield block / dodge.

## Related

- [schema.md](schema.md)
- [combat.md](combat.md)
- [reward.md](reward.md)
- [random-parts.md](random-parts.md)
