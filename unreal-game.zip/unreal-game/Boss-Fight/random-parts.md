# Boss-Fight — Random Parts

4-armed boss ke saare random parts.

## Boss Ke Parts

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Boss_ID` | String | Unique | B-99 |
| 2 | `Body_Type` | Enum | Beastman, Giant, Mutant, Elemental | Beastman |
| 3 | `Height` | Float | 10–25 feet | 15 |
| 4 | `Skin_Color` | Color | Random RGB | Dark Red |
| 5 | `Pattern` | Enum | Tribal, Scars, Scales, Glow | Tribal |
| 6 | `Eye_Color` | Color | Random | Neon Red |
| 7 | `Eye_Glow` | Boolean | True/False | True |
| 8 | `Hand_1_Weapon` | Enum | Sword, Axe, Shield, Bow, Spear | Dual Sword |
| 9 | `Hand_2_Weapon` | Enum | (same) | Giant Axe |
| 10 | `Hand_3_Weapon` | Enum | (same) | Heavy Shield |
| 11 | `Hand_4_Weapon` | Enum | (same) | Bow |
| 12 | `Health` | Float | 1000–20000 | 5000 |
| 13 | `Attack_Speed` | Float | 0.5–3.0 | 1.2 |
| 14 | `Damage` | Float | 10–500 | 120 |
| 15 | `Behavior` | Enum | Balanced, Aggressive, Defensive | Aggressive |
| 16 | `Voice_Pitch` | Float | 0.3–1.0 | 0.4 |
| 17 | `Arena` | Enum | Ruins, Cave, Temple, Floating | Ruins |
| 18 | `Reward` | Enum | Diamond, DNA, Weapon | Diamond |
| 19 | `Phase_Count` | Integer | 1–3 | 3 |
| 20 | `Weak_Point` | Enum | Back, Head, Arm, Leg | Back |

## Weapon Selection Formula

```
weapons = []
for i in 1..4:
    weapons.add(RandomEnum(Sword, Axe, Shield, Bow, Spear, Hammer))

// Adaptive override:
if (last5.mostUsedWeapon == "Bow"):
    weapons[0] = Shield
    behavior = "Hyper_Aggressive_Charge"
```

## Example Boss

### Boss 1 — Ruins Beastman (Level 500)
```
Body: Beastman | Height: 15ft | Color: Dark Red
Eye: Neon Red (Glow) | Pattern: Tribal
Hands: Dual Sword + Giant Axe + Heavy Shield + Bow
Health: 5000 | Speed: 1.2 | Damage: 120
Behavior: Aggressive | Voice: 0.4 | Arena: Ruins
Phases: 3 | Weak: Back | Reward: Diamond
```

### Boss 2 — Energy Beastman (Level 5000)
```
Body: Mutant | Height: 20ft | Color: Bioluminescent Blue
Eye: Cyan (Glow) | Pattern: Glow
Hands: Energy Blade + War Hammer + Shield + Magic Spear
Health: 15000 | Speed: 2.0 | Damage: 300
Behavior: Defensive | Voice: 0.3 | Arena: Temple
Phases: 3 | Weak: Head | Reward: Legendary DNA
```

## Balance Rules

- Har level par weapons random → replay value.
- Shield hamesha ek hath me ho sakta hai (max 1).
- Level 5000+ par energy weapons.
- Weak point random → player explore kare.

## Related

- [workflow.md](workflow.md)
- [schema.md](schema.md)
- [combat.md](combat.md)
- [reward.md](reward.md)
