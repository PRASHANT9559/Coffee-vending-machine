# 4-Armed Giant Beastman Boss — Schema

## Concept

Mission ke last point par player ko ek purani building se **diamond** lana
hai. Us building me ek **giant beastman** hai jiske **4 haath** hain aur
sabhi me weapons hain.

Usse fight karne ke baad hi diamond milega.

## Boss Schema (Database Structure)

| Column | Data Type | Example | VR Gameplay |
|--------|-----------|---------|-------------|
| `Boss_ID` | Integer | B-99 | Character identification |
| `Hand_1_Weapon` | String | ⚔ Dual Sword | Yeh hath bohot tez attack karega |
| `Hand_2_Weapon` | String | 🪓 Giant Axe | Attack slow, lekin damage heavy (stun kar sakta hai) |
| `Hand_3_Weapon` | String | 🛡 Heavy Shield | Player attack par aage aakar block karega |
| `Hand_4_Weapon` | String | 🏹 Bow / Magic Spear | Door se nishana lagayega |
| `Diamond_Status` | Boolean | `Locked_In_Chest = True` | Boss marne par False → loot milega |

## Boss Stats

| Stat | Value |
|------|-------|
| Height | 15 feet |
| Health | 5000 |
| Hands | 4 |
| Weapons | 4 (random per level) |
| Weak Point | Back (jahan koi weapon nahi) |
| Reward | Giant Diamond 💎 |

## Level-Based Weapon Randomization

- **Level 500:** Normal swords aur shield.
- **Level 5000:** Bioluminescent Energy Weapons, Avatar-style khunkhar
  hathiyaar.
- Har level par boss ka fighting style badal jayega.

## Weapon Pool

```cpp
List<String> weaponPool = [
    "Dual_Swords", "Giant_Axe", "Heavy_Shield",
    "Bow", "Magic_Spear", "Energy_Blade", "War_Hammer"
];
```

## Boss Spawn

- Sirf mission ke **final point** par.
- Purani khandahar building ke aakhri kamre me.
- Entry par dialogue + roar + weapon glow.

## 💡 Design Note

4 haath = 4 alag attack patterns. Player ko har weapon ka counter seekhna
padega — button mashing se boss nahi marega.
