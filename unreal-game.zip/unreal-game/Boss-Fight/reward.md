# Boss Reward — The Diamond

## Victory Sequence

Jab player 4-armed beastman ko haraata hai:

1. Boss zameen par girta hai.
2. Uske hathon se saare weapons chhoot jate hain.
3. Uske piche rakhi **vault/tijori** khulti hai.
4. Ek khubsurat, chamakta hua **Giant Diamond 💎** nikal kar hawa me
   tairne lagta hai.

## VR Interaction

- Player **physically apne haath aage badha kar** diamond ko touch karta hai.
- Jaise hi touch:
  - Poori screen par sabse bada **visual blast**.
  - Text: **LEVEL CLEARED!**
- Reward inventory me add.

## Backend Logic

```cpp
void onBossDeath() {
    spawnActor("Diamond_Class", bossPosition); // Diamond niche gir jayega
    triggerVREmote("Victory_Dance");           // Player ka jashn!
}
```

## Reward Table

| Reward | Chance | Use |
|--------|--------|-----|
| Giant Diamond 💎 | 100% | Mission complete, currency |
| Rare DNA Sample | 70% | Beastman upgrade |
| Legendary Weapon | 40% | Combat |
| Pet Skin | 25% | Cosmetic |
| New Emote | 15% | Social |

## Post-Fight

- **Victory Dance:** Player + pet synced emote.
- **Loot collection:** Diamond + random drops.
- **Progression:** Next level unlock.
- **Save:** Auto-save after reward.

## Mission Completion

Diamond touch karne ke baad:
- Mission complete mark.
- XP + currency.
- Next random mission generate.
- New equipment unlock.

## 💡 Replay Value

Boss har level par alag weapons ke saath aayega. Diamond ek hi hai,
lekin jeetne ka tareeqa har baar naya hoga.
