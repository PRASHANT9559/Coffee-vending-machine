# Boss Fight — Combat Mechanics

## VR Fighting (Asli Maza)

VR me sirf button-mashing nahi — player ko **dimaag** lagana padega.

### 1. The Weapon Strategy
- Boss ke 4 haath hain.
- Agar ek hath me **shield 🛡** hai → samne se hamla nahi kar sakte.
- Player ko Tiger Beastman ke pairon se tezi se **Left/Right jump**
  karke boss ke **piche** jana hoga.
- Peeth par hamla karo jahan koi weapon nahi.

### 2. Cutting the Arms (Hath Kaatna)
- Player talwar ⚔ se perfect nishana lagaye.
- Boss ka ek hath **temporarily disable ya cut** ho sakta hai.
- Hath katega → weapon gaddhe me girega → attack speed kam.

### 3. Pet Assistance 🐅
- Akele 4-armed boss se nahi lad pa rahe?
- Pet tiger aage aakar boss ke **pair pakad lega** ya distract karega.
- Player ko diamond ke paas jaane ka mauka milega.

### 4. Dodge & Block
- Player physically sir jhuka kar (duck) attack dodge kare.
- Shield 🛡 utha kar heavy attacks block kare.
- VR me actual body movement = immersion.

## Attack Patterns

| Hand | Weapon | Attack | Counter |
|------|--------|--------|---------|
| 1 | Dual Sword | Fast slash | Block / dodge |
| 2 | Giant Axe | Heavy slow slam | Side step |
| 3 | Heavy Shield | Block + bash | Go behind |
| 4 | Bow/Spear | Ranged | Close distance |

## Boss Phases

1. **Phase 1 (100–70% HP):** Slow attacks, player seekh sakta hai.
2. **Phase 2 (70–40% HP):** Combo attacks + shield usage.
3. **Phase 3 (40–0% HP):** Enraged — fast attacks, weapon glow.

## Backend Logic

```cpp
class FourArmedBoss {
    List<Weapon> activeWeapons = [];
    int health = 5000;
    int phase = 1;

    void loadBossWeapons(int levelSeed) {
        activeWeapons.add(getRandomWeapon(levelSeed + 1));
        activeWeapons.add(getRandomWeapon(levelSeed + 2));
        activeWeapons.add(getRandomWeapon(levelSeed + 3));
        activeWeapons.add(getRandomWeapon(levelSeed + 4));

        attachWeaponsToSkeletalMesh(activeWeapons);
    }
}
```

## Level Scaling

- `Boss_Health = 5000 + (Level_Number * 2)`
- `Attack_Speed = Base + (Level_Number * 0.05)`
- Weapon pool level ke hisaab se upgrade.

## 💡 VR Comfort

- Boss ke bade attacks par camera shake controlled.
- Player ko teleport/dodge me comfort options.
- Hit feedback haptics ke saath.
