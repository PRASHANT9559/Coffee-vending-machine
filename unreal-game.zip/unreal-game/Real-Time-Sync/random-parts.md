# Real-Time-Sync — Random / Dynamic Parts

Time aur weather real-world se aata hai, lekin **dynamic weather events**
random generate hote hain. Neeche unke parts.

## 1. Weather Event Random Parts

| Part | Type | Options / Range | Example |
|------|------|-----------------|---------|
| `Weather_Type` | Enum | Clear, Rain, Storm, Fog, Heatwave | Storm |
| `Intensity` | Float | 0.0–1.0 | 0.8 |
| `Duration` | Float | 30–600 sec | 240 |
| `Transition_Time` | Float | 5–30 sec | 15 |
| `Cloud_Cover` | Float | 0.0–1.0 | 0.9 |
| `Rain_Rate` | Float | 0–100 | 70 |
| `Wind_Speed` | Float | 0–50 | 30 |
| `Visibility` | Float | 0.2–1.0 | 0.4 |
| `Gameplay_Effect` | Enum | None, Slippery, PoisonRisk, Tsunami | Slippery |
| `Audio_Layer` | String | Rain, Thunder, Wind | Thunder |

## 2. Time Event Random Parts

| Part | Type | Range | Example |
|------|------|-------|---------|
| `Time_Phase` | Enum | Dawn, Day, Sunset, Night | Sunset |
| `Sun_Angle` | Float | -90 to 90 | 12 |
| `Moon_Visibility` | Boolean | True/False | True |
| `Star_Density` | Float | 0.0–1.0 | 0.7 |
| `Bioluminescence` | Boolean | True/False | True |
| `Night_Difficulty_Multiplier` | Float | 1.0–2.5 | 2.0 |

## 3. Random Weather Shift Formula

```
Every 5–10 minutes:
  If (Random(0,1) > 0.6):
      newWeather = RandomEnum(Clear, Rain, Storm, Fog)
      intensity = RandomFloat(0.3, 1.0)
      duration  = RandomFloat(60, 480)
      applyTransition(newWeather, duration)
```

## Example Instances

### Event A — Sudden Storm (Level 752, Night)
```
Weather: Storm | Intensity: 0.8 | Duration: 240s
Cloud: 0.9 | Rain: 70 | Wind: 30 | Visibility: 0.4
Effect: Slippery | Audio: Thunder
Bioluminescence: ON | Difficulty: 2x
```

### Event B — Clear Dawn (Level 12, Morning)
```
Weather: Clear | Intensity: 0.1 | Duration: 300s
Cloud: 0.2 | Rain: 0 | Wind: 5 | Visibility: 1.0
Effect: None | Audio: Birds
Bioluminescence: OFF | Difficulty: 1x
```

## Balance Rules

- Storm + night = maximum danger (predators aggressive).
- Clear + day = safe exploration.
- Tsunami sirf cataclysm levels (every 500th).
- Weather transition smooth ho — sudden pop nahi.

## Related

- [workflow.md](workflow.md)
- [api-sync.md](api-sync.md)
- [modes.md](modes.md)
- [../Levels/random-parts.md](../Levels/random-parts.md)
