# Day/Night Modes — Manual & Auto

## 3 Fail-Safe Modes

Player settings me se choose kar sakta hai:

```
              [ Player Starts Game ]
                        |
             🔬 Check Settings Selection
            /                          \
    [ Manual Mode ]              [ Auto Mode ]
          |                            |
  (Day/Night Core Fix)         🌐 Check Internet
                                /            \
                        (Connected)      (Disconnected)
                            |                 |
                      [ Live API ]     [ PC System Time ]
```

## Mode 1 — Manual Mode (User Override)

- Player chahe to real-life me raat ke 2 baje bhi game me "Day Mode"
  select kar sakta hai.
- Menu me **Day Mode / Night Mode** toggle.
- Engine real-time calculation **pause** kar deta hai aur suraj
  (Directional Light) ko fixed angle par lock kar deta hai.

## Mode 2 — Auto Mode + Internet ON (Premium)

- Player ne 'Auto' rakha hai aur internet connected hai.
- Engine background me Ayodhya (ya current location) ka IP + timezone
  uthayega.
- Live API se connect karega.
- Real accurate **weather, clouds position, sunset/sunrise** game me
  live badalte rahenge.

## Mode 3 — Auto Mode + Internet OFF (Smart Fallback)

- Internet chala gaya / disconnected.
- Engine turant **local PC/headset clock** par switch kar jayega.
- PC me 7:30 PM → game bina internet ke bhi sunset mode activate.
- **Game kisi bhi condition me nahi rukna chahiye.**

## Settings UI (Suggested)

| Setting | Options |
|---------|---------|
| Time Mode | Auto / Manual Day / Manual Night |
| Weather Sync | On / Off |
| Fallback | PC Time (default) |

## Check Loop

- Game start par check.
- Har **1 minute** ke loop par re-check (internet aa gaya ya chala gaya).
- Player ko loading/glitch feel nahi hona chahiye.

> Next: [fallback.md](fallback.md) — offline architecture.
