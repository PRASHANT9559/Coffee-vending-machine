# Offline Fallback & Fail-Safe Architecture

## Rule

> **Game kisi bhi condition me nahi rukna chahiye.**

Software development me ise **Fallback System** + **User Override** kehte
hain. Professional game ki pehchan: internet ho ya na ho, game ka core
system kabhi crash/fail nahi hota.

## Fallback Logic

```cpp
void updateGameEnvironment() {
    if (userSettings == "Manual") {
        // User ke custom input ke hisaab se
        applyCustomTime(userSelectedTime);
    }
    else if (userSettings == "Auto") {

        // Check internet connection
        if (isInternetAvailable()) {
            var apiData = fetchLiveWeatherAndInformation();
            applySkyAtmosphere(apiData.time, apiData.weatherCondition);
        }
        else {
            // Internet nahi hai? No problem! Fallback to PC Clock
            var localTime = getPCSystemTime();
            applySkyAtmosphere(localTime, "Default_Clear_Weather");
        }
    }
}
```

## Zero Loading / Zero Crash

- Live assets load nahi ho rahe.
- Pehle se maujood 3D elements ka sirf **material, color aur lighting
  angle** math se badal rahe hain.
- Isliye internet disconnected hone par bhi **koi glitch ya lag nahi**.

## Dynamic Graphics Effects

| Real Time | Game Effect |
|-----------|-------------|
| Dopahar 2 baje | Sharp, chhoti shadows (Direct Sunlight) |
| Shaam 6:55 | Orange/laal sky, sunset |
| Raat 1 baje | Stars, moon light, bioluminescence |
| Barish | Clouds, wet surfaces, kam visibility |

## Architecture Benefits

1. **Stable:** Koi crash nahi.
2. **Responsive:** Player ke mood/situation ke hisaab se dhalta hai.
3. **Lightweight:** Koi extra asset download nahi.
4. **Offline-first:** Internet optional hai, mandatory nahi.

## Edge Cases

- API timeout → PC time fallback.
- Wrong IP location → manual override.
- Timezone change → system time use.
- Headset sleep/wake → re-sync on resume.
