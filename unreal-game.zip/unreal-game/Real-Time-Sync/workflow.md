# Real-Time-Sync — Workflow

Real-world time/weather ko game me sync karne ka loop.

```mermaid
flowchart TD
    A["Game start / resume"] --> B["Read settings"]
    B --> C{"Mode?"}
    C -->|Manual| D["Lock sun angle<br/>user selection"]
    C -->|Auto| E["Get location + system time"]
    E --> F{"Internet?"}
    F -->|Yes| G["HTTP request → Weather API"]
    G --> H{"API success?"}
    H -->|No| I["Fallback: PC time"]
    H -->|Yes| J["Parse: time, sunset, weather"]
    J --> K["Set Directional Light angle"]
    J --> L["Set clouds + rain + fog"]
    K --> M["Apply Lumen + Sky Atmosphere"]
    L --> M
    I --> M
    D --> M
    M --> N["Night? → bioluminescence + difficulty"]
    N --> O["Wait 60 sec"]
    O --> B
```

## Sync Loop Details

1. **Start:** settings padho (Manual/Auto).
2. **Fetch:** location + time; internet ho to API.
3. **Apply:** sun angle, weather, clouds, fog.
4. **Gameplay effect:** night = glow + 2x difficulty.
5. **Refresh:** har 60 sec.
6. **Fallback:** API fail → PC clock.

## Failure Handling

| Failure | Action |
|---------|--------|
| No internet | PC system time |
| API timeout | Last cached data |
| Wrong location | Manual override |
| Headset sleep | Re-sync on resume |

## Related

- [api-sync.md](api-sync.md)
- [modes.md](modes.md)
- [fallback.md](fallback.md)
- [random-parts.md](random-parts.md)
