# Real-Time Time & Weather Sync

## Concept

Gaming/tech duniya me ise **Real-Time Synchronization** ya
**Dynamic Real-World Weather/Time Sync** kehte hain.

Jaise Microsoft Flight Simulator real-world weather use karta hai, waise hi
hamara game player ki location (Ayodhya) ka time aur weather use karega.

## Magic Moment

- Player ke yahan sunset ho raha hai → game ke island par bhi sunset.
- Raat ho gayi → Avatar 2 ka **bioluminescent mode** automatically ON.
- Raat 12 baje khelo → island par ghor andhera, toofan, aggressive snakes.
- Din me khelo → sab shant aur saaf.

## Data Flow (4 Steps)

### Step 1 — Location + Time
- Engine player ke PC/headset ka **system time** aur **IP address**
  check karega (Location: Ayodhya, India).

### Step 2 — Live Weather API
- UE me **HTTP Request Node** (ya C++ code) likho.
- Free API: **OpenWeatherMap**.
- Data: `Sunset_Time`, `Current_Time`, `Weather`.

### Step 3 — Sky Atmosphere Link
- UE5 ka in-built **Sky Atmosphere** + **Volumetric Clouds** use karo.
- API ke time ko **Directional Light (suraj)** ke rotation angle se jodo.
- 6:54 PM → suraj horizon ke paas → aasman laal/orange.

### Step 4 — Gameplay Effects
- Night → bioluminescence ON, snake difficulty 2x.
- Rain → slippery ground, visibility kam.
- Storm → tsunami/cataclysm events.

## Backend Logic

```cpp
void syncRealWorldTime(String userLocation) {
    var weatherData = fetchLiveAPI(userLocation); // Ayodhya ka data

    // Suraj ki position real-world time ke hisaab se
    setSunRotation(weatherData.sunAngle);
    setGameTime(weatherData.currentTime);

    if (weatherData.isNight == true) {
        enableBioluminescence(true);   // Avatar mode ON
        increaseSnakeDifficulty(2.0);  // Raat me khatra dugna
    }
}
```

## Player Par Asar

1. **Emotional Connection:** Game ki duniya asli duniya se judi lagti hai.
2. **Unpredictable Levels:** Same Level 500 subah aasan, raat ko darawna.
3. **Zero Size Cost:** Sirf API data + lighting angle — koi naya asset nahi.

> Next: [modes.md](modes.md) — Manual/Auto modes aur fallback.
