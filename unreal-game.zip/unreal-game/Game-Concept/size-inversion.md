# Size Inversion System

## Concept

Journey 2 ka rule: **badA chhota, chhota badA**.
Hamare VR game me yeh fruit khaane se player ke saath hota hai.

## 🍍 The Size Inversion Fruit

### The Giant Mode (Bada Mango)
- Bada mango khaate hi character **15 feet giant** ban jata hai.
- VR me saare ped chhote dikhne lagte hain.
- Bade animals se aasani se lad sakta hai, unhe uthakar phek sakta hai.
- **Drawback:** Chhote raaste aur caves me nahi ja sakta.

### The Ant Mode (Chhota Apple)
- Chhota apple khaate hi character **1 foot (chuhe ke barabar)** ho jata hai.
- Ghaas jungle ban jati hai.
- Normal snake **Anaconda** jaisa dikhta hai.
- **Fayda:** Patton ke neeche chhup kar nikal sakta hai, cave ke chhote
  cracks me ja sakta hai jahan bada khazana chhupa hai.

## Gameplay Impact

| Mode | Scale | Strength | Weakness |
|------|-------|----------|----------|
| Giant | 15 ft | Heavy combat, throw animals | Small paths blocked |
| Normal | 6 ft | Balanced | — |
| Ant | 1 ft | Stealth, secret areas | Vulnerable to everything |

## Backend Logic

```dart
if (fruit.effectType == "MakeGiant") {
  player.visualScale = 5.0;
  player.canEnterSmallCaves = false;
} else if (fruit.effectType == "MakeTiny") {
  player.visualScale = 0.2;
  player.canEnterSmallCaves = true;
}
```

## 💡 Motion Sickness Note

VR me scale achanak badalne par player ko comfortable transition chahiye
(warna chakkar aa sakte hain). Isliye scale change ke saath ek short
VFX + haptic feedback do.
