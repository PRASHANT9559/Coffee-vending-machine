# Game-Concept — Gameplay Workflow

Core concept se gameplay tak ka flow.

```mermaid
flowchart TD
    A["Concept: Journey 2 + Avatar 2"] --> B["Island environment design"]
    B --> C["Bioluminescent night mode"]
    B --> D["Floating mountains + ocean"]
    B --> E["Atlantis ruins + caves"]
    C --> F["Lumen lighting"]
    D --> G["UE5 Water System"]
    E --> H["Mining + puzzles"]
    F --> I["Player spawn"]
    G --> I
    H --> I
    I --> J["Explore island"]
    J --> K["Size inversion fruits"]
    J --> L["Animal encounters"]
    J --> M["Resource gathering"]
    K --> N["Giant / Ant gameplay"]
    L --> O["Tame / Fight / Flee"]
    M --> P["Crafting"]
    N --> Q["Mission progress"]
    O --> Q
    P --> Q
    Q --> R{"Boss mission?"}
    R -->|Yes| S["Boss fight"]
    R -->|No| J
```

## Design Rules

1. **Visual scale** pehle — VR ka main attraction.
2. **Exploration** reward karo — har kone me kuch ho.
3. **Night = danger + beauty** — bioluminescence + predators.
4. **Size change** ko gameplay mechanic banao, gimmick nahi.
5. **Virtual tourism** feel ko survival ke saath balance karo.

## Core Loop

Explore → Collect → Craft → Survive → Mission → Boss → Upgrade → Repeat.

## Related

- [overview.md](overview.md)
- [island.md](island.md)
- [size-inversion.md](size-inversion.md)
- [random-parts.md](random-parts.md) — island/props ke random parts
