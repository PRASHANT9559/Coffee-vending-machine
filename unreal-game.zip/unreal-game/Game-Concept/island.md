# The Island — Environment Design

## Bioluminescent Mysterious Island

- Raat ke waqt poora island **Avatar ke Pandora** ki tarah roshni se chamkega.
- Har ped, paudha aur zameen par bheege patte alag-alag rangon me glow
  karenge: **neon blue, green, pink**.
- UE5 ka **Lumen** system ise real-life jaisa dikhayega — player ke haath,
  gun aur zameen par real-time roshni padegi.

## Key Locations

| Location | Description |
|----------|-------------|
| **Floating Mountains** | Unche tairte hue patthar, Ikran/Banshee se udne ke liye |
| **Tree of Souls** | Island ke beech me jaadui ped, roots se duniya judi |
| **Atlantis Ruins** | Purani khoyi hui civilization, Journey 2 style |
| **Nautilus Submarine** | Samundar ki gehrai me khoya hua giant submarine |
| **Deep Ocean** | Crystal clear paani, colorful corals, Avatar 2 style |
| **Caves** | Andheri gufayein, rare minerals, snakes, boss arena |

## Water System

- UE5 ka naya **Water Plugin** use karo.
- Paani ki leharein, reflections aur underwater view lag-free.
- Player physically apne hathon se **tair (swim)** sake.
- Samundari jeevon ko chhu sake.

## Day / Night

- **Din:** Birds aakash me, khubsurat nazara, fruits todna aasan.
- **Raat (Avatar Mode):** Poora island chamkega, lekin snakes aur
  predators hunting par nikalenge — difficulty double.

## Size Inversion Rules (Journey 2 Style)

- Jo cheezein badi hoti hain wo chhoti ho jati hain.
- Jo chhoti hoti hain wo giant ban jati hain.
- Example: chhote elephant, giant bees/madhumakkhi.
- VR me scale ka anubhav mind-blowing hota hai.

> Next: [size-inversion.md](size-inversion.md) — fruit-based size system.
