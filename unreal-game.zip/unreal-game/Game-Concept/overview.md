# Game Concept — Overview

## The Mashup

**Journey 2: The Mysterious Island** + **Avatar: The Way of Water (Pandora)**
ke worlds ko mila kar ek naya VR map.

Yeh concept VR ke liye perfect hai kyunki VR ka asli maza do cheezon me aata hai:

1. **Visual Scale** — badi aur khubsurat cheezein dekhna.
2. **Exploration** — ek nayi duniya ko explore karna.

## Visual Look

- Upar se jannat jaisa khubsurat island.
- Raat me **jaadui / bioluminescent**.
- Avatar ke Pandora jaisa glow: neon blue, green, pink.
- Journey 2 ke mystery + Avatar 2 ke ocean ka mix.

## Gameplay Fantasy

Player VR headset pehan kar:

- Island par ghoom sakta hai.
- Pedon par chadh sakta hai.
- Samundar me dive kar sakta hai.
- Giant creatures (Ikran, Ilu, Tulkun) ke saath interact kar sakta hai.
- Floating mountains par ud sakta hai.

## Positioning

Yeh game **"Virtual Tourism"** se aage ja kar ek hardcore
**Survival-Adventure** hai:

> Log ise gaming se zyada "ek nayi duniya ghumne" ke liye khareedenge.
> Isliye visuals par sabse zyada dhyan dena hai.

## Core Loop

1. Naya level load (procedural).
2. Mission mile (random).
3. Explore + survive + craft.
4. Boss/loot/reward.
5. Naya equipment/upgrade.
6. Repeat — har baar naya experience.
