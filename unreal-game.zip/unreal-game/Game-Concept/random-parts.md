# Game-Concept — Random Parts

Island, props aur size-effect fruits har level par random generate hote
hain. Neeche unke saare parts diye gaye hain.

## 1. Island Random Parts

| Part | Type | Options / Range | Example |
|------|------|-----------------|---------|
| `Island_Shape` | Enum | Round, Crescent, Ring, Split | Crescent |
| `Island_Size` | Float | 500–5000 units | 2200 |
| `Biome` | Enum | Jungle, Swamp, Rocky, Mixed | Jungle |
| `Water_Level` | Float | 0–500 | 120 |
| `Floating_Mountains` | Integer | 0–8 | 3 |
| `Ruins_Count` | Integer | 0–5 | 2 |
| `Cave_Count` | Integer | 1–10 | 4 |
| `Tree_Density` | Float | 0.2–1.0 | 0.75 |
| `Bioluminescence_Palette` | Array | Neon Blue, Green, Pink, Purple | Blue + Pink |
| `Weather_Default` | Enum | Clear, Rain, Storm, Fog | Clear |
| `Spawn_Points` | Integer | 20–30 | 24 |

## 2. Size-Effect Fruit Random Parts

| Part | Type | Options / Range | Example |
|------|------|-----------------|---------|
| `Fruit_Type` | Enum | Apple, Mango, Blue Mango | Blue Mango |
| `Effect_Type` | Enum | MakeGiant, MakeTiny, Poison, Heal | MakeGiant |
| `Scale_Multiplier` | Float | 0.2–5.0 | 5.0 |
| `Duration` | Float | 10–120 sec | 45 |
| `Glow_Color` | Color | Random neon | Neon Pink |
| `Is_Poisonous` | Boolean | True/False | False |
| `Spawn_Zone` | Enum | Tree, Ground, Cave, Floating | Tree |

## 3. Prop Random Parts

| Part | Type | Range | Example |
|------|------|-------|---------|
| `Prop_Type` | Enum | Rock, Plant, Crystal, Statue | Crystal |
| `Color` | Color | Random RGB | Cyan |
| `Scale` | Float | 0.5–3.0 | 1.4 |
| `Glow` | Boolean | True/False | True |
| `Breakable` | Boolean | True/False | False |

## Generation Pseudocode

```cpp
FIslandData generateIsland(int levelSeed) {
    RandomStream rs = RandomStream(levelSeed);

    island.shape        = rs.RandomEnum<IslandShape>();
    island.size         = rs.FRandRange(500, 5000);
    island.biome        = rs.RandomEnum<Biome>();
    island.caves        = rs.RandRange(1, 10);
    island.floating     = rs.RandRange(0, 8);
    island.palette      = rs.RandomColors(2);
    island.weather      = rs.RandomEnum<Weather>();

    return island;
}
```

## Balance Rules

- Level 1–100: simple island, kam caves, clear weather.
- Level 1000+: floating mountains + night palette.
- Level 5000+: storm weather default + max caves.

## Related

- [workflow.md](workflow.md)
- [island.md](island.md)
- [size-inversion.md](size-inversion.md)
- [../Levels/random-parts.md](../Levels/random-parts.md)
