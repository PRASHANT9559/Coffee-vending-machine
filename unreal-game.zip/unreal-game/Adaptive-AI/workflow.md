# Adaptive-AI — Workflow

Boss ka learning loop — har fight ke baad wo player ko study karta hai.

```mermaid
flowchart TD
    A["Fight start"] --> B["Load last 5 records"]
    B --> C["Analyze player patterns"]
    C --> D["Weapon usage"]
    C --> E["Attack side"]
    C --> F["Win speed"]
    C --> G["Pet usage"]
    D --> H["Counter strategy"]
    E --> H
    F --> H
    G --> H
    H --> I["Boss weapons + behavior set"]
    I --> J["Fight"]
    J --> K{"Player wins?"}
    K -->|Yes| L["Record winning strategy"]
    L --> M["Circular queue update<br/>purana delete"]
    K -->|No| N["Record failed strategy"]
    N --> M
    M --> O["Next fight"]
    O --> B
```

## Learning Loop

1. **Before fight:** last 5 records load.
2. **Analyze:** weapon, side, speed, pet.
3. **Counter:** weapons + behavior.
4. **Fight:** player reacts.
5. **After:** new record save.

## Circular Queue

```
5 slots → naya data aane par sabse purana delete
[F6][F7][F8][F9][F10] → next fight me [F7][F8][F9][F10][F11]
```

## Related

- [records.md](records.md)
- [counter-strategy.md](counter-strategy.md)
- [code.md](code.md)
- [random-parts.md](random-parts.md)
