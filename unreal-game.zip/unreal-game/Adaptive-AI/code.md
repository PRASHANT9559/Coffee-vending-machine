# Adaptive AI — Backend Code

## Complete Boss Learning System

```dart
class BossLearningBrain {
  List<Map<String, dynamic>> last5FightRecords = [];

  // Fight ke baad record save karo
  void recordPlayerWinningStrategy(String finalMove, String weaponUsed) {
    if (last5FightRecords.length >= 5) {
      last5FightRecords.removeAt(0); // Circular queue
    }
    last5FightRecords.add({
      "winningMove": finalMove,
      "playerWeapon": weaponUsed,
    });
  }

  // Counter strategy calculate karo
  Map<String, dynamic> calculateCounterStrategy() {
    String mostUsedWeapon = analyzeTopWeapon(last5FightRecords);
    String mostUsedSide   = analyzeTopSide(last5FightRecords);

    if (mostUsedWeapon == "Bow") {
      return {
        "arm1": "Shield",
        "arm2": "Dual_Swords",
        "arm3": "Giant_Axe",
        "arm4": "Magic_Spear",
        "behavior": "Hyper_Aggressive_Charge"
      };
    } else if (mostUsedSide == "Right") {
      return {
        "arm1": "Dual_Swords",
        "arm2": "Heavy_Shield",  // Right side block
        "arm3": "Giant_Axe",
        "arm4": "Bow",
        "behavior": "Defensive_Counter"
      };
    }

    return {
      "arm1": "Dual_Swords",
      "arm2": "Giant_Axe",
      "arm3": "Heavy_Shield",
      "arm4": "Bow",
      "behavior": "Balanced"
    };
  }

  String analyzeTopWeapon(List<Map<String, dynamic>> records) {
    Map<String, int> counts = {};
    for (var r in records) {
      counts[r["playerWeapon"]] = (counts[r["playerWeapon"]] ?? 0) + 1;
    }
    return counts.entries.reduce((a, b) => a.value > b.value ? a : b).key;
  }

  String analyzeTopSide(List<Map<String, dynamic>> records) {
    // "winningMove" string se side parse karo
    int right = records.where((r) =>
        r["winningMove"].toString().contains("Right")).length;
    int left = records.where((r) =>
        r["winningMove"].toString().contains("Left")).length;
    return right >= left ? "Right" : "Left";
  }
}
```

## Performance

- Sirf **5 records** → memory negligible.
- Analyze sirf boss spawn par (har frame nahi).
- Server-side rakho to cheating se bacho.

## UE5 Implementation

- `TArray<FFightRecord>` struct.
- Blueprint me "Add" node + "Remove Index 0" node.
- Boss spawn par `CalculateCounterStrategy()` call.

## Testing

- [ ] 5 fights ke baad purana record delete
- [ ] Bow spam → shield + charge
- [ ] Right spam → right shield
- [ ] Counter ke baad bhi player jeet sake
- [ ] Save/load ke baad records persist

## 💡 Future Upgrade

- Player ki **dodge timing** bhi track karo.
- Favorite fruit/health item tracking.
- Pet usage pattern tracking.
- Difficulty auto-balance.
