# Counter Strategy — Boss Ka Jawab

## Level 11 Par Beastman Kya Karega?

Jab player 11th level par pahuchega, boss direct spawn nahi hoga.
Wo pichle 5 matches ki calculation ka **counter (tod)** lekar aayega.

## Counters

### Counter 1 — Shield Block (Hathiyaar Badalna)
- Pichle matches me 80% hamle **Right Side** se hue.
- Boss is baar game shuru hote hi apne **Right Side wale hath me Heavy
  Shield 🛡 load** kar lega!
- Player wahi purani strategy lagayega → saare attacks block ho jayenge.

### Counter 2 — Distance Closer (Door Rehne Ka Tod)
- Record batata hai ki player door se **teer 🏹** chalata hai.
- Boss aate hi tezi se player ki taraf **daudega** (Cheetah pairon ki
  power se).
- Door rehne ka mauka hi nahi dega.

### Counter 3 — Weapon Switch
- Player sword se jeeta → boss axe + shield combo layega.
- Player bow se jeeta → boss charge + ranged weapon.

## Counter Logic

```dart
Map<String, dynamic> calculateCounterStrategy() {
  // Hidden math (user se chhupa kar)
  String mostUsedWeapon = analyzeTopWeapon(last5FightRecords);

  if (mostUsedWeapon == "Bow") {
    return {
      "arm1": "Shield",
      "behavior": "Hyper_Aggressive_Charge"
    };
  } else {
    return {
      "arm1": "Dual_Swords",
      "behavior": "Defensive_Counter"
    };
  }
}
```

## Behavior Modes

| Player Pattern | Boss Counter |
|----------------|--------------|
| Right side attacks | Right hand shield |
| Bow/ranged spam | Hyper aggressive charge |
| Sword close combat | Defensive counter + axe |
| Pet assistance | AoE attacks to separate pet |
| Dodge spam | Delayed attacks / feints |

## Difficulty Balance

- Counter **perfect** nahi hona chahiye — player ke paas jeetne ka
  mauka ho.
- Boss 70% counter kare, 30% random.
- Har 5 level baad strategy phir se analyze.

## 💡 Player Reaction

Player pure gusse me physically talwar uthayega:
*"Is baar to tujhe chhodunga nahi!"*

Yeh emotional engagement hi game ka asli reward hai.
