# Adaptive-AI — Random / Decision Parts

Boss ka "dimaag" kai parts se decisions leta hai. Har part track hota hai
aur counter generate karta hai.

## Tracked Parts

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Most_Used_Weapon` | Enum | Sword, Bow, Claws, Axe, Spear | Bow |
| 2 | `Most_Used_Side` | Enum | Left, Right, Front, Back | Right |
| 3 | `Avg_Win_Time` | Float | 10–600 sec | 45 |
| 4 | `Dodge_Rate` | Float | 0.0–1.0 | 0.7 |
| 5 | `Pet_Usage_Rate` | Float | 0.0–1.0 | 0.4 |
| 6 | `Heal_Item_Usage` | Float | 0.0–1.0 | 0.2 |
| 7 | `Aggression_Score` | Float | 0.0–1.0 | 0.8 |
| 8 | `Counter_Weapon` | Enum | Shield, Sword, Axe, Bow | Shield |
| 9 | `Counter_Behavior` | Enum | Balanced, Aggressive, Defensive, Charge | Charge |
| 10 | `Counter_Side` | Enum | Left, Right, Both | Right |
| 11 | `Taunt_Type` | Enum | Mock, Threat, Personal, Random | Mock |
| 12 | `Difficulty_Adjust` | Float | 0.8–1.5 | 1.2 |

## Decision Formula

```
if (Most_Used_Weapon == "Bow"):
    Counter_Weapon = Shield
    Counter_Behavior = "Hyper_Aggressive_Charge"

if (Most_Used_Side == "Right"):
    Counter_Side = "Right"
    // Right hand me shield

if (Avg_Win_Time < 30):
    Difficulty_Adjust = 1.3   // player easy jeet raha hai
elif (Avg_Win_Time > 300):
    Difficulty_Adjust = 0.9   // player struggle kar raha hai

if (Pet_Usage_Rate > 0.6):
    Behavior = "AoE_Anti_Pet"
```

## Example Record Set

### Player A — Bow Sniper
```
Weapon: Bow (4/5 fights) | Side: Left
Win Time: 35s | Dodge: 0.6 | Pet: 0.1
→ Counter: Shield + Charge | Difficulty: 1.2
```

### Player B — Right Side Brawler
```
Weapon: Claws (5/5) | Side: Right
Win Time: 50s | Dodge: 0.8 | Pet: 0.5
→ Counter: Right Shield + Defensive | Difficulty: 1.1
```

### Player C — Pet Dependent
```
Weapon: Sword | Side: Front
Win Time: 120s | Pet: 0.9
→ Counter: AoE attacks + separate pet | Difficulty: 1.0
```

## Balance Rules

- Counter 70% max — player ke paas jeetne ka mauka ho.
- Har 5 level baad strategy reset.
- Difficulty adjust 0.8–1.5 ke beech.
- Random 30% element rakho taaki predictable na ho.

## Related

- [workflow.md](workflow.md)
- [records.md](records.md)
- [counter-strategy.md](counter-strategy.md)
- [code.md](code.md)
