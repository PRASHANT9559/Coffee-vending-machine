# Adaptive Boss AI — Last 5 Fight Records

## Concept

Technical naam: **Adaptive Boss AI** ya **Dynamic Behavior Learning**.
Yeh wahi cheez hai jo Alien: Isolation ya Dark Souls jaise games me hoti
hai — boss player ki purani chaalon ko seekh kar khud ko upgrade karta hai.

## The Hidden Record

Game background me player ke pichle **5 sabse successful boss fights**
ka data store karega ek chote se **Circular Queue** me.

Circular Queue = naya data aane par sabse purana data apne aap delete ho
jata hai → RAM bachi rahti hai.

```
[Fight 6] [Fight 7] [Fight 8] [Fight 9] [Fight 10]
   ↑ purana delete                             ↑ naya add
```

## What Gets Tracked

### 1. Attack Pattern Tracking
- Player ne boss ko harane ke liye sabse zyada kya kiya?
- Example: "Right Side Jump + Tiger Claws" 80% baar.
- `Right_Attack_Ratio = 0.80`

### 2. Weapon Strategy Tracking
- Player har baar talwar chhod kar sirf **bow & arrow** se door se
  nishana maar raha tha?
- `Most_Used_Weapon = "Bow"`

### 3. Fight Duration / Difficulty
- Kitni jaldi jeeta? Zyada aasan tha?
- Isse boss ka aggression level set hota hai.

## Data Structure (Lightweight)

```dart
class BossLearningBrain {
  // Sirf 5 records ka chhota array
  List<Map<String, dynamic>> last5FightRecords = [];

  void recordPlayerWinningStrategy(String finalMove, String weaponUsed) {
    if (last5FightRecords.length >= 5) {
      last5FightRecords.removeAt(0); // Sabse purana delete
    }
    last5FightRecords.add({
      "winningMove": finalMove,
      "playerWeapon": weaponUsed,
      "timestamp": DateTime.now(),
    });
  }
}
```

## Analysis Functions

| Function | Output |
|----------|--------|
| `analyzeTopWeapon()` | "Bow" / "Sword" / "Claws" |
| `analyzeTopSide()` | "Right" / "Left" / "Front" |
| `analyzeWinSpeed()` | "Fast" / "Normal" / "Slow" |
| `analyzeAggression()` | 0.0 – 1.0 |

## 💡 Why It Works

Player ko bilkul nahi pata ki piche algorithm chal raha hai. Use lagega:
*"Bhai, yeh game sach me zinda hai! Jo tareeqa maine pichle level par
lagaya tha, wo is level par kaam hi nahi kar raha. Boss ne meri chaal
samajh li!"*

> Next: [counter-strategy.md](counter-strategy.md) — boss ka jawab.
