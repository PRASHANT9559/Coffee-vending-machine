# Bear — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Fur Color | Brown, Black, White, Red | Brown | 4 |
| Body Size | 1.5–3.5 m | 2.5 m | 21 |
| Claw Size | 0.1–0.4 m | 0.25 m | 7 |
| Mane | None, Short, Long | Long | 3 |
| Eye Color | Random | Black | 24 |
| Roar Pitch | 0.3–0.8 | 0.4 | 6 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**860,321,710,080** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 21 × 7 × 3 × 24 × 6
```

## Example Variants

| Variant | Details |
|---------|---------|
| Cave Bear | Black, 3.5m, 120 HP, territorial |
| Honey Bear | Brown, 2m, friendly after honey |
| Frost Bear | White, 3m, 100 HP, mountain |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
