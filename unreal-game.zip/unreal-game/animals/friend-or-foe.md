# Friend or Foe — Global System

## The Boolean

Har animal ke paas ek runtime flag hota hai:

```cpp
bool is_friend;
```

- `false` → **Foe** (attack mode)
- `true` → **Friend** (help mode)

## Foe — Player Health Down

Damage formula:

```
Damage_Per_Hit = Base_Damage × Size_Scale × (1 + Level / 1000)
Player_Health -= Damage_Per_Hit
```

| Tier | Base Damage | Example |
|------|-------------|---------|
| Small | 5 HP | Frog, crab, shrimp |
| Medium | 15 HP | Snake, dog, octopus |
| Large | 40 HP | Tiger, shark, crocodile |
| Boss | 80 HP | Banshee, whale, thanator |

Status effects:

| Effect | Result |
|--------|--------|
| Poison | Health drain over time |
| Bleed | Damage over time |
| Stun | Player can't move 1–2s |
| Knockback | Player pushed back |

## Friend — Player Ko Kya Milta Hai?

| Benefit | Example |
|---------|---------|
| Resource | Meat, DNA, scale |
| Pet | Dog, tiger, eagle |
| Guide | Night glow snake, dolphin |
| Mount | Banshee, direhorse, turtle |
| Buff | Strength, speed, defense |
| Crafting help | Ape, turtle shell |

## How To Become Friend

1. **Feed** — fruit/meat/fish 3x.
2. **Rescue** — trap/net se free karo.
3. **Quest** — species-specific bonding ritual.
4. **Trust meter** — 0–100; 100 par friend.

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Avoid / feed
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Betrayal Rule

Agar player friend animal par attack kare:

```
is_friend = false
trust = 0
mode = "Hostile"
```

## Per-Animal Table

| Animal | Default | Foe Damage | Friend Benefit |
|--------|---------|------------|----------------|
| 🐍 Snake | False (aggressive spawn) | 8–45 HP per bite | Night guide, venom antidote, rare fruit tracking |
| 🐊 Crocodile | False (aggressive) | 25–70 HP per bite | Armored scale, water ambush warning |
| 🐅 Tiger | False (aggressive) | 30–80 HP per claw | Combat pet, +50% attack assist |
| 🐆 Cheetah | False (fast) | 20–60 HP per bite | Speed pet, +150% travel speed |
| 🐻 Bear | False (aggressive) | 40–90 HP per swipe | Heavy armor material, strength buff |
| 🐕 Dog | True (friendly) | 5–20 HP (if betrayed) | Scent tracking, danger alert, pet |
| 🦅 Eagle | True (neutral) | 10–30 HP per talon | Aerial scout, mini-radar |
| 🦇 Banshee | False (wild) | 50–120 HP per dive | Flight mount, fast travel |
| 🦈 Shark | False (aggressive) | 35–90 HP per bite | Shark tooth weapon, sea danger warning |
| 🐬 Dolphin | True (friendly) | 10–25 HP (if provoked) | Swim boost, shark repellent, guidance |
| 🐢 Turtle | True (passive) | 3–10 HP (if provoked) | Ride/swim, shell shield |
| 🐸 Frog | False (aggressive) | 5–15 HP + poison | Poison antidote ingredient, jump boost |
| 🦀 Crab | False (aggressive) | 2–8 HP | Food +50 HP when cooked |
| 🦞 Lobster | False (aggressive) | 3–10 HP | Food +50 HP |
| 🦐 Shrimp | True (passive) | 1–3 HP | Food +20 HP |
| 🐙 Octopus | False (aggressive) | 15–40 HP + ink | Ink bomb, camouflage ability |
| 🦑 Squid | False (aggressive) | 20–50 HP + shock | Bioluminescent ink, electric weapon |
| 🐋 Whale | True (neutral) | 60–120 HP (if provoked) | Safe travel, scale wow moment, Tulkun bond |
| 🐡 Pufferfish | False (aggressive) | 10–25 HP + poison | Poison sac, defense orb |
| ⚡ Electric Eel | False (aggressive) | 25–60 HP + shock | Electric weapon core |
| 🦧 Ape | False (aggressive) | 15–40 HP | Strength buff, tool crafting help |
| 🐴 Direhorse | False (wild) | 30–70 HP | Fast land mount |
| 🐾 Thanator | False (aggressive) | 80–150 HP | Legendary DNA, apex trophy |

## Related

- [README.md](README.md)
- [damage-system.md](damage-system.md)
