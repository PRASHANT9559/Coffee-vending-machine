# Animals — Workflow

Animal spawn hone se friend/foe interaction tak ka flow.

```mermaid
flowchart TD
    A["Level start"] --> B["Zone select"]
    B --> C["Random animal type"]
    C --> D["Generate parts<br/>color, size, body"]
    D --> E{"is_friend roll"}
    E -->|false| F["Foe: attack mode"]
    E -->|true| G["Friend: help mode"]
    F --> H["Player fight / flee"]
    G --> I["Player feed / interact"]
    H --> J{"Player wins?"}
    J -->|Yes| K["Kill → loot + DNA"]
    J -->|No| L["Player health 0 → respawn"]
    I --> M["Trust meter"]
    M --> N{"Trust 100%?"}
    N -->|Yes| O["Pet / permanent benefit"]
    N -->|No| I
```

## Decision Rule

```
is_friend = RandomBool(0.5)   // spawn par roll
if (is_friend == false) {
    animal.mode = "Foe";
    animal.attack(player);
} else {
    animal.mode = "Friend";
    animal.giveBenefit(player);
}
```

## Foe vs Friend

| Mode | Player Experience |
|------|-------------------|
| **Foe** | Attack, poison, health down, loot on kill |
| **Friend** | Feed, tame, guide, resource, pet |

## Related

- [README.md](README.md)
- [friend-or-foe.md](friend-or-foe.md)
- [damage-system.md](damage-system.md)
