# 🦇 Banshee

> **Category:** Air / Mount · **Zone:** Floating Mountain, Sky · **Tier:** boss

## Overview

Banshee ek **Air / Mount** animal hai jo **Floating Mountain, Sky** me milta hai.
Iska main ability **Flight / dive** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Air / Mount |
| Zone | Floating Mountain, Sky |
| Tier | boss |
| Rarity | Epic–Legendary |
| Tameable | True |
| Default Friend? | False (wild) |
| Damage (foe) | 50–120 HP per dive |
| Friend Benefit | Flight mount, fast travel |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Mountain Banshee | Blue, 8m, wild, 120 HP |
| Neon Banshee | Neon, 10m, tameable, glow |
| Shadow Banshee | Black, 12m, legendary, scream |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
