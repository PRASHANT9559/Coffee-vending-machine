# Banshee — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Wingspan | 4–12 m | 8 m | 81 |
| Skin Color | Blue, Purple, Black, Neon | Blue | 4 |
| Horn Style | None, Curved, Crown | Curved | 3 |
| Tail Type | Long, Spiked, Split | Long | 3 |
| Eye Glow | True/False | True | 2 |
| Flight Style | Soar, Dive, Hover | Dive | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**59,256,852,480** unique combinations per spawn.

Formula:

```
3,386,880 × 81 × 4 × 3 × 3 × 2 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Mountain Banshee | Blue, 8m, wild, 120 HP |
| Neon Banshee | Neon, 10m, tameable, glow |
| Shadow Banshee | Black, 12m, legendary, scream |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
