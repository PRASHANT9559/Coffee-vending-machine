# Banshee — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Banshee DNA | 80% | Beastman upgrade |
| Wing Membrane | 50% | Crafting / trade |
| Crystal | 30% | Crafting / trade |
| Feather | 20% | Crafting / trade |

## DNA

Banshee DNA → glide / flight upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
