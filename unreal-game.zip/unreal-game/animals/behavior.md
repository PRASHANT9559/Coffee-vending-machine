# Animal Behavior System

## Behavior States

| State | Meaning | Player Experience |
|-------|---------|-------------------|
| **Aggressive** | Dekhte hi attack | Bhaago ya lado |
| **Passive / Friendly** | Hamla nahi karega | Feed karo → dost banega |
| **Scared** | Player dekh kar bhaag jayega | Shikar karna mushkil |

## Dynamic Behavior (Kabhi Dushman, Kabhi Dost)

Har spawn par `Behavior_State` random:

- Level 450: Snake bada + gusse me → khatra.
- Level 451: Snake chhota + dost → guide karega.

Player ko door se dekh kar sochna padega: *"Yeh snake is baar gusse me
hai ya mood accha hai?"*

## The Helper State

- Friendly animal ko fruit (apple/mango) offer karo.
- Wo aapka dost ban jayega.
- Peeth par baithakar island ghuma sakta hai.
- Floating mountains tak pahunchne me help karega.

## Predator vs Prey

- Sirf player ko khatra nahi.
- Raste me bada bird snake ko utha kar le ja sakta hai.
- Isse duniya **zinda** lagti hai.

## Night Behavior

- Raat hote hi snakes aur predators **hunting mode** me.
- Aggression + speed badh jati hai.
- Bioluminescent animals raat me dikhte hain.

## Behavior Backend

```dart
// 0 = Friendly, 1 = Aggressive, 2 = Scared
targetObject.behaviorMode = randomRange(0, 2, levelSeed);

// Scale bhi random
targetObject.visualScale = randomFloatRange(0.2, 5.0, levelSeed);
```

## Poison System

| Type | Effect |
|------|--------|
| `None` | Normal |
| `Nerve_Damage` | Screen dhundli |
| `Slow_Motion` | Player slow ho jata hai |

## 💡 Design Tip

Behavior ko player ki strategy ke hisaab se bhi badlo (Adaptive AI) —
jo animal zyada maara gaya, wo agle level par zyada aggressive ho.

## Related

- [README.md](README.md) — all animals
- [friend-or-foe.md](friend-or-foe.md) — `is_friend` boolean, damage/benefit
- [damage-system.md](damage-system.md) — health formula
- [sea.md](sea.md) — sea animals
- [land.md](land.md) — land animals
