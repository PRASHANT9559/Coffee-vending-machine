# Dolphin — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Body Length | 1.5–3 m | 2.2 m | 16 |
| Skin Color | Grey, Blue, Pink, White | Grey | 4 |
| Snout Shape | Short, Long, Rounded | Long | 3 |
| Fin Size | Small, Medium, Large | Medium | 3 |
| Eye Color | Random | Black | 24 |
| Jump Height | 1–5 m | 3 m | 41 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**1,919,629,393,920** unique combinations per spawn.

Formula:

```
3,386,880 × 16 × 4 × 3 × 3 × 24 × 41
```

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Dolphin | Grey, 2m, friendly, guide |
| Pink River Dolphin | Pink, 1.5m, rare, sonar |
| Storm Dolphin | Blue, 3m, fast swim |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
