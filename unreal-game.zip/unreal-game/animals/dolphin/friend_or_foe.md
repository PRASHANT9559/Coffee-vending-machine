# Dolphin — Friend or Foe?

## The Boolean

Har spawned Dolphin ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **True (friendly)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 10–25 HP (if provoked) |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | N/A (friendly) |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- N/A (friendly) use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Swim Boost | Swim boost, shark repellent, guidance |
| Trust reward | Dolphin DNA → swim / sonar upgrade |
| Companion? | True |

**Friend kaise banayein:**
1. Play / feed fish
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Swim Boost
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Swim / sonar
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
