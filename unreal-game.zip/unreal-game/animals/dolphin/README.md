# 🐬 Dolphin

> **Category:** Sea / Companion · **Zone:** Shallow Water, Mid Water · **Tier:** medium

## Overview

Dolphin ek **Sea / Companion** animal hai jo **Shallow Water, Mid Water** me milta hai.
Iska main ability **Swim / sonar** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Companion |
| Zone | Shallow Water, Mid Water |
| Tier | medium |
| Rarity | Rare–Epic |
| Tameable | True |
| Default Friend? | True (friendly) |
| Damage (foe) | 10–25 HP (if provoked) |
| Friend Benefit | Swim boost, shark repellent, guidance |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Dolphin | Grey, 2m, friendly, guide |
| Pink River Dolphin | Pink, 1.5m, rare, sonar |
| Storm Dolphin | Blue, 3m, fast swim |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
