# Dolphin — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Dolphin DNA | 60% | Beastman upgrade |
| Fin | 30% | Weapon craft |
| Meat | 20% | Food / health |

## DNA

Dolphin DNA → swim / sonar upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
