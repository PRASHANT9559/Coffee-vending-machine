# Whale — Workflow

Spawn se le kar friend/foe outcome tak ka flow.

```mermaid
flowchart TD
    A["Level start"] --> B["Zone: Deep Ocean"]
    B --> C["Spawn Whale"]
    C --> D["Roll random parts<br/>colour, size, body"]
    D --> E{"is_friend?"}
    E -->|false| F["Foe mode"]
    E -->|true| G["Friend mode"]
    F --> H["Attack player<br/>60–120 HP (if provoked)"]
    H --> I{"Player health > 0?"}
    I -->|Yes| J["Fight / flee"]
    I -->|No| K["Death scene → respawn"]
    J --> L["Kill → loot + DNA"]
    G --> M["Give benefit<br/>Safe Travel"]
    M --> N["Feed / rescue / quest"]
    N --> O{"Trust 100%?"}
    O -->|Yes| P["Pet / permanent benefit"]
    O -->|No| N
```

## Step by Step

| Step | Kya hota hai |
|------|--------------|
| 1 | Zone select (Deep Ocean) |
| 2 | `Whale` spawn hota hai |
| 3 | Random parts generate hote hain |
| 4 | `is_friend` roll hota hai |
| 5 | Foe → attack, Friend → benefit |
| 6 | Player fight/flee ya feed/tame |
| 7 | Outcome: loot, pet, guide, ya death |

## Decision Rule

```cpp
if (!animal.is_friend) {
    animal.attack(player);          // 60–120 HP (if provoked)
} else {
    animal.giveBenefit(player);     // Safe Travel
}
```

## Related

- [README.md](README.md)
- [friend_or_foe.md](friend_or_foe.md)
- [attack.md](attack.md)
- [../workflow.md](../workflow.md)
