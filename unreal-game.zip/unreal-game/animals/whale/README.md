# 🐋 Whale

> **Category:** Sea / Giant · **Zone:** Deep Ocean · **Tier:** boss

## Overview

Whale ek **Sea / Giant** animal hai jo **Deep Ocean** me milta hai.
Iska main ability **Scale / travel** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Giant |
| Zone | Deep Ocean |
| Tier | boss |
| Rarity | Epic–Legendary |
| Tameable | False |
| Default Friend? | True (neutral) |
| Damage (foe) | 60–120 HP (if provoked) |
| Friend Benefit | Safe travel, scale wow moment, Tulkun bond |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Blue Whale | Blue, 25m, neutral |
| Tulkun | Neon, 30m, bond, legendary |
| Storm Whale | Grey, 20m, storm caller |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
