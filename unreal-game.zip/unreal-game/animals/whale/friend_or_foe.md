# Whale — Friend or Foe?

## The Boolean

Har spawned Whale ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **True (neutral)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 60–120 HP (if provoked) |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Avoid / bond |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Avoid / bond use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Safe Travel | Safe travel, scale wow moment, Tulkun bond |
| Trust reward | Whale DNA → oxygen / swim upgrade |
| Companion? | False |

**Friend kaise banayein:**
1. Rescue / sing quest
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Safe Travel
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Scale / travel
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
