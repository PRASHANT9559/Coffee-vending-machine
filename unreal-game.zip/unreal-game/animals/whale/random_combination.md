# Whale — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Body Length | 10–30 m | 20 m | 201 |
| Skin Color | Blue, Grey, White, Neon | Blue | 4 |
| Fin Style | Long, Short, Split | Long | 3 |
| Pattern | Spots, Stripes, Scars, Plain | Spots | 4 |
| Eye Color | Random | Black | 24 |
| Song Pitch | 0.1–1.0 | 0.3 | 10 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**7,842,388,377,600** unique combinations per spawn.

Formula:

```
3,386,880 × 201 × 4 × 3 × 4 × 24 × 10
```

## Example Variants

| Variant | Details |
|---------|---------|
| Blue Whale | Blue, 25m, neutral |
| Tulkun | Neon, 30m, bond, legendary |
| Storm Whale | Grey, 20m, storm caller |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
