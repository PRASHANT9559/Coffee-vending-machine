# Whale — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Whale DNA | 70% | Beastman upgrade |
| Blubber | 50% | Crafting / trade |
| Bone | 30% | Crafting / trade |
| Meat | 20% | Food / health |

## DNA

Whale DNA → oxygen / swim upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
