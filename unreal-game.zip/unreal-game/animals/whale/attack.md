# Whale — Attacks & Damage

## Attack Table

| Attack | Range | Damage | Cooldown | Effect |
|--------|-------|--------|----------|--------|
| Attack | Range | Damage | Cooldown | Effect |
|--------|-------|--------|----------|--------|
| Tail Slam | AoE | 80–90 HP | 1.5s | Heavy knockback |
| Body Ram | Melee | 85–95 HP | 2.0s | Heavy damage |

Damage formula:

```
Damage = Base_Damage × Size_Scale × (1 + Level / 1000)
```

## VR Interaction

| Attack | Player Counter |
|--------|----------------|
| Melee | Shield / dodge |
| Ranged | Strafe / cover |
| AoE | Jump / glide |

## Telegraph

- Attack se pehle animation + sound.
- Red glow = danger.
- 0.5 sec reaction window.

## Related

- [README.md](README.md)
- [friend_or_foe.md](friend_or_foe.md)
- [../damage-system.md](../damage-system.md)
