# Thanator — Workflow

Spawn se le kar friend/foe outcome tak ka flow.

```mermaid
flowchart TD
    A["Level start"] --> B["Zone: Deep Jungle, Cave"]
    B --> C["Spawn Thanator"]
    C --> D["Roll random parts<br/>colour, size, body"]
    D --> E{"is_friend?"}
    E -->|false| F["Foe mode"]
    E -->|true| G["Friend mode"]
    F --> H["Attack player<br/>80–150 HP"]
    H --> I{"Player health > 0?"}
    I -->|Yes| J["Fight / flee"]
    I -->|No| K["Death scene → respawn"]
    J --> L["Kill → loot + DNA"]
    G --> M["Give benefit<br/>Apex Trophy"]
    M --> N["Feed / rescue / quest"]
    N --> O{"Trust 100%?"}
    O -->|Yes| P["Pet / permanent benefit"]
    O -->|No| N
```

## Step by Step

| Step | Kya hota hai |
|------|--------------|
| 1 | Zone select (Deep Jungle, Cave) |
| 2 | `Thanator` spawn hota hai |
| 3 | Random parts generate hote hain |
| 4 | `is_friend` roll hota hai |
| 5 | Foe → attack, Friend → benefit |
| 6 | Player fight/flee ya feed/tame |
| 7 | Outcome: loot, pet, guide, ya death |

## Decision Rule

```cpp
if (!animal.is_friend) {
    animal.attack(player);          // 80–150 HP
} else {
    animal.giveBenefit(player);     // Apex Trophy
}
```

## Related

- [README.md](README.md)
- [friend_or_foe.md](friend_or_foe.md)
- [attack.md](attack.md)
- [../workflow.md](../workflow.md)
