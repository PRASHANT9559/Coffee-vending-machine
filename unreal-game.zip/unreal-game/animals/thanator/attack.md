# Thanator — Attacks & Damage

## Attack Table

| Attack | Range | Damage | Cooldown | Effect |
|--------|-------|--------|----------|--------|
| Attack | Range | Damage | Cooldown | Effect |
|--------|-------|--------|----------|--------|
| Pounce | Melee | 80–90 HP | 1.5s | Knockdown |
| Claw | Melee | 85–95 HP | 2.0s | Bleed 40% |
| Roar | AoE | 90–100 HP | 2.5s | Fear 40% |
| Tail | Melee | 95–105 HP | 3.0s | Knockback |

Damage formula:

```
Damage = Base_Damage × Size_Scale × (1 + Level / 1000)
```

## VR Interaction

| Attack | Player Counter |
|--------|----------------|
| Melee | Shield / dodge |
| Ranged | Strafe / cover |
| AoE | Jump / glide |

## Telegraph

- Attack se pehle animation + sound.
- Red glow = danger.
- 0.5 sec reaction window.

## Related

- [README.md](README.md)
- [friend_or_foe.md](friend_or_foe.md)
- [../damage-system.md](../damage-system.md)
