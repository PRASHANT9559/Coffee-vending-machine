# Thanator — Friend or Foe?

## The Boolean

Har spawned Thanator ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (aggressive)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 80–150 HP |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Traps, high ground, pet assist |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Traps, high ground, pet assist use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Apex Trophy | Legendary DNA, apex trophy |
| Trust reward | Thanator DNA → apex combat upgrade |
| Companion? | False |

**Friend kaise banayein:**
1. N/A (apex predator)
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Apex Trophy
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Apex combat
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
