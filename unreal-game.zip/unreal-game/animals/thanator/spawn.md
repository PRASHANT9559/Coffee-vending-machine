# Thanator — Spawn Rules

## Zone

Deep Jungle, Cave

## Level Range

1–10,000

## Rarity

Legendary

## Spawn Count

```
Count = Random(1, 5) + (Level / 2000)
```

## Day / Night

| Time | Behavior |
|------|----------|
| Day | Territorial |
| Night | Apex hunt |

## Weather

- Storm → spawn chance +20%
- Fog → visibility down
- Clear → normal

## Despawn

- Player > 50m → de-spawn
- Max Draw Distance = 5000

## Related

- [README.md](README.md)
- [../workflow.md](../workflow.md)
