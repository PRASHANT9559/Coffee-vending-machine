# Thanator — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Body Length | 4–8 m | 6 m | 41 |
| Skin Color | Black, Red, Purple, Camo | Black | 4 |
| Armor Plates | 0–5 | 4 | 6 |
| Claw Size | 0.3–0.8 m | 0.5 m | 6 |
| Eye Glow | True/False | True | 2 |
| Tail Style | Long, Spiked, Split | Spiked | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**119,976,837,120** unique combinations per spawn.

Formula:

```
3,386,880 × 41 × 4 × 6 × 6 × 2 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Jungle Thanator | Black, 6m, 150 HP, apex |
| Cave Thanator | Purple, 5m, ambush |
| Alpha Thanator | Red, 8m, legendary, roar |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
