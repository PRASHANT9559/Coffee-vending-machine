# 🐾 Thanator

> **Category:** Land / Boss · **Zone:** Deep Jungle, Cave · **Tier:** boss

## Overview

Thanator ek **Land / Boss** animal hai jo **Deep Jungle, Cave** me milta hai.
Iska main ability **Apex combat** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Land / Boss |
| Zone | Deep Jungle, Cave |
| Tier | boss |
| Rarity | Legendary |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 80–150 HP |
| Friend Benefit | Legendary DNA, apex trophy |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Jungle Thanator | Black, 6m, 150 HP, apex |
| Cave Thanator | Purple, 5m, ambush |
| Alpha Thanator | Red, 8m, legendary, roar |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
