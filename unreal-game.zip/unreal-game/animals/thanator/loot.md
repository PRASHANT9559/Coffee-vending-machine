# Thanator — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Thanator DNA | 90% | Beastman upgrade |
| Apex Claw | 60% | Weapon craft |
| Hide | 40% | Armor / cosmetic |
| Meat | 20% | Food / health |

## DNA

Thanator DNA → apex combat upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
