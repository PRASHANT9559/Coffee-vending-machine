# Tiger — Friend or Foe?

## The Boolean

Har spawned Tiger ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (aggressive)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 30–80 HP per claw |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Shield, dodge, pet assist |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Shield, dodge, pet assist use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Combat Pet | Combat pet, +50% attack assist |
| Trust reward | Tiger DNA → claws / attack upgrade |
| Companion? | True |

**Friend kaise banayein:**
1. Feed meat 5x / wounded tiger ko heal karo
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Combat Pet
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Combat / pounce
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
