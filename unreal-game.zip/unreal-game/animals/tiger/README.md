# 🐅 Tiger

> **Category:** Predator / Land · **Zone:** Forest, Jungle, Floating Mountain · **Tier:** large

## Overview

Tiger ek **Predator / Land** animal hai jo **Forest, Jungle, Floating Mountain** me milta hai.
Iska main ability **Combat / pounce** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Predator / Land |
| Zone | Forest, Jungle, Floating Mountain |
| Tier | large |
| Rarity | Rare–Legendary |
| Tameable | True |
| Default Friend? | False (aggressive) |
| Damage (foe) | 30–80 HP per claw |
| Friend Benefit | Combat pet, +50% attack assist |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Bengal Hunter | Stripes, 2.5m, 70 HP, aggressive |
| White Guardian | Solid white, 3m, friendly, combat pet |
| Shadow Tiger | Black, 4m, 90 HP, night ambush |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
