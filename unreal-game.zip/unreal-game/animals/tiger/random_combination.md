# Tiger — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Fur Pattern | Stripes, Spots, Solid | Stripes | 3 |
| Mane | None, Short, Long | Short | 3 |
| Claw Size | 0.1–0.5 m | 0.3 m | 9 |
| Body Length | 1.5–4 m | 2.5 m | 26 |
| Eye Color | Random glow | Amber | 24 |
| Roar Pitch | 0.3–1.0 | 0.5 | 8 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**1,369,491,701,760** unique combinations per spawn.

Formula:

```
3,386,880 × 3 × 3 × 9 × 26 × 24 × 8
```

## Example Variants

| Variant | Details |
|---------|---------|
| Bengal Hunter | Stripes, 2.5m, 70 HP, aggressive |
| White Guardian | Solid white, 3m, friendly, combat pet |
| Shadow Tiger | Black, 4m, 90 HP, night ambush |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
