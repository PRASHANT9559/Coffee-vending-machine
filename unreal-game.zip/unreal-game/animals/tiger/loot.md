# Tiger — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Meat | 100% | Food / health |
| Tiger DNA | 70% | Beastman upgrade |
| Fur | 40% | Armor / cosmetic |
| Claw | 20% | Weapon craft |

## DNA

Tiger DNA → claws / attack upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
