# 🦀 Crab

> **Category:** Sea / Small · **Zone:** Beach, Shallow Water · **Tier:** small

## Overview

Crab ek **Sea / Small** animal hai jo **Beach, Shallow Water** me milta hai.
Iska main ability **Pinch / armor** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Small |
| Zone | Beach, Shallow Water |
| Tier | small |
| Rarity | Common |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 2–8 HP |
| Friend Benefit | Food +50 HP when cooked |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Beach Crab | Red, 0.25m, passive |
| Blue Crab | Blue, 0.3m, fast |
| Giant Crab | Orange, 0.5m, 20 HP, pinch |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
