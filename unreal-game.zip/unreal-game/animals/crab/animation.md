# Crab — Animation & Audio

## Animation States

| State | Trigger |
|-------|---------|
| Idle | No player nearby |
| Patrol | Spawn zone |
| Attack | Player in range |
| Hurt | Health down |
| Death | Health 0 |
| Friendly | `is_friend = true` |

## Sound

- Click / scuttle
- Footstep / movement
- Attack telegraph

## VFX

- Sand + bubbles
- Hit spark
- Death dissolve

## VR Haptics

| Event | Haptic |
|-------|--------|
| Attack hit | Strong pulse |
| Nearby | Light rumble |
| Death | Fade |

## Related

- [README.md](README.md)
- [attack.md](attack.md)
