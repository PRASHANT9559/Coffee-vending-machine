# Crocodile — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Jaw Length | 0.5–2.0 m | 1.2 m | 16 |
| Bite Force | 100–5000 N | 2500 N | 50 |
| Armor Plates | 0–5 | 3 | 6 |
| Tail Spikes | 0–4 | 2 | 5 |
| Body Length | 2–8 m | 5 m | 61 |
| Eye Color | Random palette | Amber | 24 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**119,001,415,680,000** unique combinations per spawn.

Formula:

```
3,386,880 × 16 × 50 × 6 × 5 × 61 × 24
```

## Example Variants

| Variant | Details |
|---------|---------|
| Swamp Ambusher | 5m, 3 armor plates, 70 HP, bleed |
| River Brute | 8m, 5 armor plates, 90 HP, death roll |
| Baby Croc | 2m, 0 armor, 15 HP, passive |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
