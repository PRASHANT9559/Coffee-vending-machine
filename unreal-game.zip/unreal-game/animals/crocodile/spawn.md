# Crocodile — Spawn Rules

## Zone

River, Swamp, Shallow Water

## Level Range

1–10,000

## Rarity

Common–Epic

## Spawn Count

```
Count = Random(1, 5) + (Level / 2000)
```

## Day / Night

| Time | Behavior |
|------|----------|
| Day | Basking on shore |
| Night | Ambush in water |

## Weather

- Storm → spawn chance +20%
- Fog → visibility down
- Clear → normal

## Despawn

- Player > 50m → de-spawn
- Max Draw Distance = 5000

## Related

- [README.md](README.md)
- [../workflow.md](../workflow.md)
