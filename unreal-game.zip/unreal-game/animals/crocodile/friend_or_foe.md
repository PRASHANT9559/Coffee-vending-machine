# Crocodile — Friend or Foe?

## The Boolean

Har spawned Crocodile ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (aggressive)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 25–70 HP per bite |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Shield, spear, stay away from water |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Shield, spear, stay away from water use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Armored Scale | Armored scale, water ambush warning |
| Trust reward | Crocodile DNA → armor / defense upgrade |
| Companion? | False |

**Friend kaise banayein:**
1. Feed fish / rescue from net
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Armored Scale
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Armor / ambush
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
