# 🐊 Crocodile

> **Category:** Reptile / Water · **Zone:** River, Swamp, Shallow Water · **Tier:** large

## Overview

Crocodile ek **Reptile / Water** animal hai jo **River, Swamp, Shallow Water** me milta hai.
Iska main ability **Armor / ambush** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Reptile / Water |
| Zone | River, Swamp, Shallow Water |
| Tier | large |
| Rarity | Common–Epic |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 25–70 HP per bite |
| Friend Benefit | Armored scale, water ambush warning |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Swamp Ambusher | 5m, 3 armor plates, 70 HP, bleed |
| River Brute | 8m, 5 armor plates, 90 HP, death roll |
| Baby Croc | 2m, 0 armor, 15 HP, passive |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
