# Crocodile — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Meat | 100% | Food / health |
| Croc DNA | 60% | Beastman upgrade |
| Armored Scale | 35% | Armor / cosmetic |
| Tooth | 15% | Weapon craft |

## DNA

Crocodile DNA → armor / defense upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
