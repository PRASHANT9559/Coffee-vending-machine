# Electric Eel — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Body Length | 1–5 m | 3 m | 41 |
| Skin Color | Grey, Blue, Black, Neon | Grey | 4 |
| Voltage | 100–2000 V | 800 V | 20 |
| Fin Style | Long, Short, None | Long | 3 |
| Eye Style | Normal, Glow | Glow | 2 |
| Pattern | Spots, Stripes, Plain | Plain | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**199,961,395,200** unique combinations per spawn.

Formula:

```
3,386,880 × 41 × 4 × 20 × 3 × 2 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Cave Eel | Grey, 3m, shock, 60 HP |
| Neon Eel | Neon, 2m, glow, legendary |
| Giant Eel | Black, 5m, 90 HP |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
