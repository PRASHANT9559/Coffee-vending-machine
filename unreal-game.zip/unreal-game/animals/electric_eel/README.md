# ⚡ Electric Eel

> **Category:** Sea / Hazard · **Zone:** Deep Ocean, Cave · **Tier:** medium

## Overview

Electric Eel ek **Sea / Hazard** animal hai jo **Deep Ocean, Cave** me milta hai.
Iska main ability **Electric / stun** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Hazard |
| Zone | Deep Ocean, Cave |
| Tier | medium |
| Rarity | Rare–Epic |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 25–60 HP + shock |
| Friend Benefit | Electric weapon core |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Cave Eel | Grey, 3m, shock, 60 HP |
| Neon Eel | Neon, 2m, glow, legendary |
| Giant Eel | Black, 5m, 90 HP |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
