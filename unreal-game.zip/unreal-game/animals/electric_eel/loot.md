# Electric Eel — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Eel DNA | 65% | Beastman upgrade |
| Electric Organ | 45% | Crafting / trade |
| Meat | 25% | Food / health |

## DNA

Electric Eel DNA → electric weapon upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
