# Electric Eel — Spawn Rules

## Zone

Deep Ocean, Cave

## Level Range

1–10,000

## Rarity

Rare–Epic

## Spawn Count

```
Count = Random(1, 5) + (Level / 2000)
```

## Day / Night

| Time | Behavior |
|------|----------|
| Day | Cave hide |
| Night | Hunt |

## Weather

- Storm → spawn chance +20%
- Fog → visibility down
- Clear → normal

## Despawn

- Player > 50m → de-spawn
- Max Draw Distance = 5000

## Related

- [README.md](README.md)
- [../workflow.md](../workflow.md)
