# Octopus — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Skin Color | Red, Purple, Blue, Camo | Purple | 4 |
| Tentacle Count | 6, 8, 10 | 8 | 3 |
| Tentacle Length | 0.5–3 m | 1.5 m | 26 |
| Body Size | 0.3–2 m | 0.8 m | 18 |
| Eye Style | Normal, Slit, Glow | Slit | 3 |
| Camouflage | True/False | True | 2 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**114,124,308,480** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 3 × 26 × 18 × 3 × 2
```

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Octopus | Red, 0.5m, camouflage |
| Giant Octopus | Purple, 2m, 60 HP, grab |
| Glow Octopus | Neon, 1m, deep sea, ink |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
