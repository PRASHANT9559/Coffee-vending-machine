# 🐙 Octopus

> **Category:** Sea / Predator · **Zone:** Deep Ocean, Cave · **Tier:** medium

## Overview

Octopus ek **Sea / Predator** animal hai jo **Deep Ocean, Cave** me milta hai.
Iska main ability **Camouflage / grab** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Predator |
| Zone | Deep Ocean, Cave |
| Tier | medium |
| Rarity | Rare–Epic |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 15–40 HP + ink |
| Friend Benefit | Ink bomb, camouflage ability |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Octopus | Red, 0.5m, camouflage |
| Giant Octopus | Purple, 2m, 60 HP, grab |
| Glow Octopus | Neon, 1m, deep sea, ink |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
