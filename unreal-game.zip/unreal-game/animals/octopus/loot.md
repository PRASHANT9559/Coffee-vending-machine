# Octopus — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Octopus DNA | 60% | Beastman upgrade |
| Ink Sac | 40% | Crafting / trade |
| Meat | 30% | Food / health |

## DNA

Octopus DNA → camouflage / tentacle upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
