# Shrimp — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Shell Color | Pink, Red, Transparent, Blue | Pink | 4 |
| Body Size | 0.02–0.2 m | 0.08 m | 10 |
| Antenna Length | Short, Medium, Long | Long | 3 |
| Tail Style | Fan, Spike, Normal | Fan | 3 |
| Eye Style | Stalk, Normal | Stalk | 2 |
| Pattern | Spots, Stripes, Plain | Plain | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**7,315,660,800** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 10 × 3 × 3 × 2 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Pink Shrimp | Pink, 0.08m, food |
| Glass Shrimp | Transparent, 0.05m, stealth |
| Tiger Shrimp | Striped, 0.2m, fast |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
