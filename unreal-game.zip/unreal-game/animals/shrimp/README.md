# 🦐 Shrimp

> **Category:** Sea / Small · **Zone:** Shallow Water · **Tier:** small

## Overview

Shrimp ek **Sea / Small** animal hai jo **Shallow Water** me milta hai.
Iska main ability **Speed / camouflage** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Small |
| Zone | Shallow Water |
| Tier | small |
| Rarity | Common |
| Tameable | False |
| Default Friend? | True (passive) |
| Damage (foe) | 1–3 HP |
| Friend Benefit | Food +20 HP |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Pink Shrimp | Pink, 0.08m, food |
| Glass Shrimp | Transparent, 0.05m, stealth |
| Tiger Shrimp | Striped, 0.2m, fast |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
