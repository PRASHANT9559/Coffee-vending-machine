# Direhorse — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Body Length | 2–4 m | 3 m | 21 |
| Coat Color | Brown, Black, White, Blue | Brown | 4 |
| Pattern | Stripes, Spots, Plain | Stripes | 3 |
| Leg Style | Long, Short, Armored | Long | 3 |
| Eye Color | Random | Black | 24 |
| Speed | 40–80 km/h | 60 km/h | 41 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**2,519,513,579,520** unique combinations per spawn.

Formula:

```
3,386,880 × 21 × 4 × 3 × 3 × 24 × 41
```

## Example Variants

| Variant | Details |
|---------|---------|
| Plains Runner | Brown, 3m, mount |
| Night Direhorse | Black, 3.5m, fast |
| Armored Direhorse | Blue, 4m, rare, tank |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
