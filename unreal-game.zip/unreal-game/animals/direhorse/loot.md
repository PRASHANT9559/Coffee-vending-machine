# Direhorse — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Direhorse DNA | 60% | Beastman upgrade |
| Hide | 45% | Armor / cosmetic |
| Meat | 30% | Food / health |

## DNA

Direhorse DNA → mount / speed upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
