# 🐴 Direhorse

> **Category:** Land / Mount · **Zone:** Plains, Forest · **Tier:** large

## Overview

Direhorse ek **Land / Mount** animal hai jo **Plains, Forest** me milta hai.
Iska main ability **Mount / charge** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Land / Mount |
| Zone | Plains, Forest |
| Tier | large |
| Rarity | Rare–Epic |
| Tameable | True |
| Default Friend? | False (wild) |
| Damage (foe) | 30–70 HP |
| Friend Benefit | Fast land mount |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Plains Runner | Brown, 3m, mount |
| Night Direhorse | Black, 3.5m, fast |
| Armored Direhorse | Blue, 4m, rare, tank |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
