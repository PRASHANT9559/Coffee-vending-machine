# Direhorse — Friend or Foe?

## The Boolean

Har spawned Direhorse ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (wild)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 30–70 HP |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Spear, caltrops |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Spear, caltrops use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Land Mount | Fast land mount |
| Trust reward | Direhorse DNA → mount / speed upgrade |
| Companion? | True |

**Friend kaise banayein:**
1. Bonding ritual / feed fruit
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Land Mount
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Mount / charge
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
