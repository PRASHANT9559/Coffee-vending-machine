# 🐆 Cheetah

> **Category:** Predator / Land · **Zone:** Savanna, Forest, Floating Mountain · **Tier:** large

## Overview

Cheetah ek **Predator / Land** animal hai jo **Savanna, Forest, Floating Mountain** me milta hai.
Iska main ability **Speed / chase** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Predator / Land |
| Zone | Savanna, Forest, Floating Mountain |
| Tier | large |
| Rarity | Rare–Epic |
| Tameable | True |
| Default Friend? | False (fast) |
| Damage (foe) | 20–60 HP per bite |
| Friend Benefit | Speed pet, +150% travel speed |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Savanna Sprinter | Spots, 1.8m, 45 HP, fast |
| Night Runner | Black spots, 2.2m, 60 HP, night |
| Friendly Racer | Solid, 1.5m, speed pet, +150% |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
