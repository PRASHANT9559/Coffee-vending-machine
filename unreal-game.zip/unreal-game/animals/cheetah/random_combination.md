# Cheetah — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Fur Pattern | Spots, Stripes, Solid | Spots | 3 |
| Claw Size | 0.1–0.4 m | 0.2 m | 7 |
| Body Length | 1–2.5 m | 1.8 m | 16 |
| Eye Color | Random | Amber | 24 |
| Tail Style | Long, Short, Tufted | Long | 3 |
| Sprint Speed | 60–120 km/h | 100 km/h | 61 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**4,998,059,458,560** unique combinations per spawn.

Formula:

```
3,386,880 × 3 × 7 × 16 × 24 × 3 × 61
```

## Example Variants

| Variant | Details |
|---------|---------|
| Savanna Sprinter | Spots, 1.8m, 45 HP, fast |
| Night Runner | Black spots, 2.2m, 60 HP, night |
| Friendly Racer | Solid, 1.5m, speed pet, +150% |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
