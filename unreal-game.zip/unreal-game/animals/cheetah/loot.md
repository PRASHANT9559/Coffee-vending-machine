# Cheetah — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Meat | 100% | Food / health |
| Cheetah DNA | 65% | Beastman upgrade |
| Fur | 40% | Armor / cosmetic |
| Claw | 15% | Weapon craft |

## DNA

Cheetah DNA → speed / jump upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
