# Cheetah — Friend or Foe?

## The Boolean

Har spawned Cheetah ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (fast)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 20–60 HP per bite |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Traps, high ground, shield |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Traps, high ground, shield use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Speed Pet | Speed pet, +150% travel speed |
| Trust reward | Cheetah DNA → speed / jump upgrade |
| Companion? | True |

**Friend kaise banayein:**
1. Feed meat / race quest jeeto
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Speed Pet
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Speed / chase
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
