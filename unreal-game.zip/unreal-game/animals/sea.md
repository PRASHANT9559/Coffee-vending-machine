# Sea Animals (Avatar 2 Style)

Samundar ki duniya Avatar: The Way of Water se inspired hai. Har animal
ka apna zone aur behaviour hai.

## Shallow Water (Kinare Par)

| Animal | Behavior | Gameplay | Deep Dive |
|--------|----------|----------|-----------|
| 🐢 Sea Turtle | Friendly | Peeche pakad kar player paani me tair sakta hai | [turtle](turtle/README.md) |
| 🐸 Frog | Neutral/Poisonous | Kinare ke swamp me, ho sakta hai poisonous ho | [frog](frog/README.md) |
| 🦀 Crab | Passive | Pattharon ke paas, pakakar khane se health + | [crab](crab/README.md) |
| 🦞 Lobster | Passive | Kinare ke pattharon ke paas | [lobster](lobster/README.md) |
| 🦐 Shrimp | Passive | Chhota, food source | [shrimp](shrimp/README.md) |

> Kinare ke crabs/lobster/shrimp paka kar khane se **health +50**.

## Mid-Water (Beech Ka Samundar)

| Animal | Behavior | Gameplay | Deep Dive |
|--------|----------|----------|-----------|
| 🐬 Dolphin | Friendly | Player ke saath khelega, shark se bachayega | [dolphin](dolphin/README.md) |
| 🐟 Normal Fish | Passive | Food | — |
| 🐠 Tropical Fish | Passive | Decorative + food | — |
| 🐡 Puffer Fish | Dangerous | Chhune par poison, health kam | [pufferfish](pufferfish/README.md) |

## Deep Ocean (Gehra Samundar — Dangerous)

| Animal | Behavior | Gameplay | Deep Dive |
|--------|----------|----------|-----------|
| 🦈 Shark | Aggressive | Dekhte hi peeche padegi | [shark](shark/README.md) |
| 🐋🐳 Whales / Tulkun | Neutral/Giant | Visual scale ka anubhav | [whale](whale/README.md) |
| 🦑 Squid | Aggressive | Deep sea, bioluminescent ho sakta hai | [squid](squid/README.md) |
| 🐙 Octopus | Aggressive | Andhere me milta hai, neon glow | [octopus](octopus/README.md) |
| ⚡ Electric Eel | Aggressive | Nautilus mission ka guard | [electric_eel](electric_eel/README.md) |

## Ecosystem Rules

- Deep ocean me player ko **flashlight/light** chahiye.
- Whale/Tulkun ke paas jaane par scale ka wow moment.
- Shark ko dolphin door bhagata hai.
- Puffer fish ko galti se chhuna = poison effect.

## Spawn Logic

```
If (Zone == "Shallow_Water") -> [🐢, 🐸, 🦀, 🦞, 🦐]
If (Zone == "Mid_Water")     -> [🐬, 🐟, 🐠, 🐡]
If (Zone == "Deep_Ocean")    -> [🦈, 🐋, 🐳, 🦑, 🐙]
```

## Related

- [README.md](README.md) — all animals
- [land.md](land.md) — land animals
- [behavior.md](behavior.md) — behavior states
- [friend-or-foe.md](friend-or-foe.md) — friend/foe + damage/benefit
- [damage-system.md](damage-system.md) — health formula
