# Snake — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Meat | 100% | Food / health |
| Snake DNA | 60% | Beastman upgrade |
| Venom Sac | 30% | Crafting / trade |
| Scale | 10% | Armor / cosmetic |

## DNA

Snake DNA → venom / stealth upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
