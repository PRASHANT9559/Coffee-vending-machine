# 🐍 Snake

> **Category:** Reptile / Land · **Zone:** Forest, Swamp, Cave, Ruins · **Tier:** medium

## Overview

Snake ek **Reptile / Land** animal hai jo **Forest, Swamp, Cave, Ruins** me milta hai.
Iska main ability **Venom / stealth** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Reptile / Land |
| Zone | Forest, Swamp, Cave, Ruins |
| Tier | medium |
| Rarity | Common–Legendary |
| Tameable | True/False |
| Default Friend? | False (aggressive spawn) |
| Damage (foe) | 8–45 HP per bite |
| Friend Benefit | Night guide, venom antidote, rare fruit tracking |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Cave Predator | Python, Crimson/Black, 8m, Dragon head, Aggressive, 45 HP |
| Glowing Guide | Viper, Neon Pink, 0.8m, Friendly, glow 8.0 |
| Sea Serpent | Sea Snake, Deep Blue, 12m, Swim, Legendary |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
