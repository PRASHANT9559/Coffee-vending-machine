# Snake — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Species | Cobra, Viper, Python, Anaconda, Sea Snake | Cobra | 5 |
| Length | 0.5–15 m | 6.5 m | 146 |
| Thickness | 0.1–1.5 m | 0.4 m | 15 |
| Head Style | Viper, Cobra Hood, Python, Dragon, Flat | Cobra Hood | 5 |
| Fang Size | 0–0.5 m | 0.2 m | 11 |
| Scale Texture | Smooth, Rough, Spiky, Armored | Smooth | 4 |
| Tail Type | Normal, Rattle, Spiked, Split | Rattle | 4 |
| Movement | Slither, Sidewind, Climb, Swim | Slither | 4 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**130,543,902,720,000** unique combinations per spawn.

Formula:

```
3,386,880 × 5 × 146 × 15 × 5 × 11 × 4 × 4 × 4
```

## Example Variants

| Variant | Details |
|---------|---------|
| Cave Predator | Python, Crimson/Black, 8m, Dragon head, Aggressive, 45 HP |
| Glowing Guide | Viper, Neon Pink, 0.8m, Friendly, glow 8.0 |
| Sea Serpent | Sea Snake, Deep Blue, 12m, Swim, Legendary |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
