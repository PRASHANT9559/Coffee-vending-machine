# 🐾 Animals — Deep Index

> Har animal ka apna folder hai: `animals/<slug>/`.
> Har folder me **8 files** hain — README, workflow, random_combination,
> friend_or_foe, attack, loot, spawn, animation.

## Global Files

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Animal spawn → friend/foe → interaction flow |
| [friend-or-foe.md](friend-or-foe.md) | Global `is_friend` system + damage/benefit |
| [damage-system.md](damage-system.md) | Player health + damage formula |
| [random-combinations.md](random-combinations.md) | Combination math for all animals |
| [data-schema.md](data-schema.md) | 28-field master schema for any animal |
| [sea.md](sea.md) | Sea animals overview |
| [land.md](land.md) | Land animals overview |
| [behavior.md](behavior.md) | Behavior states overview |

## All Animals (23)

| Animal | Category | Default | Foe Damage | Friend Benefit | Link |
|--------|----------|---------|------------|----------------|------|
| 🐍 Snake | Reptile / Land | False (aggressive spawn) | 8–45 HP per bite | Night Guide | [open](snake/README.md) |
| 🐊 Crocodile | Reptile / Water | False (aggressive) | 25–70 HP per bite | Armored Scale | [open](crocodile/README.md) |
| 🐅 Tiger | Predator / Land | False (aggressive) | 30–80 HP per claw | Combat Pet | [open](tiger/README.md) |
| 🐆 Cheetah | Predator / Land | False (fast) | 20–60 HP per bite | Speed Pet | [open](cheetah/README.md) |
| 🐻 Bear | Predator / Land | False (aggressive) | 40–90 HP per swipe | Armor Material | [open](bear/README.md) |
| 🐕 Dog | Companion / Land | True (friendly) | 5–20 HP (if betrayed) | Scent Tracking | [open](dog/README.md) |
| 🦅 Eagle | Air / Companion | True (neutral) | 10–30 HP per talon | Aerial Scout | [open](eagle/README.md) |
| 🦇 Banshee | Air / Mount | False (wild) | 50–120 HP per dive | Flight Mount | [open](banshee/README.md) |
| 🦈 Shark | Sea / Predator | False (aggressive) | 35–90 HP per bite | Sea Weapon | [open](shark/README.md) |
| 🐬 Dolphin | Sea / Companion | True (friendly) | 10–25 HP (if provoked) | Swim Boost | [open](dolphin/README.md) |
| 🐢 Turtle | Sea / Companion | True (passive) | 3–10 HP (if provoked) | Shell Shield | [open](turtle/README.md) |
| 🐸 Frog | Amphibian / Small | False (aggressive) | 5–15 HP + poison | Antidote Ingredient | [open](frog/README.md) |
| 🦀 Crab | Sea / Small | False (aggressive) | 2–8 HP | Food | [open](crab/README.md) |
| 🦞 Lobster | Sea / Small | False (aggressive) | 3–10 HP | Food | [open](lobster/README.md) |
| 🦐 Shrimp | Sea / Small | True (passive) | 1–3 HP | Food | [open](shrimp/README.md) |
| 🐙 Octopus | Sea / Predator | False (aggressive) | 15–40 HP + ink | Ink Bomb | [open](octopus/README.md) |
| 🦑 Squid | Sea / Predator | False (aggressive) | 20–50 HP + shock | Electric Ink | [open](squid/README.md) |
| 🐋 Whale | Sea / Giant | True (neutral) | 60–120 HP (if provoked) | Safe Travel | [open](whale/README.md) |
| 🐡 Pufferfish | Sea / Hazard | False (aggressive) | 10–25 HP + poison | Poison Sac | [open](pufferfish/README.md) |
| ⚡ Electric Eel | Sea / Hazard | False (aggressive) | 25–60 HP + shock | Electric Core | [open](electric_eel/README.md) |
| 🦧 Ape | Land / Neutral | False (aggressive) | 15–40 HP | Strength Buff | [open](ape/README.md) |
| 🐴 Direhorse | Land / Mount | False (wild) | 30–70 HP | Land Mount | [open](direhorse/README.md) |
| 🐾 Thanator | Land / Boss | False (aggressive) | 80–150 HP | Apex Trophy | [open](thanator/README.md) |

## Friend / Foe Quick Rule

| `is_friend` | Result |
|-------------|--------|
| `false` | Animal attacks → player health down |
| `true` | Animal helps → resource / pet / guide |

**Total combinations across all animals:** `271,455,234,785,280`

## Folder Pattern

```
animals/
└── snake/
    ├── README.md
    ├── workflow.md
    ├── random_combination.md
    ├── friend_or_foe.md
    ├── attack.md
    ├── loot.md
    ├── spawn.md
    └── animation.md
```

Naya animal add karna ho to `scripts/generate_animals.py` me data add karke
script dobara run karo.

## Related

- [../README.md](../README.md) — main docs
- [../STRUCTURE.md](../STRUCTURE.md) — deep folder convention
