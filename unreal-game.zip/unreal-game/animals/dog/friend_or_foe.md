# Dog — Friend or Foe?

## The Boolean

Har spawned Dog ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **True (friendly)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 5–20 HP (if betrayed) |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | N/A (friendly) |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- N/A (friendly) use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Scent Tracking | Scent tracking, danger alert, pet |
| Trust reward | Dog DNA → scent / tracking upgrade |
| Companion? | True |

**Friend kaise banayein:**
1. Feed fruit/meat 2x
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Scent Tracking
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Scent / alert
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
