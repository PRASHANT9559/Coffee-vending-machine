# 🐕 Dog

> **Category:** Companion / Land · **Zone:** Forest, Camp, Ruins · **Tier:** small

## Overview

Dog ek **Companion / Land** animal hai jo **Forest, Camp, Ruins** me milta hai.
Iska main ability **Scent / alert** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Companion / Land |
| Zone | Forest, Camp, Ruins |
| Tier | small |
| Rarity | Common–Rare |
| Tameable | True |
| Default Friend? | True (friendly) |
| Damage (foe) | 5–20 HP (if betrayed) |
| Friend Benefit | Scent tracking, danger alert, pet |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Loyal Shepherd | Brown, 0.8m, scent tracking |
| Camp Guard | Black, 1m, danger alert |
| Stray Pup | White, 0.4m, friendly, easy tame |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
