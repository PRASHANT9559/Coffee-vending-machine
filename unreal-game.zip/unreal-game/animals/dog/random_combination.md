# Dog — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Breed | Lab, Shepherd, Wolf-Dog, Stray | Shepherd | 4 |
| Fur Color | Brown, Black, White, Golden | Brown | 4 |
| Size | 0.4–1.2 m | 0.8 m | 9 |
| Ear Style | Pointed, Floppy, Tufted | Pointed | 3 |
| Tail Style | Long, Short, Curly | Long | 3 |
| Eye Color | Random | Brown | 24 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**105,345,515,520** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 4 × 9 × 3 × 3 × 24
```

## Example Variants

| Variant | Details |
|---------|---------|
| Loyal Shepherd | Brown, 0.8m, scent tracking |
| Camp Guard | Black, 1m, danger alert |
| Stray Pup | White, 0.4m, friendly, easy tame |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
