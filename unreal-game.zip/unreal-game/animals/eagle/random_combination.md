# Eagle — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Wingspan | 1–4 m | 2.5 m | 31 |
| Feather Color | Brown, White, Golden, Black | Brown | 4 |
| Beak Shape | Hooked, Straight, Long | Hooked | 3 |
| Talon Size | 0.05–0.3 m | 0.15 m | 6 |
| Eye Color | Random glow | Yellow | 24 |
| Flight Style | Soar, Dive, Hover | Soar | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**544,285,163,520** unique combinations per spawn.

Formula:

```
3,386,880 × 31 × 4 × 3 × 6 × 24 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Golden Scout | Golden, 3m wingspan, radar |
| Storm Eagle | Black, 4m, aggressive, 30 HP |
| Cliff Diver | White, 2m, fast dive |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
