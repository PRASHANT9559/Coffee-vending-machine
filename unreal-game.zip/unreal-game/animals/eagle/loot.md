# Eagle — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Feather | 100% | Crafting / trade |
| Eagle DNA | 55% | Beastman upgrade |
| Beak | 25% | Weapon craft |
| Talon | 15% | Crafting / trade |

## DNA

Eagle DNA → vision / glide upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
