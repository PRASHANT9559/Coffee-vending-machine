# Eagle — Friend or Foe?

## The Boolean

Har spawned Eagle ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **True (neutral)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 10–30 HP per talon |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Bow, net, high cover |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Bow, net, high cover use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Aerial Scout | Aerial scout, mini-radar |
| Trust reward | Eagle DNA → vision / glide upgrade |
| Companion? | True |

**Friend kaise banayein:**
1. Feed fish / rescue from net
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Aerial Scout
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Scout / vision
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
