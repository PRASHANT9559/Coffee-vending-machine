# 🦅 Eagle

> **Category:** Air / Companion · **Zone:** Floating Mountain, Sky · **Tier:** medium

## Overview

Eagle ek **Air / Companion** animal hai jo **Floating Mountain, Sky** me milta hai.
Iska main ability **Scout / vision** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Air / Companion |
| Zone | Floating Mountain, Sky |
| Tier | medium |
| Rarity | Rare–Epic |
| Tameable | True |
| Default Friend? | True (neutral) |
| Damage (foe) | 10–30 HP per talon |
| Friend Benefit | Aerial scout, mini-radar |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Golden Scout | Golden, 3m wingspan, radar |
| Storm Eagle | Black, 4m, aggressive, 30 HP |
| Cliff Diver | White, 2m, fast dive |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
