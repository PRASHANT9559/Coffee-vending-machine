# Random Combinations — All Animals

## Formula

```
Total = 3,386,880 × (specific part factors)
```

Common factors (har animal ke liye):

| Part | Factor |
|------|--------|
| Primary Color | 24 |
| Secondary Color | 24 |
| Pattern | 5 |
| Size Scale | 49 |
| Behavior | 3 |
| Rarity | 4 |
| Tameable | 2 |
| **Common Total** | **3,386,880** |

## Per-Animal Counts

| Animal | Specific Factors | Total Combinations |
|--------|------------------|--------------------|
| 🐍 Snake | 5 × 146 × 15 × 5 × 11 × 4 × 4 × 4 | 130,543,902,720,000 |
| 🐊 Crocodile | 16 × 50 × 6 × 5 × 61 × 24 | 119,001,415,680,000 |
| 🐅 Tiger | 3 × 3 × 9 × 26 × 24 × 8 | 1,369,491,701,760 |
| 🐆 Cheetah | 3 × 7 × 16 × 24 × 3 × 61 | 4,998,059,458,560 |
| 🐻 Bear | 4 × 21 × 7 × 3 × 24 × 6 | 860,321,710,080 |
| 🐕 Dog | 4 × 4 × 9 × 3 × 3 × 24 | 105,345,515,520 |
| 🦅 Eagle | 31 × 4 × 3 × 6 × 24 × 3 | 544,285,163,520 |
| 🦇 Banshee | 81 × 4 × 3 × 3 × 2 × 3 | 59,256,852,480 |
| 🦈 Shark | 51 × 3 × 5 × 4 × 3 × 24 | 746,197,401,600 |
| 🐬 Dolphin | 16 × 4 × 3 × 3 × 24 × 41 | 1,919,629,393,920 |
| 🐢 Turtle | 4 × 4 × 18 × 3 × 24 × 3 | 210,691,031,040 |
| 🐸 Frog | 5 × 3 × 10 × 3 × 24 × 3 | 109,734,912,000 |
| 🦀 Crab | 4 × 3 × 5 × 3 × 2 × 3 | 3,657,830,400 |
| 🦞 Lobster | 4 × 3 × 6 × 3 × 2 × 3 | 4,389,396,480 |
| 🦐 Shrimp | 4 × 10 × 3 × 3 × 2 × 3 | 7,315,660,800 |
| 🐙 Octopus | 4 × 3 × 26 × 18 × 3 × 2 | 114,124,308,480 |
| 🦑 Squid | 4 × 3 × 36 × 3 × 3 × 2 | 26,336,378,880 |
| 🐋 Whale | 201 × 4 × 3 × 4 × 24 × 10 | 7,842,388,377,600 |
| 🐡 Pufferfish | 6 × 3 × 4 × 3 × 24 × 3 | 52,672,757,760 |
| ⚡ Electric Eel | 41 × 4 × 20 × 3 × 2 × 3 | 199,961,395,200 |
| 🦧 Ape | 4 × 11 × 3 × 3 × 24 × 3 | 96,566,722,560 |
| 🐴 Direhorse | 21 × 4 × 3 × 3 × 24 × 41 | 2,519,513,579,520 |
| 🐾 Thanator | 41 × 4 × 6 × 6 × 2 × 3 | 119,976,837,120 |

## Grand Total

**271,455,234,785,280** combinations across all animals.

## Why So Many?

- Har part independent random hai.
- Colors + size + body + behavior + rarity multiply hote hain.
- 25 lakh snakes spawn hone par bhi repeat chance ~0.
- Detail: [snake/random_combination.md](snake/random_combination.md) (example)

## Related

- [README.md](README.md)
- [workflow.md](workflow.md)
