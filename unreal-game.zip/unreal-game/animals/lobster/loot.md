# Lobster — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Lobster Meat | 90% | Food / health |
| Shell | 50% | Armor / cosmetic |
| Lobster DNA | 20% | Beastman upgrade |

## DNA

Lobster DNA → armor / claw upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
