# 🦞 Lobster

> **Category:** Sea / Small · **Zone:** Beach, Rocks · **Tier:** small

## Overview

Lobster ek **Sea / Small** animal hai jo **Beach, Rocks** me milta hai.
Iska main ability **Pinch / armor** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Small |
| Zone | Beach, Rocks |
| Tier | small |
| Rarity | Common |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 3–10 HP |
| Friend Benefit | Food +50 HP |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Rock Lobster | Red, 0.3m, passive |
| Blue Lobster | Blue, 0.4m, rare |
| Giant Lobster | Brown, 0.6m, 25 HP |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
