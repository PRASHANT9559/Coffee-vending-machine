# Lobster — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Shell Color | Red, Blue, Brown, White | Red | 4 |
| Claw Size | Small, Medium, Large | Large | 3 |
| Body Size | 0.15–0.6 m | 0.3 m | 6 |
| Antenna Length | Short, Medium, Long | Long | 3 |
| Eye Style | Stalk, Normal | Stalk | 2 |
| Shell Pattern | Spots, Stripes, Plain | Plain | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**4,389,396,480** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 3 × 6 × 3 × 2 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Rock Lobster | Red, 0.3m, passive |
| Blue Lobster | Blue, 0.4m, rare |
| Giant Lobster | Brown, 0.6m, 25 HP |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
