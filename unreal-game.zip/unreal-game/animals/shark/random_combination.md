# Shark — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Body Length | 2–7 m | 4 m | 51 |
| Fin Shape | Straight, Curved, Split | Curved | 3 |
| Teeth Rows | 1–5 | 3 | 5 |
| Skin Color | Grey, Blue, White, Black | Grey | 4 |
| Gill Style | Normal, Glowing, Armored | Normal | 3 |
| Eye Color | Random glow | Black | 24 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**746,197,401,600** unique combinations per spawn.

Formula:

```
3,386,880 × 51 × 3 × 5 × 4 × 3 × 24
```

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Shark | 2m, 40 HP, fast |
| Great White | 5m, 90 HP, aggressive |
| Glow Shark | Neon, 4m, night, legendary |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
