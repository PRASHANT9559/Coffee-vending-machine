# 🦈 Shark

> **Category:** Sea / Predator · **Zone:** Mid Water, Deep Ocean · **Tier:** large

## Overview

Shark ek **Sea / Predator** animal hai jo **Mid Water, Deep Ocean** me milta hai.
Iska main ability **Bite / charge** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Predator |
| Zone | Mid Water, Deep Ocean |
| Tier | large |
| Rarity | Rare–Legendary |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 35–90 HP per bite |
| Friend Benefit | Shark tooth weapon, sea danger warning |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Shark | 2m, 40 HP, fast |
| Great White | 5m, 90 HP, aggressive |
| Glow Shark | Neon, 4m, night, legendary |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
