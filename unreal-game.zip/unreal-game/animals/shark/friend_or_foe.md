# Shark — Friend or Foe?

## The Boolean

Har spawned Shark ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (aggressive)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 35–90 HP per bite |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | Spear, cage, dolphin ally |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Spear, cage, dolphin ally use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Sea Weapon | Shark tooth weapon, sea danger warning |
| Trust reward | Shark DNA → underwater combat upgrade |
| Companion? | False |

**Friend kaise banayein:**
1. Feed fish / rescue from net
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Sea Weapon
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Bite / charge
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
