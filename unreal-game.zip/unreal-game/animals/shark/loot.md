# Shark — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Meat | 100% | Food / health |
| Shark DNA | 70% | Beastman upgrade |
| Tooth | 40% | Weapon craft |
| Fin | 20% | Weapon craft |

## DNA

Shark DNA → underwater combat upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
