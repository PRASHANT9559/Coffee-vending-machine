# 🐢 Turtle

> **Category:** Sea / Companion · **Zone:** Shallow Water, Beach · **Tier:** small

## Overview

Turtle ek **Sea / Companion** animal hai jo **Shallow Water, Beach** me milta hai.
Iska main ability **Defense / swim** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Companion |
| Zone | Shallow Water, Beach |
| Tier | small |
| Rarity | Common–Rare |
| Tameable | True |
| Default Friend? | True (passive) |
| Damage (foe) | 3–10 HP (if provoked) |
| Friend Benefit | Ride/swim, shell shield |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Beach Turtle | Green, 0.6m, passive |
| Glow Turtle | Neon, 1.2m, night guide |
| Ancient Turtle | Brown, 2m, shell shield, rare |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
