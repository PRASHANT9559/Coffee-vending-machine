# Turtle — Friend or Foe?

## The Boolean

Har spawned Turtle ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **True (passive)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 3–10 HP (if provoked) |
| Attack cooldown | 2.0 sec |
| Poison chance | 0% |
| Player health down | `Damage × Size_Scale` |
| Counter | N/A (passive) |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- N/A (passive) use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Shell Shield | Ride/swim, shell shield |
| Trust reward | Turtle DNA → defense / swim upgrade |
| Companion? | True |

**Friend kaise banayein:**
1. Feed fruit / clear trap
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Shell Shield
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Defense / swim
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
