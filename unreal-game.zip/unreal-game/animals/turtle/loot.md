# Turtle — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Shell | 80% | Armor / cosmetic |
| Turtle DNA | 50% | Beastman upgrade |
| Meat | 40% | Food / health |

## DNA

Turtle DNA → defense / swim upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
