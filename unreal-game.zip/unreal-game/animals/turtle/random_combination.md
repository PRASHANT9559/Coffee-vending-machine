# Turtle — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Shell Pattern | Hex, Spiral, Spotted, Plain | Hex | 4 |
| Shell Color | Green, Brown, Blue, Neon | Green | 4 |
| Body Size | 0.3–2 m | 1 m | 18 |
| Fin Style | Paddle, Claw, Long | Paddle | 3 |
| Eye Color | Random | Black | 24 |
| Neck Length | Short, Medium, Long | Medium | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**210,691,031,040** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 4 × 18 × 3 × 24 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Beach Turtle | Green, 0.6m, passive |
| Glow Turtle | Neon, 1.2m, night guide |
| Ancient Turtle | Brown, 2m, shell shield, rare |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
