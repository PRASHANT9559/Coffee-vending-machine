# 🦑 Squid

> **Category:** Sea / Predator · **Zone:** Deep Ocean · **Tier:** medium

## Overview

Squid ek **Sea / Predator** animal hai jo **Deep Ocean** me milta hai.
Iska main ability **Electric / ink** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Predator |
| Zone | Deep Ocean |
| Tier | medium |
| Rarity | Rare–Epic |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 20–50 HP + shock |
| Friend Benefit | Bioluminescent ink, electric weapon |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Squid | White, 1m, ink |
| Electric Squid | Blue, 2m, shock, 50 HP |
| Neon Squid | Neon, 3m, legendary, glow |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
