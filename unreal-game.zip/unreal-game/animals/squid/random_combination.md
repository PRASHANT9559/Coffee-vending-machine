# Squid — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Skin Color | Red, White, Blue, Neon | White | 4 |
| Tentacle Count | 8, 10, 12 | 10 | 3 |
| Body Length | 0.5–4 m | 2 m | 36 |
| Fin Style | Triangle, Round, Long | Triangle | 3 |
| Eye Style | Normal, Slit, Glow | Glow | 3 |
| Bioluminescence | True/False | True | 2 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**26,336,378,880** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 3 × 36 × 3 × 3 × 2
```

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Squid | White, 1m, ink |
| Electric Squid | Blue, 2m, shock, 50 HP |
| Neon Squid | Neon, 3m, legendary, glow |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
