# Animals — Master Data Schema (28 Fields)

Yeh file batati hai ki kisi bhi random animal ko **kitne parts** me divide
kiya jata hai. Har animal folder ka `random_combination.md` in fields ko
apne species-specific options ke saath use karta hai.

## The 28 Fields

| # | Field | Type | Options / Range | Example |
|---|-------|------|-----------------|---------|
| 1 | `Species` | Enum | Cobra, Viper, Python, Anaconda, Sea Snake | Cobra |
| 2 | `Primary_Color` | Color | Random RGB / 24-color palette | Neon Green |
| 3 | `Secondary_Color` | Color | Random RGB / 24-color palette | Black |
| 4 | `Pattern` | Enum | Stripes, Spots, Diamond, Scales, None | Diamond |
| 5 | `Length` | Float | 0.5–15.0 meters | 6.5 |
| 6 | `Thickness` | Float | 0.1–1.5 meters | 0.4 |
| 7 | `Head_Style` | Enum | Viper, Cobra_Hood, Python, Dragon, Flat | Cobra_Hood |
| 8 | `Head_Size` | Float | 0.5–3.0x body | 1.8 |
| 9 | `Eye_Color` | Color | Random | Neon Yellow |
| 10 | `Eye_Glow` | Boolean | True/False | True |
| 11 | `Fang_Size` | Float | 0.0–0.5 meters | 0.2 |
| 12 | `Scale_Texture` | Enum | Smooth, Rough, Spiky, Armored | Smooth |
| 13 | `Tail_Type` | Enum | Normal, Rattle, Spiked, Split | Rattle |
| 14 | `Tongue_Type` | Enum | Forked, Normal, Long | Forked |
| 15 | `Movement_Style` | Enum | Slither, Sidewind, Climb, Swim | Slither |
| 16 | `Size_Scale` | Float | 0.2–5.0 | 4.5 |
| 17 | `Health` | Float | 10–5000 | 1200 |
| 18 | `Speed` | Float | 100–1200 | 450 |
| 19 | `Behavior` | Enum | Aggressive, Friendly, Scared | Aggressive |
| 20 | `Poison_Type` | Enum | None, Nerve_Damage, Slow_Motion | Nerve_Damage |
| 21 | `Sound_Pitch` | Float | 0.5–2.0 | 0.5 |
| 22 | `Hiss_Volume` | Float | 0.0–1.0 | 0.9 |
| 23 | `Luminescent_Intensity` | Float | 0.0–10.0 | 0.0 |
| 24 | `Zone` | Enum | Forest, Swamp, Cave, Ocean, Anywhere | Cave |
| 25 | `Rarity` | Enum | Common, Rare, Epic, Legendary | Epic |
| 26 | `Tameable` | Boolean | True/False | False |
| 27 | `Diet` | Enum | Fruits, Player, Other_Animals | Player |
| 28 | `Loot` | String | Meat, DNA, Scale, Venom | DNA |

> `is_friend` field 29 hai — har spawn par `RandomBool(0.5)` se set hota hai.
> Detail: [friend-or-foe.md](friend-or-foe.md).

## Generation Formula

```
Species       = RandomEnum(animal-specific list)
Length        = RandomFloat(min, max) * Size_Scale
Thickness     = Length * RandomFloat(0.03, 0.10)
Head_Style    = RandomEnum(animal-specific list)
Primary_Color = RandomRGB()
Pattern       = RandomEnum(Stripes, Spots, Diamond, Scales, None)
Speed         = 300 + (Level * 0.1) * Size_Scale
Health        = 100 * Size_Scale * (1 + Level / 1000)
Behavior      = RandomEnum(Aggressive, Friendly, Scared)
Poison        = (Behavior == Aggressive) ? RandomEnum(Nerve, Slow, None) : None
Glow          = (Time == Night) ? RandomFloat(0.0, 10.0) : 0.0
is_friend     = RandomBool(0.5)
```

## Example Instances

### Snake 1 — Giant Cave Predator
```
Species: Python | Color: Crimson Red / Black
Pattern: Stripes | Length: 8.0m | Thickness: 0.6m
Head: Dragon | Head Size: 2.0x | Eyes: Neon Red (Glow)
Fangs: 0.4m | Scale: Armored | Tail: Spiked
Movement: Slither | Size: 4.5 | Health: 1200 | Speed: 450
Behavior: Aggressive | Poison: Nerve_Damage
Sound: 0.5 (Heavy) | Hiss: 0.9 | Glow: 0.0
Zone: Cave | Rarity: Epic | Tameable: No | is_friend: false
```

### Snake 2 — Tiny Glowing Guide
```
Species: Viper | Color: Neon Pink
Pattern: None | Length: 0.8m | Thickness: 0.05m
Head: Viper | Head Size: 1.0x | Eyes: Cyan (Glow)
Fangs: 0.05m | Scale: Smooth | Tail: Normal
Movement: Climb | Size: 0.3 | Health: 50 | Speed: 200
Behavior: Friendly | Poison: None
Sound: 1.8 (Squeaky) | Hiss: 0.2 | Glow: 8.0
Zone: Anywhere | Rarity: Rare | Tameable: Yes | is_friend: true
```

### Snake 3 — Sea Serpent
```
Species: Sea Snake | Color: Deep Blue / Teal
Pattern: Scales | Length: 12.0m | Thickness: 1.0m
Head: Flat | Head Size: 1.5x | Eyes: Yellow (Glow)
Fangs: 0.3m | Scale: Smooth | Tail: Split
Movement: Swim | Size: 3.8 | Health: 3000 | Speed: 800
Behavior: Aggressive | Poison: Slow_Motion
Sound: 0.7 | Hiss: 0.6 | Glow: 3.0
Zone: Ocean | Rarity: Legendary | Tameable: No | is_friend: false
```

## Species-Specific Fields

| Animal | Unique Parts | Deep Dive |
|--------|--------------|-----------|
| 🐍 Snake | Species, length, thickness, head, fangs, scales, tail, movement | [snake/random_combination.md](snake/random_combination.md) |
| 🐊 Crocodile | Jaw length, bite force, armor plates, tail spikes | [crocodile/random_combination.md](crocodile/random_combination.md) |
| 🐅 Tiger | Fur pattern, mane, claw size, roar pitch | [tiger/random_combination.md](tiger/random_combination.md) |
| 🦅 Eagle | Wingspan, feather color, beak shape, talon size | [eagle/random_combination.md](eagle/random_combination.md) |
| 🦈 Shark | Fin shape, teeth rows, gill style, body length | [shark/random_combination.md](shark/random_combination.md) |
| 🐬 Dolphin | Snout shape, skin color, fin size, jump height | [dolphin/random_combination.md](dolphin/random_combination.md) |

Baaki 17 animals ke parts unke apne folder me hain:
[animals index](README.md).

## Balance Rules

- `Size_Scale` 0.2–0.5 = ant mode, friendly/stealth.
- `Size_Scale` 4.0–5.0 = boss-level, rare.
- Friendly + glow = night guide (high value).
- Aggressive + poison + high speed = extreme danger.
- Legendary sirf Level 5000+ me spawn.

## Related

- [README.md](README.md) — all animals
- [workflow.md](workflow.md) — spawn flow
- [friend-or-foe.md](friend-or-foe.md) — `is_friend` logic
- [random-combinations.md](random-combinations.md) — total math
- [sea.md](sea.md) — sea animals
- [land.md](land.md) — land animals
- [behavior.md](behavior.md) — behavior states
