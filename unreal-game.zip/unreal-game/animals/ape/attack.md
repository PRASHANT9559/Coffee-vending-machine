# Ape — Attacks & Damage

## Attack Table

| Attack | Range | Damage | Cooldown | Effect |
|--------|-------|--------|----------|--------|
| Attack | Range | Damage | Cooldown | Effect |
|--------|-------|--------|----------|--------|
| Punch | Melee | 15–25 HP | 1.5s | Knockback |
| Throw | Ranged | 20–30 HP | 2.0s | Stun 20% |
| Grab | Melee | 25–35 HP | 2.5s | Grab |

Damage formula:

```
Damage = Base_Damage × Size_Scale × (1 + Level / 1000)
```

## VR Interaction

| Attack | Player Counter |
|--------|----------------|
| Melee | Shield / dodge |
| Ranged | Strafe / cover |
| AoE | Jump / glide |

## Telegraph

- Attack se pehle animation + sound.
- Red glow = danger.
- 0.5 sec reaction window.

## Related

- [README.md](README.md)
- [friend_or_foe.md](friend_or_foe.md)
- [../damage-system.md](../damage-system.md)
