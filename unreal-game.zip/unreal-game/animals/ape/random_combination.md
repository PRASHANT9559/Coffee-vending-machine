# Ape — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Fur Color | Black, Brown, Grey, Red | Black | 4 |
| Body Size | 1–2 m | 1.5 m | 11 |
| Arm Length | Short, Medium, Long | Long | 3 |
| Face Style | Flat, Round, Scarred | Flat | 3 |
| Eye Color | Random | Brown | 24 |
| Strength | Low, Medium, High | High | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**96,566,722,560** unique combinations per spawn.

Formula:

```
3,386,880 × 4 × 11 × 3 × 3 × 24 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Jungle Ape | Black, 1.5m, territorial |
| White Ape | White, 2m, rare, strength |
| Ruins Guardian | Grey, 1.8m, puzzle helper |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
