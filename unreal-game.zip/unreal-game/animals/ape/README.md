# 🦧 Ape

> **Category:** Land / Neutral · **Zone:** Jungle, Ruins · **Tier:** medium

## Overview

Ape ek **Land / Neutral** animal hai jo **Jungle, Ruins** me milta hai.
Iska main ability **Strength / climb** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Land / Neutral |
| Zone | Jungle, Ruins |
| Tier | medium |
| Rarity | Rare–Epic |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 15–40 HP |
| Friend Benefit | Strength buff, tool crafting help |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Jungle Ape | Black, 1.5m, territorial |
| White Ape | White, 2m, rare, strength |
| Ruins Guardian | Grey, 1.8m, puzzle helper |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
