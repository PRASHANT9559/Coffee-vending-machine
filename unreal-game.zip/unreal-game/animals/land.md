# Land Animals (Journey 2 Style)

Yeh animals Forest, Land aur Floating Mountains par spawn honge.

## Reptiles (Zameen Aur Ghaas Ke Khatre)

| Animal | Behavior | Gameplay | Deep Dive |
|--------|----------|----------|-----------|
| 🐍 Snake | Core Enemy | Kahin bhi chhupa ho sakta hai, size/scale random | [snake](snake/README.md) |
| 🐊 Crocodile | Ambush | Nadi ke kinare/daldal me chhupa, paani ke paas jhapta | [crocodile](crocodile/README.md) |

## Forest Animals

| Animal | Behavior | Gameplay | Deep Dive |
|--------|----------|----------|-----------|
| 🐅 Tiger | Aggressive / Tameable | Combat, pet ban sakta hai | [tiger](tiger/README.md) |
| 🐆 Cheetah | Aggressive | Tez attack | [cheetah](cheetah/README.md) |
| 🐻 Bear | Aggressive | Heavy damage | [bear](bear/README.md) |
| 🦧 Ape | Neutral | Jungle me | [ape](ape/README.md) |
| 🐕 Dog | Friendly | Pet, scent tracking | [dog](dog/README.md) |
| 🦅 Eagle | Friendly | Aerial scout pet | [eagle](eagle/README.md) |

## Floating Mountain Animals

| Animal | Behavior | Gameplay | Deep Dive |
|--------|----------|----------|-----------|
| 🦇 Banshee / Ikran | Tameable | Udne ke liye, glider alternative | [banshee](banshee/README.md) |
| 🐴 Direhorse | Neutral | Rideable | [direhorse](direhorse/README.md) |
| 🐾 Thanator | Aggressive | Boss-level predator | [thanator](thanator/README.md) |

## Danger Scaling

- Level ke saath animals ki **size aur speed** random.
- `Size_Scale` 0.2 se 5.0 → chhota snake ya giant Anaconda.
- `Behavior_State` random → same animal kabhi dushman, kabhi dost.

## Ecosystem Events

- **Predator vs Prey:** Bada bird snake ko utha kar le ja sakta hai.
- **Night Mode:** Raat me predators aggressive ho jate hain.
- **Weather:** Toofan me animals chhup jate hain / caves me milte hain.

## Spawn Logic

```
If (Zone == "Forest")           -> [🐍, 🐊, 🐅, 🐆, 🐻, 🐕]
If (Zone == "Floating_Mountain")-> [Banshee, Ikran, Eagle]
If (Zone == "Caves")            -> [🐍 (giant), 🦇, 💎]
```

## Related

- [README.md](README.md) — all animals
- [sea.md](sea.md) — sea animals
- [behavior.md](behavior.md) — behavior states
- [friend-or-foe.md](friend-or-foe.md) — friend/foe + damage/benefit
- [damage-system.md](damage-system.md) — health formula
