# Damage System

## Player Health

```
Base_Health = 100
Health = Base_Health + (Armor × 10) + (Beastman_Skin_Level × 20)
```

## Damage Formula

```
Final_Damage = Base_Damage
             × Size_Scale
             × (1 + Level / 1000)
             × (1 - Armor_Reduction)
```

## Tier Table

| Tier | Base Damage | Player Hits to Die |
|------|-------------|--------------------|
| Small | 5 | 20 |
| Medium | 15 | 7 |
| Large | 40 | 3 |
| Boss | 80 | 2 |

## Status Effects

| Effect | Damage | Duration |
|--------|--------|----------|
| Poison | 2 HP/sec | 10s |
| Bleed | 3 HP/sec | 6s |
| Shock | 5 HP + stun | 2s |
| Burn | 4 HP/sec | 5s |

## Defense

- **Shield:** 50% block
- **Beastman Skin:** +30% resistance
- **Armor:** flat reduction
- **Dodge:** 100% avoid (timing)

## Death

Health 0 → [Death-Scene](../Death-Scene/workflow.md) → auto respawn.

## Related

- [friend-or-foe.md](friend-or-foe.md)
- [workflow.md](workflow.md)
- [../Death-Scene/workflow.md](../Death-Scene/workflow.md)
