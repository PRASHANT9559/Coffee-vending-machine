# Pufferfish — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Body Size | 0.1–0.6 m | 0.3 m | 6 |
| Spike Length | Short, Medium, Long | Medium | 3 |
| Skin Color | Yellow, Green, Brown, Neon | Yellow | 4 |
| Pattern | Spots, Stripes, Plain | Spots | 3 |
| Eye Color | Random | Black | 24 |
| Poison Type | Nerve, Slow, None | Nerve | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**52,672,757,760** unique combinations per spawn.

Formula:

```
3,386,880 × 6 × 3 × 4 × 3 × 24 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Puffer | Yellow, 0.3m, poison 70% |
| Neon Puffer | Neon, 0.2m, glow, rare |
| Giant Puffer | Brown, 0.6m, 25 HP |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
