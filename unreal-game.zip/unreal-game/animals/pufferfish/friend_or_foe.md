# Pufferfish — Friend or Foe?

## The Boolean

Har spawned Pufferfish ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (aggressive)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 10–25 HP + poison |
| Attack cooldown | 2.0 sec |
| Poison chance | 70% |
| Player health down | `Damage × Size_Scale` |
| Counter | Don't touch, ranged |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Don't touch, ranged use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Poison Sac | Poison sac, defense orb |
| Trust reward | Pufferfish DNA → poison / defense upgrade |
| Companion? | False |

**Friend kaise banayein:**
1. N/A (passive)
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Poison Sac
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Poison / defense
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
