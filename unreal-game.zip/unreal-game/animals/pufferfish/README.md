# 🐡 Pufferfish

> **Category:** Sea / Hazard · **Zone:** Mid Water, Reef · **Tier:** small

## Overview

Pufferfish ek **Sea / Hazard** animal hai jo **Mid Water, Reef** me milta hai.
Iska main ability **Poison / defense** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Sea / Hazard |
| Zone | Mid Water, Reef |
| Tier | small |
| Rarity | Common–Rare |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 10–25 HP + poison |
| Friend Benefit | Poison sac, defense orb |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Reef Puffer | Yellow, 0.3m, poison 70% |
| Neon Puffer | Neon, 0.2m, glow, rare |
| Giant Puffer | Brown, 0.6m, 25 HP |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
