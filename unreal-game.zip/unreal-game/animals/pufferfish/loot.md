# Pufferfish — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Puffer DNA | 50% | Beastman upgrade |
| Poison Sac | 45% | Crafting / trade |
| Meat | 20% | Food / health |

## DNA

Pufferfish DNA → poison / defense upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
