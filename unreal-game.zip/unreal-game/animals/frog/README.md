# 🐸 Frog

> **Category:** Amphibian / Small · **Zone:** Swamp, River · **Tier:** small

## Overview

Frog ek **Amphibian / Small** animal hai jo **Swamp, River** me milta hai.
Iska main ability **Poison / jump** hai. Har spawn par **friend ya foe**
(`is_friend`) decide hota hai — agar foe hai to player ki health down
hoti hai, agar friend hai to player ko benefit milta hai.

## Quick Stats

| Stat | Value |
|------|-------|
| Category | Amphibian / Small |
| Zone | Swamp, River |
| Tier | small |
| Rarity | Common–Rare |
| Tameable | False |
| Default Friend? | False (aggressive) |
| Damage (foe) | 5–15 HP + poison |
| Friend Benefit | Poison antidote ingredient, jump boost |
| Level Range | 1–10,000 |

## Files (Deep Dive)

| File | Kya hai |
|------|---------|
| [workflow.md](workflow.md) | Spawn → friend/foe → outcome flow |
| [random_combination.md](random_combination.md) | Parts + combinations |
| [friend_or_foe.md](friend_or_foe.md) | `is_friend` logic, damage/benefit |
| [attack.md](attack.md) | Attack patterns + damage |
| [loot.md](loot.md) | Drops + crafting |
| [spawn.md](spawn.md) | Zone, level, rarity |
| [animation.md](animation.md) | Animations + SFX |

## Example Variants

| Variant | Details |
|---------|---------|
| Swamp Frog | Green, 0.2m, poison 50% |
| Neon Dart Frog | Neon, 0.1m, poison 80% |
| Giant Toad | Brown, 0.5m, 30 HP, tank |

## Related

- [../README.md](../README.md) — all animals
- [../friend-or-foe.md](../friend-or-foe.md) — global system
- [../damage-system.md](../damage-system.md) — health formula
