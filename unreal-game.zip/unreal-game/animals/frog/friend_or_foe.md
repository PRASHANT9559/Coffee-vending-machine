# Frog — Friend or Foe?

## The Boolean

Har spawned Frog ke paas ek `is_friend` flag hota hai:

```
is_friend = false  →  Foe (attack / threat)
is_friend = true   →  Friend (help / resource)
```

Default spawn: **False (aggressive)**

## If `is_friend = false` (Foe)

| Cheez | Value |
|-------|-------|
| Damage per hit | 5–15 HP + poison |
| Attack cooldown | 2.0 sec |
| Poison chance | 50% |
| Player health down | `Damage × Size_Scale` |
| Counter | Gloves, antidote, ranged |

**Player ko kya karna chahiye:**
- Dodge/block karo.
- Gloves, antidote, ranged use karo.
- Health low ho to retreat.

## If `is_friend = true` (Friend)

| Benefit | Value |
|---------|-------|
| Antidote Ingredient | Poison antidote ingredient, jump boost |
| Trust reward | Frog DNA → jump / poison resist upgrade |
| Companion? | False |

**Friend kaise banayein:**
1. Feed insect
2. 3 successful interactions
3. Trust meter 100% → friend

## State Machine

```mermaid
stateDiagram-v2
    [*] --> Hostile
    Hostile --> Neutral: Player avoids / feeds
    Neutral --> Friendly: Trust 100%
    Friendly --> Hostile: Player attacks
    Neutral --> Hostile: Player attacks
```

## Code

```cpp
if (animal.is_friend) {
    // No damage — benefit do
    animal.giveBenefit(player);   // Antidote Ingredient
} else {
    player.health -= animal.damage * animal.sizeScale;
    animal.applyStatus(player);   // Poison / jump
}
```

## Related

- [../friend-or-foe.md](../friend-or-foe.md)
- [../damage-system.md](../damage-system.md)
- [attack.md](attack.md)
