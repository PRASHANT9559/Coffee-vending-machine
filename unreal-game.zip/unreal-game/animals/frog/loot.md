# Frog — Loot & Drops

## Drop Table

| Item | Chance | Use |
|------|--------|-----|
| Item | Chance | Use |
|------|--------|-----|
| Frog DNA | 50% | Beastman upgrade |
| Poison Gland | 35% | Crafting / trade |
| Meat | 20% | Food / health |

## DNA

Frog DNA → jump / poison resist upgrade

## Crafting Uses

- Meat → food / health
- DNA → Beastman upgrade
- Rare part → weapon / skin

## Level Scaling

- Higher level → higher rarity chance.
- Boss variant → guaranteed rare drop.

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
