# Frog — Random Combination

## Parts

Har spawn par neeche diye gaye parts random generate hote hain.

| Part | Options / Range | Example | Factor |
|------|-----------------|---------|--------|
| Skin Color | Green, Blue, Red, Yellow, Neon | Green | 5 |
| Pattern | Spots, Stripes, Plain | Spots | 3 |
| Body Size | 0.05–0.5 m | 0.2 m | 10 |
| Leg Length | Short, Medium, Long | Long | 3 |
| Eye Color | Random glow | Yellow | 24 |
| Poison Type | None, Nerve, Slow | Nerve | 3 |
| Primary Color | 24-color palette | Neon Blue | 24 |
| Secondary Color | 24-color palette | Black | 24 |
| Pattern | Stripes, Spots, Diamond, Scales, None | Diamond | 5 |
| Size Scale | 0.2–5.0 (0.1 step) | 4.5 | 49 |
| Behavior | Aggressive, Friendly, Scared | Aggressive | 3 |
| Rarity | Common, Rare, Epic, Legendary | Epic | 4 |
| Tameable | True/False | False | 2 |

## Total Combinations

**109,734,912,000** unique combinations per spawn.

Formula:

```
3,386,880 × 5 × 3 × 10 × 3 × 24 × 3
```

## Example Variants

| Variant | Details |
|---------|---------|
| Swamp Frog | Green, 0.2m, poison 50% |
| Neon Dart Frog | Neon, 0.1m, poison 80% |
| Giant Toad | Brown, 0.5m, 30 HP, tank |

## Notes

- Health/speed level se derive hote hain, isliye upar count me sirf
  visual/gameplay parts liye gaye hain.
- Har spawn par seed change → naya combination.
- Same level dobara khelne par same seed → same variant.
- Poora animal combination math: [../random-combinations.md](../random-combinations.md)

## Related

- [README.md](README.md)
- [../random-combinations.md](../random-combinations.md)
