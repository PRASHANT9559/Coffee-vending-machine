# Optimization — Workflow

Frame-by-frame rendering pipeline: sirf zaroori cheezein load/render hoti
hain.

```mermaid
flowchart TD
    A["Player position update"] --> B["World Partition cell check"]
    B --> C["Load nearby 4–5 cells"]
    B --> D["Unload far cells"]
    C --> E["Frustum culling<br/>camera ke bahar wale hatao"]
    E --> F["Occlusion culling<br/>deewar ke piche wale hatao"]
    F --> G{"Distance > Max Draw?"}
    G -->|Yes| H["De-spawn / hide"]
    G -->|No| I["LOD / HLOD select"]
    I --> J["Render frame"]
    J --> K{"FPS < 90?"}
    K -->|Yes| L["Profile: stat unit / rhi"]
    L --> M["Optimize bottleneck"]
    M --> J
    K -->|No| N["✅ Smooth VR"]
```

## Pipeline Stages

1. **Streaming** — World Partition cells.
2. **Culling** — frustum + occlusion.
3. **Distance** — Max Draw Distance.
4. **LOD** — distance-based detail.
5. **Render** — GPU frame.
6. **Profile** — 90 FPS maintain.

## Profiling Commands

| Command | Kya dikhata hai |
|---------|-----------------|
| `stat fps` | Frame rate |
| `stat unit` | CPU/GPU breakdown |
| `stat rhi` | Rendering stats |
| `stat scenerendering` | Draw calls |
| Unreal Insights | Deep profiling |

## Targets

- VR: **90 FPS minimum** (120 ideal).
- Low-end PC: 16GB RAM par smooth.
- Frame time: < 11ms (90 FPS).

## Related

- [culling.md](culling.md)
- [world-partition.md](world-partition.md)
- [performance.md](performance.md)
