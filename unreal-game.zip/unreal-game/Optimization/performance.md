# Performance Optimization Guide

## Target

- **90+ FPS** VR me (warna motion sickness).
- 16GB RAM wale normal gaming PC par bhi smooth.
- Standalone VR headsets (Quest) par bhi chal sake.

## Key Techniques

### 1. Jitna Dikhega Utna Load Hoga
- Frustum culling + occlusion culling + world partition.
- Off-screen actors → de-spawn.
- Door objects → low-poly HLOD.

### 2. Asset Optimization
- Textures ka size limit.
- Shared materials (material instances).
- Nanite for high-poly, LOD for others.

### 3. Lighting
- Lumen real-time hai, lekin VR me expensive ho sakta hai.
- Static lighting + baked GI ka mix use karo jahan possible ho.
- Bioluminescence ke liye emissive materials (light sources kam).

### 4. Physics
- Complex collision avoid karo.
- Simple capsules/boxes for AI.
- Physics objects ko sleep state me bhejo.

### 5. AI Optimization
- NavMesh ka size limit.
- Door ke AI ko tick se hatao.
- Behavior tree optimization.

## VR-Specific

| Problem | Solution |
|---------|----------|
| Motion sickness | 90/120 FPS lock, comfort options |
| GPU overload | Foveated rendering, fixed foveated |
| CPU spikes | Async loading, shader warmup |
| Latency | Late-latching, prediction |

## Profiling Tools

- `stat fps` — frame rate
- `stat unit` — CPU/GPU breakdown
- `stat rhi` — rendering
- Unreal Insights — deep profiling

## Checklist ✅

- [ ] World Partition enabled
- [ ] Max Draw Distance set
- [ ] LOD/HLOD configured
- [ ] Texture sizes optimized
- [ ] 90 FPS target tested on low-end PC
- [ ] Shader compilation warmup done
- [ ] No runtime hitches

## 💡 Golden Rule

Graphics acche banana ek baat hai, lekin unhe **kam se kam RAM par smooth**
chalana hi asli programmer ka kaam hai.
