# World Partition & HLOD

## 1. World Partition (Grid Cell Loading) 🗺

UE5 poore island ko chhote-chhote **2D grids (boxes)** me baant deta hai.

- Player jis grid me khada hoga, sirf uske aas-paas ke **4–5 grids** hi
  RAM me active rahenge.
- Door ke grids **SSD par soye rahenge**.
- Player chalte hi grids stream hoti hain.

**Fayda:** 10,000 levels ka map ek saath RAM me load nahi hota → PC
dhuaan nahi chhodta, game crash nahi hota.

## 2. HLOD (Hierarchical Level of Detail)

- Player floating mountain se bohot door samundari jahaaz par khada hai.
- Door ka pahad **high-graphics me dikhane ki zaroorat nahi**.
- Engine us pahad ka **low-polygon (halka) 3D model** dikhayega.
- Jaise player glider suit pehan kar paas aayega, pahad automatically
  high-detail hota jayega.

## 3. Nanite + LOD

- Nanite high-poly meshes ko automatically manage karta hai.
- Manual LOD banana kam pad jata hai.
- VR me performance ke liye LOD + Nanite balance zaroori.

## UE5 Setup Steps

1. **Enable World Partition** — island landscape automatic chhote hisson
   me kaatega.
2. **HLOD settings** — door ke objects ke liye low-poly meshes generate.
3. **Streaming distances** — grid size aur loading radius set karo.
4. **Data layers** — gameplay objects ko alag layers me rakho.

## Performance Results

| Feature | Result |
|---------|--------|
| World Partition | Huge map, controlled RAM |
| HLOD | Door ke objects sasta render |
| LOD | Smooth FPS |
| Nanite | High-poly detail bina lag |

## 💡 Infinite Replayability

Kyunki data tabhi load hota hai jab zaroorat hai:
- 10,000 kya, **1 lakh levels** bhi bana do.
- Game ka size aur RAM usage hamesha control me rahega.
