# Frustum & Occlusion Culling

## Core Idea

> "VR headset me jitna show hoga, utna hi load hoga — RAM kam lagegi."

Yeh game optimization ka sabse bada brahmastra hai.

## 1. Frustum Culling 👁

- Player ke do aankhein hain jinhe computer do **camera** ki tarah dekhta hai.
- Player ka ek nishchit dekhne ka daira hota hai (**Field of View**).

**Logic:** Agar player samundar ke kinare khada hokar Avatar 2 ki whales
🐋 dekh raha hai, to uske piche jo jungle, snakes 🐍 aur gufayein hain,
engine unhe **render (draw) karna band** kar deta hai.

**RAM par asar:** VRAM aur RAM par load **70% tak kam** — computer ko
sirf samne dikhne wali cheezon ke pixels banane padte hain.

## 2. Occlusion Culling 🧱

- Player kisi badi Atlantis ki deewar ya gufa ke saamne khada hai.
- Deewar ke paar ek bada tiger 🐅 ghum raha hai aur mango ke ped hain.
- Player deewar ke paar nahi dekh sakta → engine **har chhupi cheez ko
  temporarily hide/unload** kar deta hai.

**VR Fayda:** Player deewar ke kone se jhaankega → mili-second me cheezein
wapas dikhengi. Player ko pata nahi chalega, RAM bachi rahegi.

## 3. Max Draw Distance

- Snake ya tools ke Blueprint me limit set karo:
  `Max Draw Distance = 5000`
- Agar player snake se 50 meters se zyada door hai → snake physically
  **de-spawn** ho jayega.
- Paas aate hi wapas aa jayega.

## Optimization Impact

| Technique | Kya bachta hai | Impact |
|-----------|----------------|--------|
| Frustum Culling | Off-screen rendering | ~70% GPU/RAM saving |
| Occlusion Culling | Hidden objects | Heavy saving in caves/ruins |
| Max Draw Distance | Distant actors | CPU + RAM saving |

## UE5 Settings

- **World Partition** → automatic grid streaming.
- **HLOD** → door ke objects ka low-poly version.
- **LOD** → distance ke hisaab se detail kam.
- **Nanite** → high-poly assets efficiently render.
