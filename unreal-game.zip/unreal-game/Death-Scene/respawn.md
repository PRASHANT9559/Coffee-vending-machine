# Auto Respawn Loop (Bina Exit Ke)

## Requirement

- Game turant exit na ho.
- New start ka button na aaye.
- Death animation ke dauran background me **reload loop** chale.
- Animation khatam → player automatically respawn.

## Flow

```
Player health = 0
      ↓
Disable VR input (controllers off)
      ↓
Detach camera from mesh (floating +300 units)
      ↓
Boss plays "Cook_Seekh_Kabab_Sequence" (15 sec)
      ↓
Background: prepareProceduralLevelData(currentLevel)
      ↓
Animation complete
      ↓
respawnPlayerAtStartPoint()
      ↓
Game resumes — no button, no menu
```

## Backend Logic

```cpp
void onPlayerDefeated() {
    // 1. Player input block karo
    player.disableInput();

    // 2. Camera ko character se alag karke floating mode me daalo
    detachCameraFromMesh(player.headsetCamera, spawnHeight: "+300 units");

    // 3. Boss ka death animation trigger karo
    boss.playSequenceAnimation("Cook_Seekh_Kabab_Sequence");

    // 4. Hidden calculation: animation ke dauran level reload
    int currentLevel = game.currentLevel;
    prepareProceduralLevelData(currentLevel);

    // 5. Animation khatam → automatic respawn bina button
    startAnimationTimer(duration: "15 seconds", onComplete: () {
        respawnPlayerAtStartPoint();
    });
}
```

## Respawn Rules

- Same level dobara (procedural seed same → same layout).
- Player ke upgrades/pets retain.
- Boss health reset.
- Mission objectives reset.
- Cinematic skip option (comfort ke liye).

## Timer

| Phase | Duration |
|-------|----------|
| Death animation | 10–15 sec |
| Fade to black | 1 sec |
| Level prepare | Background |
| Respawn fade-in | 1 sec |

## VR Comfort

- Player ko input se pehle hi disable karo (falling sensation avoid).
- Camera fixed overhead.
- Skip button (optional) — repeated deaths par boring na ho.
- No sudden camera cuts.

## 💡 Revenge Loop

Player jab apni body ka kabab bante dekhega:
- Gussa aayega.
- Bina break liye agla round shuru karega.
- Sochega: *"Is baar isko chhodna nahi hai!"*

Yeh emotional loop game ka sabse strong retention hook hai.
