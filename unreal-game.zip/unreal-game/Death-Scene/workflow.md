# Death-Scene — Workflow

Player defeat hone par cinematic death + auto respawn ka flow.

```mermaid
flowchart TD
    A["Player health = 0"] --> B["Disable VR input"]
    B --> C["Camera detach +300 units<br/>out-of-body view"]
    C --> D["Boss grabs body"]
    D --> E["Carry to bioluminescent fire"]
    E --> F["Cook sequence 15 sec"]
    F --> G["Background: prepare level"]
    G --> H["Fade to black"]
    H --> I["Auto respawn at start"]
    I --> J["Same level + upgrades retained"]
    J --> K["Revenge loop"]
```

## Sequence Timing

| Phase | Duration |
|-------|----------|
| Knockout + camera shift | 2 sec |
| Boss action | 3 sec |
| Cook cinematic | 8 sec |
| Fade to black | 1 sec |
| Respawn fade-in | 1 sec |

## Rules

- No exit button, no menu.
- Input disabled immediately.
- Camera fixed overhead (motion sickness avoid).
- Upgrades/pets retained.
- Same level reload.

## Safety

- Neon blue/purple blood (red nahi).
- Skip button optional.
- No sudden loud jumpscares.

## Related

- [scene.md](scene.md)
- [respawn.md](respawn.md)
- [safety.md](safety.md)
