# Brutal Death Scene — Cinematic

## Concept

Agar user haar jata hai (giant beastman se), to game turant exit na ho
aur new start ka option na de.

Uski dead body ke saath beastman kuch bhayanak kare — jaise **seekh kabab
banakar khana** — taaki player ke dimaag par asar pade aur agli baar
jeetne ki aag + badla lene ki bhavna (revenge loop) paida ho.

## Reference

Mortal Kombat (Fatality moves) aur Resident Evil ke death animations.

## VR Death Scene Hierarchy

### Step 1 — Knockout & Camera Shift
- Player ki health 0 → character zameen par girta hai.
- Thik usi pal, VR camera player ke shareer se alag hokar **thoda upar**
  chala jata hai (jaise aatma shareer se alag ho gayi).
- Ab player upar se apni hi dead body dekh raha hai.
- **Out-of-Body Experience (Third-Person View Transition)** — motion
  sickness se bachne ka professional tareeqa.

### Step 2 — Beastman Ka Brutal Action
15-foot ka 4-Armed Giant Beastman hansta hua aage badhega:
1. Do hathon se dead body uthayega.
2. Khandahar building ke beech me jalte **Bioluminescent Fire** ke paas
   le jayega.
3. Teesre hath se lohe ki rod/spear 🗡 uthayega aur body ko uspar set
   karega.
4. Chouthe hath se jaadui masale chhidkega.
5. Aag ki laptein aur dhuan.

### Step 3 — Savage Finish & Fade to Black
- Beastman kabab ka piece tod kar muh me dalega.
- Dahaad marega.
- Camera (player) ki taraf dekh kar bolega:
  *"Maine kaha tha na insaan... tum sirf mera ek waqt ka khana ho!"*
- Dusra bite lene se pehle **smoke effect** → screen **black**.

## Camera Rules

- Player camera ko dead body ke saath mat ghumao (motion sickness).
- Fixed third-person overhead view.
- Cuts/teleports avoid karo — smooth transition.

## 💡 Safety Note

Blood/gore ko **neon blue ya glowing purple** rakho (Avatar/Journey theme).
Red blood realistic na dikhe — age rating aur comfort ke liye.

> Next: [respawn.md](respawn.md) — auto respawn loop.
