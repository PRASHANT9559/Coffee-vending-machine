# Death Scene — Safety & Ratings

## VR Safety Rules

1. **Motion Sickness:** Camera ko dead body ke saath mat ghumao.
2. **No Jumpscares in Death:** Sudden loud sounds avoid.
3. **Comfort Break:** Player ko pause/skip ka option.
4. **Duration:** Scene 15 sec se zyada lamba na ho.
5. **Input Disable:** Death par controllers disable.

## Gore Guidelines

| Element | Recommendation |
|---------|----------------|
| Blood color | Neon Blue / Glowing Purple (Avatar theme) |
| Gore level | Stylized, not realistic |
| Dismemberment | Minimal / implied |
| Cannibalism | Cinematic, not explicit |
| Sound | Aag, masale, roar — not gore sounds |

## Age Rating

- Realistic red blood = high age rating (Mature 17+).
- Stylized neon blood = Teen rating possible.
- Avatar/Journey theme ke saath **sci-fi/fantasy** feel better.

## Why Neon Blood?

- Game ki theme jaadui hai (Avatar + Journey 2).
- Red blood realistic aur ganda lagta hai.
- Neon blue/purple **cool aur dhasu** lagta hai.
- Photo-sensitive players ke liye bhi better.

## Mental Comfort

- Scene ko **cartoonish/cinematic** rakho.
- Player ko lage ki yeh game ka part hai, real nahi.
- Revenge motivation create karo, trauma nahi.

## Settings Menu

| Setting | Options |
|---------|---------|
| Gore Level | Low / Medium / Off |
| Cinematic Skip | On / Off |
| Screen Shake | Low / Medium / High |
| Comfort Mode | On / Off |

## Accessibility

- Colorblind-friendly indicators.
- Subtitles for dialogue.
- Seated/standing mode.
- Snap turn option.

## 💡 Golden Rule

> Player ko darr aur gussa feel karwao — lekin **respect** ke saath.
> Immersion kabhi discomfort na bane.
