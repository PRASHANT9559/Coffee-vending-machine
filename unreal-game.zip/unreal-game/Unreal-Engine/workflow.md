# Unreal-Engine — Setup Workflow

UE5 project ko VR game ke liye ready karne ka step-by-step flow.

```mermaid
flowchart TD
    A["Epic Games Launcher install"] --> B["Unreal Engine 5 install"]
    B --> C["New Project<br/>Game → VR Template"]
    C --> D["Enable Plugins<br/>OpenXR + Lumen + Nanite"]
    D --> E["Project Settings<br/>VR + Performance"]
    E --> F["Hardware check<br/>VRAM + SSD"]
    F --> G["VR headset connect + test"]
    G --> H{"90+ FPS?"}
    H -->|No| I["Optimize settings<br/>LOD + culling"]
    I --> H
    H -->|Yes| J["✅ Ready for development"]
```

## Steps

1. **Install UE5** via Epic Games Launcher.
2. **New Project** → Games → **VR Template**.
3. **Plugins enable:** OpenXR, Lumen, Nanite, World Partition.
4. **Project Settings:** Default map, VR comfort options, 90 FPS target.
5. **Hardware verify:** 32GB RAM, 12GB+ VRAM, NVMe SSD.
6. **Headset test:** Quest/Vive/Index connect karke template run karo.
7. **Baseline:** Empty scene me 90 FPS stable karo, phir content banao.

## Output

- VR-ready UE5 project.
- Stable 90 FPS baseline.
- OpenXR configured for multi-headset support.

## Related

- [intro.md](intro.md) — UE basics
- [features.md](features.md) — Nanite/Lumen
- [pc-requirements.md](pc-requirements.md) — hardware
- [vr-support.md](vr-support.md) — VR headsets
