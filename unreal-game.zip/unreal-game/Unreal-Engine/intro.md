# Unreal Engine Kya Hai?

Unreal Engine (UE) ek powerful **3D computer graphics game engine** hai, jise
**Epic Games** ne develop kiya hai.

Aasan shabdon me: yeh ek software/toolkit hai jahan developers, designers aur
animators milkar **video games, 3D animations aur movies** banate hain.

## History

- Shuruat me yeh sirf **first-person shooter games** ke liye bana tha
  (Unreal game, jahan se naam aaya).
- Aaj yeh lagbhag **har badi industry** me use hota hai — gaming, movies,
  automotive, architecture.

## Pricing / License

- Unreal Engine **free-to-use** hai creators aur animators ke liye.
- Epic Games royalty tabhi leta hai jab aapka game/product **$1 Million**
  ke upar commercial level par kamane lage.

## Why It Matters

| Cheez | Matlab |
|-------|--------|
| Free entry | Bina paise diye seekhna/shuru karna |
| Industry standard | Bade studios yahi use karte hain |
| Blueprint | Bina coding ke game logic |
| UE5 features | Nanite + Lumen se film-quality visuals |

> Next: [features.md](features.md) — Nanite, Lumen, Blueprint.
