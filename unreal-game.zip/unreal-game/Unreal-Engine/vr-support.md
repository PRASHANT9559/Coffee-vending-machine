# Unreal Engine Aur VR

UE (UE4/UE5) VR game development ke liye duniya me sabse popular aur trusted
tool hai.

## In-Built VR Template

UE open karte hi **"VR Template"** milta hai. Isme pehle se set hota hai:

- VR controller se cheezon ko **uthana (grabbing)**
- Ek jagah se dusri jagah **teleport**
- **Head-tracking** (gardan ghumaane par screen ghumna)

Aapko sab kuch zero se nahi banana padta.

## Supported Headsets

- Meta Quest (Quest 2, Quest 3, Quest Pro)
- HTC Vive
- Valve Index
- PlayStation VR2 (PSVR2)
- Apple Vision Pro (UE5 me support)

> **Tip:** OpenXR plugin use karo taaki ek hi game kai headsets par chale.

## UE Par Bane Mashhoor VR Games

- Robo Recall
- Batman: Arkham VR
- Star Wars: Squadrons (VR Mode)
- Medal of Honor: Above and Beyond

## VR Ke Liye 3 Zaroori Baatein

1. **Performance:** FPS 90/120 se kam = motion sickness (sir dard/chakkar).
2. **Optimization:** UE ke tools se graphics optimize karke smooth chalana.
3. **Comfort:** Camera movement, scale aur transitions carefully design karo.

## Popular vs Full Experience

| Category | Games |
|----------|-------|
| Sabse zyada popular | Beat Saber, Gorilla Tag |
| Full experience (story/AAA) | Half-Life: Alyx, Asgard's Wrath 2, The Walking Dead: Saints & Sinners |
| Physics sandbox | Boneworks / Bonelab |
| Action/Horror | Batman: Arkham Shadow, Resident Evil 4 VR |
