# UE5 PC Requirements

UE5 ek heavy software hai. Smooth kaam ke liye (khaas kar Lumen + Nanite)
tagda hardware chahiye.

## Minimum vs Recommended

| Component | Minimum (Seekhna/Basic) | Recommended (Smooth) |
|-----------|--------------------------|----------------------|
| OS | Windows 10/11 (64-bit) | Windows 11 (64-bit) |
| CPU | Intel Core i5 (9th/10th Gen) ya AMD Ryzen 5 (6 Cores) | Intel Core i7/i9 (13th/14th Gen) ya AMD Ryzen 7/9 (8–16 Cores) |
| RAM | 16 GB | 32 GB – 64 GB (DDR4/DDR5) |
| GPU | NVIDIA GTX 1060 / RTX 2060 ya AMD RX 580 | NVIDIA RTX 3070 / 4070 / 5060 Ti ya upar (Ray Tracing support) |
| VRAM | 6–8 GB | 12–16 GB (ya zyada) |
| Storage | 100 GB HDD / SATA SSD | 1–2 TB NVMe M.2 SSD (compulsory) |

## Components Kyun Matter Karte Hain?

- **CPU:** Scene banate waqt Shader Compilation hoti hai. Kam cores = zyada
  loading screens.
- **GPU + VRAM:** UE5 ke heavy visuals GPU par depend karte hain. 8GB se kam
  VRAM par bade scenes / Quixel Megascans load karte hi crash ho sakta hai.
  Smooth viewport ke liye **12GB VRAM** best.
- **RAM:** 16GB par UE khulta hai, lekin Photoshop/Blender/browser ke saath
  system lag karega. **32GB** aaj UE5 ka standard benchmark hai.
- **SSD vs HDD:** UE5 har second terabytes data stream karta hai. HDD par
  install mat karo — **NVMe M.2 SSD zaroori** hai.

## 💡 Pro Tip (Budget Setup)

RTX 3060 (12GB VRAM) + 32GB RAM = budget me sabse stable aur smooth
performance.
