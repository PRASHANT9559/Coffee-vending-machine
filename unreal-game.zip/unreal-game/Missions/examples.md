# Mission Examples & Variety

## Why Variety Matters

- Fixed mission = player ek strategy seekh kar sab levels paar kar leta hai.
- Random mission = har level par on-the-spot dimaag lagana padta hai.

## Mission Pool

### 1. The Rescue
- Na'vi child / baby animal ko snakes ke beech se safe zone tak lana.
- **Mechanic:** Physically uthana (VR grab), dushman ko avoid karna.

### 2. The Antique Hunter
- Sunken Nautilus submarine se purana compass lana.
- **Mechanic:** Underwater swimming + electric eel se bachna.

### 3. The Botanist
- Raat me floating mountain par rare Blue Mango todna.
- **Mechanic:** Climbing + night navigation + poison risk.

### 4. The Survival
- Time limit tak island par zinda rehna.
- **Mechanic:** Weather, predators, food/health management.

### 5. The Decoder
- Atlantis ruins ka math puzzle solve karna.
- **Mechanic:** Stone mechanism par equation ka answer dena.

### 6. The Hunt
- Specific aggressive animal ko harana.
- **Mechanic:** Combat + traps + pet assistance.

## Multi-Stage Example

1. Khazana mila → **locked** hai.
2. Lock kholne ke liye island ke random kone se **specific animal ka
   horn** lao.
3. Horn laate hi **boss spawn** ho jata hai.
4. Boss ko harao → diamond milega.

## Reward Types

| Reward | Example |
|--------|---------|
| Equipment | Glider Suit, Torch, Grappling Hook |
| Consumable | Health fruit, Poison antidote |
| Cosmetic | Skin, pet costume, emote |
| Progression | New beast body part upgrade |
