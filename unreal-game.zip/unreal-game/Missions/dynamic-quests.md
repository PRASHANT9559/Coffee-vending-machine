# Dynamic Quest System

## Problem

- Bina mission ke game 10–15 minute me boring ho jata hai.
- Agar mission hamesha "Go to building, get treasure" ho to maza pehli
  baar me hi khatam.

## Solution — Dynamic Quest System

Missions ko **procedural** (apne aap badalne wala) banao.
Unreal Engine me ise **Dynamic Quest System** kehte hain.

### Random Mission Generator

Game shuru hote hi engine 3 cheezon ko **mix-and-match** karega:

```
Mission Type + Target Item + Location
```

Isse har baar naya combination banega — jaise ludo me har baar alag
number aata hai.

## 3 Random Tables (Backend)

### 1. Random Location Spawning
- Poore map par **20–30 khali points** (`Target Actors` / `Spawn Points`)
  chhod do.
- Engine random number generate karega (e.g. 1 to 30).
- Number 5 aaya → khazana/snake/rescue target point 5 par spawn hoga.

### 2. Random Enemy Patrol
- Snakes aur bade animals ek jagah nahi rahenge.
- **NavMesh Bounds Volume** use karo.
- AI command: `Get Random Reachable Point in Radius`.
- Snake har match me island par randomly ghumega — kabhi samundar kinare,
  kabhi ped par.

### 3. Mission Type Array
- 5–6 base mission types: **Rescue, Collect, Survive, Decode, Hunt, Escort**.
- `Mission_Type = Level_Number % 5` se har level par target badlega.

## Multi-Stage Missions

Mission ko aur interesting banane ke liye conditions daalo:

- Khazana locked hai → lock kholne ke liye random kone se specific
  animal ka **horn** ya **khaas patthar** dhoondna hoga.
- Time limit: "Suraj doobne se pehle oxygen cylinder lekar aao, warna
  raat ko predators nikal aayenge."

## Reward / Attraction Factor

- **New Equipment Unlock:** Mushkil mission par "Glider Suit" ya
  "Torch/Flashlight" jo raat me snakes ko door bhagaye.
- **Visual reward:** VR me reward physically attractive hona chahiye.
