# Missions — Random Parts

Har mission ek random object hai jo kai parts se banta hai.
Yeh file batati hai ki mission ko kitne parts me divide kiya gaya hai.

## Mission Ke Parts

| Part | Type | Options / Range | Example |
|------|------|-----------------|---------|
| `Mission_Type` | Enum | Rescue, Collect, Survive, Decode, Hunt, Escort | Rescue |
| `Target_Item` | Enum | Apple, Mango, Blue Mango, Compass, Horn, Crystal, Na'vi child | Na'vi child |
| `Location_Zone` | Enum | Forest, Ocean, Cave, Floating Mountain, Ruins | Forest |
| `Spawn_Point_ID` | Integer | 1–30 | 5 |
| `Distance` | Float | 100–3000 units | 1200 |
| `Time_Limit` | Float | 0 (none) – 600 sec | 300 |
| `Enemy_Guard` | Enum | None, Snake, Crocodile, Boss | Snake |
| `Enemy_Count` | Integer | 0–20 | 8 |
| `Difficulty` | Enum | Easy, Normal, Hard, Extreme | Hard |
| `Reward_Type` | Enum | Equipment, Cosmetic, Consumable, XP | Equipment |
| `Reward_ID` | Integer | Random from pool | Glider Suit |
| `Is_Multi_Stage` | Boolean | True/False | True |
| `Stage_Count` | Integer | 1–3 | 2 |
| `Modifier` | Enum | None, Night, Poison, Storm | Night |

## Formula

```
Mission_Type  = Random Enum
Target_Item   = Random Enum
Spawn_Point   = Random(1, 30)
Difficulty    = Level_Number / 2000  (cap at Extreme)
Enemy_Count   = (Level_Number * 0.01) + Random(0, 5)
Time_Limit    = Difficulty == Easy ? 0 : Random(180, 600)
Is_Multi_Stage= Random(0, 1) && Level_Number > 100
```

## Example Instances

### Mission A — The Rescue (Hard)
```
Type: Rescue | Target: Na'vi child | Zone: Forest
Spawn: 5 | Enemies: 8 snakes | Time: 300s
Modifier: Night | Reward: Glider Suit
Stages: 2 (find child → carry to safe zone)
```

### Mission B — The Antique Hunter (Extreme)
```
Type: Collect | Target: Compass | Zone: Ocean
Spawn: 17 | Enemies: Electric Eel | Time: 420s
Modifier: Storm | Reward: Legendary Weapon
Stages: 1
```

### Mission C — The Botanist (Normal)
```
Type: Collect | Target: Blue Mango | Zone: Floating Mountain
Spawn: 22 | Enemies: 0 | Time: 0
Modifier: Night | Reward: Rare DNA
Stages: 1
```

## Balance Rules

- Pehle 100 levels: no time limit, easy enemies.
- 1000+: multi-stage + night modifier.
- 5000+: storm + extreme difficulty + boss guard.
- Reward rarity difficulty ke saath badhe.

## Related

- [workflow.md](workflow.md)
- [dynamic-quests.md](dynamic-quests.md)
- [random-generator.md](random-generator.md)
