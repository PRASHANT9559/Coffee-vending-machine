# Random Mission Generator — Logic

## Formula

```
Mission_Type = random(Rescue, Collect, Survive, Decode, Hunt)
Target_Item  = random(Apple, Mango, Blue Mango, Compass, Horn, Crystal)
Location     = random(Spawn_Point_1 ... Spawn_Point_30)
```

Har game start par teeno random → **unique mission**.

## Unreal Engine Logic

1. **Spawn Points:** Map par 20–30 empty Target Actors rakho.
2. **Random Integer in Range (1–30):** Location select.
3. **Random Enum:** Mission type select.
4. **Random Item from Array:** Target item select.
5. Mission UI me objective dikhao (3D marker + text).

## Example Generated Missions

### Mission 1 — The Rescue
> "Island ke dusri taraf ek Avatar ka bacha (Na'vi child) ghas ke beech
> fasa hai aur wahan bohot saare snakes ghum rahe hain. Use bina nuksan
> pahunchaye physically uthakar safe zone tak lana hai."

### Mission 2 — The Antique Hunter
> "Samundar ki gehrai me khoye hue Journey 2 wale Nautilus Submarine ke
> andar se ek purana compass dhoond kar lana hai, lekin raste me ek giant
> electric eel samundar me ghum rahi hai."

### Mission 3 — The Botanist
> "Island par achanak ajeeb bimari phaili hai. Aapko raat ke waqt
> (bioluminescent mode) sabse unche floating mountain par ja kar sabse
> rare chamakne wala Blue Mango tod kar lana hai taaki vaccine ban sake."

## Mission Components Table

| Component | Values |
|-----------|--------|
| Type | Rescue, Collect, Survive, Decode, Hunt, Escort |
| Target | Apple, Mango, Blue Mango, Compass, Horn, Crystal, Na'vi child |
| Location | Forest, Ocean, Cave, Floating Mountain, Ruins |
| Modifier | Time limit, Night mode, Poison risk, Boss guard |

## 💡 Takeaway

Jab mission system random hoga, player 100 baar bhi khelega to har baar
nayi story, naya khatra aur naya raasta milega.
