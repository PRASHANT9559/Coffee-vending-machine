# Missions — Workflow

Mission generate hone se reward milne tak ka poora flow.

```mermaid
flowchart TD
    A["Level start"] --> B["Mission seed = level number"]
    B --> C["Random Mission Type"]
    B --> D["Random Target Item"]
    B --> E["Random Spawn Point 1–30"]
    C --> F["Build mission object"]
    D --> F
    E --> F
    F --> G["Show objective marker + HUD"]
    G --> H["Player travels to location"]
    H --> I{"Objective complete?"}
    I -->|No| H
    I -->|Yes| J{"Multi-stage?"}
    J -->|Yes| K["Unlock next condition"]
    K --> H
    J -->|No| L["Reward grant"]
    L --> M["Save progress"]
    M --> N["Next level"]
```

## Mission Lifecycle

1. **Generate** — type + target + location.
2. **Assign** — HUD marker, text, voice-over.
3. **Track** — progress updates (0–100%).
4. **Complete/Fail** — time limit ya death.
5. **Reward** — equipment/cosmetic/XP.
6. **Save** — completed missions log.

## Multi-Stage Example

1. Khazana mila → locked.
2. Random corner se horn lao.
3. Horn laate hi boss spawn.
4. Boss harao → diamond.

## Related

- [dynamic-quests.md](dynamic-quests.md)
- [random-generator.md](random-generator.md)
- [examples.md](examples.md)
- [random-parts.md](random-parts.md)
