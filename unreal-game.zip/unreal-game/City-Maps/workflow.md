# City-Maps — Merge Workflow

4 alag city maps ko ek master open-world me merge karne ka flow.

```mermaid
flowchart TD
    A["4 alag .umap files"] --> B["Naya khali Master Map banao"]
    B --> C["Window → Levels"]
    C --> D["Levels dropdown → Add Existing"]
    D --> E["4 city maps add karo"]
    E --> F["Har city ko position/transform karo"]
    F --> G["Sub-maps se lights delete karo"]
    G --> H["Master map me ek Directional Light"]
    H --> I["Landscape edges match karo"]
    I --> J["Streaming distance set karo"]
    J --> K["Play mode me test"]
    K --> L{"Transitions smooth?"}
    L -->|No| F
    L -->|Yes| M["✅ Merged open world"]
```

## Step-by-Step

1. **Master map** banao — yeh Persistent Level hoga.
2. **Window → Levels** kholo.
3. **Add Existing** se charon `.umap` add karo.
4. Har city ko **move/transform** karke sahi jagah rakho.
5. Charon sub-maps se **light delete** karo, master me ek light rakho.
6. **Landscape** ke edges sculpt karke gaps bharo.
7. **Streaming distance** set karo (pop-in avoid).
8. Play mode me **City 1 → 2 → 3 → 4** transition test karo.

## UE5 Upgrade Path

World Composition ki jagah **World Partition** use karo — automatic
grid-based streaming.

## Related

- [merge-methods.md](merge-methods.md)
- [steps.md](steps.md)
- [precautions.md](precautions.md)
