# Merge Karte Waqt In Baaton Ka Dhyan Rakhein

## 1. Lighting Conflict ⚠
- Agar charon cities me alag-alag **Directional Light (suraj)** ya
  **Skylight** lagi hui hai, to merge par lighting kharab ho sakti hai.
- **Hal:** Charon sub-maps se light delete karo aur sirf Master
  (Persistent) Map me **ek single light source** rakho.

## 2. Landscape Coordinates
- Agar cities landscape (pahaad/jameen) par bani hain, to unke edges
  (kinare) aapas me milane padenge.
- Thodi **manual sculpting/editing** karni padegi taaki beech me gaddhe
  ya gaps na dikhein.

## 3. Streaming Distance
- Sub-levels ka loading distance set karo, warna player ko pop-in
  dikhega ya RAM overuse hogi.

## 4. World Settings
- Master map ke World Settings me composition/streaming settings
  verify karo.

## 5. UE5 Me Upgrade
- Future me UE5 use kar rahe ho to **World Partition** use karo —
  yeh automatic grid-based streaming karta hai aur manual sub-level
  management ki zaroorat kam ho jati hai.

## Checklist ✅

- [ ] Ek hi Directional Light (master map me)
- [ ] Landscape edges matched
- [ ] Har city ka streaming distance set
- [ ] Play mode me transitions test
- [ ] UE5 me World Partition consider kiya
