# Maps Merge Karne Ke Steps (UE4)

Agar aapke paas 4 alag-alag `.umap` files hain, to unhe merge karne ka
basic process:

## Step 1 — Naya Master Map Banayein
- Ek naya khali map banayein aur save kar lein.
- Isse **Persistent Level** kehte hain.

## Step 2 — Levels Window Kholein
- Top menu: **Window → Levels**
- Ek chhota Levels panel khulega.

## Step 3 — Purane Maps Add Karein
- Levels panel me **Levels** dropdown par click karein.
- **Add Existing...** select karein.
- Apni 4 city maps (`.umap` files) select karke add kar lein.

## Step 4 — Position Set Karein
- Charon cities ab master map me aa chuki hain.
- Levels window me kisi bhi city par **right-click → transform/move**.
- Cities ko sahi jagah set karein (City 1 khatam hote hi City 2 shuru ho).

## Step 5 — Test Karein
- Play mode me check karein ki transitions smooth hain.
- Streaming distance aur loading behaviour tune karein.

## Kaise Kaam Karta Hai?

Yeh charon cities ko alag-alag **Levels (Sub-levels)** ki tarah ek master
map (Persistent Level) ke andar jod deta hai.

**Fayda:** Player City 1 me ho to sirf City 1 load hoti hai. Aage badhne
par City 2 background me load hoti hai aur City 1 unload. PC par load nahi
padta, performance smooth rehti hai.
