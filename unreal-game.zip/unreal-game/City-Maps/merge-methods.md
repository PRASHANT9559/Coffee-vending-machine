# 4 City Maps Merge Karne Ke Tareeqe

UE4 me 4 alag-alag city maps ko **merge (combine)** kiya ja sakta hai.
Open-world games me yahi technique use hoti hai taaki PC/game crash na ho.

## Method 1: World Composition (Sabse Best)

- Charon cities badi hain aur bina lag ke ek bada open-world map chahiye
  to **World Composition** activate karo.
- Har city ek **sub-level** ban jaati hai.
- Player jis city me hai, sirf wahi load hoti hai; baaki background me
  stream hoti rehti hain.

## Method 2: Level Streaming (Manual)

- Charon cities ek hi bade world me dikhein, lekin load/unload aap control
  karo (jaise player gate par pahuche tabhi dusri city load ho).
- Triggers/Blueprint se level load-unload kar sakte hain.

## Comparison

| Feature | World Composition | Manual Level Streaming |
|---------|-------------------|------------------------|
| Setup | Automatic-ish | Manual triggers |
| Bade open world | ✅ Best | Thoda kaam zyada |
| Control | Engine handle karta hai | Aap poora control |
| Best for | 4 badi cities | Specific transitions |

## UE5 Note

UE5 me World Composition ki jagah **World Partition** aata hai, jo
automatic sab manage karta hai (grid-based streaming).

> Next: [steps.md](steps.md) — step-by-step merge guide.
