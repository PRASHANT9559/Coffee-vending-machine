# Tsunami & Land Shift (Cataclysm Levels)

## Concept

10,000 levels me se har **500th level** ek **"Cataclysm Level"
(Maha-toofan)** hoga.

## VR Experience

- Player VR headset pehan kar dekh raha hai:
  - Achanak samundar me ek **giant tsunami** uthti hai.
  - Poora island doob raha hai.
- Ab player ko bhagna nahi hai.
- Use **paani ke andar tairte hue** ya **flying mountains par koodte
  hue** zinda rehna hai.

## Optimization (Zero RAM Load)

- Isme naya map load nahi hoga.
- Sirf aapke paani ka level (**Water Height Vector**) automatic math
  formula se upar uthta chala jayega.
- Zameen apne aap paani ke andar doobti hui dikhegi.
- **RAM par zero load!**

## Backend Logic

```cpp
void triggerCataclysm(int levelNumber) {
    if (levelNumber % 500 == 0) {
        float waterHeight = 0.0;
        float targetHeight = 2000.0; // 20 meters

        // Smooth rise over 30 seconds
        while (waterHeight < targetHeight) {
            waterHeight += deltaTime * 66.6;
            setWaterLevel(waterHeight);
        }

        // Spawn debris, change animal behavior
        spawnFloatingDebris();
        makeAnimalsFlee();
    }
}
```

## Gameplay Changes

| Before | During Cataclysm |
|--------|------------------|
| Normal ground | Flooded |
| Land animals | Swimming/fleeing |
| Caves | Underwater |
| Snakes | Floating on debris |
| Player | Must swim/glide |

## Survival Mechanics

- **Oxygen meter** underwater.
- **Stamina** for swimming.
- **Glider suit** for mountain jumps.
- **Floating debris** as platforms.

## Visual Effects

- Giant wave mesh (Niagara).
- Water splash + spray.
- Screen droplets.
- Rumble haptics.
- Storm audio.

## 💡 Why It Works

- Har 500 level par ek **event** — player ko milestone feel hota hai.
- Bina naya map banaye **naya gameplay**.
- Streaming/social media par share karne layak moment.
