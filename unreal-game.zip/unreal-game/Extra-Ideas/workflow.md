# Extra-Ideas — Workflow

Bonus systems (DNA, living weapons, world memory, tsunami) ka integration
flow.

```mermaid
flowchart TD
    A["Hunt animal / boss"] --> B["DNA sample"]
    B --> C["Mutation Table"]
    C --> D["Craft living weapon"]
    C --> E["Upgrade Beastman"]
    A --> F["Save animal / plant tree"]
    F --> G["World memory update"]
    G --> H["Future help event"]
    G --> I["Echo zone / ghost"]
    J["Every 500th level"] --> K["Tsunami cataclysm"]
    K --> L["Water level rises"]
    L --> M["Swim / glide survival"]
    D --> N["Combat"]
    E --> N
    H --> N
    M --> N
    N --> O["Next level"]
```

## System Connections

| System | Input | Output |
|--------|-------|--------|
| DNA crafting | Animal/boss kill | New body part/weapon |
| Living weapons | Environment + DNA | Adaptive weapon |
| World memory | Player choices | Future events |
| Tsunami | Level % 500 | Survival event |

## Related

- [dna-crafting.md](dna-crafting.md)
- [living-weapons.md](living-weapons.md)
- [ecosystem-memory.md](ecosystem-memory.md)
- [tsunami.md](tsunami.md)
- [random-parts.md](random-parts.md)
