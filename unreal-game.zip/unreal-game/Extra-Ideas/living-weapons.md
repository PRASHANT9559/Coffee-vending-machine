# Symbiotic Weapons & Tools (Zinda Hathiyaar)

## Concept

Kyunki duniya Avatar jaisi jaadui hai, talwar ⚔ ya kulhaadi 🪓 lohe ki
hone ke bajaye island ke **zinda paudhon aur jaanwaron** se bani ho sakti
hai.

## Examples

### 1. Living Bow 🏹
- Ek aisi dhanush jo asal me ek **zinda parinda (bird)** hai.
- Jab aap nishana lagayenge → wo parinda khud ko **stretch** karega.
- Awaaz: bird screech.

### 2. Electric Eel Blade 🗡
- Paani ke andar weapon **electric eel** ban jata hai.
- Dushman ko shock deta hai.
- Underwater combat me bonus damage.

### 3. Plant Whip 🌿
- Zinda paudhe se bani whip.
- Dushman ko pakad kar kheenchi ja sakti hai.

### 4. Bioluminescent Shield 🛡
- Raat me glow karta hai.
- Andhere me visibility + defense.

## Adaptive Weapon Logic

```cpp
void updateWeaponForm(String environment, String beastType) {
    if (environment == "Underwater") {
        weapon.form = "Electric_Eel";
        weapon.damageType = "Shock";
    } else if (environment == "Night") {
        weapon.form = "Bioluminescent";
        weapon.glow = true;
    }

    // Beastman body color ke hisaab se weapon color
    weapon.color = player.bodyColor;
}
```

## Weapon Behavior

| Environment | Weapon Form | Effect |
|-------------|-------------|--------|
| Forest | Plant Whip | Grab + pull |
| Ocean | Electric Eel | Shock damage |
| Cave | Glowing Crystal Blade | Light + damage |
| Night | Bioluminescent | Visibility + style |
| Floating Mountain | Wind Bow | Long range |

## Crafting

- DNA + plant material + crystal.
- Mutation Table par craft.
- Upgrade levels 1–5.

## VR Interaction

- Living weapon **hilt se breath** karti hai (subtle animation).
- Player haath lagaye → weapon react kare.
- Attack par unique sound.

## 💡 Why It Fits

Avatar/Journey theme me **everything is alive** — weapons bhi zinda
honi chahiye. Yeh theme ko strong banata hai.
