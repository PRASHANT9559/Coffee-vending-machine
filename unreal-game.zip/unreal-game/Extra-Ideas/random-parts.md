# Extra-Ideas — Random Parts

DNA recipes, living weapons aur cataclysm events ke random parts.

## 1. DNA Recipe Ke Parts

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Recipe_ID` | Integer | Unique | R-07 |
| 2 | `DNA_1` | Enum | Snake, Eagle, Tiger, Shark, Cheetah, Crocodile | Snake |
| 3 | `DNA_2` | Enum | (same) | Eagle |
| 4 | `Output` | Enum | Wings, Claws, Armor, Vision, Speed | Flying Wings |
| 5 | `Rarity` | Enum | Common, Rare, Epic, Legendary | Epic |
| 6 | `Level_Required` | Integer | 1–10000 | 500 |
| 7 | `Craft_Time` | Float | 5–60 sec | 15 |
| 8 | `Success_Rate` | Float | 0.5–1.0 | 0.8 |
| 9 | `Visual_Effect` | Enum | None, Glow, Smoke, Sparks | Glow |

## 2. Living Weapon Ke Parts

| Part | Type | Options | Example |
|------|------|---------|---------|
| `Weapon_ID` | Integer | Unique | W-22 |
| `Base_Type` | Enum | Bow, Blade, Whip, Shield | Bow |
| `Living_Form` | Enum | Bird, Eel, Plant, Crystal | Bird |
| `Environment` | Enum | Forest, Ocean, Cave, Night | Ocean |
| `Damage_Type` | Enum | Slash, Shock, Poison, Light | Shock |
| `Glow` | Boolean | True/False | True |
| `Upgrade_Level` | Integer | 1–5 | 3 |

## 3. World Memory Parts

| Part | Type | Range | Example |
|------|------|-------|---------|
| `is_tiger_saved` | Boolean | True/False | True |
| `is_dolphin_saved` | Boolean | True/False | False |
| `snakes_killed` | Integer | 0–∞ | 245 |
| `trees_planted` | Integer | 0–∞ | 12 |
| `defeated_bosses` | Array | List | [B-99] |
| `discovered_caves` | Map | Bool per cave | Cave_3: True |

## 4. Cataclysm Event Parts

| Part | Type | Range | Example |
|------|------|-------|---------|
| `Trigger_Level` | Integer | Every 500 | 500 |
| `Water_Rise` | Float | 0–3000 units | 2000 |
| `Rise_Duration` | Float | 10–60 sec | 30 |
| `Debris_Count` | Integer | 10–100 | 40 |
| `Storm_Intensity` | Float | 0.5–1.0 | 0.9 |
| `Oxygen_Drain` | Float | 1–5x | 2.0 |

## Generation Formulas

```
// DNA recipe
Output = Combine(DNA_1, DNA_2)
Success_Rate = 0.5 + (Player_Level / 20000)  // cap 1.0

// Cataclysm
if (Level % 500 == 0):
    Water_Rise = RandomFloat(1500, 3000)
    Rise_Duration = RandomFloat(20, 45)
    Debris_Count = RandomInt(20, 80)
```

## Example Instances

### Recipe 1 — Flying Venomous Wings
```
DNA: Snake + Eagle | Output: Flying Wings
Rarity: Epic | Level: 500 | Craft: 15s
Success: 0.8 | Effect: Glow
```

### Weapon 1 — Electric Eel Bow
```
Base: Bow | Living: Eel | Environment: Ocean
Damage: Shock | Glow: True | Level: 3
```

### Cataclysm 1 — Level 500 Tsunami
```
Level: 500 | Water Rise: 2200 units
Duration: 30s | Debris: 45 | Storm: 0.9
Oxygen Drain: 2x
```

## Balance Rules

- DNA recipes Level 500+ me unlock.
- Living weapon environment ke hisaab se badle.
- World memory permanent — player choices matter.
- Cataclysm har 500th level, skip nahi.

## Related

- [workflow.md](workflow.md)
- [dna-crafting.md](dna-crafting.md)
- [living-weapons.md](living-weapons.md)
- [ecosystem-memory.md](ecosystem-memory.md)
- [tsunami.md](tsunami.md)
