# Genetic Mutation Crafting (DNA System)

## Concept

Beastman upgrades ke liye materials kahan se aayenge? Uska maza
**genetic crafting** me hai.

- Jab player kisi dushman (Giant Snake 🐍) ko haraata hai, ya kisi
  friendly Dolphin 🐬 ki madad karta hai → us se **DNA Sample (Essence)**
  milta hai.
- Player andheri gufaon me Atlantis ke purane **Biochemical Pools
  (Mutation Tables)** par jaakar DNAs ko mix kar sakta hai.

## DNA Combinations

| Combo | Result |
|-------|--------|
| Snake DNA + Eagle DNA | Level 3 Flying Venomous Wings |
| Tiger DNA + Crocodile DNA | Armored Claws |
| Cheetah DNA + Banshee DNA | Sky Runner (speed + glide) |
| Shark DNA + Turtle DNA | Aquatic Armor |
| Eagle DNA + Snake DNA | Night Vision + Poison Bite |

## VR Interaction

- Player physically ek **syringe (sui)** se DNA nikaalta hai.
- Use machine me daalta hai.
- Machine me bubbling VFX + sound.
- Upgrade complete → haptics + glow.

## Crafting Flow

```
Hunt Animal
    ↓
Collect DNA Sample (syringe)
    ↓
Bring to Mutation Table (Atlantis cave)
    ↓
Combine 2+ DNA samples
    ↓
Check recipe match
    ↓
New body part / upgrade unlock
```

## Recipe Table (Database)

| Column | Type | Example |
|--------|------|---------|
| `Recipe_ID` | Integer | R-07 |
| `DNA_1` | String | Snake |
| `DNA_2` | String | Eagle |
| `Output` | String | Flying_Venomous_Wings |
| `Required_Level` | Integer | 3 |
| `Rarity` | String | Rare |

## Why It Works

- Upgrade karne ki ek solid **wajah (mission)** mil jati hai.
- Player ko hunt/craft/explore ka loop milta hai.
- Har animal ka value badh jata hai.

## 💡 Player Psychology

"DNA collect karna" = collection loop. Players sab kuch collect karna
chahte hain — yeh retention badhata hai.
