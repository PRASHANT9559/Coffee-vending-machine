# Customization — Random Parts

Cosmetic drops aur random skin generation ke parts.

## 1. Skin Ke Parts

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Skin_ID` | Integer | Unique | 501 |
| 2 | `Owner` | Enum | Character, Pet | Character |
| 3 | `Theme` | Enum | Survival, Na'vi, Explorer, Cyberpunk, Golden | Na'vi |
| 4 | `Primary_Color` | Color | Random / themed | Blue |
| 5 | `Secondary_Color` | Color | Random / themed | Teal |
| 6 | `Pattern` | Enum | Tribal, Neon, Camo, Solid | Tribal |
| 7 | `Material` | Enum | Cloth, Leather, Metal, Bioluminescent | Bioluminescent |
| 8 | `Glow` | Boolean | True/False | True |
| 9 | `Unlock_Type` | Enum | Free, Game, Paid | Game |
| 10 | `Rarity` | Enum | Common, Rare, Epic, Legendary | Epic |
| 11 | `Price` | Float | 0–19.99 | 0 |
| 12 | `Level_Required` | Integer | 0–10000 | 2000 |

## 2. Emote Ke Parts

| Part | Type | Options | Example |
|------|------|---------|---------|
| `Emote_ID` | Integer | Unique | 88 |
| `Type` | Enum | Dance, Taunt, Fear, Greeting, Pet | Dance |
| `Duration` | Float | 1–10 sec | 4 |
| `Body_Part` | Enum | Full, Hands, Head | Full |
| `Pet_Sync` | Boolean | True/False | True |
| `Sound` | String | Music/SFX | Tribal_Drum |

## 3. Random Loot Drop Formula

```
On boss kill / level clear:
  rarity = WeightedRandom(Common 50%, Rare 30%, Epic 15%, Legendary 5%)
  itemType = RandomEnum(Skin, Emote, PetSkin)

  if (rarity == Legendary):
      item = RandomLegendaryFromPool()
  else:
      item = RandomFromRarityPool(rarity)
```

## Example Drops

### Drop 1 — Bioluminescent Na'vi Outfit
```
Owner: Character | Theme: Na'vi | Colors: Blue/Teal
Pattern: Tribal | Material: Bioluminescent | Glow: True
Unlock: Game | Rarity: Epic | Level: 2000
```

### Drop 2 — Mecha Tiger Skin
```
Owner: Pet | Theme: Cyberpunk | Colors: Grey/Red
Pattern: Neon | Material: Metal | Glow: True
Unlock: Paid | Rarity: Legendary | Price: 9.99
```

### Drop 3 — Victory Dance
```
Type: Dance | Duration: 4s | Body: Full
Pet Sync: True | Sound: Tribal_Drum
Rarity: Rare
```

## Balance Rules

- Paid items **cosmetic only** — pay-to-win nahi.
- Legendary drop 5% se zyada nahi.
- Level 1000+ par Epic/Legendary chance badhe.
- Seasonal items limited time.

## Related

- [workflow.md](workflow.md)
- [skins.md](skins.md)
- [emotes.md](emotes.md)
- [animations.md](animations.md)
