# VR Emotes System

VR me emotes ka maza button dabane se zyada **body gestures** se aata hai.

## Emote Types

### 1. The Victory Dance 🕺
- Mushkil level clear hone par player aur pet dono saath
  **Fortnite/Avatar style tribal dance** karenge.

### 2. The Fear Emote 😨
- Saamne giant snake ya crocodile 🐊 aa jaye.
- Character darr ke maare kaanpne lagega.
- Pet apna sir chhupa lega.

### 3. The Pet Interaction 🤝
- Pet ko high-five (✋) dena.
- Gale lagana (hug).
- Treat/fruit dena.

### 4. Taunt / Provoke 😈
- Boss ke saamne dance ya taunt.
- Boss ka gussa badhta hai → aggressive attack.

## VR Gesture Mapping

| Gesture | Emote |
|---------|-------|
| Dono haath upar | Victory |
| Haath kaanpna | Fear |
| Haath aage | High-five |
| Haath ghumana | Dance |
| Fist shake | Taunt |

## Emote System Backend

```cpp
class GameCharacter {
    String currentDressID;
    String currentEmoteID;
    String movementState;

    void triggerEmote(String emoteID) {
        playAnimation(emoteID);
        if (hasPet) pet.playSyncedEmote(emoteID);
    }
}
```

## Synced Emotes

- Player + pet ka emote **same time** par sync hoga.
- VR me dono ko saath dekhna emotional connection badhata hai.

## Unlock System

- Starting emotes: 3 free.
- Level milestones par naye emotes.
- Seasonal/paid emotes.

## 💡 Social Feature

Multiplayer me do players ek saath dance kar sakte hain — virality
badhane ke liye strong hook.
