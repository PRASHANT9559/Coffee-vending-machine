# Skins & Dress System (Character + Pet)

Free-to-Play (F2P) + Premium RPG model — Fortnite, PUBG, Free Fire jaisa.

## Unlock Types

Database me ek `Unlock_Type` column hoga:

| Type | Matlab | Example |
|------|--------|---------|
| **Free / Default** | Shuruat se available | Basic survival clothes, tattered pants, normal shirt |
| **Game-Unlocked** | Khelne par milega | Level 1000/5000 par "Avatar-Style Na'vi Outfit", "Journey 2 Explorer Suit" |
| **Paid / Premium** | Paise de kar | Cyberpunk suit, Golden Armor, Mecha-Tiger, Dog sunglasses + jacket |

## Pet Skins

- **Free:** Normal brown dog 🐕, normal orange tiger 🐅.
- **Game-Unlocked:** "Bioluminescent Glow Armor" (raat me chamkega).
- **Paid:** Mecha-Tiger (lohe ka robot tiger).

## Skin Schema

| Column | Type | Example |
|--------|------|---------|
| `Skin_ID` | Integer | 501 |
| `Owner` | String | Character / Pet |
| `Unlock_Type` | String | Free / Game / Paid |
| `Rarity` | String | Common / Rare / Legendary |
| `Luminescent` | Boolean | True/False |
| `Price` | Float | 0 / 4.99 / 9.99 |

## Retention Hook

- Level 2000 par tiger ke liye **"Neon Fire Skin"** unlock hogi.
- Player 0 se 10,000 tak ka safar poora karna chahega.

## Earning Potential

- Game procedural hai → size chhota → log aasani se download karenge.
- Paid dresses + premium emotes se acchi earning.

## 💡 Fair Monetization

- Sirf **cosmetic** items paid rakho.
- Pay-to-win nahi — gameplay sabke liye equal.
- Seasonal skins + battle pass model.
