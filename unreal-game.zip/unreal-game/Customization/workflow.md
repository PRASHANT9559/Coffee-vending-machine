# Customization — Workflow

Skin/emote unlock aur apply hone ka flow.

```mermaid
flowchart TD
    A["Player profile load"] --> B["Inventory check"]
    B --> C{"Skin owned?"}
    C -->|No| D["Store / Level reward"]
    D --> E{"Unlock type?"}
    E -->|Free| F["Auto add"]
    E -->|Game| G["Level / boss reward"]
    E -->|Paid| H["Purchase"]
    F --> I["Inventory"]
    G --> I
    H --> I
    I --> J["Player selects skin"]
    J --> K["Apply mesh + material"]
    K --> L["Character / Pet updated"]
    L --> M["Emote trigger"]
    M --> N["Synced animation<br/>Character + Pet"]
```

## Unlock Types

| Type | Source |
|------|--------|
| Free | Default inventory |
| Game | Level 1000/5000, boss drop |
| Paid | Store purchase |

## Apply Flow

1. Inventory me item check.
2. Mesh + material swap (async).
3. Character/pet update.
4. Save profile.

## Emote Flow

1. Player gesture/button.
2. Animation play.
3. Pet synced emote.
4. Haptic feedback.

## Related

- [skins.md](skins.md)
- [emotes.md](emotes.md)
- [animations.md](animations.md)
- [random-parts.md](random-parts.md)
