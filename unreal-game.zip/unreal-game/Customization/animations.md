# Animation State Machine

Game smooth lagne ke liye **Animation State Machine** zaroori hai. Yeh
player ki speed aur direction ke hisab se automatic animation badalta hai.

## Character Animations

### Locomotion
- **Idle** — shant khada hona
- **Walk** — chalna
- **Run** — bhaagna
- **Stop** — brake lagna (mitti udne ka effect)

### Directional
- **Left Run / Right Run** — leaning animation jab player mudega.

### Vertical
- **Jump Start** — koodna
- **Jump Loop** — hawa me rehna
- **Land** — zameen par girna

### Survival Actions
- 🪓 Kulhaadi chalana
- ⚔ Talwar chalana
- 🍍 Fruit khana
- 🏊 Paani me tairna

## Pet Animations (Dog 🐕 / Tiger 🐅)

- **Follow** — player ke piche bhaagna, mudna, rukna (same speed).
- **Alert** — ghaas me khatra dekh kar khada hona, kaan khade karna,
  ishaara karna.
- **Attack / Defend** — dushman par jhapatna, kaatna.
- **Hurt** — zakhmi hone par karahna (whimper).

## Animation Blueprints

Dono ke liye alag-alag **Animation Blueprints**:

| Blueprint | Kya handle karega |
|-----------|-------------------|
| `ABP_Character` | Player locomotion, combat, survival |
| `ABP_Pet` | Follow, alert, attack, hurt |

## State Transition Logic

```cpp
void triggerMovementAnimation(String state) {
    if (state == "Stop") {
        playAnimation("Run_To_Stop_Transition");
        spawnParticleEffect("Dust_Cloud"); // pairon ke paas mitti
    }
}
```

## Speed-Based Blending

- Speed > 300 → Run animation
- Speed 100–300 → Walk
- Speed < 100 → Idle
- Direction change par leaning blend.

## VR Considerations

- Player ke haath/head movement ko animation se match karo.
- Camera shake kam rakho (motion sickness).
- Scale change par transition animation + VFX.
