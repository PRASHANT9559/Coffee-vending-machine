# Database — Workflow

Data table se random entity spawn hone tak ka flow.

```mermaid
flowchart TD
    A["FAnimalData Struct banao"] --> B["Fields define: Color, Size,<br/>Behavior, Zone, etc."]
    B --> C["Data Table banao"]
    C --> D["Random generator activate"]
    D --> E["Har field ke liye random value"]
    E --> F["Runtime par row generate"]
    F --> G["Spawn Actor<br/>Animal Blueprint"]
    G --> H["Master Controller schema padhta hai"]
    H --> I["Mesh + Material + Scale apply"]
    I --> J["AI Behavior apply"]
    J --> K["Player interaction"]
    K --> L{"Death / Tame?"}
    L -->|Death| M["Loot + DNA drop"]
    L -->|Tame| N["Pet ban jata hai"]
```

## Data Layer Rules

1. **Struct** = columns (schema).
2. **Data Table** = rows (instances).
3. **Random generator** = runtime row creation.
4. **Master controller** = ek hi script, sab animals ke liye.
5. **Naya animal** = bas table me row add — naya code nahi.

## Why Data-Driven?

- 100 animals ke liye 100 scripts nahi.
- Ek master controller sab handle karta hai.
- Balance change karna easy (table edit).
- Save file chhoti (sirf seed + state).

## Related

- [animal-schema.md](animal-schema.md)
- [tools.md](tools.md)
- [zones.md](zones.md)
- [random-parts.md](random-parts.md)
