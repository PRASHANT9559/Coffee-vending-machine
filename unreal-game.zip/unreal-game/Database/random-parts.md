# Database — Random Entity Parts (Master Schema)

Yeh file batati hai ki koi bhi random cheez (animal, tool, prop) kitne
parts me divide hoti hai. Har part ka apna data type, range aur gameplay
effect hai.

## 1. Animal — Full Part Breakdown

| # | Part | Type | Options / Range | Example |
|---|------|------|-----------------|---------|
| 1 | `Animal_ID` | Integer | Unique | 1042 |
| 2 | `Animal_Type` | Enum | Snake, Bird, Banshee, Direhorse, Fish | Snake |
| 3 | `Species` | Enum | Cobra, Viper, Python, Anaconda | Cobra |
| 4 | `Primary_Color` | Color | Random RGB | Crimson Red |
| 5 | `Secondary_Color` | Color | Random RGB | Black |
| 6 | `Pattern` | Enum | Stripes, Spots, Scales, None | Stripes |
| 7 | `Length` | Float | 0.5–15 meters | 6.5 |
| 8 | `Thickness` | Float | 0.1–1.5 meters | 0.4 |
| 9 | `Head_Style` | Enum | Viper, Cobra_Hood, Python, Dragon | Cobra_Hood |
| 10 | `Eye_Color` | Color | Random | Neon Yellow |
| 11 | `Eye_Glow` | Boolean | True/False | True |
| 12 | `Fang_Size` | Float | 0.0–0.5 | 0.2 |
| 13 | `Scale_Texture` | Enum | Smooth, Rough, Spiky | Smooth |
| 14 | `Tail_Type` | Enum | Normal, Rattle, Spiked | Rattle |
| 15 | `Movement_Style` | Enum | Slither, Sidewind, Climb | Slither |
| 16 | `Size_Scale` | Float | 0.2–5.0 | 4.5 |
| 17 | `Health` | Float | 10–5000 | 1200 |
| 18 | `Speed` | Float | 100–1200 | 450 |
| 19 | `Behavior_State` | Enum | Aggressive, Friendly, Scared | Aggressive |
| 20 | `Poison_Type` | Enum | None, Nerve_Damage, Slow_Motion | Nerve_Damage |
| 21 | `Sound_Pitch` | Float | 0.5–2.0 | 0.5 |
| 22 | `Luminescent_Intensity` | Float | 0.0–10.0 | 0.0 |
| 23 | `Place_Zone` | Enum | Forest, Ocean, Cave, Floating Mountain | Cave |
| 24 | `Is_All_Rounder` | Boolean | True/False | False |
| 25 | `Diet_Preference` | Enum | Fruits, Player, Other_Animals | Player |
| 26 | `Rarity` | Enum | Common, Rare, Epic, Legendary | Rare |
| 27 | `Tameable` | Boolean | True/False | False |
| 28 | `Loot_Drop` | String | Meat, DNA, Scale | DNA |

## 2. Snake Generation Formula

```
Length        = RandomFloat(0.5, 15.0) * Size_Scale
Thickness     = Length * RandomFloat(0.03, 0.10)
Head_Style    = RandomEnum(Viper, Cobra_Hood, Python, Dragon)
Primary_Color = RandomRGB()
Pattern       = RandomEnum(Stripes, Spots, Scales, None)
Speed         = 300 + (Level_Number * 0.1) * Size_Scale
Health        = 100 * Size_Scale * (1 + Level_Number/1000)
Behavior      = RandomEnum(Aggressive, Friendly, Scared)
Poison        = Aggressive ? RandomEnum(Nerve, Slow, None) : None
```

## 3. Example Instances

### Snake 1 — The Cave Nightmare
```
Species: Python | Color: Crimson Red | Pattern: Stripes
Length: 8.0m | Thickness: 0.6m | Head: Dragon
Eyes: Neon Red (Glow) | Fangs: 0.4 | Tail: Spiked
Size: 4.5 | Health: 1200 | Speed: 450
Behavior: Aggressive | Poison: Nerve_Damage
Sound: 0.5 (Heavy) | Glow: 0.0 | Zone: Cave
Rarity: Epic | Tameable: No
```

### Snake 2 — The Glowing Guide
```
Species: Viper | Color: Neon Pink | Pattern: None
Length: 0.8m | Thickness: 0.05m | Head: Viper
Eyes: Cyan (Glow) | Fangs: 0.05 | Tail: Normal
Size: 0.3 | Health: 50 | Speed: 200
Behavior: Friendly | Poison: None
Sound: 1.8 (Squeaky) | Glow: 8.0 | Zone: Anywhere
Rarity: Rare | Tameable: Yes
```

### Snake 3 — The Giant Anaconda
```
Species: Anaconda | Color: Matte Black | Pattern: Scales
Length: 14.0m | Thickness: 1.4m | Head: Python
Eyes: Yellow | Fangs: 0.5 | Tail: Normal
Size: 5.0 | Health: 5000 | Speed: 700
Behavior: Aggressive | Poison: Slow_Motion
Sound: 0.5 | Glow: 0.0 | Zone: Swamp
Rarity: Legendary | Tameable: No
```

## 4. Other Entity Types

| Entity | Parts |
|--------|-------|
| **Tool** | Type, damage, durability, material, rarity, craft cost |
| **Fruit** | Type, effect, scale, glow, poison, duration |
| **Prop** | Type, color, scale, glow, breakable |
| **Pet** | Species, breed, color, size, ability, loyalty, rarity |

## 5. Balance Rules

- Size_Scale 5.0 = boss-level animal, rare spawn.
- Friendly + glow = night guide (high value).
- Aggressive + poison = maximum danger.
- Rarity level ke saath badhe (Level 1000+ me Epic/Legendary zyada).

## Related

- [workflow.md](workflow.md)
- [animal-schema.md](animal-schema.md)
- [tools.md](tools.md)
- [zones.md](zones.md)
- [../animals/data-schema.md](../animals/data-schema.md)
- [../animals/snake/random_combination.md](../animals/snake/random_combination.md)
