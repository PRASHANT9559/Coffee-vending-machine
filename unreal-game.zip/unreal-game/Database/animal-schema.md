# Master Animal Schema (Database Concept)

Database engineering me ise **Object-Oriented Structure** ya **Schema Design**
kehte hain.

Jaise user table me columns hote hain, waise hi 3D animals ke liye ek
**Master Blueprint Structure (Data Table)** banega.

Game start hote hi random function chalega, har column ke liye random value
generate karega, aur uske mutabik animal map par spawn hoga.

## Animal Schema Table

| Column | Data Type | Example / Logic | Gameplay Impact |
|--------|-----------|-----------------|-----------------|
| `Animal_ID` | Integer | Unique ID (e.g. 1042) | Engine ko pehchanne ke liye |
| `Animal_Type` | String | Snake, Bird, Banshee, Direhorse | Kaun sa 3D model load karna hai |
| `Color` | Color/Vector | Random RGB (Neon Blue, Matte Black) | Material ka color |
| `Size_Scale` | Float | 0.2 (Tiny) – 5.0 (Giant) | VR me size aur vazan |
| `Is_All_Rounder` | Boolean | True (poore map par) / False (ek ilake me) | Patrol radius |
| `Place_Zone` | String | Forest, Ocean, Floating_Mountain, Caves | Kahan spawn hoga |
| `Behavior_State` | String | Aggressive, Passive/Friendly, Scared | Kaatega, dost banega, ya bhagega |
| `Poison_Type` | String | None, Nerve_Damage, Slow_Motion | Snake ke katne par effect |
| `Sound_Pitch` | Float | 0.5 (Heavy bass) – 2.0 (Squeaky) | Giant = sher jaisi awaaz, chhota = patli |
| `Luminescent_Intensity` | Float | 0.0 (Normal) – 10.0 (Tez glow) | Avatar mode me kitna chamkega |
| `Diet_Preference` | String | Fruits, Player, Other_Animals | Khane ka behaviour |

## UE5 Implementation

### 1. Structs
- `FAnimalData` naam ka struct banao.
- Saari fields add karo (Color, Size, Is_All_Rounder, etc.).
- Yeh database ke rows/columns jaisa hai.

### 2. Data Tables
- Struct ka use karke **Data Table** banao.
- Random function game load hote hi rows runtime par generate karega.

## Example Instances (Level 752)

### Instance 1 — The Cave Nightmare
```
Type: Snake | Color: Crimson Red | Size: 4.5 (Giant)
Is_All_Rounder: False | Place: Caves | Behavior: Aggressive
Sound_Pitch: 0.5 (Heavy)
```

**VR Experience:** Gufa me andhere me bhari phuphkaar. Saamne giant laal
snake — dekhte hi jaan lene daudega.

### Instance 2 — The Glowing Guide
```
Type: Snake | Color: Neon Pink | Size: 0.3 (Tiny)
Is_All_Rounder: True | Place: Anywhere | Behavior: Friendly
Luminescent_Intensity: 8.0
```

**VR Experience:** Raat me chhota neon pink snake chamakta hua paas aayega.
Kaatne ke bajaye haath par lipat kar andhere raste dikhayega.

## 💡 100x Boost

- Data lock nahi, properties me baanta hai → computer lakhon unique
  animals generate kar sakta hai.
- Har animal ke liye alag animation/programming nahi — sirf **ek master
  animal controller** jo schema padh kar roop badle.
- Bade RPGs (No Man's Sky, Cyberpunk) isi approach ka use karte hain.
