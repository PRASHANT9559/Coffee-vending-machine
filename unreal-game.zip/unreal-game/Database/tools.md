# Tools, Weapons & Survival Gear (Player Items Table)

Saare items player map se **dhoond sakta hai (Collect)** ya resources jama
karke **khud bana sakta hai (Craft)**.

## Mining & Crafting Tools

| Item | Kaam |
|------|------|
| ⛏ Pickaxe | Patthar todna, gufaon me rare minerals/crystals nikalna |
| ⚒ Hammer / Mallet | Base banana, cheezein repair, crafting bench |
| 🪚 Hand Saw | Lakdi ko shape dena, planks banana |
| 🪓 Axe | Ped kaat kar wood jama karna (survival ka basic tool) |

## Combat & Self-Defense

| Item | Kaam |
|------|------|
| ⚔ Dual Swords | Tezi se hamla, aggressive land animals se ladna |
| 🗡 Dagger / Knife | Chhupa kar rakhna, paani ke andar snake par jaldi attack |
| 🛡 Shield | Bade animals ke heavy attacks block (VR me dusre haath se) |
| 🏹 Bow & Arrow | Door se bird/dushman par silent nishana |

## Light & Navigation (Raat Ke Liye)

| Item | Kaam |
|------|------|
| 🔦 Flashlight | Andheri gufaon me door tak dekhna (battery limit) |
| 🕯 Candle | Shuruat me thodi roshni (barish me bujh jayegi) |
| 🧭 Compass | 10,000 levels ke jungle/samundar me direction |

## Item Schema (Suggested)

| Column | Type | Example |
|--------|------|---------|
| `Item_ID` | Integer | 204 |
| `Item_Type` | String | Tool / Weapon / Light |
| `Damage` | Float | 25.0 |
| `Durability` | Float | 100.0 |
| `Craft_Material` | String | Wood + Stone |
| `Rarity` | String | Common / Rare / Legendary |

## VR Interaction

- Pickaxe/axe ko **physically swing** karna hoga.
- Shield ko dusre haath se uthana hoga.
- Bow ko physically kheenchna hoga.
- Candle/flashlight ko haath me pakad kar raaste dikhane honge.

## Loot Logic

```
If (Player_Needs_Light) -> random loot [🔦, 🕯, 🧭]
If (Zone == "Cave")     -> random loot [⛏, 💎, 🪓]
If (Zone == "Forest")   -> random loot [🪚, 🏹, 🍎]
```
