# Spawn Zones & Placement Logic

## Zone-Based Spawning

Har animal ka ek `Place_Zone` column hai. Random function animal ko sirf
usi zone ke coordinates par spawn karega.

### Zones

| Zone | Description | Animals |
|------|-------------|---------|
| **Forest** | Jungle, ped, ghaas | 🐍 Snake, 🐊 Crocodile, 🐕 Dog, 🐅 Tiger |
| **Ocean** | Samundar, shallow + deep | 🦈 Shark, 🐬 Dolphin, 🐙 Octopus, 🐢 Turtle |
| **Floating_Mountain** | Unche tairte patthar | 🦅 Eagle, Banshee, Ikran |
| **Caves** | Andheri gufayein | 🐍 Giant Snake, 🦇 Bats, 💎 Crystal |
| **Ruins** | Atlantis ke khandar | Boss, traps, rare loot |

## Algorithm

```
If (Spawn_Zone == "Ocean") -> Randomly select from [🦈, 🐬, 🐙, 🐢, 🐡]
If (Spawn_Zone == "Land")  -> Randomly select from [🐍, 🐊]
If (Spawn_Zone == "Sky")   -> Randomly select from [🦅, Banshee]
If (Player_Needs_Light)    -> Randomly generate loot [🔦, 🕯, 🧭]
```

## Placement Rules

1. **Water animals** sirf water volume ke andar spawn honge.
2. **Land animals** NavMesh ke reachable points par.
3. **Flying animals** air volume me.
4. **Cave animals** sirf cave bounds ke andar.
5. Har zone me **minimum/maximum count** set karo taaki performance aur
   balance bana rahe.

## Is_All_Rounder Column

- `True` → poore map par ghoom sakta hai (e.g. friendly neon snake).
- `False` → sirf apne `Place_Zone` me rahega (e.g. cave giant snake).

## Dynamic Ecosystem

- Predator vs Prey: bada bird snake ko utha kar le ja sakta hai.
- Agar player ne kisi animal ko bachaya → `is_tiger_saved = true` →
  future me wahi animal help kar sakta hai.
- Zone me animal count random → har match alag ecosystem.
