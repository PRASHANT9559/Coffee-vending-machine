# Game Workflow — Mysterious Avatar Island

> Yeh file poore game ka **flow** dikhati hai — start se end tak.
> Diagrams **Mermaid** me hain. GitHub, VS Code (Markdown Preview Mermaid),
> Obsidian aur GitLab me render ho jayenge.

---

## 📑 Workflow Index

1. [High-Level Game Loop](#1-high-level-game-loop)
2. [Game Boot / Start Flow](#2-game-boot--start-flow)
3. [Procedural Level Generation](#3-procedural-level-generation)
4. [Mission Generation](#4-mission-generation)
5. [Core Gameplay Loop](#5-core-gameplay-loop)
6. [Boss Fight + Adaptive AI](#6-boss-fight--adaptive-ai)
7. [Death & Respawn Loop](#7-death--respawn-loop)
8. [Beastman Upgrade Flow](#8-beastman-upgrade-flow)
9. [System Architecture](#9-system-architecture)
10. [Optimization / Streaming](#10-optimization--streaming)
11. [Time & Weather Sync](#11-time--weather-sync)
12. [Pet System Flow](#12-pet-system-flow)

---

## 1. High-Level Game Loop

Player game start karta hai → level generate hota hai → mission milta hai →
explore/survive/craft → boss → reward → next level. Yeh loop 10,000 levels
tak chalta hai.

```mermaid
flowchart TD
    A["🎮 Game Start"] --> B["⚙️ Settings: Time Mode + Difficulty"]
    B --> C["🌍 Sync Real-World Time / Weather"]
    C --> D["🧬 Generate Level<br/>Seed = Level Number"]
    D --> E["📜 Random Mission Generate"]
    E --> F["🏝️ Explore + Survive + Craft"]
    F --> G{"Mission Complete?"}
    G -->|No| F
    G -->|Yes| H["⚔️ Boss Fight"]
    H --> I{"Player Wins?"}
    I -->|No| J["💀 Death Cinematic<br/>Auto Respawn"]
    J --> F
    I -->|Yes| K["💎 Loot + Diamond + Upgrade"]
    K --> L{"Level 10,000?"}
    L -->|No| M["Level + 1"]
    M --> D
    L -->|Yes| N["🏆 Endgame / New Game+"]
```

**Key rule:** Har level ka seed = level number. Isliye same level dobara
khelne par same layout milega, lekin agla level bilkul naya hoga.

---

## 2. Game Boot / Start Flow

Game start hote hi sabse pehle **time/weather system** decide karta hai ki
din hoga ya raat. Internet na ho to PC clock fallback.

```mermaid
flowchart TD
    A["Player launches game"] --> B{"Time Mode?"}
    B -->|Manual| C["Apply user selected Day/Night"]
    B -->|Auto| D{"Internet available?"}
    D -->|Yes| E["Fetch OpenWeatherMap API"]
    E --> F["Set sun angle + weather + clouds"]
    D -->|No| G["Use PC system time"]
    G --> H["Default clear weather"]
    F --> I["Apply Sky Atmosphere + Lumen"]
    H --> I
    C --> I
    I --> J["Load player profile"]
    J --> K["Load last 5 boss fight records"]
    K --> L["Generate procedural level"]
```

**Fail-safe:** API fail ho ya internet jaye → game rukta nahi, PC time par
switch ho jata hai. Detail: [Real-Time-Sync/fallback.md](Real-Time-Sync/fallback.md)

---

## 3. Procedural Level Generation

Level number se poora island math se generate hota hai — koi saved map
file nahi.

```mermaid
flowchart TD
    A["Level Number N"] --> B["Random Stream<br/>Seed = N"]
    B --> C["Map Layout<br/>X/Y coordinates"]
    B --> D["Snake Count<br/>N * 0.05 + 3"]
    B --> E["Snake Speed<br/>Base + N * 0.1"]
    B --> F["Mission Type<br/>N % 5"]
    B --> G["Difficulty<br/>1 + N / 1000"]
    C --> H["Spawn terrain + ruins + caves"]
    D --> I["Spawn animals + tools + fruits"]
    E --> I
    F --> J["Assign mission objective"]
    G --> I
    H --> K["✅ Level Ready"]
    I --> K
    J --> K
```

**Difficulty bands:**

| Levels | Name | Mood |
|--------|------|------|
| 1–100 | The Dawn | Sunny, calm |
| 100–1000 | The Explorer | Adventure |
| 1000–5000 | Pandora Shift | Night, magical |
| 5000–10000 | Extreme Survival | Storm, chaos |
| Every 500th | Cataclysm | Tsunami |

Detail: [Levels/10k-levels.md](Levels/10k-levels.md) +
[Levels/formulas.md](Levels/formulas.md)

---

## 4. Mission Generation

Har level par **Mission Type + Target Item + Location** ka random
combination banta hai.

```mermaid
flowchart TD
    A["New Level Start"] --> B["Pick Mission Type"]
    A --> C["Pick Target Item"]
    A --> D["Pick Spawn Point 1–30"]
    B --> E["Combine all three"]
    C --> E
    D --> E
    E --> F["Show 3D objective marker"]
    F --> G["Player completes objective"]
    G --> H{"Multi-stage?"}
    H -->|Yes| I["Next condition<br/>Key item / Boss / Time limit"]
    I --> G
    H -->|No| J["Reward<br/>Equipment / Cosmetic / XP"]
    J --> K["Next Level"]
```

**Mission types:** Rescue, Collect, Survive, Decode, Hunt, Escort.
Detail: [Missions/dynamic-quests.md](Missions/dynamic-quests.md)

---

## 5. Core Gameplay Loop

Island par player ke paas har waqt kuch na kuch karne ko hota hai —
explore, eat, fight, tame, craft.

```mermaid
flowchart TD
    A["Enter Island"] --> B["Explore"]
    B --> C["Find Fruits / Resources"]
    B --> D["Encounter Animals"]
    B --> E["Discover Caves / Ruins"]
    C --> F["Eat Fruit<br/>Giant / Tiny / Poison"]
    D --> G{"Animal Behavior?"}
    G -->|Aggressive| H["Combat or Flee"]
    G -->|Friendly| I["Feed → Tame Pet"]
    G -->|Scared| J["Hunt or Ignore"]
    E --> K["Mining + Crafting"]
    H --> L["Health / Loot"]
    I --> M["Pet Abilities"]
    J --> L
    K --> N["Better Tools / Weapons"]
    F --> L
    L --> O["Mission Progress"]
    M --> O
    N --> O
    O --> P{"Boss Mission?"}
    P -->|Yes| Q["Boss Fight"]
    P -->|No| B
```

**Size Inversion:** Bada mango = 15 ft giant, chhota apple = 1 ft ant.
Detail: [Game-Concept/size-inversion.md](Game-Concept/size-inversion.md)

---

## 6. Boss Fight + Adaptive AI

Boss player ki pichli **5 fights** yaad rakhta hai aur uske hisaab se
counter strategy banata hai.

```mermaid
sequenceDiagram
    participant P as Player
    participant E as Game Engine
    participant B as Beastman Boss
    participant AI as Learning Brain

    P->>E: Enter boss room
    E->>AI: Load last 5 fight records
    AI->>AI: Analyze weapon + side + win speed
    AI-->>B: Counter strategy + 4 weapons
    B->>P: Taunt dialogue + roar + haptics
    P->>B: Fight (dodge, attack, pet assist)
    B->>P: Counter attacks
    alt Player wins
        B->>E: Boss death
        E->>P: Diamond + loot + Victory Dance
        E->>AI: Save new fight record
    else Player loses
        E->>P: Death cinematic
        E->>E: Auto respawn same level
    end
```

**Counter examples:**

| Player Pattern | Boss Counter |
|----------------|--------------|
| Bow/ranged spam | Shield + hyper aggressive charge |
| Right-side attacks | Right hand heavy shield |
| Sword close combat | Defensive counter + axe |
| Pet assistance | AoE attacks to separate pet |

Detail: [Boss-Fight/combat.md](Boss-Fight/combat.md) +
[Adaptive-AI/counter-strategy.md](Adaptive-AI/counter-strategy.md)

---

## 7. Death & Respawn Loop

Player haarta hai to game exit nahi hota, menu nahi aata — ek cinematic
death scene chalti hai aur player automatically respawn ho jata hai.

```mermaid
flowchart TD
    A["Player Health = 0"] --> B["Disable VR input"]
    B --> C["Detach camera +300 units<br/>Out-of-body view"]
    C --> D["Boss plays Cook Sequence<br/>15 seconds"]
    D --> E["Background:<br/>prepare level data"]
    E --> F["Fade to black"]
    F --> G["Auto respawn at start point"]
    G --> H["Same level<br/>upgrades retained"]
    H --> I["🔥 Revenge loop continues"]
```

**Safety:** Realistic gore nahi — blood **neon blue / glowing purple**
(Avatar theme). Detail: [Death-Scene/scene.md](Death-Scene/scene.md) +
[Death-Scene/respawn.md](Death-Scene/respawn.md)

---

## 8. Beastman Upgrade Flow

Player animal/boss ko harata hai → DNA collect karta hai → Mutation Chamber
me body part upgrade karta hai.

```mermaid
flowchart TD
    A["Defeat animal / boss"] --> B["Collect DNA Sample"]
    B --> C["Enter Mutation Chamber"]
    C --> D["Select body part"]
    D --> E{"Enough resources?"}
    E -->|No| F["Go farming"]
    F --> A
    E -->|Yes| G["Mutation VFX + haptics"]
    G --> H["Swap mesh<br/>Skeletal Mesh Merge"]
    H --> I["Recalculate stats"]
    I --> J["New playstyle unlocked"]
```

**Body parts:**

| Part | Beast | Power |
|------|-------|-------|
| Hands | Tiger / Bear | Claw attacks, fast mining |
| Legs | Cheetah / Kangaroo | +150% speed, high jump |
| Eyes | Eagle / Snake | Night vision + heat scan |
| Skin | Crocodile / Rhino | +300% defense, poison resist |
| Back | Banshee / Falcon | Gliding / flying |

Detail: [Beastman/body.md](Beastman/body.md) +
[Beastman/work.md](Beastman/work.md)

---

## 9. System Architecture

Sabhi systems aapas me kaise jude hain.

```mermaid
flowchart LR
    VR["🎮 VR Controllers<br/>+ Headset"] --> LS["🧬 Level Seed Manager"]
    VR --> INV["🎒 Inventory + Crafting"]
    VR --> PET["🐕 Pet Controller"]

    LS --> QS["📜 Quest Generator"]
    LS --> AI["🧠 Adaptive Boss AI"]
    LS --> WP["🗺️ World Partition"]

    QS --> DT["📊 Animal Data Table"]
    AI --> BOSS["⚔️ Boss Schema"]
    PET --> DT
    INV --> SK["👕 Skin / Emote Table"]

    DT --> SAVE["💾 Save Profile"]
    BOSS --> SAVE
    SK --> SAVE

    WP --> LUM["💡 Lumen + Sky Atmosphere"]
    WP --> AUD["🔊 Spatial Audio"]
    WP --> HAP["📳 Haptics"]

    SAVE --> NEXT["➡️ Next Level"]
```

**Data-driven design:** Naya animal, skin ya boss weapon add karna ho to
sirf table me row add karo — code change nahi.

---

## 10. Optimization / Streaming

Sirf wahi load hota hai jo player dekh sakta hai — isliye 10,000 levels
bhi RAM me fit hote hain.

```mermaid
flowchart TD
    A["Player Position"] --> B["World Partition Grid"]
    B --> C["Load 4–5 nearby cells"]
    B --> D["Unload far cells"]
    C --> E["Frustum Culling"]
    E --> F["Occlusion Culling"]
    F --> G{"Distance > Max Draw?"}
    G -->|Yes| H["De-spawn actor"]
    G -->|No| I["Render with LOD / HLOD"]
    I --> J["✅ 90+ FPS VR"]
    H --> J
```

**Result:** RAM ~70% saving, low-end PC support, infinite replayability.
Detail: [Optimization/culling.md](Optimization/culling.md) +
[Optimization/world-partition.md](Optimization/world-partition.md)

---

## 11. Time & Weather Sync

Real-world time/weather game ke andar directly affect karta hai.

```mermaid
flowchart LR
    A["📍 Player Location<br/>Ayodhya, India"] --> C["🌐 Weather API"]
    B["🕐 System Time"] --> C
    C --> D["Sun Angle<br/>+ Clouds + Rain"]
    D --> E{"Night?"}
    E -->|Yes| F["🌌 Bioluminescence ON<br/>Snake difficulty 2x"]
    E -->|No| G["☀️ Clear Day<br/>Normal difficulty"]
    F --> H["Gameplay"]
    G --> H
```

**Example:** Raat 12 baje khelo → island par ghor andhera, toofan,
aggressive predators. Dopahar me khelo → shant, saaf island.

Detail: [Real-Time-Sync/api-sync.md](Real-Time-Sync/api-sync.md) +
[Real-Time-Sync/modes.md](Real-Time-Sync/modes.md)

---

## 12. Pet System Flow

Pet tame karna, feed karna, command dena aur combat me use karna.

```mermaid
flowchart TD
    A["Encounter wounded / hungry animal"] --> B{"Feed or Attack?"}
    B -->|Attack| C["Kill → Loot"]
    B -->|Feed| D["Taming chance"]
    D --> E{"Tamed?"}
    E -->|No| F["Animal runs away"]
    E -->|Yes| G["Pet joins player"]
    G --> H["Follow + Alert + Attack"]
    H --> I{"Pet injured?"}
    I -->|Yes| J["Feed fruit / fish<br/>Restore health + loyalty"]
    I -->|No| K["Pet ability active"]
    J --> H
    K --> L["Combat / Scout / Navigation"]
    L --> M["Mission success"]
```

**Pet types:** Dog (scent), Tiger (combat), Eagle (scout), Dolphin
(sea navigation). Detail: [Pets/pet-types.md](Pets/pet-types.md) +
[Pets/taming.md](Pets/taming.md) +
[Pets/commands.md](Pets/commands.md)

---

## 🔗 Related Docs

| Topic | File |
|-------|------|
| Complete index | [README.md](README.md) |
| Game concept | [Game-Concept/overview.md](Game-Concept/overview.md) |
| Procedural levels | [Levels/10k-levels.md](Levels/10k-levels.md) |
| Database schema | [Database/animal-schema.md](Database/animal-schema.md) |
| Boss system | [Boss-Fight/schema.md](Boss-Fight/schema.md) |
| Performance | [Optimization/performance.md](Optimization/performance.md) |

---

## 📝 Mermaid Rendering Note

- **GitHub:** Automatic render.
- **VS Code:** Markdown Preview Mermaid Support extension.
- **Obsidian:** Built-in support.
- **CLI:** `mmdc` (Mermaid CLI) se PNG/SVG export kar sakte ho.

```bash
# Example: workflow diagram export
npx @mermaid-js/mermaid-cli -i docs/workflow.md -o workflow.png
```
