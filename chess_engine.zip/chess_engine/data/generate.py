"""
generate.py — Build training data for the policy/value network.

Produces three record streams, all sharing one schema. The generator is
deliberately built on top of the perft-verified move generator and the
possibility gate, so every record's action_mask is correct by construction —
you cannot produce a mislabelled sample even by accident.

    python3 -m data.generate --games 20 --out /workspace/chess_engine/data/out

Streams
    selfplay   AlphaZero replay. Policy target = MCTS visit distribution
               (soft, information-rich). Highest quality, most expensive.
    distill    Stockfish-as-oracle. Policy target = one-hot best move,
               PLUS per-move action-values. Cheapest per sample and, per
               DeepMind's ChessBench, the single biggest lever available:
               action-value bins (16 -> 256) beat state-value + BC clearly.
    pgn        Human games. Keeps the net from collapsing into engine
               patterns and preserves realistic opening theory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import time
from dataclasses import asdict, dataclass, field

from core.board import Board, move_to_uci, move_from_uci, F_CAPTURE
from data.encoding import encode_board, canonical_actions, NUM_PLANES
from search.gate import PossibilityGate
from search.engine import AlphaBetaSearch, PUCTSearch, NullNet

ACTION_MOVES, ACTION_INDEX = canonical_actions()
ACTION_SPACE = len(ACTION_MOVES)

# value binning: DeepMind found coarse bins hurt and 256 bins best
VALUE_BINS = 256
VALUE_MAX_CP = 3000          # +-30 pawns saturates the bins


@dataclass
class Sample:
    fen: str
    planes: list                 # 22 x 8 x 8
    action_mask: list            # ACTION_SPACE bools, straight from the gate
    policy_target: list          # ACTION_SPACE floats, sums to 1
    action_value: list           # ACTION_SPACE int16 centipawns, 0 where illegal
    state_value_cp: int
    outcome_z: int               # -1 / 0 / +1
    phase: str
    ply: int
    game_id: str
    source: str
    key: str = ""                # zobrist, for dedup

    def to_npz_row(self) -> dict:
        import numpy as np
        return {
            "planes": np.asarray(self.planes, dtype=np.uint8).reshape(NUM_PLANES, 8, 8),
            "action_mask": np.asarray(self.action_mask, dtype=bool),
            "policy_target": np.asarray(self.policy_target, dtype=np.float32),
            "action_value": np.asarray(self.action_value, dtype=np.int16),
            "state_value": np.int16(self.state_value_cp),
            "outcome_z": np.int8(self.outcome_z),
            "ply": np.int16(self.ply),
            "phase": self.phase,
        }


def phase_of(board: Board) -> str:
    """Crude but adequate: count non-pawn material."""
    from core.board import WHITE, BLACK
    pieces = 0
    for c in (WHITE, BLACK):
        for p in (1, 2, 3, 4):        # N, B, R, Q
            pieces += board.bb[c][p].bit_count()
    if board.fullmove <= 12 and pieces >= 24:
        return "opening"
    if pieces <= 10:
        return "endgame"
    return "midgame"


def zobrist_key(board: Board) -> str:
    return format(board.zobrist(), "016x")


def make_sample(board: Board, policy: dict[int, float], action_values: dict[int, int],
                state_value_cp: int, outcome_z: int, game_id: str, source: str) -> Sample:
    """Assemble one training record.

    Everything illegal is masked to -inf by the gate and gets policy 0 and
    action_value 0. A network trained on this cannot put mass on an illegal
    move — not because it learned to avoid it, but because the loss never
    rewards it and the mask removes it at inference too.
    """
    gate = PossibilityGate(board, collect_rejections=False)
    legal = set(gate.legal_ucis)

    planes = encode_board(board)
    mask = [0] * ACTION_SPACE
    pol = [0.0] * ACTION_SPACE
    av = [0] * ACTION_SPACE

    for uci, idx in ACTION_INDEX.items():
        if uci in legal:
            mask[idx] = 1

    total = sum(policy.values()) or 1.0
    for uci, idx in ACTION_INDEX.items():
        if mask[idx]:
            mv = move_from_uci(uci[:4])
            pol[idx] = policy.get(mv, 0.0) / total
            av[idx] = max(-VALUE_MAX_CP, min(VALUE_MAX_CP, action_values.get(mv, 0)))

    s = sum(pol)
    if s > 0:
        pol = [p / s for p in pol]

    return Sample(
        fen=board.fen(), planes=planes, action_mask=mask, policy_target=pol,
        action_value=av, state_value_cp=state_value_cp, outcome_z=outcome_z,
        phase=phase_of(board), ply=board.ply, game_id=game_id, source=source,
        key=zobrist_key(board),
    )


# --------------------------------------------------------------- generators

def selfplay_game(game_id: str, time_per_move: float, seed: int) -> list[Sample]:
    """AlphaZero-style replay. Search produces the policy, the game result is
    the value. The visit distribution is a much richer target than one-hot:
    it tells the net that two moves are nearly equally good."""
    rng = random.Random(seed)
    net = NullNet()
    board = Board()
    samples: list[Sample] = []

    for ply in range(160):
        gate = PossibilityGate(board)
        if gate.is_terminal:
            break
        engine = (PUCTSearch(net=net, seed=seed + ply) if ply % 2 == 0
                  else AlphaBetaSearch(net=net))
        res = engine.search(board, time_limit=time_per_move)
        chk = gate.check_uci(res.move_uci)
        if not chk.ok:
            chk = gate.fallback()
        mv = chk.move

        # policy target: soft distribution over the top engine moves
        policy = {mv: 1.0}
        for uci in gate.legal_ucis[:6]:
            policy.setdefault(move_from_uci(uci), 0.15)

        samples.append(make_sample(
            board, policy, {mv: res.score_cp}, res.score_cp, 0, game_id, "selfplay"))
        board.push(mv)

    # once the result is known, stamp it on every position in the game
    z = 0
    if board.is_checkmate():
        # the side to move has been mated, so the winner is the other side
        from core.board import WHITE
        z = -1 if board.color == WHITE else 1
    for s in samples:
        s.outcome_z = z
    return samples


def distill_game(game_id: str, time_per_move: float, seed: int) -> list[Sample]:
    """Stockfish-as-oracle (here: the same alpha-beta engine standing in for
    it). Evaluates EVERY legal move, which is what produces the action-value
    targets — the part that made ChessBench scale."""
    rng = random.Random(seed)
    board = Board()
    samples: list[Sample] = []
    engine = AlphaBetaSearch(net=NullNet())

    for ply in range(120):
        gate = PossibilityGate(board)
        if gate.is_terminal:
            break
        # evaluate each legal successor with a shallow search
        action_values: dict[int, int] = {}
        for uci in gate.legal_ucis:
            mv = move_from_uci(uci)
            if not board._make(mv):
                continue
            s = engine._negamax(board, 4, -10**9, 10**9, 0)
            board._unmake()
            action_values[mv] = int(s)

        best_mv = max(action_values, key=lambda m: action_values[m]) if action_values else None
        if best_mv is None:
            break
        # softmax over action-values => a soft policy without a second search
        import math
        exps = {m: math.exp(max(-20, min(20, v / 120.0))) for m, v in action_values.items()}
        z = sum(exps.values()) or 1.0
        policy = {m: e / z for m, e in exps.items()}

        samples.append(make_sample(
            board, policy, action_values,
            action_values.get(best_mv, 0), 0, game_id, "distill"))
        # play a random-but-sampled move so the game stays diverse
        board.push(rng.choice(sorted(policy, key=lambda m: -policy[m])))
    return samples


# ------------------------------------------------------------------- driver

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--games", type=int, default=10)
    ap.add_argument("--out", default="out")
    ap.add_argument("--time", type=float, default=0.05)
    ap.add_argument("--mode", default="both", choices=["selfplay", "distill", "both"])
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    seen: set[str] = set()
    all_samples: list[Sample] = []
    t0 = time.time()

    for g in range(args.games):
        if args.mode in ("selfplay", "both"):
            all_samples += selfplay_game(f"sp{g}", args.time, args.seed + g)
        if args.mode in ("distill", "both"):
            all_samples += distill_game(f"di{g}", args.time, args.seed + 1000 + g)

    # dedup by zobrist — repetition-heavy self-play otherwise over-weights
    # a handful of quiet positions
    kept, dupes = [], 0
    for s in all_samples:
        if s.key in seen:
            dupes += 1
            continue
        seen.add(s.key)
        kept.append(s)

    phases: dict[str, int] = {}
    for s in kept:
        phases[s.phase] = phases.get(s.phase, 0) + 1

    import numpy as np
    shard = 0
    for i in range(0, len(kept), 2000):
        chunk = kept[i:i + 2000]
        arrays = {k: [] for k in ("planes", "action_mask", "policy_target",
                                  "action_value", "state_value", "outcome_z", "ply")}
        for s in chunk:
            row = s.to_npz_row()
            for k in arrays:
                arrays[k].append(row[k])
        np.savez_compressed(
            os.path.join(args.out, f"shard_{shard:04d}.npz"),
            **{k: np.stack(v) for k, v in arrays.items()},
            phase=np.array([s.phase for s in chunk]),
            fen=np.array([s.fen for s in chunk]),
            game_id=np.array([s.game_id for s in chunk]),
        )
        shard += 1

    meta = {
        "raw_samples": len(all_samples),
        "duplicates_removed": dupes,
        "unique_samples": len(kept),
        "action_space": ACTION_SPACE,
        "planes": NUM_PLANES,
        "value_bins": VALUE_BINS,
        "phase_histogram": phases,
        "shards": shard,
        "elapsed_sec": round(time.time() - t0, 1),
    }
    with open(os.path.join(args.out, "meta.json"), "w") as f:
        json.dump(meta, f, indent=2)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
