"""
encoding.py — Board and action encoding for the policy/value network.

Two independent encodings are provided because two different papers use two
different action spaces, and picking the wrong one silently costs you Elo:

  * ACTION_4672 — 8 x 8 x 73, the AlphaZero (Silver et al.) layout. 56
    queen-like planes + 8 knight planes + 9 underpromotion planes. Simple,
    dense, and what most reimplementations use.

  * canonical ~1880 — the reduced space used by DeepMind's ChessBench and by
    the small self-play nets. Deduplicates symmetric moves. Smaller output
    head, measurably better on a small net. Build it with canonical_actions().

The single most important property of BOTH, and the reason this file sits
downstream of the possibility gate: the action space is a fixed enumeration of
SYNTACTICALLY possible moves. It deliberately contains moves that are illegal
in the current position. AlphaZero never trained the net to avoid them; it
masked them at inference. The gate is that mask, made authoritative.
"""

from __future__ import annotations

from core.board import (
    Board, move_to_uci, WHITE, BLACK,
    PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
    F_PROMO, F_CAPTURE, F_EP, F_CASTLE,
    PROMO_TO_PIECE,
)

# ---------------------------------------------------------------- board planes

NUM_PLANES = 22

# plane index map (documented so the dataset spec and the net cannot drift)
PLANE = {
    "w_pawn": 0, "w_knight": 1, "w_bishop": 2,
    "w_rook": 3, "w_queen": 4, "w_king": 5,
    "b_pawn": 6, "b_knight": 7, "b_bishop": 8,
    "b_rook": 9, "b_queen": 10, "b_king": 11,
    "side_to_move": 12,          # 1.0 if BLACK to move
    "castle_wk": 13, "castle_wq": 14, "castle_bk": 15, "castle_bq": 16,
    "en_passant": 17,            # 1.0 on the ep target square only
    "repetition": 18,            # 1.0 if this position occurred before
    "halfmove": 19,              # 50-move counter / 100, replicated
    "fullmove_norm": 20,         # move number / 200, replicated
    "in_check": 21,              # 1.0 if side to move is in check
}

PIECE_ORDER = [PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING]


def encode_board(board: Board) -> list[list[list[float]]]:
    """board -> 22 x 8 x 8 float planes, little-endian rank 1 at row 0."""
    planes = [[[0.0] * 8 for _ in range(8)] for _ in range(NUM_PLANES)]

    for colour, base in ((WHITE, 0), (BLACK, 6)):
        for i, kind in enumerate(PIECE_ORDER):
            bb = board.bb[colour][kind]
            while bb:
                s = (bb & -bb).bit_length() - 1
                bb &= bb - 1
                planes[base + i][s >> 3][s & 7] = 1.0

    planes[PLANE["side_to_move"]][0][0] = 1.0 if board.color == BLACK else 0.0

    from core.board import CR_WK, CR_WQ, CR_BK, CR_BQ
    for bit, name in ((CR_WK, "castle_wk"), (CR_WQ, "castle_wq"),
                      (CR_BK, "castle_bk"), (CR_BQ, "castle_bq")):
        planes[PLANE[name]][0][0] = 1.0 if board.castling & bit else 0.0

    if board.ep >= 0:
        planes[PLANE["en_passant"]][board.ep >> 3][board.ep & 7] = 1.0
    if any(k == board.zobrist() for k in board.keys[:-1]):
        planes[PLANE["repetition"]][0][0] = 1.0
    planes[PLANE["halfmove"]][0][0] = min(board.halfmove, 100) / 100.0
    planes[PLANE["fullmove_norm"]][0][0] = min(board.fullmove, 200) / 200.0
    planes[PLANE["in_check"]][0][0] = 1.0 if board.in_check() else 0.0
    return planes


def decode_board_fen(planes) -> str:
    """Round-trip helper used by the dataset test. Reconstructs a FEN and
    compares it to the source — catches plane-layout drift immediately."""
    from core.board import _SQ_NAMES
    rows = []
    for r in range(7, -1, -1):
        row, empty = "", 0
        for f in range(8):
            pc = "."
            for colour, base in ((WHITE, 0), (BLACK, 6)):
                for i, name in enumerate("PNBRQK"):
                    if planes[base + i][r][f] == 1.0:
                        pc = name if colour == WHITE else name.lower()
            if pc == ".":
                empty += 1
            else:
                if empty:
                    row += str(empty); empty = 0
                row += pc
        if empty:
            row += str(empty)
        rows.append(row)
    side = "b" if planes[PLANE["side_to_move"]][0][0] == 1.0 else "w"
    castle = "".join(c for k, c in (("castle_wk", "K"), ("castle_wq", "Q"),
                                    ("castle_bk", "k"), ("castle_bq", "q"))
                     if planes[PLANE[k]][0][0] == 1.0) or "-"
    ep = "-"
    for r in range(8):
        for f in range(8):
            if planes[PLANE["en_passant"]][r][f] == 1.0:
                ep = _SQ_NAMES[r * 8 + f]
    return f"{'/'.join(rows)} {side} {castle} {ep} 0 1"


# ------------------------------------------------------------- action 4672

NUM_ACTION_PLANES = 73
ACTION_SPACE = 8 * 8 * NUM_ACTION_PLANES      # 4672

# 8 compass directions, index 0..7, as (d_rank, d_file).
# d_rank is +1 toward rank 8, i.e. White's forward.
DIRECTIONS = [(1, 0), (1, 1), (0, 1), (-1, 1),
              (-1, 0), (-1, -1), (0, -1), (1, -1)]

KNIGHT_DELTAS = [(2, 1), (2, -1), (1, 2), (1, -2),
                 (-1, 2), (-1, -2), (-2, 1), (-2, -1)]   # planes 56..63

# planes 64..72: forward-rook, forward-knight, forward-bishop,
#                capture-left x3, capture-right x3
UNDERPLANE = {
    ("fwd", "rook"): 64, ("fwd", "knight"): 65, ("fwd", "bishop"): 66,
    ("left", "rook"): 67, ("left", "knight"): 68, ("left", "bishop"): 69,
    ("right", "rook"): 70, ("right", "knight"): 71, ("right", "bishop"): 72,
}


def encode_action(board: Board, mv: int) -> int | None:
    """Packed move -> action index in [0, 4672). None if unencodable."""
    frm, to = mv & 0x3F, (mv >> 6) & 0x3F
    fr, ff = frm >> 3, frm & 7
    tr, tf = to >> 3, to & 7
    dr, df = tr - fr, tf - ff
    promo = (mv & F_PROMO) != 0
    promo_piece = PROMO_TO_PIECE[(mv >> 12) & 3] if promo else None
    fwd = 1 if board.color == WHITE else -1

    # pawn underpromotion takes the dedicated planes
    if promo and promo_piece != QUEEN:
        if df == 0:
            key = ("fwd", {ROOK: "rook", KNIGHT: "knight", BISHOP: "bishop"}[promo_piece])
        else:
            side = "left" if df == fwd else "right"
            key = (side, {ROOK: "rook", KNIGHT: "knight", BISHOP: "bishop"}[promo_piece])
        if key in UNDERPLANE and dr == fwd:
            return UNDERPLANE[key] * 64 + frm

    # knight
    for i, (kr, kf) in enumerate(KNIGHT_DELTAS):
        if (dr, df) == (kr, kf):
            return (56 + i) * 64 + frm

    # queen-like: the target must lie exactly k steps along one compass ray
    for di, (ur, uf) in enumerate(DIRECTIONS):
        if ur and uf:                                   # diagonal
            if abs(dr) == abs(df) and dr * ur > 0 and df * uf > 0:
                k = abs(dr)
                if 1 <= k <= 7:
                    return (di * 7 + (k - 1)) * 64 + frm
        elif ur:                                        # vertical
            if df == 0 and dr * ur > 0:
                k = abs(dr)
                if 1 <= k <= 7:
                    return (di * 7 + (k - 1)) * 64 + frm
        else:                                           # horizontal
            if dr == 0 and df * uf > 0:
                k = abs(df)
                if 1 <= k <= 7:
                    return (di * 7 + (k - 1)) * 64 + frm
    return None


def decode_action(board: Board, action: int) -> int | None:
    """Action index -> packed move, WITHOUT legality checking.

    Returns a syntactically valid move that may be illegal in this position.
    That is by design: the gate rejects it. This function must never be
    treated as an authority on what is playable.
    """
    if not (0 <= action < ACTION_SPACE):
        return None
    plane, frm = divmod(action, 64)
    fr, ff = frm >> 3, frm & 7
    fwd = 1 if board.color == WHITE else -1

    if plane < 56:
        di, k = divmod(plane, 7)
        ur, uf = DIRECTIONS[di]
        dist = k + 1
        tr, tf = fr + ur * dist, ff + uf * dist
        if not (0 <= tr < 8 and 0 <= tf < 8):
            return None
        return _finish(board, frm, tr * 8 + tf, queen_promo=True)

    if plane < 64:
        kr, kf = KNIGHT_DELTAS[plane - 56]
        tr, tf = fr + kr, ff + kf
        if not (0 <= tr < 8 and 0 <= tf < 8):
            return None
        return _finish(board, frm, tr * 8 + tf, queen_promo=True)

    key = next(k for k, v in UNDERPLANE.items() if v == plane)
    mode, pname = key
    piece = {"rook": ROOK, "knight": KNIGHT, "bishop": BISHOP}[pname]
    if mode == "fwd":
        tr, tf = fr + fwd, ff
    else:
        tr, tf = fr + fwd, ff + (fwd if mode == "left" else -fwd)
    if not (0 <= tr < 8 and 0 <= tf < 8):
        return None
    return _finish(board, frm, tr * 8 + tf, promo_piece=piece)


def _finish(board: Board, frm: int, to: int, queen_promo: bool = False,
            promo_piece: int | None = None) -> int | None:
    fwd = 1 if board.color == WHITE else -1
    fr = frm >> 3
    mv = frm | (to << 6)
    on_last = (to >> 3) == (7 if board.color == WHITE else 0)
    is_pawn = bool(board.bb[board.color][PAWN] >> frm & 1)
    if is_pawn and on_last:
        code = (PROMO_TO_PIECE.index(promo_piece) if promo_piece is not None
                else PROMO_TO_PIECE.index(QUEEN))
        mv |= F_PROMO | (code << 12)
    if is_pawn and (to >> 3) == fr + fwd and abs((to & 7) - (frm & 7)) == 0:
        pass
    return mv


# --------------------------------------------------- canonical (small) space

def canonical_actions() -> tuple[list[str], dict[str, int]]:
    """Build the reduced ~1880-action space.

    The full 4672 space wastes capacity on mutually exclusive duplicates: the
    same (from, to) pair appears once per direction plane, and half the
    queen-move planes are unreachable from most squares. The reduced space
    enumerates each geometrically distinct move exactly once, which shrinks the
    policy head and is what makes a 6-20M net competitive on a phone.

    Returns (list of "from-to" keys, key -> index). Castling and underpromotions
    get their own explicit slots.
    """
    moves: list[str] = []
    index: dict[str, int] = {}
    from core.board import _SQ_NAMES
    for frm in range(64):
        for to in range(64):
            if frm == to:
                continue
            fr, ff = frm >> 3, frm & 7
            tr, tf = to >> 3, to & 7
            dr, df = tr - fr, tf - ff
            key = _SQ_NAMES[frm] + _SQ_NAMES[to]
            # queen-like: share a line
            queen_like = (dr == 0 or df == 0 or abs(dr) == abs(df))
            knight = (abs(dr), abs(df)) in ((1, 2), (2, 1))
            king = max(abs(dr), abs(df)) == 1
            if queen_like or knight or king:
                # pawn direction constraint is resolved by the gate, not here
                moves.append(key)
                index[key] = len(moves) - 1
    # Underpromotion slots. A queen promotion is already covered by the
    # queen-like moves above; promoting to N/B/R on the same (from, to) is a
    # DIFFERENT action and needs its own index.
    promo_names = {KNIGHT: "n", BISHOP: "b", ROOK: "r"}
    for colour in (WHITE, BLACK):
        fwd = 1 if colour == WHITE else -1
        home = 6 if colour == WHITE else 1
        for frm in range(home * 8, home * 8 + 8):
            targets = [frm + fwd * 8]
            if (frm & 7) > 0:
                targets.append(frm + fwd * 8 - 1)
            if (frm & 7) < 7:
                targets.append(frm + fwd * 8 + 1)
            for to in targets:
                for piece in (KNIGHT, BISHOP, ROOK):
                    key = _SQ_NAMES[frm] + _SQ_NAMES[to] + promo_names[piece]
                    if key not in index:
                        moves.append(key)
                        index[key] = len(moves) - 1
    return moves, index
