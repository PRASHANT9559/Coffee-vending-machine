"""
bitboard.py — Self-contained legal chess move generator (0 external deps).

THIS IS LAYER 1: THE POSSIBILITY GATE.
It answers exactly one question: "which moves are legal right now, and is this
candidate move one of them?" It is deterministic. It CANNOT hallucinate.
That guarantee is what makes the rest of the system trustworthy.

Square mapping: a1=0, b1=1, ... h1=7, a2=8, ... h8=63
Rank index 0 == Rank "1". White advances toward higher rank index.

Verification standard: `perft` (see verify/perft.py). A move generator is
considered correct only if it reproduces the canonical node counts.
"""

from __future__ import annotations

# ---------------------------------------------------------------- constants

WHITE, BLACK = 0, 1
PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING = range(6)

# Square names indexed A1..H8
_SQ_NAMES = [chr(ord("a") + (s & 7)) + str((s >> 3) + 1) for s in range(64)]
SQ_A1, SQ_B1, SQ_C1, SQ_D1, SQ_E1, SQ_F1, SQ_G1, SQ_H1 = range(8)
SQ_A8, SQ_B8, SQ_C8, SQ_D8, SQ_E8, SQ_F8, SQ_G8, SQ_H8 = range(56, 64)

# Castling right bits, indexed by king square (we key rights off king origin
# so that a king that moves and returns permanently forfeits the right).
CR_WK, CR_WQ, CR_BK, CR_BQ = 1, 2, 4, 8
CASTLE_BIT = {SQ_E1: CR_WK | CR_WQ, SQ_E8: CR_BK | CR_BQ}

# Move encoding — every field gets its own bits. (Colliding F_CAPTURE with the
# promotion-piece code silently dropped 3 of 4 promotions; perft is what caught
# it.)
#   bits  0-5  from square
#   bits  6-11 to square
#   bits 12-13 promotion piece (0=N 1=B 2=R 3=Q)
#   bit  14    capture
#   bit  15    en passant
#   bit  16    castling
#   bit  17    double pawn push
#   bit  18    promotion
F_CAPTURE, F_EP, F_CASTLE, F_DPUSH, F_PROMO = 1 << 14, 1 << 15, 1 << 16, 1 << 17, 1 << 18
PROMO_MASK = 3 << 12
FLAG_MASK = F_CAPTURE | F_EP | F_CASTLE | F_CASTLE | F_DPUSH | F_PROMO
PROMO_TO_PIECE = (KNIGHT, BISHOP, ROOK, QUEEN)   # indexed by the 2-bit field
PIECE_TO_PROMO = (KNIGHT, BISHOP, ROOK, QUEEN)   # symmetry: same order

START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

# Precomputed knight jumps: KNIGHT_ATTACKS[sq] is a bitboard of all targets.
KNIGHT_ATTACKS = [0] * 64
KING_ATTACKS = [0] * 64
for _s in range(64):
    _r, _f = divmod(_s, 8)
    for _dr, _df in ((2, 1), (2, -1), (-2, 1), (-2, -1), (1, 2), (1, -2), (-1, 2), (-1, -2)):
        _nr, _nf = _r + _dr, _f + _df
        if 0 <= _nr < 8 and 0 <= _nf < 8:
            KNIGHT_ATTACKS[_s] |= 1 << (_nr * 8 + _nf)
    for _dr, _df in ((1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1)):
        _nr, _nf = _r + _dr, _f + _df
        if 0 <= _nr < 8 and 0 <= _nf < 8:
            KING_ATTACKS[_s] |= 1 << (_nr * 8 + _nf)

# Colour-specific pawn geometry. MUST be per-colour: white captures toward
# higher ranks, black toward lower. A merged table produces phantom backward
# "captures" (this is exactly the class of bug perft exists to kill).
PUSH1 = [[0] * 64, [0] * 64]
PUSH2 = [[0] * 64, [0] * 64]
PAWN_CAPS = [[0] * 64, [0] * 64]
PROMO_RANK = [7, 0]
HOME_RANK = [1, 6]
for _c in (WHITE, BLACK):
    _step = 1 if _c == WHITE else -1
    for _s in range(64):
        _r, _f = _s >> 3, _s & 7
        _nr = _r + _step
        if 0 <= _nr < 8:
            PUSH1[_c][_s] = 1 << (_nr * 8 + _f)
            _bits = 0
            for _df in (-1, 1):
                _nf = _f + _df
                if 0 <= _nf < 8:
                    _bits |= 1 << (_nr * 8 + _nf)
            PAWN_CAPS[_c][_s] = _bits
        _hr = HOME_RANK[_c]
        if _r == _hr and 0 <= _hr + 2 * _step < 8:
            PUSH2[_c][_s] = 1 << ((_hr + 2 * _step) * 8 + _f)

# File masks for sliding / king-safety tests.
FILE_A, FILE_H = 0x0101010101010101, 0x8080808080808080
RANK_1, RANK_8 = 0x00000000000000FF, 0xFF00000000000000
_files = [0] * 8
for _sq in range(64):
    _files[_sq & 7] |= 1 << _sq
FILE_BB = _files
ALL_SQUARES = 0xFFFFFFFFFFFFFFFF

# Direction vectors for sliding rays. Walking rank/file deltas and validating
# the file on every step is slower than magic bitboards but is provably
# correct and trivially portable to C++/Rust/NDK later.
_rook_dirs = ((1, 0), (-1, 0), (0, 1), (0, -1))
_bishop_dirs = ((1, 1), (1, -1), (-1, 1), (-1, -1))
ROOK_DIRS, BISHOP_DIRS = _rook_dirs, _bishop_dirs


def popcount(bb: int) -> int:
    return bb.bit_count()


def lsb(bb: int) -> int:
    """Index of lowest set bit. Returns 64 for an empty board."""
    return (bb & -bb).bit_length() - 1


def pop_lsb(bb: int) -> tuple[int, int]:
    s = lsb(bb)
    return s, bb & (bb - 1)


def move_to_uci(mv: int) -> str:
    f, t = mv & 0x3F, (mv >> 6) & 0x3F
    s = _SQ_NAMES[f] + _SQ_NAMES[t]
    if mv & F_PROMO:
        s += "nbrq"[(mv >> 12) & 3]
    return s


def move_from_uci(uci: str) -> int:
    uci = uci.strip().lower()
    f = _SQ_NAMES.index(uci[0:2])
    t = _SQ_NAMES.index(uci[2:4])
    mv = f | (t << 6)
    if len(uci) >= 5:
        mv |= F_PROMO | ({"n": 0, "b": 1, "r": 2, "q": 3}[uci[4]] << 12)
    return mv


def ray(sq: int, dr: int, df: int, occ: int) -> int:
    """Squares reachable along (dr, df) from sq, stopping at the first blocker."""
    r, f = sq >> 3, sq & 7
    out = 0
    while True:
        r += dr
        f += df
        if not (0 <= r < 8 and 0 <= f < 8):
            break
        s = r * 8 + f
        out |= 1 << s
        if occ & (1 << s):
            break
    return out


def slider_attacks(sq: int, dirs, occ: int) -> int:
    out = 0
    for dr, df in dirs:
        out |= ray(sq, dr, df, occ)
    return out


def between_mask(a: int, b: int) -> int:
    """Squares strictly between a and b when they share a line, else 0."""
    if a == b:
        return 0
    r1, f1 = a >> 3, a & 7
    r2, f2 = b >> 3, b & 7
    dr, df = r2 - r1, f2 - f1
    if not (dr == 0 or df == 0 or abs(dr) == abs(df)):
        return 0
    step = 1 if (dr > 0 or (dr == 0 and df > 0)) else -1
    if dr != 0:
        step = 8 if dr > 0 else -8
    elif df != 0:
        step = 1 if df > 0 else -1
    else:
        return 0
    out = 0
    s = a + step
    while s != b:
        out |= 1 << s
        s += step
    return out


# ---------------------------------------------------------------- board

class Board:
    __slots__ = ("bb", "color", "ep", "castling", "halfmove", "fullmove",
                 "_stack", "ply", "keys")

    def __init__(self, fen: str = START_FEN):
        self.bb = [[0] * 6, [0] * 6]
        self.color = WHITE
        self.ep = -1
        self.castling = 0
        self.halfmove = 0
        self.fullmove = 1
        self._stack = []
        self.ply = 0
        self.keys = []
        self.set_fen(fen)

    # ------------------------------------------------------------ state I/O

    def set_fen(self, fen: str) -> None:
        placement, side, castling, ep, half, full = fen.split()
        self.bb = [[0] * 6, [0] * 6]
        for c in (WHITE, BLACK):
            for p in range(6):
                self.bb[c][p] = 0

        rows = placement.split("/")
        for r, row in enumerate(rows):
            rank = 7 - r  # rows[0] is rank 8
            f = 0
            for ch in row:
                if ch.isdigit():
                    f += int(ch)
                else:
                    p = "PNBRQK".index(ch.upper())
                    c = WHITE if ch.isupper() else BLACK
                    self.bb[c][p] |= 1 << (rank * 8 + f)
                    f += 1

        self.color = WHITE if side == "w" else BLACK
        self.castling = 0
        for i, ch in enumerate("KQkq"):
            if ch in castling:
                self.castling |= 1 << i
        self.ep = -1 if ep == "-" else _SQ_NAMES.index(ep)
        self.halfmove = int(half)
        self.fullmove = int(full)
        self._stack = []
        self.ply = 0
        self.keys = [self.zobrist()]

    def fen(self) -> str:
        rows = []
        for r in range(7, -1, -1):
            row, empty = "", 0
            for f in range(8):
                s = r * 8 + f
                pc = self.piece_at(s)
                if pc is None:
                    empty += 1
                    continue
                if empty:
                    row += str(empty)
                    empty = 0
                p, c = pc
                row += "PNBRQK"[p] if c == WHITE else "PNBRQK"[p].lower()
            if empty:
                row += str(empty)
            rows.append(row)
        cast = "".join(ch for i, ch in enumerate("KQkq") if self.castling & (1 << i)) or "-"
        ep = "-" if self.ep < 0 else _SQ_NAMES[self.ep]
        return f"{'/'.join(rows)} {'w' if self.color == WHITE else 'b'} {cast} {ep} {self.halfmove} {self.fullmove}"

    def piece_at(self, sq: int):
        for c in (WHITE, BLACK):
            for p in range(6):
                if self.bb[c][p] >> sq & 1:
                    return (p, c)
        return None

    # ------------------------------------------------------------ occupancy

    def occ(self, c: int) -> int:
        b = self.bb[c]
        return b[0] | b[1] | b[2] | b[3] | b[4] | b[5]

    def all_occ(self) -> int:
        return self.occ(WHITE) | self.occ(BLACK)

    def king_sq(self, c: int) -> int:
        return lsb(self.bb[c][KING])

    def zobrist(self) -> int:
        h = 0
        for c in (WHITE, BLACK):
            for p in range(6):
                b = self.bb[c][p]
                while b:
                    s, b = pop_lsb(b)
                    h ^= _ZOB_PIECE[c][p][s]
        h ^= _ZOB_SIDE if self.color == BLACK else 0
        h ^= _ZOB_CASTLE[self.castling]
        h ^= _ZOB_EP[self.ep] if self.ep >= 0 else 0
        return h

    # ------------------------------------------------------------ attacks

    def is_square_attacked(self, sq: int, by: int) -> bool:
        """Attacks that ignore pin/check legality — used both for king safety
        and for castling transit-square tests."""
        occ = self.all_occ()
        # Pawns: a square is attacked by colour `by` if a `by`-pawn sits one
        # rank "behind" it in that colour's advance direction.
        step = -8 if by == WHITE else 8
        src = sq + step
        if 0 <= src < 64:
            f_from = src & 7
            for df in (-1, 1):
                nf = f_from + df
                if 0 <= nf < 8 and self.bb[by][PAWN] >> (src + df) & 1:
                    return True
        if KNIGHT_ATTACKS[sq] & self.bb[by][KNIGHT]:
            return True
        if KING_ATTACKS[sq] & self.bb[by][KING]:
            return True
        enemy_p = self.bb[by][PAWN] | self.bb[by][KNIGHT] | self.bb[by][KING]
        if slider_attacks(sq, ROOK_DIRS, occ) & (self.bb[by][ROOK] | self.bb[by][QUEEN]):
            return True
        if slider_attacks(sq, BISHOP_DIRS, occ) & (self.bb[by][BISHOP] | self.bb[by][QUEEN]):
            return True
        _ = (enemy_p,)
        return False

    def in_check(self, c: int | None = None) -> bool:
        c = self.color if c is None else c
        return self.is_square_attacked(self.king_sq(c), c ^ 1)

    # ------------------------------------------------------------ movegen

    def _add(self, out: list, frm: int, to: int, flags: int = 0,
             promo: int = 0) -> None:
        out.append(frm | (to << 6) | (promo << 12) | flags)

    def pseudo_legal(self) -> list:
        out = []
        us, them = self.color, self.color ^ 1
        occ_all = self.all_occ()
        occ_us = self.occ(us)
        occ_them = self.occ(them)
        b = self.bb[us]

        promo_rank = PROMO_RANK[us]
        home_rank = HOME_RANK[us]

        # Pawns
        pw = b[PAWN]
        caps_tbl = PAWN_CAPS[us]
        ep_bb = 1 << self.ep if self.ep >= 0 else 0
        while pw:
            frm, pw = pop_lsb(pw)
            r = frm >> 3
            one = PUSH1[us][frm]
            if one & ~occ_all:
                to = lsb(one)
                if (to >> 3) == promo_rank:      # destination rank, not origin
                    for code in range(4):
                        self._add(out, frm, to, F_PROMO, code)
                else:
                    self._add(out, frm, to)
                    if r == home_rank:
                        two = PUSH2[us][frm]
                        if two & ~occ_all:
                            self._add(out, frm, lsb(two), F_DPUSH)
            # captures: diagonal targets holding an ENEMY piece
            caps = caps_tbl[frm] & occ_them
            while caps:
                to, caps = pop_lsb(caps)
                if (to >> 3) == promo_rank:      # destination rank, not origin
                    for code in range(4):
                        self._add(out, frm, to, F_CAPTURE | F_PROMO, code)
                else:
                    self._add(out, frm, to, F_CAPTURE)
            # en passant: diagonal target that is the ep square
            if ep_bb and (caps_tbl[frm] & ep_bb):
                self._add(out, frm, self.ep, F_CAPTURE | F_EP)

        # Knights, then King. Captures must consider every enemy piece type,
        # not just pawns, and must never target our own pieces.
        for kind in (KNIGHT, KING):
            table = KNIGHT_ATTACKS if kind == KNIGHT else KING_ATTACKS
            m = b[kind]
            while m:
                frm, m = pop_lsb(m)
                reach = table[frm]
                quiet = reach & ~occ_all
                while quiet:
                    to, quiet = pop_lsb(quiet)
                    self._add(out, frm, to)
                taken = reach & occ_them
                if kind == KING:
                    taken &= ~self.bb[them][KING]  # kings are never captured
                while taken:
                    to, taken = pop_lsb(taken)
                    self._add(out, frm, to, F_CAPTURE)

        # Sliding pieces
        for kind, dirs in ((BISHOP, BISHOP_DIRS), (ROOK, ROOK_DIRS), (QUEEN, None)):
            m = b[kind]
            while m:
                frm, m = pop_lsb(m)
                d = (ROOK_DIRS + BISHOP_DIRS) if dirs is None else dirs
                targets = slider_attacks(frm, d, occ_all)
                quiet = targets & ~occ_all
                while quiet:
                    to, quiet = pop_lsb(quiet)
                    self._add(out, frm, to)
                taken = targets & occ_them
                while taken:
                    to, taken = pop_lsb(taken)
                    self._add(out, frm, to, F_CAPTURE)

        self._gen_castles(out)
        return out

    def _gen_castles(self, out: list) -> None:
        """Castling needs FOUR independent conditions per side:
             1. the right has not been forfeited
             2. king and rook stand on their home squares
             3. every square the king crosses or lands on is empty
                (b1/b8 must be EMPTY but the king never passes through them,
                 so they are checked for occupancy only, not for attacks)
             4. the king does not start on, cross, or land on an attacked
                square. Attacking the ROOK is fine — that is legal.
        """
        us, them = self.color, self.color ^ 1
        occ = self.all_occ()
        king_sq = SQ_E1 if us == WHITE else SQ_E8
        if not (self.bb[us][KING] >> king_sq & 1):
            return
        if self.is_square_attacked(king_sq, them):
            return

        if us == WHITE:
            specs = [
                (CR_WK, SQ_H1, (SQ_F1, SQ_G1), SQ_F1, SQ_G1),
                (CR_WQ, SQ_A1, (SQ_B1, SQ_C1, SQ_D1), SQ_D1, SQ_C1),
            ]
        else:
            specs = [
                (CR_BK, SQ_H8, (SQ_F8, SQ_G8), SQ_F8, SQ_G8),
                (CR_BQ, SQ_A8, (SQ_B8, SQ_C8, SQ_D8), SQ_D8, SQ_C8),
            ]
        for right, rook_sq, empties, transit, dest in specs:
            if not (self.castling & right):
                continue
            if not (self.bb[us][ROOK] >> rook_sq & 1):
                continue
            if any(occ >> sq & 1 for sq in empties):
                continue
            if any(self.is_square_attacked(sq, them) for sq in (king_sq, transit, dest)):
                continue
            self._add(out, king_sq, dest, F_CASTLE)

    def legal_moves(self) -> list:
        """Fully legal moves. Self-check filter is the final, authoritative
        gate — nothing enters search without passing through here."""
        out = []
        for mv in self.pseudo_legal():
            if self._is_legal(mv):
                out.append(mv)
        return out

    def _is_legal(self, mv: int) -> bool:
        """Final self-check filter. _make() already refuses to leave our own
        king en prise, so this is a cheap belt-and-braces confirmation."""
        return self._make(mv) is True and self._unmake() is not None

    # ------------------------------------------------------- make / unmake

    def push(self, mv: int) -> None:
        if not self._make(mv):
            raise ValueError(f"illegal move pushed: {move_to_uci(mv)} in {self.fen()}")
        self.keys.append(self.zobrist())

    def pop(self) -> int:
        self.keys.pop()
        return self._unmake()

    def _make(self, mv: int) -> bool:
        """Apply a pseudo-legal move.

        Everything needed to reverse the move is written to the undo stack
        BEFORE the board is touched — in particular `cap_piece`/`cap_sq`.
        The naive alternative (re-scan the destination square on unmake) is
        WRONG: the captured piece is already gone by then, so captures are
        never restored and the board silently rots.

        Returns False and leaves the board untouched if the move is illegal.
        """
        frm, to = mv & 0x3F, (mv >> 6) & 0x3F
        flags = mv & FLAG_MASK
        us, them = self.color, self.color ^ 1
        b = self.bb

        piece = -1
        for p in range(6):
            if b[us][p] >> frm & 1:
                piece = p
                break
        if piece < 0:
            return False

        # --- resolve the capture BEFORE mutating anything
        cap_piece, cap_sq = -1, -1
        if flags & F_EP:
            cap_sq = to - 8 if us == WHITE else to + 8
            if b[them][PAWN] >> cap_sq & 1:
                cap_piece = PAWN
        else:
            for p in range(6):
                if b[them][p] >> to & 1:
                    cap_piece, cap_sq = p, to
                    break

        self._stack.append((mv, self.castling, self.ep, self.halfmove,
                            piece, cap_piece, cap_sq))

        if cap_piece >= 0:
            b[them][cap_piece] &= ~(1 << cap_sq)

        b[us][piece] &= ~(1 << frm)
        if flags & F_PROMO:
            b[us][PROMO_TO_PIECE[(mv >> 12) & 3]] |= 1 << to
        else:
            b[us][piece] |= 1 << to

        if flags & F_CASTLE:
            for kfrom, kto, rfrom, rto in (
                (SQ_E1, SQ_G1, SQ_H1, SQ_F1), (SQ_E1, SQ_C1, SQ_A1, SQ_D1),
                (SQ_E8, SQ_G8, SQ_H8, SQ_F8), (SQ_E8, SQ_C8, SQ_A8, SQ_D8),
            ):
                if to == kto:
                    b[us][ROOK] &= ~(1 << rfrom)
                    b[us][ROOK] |= 1 << rto
                    break

        cr = self.castling
        if piece == KING:
            cr &= ~CASTLE_BIT.get(frm, 0)
        if frm == SQ_A1 or to == SQ_A1:
            cr &= ~CR_WQ
        if frm == SQ_H1 or to == SQ_H1:
            cr &= ~CR_WK
        if frm == SQ_A8 or to == SQ_A8:
            cr &= ~CR_BQ
        if frm == SQ_H8 or to == SQ_H8:
            cr &= ~CR_BK
        self.castling = cr

        self.ep = (frm + to) // 2 if flags & F_DPUSH else -1
        self.halfmove = 0 if (piece == PAWN or cap_piece >= 0) else self.halfmove + 1
        if us == BLACK:
            self.fullmove += 1
        self.color = them
        self.ply += 1

        ksq = lsb(b[us][KING])
        if ksq == 64 or self.is_square_attacked(ksq, them):
            self._unmake()
            return False
        return True

    def _unmake(self) -> int:
        (mv, self.castling, self.ep, self.halfmove,
         piece, cap_piece, cap_sq) = self._stack.pop()
        self.color ^= 1
        us = self.color
        frm, to = mv & 0x3F, (mv >> 6) & 0x3F
        flags = mv & FLAG_MASK
        b = self.bb

        if flags & F_CASTLE:
            for kfrom, kto, rfrom, rto in (
                (SQ_E1, SQ_G1, SQ_H1, SQ_F1), (SQ_E1, SQ_C1, SQ_A1, SQ_D1),
                (SQ_E8, SQ_G8, SQ_H8, SQ_F8), (SQ_E8, SQ_C8, SQ_A8, SQ_D8),
            ):
                if to == kto:
                    b[us][ROOK] &= ~(1 << rto)
                    b[us][ROOK] |= 1 << rfrom
                    break

        # lift the mover's piece off the destination (it may be a promoted one)
        for p in range(6):
            if b[us][p] >> to & 1:
                b[us][p] &= ~(1 << to)
                break
        b[us][piece] |= 1 << frm

        # put the captured piece back exactly where it came from
        if cap_piece >= 0:
            b[us ^ 1][cap_piece] |= 1 << cap_sq

        if us == BLACK:
            self.fullmove -= 1
        self.ply -= 1
        return mv

    # ------------------------------------------------------ game state

    def is_insufficient_material(self) -> bool:
        if self.bb[WHITE][PAWN] or self.bb[BLACK][PAWN]:
            return False
        if self.bb[WHITE][ROOK] or self.bb[BLACK][ROOK] \
           or self.bb[WHITE][QUEEN] or self.bb[BLACK][QUEEN]:
            return False
        minors = popcount(self.bb[WHITE][BISHOP] | self.bb[WHITE][KNIGHT]) + \
                 popcount(self.bb[BLACK][BISHOP] | self.bb[BLACK][KNIGHT])
        bishops = [self.bb[WHITE][BISHOP], self.bb[BLACK][BISHOP]]
        if minors <= 1:
            return True
        if minors == 2 and all(popcount(x) == 1 for x in bishops):
            b1, b2 = bishops
            s1 = lsb(b1) & 7
            s2 = lsb(b2) & 7
            if (s1 & 1) == (s2 & 1):  # same colour complex
                return True
        return False

    def repetition_key(self) -> int:
        return self.zobrist()

    def is_draw(self) -> bool:
        if self.halfmove >= 100:
            return True
        if self.is_insufficient_material():
            return True
        k = self.repetition_key()
        reps = 0
        for old in reversed(self.keys[:-1]):
            if old == k:
                reps += 1
            if len(self.keys) - self.keys.index(old) > 100:
                break
        return reps >= 2

    def is_checkmate(self) -> bool:
        return not self.legal_moves() and self.in_check()

    def is_stalemate(self) -> bool:
        return not self.legal_moves() and not self.in_check()

    def outcome(self):
        """+1 win, 0 draw, -1 loss from side-to-move's perspective. None if
        the game continues."""
        if not self.legal_moves():
            return 0 if self.in_check() is False else -1
        if self.is_draw():
            return 0
        return None

    def perft(self, depth: int) -> int:
        if depth == 0:
            return 1
        total = 0
        for mv in self.legal_moves():
            if self._make(mv):
                total += self.perft(depth - 1)
                self._unmake()
        return total


# ------------------------------------------------- zobrist (fixed seed)

def _mk_zobrist():
    import random
    rnd = random.Random(0x9E3779B9)
    piece = [[[rnd.getrandbits(64) for _ in range(64)] for _ in range(6)] for _ in range(2)]
    return piece


_ZOB_PIECE = _mk_zobrist()
_ZOB_SIDE = 0x5DEECE66D ^ 0x1234567
_ZOB_CASTLE = [0, 1, 2, 3, 5, 9, 17, 33, 65, 129, 257, 513, 1025, 2049, 4097, 8193,
               17, 33, 65, 129, 257, 513, 1025, 2049, 4097, 8193, 16385, 32769]
_ZOB_EP = [0] * 65
for _i in range(64):
    _ZOB_EP[_i] = (_i + 1) * 0x9E3779B97F4A7C15 & 0xFFFFFFFFFFFFFFFF
_ZOB_EP[64] = 0x1234567890ABCDEF
