"""
perft.py — The correctness gate for the possibility checker.

Perft counts the leaves of the legal move tree at a fixed depth. The counts
below are canonical (from the Chess Programming Wiki, cross-verified across
engines). If our generator disagrees on any number, then any model built on
top of it can emit illegal moves, and no amount of model training will fix it.

Run:  python3 -m verify.perft [--max-depth N] [--quick]
"""

from __future__ import annotations

import sys
import time

sys.path.insert(0, __file__.rsplit("/", 2)[0])
from core.board import Board, ALL_SQUARES  # noqa: E402

# Canonical perft suite. These are the standard "the six positions".
SUITE = [
    ("initial",
     "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
     {1: 20, 2: 400, 3: 8902, 4: 197281, 5: 4865609}),
    ("kiwipete",
     "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
     {1: 48, 2: 2039, 3: 97862, 4: 4085603, 5: 193690690}),
    ("position3",
     "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
     {1: 14, 2: 191, 3: 2812, 4: 43238, 5: 674624, 6: 11030083}),
    ("position4",
     "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
     {1: 6, 2: 264, 3: 9467, 4: 422333, 5: 15833292}),
    ("position5",
     "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
     {1: 44, 2: 1486, 3: 62379, 4: 2103487, 5: 89941194}),
    ("position6",
     "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
     {1: 46, 2: 2079, 3: 89890, 4: 3894594, 5: 164075551}),
]

# Promotion / en-passant / castling-rights edge cases.
# These expectations were produced by verify/oracle.py (the independent naive
# generator) and then confirmed to match core/board.py. Do not hand-write them.
EDGE = [
    ("underpromo-gall",
     "8/8/8/8/8/8/6k1/4K2R w K - 0 1",
     {1: 12, 2: 38, 3: 564}),
    ("promo-capture-both",
     "n1n5/PPPk4/8/8/8/8/4Kppp/5N1N b - - 0 1",
     {1: 24, 2: 496, 3: 9483}),
    ("ep-pinned",
     "8/8/8/8/k1p4R/8/3P4/3K4 w - - 0 1",
     {1: 18, 2: 92, 3: 1670}),
    ("castling-rights-loss",
     "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1",
     {1: 26, 2: 568, 3: 13744}),
    ("ep-discovered-check",
     "8/8/8/8/1k1Pp2R/8/8/4K3 b - d3 0 1",
     {1: 8, 2: 125, 3: 869}),
    ("mating-net",
     "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 4 4",
     {1: 41, 2: 1156, 3: 45434}),
]


def perft_fast(board: Board, depth: int) -> int:
    """Perft without the redundant double legality filter: _make() already
    rejects moves that leave the king in check, so pseudo_legal + _make is
    exactly the legal tree, just without the extra make/unmake round trip."""
    if depth == 0:
        return 1
    total = 0
    for mv in board.pseudo_legal():
        if board._make(mv):
            total += perft_fast(board, depth - 1)
            board._unmake()
    return total


def divide(board: Board, depth: int) -> list:
    """Perft divide: node count per root move. This is the tool you actually
    use to localise a bug — if depth-3 is wrong but the sum of depth-2 divides
    isn't, the error is in ordering/plumbing, not generation."""
    rows = []
    for mv in board.pseudo_legal():
        if board._make(mv):
            rows.append((mv, perft_fast(board, depth - 1) if depth > 1 else 1))
            board._unmake()
    return rows


def run(cases, max_depth: int = 4, quiet: bool = False) -> bool:
    ok = True
    for name, fen, expected in cases:
        b = Board(fen)
        for d, want in sorted(expected.items()):
            if d > max_depth:
                continue
            t0 = time.perf_counter()
            got = perft_fast(b, d)
            dt = time.perf_counter() - t0
            good = got == want
            ok &= good
            mark = "PASS" if good else "FAIL"
            if not quiet or not good:
                print(f"  [{mark}] {name:<22} d{d}  got={got:<12} want={want:<12} "
                      f"{dt:6.2f}s  {got/max(dt,1e-9):>10,.0f} nps")
            if not good:
                print(f"         !! delta={got - want}  ({got - want:+d} extra/missing nodes)")
                for mv, n in divide(b, min(d, 3)):
                    from core.board import move_to_uci
                    sub = perft_fast(Board(fen), 0)
                    _ = (mv, sub)
                print("         -- divide at depth 3 (compare against reference):")
                for mv, n in divide(b, min(d, 3)):
                    print(f"            {move_to_uci(mv)}: {n}")
    return ok


def main():
    args = sys.argv[1:]
    max_depth = 4
    quick = "--quick" in args
    for i, a in enumerate(args):
        if a == "--max-depth" and i + 1 < len(args):
            max_depth = int(args[i + 1])
    if quick:
        max_depth = min(max_depth, 3)

    print("=" * 78)
    print("PERFT VERIFICATION — standard suite")
    print("=" * 78)
    ok1 = run(SUITE, max_depth)
    print()
    print("=" * 78)
    print("PERFT VERIFICATION — edge cases (underpromo, en-passant pins, rights)")
    print("=" * 78)
    ok2 = run(EDGE, max_depth)

    print()
    print("=" * 78)
    if ok1 and ok2:
        print("RESULT: ALL PASS — the possibility gate is sound.")
    else:
        print("RESULT: FAILURES — do not train on top of this generator.")
    print("=" * 78)
    return 0 if (ok1 and ok2) else 1


if __name__ == "__main__":
    raise SystemExit(main())
