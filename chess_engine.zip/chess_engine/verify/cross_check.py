"""
cross_check.py — Differential test: bitboard engine vs naive oracle.

Plays random games from the perft positions (and from random legal positions)
and compares the two generators' legal-move lists at EVERY ply. The first
divergence is printed with its FEN and the symmetric difference.

    python3 -m verify.cross_check --games 300
"""

from __future__ import annotations

import random
import sys

sys.path.insert(0, __file__.rsplit("/", 2)[0])
from core.board import Board, move_to_uci, move_from_uci  # noqa: E402
import verify.oracle as O  # noqa: E402

SUITE_FENS = [
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
    "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
    "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
    "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
    "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
    "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
]


def compare(fen: str):
    b = Board(fen)
    mine = sorted(move_to_uci(m) for m in b.legal_moves())
    st = O.parse(fen)
    theirs = O.legal_moves(st)
    if mine == theirs:
        return None
    only_mine = sorted(set(mine) - set(theirs))
    only_theirs = sorted(set(theirs) - set(mine))
    return only_mine, only_theirs


def main():
    games = 300
    seed = 12345
    argv = sys.argv[1:]
    for i, a in enumerate(argv):
        if a == "--games" and i + 1 < len(argv):
            games = int(argv[i + 1])
        if a == "--seed" and i + 1 < len(argv):
            seed = int(argv[i + 1])
    rng = random.Random(seed)

    checked = 0
    bad = 0
    for g in range(games):
        fen = SUITE_FENS[g % len(SUITE_FENS)]
        b = Board(fen)
        for ply in range(120):
            diff = compare(b.fen())
            checked += 1
            if diff:
                bad += 1
                only_mine, only_theirs = diff
                print("=" * 74)
                print(f"MISMATCH  game {g} ply {ply}")
                print(f"FEN: {b.fen()}")
                print(f"  bitboard has, oracle lacks: {only_mine}")
                print(f"  oracle has, bitboard lacks: {only_theirs}")
                print(f"  counts: mine={len(b.legal_moves())} oracle={len(O.legal_moves(O.parse(b.fen())))}")
                print("=" * 74)
                return 1
            moves = b.legal_moves()
            if not moves:
                break
            b.push(rng.choice(moves))
    print(f"cross_check: {checked} positions compared, {bad} mismatches")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
