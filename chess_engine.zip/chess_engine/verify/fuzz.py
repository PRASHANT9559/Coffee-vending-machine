"""
fuzz.py — Randomised make/unmake integrity test.

Perft proves the move GENERATOR is right. It does not prove make/unmake is
symmetric: a non-symmetric unmake still yields correct perft counts as long as
the corruption happens to cancel within the same subtree, and only shows up
later as a position with three rooks and a bishop.

This test therefore checks the thing perft cannot: after push/pop of any legal
move, every field of the board must be bit-identical to what it was before.

    python3 -m verify.fuzz --games 300 --plies 200
"""

from __future__ import annotations

import random
import sys

sys.path.insert(0, __file__.rsplit("/", 2)[0])
from core.board import Board, move_to_uci, lsb  # noqa: E402

SUITE_FENS = [
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
    "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
    "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
    "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
    "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
    "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
    "n1n5/PPPk4/8/8/8/8/4Kppp/5N1N b - - 0 1",
    "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
]


def snapshot(b: Board):
    return (
        tuple(tuple(b.bb[c][p] for p in range(6)) for c in range(2)),
        b.color, b.castling, b.ep, b.halfmove, b.fullmove, b.ply,
    )


def diff(snap, b: Board) -> str:
    bits, color, castle, ep, half, full, ply = snap
    for c in range(2):
        for p in range(6):
            if bits[c][p] != b.bb[c][p]:
                diff_bb = bits[c][p] ^ b.bb[c][p]
                from core.board import _SQ_NAMES
                sqs = [s for s in range(64) if diff_bb >> s & 1]
                return (f"bitboard colour={c} piece={p} differs at "
                        f"{[_SQ_NAMES[s] for s in sqs]}")
    for name, old, new in (("color", color, b.color), ("castling", castle, b.castling),
                           ("ep", ep, b.ep), ("halfmove", half, b.halfmove),
                           ("fullmove", full, b.fullmove), ("ply", ply, b.ply)):
        if old != new:
            return f"{name}: {old} -> {new}"
    return ""


def main():
    games, plies, seed = 300, 200, 4242
    argv = sys.argv[1:]
    for i, a in enumerate(argv):
        if a == "--games" and i + 1 < len(argv):
            games = int(argv[i + 1])
        if a == "--plies" and i + 1 < len(argv):
            plies = int(argv[i + 1])
        if a == "--seed" and i + 1 < len(argv):
            seed = int(argv[i + 1])

    rng = random.Random(seed)
    checks = 0
    for g in range(games):
        b = Board(SUITE_FENS[g % len(SUITE_FENS)])
        for _ in range(plies):
            moves = b.legal_moves()
            if not moves:
                break
            # verify every single candidate move round-trips
            for mv in moves:
                before = snapshot(b)
                uci = move_to_uci(mv)
                b.push(mv)
                b.pop()
                checks += 1
                d = diff(before, b)
                if d:
                    print("=" * 74)
                    print(f"MAKE/UNMAKE ASYMMETRY after {uci}")
                    print(f"  FEN before: {Board(SUITE_FENS[g % len(SUITE_FENS)]).fen()}")
                    print(f"  FEN now   : {b.fen()}")
                    print(f"  {d}")
                    print("=" * 74)
                    return 1
            b.push(rng.choice(moves))

    # deep-stack check: 60 plies, unmake them all in order
    b = Board(SUITE_FENS[1])
    stack = []
    for _ in range(60):
        ms = b.legal_moves()
        if not ms:
            break
        mv = rng.choice(ms)
        stack.append((snapshot(b), move_to_uci(mv)))
        b.push(mv)
    for before, uci in reversed(stack):
        b.pop()
        checks += 1
        d = diff(before, b)
        if d:
            print(f"DEEP-UNWIND ASYMMETRY after {uci}: {d}")
            print(f"  FEN: {b.fen()}")
            return 1

    print(f"fuzz: {checks} push/pop round-trips verified, 0 asymmetries")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
