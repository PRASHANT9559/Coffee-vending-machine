"""
oracle.py — A deliberately NAIVE, independent chess move generator.

Its only job is to disagree with core/board.py when core/board.py is wrong.
It shares no code, no data structures and no algorithm with the bitboard
engine: this one keeps pieces in a plain 64-element list, generates moves by
stepping square by square with explicit bounds checks, and makes moves by
copying the entire board. Slow, but obvious.

cross_check.py plays random games and diffs the two move lists at every ply.
"""

from __future__ import annotations

WHITE, BLACK = 0, 1
EMPTY = "."
FILES = "abcdefgh"


def sq_name(s: int) -> str:
    return FILES[s & 7] + str((s >> 3) + 1)


def name_sq(n: str) -> int:
    return (int(n[1]) - 1) * 8 + FILES.index(n[0])


def parse(fen: str):
    placement, side, castling, ep, half, full = fen.split()
    board = [EMPTY] * 64
    for i, row in enumerate(placement.split("/")):
        r = 7 - i
        f = 0
        for ch in row:
            if ch.isdigit():
                f += int(ch)
            else:
                board[r * 8 + f] = ch
                f += 1
    return {
        "b": board,
        "w": WHITE if side == "w" else BLACK,
        "castle": set(castling) - {"-"},
        "ep": None if ep == "-" else name_sq(ep),
        "half": int(half),
        "full": int(full),
    }


def render(st) -> str:
    rows = []
    for r in range(7, -1, -1):
        row, empty = "", 0
        for f in range(8):
            pc = st["b"][r * 8 + f]
            if pc == EMPTY:
                empty += 1
            else:
                if empty:
                    row += str(empty)
                    empty = 0
                row += pc
        if empty:
            row += str(empty)
        rows.append(row)
    castle = "".join(sorted(st["castle"], key="KQkq".index)) or "-"
    ep = sq_name(st["ep"]) if st["ep"] is not None else "-"
    return f"{'/'.join(rows)} {'w' if st['w'] == WHITE else 'b'} {castle} {ep} {st['half']} {st['full']}"


def is_white(pc: str) -> bool:
    return pc.isupper()


def find_king(st, white: bool) -> int:
    target = "K" if white else "k"
    for s in range(64):
        if st["b"][s] == target:
            return s
    return -1


def attacked(st, sq: int, by_white: bool) -> bool:
    """Is `sq` attacked by the given side? Pure geometry, no bitboards."""
    # pawns
    d = -1 if by_white else 1          # step back from sq to the attacker's rank
    r, f = sq >> 3, sq & 7
    for df in (-1, 1):
        nf = f + df
        if 0 <= nf < 8:
            nr = r + d
            if 0 <= nr < 8:
                pc = st["b"][nr * 8 + nf]
                if pc != EMPTY and is_white(pc) == by_white and pc.upper() == "P":
                    return True
    # knights
    for dr, df in ((2, 1), (2, -1), (-2, 1), (-2, -1), (1, 2), (1, -2), (-1, 2), (-1, -2)):
        nr, nf = r + dr, f + df
        if 0 <= nr < 8 and 0 <= nf < 8:
            pc = st["b"][nr * 8 + nf]
            if pc != EMPTY and is_white(pc) == by_white and pc.upper() == "N":
                return True
    # king
    for dr in (-1, 0, 1):
        for df in (-1, 0, 1):
            if dr == 0 and df == 0:
                continue
            nr, nf = r + dr, f + df
            if 0 <= nr < 8 and 0 <= nf < 8:
                pc = st["b"][nr * 8 + nf]
                if pc != EMPTY and is_white(pc) == by_white and pc.upper() == "K":
                    return True
    # sliders
    for dirs, names in ((((1, 0), (-1, 0), (0, 1), (0, -1)), "RQ"),
                        (((1, 1), (1, -1), (-1, 1), (-1, -1)), "BQ")):
        for dr, df in dirs:
            nr, nf = r + dr, f + df
            while 0 <= nr < 8 and 0 <= nf < 8:
                pc = st["b"][nr * 8 + nf]
                if pc != EMPTY:
                    if is_white(pc) == by_white and pc.upper() in names:
                        return True
                    break
                nr += dr
                nf += df
    return False


def pseudo_moves(st):
    """Yields (uci, new_state). Correctness over speed."""
    me = st["w"]
    out = []
    board = st["b"]
    forward = 8 if me == WHITE else -8
    start_rank = 1 if me == WHITE else 6
    last_rank = 7 if me == WHITE else 0

    for s in range(64):
        pc = board[s]
        if pc == EMPTY or is_white(pc) != (me == WHITE):
            continue
        kind = pc.upper()
        r, f = s >> 3, s & 7
        targets = []

        if kind == "P":
            nr = r + (1 if me == WHITE else -1)
            if 0 <= nr < 8 and board[nr * 8 + f] == EMPTY:
                targets.append((nr * 8 + f, None, False))
                if r == start_rank:
                    nr2 = r + 2 * (1 if me == WHITE else -1)
                    if board[nr2 * 8 + f] == EMPTY:
                        targets.append((nr2 * 8 + f, None, True))
            for df in (-1, 1):
                nf = f + df
                if not (0 <= nf < 8 and 0 <= nr < 8):
                    continue
                t = nr * 8 + nf
                if board[t] != EMPTY and is_white(board[t]) != (me == WHITE):
                    targets.append((t, None, False))
                elif st["ep"] is not None and t == st["ep"]:
                    targets.append((t, "P", False))   # en passant capture

        elif kind in ("N", "K"):
            if kind == "N":
                deltas = ((2, 1), (2, -1), (-2, 1), (-2, -1), (1, 2), (1, -2), (-1, 2), (-1, -2))
            else:
                deltas = [(dr, df) for dr in (-1, 0, 1) for df in (-1, 0, 1) if (dr, df) != (0, 0)]
            for dr, df in deltas:
                nr, nf = r + dr, f + df
                if 0 <= nr < 8 and 0 <= nf < 8:
                    t = nr * 8 + nf
                    if board[t] == EMPTY or is_white(board[t]) != (me == WHITE):
                        targets.append((t, None, False))

        else:  # sliders
            if kind in ("B", "Q"):
                dirs = ((1, 1), (1, -1), (-1, 1), (-1, -1))
            else:
                dirs = ((1, 0), (-1, 0), (0, 1), (0, -1))
            if kind == "Q":
                dirs = dirs + ((1, 0), (-1, 0), (0, 1), (0, -1))
            for dr, df in dirs:
                nr, nf = r + dr, f + df
                while 0 <= nr < 8 and 0 <= nf < 8:
                    t = nr * 8 + nf
                    if board[t] == EMPTY:
                        targets.append((t, None, False))
                    else:
                        if is_white(board[t]) != (me == WHITE):
                            targets.append((t, None, False))
                        break
                    nr += dr
                    nf += df

        if kind == "K":
            # castling candidates (validated later in legal_moves)
            home = 0 if me == WHITE else 56
            for kside, empties, dest in (
                (True, (home + 5, home + 6), home + 6),
                (False, (home + 1, home + 2, home + 3), home + 2),
            ):
                if s == home + 4 and all(board[q] == EMPTY for q in empties):
                    targets.append((dest, None, False))

        for t, epcap, dbl in targets:
            tr, tf = t >> 3, t & 7
            is_promo = kind == "P" and tr == last_rank
            for uci, ns in _emit(st, s, t, epcap, dbl, is_promo, pc):
                out.append((uci, ns))
    return out


def _emit(st, frm, to, epcap, dbl, is_promo, pc):
    """Build every concrete resulting position (4 promotion choices etc.)."""
    kinds = "qrbn" if is_promo else None
    for k in (kinds or " "):
        nb = st["b"][:]
        nb[frm] = EMPTY
        if epcap:
            cap_sq = to - 8 if st["w"] == WHITE else to + 8
            nb[cap_sq] = EMPTY
        np = pc if not is_promo else (k.upper() if st["w"] == WHITE else k)
        nb[to] = np
        uci = sq_name(frm) + sq_name(to) + (k if is_promo else "")

        # castling rook
        if pc.upper() == "K" and abs((to & 7) - (frm & 7)) == 2:
            kside = (to & 7) > (frm & 7)
            home = 0 if st["w"] == WHITE else 56
            r_from = home + 7 if kside else home
            r_to = home + 5 if kside else home + 3
            nb[r_to] = nb[r_from]
            nb[r_from] = EMPTY

        ns = {
            "b": nb, "w": st["w"] ^ 1,
            "castle": set(st["castle"]), "ep": None,
            "half": 0 if (pc.upper() == "P" or epcap) else st["half"] + 1,
            "full": st["full"] + (1 if st["w"] == BLACK else 0),
        }
        if dbl:
            ns["ep"] = (frm + to) // 2
        if pc.upper() == "K":
            for c in ("KQ" if st["w"] == WHITE else "kq"):
                ns["castle"].discard(c)
        for sq, right in ((0, "Q"), (7, "K"), (56, "q"), (56 + 7, "k")):
            if frm == sq or to == sq:
                ns["castle"].discard(right)
        yield uci, ns


def legal_moves(st):
    me_white = st["w"] == WHITE
    out = []
    for uci, ns in pseudo_moves(st):
        # castling: king may not start, cross, or land on an attacked square
        frm = name_sq(uci[:2])
        to = name_sq(uci[2:4])
        if st["b"][frm].upper() == "K" and abs((to & 7) - (frm & 7)) == 2:
            kside = (to & 7) > (frm & 7)
            right = ("K" if kside else "Q") if me_white else ("k" if kside else "q")
            if right not in st["castle"]:
                continue
            home = 0 if me_white else 56
            rook_sq = home + (7 if kside else 0)
            if st["b"][rook_sq] != ("R" if me_white else "r"):
                continue
            path = [frm, to] if kside else [frm, to]
            mid = home + (5 if kside else 3)
            path = [frm, mid, to]
            if any(st["b"][p] != EMPTY for p in (mid, to)):
                continue
            if any(attacked(st, p, not me_white) for p in path):
                continue
        if not attacked(ns, find_king(ns, me_white), not me_white):
            out.append(uci)
    return sorted(out)
