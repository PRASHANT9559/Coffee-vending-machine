"""
gate.py — THE POSSIBILITY GATE.

This is the component that makes the whole system trustworthy. Every move,
no matter where it came from, passes through `check()` before it can be played.

    neural net logits  ─┐
    LLM text output    ─┼──▶  PossibilityGate.check()  ──▶  legal move or rejection
    human UCI string   ─┘

Design rule: the gate is the ONLY component allowed to authorise a move, and it
authorises nothing it has not itself enumerated. The model is treated as an
untrusted advisor that may be wrong, hallucinate, or propose a move that does
not exist. That is not paranoia — a distilled 270M chess transformer still
produces illegal moves in endgames, and "thinking" LLMs sit around 99% legal,
not 100%.

Rejections are not discarded. They are logged, because an illegal proposal is
one of the most informative training examples you can generate: it is exactly
the failure mode you want the network to stop producing.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from core.board import Board, move_to_uci, move_from_uci

REASON_OK = "ok"
REASON_NOT_SYNTAX = "not_a_uci_move"
REASON_ILLEGAL = "not_legal_here"
REASON_WRONG_TURN = "not_our_piece_to_move"
REASON_UNKNOWN = "unknown_move"


@dataclass
class GateResult:
    ok: bool
    move: int | None = None
    uci: str | None = None
    reason: str = REASON_OK
    legal_count: int = 0
    """How many moves were actually available. 0 means mate/stalemate."""

    def __bool__(self) -> bool:
        return self.ok


@dataclass
class Rejection:
    fen: str
    proposed: str
    reason: str
    legal_moves: list[str] = field(default_factory=list)


class PossibilityGate:
    """Deterministic legality authority.

    Stateless with respect to the board: it reads the board, never mutates it.
    """

    def __init__(self, board: Board, collect_rejections: bool = True):
        self.board = board
        self.collect_rejections = collect_rejections
        self.rejections: list[Rejection] = []
        self._cache: dict[str, GateResult] = {}
        self._legal = self._enumerate()

    # ------------------------------------------------------------------ core

    def _enumerate(self) -> dict[str, int]:
        """The authoritative legal move table, keyed by UCI.

        Enumerated once per position and reused for every proposal, so
        validating N candidates costs N dict lookups rather than N move
        generations. On a phone this is the difference between ~40us and
        ~40ms per move.
        """
        if not self._cache:
            for mv in self.board.legal_moves():
                self._cache[move_to_uci(mv)] = mv
        return self._cache

    def check_uci(self, uci: str) -> GateResult:
        """Validate a candidate given as text (LLM output, PGN import, UI)."""
        uci = (uci or "").strip()
        if uci in self._cache:
            mv = self._cache[uci]
            return GateResult(True, mv, uci, REASON_OK, len(self._cache))
        reason = REASON_NOT_SYNTAX
        try:
            mv = move_from_uci(uci)
        except (ValueError, IndexError):
            mv = None
        if mv is not None:
            reason = REASON_ILLEGAL if self._cache else REASON_WRONG_TURN
        self._reject(uci, reason)
        return GateResult(False, None, uci, reason, len(self._cache))

    def check_int(self, mv: int) -> GateResult:
        """Validate a candidate already encoded as a packed move int."""
        uci = move_to_uci(mv)
        if uci in self._cache:
            return GateResult(True, self._cache[uci], uci, REASON_OK, len(self._cache))
        self._reject(uci, REASON_ILLEGAL)
        return GateResult(False, None, uci, REASON_ILLEGAL, len(self._cache))

    def check_index(self, action_index: int, action_to_uci: list[str]) -> GateResult:
        """Validate a network output expressed as an index into a fixed action
        space (the 1,880-canonical-action encoding used by AlphaZero-style
        nets). The mapping is supplied by the caller so the gate stays ignorant
        of the network's internal layout.
        """
        if not (0 <= action_index < len(action_to_uci)):
            self._reject(str(action_index), REASON_UNKNOWN)
            return GateResult(False, None, None, REASON_UNKNOWN, len(self._cache))
        return self.check_uci(action_to_uci[action_index])

    def check_logits(self, scored: list[tuple[int, float]]) -> GateResult | None:
        """Validate an ordered proposal list of (packed move, score), best first.

        Walks the list until the first move the gate recognises. This is the
        path a policy network takes: it proposes its top-N moves, and the gate
        picks the best one that is actually legal.
        """
        for mv, _score in scored:
            r = self.check_int(mv)
            if r.ok:
                return r
        return None

    # ------------------------------------------------------------- fallbacks

    def fallback(self, prefer: list[int] | None = None) -> GateResult:
        """When every proposal failed, return a legal move anyway.

        A chess engine that refuses to move is worse than one that plays a
        mediocre move. The caller decides how dumb the fallback is:
        `prefer` lets the net still contribute ordering, but only among moves
        the gate has independently verified.
        """
        if not self._cache:
            self._reject("<none>", REASON_WRONG_TURN)
            return GateResult(False, None, None, REASON_WRONG_TURN, 0)
        if prefer:
            for mv in prefer:
                r = self.check_int(mv)
                if r.ok:
                    return r
        # deterministic: first legal move in generation order
        uci, mv = next(iter(self._cache.items()))
        return GateResult(True, mv, uci, REASON_OK, len(self._cache))

    # ------------------------------------------------------------ diagnostics

    def _reject(self, uci: str, reason: str) -> None:
        if self.collect_rejections:
            self.rejections.append(
                Rejection(self.board.fen(), uci, reason, sorted(self._cache))
            )

    @property
    def legal_ucis(self) -> list[str]:
        return sorted(self._cache)

    @property
    def legal_count(self) -> int:
        return len(self._cache)

    @property
    def is_terminal(self) -> bool:
        return len(self._cache) == 0

    def terminal_reason(self) -> str | None:
        if self._cache:
            return None
        if self.board.in_check():
            return "checkmate"
        return "stalemate"
