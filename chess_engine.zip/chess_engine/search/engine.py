"""
engine.py — Search on top of the possibility gate.

Two interchangeable searchers, same contract:

    SearchResult( move_uci, score_cp, nodes, pv, depth )

Both draw their move lists exclusively from PossibilityGate, so neither can
ever play an illegal move regardless of what the evaluation network says.
The network is an *advisor* (move ordering + leaf evaluation); the gate is the
*authority* (what is actually playable).

Implementations:
  * AlphaBetaSearch  — iterative deepening, PVS, transposition table, null
                       move pruning, quiescence, LMR. The Stockfish shape.
                       Better strength per node, worse strength per second on
                       a small NN.
  * PUCTSearch       — AlphaZero shape. Policy/value network drives MCTS.
                       Scales better to a weak net and to batched NN inference,
                       which is what a phone NPU actually gives you.

Pick AlphaBeta if your evaluation is a strong scalar NNUE-style net.
Pick PUCT if your evaluation is a small policy+value net trained by self-play.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

from core.board import Board, move_to_uci, move_from_uci
from search.gate import PossibilityGate

MATE = 30000
INFINITY = 10 ** 9


@dataclass
class SearchResult:
    move_uci: str | None
    score_cp: int
    nodes: int
    depth: int
    pv: list[str] = field(default_factory=list)
    elapsed: float = 0.0
    nps: int = 0
    gate_rejections: int = 0

    def __str__(self) -> str:
        return (f"{self.move_uci or '-':<7} {self.score_cp:+6d}cp  "
                f"d{self.depth}  {self.nodes:>9,}n  {self.nps:>9,}nps  "
                f"{self.elapsed:.2f}s  pv={' '.join(self.pv[:6])}")


# --------------------------------------------------------------------------
# Evaluation network protocol
# --------------------------------------------------------------------------

class NullNet:
    """Stand-in so the pipeline runs before a model exists.

    Material evaluation only. Weak, but it makes every interface in this file
    executable and testable today.
    """
    name = "null"

    def policy_value(self, board: Board) -> tuple[list[tuple[int, float]], float]:
        order = []
        for mv in board.pseudo_legal():
            order.append((mv, 0.0))
        return order, material(board)

    def batch_policy_value(self, boards: list[Board]):
        return [self.policy_value(b) for b in boards]


PIECE_VALUE = [100, 320, 330, 500, 900, 0]


def material(board: Board) -> float:
    from core.board import WHITE, BLACK
    score = 0.0
    for p in range(5):
        score += board.bb[WHITE][p].bit_count() * PIECE_VALUE[p]
        score -= board.bb[BLACK][p].bit_count() * PIECE_VALUE[p]
    return score


# --------------------------------------------------------------------------
# Alpha-beta (Stockfish-shaped)
# --------------------------------------------------------------------------

class AlphaBetaSearch:
    def __init__(self, net=None, max_depth: int = 64,
                 time_limit: float = 10.0, tt: dict | None = None):
        self.net = net or NullNet()
        self.max_depth = max_depth
        self.time_limit = time_limit
        self.tt = tt if tt is not None else {}
        self.nodes = 0
        self.deadline = 0.0
        self._timed_out = False
        self.rejections = 0

    # ---- public

    def search(self, board: Board, time_limit: float | None = None) -> SearchResult:
        self.nodes = 0
        self._timed_out = False
        limit = time_limit if time_limit is not None else self.time_limit
        self.deadline = time.perf_counter() + limit
        start = self.deadline - limit
        self.rejections = 0

        gate = PossibilityGate(board)
        if gate.is_terminal:
            return SearchResult(None, 0, 0, 0, [], limit, 0, 0)

        best_uci, best_score = None, -INFINITY
        reached_depth = 0
        for depth in range(1, self.max_depth + 1):
            uci, score = self._root(board, gate, depth, -INFINITY, INFINITY)
            if self._timed_out and depth > 1:
                break
            best_uci, best_score = uci, score
            reached_depth = depth
            if abs(score) >= MATE - 1000:
                break
        elapsed = time.perf_counter() - start
        return SearchResult(
            best_uci, int(best_score), self.nodes, reached_depth,
            self._pv(board, best_uci), elapsed,
            int(self.nodes / elapsed) if elapsed > 0 else 0,
            self.rejections,
        )

    # ---- internals

    def _ordered(self, board: Board, gate: PossibilityGate):
        """Gate-authorised moves, best-first per the network's advice.

        Crucially: whatever the net ranks first that the gate rejects is
        dropped, and the next candidate slides up. The ordering degrades
        gracefully instead of breaking the search.
        """
        legal = set(gate.legal_ucis)
        advice, _ = self.net.policy_value(board)
        ranked = []
        for mv, score in advice:
            uci = move_to_uci(mv)
            if uci in legal:
                ranked.append(mv)
                legal.discard(uci)
        for uci in sorted(legal):                 # anything the net missed
            ranked.append(move_from_uci(uci))
        self.rejections += len(advice) - (len(ranked) - 0) if False else 0
        return ranked

    def _root(self, board, gate, depth, alpha, beta):
        moves = self._ordered(board, gate)
        best_uci, best = None, -INFINITY
        for mv in moves:
            if not board._make(mv):
                continue
            score = -self._negamax(board, depth - 1, -beta, -alpha, 0)
            board._unmake()
            if self._timed_out:
                break
            if score > best:
                best, best_uci = score, mv
                alpha = max(alpha, score)
        return move_to_uci(best_uci) if best_uci is not None else None, best

    def _negamax(self, board, depth, alpha, beta, ply):
        self.nodes += 1
        if (self.nodes & 1023) == 0 and time.perf_counter() > self.deadline:
            self._timed_out = True
            return 0
        if ply > 0 and board.is_draw():
            return 0
        if depth <= 0:
            return self._quiesce(board, alpha, beta, ply)

        # transposition probe
        key = board.zobrist()
        entry = self.tt.get(key)
        if entry and entry[0] >= depth and ply > 0:
            _, tte_score, tte_flag, tte_move = entry
            if tte_flag == 0:
                return tte_score
            elif tte_flag == 1 and tte_score > alpha:
                alpha = tte_score
            elif tte_flag == 2 and tte_score < beta:
                beta = tte_score
            if alpha >= beta:
                return tte_score

        gate = PossibilityGate(board, collect_rejections=False)
        if gate.is_terminal:
            return -MATE + ply if board.in_check() else 0

        moves = self._ordered(board, gate)
        original_alpha = alpha
        best, best_move = -INFINITY, None
        for i, mv in enumerate(moves):
            if not board._make(mv):
                continue
            # late move reduction: quiet, late, non-check moves
            reduction = 0
            if depth >= 3 and i >= 4 and not (mv >> 14) & 1 and ply > 0:
                reduction = 1 if depth < 6 else 2
            score = -self._negamax(board, depth - 1 - reduction, -beta, -alpha, ply + 1)
            if score > alpha and reduction:
                score = -self._negamax(board, depth - 1, -beta, -alpha, ply + 1)
            board._unmake()
            if self._timed_out:
                break
            if score > best:
                best, best_move = score, mv
                if score > alpha:
                    alpha = score
                    if alpha >= beta:
                        flag = 1 if best > original_alpha else 2
                        self.tt[key] = (depth, int(best), flag, best_move)
                        return best
        if best_move is None:
            return -MATE + ply
        flag = 1 if best > original_alpha else (2 if best >= beta else 0)
        self.tt[key] = (depth, int(best), flag, best_move)
        return best

    def _quiesce(self, board, alpha, beta, ply):
        """Search captures only, so the evaluation never sees a position where
        a piece is hanging for free."""
        self.nodes += 1
        stand_pat = material(board)
        if stand_pat >= beta:
            return stand_pat
        if stand_pat > alpha:
            alpha = stand_pat
        if ply > 24:
            return stand_pat
        gate = PossibilityGate(board, collect_rejections=False)
        from core.board import F_CAPTURE
        captures = [mv for mv in (move_from_uci(u) for u in gate.legal_ucis)
                    if mv & F_CAPTURE]
        for uci in sorted(captures):
            mv = move_from_uci(uci)
            if not board._make(mv):
                continue
            score = -self._quiesce(board, -beta, -alpha, ply + 1)
            board._unmake()
            if self._timed_out:
                return alpha
            if score >= beta:
                return beta
            if score > alpha:
                alpha = score
        return alpha

    def _pv(self, board, first_uci):
        if not first_uci:
            return []
        pv, b = [], Board(board.fen())
        mv = move_from_uci(first_uci)
        if not b._make(mv):
            return []
        pv.append(first_uci)
        for _ in range(10):
            gate = PossibilityGate(b, collect_rejections=False)
            if gate.is_terminal:
                break
            key = b.zobrist()
            entry = self.tt.get(key)
            if not entry:
                break
            nxt = move_to_uci(entry[3])
            if nxt not in gate._cache:
                break
            pv.append(nxt)
            if not b._make(move_from_uci(nxt)):
                break
        return pv


# --------------------------------------------------------------------------
# PUCT / MCTS (AlphaZero-shaped)
# --------------------------------------------------------------------------

class MCTSNode:
    __slots__ = ("fen", "children", "visits", "value_sum", "prior", "terminal")

    def __init__(self, fen: str):
        self.fen = fen
        self.children: dict[str, MCTSNode] = {}
        self.visits = 0
        self.value_sum = 0.0
        self.prior = 0.0
        self.terminal = False

    @property
    def q(self) -> float:
        return self.value_sum / self.visits if self.visits else 0.0


class PUCTSearch:
    """AlphaZero-style MCTS. The right choice for a small policy+value net on
    a phone: NN evaluation is batched and a weak net hurts PUCT far less than
    it hurts alpha-beta, because a bad prior only skews the order in which
    lines get explored — it cannot make an illegal line reachable, since the
    gate builds the child list.

    Everything below is standard. The one non-negotiable line is the gate
    inside _expand: it is the only thing that decides which children exist.
    """

    C_PUCT = 1.5
    FPU = 0.0            # first-play urgency for unvisited children

    def __init__(self, net=None, simulations: int = 800,
                 time_limit: float = 10.0, dirichlet_alpha: float = 0.15,
                 dirichlet_epsilon: float = 0.25,
                 temperature_moves: int = 12, seed: int = 0):
        self.net = net or NullNet()
        self.simulations = simulations
        self.time_limit = time_limit
        self.dirichlet_alpha = dirichlet_alpha
        self.dirichlet_epsilon = dirichlet_epsilon
        self.temperature_moves = temperature_moves
        self.seed = seed
        self.rejections = 0

    def search(self, board: Board, time_limit: float | None = None) -> SearchResult:
        import random
        rng = random.Random(self.seed)
        start = time.perf_counter()
        deadline = start + (time_limit if time_limit is not None else self.time_limit)

        root = MCTSNode(board.fen())
        self._expand(root, board, rng, is_root=True)
        if root.terminal:
            return SearchResult(None, 0, 0, 0, [], deadline - start, 0, 0)

        nodes = 0
        for _ in range(self.simulations):
            if time.perf_counter() > deadline:
                break
            node, b = root, Board(board.fen())
            path = []
            while True:
                if node.terminal or not node.children:
                    break
                uci = self._select(node)
                path.append(node)
                mv = _uci_to_int(uci)
                if mv is None or not b._make(mv):
                    node.terminal = True
                    break
                node = node.children[uci]
            leaf_value = self._evaluate(node, b)
            nodes += 1
            for n in reversed(path):
                n.visits += 1
                n.value_sum += -leaf_value if n is not path[0] else leaf_value
                # value is from the perspective of the player to move at `n`,
                # so each step up the path negates
                leaf_value = -leaf_value

        elapsed = time.perf_counter() - start
        legal = list(root.children)
        total_visits = sum(root.children[u].visits for u in legal)
        best = max(legal, key=lambda u: root.children[u].visits)
        if total_visits < self.temperature_moves:
            best = self._sample(legal, root, rng)
        win = root.children[best].q
        score_cp = int(200 * max(-1.0, min(1.0, win)))
        return SearchResult(best, score_cp, nodes, 0, [best], elapsed,
                            int(nodes / elapsed) if elapsed > 0 else 0, 0)

    # ---- tree ops

    def _expand(self, node: MCTSNode, board: Board, rng, is_root: bool = False) -> None:
        """Create children for `node`. The gate decides which ones exist."""
        gate = PossibilityGate(board, collect_rejections=False)
        if gate.is_terminal:
            node.terminal = True
            return
        legal = gate.legal_ucis
        advice, value = self.net.policy_value(board)

        import math
        raw = {}
        for mv, s in advice:
            uci = move_to_uci(mv)
            if uci in gate._cache:
                raw[uci] = math.exp(max(-30.0, min(30.0, s)))
        total = sum(raw.get(u, 0.0) for u in legal) or float(len(legal))

        priors = {u: raw.get(u, 0.0) / total for u in legal}
        if is_root:
            noise = _dirichlet(len(legal), self.dirichlet_alpha, rng)
            eps = self.dirichlet_epsilon
            for i, u in enumerate(legal):
                priors[u] = (1 - eps) * priors[u] + eps * noise[i]
        else:
            # unvisited children get a small floor rather than exactly zero
            floor = 0.01 / len(legal)
            for u in legal:
                priors[u] = priors[u] + floor

        node.children = {u: MCTSNode(board.fen()) for u in legal}
        for u, p in priors.items():
            node.children[u].prior = p
        self.rejections += len(advice) - len([1 for mv, _ in advice
                                              if move_to_uci(mv) in gate._cache])

    def _select(self, node: MCTSNode) -> str:
        total = sum(c.visits for c in node.children.values()) or 1
        sqrt_total = math.sqrt(total)
        best_uci, best_score = None, -math.inf
        for uci, child in node.children.items():
            q = child.q if child.visits else self.FPU
            score = q + self.C_PUCT * child.prior * sqrt_total / (1 + child.visits)
            if score > best_score:
                best_uci, best_score = uci, score
        return best_uci

    def _evaluate(self, node: MCTSNode, board: Board) -> float:
        if not node.children and not node.terminal:
            self._expand(node, board, _RNG)
        if node.terminal:
            gate_free = PossibilityGate(board, collect_rejections=False)
            if gate_free.is_terminal:
                return 0.0 if not board.in_check() else -1.0
        _, value = self.net.policy_value(board)
        return max(-1.0, min(1.0, value / 1000.0))

    @staticmethod
    def _sample(legal, root: MCTSNode, rng) -> str:
        tot = sum(root.children[u].visits for u in legal)
        if tot == 0:
            return legal[0]
        r = rng.random() * tot
        acc = 0
        for u in legal:
            acc += root.children[u].visits
            if acc >= r:
                return u
        return legal[-1]


def _uci_to_int(uci: str):
    from core.board import move_from_uci
    try:
        return move_from_uci(uci)
    except (ValueError, IndexError):
        return None


def _dirichlet(n, alpha, rng):
    if n <= 0:
        return []
    xs = [rng.gammavariate(alpha, 1.0) for _ in range(n)]
    s = sum(xs) or 1.0
    return [x / s for x in xs]


import random as _random_mod
_RNG = _random_mod.Random(0)
