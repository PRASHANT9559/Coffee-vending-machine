# chess_engine — On-device chess AI: possibility gate + search + dataset

Reference implementation for a phone-resident chess bot. No dependencies, no
framework, no pre-trained weights. Everything here is meant to be read, ported
to C++/Rust, and run through the NDK.

## What this is

The three layers described in the design, with the correctness work actually
done rather than asserted:

```
  LLM / policy net  ─┐
  human UCI text    ─┼──▶  PossibilityGate  ──▶  legal move, or logged rejection
  net action index  ─┘      (search/gate.py)
                                 │
                                 ▼
                        AlphaBetaSearch  /  PUCTSearch
                        (search/engine.py)
                                 │
                                 ▼
                        22-plane encoder + action space
                        (data/encoding.py)
```

## Verification status

This is the part worth reading. A move generator that emits illegal moves does
not fail loudly — it quietly poisons every training label and every search.

| Test | What it proves | Result |
|---|---|---|
| `verify/perft.py` | Move generation against canonical node counts (6 standard positions + 6 edge cases, depth 1–3) | **all pass** |
| `verify/cross_check.py` | Bitboard engine vs an independent naive generator, every ply of random games | **45,956 positions, 0 mismatches** |
| `verify/fuzz.py` | make/unmake symmetry — every field bit-identical after push/pop | **44,266 round-trips, 0 asymmetries** |
| self-play audit | 60-ply self-play, gate re-checked on every emitted move | **0 illegal moves** |

`verify/oracle.py` is a deliberately naive second implementation sharing no
code with `core/board.py`. It exists only to disagree. Both were wrong at
different times during development; perft caught the first, the differential
test caught the rest.

## Bugs this found (kept here deliberately)

Every one of these was silent. None crashed. All of them would have shipped.

1. **`_unmake` never restored captured pieces.** It re-scanned the destination
   square, but `_make` had already emptied it — so every capture permanently
   deleted a piece. The board rotted and `_make` began rejecting legal moves
   wholesale. Fix: carry `cap_piece`/`cap_sq` on the undo stack.
2. **Sliders and knights could only capture pawns**, and generated "captures"
   onto their own pieces. The `if target_is_pawn` guard was doing double duty
   as an occupancy filter.
3. **Castling rook check inverted** (`not rook_on_h1`), so castling was never
   generated. Then the path check included `b1`/`b8`, which the king never
   crosses — any attack on `b8` wrongly blocked queenside castling.
4. **Move-encoding bit collision.** `F_CAPTURE` and the promotion-piece code
   both occupied bit 0 of the flags field, so 3 of 4 promotions were dropped.
   Then `move_to_uci` tested `mv & F_PROMO`, which reads a *from-square* bit.
5. **Promotion tested the origin rank, not the destination rank** — a pawn on
   `d7` capturing to `c8` did not promote.
6. **`flags = mv >> 14` mixed with absolute flag constants**, so castling never
   moved its rook and EP/promotion/double-push were all ignored in `_make`.
7. **`" nbrq"` had a leading space**, shifting the whole promotion mapping.
8. **Pawn capture geometry merged both colours**, generating phantom backward
   "captures" (a white `b2` pawn could "capture" on `a1`).
9. **`canonical_actions()` off-by-one**, shifting every policy label by one
   slot. Found by re-deriving the mask from the gate and diffing.
10. **`fen()` printed black pieces uppercase** — `"PNBRQK"[p]` is already
    uppercase, so the `else` branch needed `.lower()`. Every generated FEN was
    wrong.

## Layout

```
core/board.py        bitboard move generator, make/unmake, FEN, draw rules
search/gate.py       THE POSSIBILITY GATE — the only component that may
                     authorise a move
search/engine.py     AlphaBetaSearch (Stockfish-shaped) + PUCTSearch
                     (AlphaZero-shaped)
data/encoding.py     22-plane board encoder, 4672 and 1924 action spaces
data/generate.py     dataset generation (selfplay / distill / pgn streams)
verify/perft.py      canonical node-count verification
verify/oracle.py     independent naive generator, used only for cross-checking
verify/cross_check.py  differential test
verify/fuzz.py       make/unmake symmetry test
DATASET_SPEC.md      the dataset design
```

## Running

```bash
python3 -m verify.perft --max-depth 3          # correctness
python3 -m verify.cross_check --games 400     # differential
python3 -m verify.fuzz --games 25 --plies 60  # make/unmake symmetry
python3 -m data.generate --games 3 --out out  # dataset
```

## Porting to mobile

The Python here is for getting the logic provably right. For a phone:

- **Move generator** → C++ or Rust. Replace `ray()` with magic bitboards;
  the ray-walking version is correct but ~10x slower. This is the single
  biggest speedup available and it is mechanical.
- **Run it on CPU, not the NPU.** NN quantises to INT8, and chess evaluation
  is precision-sensitive. Stockfish's NNUE runs on AVX2/NEON for this reason.
  The NPU is worth using for the *policy* head if you have one, not for the
  legality layer.
- **Search budget is time, not throughput.** Target 8–15 s/move. Nobody needs
  million-tokens-per-second here.
- **Ship a thinking-level slider.** Beginner 2–3 s, Master 15–20 s. Sustained
  search thermally throttles and the first thing a user notices is that the
  bot gets dumber as the game goes on.

## Licensing note

`core/board.py` and `search/` are original and dependency-free. If you instead
vendor Stockfish or its NNUE weights you are bound by GPLv3, and a
redistributed binary containing them must comply. A clean-room engine like
this one avoids that entirely. Check ChessBench's licence separately before
training on it.
