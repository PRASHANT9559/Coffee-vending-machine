# Dataset Spec — On-device Chess Policy/Value Net (6–20M params)

Target: a small policy+value network that, combined with the possibility gate
and MCTS, plays 2400–3000 Elo entirely on a phone with no network.

Everything below assumes the perft-verified move generator in `core/board.py`
and the gate in `search/gate.py`. That is not a convenience: **every label in
this dataset is produced by those two components**, so a label cannot be
syntactically legal-but-wrong, and it cannot be a position the net will never
see played correctly.

---

## 1. The one non-negotiable field

Every record carries an `action_mask` straight out of the gate:

```python
mask = [1 if uci in gate.legal_ucis else 0 for uci in ACTION_MOVES]
```

This single array is the difference between "the net sometimes emits an illegal
move" and "the net structurally cannot". The action space deliberately
contains moves that are illegal in the current position — AlphaZero never
trained the network to avoid those, it masked them at inference. The gate is
that mask, promoted to authority.

**Do not derive `action_mask` from your move generator's second opinion.** It
must be the same code path the engine will use at inference. If they ever
diverge, you have a training/serving skew bug that shows up as random
illegal moves on device and nowhere else.

---

## 2. Record schema

```jsonc
{
  "fen":        "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4",

  // 22 x 8 x 8 uint8 = 1408 bytes
  "planes":     [ /* see plane map below */ ],

  // ACTION_SPACE bools. 0 => the net may not play it, and gets no credit.
  "action_mask":[ 1, 0, 1, ... ],

  // ACTION_SPACE float32, sums to 1 over the masked set.
  // Soft for self-play (MCTS visit counts), softmax for distillation.
  "policy_target":[ 0.0, 0.0, 0.71, ... ],

  // ACTION_SPACE int16 centipawns, 0 where masked.
  // THIS is the field that makes small nets work. See §4.
  "action_value":[ 0, 0, 145, -30, ... ],

  "state_value_cp": 145,     // int16, the position's own eval
  "outcome_z":      0,       // int8: -1 loss / 0 draw / +1 win, from POV of side to move
  "phase":  "opening",       // opening | midgame | endgame
  "ply":    8,
  "game_id":"sp0042",
  "source": "selfplay",      // selfplay | distill | pgn
  "key":    "9f2c..."        // zobrist, for dedup
}
```

### Board plane map (22 planes, little-endian: row 0 = rank 1)

| Planes | Content |
|---|---|
| 0–5 | White P, N, B, R, Q, K |
| 6–11 | Black P, N, B, R, Q, K |
| 12 | Side to move (1.0 if black) |
| 13–16 | Castling rights K, Q, k, q |
| 17 | En passant target square |
| 18 | Position seen before in this game (repetition) |
| 19 | Halfmove clock / 100 |
| 20 | Move number / 200 |
| 21 | Side to move is in check |

Keep the map in code, not in a config file that can drift. `data/encoding.py`
is the single source of truth; `decode_board_fen()` exists purely as a
round-trip test.

---

## 3. Action space — pick one, do not mix

| Space | Size | When |
|---|---|---|
| `8×8×73` (AlphaZero, Silver et al.) | **4672** | Simplest, densest, best-documented. 56 queen-like planes + 8 knight + 9 underpromotion. Start here. |
| Reduced geometric + underpromotion | **1924** | 1792 distinct (from, to) pairs + 132 underpromotion slots. Smaller policy head — measurably better for a 6–20M net on a phone. |

Published work also cites a "1,880 canonical" space (DeepMind ChessBench and
the small self-play nets). The exact composition varies between
implementations; `data/encoding.py::canonical_actions()` builds a
fully-enumerated, verified variant and reports its true size rather than
quoting a number it does not construct. **Whichever you pick, the gate masks
illegal actions identically** — the space only changes the output head size.

Underpromotion needs explicit slots. A queen promotion is already a
queen-like move in the space; promoting to N/B/R on the same (from, to) is a
*different* action and needs its own index. This is the single most commonly
missed detail — get it wrong and the net can never underpromote, which costs
real Elo in endgames.

---

## 4. Label design — the part that actually decides your Elo

**Action-value beats state-value, and beats behavioural cloning.** DeepMind's
ChessBench found action-value discretisation, with the number of bins pushed
from 16 to 256, was the biggest single lever in their ablation. A state-value
tells the net "this position is +0.3". An action-value tells it "Nxe5 is +0.9,
d4 is +0.1, Qh5 hangs a piece to Bxc3". The second is a policy, and it is
what a small net can actually learn from few samples.

Recipe:

```
action_value[mv] = clip(engine_eval(play(board, mv)), -3000, +3000)
state_value      = max(action_value)          # the best move's value
policy_target    = softmax(action_value / 120) # tau ≈ 120cp
```

Sampled, not argmax. A hard one-hot target throws away the information that
two moves are nearly equal, which is most of the signal in a quiet middlegame.

**Value bins: 256.** Store as int16 centipawns and bin at loss time. Do not
bake the binning into the data — keep centipawns so you can re-bin without a
regeneration pass.

---

## 5. The three streams, and their ratio

| Stream | Policy target | Cost | Job |
|---|---|---|---|
| `distill` | softmax(action_value) | low | The workhorse. Cheapest sample per unit of quality. |
| `selfplay` | MCTS visit distribution | high | Best per-sample quality; keeps the net improving past its teacher. |
| `pgn` | one-hot human move | lowest | Stops the net collapsing into engine patterns; preserves opening theory. |

Start at **70% distill / 25% selfplay / 5% PGN**. Shift toward selfplay once
the distilled net plateaus — that is the point at which you have caught up
with the teacher and need to exceed it.

PGN is a small fraction on purpose. Human games are abundant, cheap, and
biased toward early-move, low-blunder positions. Over-weighting them teaches
the net to play the opening and then not know what to do.

---

## 6. Volume targets for a 6–20M net

| Stage | Unique positions | What it buys |
|---|---|---|
| Smoke test | 50k | Pipeline works, mask correct, loss falls. Nothing else. |
| v1 | 500k – 1M | ~1800–2200 Elo with search. |
| v2 | 5M | ~2400–2700 Elo. This is the practical target. |
| v3 | 20M+ | Diminishing returns. Past this, spend on search budget instead. |

For reference, the published self-play result that reached 3251 Elo used a
6.32M-parameter network, a 14-block/160-channel backbone, 52 input planes, and
100,000 searches per move. DeepMind's distilled 270M model needed ~15 billion
labelled points (10M games) to get to 2299 Elo against engines. Your 6M net
at 5M positions is not a compromise — it is the cheaper half of a trade that
almost always favours **small-net-plus-search over big-net-without-search**.

Dedup hard. Self-play repeats quiet positions constantly; a naive run can
spend 30%+ of its samples on a few hundred distinct positions. `generate.py`
dedups by Zobrist hash and reports the removed fraction — if that number is
under ~15%, something is wrong with your sampling.

---

## 7. Phase balance

Self-play and PGN are both heavy in openings and middlegames. Endgames are
where underpromotion and piece-activity detail actually decide games, and they
are exactly what gets starved.

Check the histogram in `meta.json` after every run. Target roughly:

```
opening  15–25%   midgame  45–60%   endgame  25–35%
```

If endgames are under 20%, oversample them. If openings are over 30%, your
net will look brilliant for ten moves and then coast on a 0.0 score.

---

## 8. Storage

`.npz` shards of ~2000 samples, one array per field, with the string fields
(`fen`, `phase`, `game_id`) kept as object arrays for joining back to labels.

```
shard_0000.npz
  planes       uint8   [N, 22, 8, 8]
  action_mask  bool    [N, 1924]
  policy_target float32[N, 1924]
  action_value int16   [N, 1924]
  state_value  int16   [N]
  outcome_z    int8    [N]
  ply          int16   [N]
  phase, fen, game_id   object[N]
```

Roughly 8–12 KB per sample uncompressed; 5M samples ≈ 50 GB before
compression. `np.savez_compressed` gets you to roughly a third of that. The
masks and most of `action_value` are near-constant per row and compress hard.

**Validate the shard before training on it.** Three assertions catch
essentially every generation bug:

```python
assert (action_mask.sum(1) > 0).all()                 # no empty positions
assert np.allclose(policy_target.sum(1), 1.0, atol=1e-4)   # normalised
assert (policy_target[~action_mask] == 0).all()       # never rewards illegal
```

---

## 9. Generation order (do it in this order)

1. **Gate + move generator first, and verify with perft.** Everything else is
   downstream. A move generator that emits illegal captures will not fail
   loudly — it will quietly poison every label.
2. **Generate a 50k smoke set and eyeball it.** Print ten positions with their
   mask and their top-3 action-values. Sanity-check that the top action-value
   is a move a human would play.
3. **Train the smoke net to convergence.** If a 6M net cannot overfit 50k
   samples, your label pipeline is wrong, not your architecture.
4. **Only then scale the dataset.**

---

## 10. Common ways to waste the effort

- **Training on one-hot best-move only.** You are throwing away the ranking
  information that makes small nets work. This is the most common mistake.
- **Letting the network learn legality.** Do not. A 270M distilled transformer
  still produces illegal moves; "thinking" LLMs reach ~99% legal, not 100%.
  Mask, don't hope.
- **Ignoring the repetition and halfmove planes.** Threefold and the 50-move
  rule are part of the game state, and a net that cannot see them will
  cheerfully repeat into a draw.
- **Underpromotion not in the action space.** Silent Elo loss in endgames.
- **No endgame oversampling.** The phase histogram drifts and the net plateaus
  well below its architecture's ceiling.
- **Optimising tokens/second.** Chess is nodes/second bound. Your target is
  nodes per move within a 8–15 second think time, not MTPS.
