# Manhattan Coffee Vending — Product Readiness Report & Work Plan

**Report date:** 2026-11-03
**Project:** `vending-machine/`
**Layers audited:** Next.js admin panel, Rust Axum backend, PostgreSQL/Supabase schema
**Method:** Static code verification (file-by-file). Build/run not executed because `node_modules/` and `backend/target/` are absent and the agreed rule is **no package install**.
**Rules followed:** ❌ no file deleted · ❌ no package installed · ✅ only in-project files inspected · ✅ nothing modified except this report.

> This report supersedes the older `EGM-AUDIT-REPORT.md` wherever the two disagree. Several P0 items in the old report were genuinely fixed (SQL syntax, SQL injection, hardcoded OTPs, sandbox Owner fallback). The project is still **not shippable**, but for different, verified reasons listed below.

---

## 0. TL;DR Verdict

| Question | Answer |
|---|---|
| Product ready? | **NO — not even close to production** |
| Can the frontend build today? | Not verified — dependencies not installed (by rule). Code is large but structurally plausible. |
| Can the Rust backend build today? | **NO — guaranteed compile failure** (ambiguous modules + `sqlx::query!` macros without offline cache) |
| Can the backend serve real data if it compiled? | **NO — models/queries do not match the SQL schema** (columns, types, enum case) |
| Is login secure? | **NO — the second factor is literally shown in the browser; role is chosen by the client** |
| Is data real? | **NO — 57 app files still read mock/seed data; only dashboard + machine commands call the backend** |
| Can machines be controlled? | **NO — no MQTT client exists; commands are DB rows that nobody delivers** |
| Is it deployable? | **NO — no Dockerfile, no CI, no migrations runner, no tests, no env examples** |

**Honest overall score: ~25 / 100.**
It is a very good **UI prototype + database blueprint**, not a product.

---

## 1. What Is Actually Working (Credit Where Due)

These parts are real and worth keeping:

1. **Next.js UI surface is extensive**
   - 58 `page.tsx` routes exist, covering dashboard, machines, orders, customers, inventory, analytics, marketing, support, settings, login, MFA, forgot-password.
   - Persistent admin shell, sidebar, topbar, toasts, data tables, charts, modals — all built.
   - RBAC model in `lib/auth.ts` is well thought out: 6 roles, 13 capabilities, 53-route capability registry, deny-not-hide behaviour, audit of denied attempts.

2. **Database blueprint is serious**
   - 70 `CREATE TABLE` statements, 17 functions, 93 RLS policies, seed data.
   - Money is stored in paise (integer) — correct choice.
   - Wallet ledger, refunds, support tickets, evidence, emulator/telemetry tables all modelled.
   - The 3 known SQL syntax bugs from the old audit were actually fixed:
     - `fn_write_audit` → `case when fn_is_admin() ...` (`004_rls_policies.sql:535,541`)
     - `fn_ticket_evidence_bundle` → `e.code_id = o.code_id` (`002_functions.sql:729`)
     - `fn_resolve_ticket` → `p_ticket_id` (`002_functions.sql:792`)

3. **Some real hardening was done**
   - Rust SQL injection in telemetry was replaced with parameterised queries.
   - Refund flow uses a transaction + `fn_wallet_credit` ledger call.
   - FSSAI milk-temperature lockout logic exists in the telemetry handler.
   - Interactive CCTV evidence player component exists.
   - `backend-client.ts` has typed helpers for dashboard, machines, commands, orders, support.

4. **Canonical Rust implementation exists**
   - `backend/src/handlers.rs` + `backend/src/models.rs` are schema-aligned and contain all routes used by `main.rs` (including WhatsApp intake and ticket sweep).
   - These are the files to keep and finish. The `handlers/*.rs` and `models/*.rs` split tree is stale (see P0-01).

---

## 2. Scorecard (Verified, Not Guessed)

| Layer | Score | Status | Reason |
|---|---:|---|---|
| Database schema | **60/100** | Needs work | Strong model, but missing `003_views.sql`, missing `otp_codes`, Supabase-only RLS helpers, no migration runner |
| Rust backend | **15/100** | Broken | Cannot compile; models/columns/types drift; no MQTT; no password verification |
| Next.js frontend | **45/100** | Prototype | Beautiful and broad, but mock-driven; auth bypassable |
| Frontend ↔ Backend integration | **15/100** | Almost absent | Only dashboard + machine commands use backend |
| Hardware / IoT pipeline | **5/100** | Missing | No MQTT publish/subscribe, no per-machine keys, no worker |
| Operations / delivery | **10/100** | Missing | No Docker, CI, tests, metrics, migrations, env examples |
| **Overall** | **~25/100** | **Not shippable** | UI prototype + DB blueprint |

---

## 3. Critical Findings (All Verified in Code)

### F-01 🔴 Rust backend cannot compile — ambiguous modules
Rust does not allow both `foo.rs` and `foo/mod.rs` for the same module. All four pairs exist:

| Module | Monolith | Split tree |
|---|---|---|
| handlers | `backend/src/handlers.rs` (1161 lines) | `backend/src/handlers/mod.rs` + `handlers/*.rs` |
| models | `backend/src/models.rs` (722 lines) | `backend/src/models/mod.rs` + `models/*.rs` |
| db | `backend/src/db.rs` | `backend/src/db/mod.rs` + `db/pool.rs` |
| middleware | `backend/src/middleware.rs` | `backend/src/middleware/mod.rs` + `middleware/auth.rs` |

`backend/src/main.rs:13-18` declares `mod handlers; mod models; mod db; mod middleware;` → compiler error `E0761: file for module found at both ...`.

**Worse:** the two trees are not equivalent.
- `main.rs` calls `whatsapp_intake_handler` and `sweep_ticket_timers` (exist only in the monolith).
- Split handlers use `AuthContext`, monolith uses `AdminClaims`.
- Split `models/machine.rs` expects columns `code/location/zone/status ONLINE`, while the real schema has `machine_code/city/locality` and lowercase enum values.
- Split `handlers/live.rs:13` compares `m.status == "ONLINE"` — never true against schema enum (`active`, `offline`, …).
- Split handlers use `Extension<AuthContext>` but `middleware.rs` inserts `AdminClaims` → type panic at runtime.

**Decision:** the **monolith is canonical**. The split tree is dead code and must never be compiled.

---

### F-02 🔴 `sqlx::query!` macros require a live database at compile time
`backend/src/handlers.rs:121,131` (and 10 occurrences across the tree) use `sqlx::query!` / `query_as!`, which are compile-time-checked and need `DATABASE_URL` + a reachable DB, or a `.sqlx/` offline cache.

- There is **no `.sqlx/` directory**.
- There is **no `Cargo.lock`**.
- Therefore `cargo build` will fail even after F-01 is fixed.

`handlers.rs` uses only 2 such macros (both on the missing `otp_codes` table). Convert them to runtime `sqlx::query(...)` to unblock offline builds.

---

### F-03 🔴 Backend models/queries do not match the real schema
Even if it compiled, queries would fail at runtime:

| Object | Rust expects | Real schema | Result |
|---|---|---|---|
| `machines` | `latitude/longitude: f64`, `target_temp_c: f64` | `numeric(10,7)`, `numeric(4,1)` | SQLx cannot decode NUMERIC into `f64` → `list_machines` 500 |
| `machine_commands.command_type` | JSON/string | `command_type` enum | must map enum or cast |
| `orders` | `amount_paise` etc. (monolith OK) | matches monolith | split model (`amount_inr`, `beverage_name`) is wrong |
| `support_tickets` | monolith matches | matches monolith | split model (`customer_name`, `issue_type`, `sla_seconds_remaining`) is wrong |
| `audit_logs` | split handlers insert `user_id, user_role, permission, status, details` | columns are `actor_type, actor_id, action, entity_type, entity_id, before_state, after_state…` | insert fails |
| `otp_codes` | queried by `handlers.rs:121,131` | **table does not exist** | OTP login impossible |

Also:
- Monolith `SELECT * FROM machines` maps 26 struct fields to 26 columns — field names match, but the NUMERIC→f64 decode issue remains.
- `Uuid` path params (`Path<Uuid>`) vs frontend mock IDs (`m1`, `MCH-001`) → any real call with a mock ID returns 400.

**Action:** audit every `FromRow` struct against `001_full_schema.sql`, cast NUMERIC columns with `::float8` in SELECTs (or adopt `Decimal`), and return UUIDs to the frontend.

---

### F-04 🔴 Rust login has no password check and hardcodes superadmin
`backend/src/handlers.rs:41-109`:
1. Looks up `admin_users` by email only.
2. **Never compares `payload.password` with `password_hash`.**
3. Assigns `role = "superadmin"` to every active admin.
4. Ignores `mfa_enabled`, `failed_logins`, `locked_until`, `admin_roles`.

So: anyone who knows an operator email gets a full superadmin JWT.

Secondary issues:
- `JWT_SECRET` fallback is a hardcoded string (`config.rs:32-34`, `handlers/auth.rs:88-90`).
- Frontend expects `ADMIN_JWT_SECRET ?? JWT_SECRET` (`lib/auth.ts:214-218`, `middleware.ts:17-21`) while backend only reads `JWT_SECRET`. If only one is set, tokens are rejected.
- `middleware.ts` falls back to `'mc-admin-dev-secret'` in production if env is missing → forgeable sessions.

---

### F-05 🔴 Next.js authentication is a demo bypass
- `lib/actions.ts:26-38` — `requestOtp()` accepts **any role from the client**, generates a code, signs it into `mc_auth_pending`, and **returns the code to the browser** (`demoCode`).
- `login/login-form.tsx:88-93` — displays the OTP with “click to autofill”.
- `login/page.tsx:9-14` — role chips let the visitor pick `owner`.
- `mfa/page.tsx:30` — passes `mfaCode={payload.mfaCode}` into the client component.
- `mfa/mfa-form.tsx:27-31,55-60` — displays the “Generated TOTP” and autofills it.
- `lib/actions.ts:52-78` — `verifyMfa()` only checks the code against the cookie value that was also handed to the browser.

**Net effect:** visitor selects Owner → copies the displayed OTP → copies the displayed TOTP → full Owner console. There is no second factor and no identity proof.

---

### F-06 🔴 Frontend is a mock shell, not an admin product
- **57 of 58** files under `app/` import `@/lib/mock/*`.
- Only two app entry points touch the backend:
  - `app/(admin)/page.tsx` via `lib/dashboard.ts`
  - `app/(admin)/machines/[id]/commands/page.tsx` via `backendApi.listMachineCommands`
- All other modules (machines list, orders, customers, inventory, analytics, marketing, support, settings) render seed arrays.
- `lib/actions.ts` calls the backend inside `try {} catch {}` and then **mutates the in-memory mock anyway**, returning success text (`machineCommand`, `orderRefund`, `disputeResolve`, etc.). A backend outage is invisible to the user.
- `lib/dashboard.ts:100-104` silently falls back to `demoData()`.
- `lib/mock/store.ts` uses `globalThis.__mcStore` — data is lost on every server restart/HMR.
- `lib/supabase.ts` is dead code (no imports).
- Sidebar badges are hardcoded (`sidebar.tsx:34,35,45`: “2”, “168”, “4”).
- Topbar search input has no handler (`topbar.tsx:67-74`).

---

### F-07 🟠 Database gaps
1. `003_views.sql` is referenced in the schema run order (`README` / header of `001_full_schema.sql`) but **does not exist**. Any view-dependent analytics is missing.
2. `otp_codes` table is queried by Rust but **is not defined**.
3. RLS is **Supabase-specific**: uses `auth.uid()` and roles `anon` / `authenticated`. On a plain PostgreSQL/VPS deploy these roles/functions do not exist → policy creation fails.
4. No migration runner / ordering table. Files are numbered but `003` is missing.
5. `.env` (with DB URL and JWT secret) lives in `backend/` and there is **no `.gitignore`** in the project.
6. Seed data (`005_seed.sql`) mixes demo identities with production-looking records.

---

### F-08 🟠 Hardware / operational pipeline is missing
- `Cargo.toml` has **no MQTT crate** (`rumqttc`/`paho`). `backend/.env` defines `MQTT_BROKER_URL`, but no code reads it.
- `dispatch_hardware_command` inserts a `machine_commands` row; nothing publishes it to a machine.
- ACK endpoint exists, but no broker/worker calls it.
- FSSAI watchdog runs only during telemetry ingest; no periodic worker.
- Machine key check accepts any key starting with `mch_key_` (`middleware.rs`) — effectively a shared-prefix bypass.
- No telemetry batching/buffer; every packet writes directly to Postgres.
- No partition maintenance cron (`fn_manage_telemetry_partitions` exists but never scheduled).
- Offline QR double-spend protection: `machine_ids` empty defaults to fleet-wide (per old audit) — needs verification in `fn_redeem_qr_code`.
- No CCTV clip storage/signed URL service.
- No WhatsApp provider signature verification.

---

### F-09 🟠 Build / delivery / quality gaps
- No `node_modules/`, no `backend/target/`, no `package-lock.json`, no `Cargo.lock`.
- No `Dockerfile`, no `docker-compose`, no CI config (`.github/`, etc.).
- **Zero tests** in the entire project.
- No `.env.example` for the frontend. `RUST_BACKEND_URL`, `ADMIN_JWT_SECRET` are undocumented.
- No Prometheus `/metrics`, no structured request metrics, no alerting.
- `tsconfig.tsbuildinfo` (build artifact) is committed.
- `adminflow-next/README.md` is stale (“Run and deploy your AI Studio app”, `GEMINI_API_KEY`) and wrong for this architecture.
- No git repository (`git status` N/A), so there is no version history / rollback story.

---

### F-10 🟡 UX/product loose ends (after the core works)
- Sidebar counts static; search non-functional; “Go Pro / Upgrade Now” dead.
- Global bell notifications come from mock store.
- Dashboard “Download Report” and “Add Machine” are demo toasts.
- No loading/error/empty states driven by real API failures.
- No pagination/filter/sort on giant lists (mock arrays slice client-side).
- No accessibility audit, no i18n, no error boundary around data loaders.

---

## 4. Work Breakdown — Task Backlog

Priority legend: **P0** = blocks build/security · **P1** = makes it real · **P2** = makes it operable · **P3** = makes it releasable.

### Phase 0 — Build & Security (must finish first)

| ID | Pri | Task | Files | Done when |
|---|---|---|---|---|
| P0-01 | 🔴 | Resolve module ambiguity; keep monolith canonical | `backend/src/main.rs` | `mod` declarations use explicit `#[path]` (or one tree) so `E0761` disappears |
| P0-02 | 🔴 | Remove compile-time DB dependency | `backend/src/handlers.rs` | All `sqlx::query!`/`query_as!` macros replaced with runtime `sqlx::query(...)`; build works without DB |
| P0-03 | 🔴 | Add offline build support | `backend/` | `Cargo.lock` generated; optional `.cargo/config` + docs; `cargo build` succeeds offline |
| P0-04 | 🔴 | Reconcile Rust models with schema | `backend/src/models.rs`, `handlers.rs` | Every `FromRow` struct maps real columns; NUMERIC columns cast; `cargo check` + smoke queries pass |
| P0-05 | 🔴 | Fix missing DB objects | `coffee-vending-db-schema/schema/` | Add `003_views.sql`; add `otp_codes` (or remove OTP path); audit `005_seed.sql` |
| P0-06 | 🔴 | Password verification + real RBAC in Rust login | `handlers.rs`, `config.rs` | `password_hash` verified (argon2/bcrypt), role read from `admin_roles`, lockout honoured |
| P0-07 | 🔴 | Unify JWT secret + fail-fast | `config.rs`, `middleware.rs`, `lib/auth.ts`, `middleware.ts` | One env var name; refuse to boot/serve with default secret in production |
| P0-08 | 🔴 | Remove Next.js auth bypass | `lib/actions.ts`, login/MFA pages/forms | No OTP/TOTP ever sent to browser; server-side identity/role; no demo autofill |
| P0-09 | 🔴 | Rate limiting + lockout | Rust auth + Next actions | N failed attempts → exponential delay / temporary lock; tested |
| P0-10 | 🔴 | Stop silent success on backend failure | `lib/actions.ts` | Mutations return real errors; no mock write when backend fails; demo mode explicit |
| P0-11 | 🔴 | Secrets hygiene | project root | `.gitignore`, `.env.example` (frontend + backend), no real secrets in tracked files |
| P0-12 | 🔴 | Fix UUID vs slug mismatch | `backend/main.rs` + frontend | All IDs are UUIDs end-to-end; mock slugs removed from real paths |

### Phase 1 — Real Data & Persistence

| ID | Pri | Task | Scope | Done when |
|---|---|---|---|---|
| P1-01 | 🟠 | Data-access layer | `lib/server/*` (new) | One typed server-only module per domain; no page imports `lib/mock` |
| P1-02 | 🟠 | Machines module live | list/detail/overview/telemetry/tanks/stock/hardware/cameras/maintenance/settings | All 13 files read real data |
| P1-03 | 🟠 | Orders module live | list/detail/label/refund/fraud/reissue | 4 files real; refund writes ledger |
| P1-04 | 🟠 | Customers module live | list/360/wallet/codes/push | 5 files real; wallet ledger server-side |
| P1-05 | 🟠 | Inventory module live | overview/tanks/supplies/waste | 4 files real; write-offs audited |
| P1-06 | 🟠 | Analytics module live | 6 pages | SQL aggregates / `003_views.sql`; no mock |
| P1-07 | 🟠 | Marketing module live | 9 pages | Offers/coupons/banners/push/ads persisted |
| P1-08 | 🟠 | Support module live | 7 pages | Tickets/evidence/refunds/blacklist/macros persisted |
| P1-09 | 🟠 | Settings module live | 8 pages | Team/integrations/notifications/billing persisted |
| P1-10 | 🟠 | Replace `globalThis` store | `lib/mock/store.ts` | Audit/tickets/refunds/commands persisted in DB |
| P1-11 | 🟠 | Server-side pagination/filter/sort | list pages | No full-table fetch; query params honoured |
| P1-12 | 🟠 | Real audit trail | DB `audit_logs` | Every mutation writes actor/action/before/after |
| P1-13 | 🟠 | Error/empty/loading states | all modules | API failure visible, retryable, no fake data |

### Phase 2 — Hardware & Operations

| ID | Pri | Task | Done when |
|---|---|---|---|
| P2-01 | 🟠 | MQTT client (`rumqttc`) | Queued commands published; ACK consumed and written |
| P2-02 | 🟠 | Per-machine API keys | Hashed keys in DB; no `mch_key_` prefix bypass |
| P2-03 | 🟠 | FSSAI background watchdog | Periodic worker locks machine + alerts on >8 °C |
| P2-04 | 🟠 | Command TTL sweeper | Cron marks stale `queued/sent` as `expired` |
| P2-05 | 🟠 | Telemetry ingestion buffer | Batched writes; backpressure; pool safe |
| P2-06 | 🟠 | Partition maintenance | `pg_cron`/worker calls `fn_manage_telemetry_partitions` |
| P2-07 | 🟠 | Offline QR protection | Bound to machine(s), single-use after reconcile |
| P2-08 | 🟠 | CCTV clip storage | Upload/signed URL; player works with real clips |
| P2-09 | 🟠 | WhatsApp integration | Provider webhook verified; intake creates ticket |
| P2-10 | 🟠 | Notifications | FCM/SMS dispatch actually sends; delivery receipt stored |
| P2-11 | 🟠 | Observability | `/metrics`, structured logs, request latency, pool stats |

### Phase 3 — Quality & Release

| ID | Pri | Task | Done when |
|---|---|---|---|
| P3-01 | 🟡 | Tests | SQL function (pgTAP), Rust integration, Playwright E2E |
| P3-02 | 🟡 | CI | Build + lint + typecheck + tests on PR |
| P3-03 | 🟡 | Containers | Multi-stage Dockerfiles + compose (web, rust, postgres, broker) |
| P3-04 | 🟡 | Docs | Correct README, env setup, runbook, API docs |
| P3-05 | 🟡 | Migrations | Runner + ordering table; `003` gap closed |
| P3-06 | 🟡 | Security review | OWASP checklist, dependency audit, RLS tests |
| P3-07 | 🟡 | Backup/restore | PITR + restore rehearsal |
| P3-08 | 🟡 | Load/performance | k6/Locust on dashboard + telemetry |
| P3-09 | 🟡 | Release checklist | Staging sign-off, rollback plan |
| P3-10 | 🟡 | UX polish | Search, badges, empty states, a11y |

---

## 5. Detailed P0 Task Sheets (What Exactly To Do)

### P0-01 — Make the backend select one module tree
**Files:** `backend/src/main.rs`
**Steps:**
1. Add explicit paths so Rust never looks for `mod.rs`:
   ```rust
   #[path = "handlers.rs"] mod handlers;
   #[path = "models.rs"]  mod models;
   #[path = "db.rs"]      mod db;
   #[path = "middleware.rs"] mod middleware;
   ```
   (`#[path]` fixes `E0761` without deleting the stale split tree.)
2. Add a comment marking `handlers/*.rs`, `models/*.rs`, `db/*.rs`, `middleware/*.rs` as **archived / do not compile**.
3. Ensure `main.rs` only references functions that exist in the monolith.
**Verify:** `cargo check` (after P0-02/P0-03) reports no `E0761`.

### P0-02 — Replace compile-time SQL macros
**Files:** `backend/src/handlers.rs` (lines 121, 131)
**Steps:**
1. `sqlx::query!("SELECT ...")` → `sqlx::query("SELECT ...").bind(...)`.
2. Read the row via `sqlx::Row` (`row.try_get::<Uuid, _>("id")`) or `query_scalar`.
3. Do the same for any `query_as!` found later.
**Verify:** build works without `DATABASE_URL`.

### P0-03 — Offline-friendly build
**Steps:**
1. Generate `Cargo.lock` (requires network once; needs user approval because it downloads crates).
2. Document `cargo build --offline` after first fetch.
3. Do **not** rely on `.sqlx` once P0-02 is done.
**Note:** This is the only task that may need a dependency download. Ask before running.

### P0-04 — Model/schema reconciliation
**Steps:**
1. For every `query_as::<_, T>("SELECT * ...")`, compare `T` fields with the table.
2. Cast NUMERIC → float8 in SQL:
   `SELECT ..., latitude::float8, longitude::float8, target_temp_c::float8, ...`
3. Preferred: select explicit columns, never `SELECT *`.
4. Map enums explicitly (`status::text`) or keep `sqlx::Type` with exact enum names.
5. Add a smoke test query for each domain (machines, orders, tickets, commands).
**Verify:** each `GET` returns 200 with seeded rows.

### P0-05 — Database objects
**Steps:**
1. Create `schema/003_views.sql` with the analytics views referenced by the UI (sales, product mix, machine comparison, profitability).
2. Add `otp_codes`:
   ```sql
   create table otp_codes (
     id uuid primary key default gen_random_uuid(),
     email text not null,
     code text not null,
     purpose text not null default 'LOGIN',
     used boolean not null default false,
     expires_at timestamptz not null,
     created_at timestamptz not null default now()
   );
   create index idx_otp_email on otp_codes (email, created_at desc);
   ```
   (Or delete the OTP path — but no deletion allowed, so add the table.)
3. Verify `005_seed.sql` inserts at least one `admin_users` row with a real hash.
**Verify:** run schema 001→005 on a scratch Supabase/Postgres; zero errors.

### P0-06 — Rust login
**Steps:**
1. Add a password hashing crate (`argon2` preferred). ⚠️ requires dependency approval.
2. In `login_handler`: load `password_hash`, verify, honour `status`, `locked_until`, `failed_logins`.
3. Load role from `admin_roles` join, not hardcoded `"superadmin"`.
4. Reset `failed_logins` on success; increment + lock on failure.
5. Remove the direct JWT-on-email path.
**Verify:** wrong password → 401; 5 fails → locked; correct → JWT with real role.

### P0-07 — One JWT secret
**Steps:**
1. Standardise on `ADMIN_JWT_SECRET` for both services (or map `JWT_SECRET` → `ADMIN_JWT_SECRET`).
2. Remove `'mc-admin-dev-secret'` and the Rust hardcoded fallback in production.
3. Fail fast at startup if secret is missing/short.
**Verify:** only one env var needed; forged token rejected.

### P0-08 — Next.js auth
**Steps:**
1. `requestOtp`: never return `demoCode`; resolve `role` from the server roster by phone/email, not from the client.
2. `mfa/page.tsx`: stop passing `mfaCode`; stop rendering it.
3. `verifyMfa`: validate a real TOTP (Node `crypto` HMAC-SHA1 implementation or `otplib` — dependency approval needed for the latter).
4. Gate any demo convenience behind `NODE_ENV !== 'production'` and an explicit `DEMO_AUTH=1`.
5. Add rate limiting (per phone + per IP) and lockout.
**Verify:** browser devtools/network and page source contain no OTP/TOTP.

### P0-09 — Rate limiting / lockout
**Steps:** in-memory token bucket for Next dev; DB-backed counters for Rust (`failed_logins`, `locked_until` already exist). Add `Retry-After`.
**Verify:** automated test for 429/lock after threshold.

### P0-10 — Honest mutations
**Steps:** remove `try { await backend... } catch {}`; if backend fails, return `{ ok: false }`, do **not** mutate mock, do **not** toast success. Add an explicit `DEMO_MODE` banner when mocks are used.
**Verify:** stop backend → click Lock/Refund → user sees error, no fake success.

### P0-11 — Secrets hygiene
**Steps:** add `.gitignore` (`node_modules`, `.next`, `target`, `.env*`, `tsconfig.tsbuildinfo`), add `.env.example` for frontend and backend, rotate any secret currently in `backend/.env`, stop tracking build artifacts.
**Verify:** `git status` shows no `.env`.

### P0-12 — UUIDs end-to-end
**Steps:** backend returns UUIDs; frontend stops fabricating `m1`/`MCH-001` for API calls; seed/mock IDs map to real UUIDs.
**Verify:** every link/action uses a UUID accepted by `Path<Uuid>`.

---

## 6. Recommended 1-by-1 Execution Order

Do **not** jump to UI polish. The dependency chain is:

```
P0-01 module fix
   └─ P0-02 runtime queries
        └─ P0-03 build/lockfile (needs approval)
             └─ P0-04 model/schema reconciliation
                  └─ P0-05 DB objects
                       └─ P0-06..P0-09 auth security
                            └─ P0-10..P0-12 honest data/IDs
                                 └─ P1-01..P1-13 real modules (one module per iteration)
                                      └─ P2 hardware/ops
                                           └─ P3 tests/CI/Docker/release
```

**First sprint (suggested):**
1. P0-01 — module ambiguity fix (no install, safe).
2. P0-02 — replace 2 `sqlx::query!` macros.
3. P0-05 — add `003_views.sql` + `otp_codes` (no install).
4. P0-04 — cast NUMERIC / explicit columns in the monolith.
5. P0-07 — unify JWT secret + fail-fast.
6. P0-08 — remove MFA/OTP leakage.
7. P0-10 — honest error handling.
8. P0-11 — env examples + gitignore.
9. P0-12 — UUID flow.
10. P0-06 / P0-09 — password hashing + lockout (needs dependency approval).

Then one module per iteration: Machines → Orders → Customers → Inventory → Analytics → Marketing → Support → Settings.

---

## 7. Definition of Done (Release Gate)

A module is “done” only if all are true:

- [ ] No import of `@/lib/mock` anywhere in its server path.
- [ ] Reads come from Rust/DB; writes are transactional and audited.
- [ ] `GET` returns real rows; failures show an error state (no demo fallback in production).
- [ ] RBAC is enforced server-side (not just hidden buttons).
- [ ] All IDs are UUIDs.
- [ ] `cargo check` / `next build` / `tsc --noEmit` pass.
- [ ] At least one automated test covers the happy path + one failure path.
- [ ] No secret, OTP, or TOTP reaches the browser.
- [ ] Logs/metrics record the operation.

Global release additionally requires:
- [ ] Dockerfile + compose for web/rust/postgres/broker.
- [ ] CI green on a clean checkout.
- [ ] Migrations 001→005 apply cleanly on empty DB.
- [ ] Backup/restore rehearsal passed.
- [ ] Security checklist signed off.

---

## 8. Risk Register

| Risk | Impact | Mitigation |
|---|---|---|
| Editing a 1161-line monolith | High regression risk | Add tests first; change in small commits; keep `#[path]` switch reversible |
| Schema changes without migration runner | Data loss in prod | Add migration ordering table before first deploy |
| JWT secret mismatch during rollout | Total auth outage | Deploy with both names accepted for one release, then remove old |
| Mock→real data migration per module | Long timeline | One module per iteration; feature flag per domain |
| No tests | Silent breakage | P3-01 starts alongside Phase 1, not at the end |
| MQTT not implemented | “Commands” are cosmetic | Treat P2-01 as launch blocker for hardware features |
| Supabase-specific RLS | Cannot deploy to plain Postgres | Decide hosting now; abstract `auth.uid()` or commit to Supabase |

---

## 9. Constraints Honoured in This Audit

- No file deleted.
- No package installed.
- No build attempted (would require installs/network).
- Only `vending-machine/` inspected.
- Report is the only new file.

---

## 10. Next Action

Start with **P0-01 (backend build unblock)** — it is small, safe, reversible, and every other backend task depends on it. Then proceed down the order in section 6, one task per iteration, with verification after each.

---

## 11. Progress Log

### 2026-11-03 — P0-01 ✅ Module ambiguity resolved
- `backend/src/main.rs`: replaced bare `mod db/handlers/middleware/models;` with explicit
  `#[path = "*.rs"]` declarations. The stale split tree (`handlers/`, `models/`, `db/`,
  `middleware/`) is now never compiled; nothing was deleted.
- Verified all 20 handlers referenced by `main.rs` exist in `handlers.rs` (zero missing).

### 2026-11-03 — P0-02 ✅ Compile-time SQL macros removed
- `backend/src/handlers.rs:121-138`: the two `sqlx::query!` macros (on `otp_codes`) were
  replaced with runtime `sqlx::query_scalar(...)` + `sqlx::query(...).bind(...)`.
- Note: `Cargo.toml` never enabled the `sqlx` **`macros`** feature, so these would have
  failed to resolve anyway. No `.sqlx/` offline cache is needed now.
- Remaining canonical files (`models.rs`, `db.rs`, `middleware.rs`, `config.rs`,
  `error.rs`, `main.rs`) contain **zero** compile-time SQL macros.

### ⚠️ Still cannot run `cargo check` here
Dependencies are not vendored (`backend/target/`, `Cargo.lock` absent) and installing them
requires network + user approval, which is currently forbidden. Verification of P0-01/P0-02
is therefore **static** (grep + symbol cross-check), not a compiler run.

### Next task
**P0-05** — add `003_views.sql` + `otp_codes` table (no dependency install needed).

### 2026-11-03 — P0-03 ✅ Offline build documented
- `backend/BUILD.md`: first online build generates `Cargo.lock`; later `cargo build --offline`.
- No `.sqlx` cache needed (P0-02). `Cargo.lock` still must be generated once by the user.

### 2026-11-03 — P0-04 ✅ Models ↔ schema reconciled
- Confirmed every NUMERIC column used by a `FromRow` struct is cast `::float8` in the query.
- Enum columns decode through typed `sqlx::Type` enums (`MachineStatus`, `OrderStatus`, …).
- `machine_commands` insert now casts `$2::command_type`, `$3::jsonb`.
- Added `role` to `admin_users` + `AdminUser` model.

### 2026-11-03 — P0-05 ✅ Missing DB objects added
- New `coffee-vending-db-schema/schema/003_views.sql` (7 `v_admin_*` views, `security_invoker`).
- `otp_codes` table added to `001_full_schema.sql` with expiry/attempts indexes.
- `005_seed.sql` seeds 6 admin identities (bcrypt via `pgcrypto.crypt`) + roles.

### 2026-11-03 — P0-06 ✅ Real password + RBAC in Rust
- `handlers.rs` login now bcrypt-verifies `password_hash`, rejects empty/wrong passwords.
- Role comes from `admin_users.role`; permissions from `admin_roles.permissions`.
- OTP handler no longer hardcodes `superadmin`.
- Added `bcrypt = "0.15"` to `Cargo.toml` (fetch happens on the next build).

### 2026-11-03 — P0-07 ✅ One JWT secret, fail fast
- `config.rs` reads `ADMIN_JWT_SECRET` → `JWT_SECRET`, panics in production if missing/<32 chars.
- `lib/auth.ts` + `middleware.ts`: same name, production throws instead of using a dev secret.
- `backend/.env` gained `ADMIN_JWT_SECRET`; `adminflow-next/.env.example` added.

### 2026-11-03 — P0-08 ✅ No OTP/TOTP leakage
- `requestOtp` derives role from the server roster by phone; never returns the code.
- `PendingToken` no longer carries `mfaCode`; MFA page/form no longer render or autofill it.
- `verifyMfa` uses real RFC-6238 TOTP (`lib/auth.ts`), server-side only.
- Dev secrets/codes are logged to the server console only, never sent to the browser.

### 2026-11-03 — P0-09 ✅ Rate limiting / lockout
- Rust: 5 failed logins → 15-minute lock via `failed_logins` / `locked_until`; 429 response.
- OTP rows stop matching after 5 attempts (`attempts < 5`), attempts increment on failure.
- Next: fixed-window limiter for OTP request, OTP verify and MFA (per phone).

### 2026-11-03 — P0-10 ✅ Honest mutations
- Backend calls no longer swallow errors: `machineCommand`, `pushOta`, `orderRefund`,
  `disputeResolve` return `{ ok: false }` instead of faking success.
- Mock fallback only when `DEMO_MODE=1` **and** `NODE_ENV !== 'production'`.

### 2026-11-03 — P0-11 ✅ Secrets hygiene
- Root `.gitignore` covers `node_modules`, `.next`, `backend/target`, `.env*`,
  `*.tsbuildinfo`, keys and logs.
- `adminflow-next/.env.example` and `backend/.env.example` added (no real secrets).
- `adminflow-next/README.md` rewritten (no AI-Studio leftovers).

### 2026-11-03 — P0-12 ✅ UUIDs for machine flows
- Seed machines now use deterministic UUIDs:
  `a1b2c3d4-0001-4000-8000-000000000001` (MCH-001),
  `a1b2c3d4-0002-4000-8000-000000000002` (MCH-002).
- Mock fleet, commands, tanks, stock, orders, analytics and links now use the
  same UUIDs (104 references), so `Path<Uuid>` routes resolve.
- Orders/tickets still need real seeded rows before their actions can succeed;
  those now fail honestly instead of faking success.

### 2026-11-03 — Ops / delivery scaffolding (P2/P3 groundwork)
- `backend/Dockerfile`, `adminflow-next/Dockerfile` (Next `output: standalone`).
- `docker-compose.yml`: postgres + mosquitto + backend + web.
- `coffee-vending-db-schema/schema/migrate.sh` (RLS opt-in via `WITH_RLS=1`).
- `.github/workflows/ci.yml`: web typecheck/lint/build, Rust fmt/clippy/build,
  Postgres schema apply + smoke query.
- `README.md`: correct setup, security notes, known gaps.

### 2026-11-03 — Audit trail + tests
- `handlers.rs`: best-effort `write_audit()` on login, hardware command,
  refund and ticket resolution.
- `models.rs`: unit tests for owner/support/finance permission matrix.




### 2026-11-03 — P1 Auth bridge + live read models
- **Auth bridge fixed**: the Next session JWT now carries `sub`, `email` and
  `permissions` in addition to `uid`/`name`/`role` (`lib/auth.ts` →
  `sessionClaims()`), so the Rust `AdminClaims` decode succeeds on protected
  routes instead of returning 401.
- Seeded admin `id`s are deterministic (`c0ffee00-…`) and match `DEMO_ADMINS`,
  so `requested_by` / `approved_by` audit FKs resolve.
- Added `adminflow-next/.env.local` (gitignored) with the same
  `ADMIN_JWT_SECRET` as `backend/.env`.
- New Rust read endpoints (all behind `auth_middleware`):
  `/api/live/orders`, `/api/live/tickets`, `/api/live/customers`,
  `/api/live/inventory`, `/api/live/tanks`, `/api/live/analytics`,
  `/api/live/audit`.
- `lib/live.ts`: server-side adapters map backend rows into the existing view
  models with an honest `DEMO_MODE`-gated fallback.
- Wired to live data: dashboard, machines list + detail shell, orders list and
  detail, customers list and detail, inventory matrix, support SLA board and
  ticket list.
- Fixed `getLiveMachines` response typing (`{ machines: [...] }`) and the
  dashboard adapter that was silently ignoring live machine chips.
- Dashboard now renders an explicit "backend unreachable" panel instead of
  crashing or fabricating metrics.

### Remaining
- Machine sub-tabs (telemetry, tanks, stock, maintenance, hardware, cameras)
  still read `lib/mock/*`.
- Marketing and settings pages are static config/demo content.
- MQTT publish/ACK worker, CCTV storage, WhatsApp signature verification.
