# EGM Swarm Comprehensive Audit: Coffee Vending Machine Ecosystem

> [!CAUTION]
> **Production Readiness Verdict: 0% Ready (CRITICAL BLOCKERS DETECTED)**
> The Coffee Vending Machine platform currently exists as three mutually disconnected layers: a Next.js 15 UI running on volatile in-memory JavaScript mocks, an incomplete Rust Axum backend containing authentication backdoors and SQL injections, and an over-engineered 68-table PostgreSQL database containing runtime syntax crashes.

---

## 1. Executive Summary & Readiness Scorecard

An ensemble audit was executed using four specialized EGM auditor personas:
- **Hostile Architecture Critic** ([`egm-design`](file:///sdcard/download/vending-machine/adminflow-next/backend))
- **Technical Quality Auditor** ([`egm-codebase-details`](file:///sdcard/download/vending-machine/adminflow-next/lib))
- **Skeptical Minimalism Architect** ([`egm-zoom-out`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema))
- **Pragmatic Tech Lead** ([`egm-implementation-readiness`](file:///sdcard/download/vending-machine/adminflow-next))

```mermaid
xychart-beta
    title "EGM Swarm Production Readiness Scorecard (out of 100)"
    x-axis ["Database (PostgreSQL)", "Frontend (Next.js)", "Backend (Rust Axum)", "Operations & CI/CD", "Overall System"]
    y-axis "Readiness Score" 0 --> 100
    bar [65, 25, 20, 10, 18]
```

### Readiness Breakdown
| Layer | Score | Status | Primary Reason |
| :--- | :---: | :---: | :--- |
| **Database (PostgreSQL / Supabase)** | **65 / 100** | Needs Patches | Robust schema & financial ledger primitives, but blocked by syntax errors in `fn_write_audit` and missing cron runners. |
| **Frontend (Next.js 15)** | **25 / 100** | Simulated | 100% of mutations hit volatile RAM (`globalThis.__mcStore`); zero HTTP calls to Rust; 52 of 53 routes yield 404s. |
| **Backend (Rust Axum)** | **20 / 100** | Insecure | Passwords never checked; hardcoded OTP backdoors (`123456`, `888222`); SQL injection; hardware commands never sent. |
| **Operations & Observability** | **10 / 100** | Deficient | No Dockerfile; no CI/CD; no Prometheus metrics; no milk temperature health watchdog or alerting. |
| **End-to-End Operational Pipeline** | **18 / 100** | Broken | The three layers do not communicate with each other at runtime. |

---

## 2. The "Three Disconnected Universes" Anti-Pattern

```mermaid
flowchart TD
    subgraph UniverseA ["Universe A: Next.js 15 Console (Simulated)"]
        UI["53 Dashboard Routes"]
        MockStore["In-Memory Store (globalThis.__mcStore)"]
        ServerActions["Server Actions (lib/actions.ts)"]
        AnonSupabase["Supabase Client (anon key)"]
        UI --> ServerActions
        ServerActions -->|Mutates| MockStore
        UI -.->|Queries fail under RLS| AnonSupabase
        AnonSupabase -.->|Silent Fallback| DemoData["Static Demo Data (lib/demo-data.ts)"]
    end

    subgraph UniverseB ["Universe B: Orphaned Rust Axum Microservice"]
        AxumRoutes["Axum Endpoints (:8080)"]
        AuthBypass["Auth: Password Never Verified + Hardcoded OTP"]
        SQLx["SQLx Queries (Raw & Deserialization Errors)"]
        GhostDispatch["Simulated Hardware ACK (rand ms)"]
        AxumRoutes --> AuthBypass
        AxumRoutes --> SQLx
        AxumRoutes --> GhostDispatch
    end

    subgraph UniverseC ["Universe C: PostgreSQL 16 Schema"]
        SchemaTables["68 Speculative Tables"]
        StoredProcs["Deep Stored Procedures (fn_redeem_qr_code)"]
        BuggyTriggers["Broken fn_write_audit (Type Crash on Update)"]
        RLS["Strict Row Level Security (Blocks Anon Reads)"]
        SchemaTables --> StoredProcs
        SchemaTables --> BuggyTriggers
        SchemaTables --> RLS
    end

    UniverseA x-- "Zero HTTP Calls (backend-client.ts orphaned)" --x UniverseB
    UniverseB x-- "Bypasses Stored Procedures & Ledger Triggers" --x UniverseC
    UniverseA x-- "Blocked by RLS (Fails to Mocks)" --x UniverseC
```

---

## 3. Critical Blockers (P0 Immediate Vulnerabilities & Crashes)

### 3.1. Authentication Backdoors & Security Bypasses
- **Password Check Omitted**: In [`backend/src/handlers.rs#L41-L76`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L41-L76), `login_handler` fetches the user by email and immediately mints an administrative JWT. `payload.password` is **never compared against `password_hash`** (the backend does not even import `argon2` or `bcrypt`). Anyone knowing an operator email gains full access without credentials.
- **Hardcoded Superadmin Master Emails**: Supplying `admin@manhattancoffee.in` or `operator@manhattancoffee.in` bypasses database checks entirely and assigns dummy UUID `00000000-0000-0000-0000-000000000001`.
- **Hardcoded Global OTPs**: In [`handlers.rs#L128`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L128) and [`handlers/auth.rs#L63`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers/auth.rs#L63), codes `"123456"`, `"654321"`, and `"888222"` bypass verification.
- **Root Elevation in Middleware**: In [`middleware/auth.rs#L94-L104`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/middleware/auth.rs#L94-L104), unauthenticated requests without cookies or bearer headers fall into an `else` block that injects `user_id: "usr_sandbox_dev"` with `UserRole::Owner`.

### 3.2. Fatal SQL Syntax Crashes on Core Operations
- **`fn_write_audit` Illegal Type Cast**: In [`004_rls_policies.sql#L535`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/004_rls_policies.sql#L535):
  ```sql
  coalesce(fn_is_admin() and 'admin'::sub_entity_type, 'system'::sub_entity_type)
  ```
  PostgreSQL `AND` requires boolean operands. Attempting `boolean AND enum` causes: `ERROR: argument of AND must be type boolean, not type sub_entity_type`.
  > [!IMPORTANT]
  > Because triggers using `fn_write_audit()` are attached to 14 core tables (`machines`, `products`, `machine_stock`, `support_tickets`, `refunds`), **any `UPDATE` or `DELETE` on these tables crashes the database transaction.**
- **`fn_resolve_ticket` Undeclared Identifier**: In [`002_functions.sql#L792`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/002_functions.sql#L792), `v_ticket_id` is referenced without being declared in the `DECLARE` block (the parameter is `p_ticket_id`). Dispute resolution crashes with `ERROR: column "v_ticket_id" does not exist`.
- **`fn_ticket_evidence_bundle` Non-Existent Column**: In [`002_functions.sql#L729`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/002_functions.sql#L729), the query attempts `where e.code_id = t.code_id`. `support_tickets` has no `code_id` column, throwing `ERROR: column t.code_id does not exist`.

### 3.3. Direct SQL Injection
- In [`backend/src/handlers/machines.rs#L53-L68`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers/machines.rs#L53-L68), machine telemetry update dynamically formats SQL strings:
  ```rust
  if let Some(ref st) = payload.status {
      query.push_str(&format!(", status = '{st}'"));
  }
  query.push_str(&format!(" WHERE id = '{id}'"));
  ```
  Unsanitized values allow arbitrary SQL execution.

### 3.4. Non-Transactional Refunds & Ledger Breach
- In [`backend/src/handlers.rs#L647-L695`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L647-L695), `process_refund` executes three uncoordinated queries without a transaction (`pool.begin()`).
- Line 683 directly updates `wallets SET balance_paise = balance_paise + $2` while bypassing `wallet_transactions`, breaking the append-only accounting ledger invariant.
- Database errors during wallet credit are silently discarded via `.ok()`.

---

## 4. Codebase Design & Module Depth Analysis

Applying principles from [`codebase-design`](file:///sdcard/download/vending-machine/.agents/skills/codebase-design/SKILL.md):

### 4.1. Shallow vs. Deep Modules
- **Shallow Pass-Throughs in Rust**: Handlers like `list_machines` ([`handlers.rs#L342`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L342)) and `list_orders` ([`handlers.rs#L536`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L536)) are thin wrappers around `SELECT * FROM ... LIMIT 50`. They provide zero leverage to callers and expose raw table schemas over HTTP.
- **Inverted Depth in Database**: The stored procedure [`fn_redeem_qr_code`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/002_functions.sql#L202-L250) is genuinely **deep**: behind a 3-argument interface (`p_code`, `p_machine_id`, `p_user_id`), it encapsulates row-level locking (`FOR UPDATE`), machine online validation, stock decrement, and order generation. However, the Rust backend bypasses this procedure to run shallow manual SQL queries.
- **The Deletion Test**: Deleting the Rust microservice today results in **zero loss of business logic**, because the Next.js frontend uses in-memory mock actions and Rust contains only shallow query pass-throughs.

### 4.2. Locality & Accidental Complexity
Executing a single business capability (e.g., **Order Refund**) currently touches 6 decoupled files across 3 languages:
1. `001_full_schema.sql` (Postgres table & status enum)
2. `002_functions.sql` (Postgres wallet ledger triggers)
3. `backend/src/handlers.rs` (Rust raw SQL updates)
4. `adminflow-next/lib/actions.ts` (Next.js server action)
5. `adminflow-next/lib/mock/store.ts` (JavaScript in-memory array patch)
6. `adminflow-next/lib/auth.ts` (Next.js RBAC capability guard)

Knowledge is scattered with **zero locality**.

---

## 5. Type and Schema Drift Matrix

| Domain | PostgreSQL Schema ([`001_full_schema.sql`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/001_full_schema.sql)) | Rust Axum Models ([`backend/src/models/`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/models)) | Next.js Frontend Types ([`lib/mock/types.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/mock/types.ts)) | Consequence |
| :--- | :--- | :--- | :--- | :--- |
| **Money Representation** | `amount_paise integer` (Strict integer paise) | `pub amount_inr: f64` (Float currency) | `amount: number` (Rupees float) | Floating point rounding errors; SQLx query deserialization crashes. |
| **Enum Case** | Lowercase: `'created'`, `'refunded'`, `'active'` | Uppercase: `'REFUNDED'`, `'ONLINE'`, `'OPEN'` | Lowercase strings: `'refunded'` | SQL execution throws: `invalid input value for enum`. |
| **Machine Fields** | `machine_code`, `city`, `locality` | `code`, `location`, `zone`, `boiler_pressure` | `name`, `status`, `temp` | `sqlx::query_as::<_, Machine>` fails; handler returns `[]`. |
| **Non-Existent Tables** | *Does not exist* | Queries `otp_codes` & `audit_logs` | Maintains fake audit array | Handlers fail with database relation errors. |
| **Session Cookie** | N/A (Internal auth) | Reads cookie `auth_token` or `session_token` | Writes cookie `mc_admin_session` | Incompatible cookies prevent cross-service authentication. |

---

## 6. IoT Hardware & Telemetry Engineering

```mermaid
sequenceDiagram
    autonumber
    participant Machine as IoT Vending Machine
    participant Edge as Axum Telemetry Endpoint
    participant Buffer as Async Ingestion Buffer
    participant Postgres as PostgreSQL (Partitioned)
    participant Watchdog as Health Watchdog Worker
    participant Ops as Alert System (WhatsApp / PagerDuty)

    Machine->>Edge: POST /api/machines/:id/telemetry (HMAC Signed)
    Edge->>Buffer: Push Sensor Packet (Temp, Flow, Stock)
    Edge-->>Machine: 200 OK (Instant Response)
    Buffer->>Postgres: Batched Flush (UNNEST / COPY)
    Buffer->>Watchdog: Inspect Sensor Readings
    alt Milk Temp > 8°C (3 consecutive readings)
        Watchdog->>Postgres: Enqueue Machine Emergency Lock
        Watchdog->>Ops: Dispatch Critical Spoilage Alarm
    end
```

### Critical Hardware Flaws
1. **Telemetry Ingest Locked Behind Admin JWT**: `PATCH /api/machines/:id/telemetry` requires interactive admin login credentials instead of machine hardware keys (`X-Machine-Key`).
2. **Ghost Hardware Command Dispatch**: Enqueuing hardware commands (`clean_cycle`, `lock_machine`) inserts a row in `machine_commands`, but no MQTT broker client (`rumqttc`) exists to push the payload to the physical machine. Commands expire unexecuted.
3. **Missing Health Watchdogs**: If milk temperature exceeds FSSAI health limits (> 8°C), the system takes no automated action and sends no alerts.
4. **Offline QR Double-Spend**: Empty `machine_ids` arrays default vouchers to fleet-wide affinity, allowing identical offline QR tokens to be redeemed across multiple offline machines before network reconciliation occurs.

---

## 7. Step-by-Step Remediation Roadmap

### Phase P0: Critical Stabilizers (Immediate)
1. **Fix PostgreSQL Syntax Errors**:
   - In [`004_rls_policies.sql#L535`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/004_rls_policies.sql#L535), replace `and` with `CASE WHEN fn_is_admin() THEN 'admin'::sub_entity_type ELSE 'system'::sub_entity_type END`.
   - In [`002_functions.sql#L792`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/002_functions.sql#L792), change `v_ticket_id` to `p_ticket_id`.
   - In [`002_functions.sql#L729`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/002_functions.sql#L729), join `orders` to retrieve `code_id`.
2. **Harden Rust Authentication**:
   - Add `argon2 = "0.5"` to `Cargo.toml`; verify `payload.password` against `user.password_hash`.
   - Eliminate hardcoded fallback emails and OTP codes (`123456`, `654321`, `888222`).
   - Remove the unauthenticated sandbox fallback in `middleware/auth.rs`.
3. **Bridge Frontend to Database**:
   - Standardize on shared JWT secret and cookie (`mc_admin_session`).
   - Replace volatile in-memory mutations in Next.js `lib/actions.ts` with real database operations.
4. **Fix Telemetry Route Access**:
   - Relocate `PATCH /api/machines/:id/telemetry` to machine API key authentication.
   - Place `/api/live/dashboard` behind admin authentication.

### Phase P1: Production Hardening (Near-Term)
1. **Hardware MQTT Engine**: Add `rumqttc` to Rust backend to listen for queued `machine_commands` and transmit payloads to physical machines.
2. **Database Maintenance Scheduler**: Configure `pg_cron` or background worker for monthly partition rollups and stale milk tank expiry (`fn_expire_stale_tanks`).
3. **Schema Pruning**: Drop unused speculative tables (`ad_impressions`, `leaderboard_entries`, `video_clips`) to streamline the schema down to core operational tables.
4. **Containerization & CI/CD**: Create multi-stage `Dockerfile` for Rust Axum and Next.js; add GitHub Actions pipeline for automated compilation and linting.

### Phase P2: Operational Excellence (Polish)
1. **FSSAI Watchdog**: Add automatic emergency lockout when milk temperature sensor exceeds 8°C.
2. **Prometheus Metrics**: Expose `/metrics` endpoint in Axum tracking request latencies, pool utilization, and dispense variance.
3. **Telemetry Ingestion Buffer**: Implement Tokio channel buffering to batch telemetry writes and prevent connection pool exhaustion.
