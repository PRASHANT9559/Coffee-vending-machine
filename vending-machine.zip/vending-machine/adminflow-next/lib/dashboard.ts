import {
  DashboardData,
  MachineChip,
  RangeKey,
  StatusSlice,
  TrendData,
  VariantSlice,
} from './dashboard-types';
import {
  backendApi,
  type RustLiveDashboardMetrics,
  type RustLiveMachine,
} from './backend-client';
import {
  istDisplayDate,
  istParts,
} from './time';
import { hourLabel, paise } from './format';
import { demoData } from './demo-data';

/* ─────────────────────────────────────────────────────────────
   Data layer for the dashboard.
   
   TRUST BOUNDARY ARCHITECTURE:
   • The admin panel never talks to the database directly.
   • Every read and write passes through the Rust microservice (:8080).
   • Fallback to demoData() only if the Rust microservice is offline.
   ───────────────────────────────────────────────────────────── */

function rustMachineChips(machines: RustLiveMachine[]): MachineChip[] {
  const now = Date.now();
  return machines.map(m => {
    const lastPingMs = m.last_ping_at ? new Date(m.last_ping_at).getTime() : 0;
    const isLive = (now - lastPingMs) < 120_000; // pinged within 2 min
    const isOnline = m.status === 'active' || m.status === 'online' || isLive;
    return {
      id: m.id,
      code: m.machine_code,
      name: m.name,
      mode: m.mode || 'hot',
      tempC: m.milk_temp_c ?? null,
      litres: m.milk_level_l ?? null,
      malaiL: null,
      cups: m.cup_stack_count ?? 0,
      live: isLive,
      online: isOnline,
    };
  });
}

function buildRustDashboard(
  metrics: RustLiveDashboardMetrics,
  machines: RustLiveMachine[],
  date: string,
): DashboardData {
  const base = demoData(date);
  const live = machines.length > 0 ? rustMachineChips(machines) : base.live;

  const todayRevenue = metrics.sales?.today_revenue_inr ?? (metrics.sales?.today_revenue_paise ? metrics.sales.today_revenue_paise / 100 : base.stats.revenueToday);
  const todayOrders = metrics.sales?.today_orders ?? base.stats.ordersToday;
  const activeMachines = metrics.machines?.active ?? base.stats.activeMachines;
  const totalMachines = metrics.machines?.total ?? (machines.length > 0 ? machines.length : base.stats.totalMachines);
  const avgOrder = todayOrders > 0 ? Math.round(todayRevenue / todayOrders) : base.stats.avgOrder;

  return {
    ...base,
    source: 'rust',
    date,
    live,
    stats: {
      ...base.stats,
      revenueToday: Math.round(todayRevenue),
      ordersToday: todayOrders,
      activeMachines,
      totalMachines,
      avgOrder,
    },
    insights: {
      ...base.insights,
      walletFloat: base.insights.walletFloat,
      adRevenue: base.insights.adRevenue,
    },
  };
}

/** Public entry — routes directly through the Rust Axum microservice (:8080).
 * Never queries Supabase directly. Falls back safely if the service is starting up.
 */
export async function getDashboardData(): Promise<DashboardData> {
  const date = istDisplayDate();
  try {
    const [liveDashRes, liveMachinesRes] = await Promise.all([
      backendApi.getLiveDashboard(),
      backendApi.getLiveMachines(),
    ]);

    if (liveDashRes.success && liveDashRes.data) {
      return buildRustDashboard(
        liveDashRes.data,
        liveMachinesRes.data?.machines ?? [],
        date,
      );
    }
  } catch {
    // P0-10: fabricated metrics are opt-in demo only.
    if (process.env.DEMO_MODE === '1' && process.env.NODE_ENV !== 'production') {
      return demoData(date);
    }
    throw new Error('Rust backend unavailable — dashboard data could not be loaded.');
  }

  if (process.env.DEMO_MODE === '1' && process.env.NODE_ENV !== 'production') {
    return demoData(date);
  }
  throw new Error('Rust backend returned no dashboard payload.');
}
