/**
 * Manhattan Coffee — Backend API Client
 * Connects Next.js Server Components and Server Actions to the high-performance
 * Rust backend running on port 8080 (or process.env.RUST_BACKEND_URL).
 */

const BACKEND_BASE_URL = process.env.RUST_BACKEND_URL || 'http://127.0.0.1:8080';

export interface BackendRequestOptions extends RequestInit {
  token?: string;
  params?: Record<string, string | number | boolean | undefined>;
}

export interface RustLiveDashboardMetrics {
  timestamp: string;
  machines: {
    total: number;
    active: number;
    offline: number;
    maintenance: number;
    online_pct: number;
  };
  sales: {
    today_orders: number;
    today_revenue_paise: number;
    today_revenue_inr: number;
  };
  support: {
    open_tickets: number;
    pending_disputes: number;
  };
}

export interface RustLiveMachine {
  id: string;
  machine_code: string;
  name: string;
  status: string;
  mode: 'hot' | 'cold' | 'off';
  target_temp_c?: number | null;
  cup_stack_count?: number;
  max_cup_stack?: number;
  is_locked: boolean;
  last_ping_at: string | null;
  milk_temp_c?: number | null;
  milk_level_l?: number | null;
  signal_dbm?: number | null;
}

export interface RustMachineCommand {
  id: string;
  machine_id: string;
  command_type: string;
  payload: any;
  status: 'queued' | 'sent' | 'acked' | 'success' | 'failed' | 'expired';
  requested_by: string | null;
  requested_at: string;
  sent_at: string | null;
  acked_at: string | null;
  completed_at: string | null;
  expires_at: string | null;
  result: any;
  error: string | null;
}

async function resolveAuthToken(explicitToken?: string): Promise<string | undefined> {
  if (explicitToken) return explicitToken;
  try {
    const { cookies } = await import('next/headers');
    const jar = await cookies();
    return (
      jar.get('mc_admin_session')?.value ||
      jar.get('session_token')?.value ||
      jar.get('auth_token')?.value
    );
  } catch {
    return undefined;
  }
}

export async function backendFetch<T = any>(
  endpoint: string,
  options: BackendRequestOptions = {}
): Promise<{ success: boolean; data?: T; error?: string; status: number }> {
  const { token, params, headers, ...restOptions } = options;

  let url = `${BACKEND_BASE_URL}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;

  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        searchParams.append(key, String(value));
      }
    });
    const qs = searchParams.toString();
    if (qs) {
      url += `?${qs}`;
    }
  }

  const defaultHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };

  const effectiveToken = await resolveAuthToken(token);
  if (effectiveToken) {
    defaultHeaders['Authorization'] = `Bearer ${effectiveToken}`;
    defaultHeaders['Cookie'] = `mc_admin_session=${effectiveToken}; session_token=${effectiveToken}; auth_token=${effectiveToken}`;
  }

  try {
    const res = await fetch(url, {
      ...restOptions,
      headers: {
        ...defaultHeaders,
        ...(headers as Record<string, string>),
      },
      cache: 'no-store',
    });

    const data = await res.json().catch(() => null);

    if (!res.ok) {
      return {
        success: false,
        error: data?.error || `Backend request failed with status ${res.status}`,
        status: res.status,
      };
    }

    return {
      success: true,
      data,
      status: res.status,
    };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'Failed to connect to Rust backend service',
      status: 503,
    };
  }
}

// ─────────────────────────────────────────────────────────────
// Typed Helper Methods
// ─────────────────────────────────────────────────────────────

export const backendApi = {
  // Health
  checkHealth: () => backendFetch<{ status: string }>('/health'),

  // Live Fleet Dashboard
  getLiveDashboard: (token?: string) =>
    backendFetch<RustLiveDashboardMetrics>('/api/live/dashboard', { token }),

  getLiveMachines: (token?: string) =>
    backendFetch<{ timestamp: string; total: number; machines: RustLiveMachine[] }>('/api/live/machines', { token }),

  // Live joined read models (admin panel)
  liveOrders: (token?: string) => backendFetch('/api/live/orders', { token }),
  liveTickets: (token?: string) => backendFetch('/api/live/tickets', { token }),
  liveCustomers: (token?: string) => backendFetch('/api/live/customers', { token }),
  liveInventory: (token?: string) => backendFetch('/api/live/inventory', { token }),
  liveTanks: (token?: string) => backendFetch('/api/live/tanks', { token }),
  liveAnalytics: (token?: string) => backendFetch('/api/live/analytics', { token }),
  liveAudit: (token?: string) => backendFetch('/api/live/audit', { token }),

  // Machines
  listMachines: (token?: string) => backendFetch('/api/machines', { token }),
  getMachine: (id: string, token?: string) => backendFetch(`/api/machines/${id}`, { token }),
  updateTelemetry: (id: string, telemetry: any, token?: string) =>
    backendFetch(`/api/machines/${id}/telemetry`, {
      method: 'PATCH',
      token,
      body: JSON.stringify(telemetry),
    }),
  dispatchCommand: (id: string, commandType: string, payload: any = {}, token?: string) =>
    backendFetch(`/api/machines/${id}/command`, {
      method: 'POST',
      token,
      body: JSON.stringify({ command_type: commandType, payload }),
    }),
  listMachineCommands: (id: string, token?: string) =>
    backendFetch<{ success: boolean; machine_id: string; count: number; commands: RustMachineCommand[] }>(
      `/api/machines/${id}/commands`,
      { token },
    ),
  ackCommand: (id: string, result?: any, error?: string, token?: string) =>
    backendFetch(`/api/commands/${id}/ack`, {
      method: 'POST',
      token,
      body: JSON.stringify({ result, error }),
    }),

  // Orders
  listOrders: (params?: { limit?: number; offset?: number }, token?: string) =>
    backendFetch('/api/orders', { params, token }),
  getOrder: (id: string, token?: string) => backendFetch(`/api/orders/${id}`, { token }),
  refundOrder: (id: string, reason: string, destination: string = 'wallet', token?: string) =>
    backendFetch(`/api/orders/${id}/refund`, {
      method: 'POST',
      token,
      body: JSON.stringify({ reason, destination }),
    }),

  // Support & Dispute Desk
  listTickets: (token?: string) => backendFetch('/api/support/tickets', { token }),
  getTicket: (id: string, token?: string) => backendFetch(`/api/support/tickets/${id}`, { token }),
  resolveDispute: (id: string, verdict: string, notes: string = '', token?: string) =>
    backendFetch(`/api/support/tickets/${id}/resolve`, {
      method: 'POST',
      token,
      body: JSON.stringify({ verdict, notes }),
    }),
  intakeWhatsAppTicket: (payload: { phone: string; message: string; ticket_type?: string; order_no?: string; upi_ref?: string }) =>
    backendFetch('/api/support/tickets/whatsapp', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  sweepTicketTimers: (token?: string) =>
    backendFetch('/api/support/tickets/sweep', {
      method: 'POST',
      token,
    }),
};
