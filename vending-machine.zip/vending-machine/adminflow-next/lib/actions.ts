'use server';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import {
  DEMO_ADMINS, MAINT_COOKIE, PENDING_COOKIE, SESSION_COOKIE,
  TRUST_COOKIE, signToken, readToken, requireAdmin, roleCan,
  verifyTotp, currentTotp, sessionClaims,
  type AdminSession, type Role, type Cap, type PendingToken,
} from '@/lib/auth';
import { backendApi } from '@/lib/backend-client';
import {
  appendCommand, appendWalletTxn, claimTicket, createTicket, nextTicketNum,
  pushAudit, pushDeniedAudit, resolveTicket, setRefundState, markFraud, markRefunded,
  patchOrder, setMachinePatch,
} from '@/lib/mock/store';

/* ─────────────────────────────────────────────────────────────
   Server actions — auth pipeline + authenticated RBAC mutations.
   Client-supplied who/role arguments are discarded; caller
   identity and permissions are strictly resolved from session.
   ───────────────────────────────────────────────────────────── */

const jar = () => cookies();

/* P0-10 — demo mode is explicit opt-in and impossible in production. */
const DEMO_MODE = process.env.DEMO_MODE === '1' && process.env.NODE_ENV !== 'production';

function backendDown(what: string): { ok: false; message: string } {
  return {
    ok: false,
    message: `Backend unavailable — ${what} was NOT saved. Check the Rust service and retry.`,
  };
}

/* P0-09 — per-instance fixed-window rate limiter (OTP / MFA / login). */
const buckets = new Map<string, { count: number; reset: number }>();
function hitRateLimit(key: string, limit: number, windowMs: number): { ok: boolean; retryAfter: number } {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.reset <= now) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return { ok: true, retryAfter: 0 };
  }
  bucket.count += 1;
  return { ok: bucket.count <= limit, retryAfter: Math.ceil((bucket.reset - now) / 1000) };
}

/* ── auth: request otp (login step 1) ───────────────────────── */
export async function requestOtp(formData: FormData): Promise<{ ok: boolean; message: string }> {
  const phone = String(formData.get('phone') ?? '').trim();

  // P0-08: identity AND role come from the server roster, never the client.
  const admin = DEMO_ADMINS.find(a => a.phone === phone);
  if (!admin) return { ok: false, message: 'No administrator is registered with this phone number.' };
  if (admin.suspended) return { ok: false, message: 'Account suspended — contact the owner.' };

  const rl = hitRateLimit(`otp:${phone}`, 5, 15 * 60_000);
  if (!rl.ok) return { ok: false, message: `Too many OTP requests — retry in ${rl.retryAfter}s.` };

  const code = String(Math.floor(100000 + Math.random() * 900000));
  const payload: PendingToken = { phone, role: admin.role, code, kind: 'pending' };
  const token = await signToken(payload, 0.0104); // ≈15 min
  (await jar()).set(PENDING_COOKIE, token, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 900 });

  // Dev convenience only: printed to the server console, never returned to the browser.
  if (process.env.NODE_ENV !== 'production') {
    console.info(`[auth] dev OTP for ${phone}: ${code}`);
  }
  return { ok: true, message: `OTP sent to ${phone}` };
}

/* ── auth: verify otp (login step 2 → /mfa) ─────────────────── */
export async function verifyLoginOtp(formData: FormData): Promise<{ ok: boolean; message: string }> {
  const code = String(formData.get('otp') ?? '').trim();
  const pending = await readPending();
  if (!pending) return { ok: false, message: 'Session expired — request a new OTP.' };

  const rl = hitRateLimit(`otp-verify:${pending.phone}`, 5, 10 * 60_000);
  if (!rl.ok) return { ok: false, message: `Too many attempts — retry in ${rl.retryAfter}s.` };

  if (code !== pending.code) {
    return { ok: false, message: 'Invalid OTP code.' };
  }
  redirect('/mfa');
  return { ok: true, message: 'Redirecting to 2FA.' };
}

/* ── auth: mfa verify (login step 3 → dashboard) ────────────── */
export async function verifyMfa(formData: FormData): Promise<void> {
  const code = String(formData.get('code') ?? '').replace(/\D/g, '');
  const pending = await readPending();
  if (!pending) {
    redirect('/login');
    return;
  }

  const rl = hitRateLimit(`mfa:${pending.phone}`, 5, 5 * 60_000);
  if (!rl.ok) {
    redirect('/mfa?err=throttled');
    return;
  }

  // P0-08: real RFC-6238 TOTP; the code is never generated for, or shown to,
  // the browser. Dev fallback secret is only used outside production.
  const devSecret = 'JBSWY3DPEHPK3PXP';
  const totpSecret = process.env.ADMIN_TOTP_SECRET
    ?? (process.env.NODE_ENV !== 'production' ? devSecret : '');
  if (!totpSecret || !verifyTotp(totpSecret, code)) {
    redirect('/mfa?err=wrong');
    return;
  }
  if (process.env.NODE_ENV !== 'production' && !process.env.ADMIN_TOTP_SECRET) {
    console.info(`[auth] dev TOTP secret ${devSecret} — current code ${currentTotp(devSecret)}`);
  }

  const admin = DEMO_ADMINS.find(a => a.phone === pending.phone && a.role === pending.role);
  if (!admin) {
    redirect('/login?err=suspended');
    return;
  }

  const session: AdminSession = { uid: admin.uid, name: admin.name, role: admin.role, email: admin.email };
  const j = await jar();
  j.set(SESSION_COOKIE, await signToken(sessionClaims(session), 7), { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 7 * 86400 });
  if (String(formData.get('trust') ?? '') === '1') {
    j.set(TRUST_COOKIE, '1', { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 30 * 86400 });
  }
  j.delete(PENDING_COOKIE);
  pushAudit(admin.name, admin.role, 'auth.login', { detail: 'OTP + TOTP verified · device noted' });

  const next = String(formData.get('next') ?? '/') || '/';
  redirect(next);
}

async function readPending(): Promise<PendingToken | null> {
  const raw = (await jar()).get(PENDING_COOKIE)?.value;
  if (!raw) return null;
  const token = await readToken<PendingToken>(raw);
  if (!token || token.kind !== 'pending') return null;
  return token;
}

/* ── auth: forgot password (demo stub) ──────────────────────── */
export async function sendRecovery(formData: FormData): Promise<{ ok: boolean; message: string }> {
  const email = String(formData.get('email') ?? '').trim();
  const recCode = String(formData.get('recovery') ?? '').trim();
  if (!email || !recCode) return { ok: false, message: 'Email + recovery code both required (valid for 15 min).' };
  return { ok: true, message: `Recovery link sent to ${email} — valid for 15 min (demo).` };
}

/* ── auth: logout ───────────────────────────────────────────── */
export async function logout(): Promise<void> {
  const j = await jar();
  pushAudit('session', '—', 'auth.logout', {});
  j.delete(SESSION_COOKIE);
  j.delete(TRUST_COOKIE);
  j.delete(PENDING_COOKIE);
  redirect('/login');
}

/* ── maintenance overlay toggle (demo pin on security page) ─── */
export async function toggleMaintenance(): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'settings')) {
    pushDeniedAudit(admin, '/settings/security', 'settings');
    return { ok: false, message: 'Forbidden: settings capability required (Owner only).' };
  }
  const j = await jar();
  const on = j.get(MAINT_COOKIE)?.value === '1';
  if (on) j.delete(MAINT_COOKIE); else j.set(MAINT_COOKIE, '1', { path: '/', maxAge: 6 * 3600 });
  pushAudit(admin.name, admin.role, 'maintenance.toggle', { detail: on ? 'cleared' : 'read-only overlay applied', after: on ? '0' : '1' });
  return { ok: true, message: on ? 'Maintenance mode cleared.' : 'Maintenance overlay on — panel is read-only.' };
}

/* ── machines: hardware commands ─────────────────────────────── */
export async function machineCommand(
  machineId: string, cmd: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  const neededCap: Cap = (cmd === 'ota_rollout' || cmd === 'reflash') ? 'hardware' : 'machines';
  if (!roleCan(admin.role, neededCap)) {
    pushDeniedAudit(admin, `/machines/${machineId}/commands`, neededCap);
    return { ok: false, message: `Forbidden: '${neededCap}' capability required.` };
  }
  const flat = cmd === 'unlock' ? 'unlock' : cmd;
  try {
    await backendApi.dispatchCommand(machineId, flat);
  } catch {
    // P0-10: never fake success when the backend is down.
    if (!DEMO_MODE) return backendDown('this operation');
  }
  appendCommand({
    machineId, cmd: flat, status: flat === 'reboot' ? 'sent' : 'queued',
    ttlS: 120, by: `${admin.name} · ${admin.role}`, atLabel: 'Just now',
    result: flat === 'test_dispense' ? '{"pending":"ack T-120s"}' : JSON.stringify({ queued: flat }),
  });
  if (flat === 'lock' || flat === 'unlock') setMachinePatch(machineId, { locked: flat === 'lock' });
  pushAudit(admin.name, admin.role, 'machine.command', { target: machineId.toUpperCase(), detail: flat });
  return { ok: true, message: `${flat} sent via Rust microservice — TTL 120s, queued first.` };
}

export async function setMode(
  machineId: string, mode: 'hot' | 'cold', _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'machines')) {
    pushDeniedAudit(admin, `/machines/${machineId}/settings`, 'machines');
    return { ok: false, message: "Forbidden: 'machines' capability required." };
  }
  setMachinePatch(machineId, { mode });
  pushAudit(admin.name, admin.role, 'machine.set_mode', { target: machineId.toUpperCase(), detail: `mode → ${mode}`, after: mode });
  return { ok: true, message: `Mode change queued: ${mode} — fleet default untouched.` };
}

export async function pushOta(
  machineId: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'hardware')) {
    pushDeniedAudit(admin, `/machines/${machineId}/hardware`, 'hardware');
    return { ok: false, message: "Forbidden: 'hardware' capability required (Owner only)." };
  }
  try {
    await backendApi.dispatchCommand(machineId, 'ota_rollout', { bundle: 'fw 2.4.2', sha: '31af77' });
  } catch {
    // P0-10: never fake success when the backend is down.
    if (!DEMO_MODE) return backendDown('this operation');
  }
  appendCommand({ machineId, cmd: 'ota_rollout', status: 'queued', ttlS: 120, by: `${admin.name} · ${admin.role}`, atLabel: 'Just now', result: '{"bundle":"fw 2.4.2","sha":"31af77"}' });
  pushAudit(admin.name, admin.role, 'machine.ota', { target: machineId.toUpperCase(), detail: 'fw 2.4.2 · deferred 02:00-04:00 window' });
  return { ok: true, message: 'OTA queued — checksum verified, machines apply in idle window.' };
}

export async function logRefill(
  machineId: string, variant: string, qty: number, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'machines')) {
    pushDeniedAudit(admin, `/machines/${machineId}/stock`, 'machines');
    return { ok: false, message: "Forbidden: 'machines' capability required." };
  }
  pushAudit(admin.name, admin.role, 'stock.refill', { target: machineId.toUpperCase(), detail: `${variant} +${qty}` });
  return { ok: true, message: `Refill logged: ${variant} +${qty} on ${machineId.toUpperCase()} — reorder bar updated after refresh.` };
}

export async function mountTank(
  machineId: string, uid: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'machines')) {
    pushDeniedAudit(admin, `/machines/${machineId}/tanks`, 'machines');
    return { ok: false, message: "Forbidden: 'machines' capability required." };
  }
  pushAudit(admin.name, admin.role, 'tank.mount', { target: `${machineId.toUpperCase()} · ${uid}`, detail: '20L mounted · FSSAI bundle updated', after: uid });
  return { ok: true, message: `${uid} mounted — expiry clock running (12h hold).` };
}

/* ── customers ──────────────────────────────────────────────── */
export async function creditWallet(
  customerId: string, customer: string, amount: number, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'wallet')) {
    pushDeniedAudit(admin, `/customers/${customerId}/wallet`, 'wallet');
    return { ok: false, message: "Forbidden: 'wallet' capability required (Finance/Owner only)." };
  }
  appendWalletTxn(customerId, {
    id: `w-${Date.now()}`, tsLabel: 'Just now',
    kind: 'manual-credit', amount, balanceAfter: 0, note: `manual credit by ${admin.name}`,
  });
  pushAudit(admin.name, admin.role, 'wallet.credit', { target: customer, detail: `₹${amount} manual credit` });
  return { ok: true, message: `₹${amount} credited to ${customer}'s wallet (legacy row appended).` };
}

export async function blockCustomer(
  customer: string, customerId: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'blacklist')) {
    pushDeniedAudit(admin, `/customers/${customerId}`, 'blacklist');
    return { ok: false, message: "Forbidden: 'blacklist' capability required (Owner only)." };
  }
  pushAudit(admin.name, admin.role, 'customer.block', { target: customer, detail: 'added to blacklist review — owner approval needed' });
  return { ok: true, message: `${customer} flagged. Blacklist write confirmed.` };
}

/* ── orders ─────────────────────────────────────────────────── */
export async function orderRefund(
  orderId: string, num: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'refunds')) {
    pushDeniedAudit(admin, `/orders/${orderId}`, 'refunds');
    return { ok: false, message: "Forbidden: 'refunds' capability required (Finance/Owner only)." };
  }
  try {
    await backendApi.refundOrder(orderId, 'Admin initiated refund', 'wallet');
  } catch {
    // P0-10: never fake success when the backend is down.
    if (!DEMO_MODE) return backendDown('this operation');
  }
  markRefunded(orderId, admin.name, admin.role);
  return { ok: true, message: `${num} queued to payout batch — finance approves release.` };
}

export async function orderFraud(
  orderId: string, num: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'support')) {
    pushDeniedAudit(admin, `/orders/${orderId}`, 'support');
    return { ok: false, message: "Forbidden: 'support' capability required." };
  }
  markFraud(orderId, admin.name, admin.role);
  return { ok: true, message: `${num} flagged for blacklist review (owner approves).` };
}

export async function reissueQr(
  orderId: string, num: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'support')) {
    pushDeniedAudit(admin, `/orders/${orderId}`, 'support');
    return { ok: false, message: "Forbidden: 'support' capability required." };
  }
  patchOrder(orderId, { code: { value: `MC${Date.now() % 99999999}`, source: 'buy', issuedLabel: 'Just now', expiryLabel: 'Valid · 10 min', shared: 0, redeemed: false, redeemedLabel: null } });
  pushAudit(admin.name, admin.role, 'order.reissue_qr', { target: num });
  return { ok: true, message: `Fresh code issued for ${num} — old code can no longer authorise.` };
}

/* ── support: dispute desk ──────────────────────────────────── */
export async function openDispute(
  orderId: string, num: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'support')) {
    pushDeniedAudit(admin, `/orders/${orderId}`, 'support');
    return { ok: false, message: "Forbidden: 'support' capability required." };
  }
  const tnum = nextTicketNum();
  createTicket({
    id: tnum.toLowerCase(), num: tnum, type: 'no-coffee', typeLabel: 'No coffee', channel: 'manual',
    priority: 'P2', state: 'investigating', customer: '—', customerId: '—', phone: '—', amount: 0,
    upiRef: '—', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub', orderId, openedLabel: 'Just now', slaMin: 5,
    assignedTo: admin.name, message: 'pre-filled from order evidence page', contextLine: 'Server-filled from order + machine window',
    history: [{ tsLabel: 'Just now', by: `${admin.name} · ${admin.role}`, text: `dispute opened from order page ${num}` }],
  });
  pushAudit(admin.name, admin.role, 'ticket.open', { target: tnum, detail: `from ${num}` });
  return { ok: true, message: `${tnum} created (pre-filled) → opening dispute desk…` };
}

export async function disputeResolve(
  ticketId: string, verdict: 'refund' | 'reject' | 'info', note: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'support')) {
    pushDeniedAudit(admin, `/support/tickets/${ticketId}`, 'support');
    return { ok: false, message: "Forbidden: 'support' capability required." };
  }
  try {
    await backendApi.resolveDispute(ticketId, verdict, note);
  } catch {
    // P0-10: never fake success when the backend is down.
    if (!DEMO_MODE) return backendDown('this operation');
  }
  const t = resolveTicket(ticketId, verdict, admin.name, admin.role, note);
  if (!t) return { ok: false, message: 'Ticket not found.' };
  const msg = verdict === 'refund'
    ? `${t.num} → refund requested. Wallet credit runs through fn_wallet_credit; payout batch needs finance.`
    : verdict === 'reject' ? `${t.num} rejected with proof — clip + dispense log snapshot sent to customer.`
      : `${t.num} → awaiting customer (48h window).`;
  return { ok: true, message: msg };
}

export async function claimNext(
  ticketId: string, _who?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'support')) {
    pushDeniedAudit(admin, `/support/tickets/${ticketId}`, 'support');
    return { ok: false, message: "Forbidden: 'support' capability required." };
  }
  claimTicket(ticketId, admin.name);
  return { ok: true, message: `${ticketId.toUpperCase()} claimed — investigating.` };
}

/* ── support: refunds queue (finance) ───────────────────────── */
export async function refundPayout(
  id: string, state: 'approved' | 'rejected' | 'paid', _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'refunds')) {
    pushDeniedAudit(admin, '/support/refunds', 'refunds');
    return { ok: false, message: "Forbidden: 'refunds' capability required (Finance/Owner only)." };
  }
  setRefundState(id, state, admin.name, admin.role);
  return { ok: true, message: `Payout ${state}.` };
}

export async function denyAuditNote(): Promise<{ ok: boolean; message: string }> {
  return { ok: false, message: 'Blocked: refunds need Finance+ (split is deliberate).' };
}

/* demo no-op mutation: writes the audit entry only — used by
   buttons whose real write happens in the Rust service (dispose,
   schedule visit, wipe SD, save banner …). */
export async function demoAudit(
  action: string, target: string, detail: string, _who?: string, _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  pushAudit(admin.name, admin.role, action, { target, detail });
  return { ok: true, message: `${action} logged — audit trail updated.` };
}

/* ── orders: batch review / flags ───────────────────────────── */
export async function batchReviewOrders(
  orderIds: string[],
  action: 'examine' | 'flag_dispute',
  _who?: string,
  _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'support')) {
    pushDeniedAudit(admin, '/orders', 'support');
    return { ok: false, message: "Forbidden: 'support' capability required." };
  }
  for (const id of orderIds) {
    if (action === 'flag_dispute') {
      patchOrder(id, { flagged: true });
    }
  }
  pushAudit(admin.name, admin.role, `orders.batch_${action}`, {
    target: `${orderIds.length} orders`,
    detail: `Bulk action ${action} performed on orders: ${orderIds.slice(0, 3).join(', ')}${orderIds.length > 3 ? '...' : ''}`,
  });
  return {
    ok: true,
    message: action === 'examine'
      ? `Batch examination complete for ${orderIds.length} orders.`
      : `Flagged ${orderIds.length} orders for dispute desk review.`,
  };
}

/* ── customers: voucher reissuance ──────────────────────────── */
export async function reissueCustomerCode(
  customerId: string,
  customerName: string,
  oldCode: string,
  _who?: string,
  _role?: string,
): Promise<{ ok: boolean; message: string; newCode?: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'support') && !roleCan(admin.role, 'machines')) {
    pushDeniedAudit(admin, `/customers/${customerId}/codes`, 'support');
    return { ok: false, message: "Forbidden: 'support' or 'machines' capability required." };
  }
  const prefix = oldCode.slice(0, 2) || 'MC';
  const randNum = Math.floor(1000000 + Math.random() * 9000000);
  const suffix = Math.floor(10 + Math.random() * 89);
  const newCode = `${prefix}${randNum}-${suffix}`;

  pushAudit(admin.name, admin.role, 'qr.reissue', {
    target: customerName,
    detail: `Voucher reissued: ${oldCode} → ${newCode} (valid for 10 min)`,
  });
  return {
    ok: true,
    message: `Fresh voucher ${newCode} issued for ${customerName} (previous code invalidated).`,
    newCode,
  };
}

/* ── customers: push notification dispatch ──────────────────── */
export async function sendCustomerPush(
  customerId: string,
  customerName: string,
  title: string,
  body: string,
  channel: string = 'fcm',
  _who?: string,
  _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'marketing') && !roleCan(admin.role, 'support')) {
    pushDeniedAudit(admin, `/customers/${customerId}`, 'marketing');
    return { ok: false, message: "Forbidden: 'marketing' or 'support' capability required." };
  }
  if (!title.trim() || !body.trim()) {
    return { ok: false, message: 'Notification title and body are required.' };
  }

  pushAudit(admin.name, admin.role, 'push.dispatch', {
    target: customerName,
    detail: `[${channel.toUpperCase()}] "${title}" — ${body.slice(0, 60)}${body.length > 60 ? '...' : ''}`,
  });
  return {
    ok: true,
    message: `Push notification queued via ${channel.toUpperCase()} to ${customerName}.`,
  };
}

/* ── team: invite administrator & reset MFA ─────────────────── */
export async function inviteAdminUser(
  name: string,
  phone: string,
  email: string,
  role: Role,
  _who?: string,
  _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'settings')) {
    pushDeniedAudit(admin, '/settings/team', 'settings');
    return { ok: false, message: "Forbidden: 'settings' capability required (Owner only)." };
  }
  if (!name.trim() || !phone.trim()) {
    return { ok: false, message: 'Name and phone number are required.' };
  }

  // Check if phone or email already in DEMO_ADMINS
  const exists = DEMO_ADMINS.some(a => a.phone === phone);
  if (exists) {
    return { ok: false, message: `An administrator with phone ${phone} already exists.` };
  }

  const uid = `u-${Date.now().toString().slice(-4)}`;
  DEMO_ADMINS.push({
    uid,
    name: name.trim(),
    phone: phone.trim(),
    role,
  });

  pushAudit(admin.name, admin.role, 'team.invite', {
    target: name.trim(),
    detail: `Provisioned ${role.toUpperCase()} role (${phone.trim()}${email ? ` · ${email.trim()}` : ''})`,
  });

  return {
    ok: true,
    message: `Invitation sent to ${name.trim()} (${phone.trim()}) as ${role.toUpperCase()}.`,
  };
}

export async function resetAdminMfa(
  uid: string,
  name: string,
  _who?: string,
  _role?: string,
): Promise<{ ok: boolean; message: string }> {
  const admin = await requireAdmin();
  if (!roleCan(admin.role, 'settings')) {
    pushDeniedAudit(admin, '/settings/team', 'settings');
    return { ok: false, message: "Forbidden: 'settings' capability required (Owner only)." };
  }

  pushAudit(admin.name, admin.role, 'team.reset_mfa', {
    target: name,
    detail: `MFA secret wiped for ${uid}; user prompted for re-enrollment on next login.`,
  });

  return {
    ok: true,
    message: `2FA secret for ${name} has been reset. Fresh enrollment will be required on next login.`,
  };
}
