import { cookies } from 'next/headers';
import { notFound, redirect } from 'next/navigation';
import { SignJWT, jwtVerify } from 'jose';
import { createHmac } from 'crypto';
import { pushDeniedAudit } from '@/lib/mock/store';

/* ─────────────────────────────────────────────────────────────
   Role & route guard model — lifted from the two spec sheets:
   · admin-routing-workflow.html → "Role → route reach" + guard
     pipeline (deny, never hide).
   · admin-panel-architecture.html → 6 roles / 8 capabilities,
     the panel serves affordances, the Rust service re-checks
     every mutation server-side (we mirror that split: routes
     DENY with a 403 screen, in-page buttons hide cosmetically).

   Six roles · capability sets · route→capability registry.
   ───────────────────────────────────────────────────────────── */

export type Role = 'viewer' | 'support' | 'ops' | 'marketing' | 'finance' | 'owner';

export type Cap =
  | 'machines'          // mutate machine state: tanks, stock, lock, reboot, settings
  | 'hardware'          // firmware + OTA (owner only)
  | 'cctv'              // camera channels + clips
  | 'customersRead'     // customer lists + 360° profiles
  | 'wallet'            // wallet ledger + manual adjust (finance level)
  | 'inventoryRead'
  | 'inventoryWrite'    // cost basis + write-offs (finance level)
  | 'profitability'     // analytics → profitability (finance level)
  | 'marketing'
  | 'support'           // tickets, dispute desk, reviews, macros
  | 'refunds'           // refund payout queue (finance level)
  | 'blacklist'         // owner only
  | 'settings';         // settings module (owner only, fleet defaults = ops)

export interface AdminSession {
  uid: string;
  name: string;
  role: Role;
  email?: string;
}

/* Rust-compatible RBAC bundle. Mirrors `admin_roles.permissions` in the seed so
   the same session token can be verified by BOTH Next middleware and the Rust
   service (`AdminClaims` requires sub/email/name/role/permissions/exp/iat). */
const ROLE_PERMISSIONS: Record<Role, Record<string, boolean>> = {
  owner: { '*': true },
  ops: {
    'machine.view': true, 'machine.lock': true, 'machine.command': true,
    'maintenance.write': true, 'tank.write': true, 'stock.write': true,
    'ticket.view': true, 'ticket.resolve': true, 'refund.approve': true,
    'video.view': true, 'app_config.view': true,
  },
  support: {
    'ticket.view': true, 'ticket.resolve': true, 'refund.request': true,
    'video.view': true, 'user.view': true,
  },
  finance: {
    'finance.view': true, 'refund.approve': true, 'pricing.edit': true,
    'coupon.write': true, 'adspace.write': true, 'report.export': true,
  },
  marketing: {
    'offer.write': true, 'banner.write': true, 'push.write': true,
    'leaderboard.write': true, 'adspace.write': true, 'report.export': true,
  },
  viewer: {},
};

/** Single token both layers understand: `uid` for Next, `sub`/`email`/
 *  `permissions` for the Rust `AdminClaims` struct. */
export function sessionClaims(admin: AdminSession): Record<string, unknown> {
  return {
    uid: admin.uid,
    name: admin.name,
    role: admin.role,
    sub: admin.uid,
    email: admin.email ?? `${admin.role}@manhattancoffee.in`,
    permissions: ROLE_PERMISSIONS[admin.role] ?? {},
  };
}

export interface RoleMeta {
  label: string;
  blurb: string;
  tint: string;              // tag classes
}

export const ROLES: Role[] = ['viewer', 'support', 'ops', 'marketing', 'finance', 'owner'];

export const ROLE_META: Record<Role, RoleMeta> = {
  viewer:    { label: 'Viewer',    blurb: 'Read-only console access',          tint: 'bg-ink-300/20 text-ink-500' },
  support:   { label: 'Support',   blurb: 'Ticket desk · dispute resolution',   tint: 'bg-amber2-50 text-amber2-600' },
  ops:       { label: 'Ops',       blurb: 'Field ops · machines · refunds req', tint: 'bg-leaf-50 text-leaf-600' },
  marketing: { label: 'Marketing', blurb: 'Campaigns · offers · ad networks',   tint: 'bg-brand-50 text-brand-600' },
  finance:   { label: 'Finance',   blurb: 'Payouts · margin · wallet ledger',   tint: 'bg-blue-50 text-blue-700' },
  owner:     { label: 'Owner',     blurb: 'Superadmin — everything',            tint: 'bg-brand-500 text-white' },
};

/** Demo admin identities — /settings/team mirrors this roster.
 *  `uid` is the real seeded `admin_users.id` so Rust audit FKs resolve. */
export const DEMO_ADMINS: (AdminSession & { phone: string; suspended?: boolean })[] = [
  { uid: 'c0ffee00-0001-4000-8000-000000000001', name: 'Chief Rohan',  role: 'owner',     phone: '+91 98765 43210', email: 'owner@manhattancoffee.in' },
  { uid: 'c0ffee00-0002-4000-8000-000000000002', name: 'Meera Sawant', role: 'ops',       phone: '+91 98111 20044', email: 'ops@manhattancoffee.in' },
  { uid: 'c0ffee00-0003-4000-8000-000000000003', name: 'Arjun Khanna', role: 'support',   phone: '+91 99001 77321', email: 'support@manhattancoffee.in' },
  { uid: 'c0ffee00-0004-4000-8000-000000000004', name: 'Nikhil Rao',   role: 'finance',   phone: '+91 98220 91135', email: 'finance@manhattancoffee.in' },
  { uid: 'c0ffee00-0005-4000-8000-000000000005', name: 'Sana Qureshi', role: 'marketing', phone: '+91 97690 51240', email: 'mkt@manhattancoffee.in' },
  { uid: 'c0ffee00-0006-4000-8000-000000000006', name: 'Aman Gupta',   role: 'viewer',    phone: '+91 95000 61092', email: 'viewer@manhattancoffee.in' },
];

/** capability sets per role (the permission matrix, JSONB-emulated) */
const ROLE_CAPS: Record<Role, Cap[]> = {
  viewer:    ['inventoryRead'],
  support:   ['inventoryRead', 'cctv', 'customersRead', 'support'],
  ops:       ['inventoryRead', 'cctv', 'support', 'machines'],
  marketing: ['customersRead', 'marketing'],
  finance:   ['inventoryRead', 'customersRead', 'wallet', 'inventoryWrite', 'profitability', 'support', 'refunds'],
  owner:     ['inventoryRead', 'cctv', 'customersRead', 'wallet', 'inventoryWrite',
              'profitability', 'marketing', 'support', 'refunds', 'machines', 'hardware',
              'blacklist', 'settings'],
};

export function roleCan(role: Role, cap: Cap): boolean {
  return ROLE_CAPS[role].includes(cap);
}

/** "minOps" style label shown in the 403 screen + affordance tooltips */
export const CAP_MIN_LABEL: Record<Cap, string> = {
  machines:        'Ops',
  hardware:        'Owner',
  cctv:            'Support',
  customersRead:   'Support',
  wallet:          'Finance',
  inventoryRead:   'Viewer',
  inventoryWrite:  'Finance',
  profitability:   'Finance',
  marketing:       'Marketing',
  support:         'Support',
  refunds:         'Finance',
  blacklist:       'Owner',
  settings:        'Owner',
};

/* ═════════════════════════════════════════════════════════════
   Route → capability registry — 53 console routes (+3 auth).
   Pattern segments named `:anything` match exactly one segment.
   APPEARS IN THE 403 SCREEN: "requires {CAP_MIN_LABEL[cap]}+".
   ═════════════════════════════════════════════════════════════ */

const ROUTE_CAPS: [pattern: string, cap: Cap | null][] = [
  // ① dashboard
  ['/', null],

  // ② machines
  ['/machines', 'inventoryRead'],
  ['/machines/:id', 'inventoryRead'],
  ['/machines/:id/overview', 'inventoryRead'],
  ['/machines/:id/telemetry', 'inventoryRead'],
  ['/machines/:id/tanks', 'machines'],
  ['/machines/:id/stock', 'machines'],
  ['/machines/:id/hardware', 'hardware'],
  ['/machines/:id/cameras', 'cctv'],
  ['/machines/:id/commands', 'inventoryRead'],
  ['/machines/:id/maintenance', 'machines'],
  ['/machines/:id/settings', 'machines'],

  // ③ orders
  ['/orders', 'inventoryRead'],
  ['/orders/:id', 'inventoryRead'],
  ['/orders/:id/label', 'inventoryRead'],

  // ④ customers
  ['/customers', 'customersRead'],
  ['/customers/:id', 'customersRead'],
  ['/customers/:id/wallet', 'wallet'],
  ['/customers/:id/codes', 'customersRead'],

  // ⑤ inventory
  ['/inventory', 'inventoryRead'],
  ['/inventory/tanks', 'machines'],
  ['/inventory/supplies', 'inventoryWrite'],
  ['/inventory/waste', 'inventoryWrite'],

  // ⑥ analytics
  ['/analytics', 'inventoryRead'],
  ['/analytics/sales', 'inventoryRead'],
  ['/analytics/products', 'inventoryRead'],
  ['/analytics/consumption', 'inventoryRead'],
  ['/analytics/machines', 'inventoryRead'],
  ['/analytics/profitability', 'profitability'],

  // ⑦ marketing
  ['/marketing', 'marketing'],
  ['/marketing/offers', 'marketing'],
  ['/marketing/coupons', 'marketing'],
  ['/marketing/banners', 'marketing'],
  ['/marketing/push', 'marketing'],
  ['/marketing/festivals', 'marketing'],
  ['/marketing/referrals', 'marketing'],
  ['/marketing/ads', 'marketing'],
  ['/marketing/adspaces', 'wallet'], // finance-level rental money

  // ⑧ support
  ['/support', 'support'],
  ['/support/tickets', 'support'],
  ['/support/tickets/:id', 'support'],
  ['/support/refunds', 'refunds'],
  ['/support/reviews', 'support'],
  ['/support/blacklist', 'blacklist'],
  ['/support/macros', 'support'],

  // ⑨ settings
  ['/settings', 'settings'],
  ['/settings/general', 'settings'],
  ['/settings/machines', 'machines'],       // fleet defaults — registry min: ops
  ['/settings/payments', 'settings'],
  ['/settings/notifications', 'settings'],
  ['/settings/team', 'settings'],
  ['/settings/integrations', 'settings'],
  ['/settings/security', 'settings'],
  ['/settings/appearance', 'settings'],
  ['/settings/billing', 'settings'],
];

function matchRoute(pattern: string, segments: string[]): boolean {
  const p = pattern.split('/').filter(Boolean);
  if (p.length !== segments.length) return false;
  return p.every((seg, i) => seg.startsWith(':') || seg === segments[i]);
}

export function capForRoute(pathname: string): Cap | null | undefined {
  const segments = pathname.split('?')[0].split('/').filter(Boolean);
  for (const [pattern, cap] of ROUTE_CAPS) {
    if (matchRoute(pattern, segments)) return cap;
  }
  return undefined; // not a registered route → let 404 handle it
}

/* ═════════════════════════════════════════════════════════════
   Session cookies — HS256 JWTs via jose, mirroring the Rust
   service's auth model (Bearer / session cookie).
   ═════════════════════════════════════════════════════════════ */

export const SESSION_COOKIE = 'mc_admin_session';
export const PENDING_COOKIE = 'mc_auth_pending';
export const TRUST_COOKIE = 'mc_trust_device';
export const MAINT_COOKIE = 'mc_maintenance';

export interface PendingToken {
  phone: string;
  role: Role;
  code: string;
  kind: 'pending';
}

/**
 * P0-07: single shared secret name (ADMIN_JWT_SECRET) with a hard failure in
 * production. The development fallback never applies when NODE_ENV=production.
 */
function secret() {
  const raw = process.env.ADMIN_JWT_SECRET ?? process.env.JWT_SECRET;
  if (raw && raw.length >= 32) return new TextEncoder().encode(raw);
  if (process.env.NODE_ENV === 'production') {
    throw new Error('ADMIN_JWT_SECRET (>= 32 chars) must be set in production.');
  }
  return new TextEncoder().encode('dev-only-insecure-secret-change-me-32+chars');
}

/* ── TOTP (RFC 6238) — server-side only. Codes are never sent to the browser. ── */
function base32Decode(input: string): Buffer {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const ch of input.replace(/=+$/, '').toUpperCase()) {
    const idx = alphabet.indexOf(ch);
    if (idx < 0) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

function totpAt(secretB32: string, counter: number): string {
  const key = base32Decode(secretB32);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const digest = createHmac('sha1', key).update(buf).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const code = ((digest[offset] & 0x7f) << 24)
    | (digest[offset + 1] << 16)
    | (digest[offset + 2] << 8)
    | digest[offset + 3];
  return String(code % 1_000_000).padStart(6, '0');
}

export function verifyTotp(secretB32: string, token: string, window = 1): boolean {
  if (!secretB32 || !/^\d{6}$/.test(token)) return false;
  const counter = Math.floor(Date.now() / 30_000);
  for (let i = -window; i <= window; i += 1) {
    if (totpAt(secretB32, counter + i) === token) return true;
  }
  return false;
}

export function currentTotp(secretB32: string): string {
  return totpAt(secretB32, Math.floor(Date.now() / 30_000));
}

export async function signToken(payload: object, days: number): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${days}d`)
    .sign(secret());
}

export async function readToken<T>(token: string | undefined): Promise<T | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    return payload as T;
  } catch {
    return null; // expired / forged
  }
}

export async function getAdmin(): Promise<AdminSession | null> {
  const jar = await cookies();
  const payload = await readToken<AdminSession>(jar.get(SESSION_COOKIE)?.value);
  if (!payload || !payload.role) return null;
  return { uid: payload.uid, name: payload.name, role: payload.role };
}

/** Guard steps 1+2+3: session present → else redirect /login (intended path kept). */
export async function requireAdmin(): Promise<AdminSession> {
  const admin = await getAdmin();
  if (!admin) redirect('/login');
  return admin;
}

export async function isMaintenance(): Promise<boolean> {
  const jar = await cookies();
  return jar.get(MAINT_COOKIE)?.value === '1';
}

export type GuardResult =
  | { kind: 'ok'; admin: AdminSession }
  | { kind: 'forbidden'; admin: AdminSession; cap: Cap };

/**
 * Guard steps 4: role check. Sits between middleware (session) and the
 * data loader. A role below the route minimum gets a 403 screen — never
 * a silently absent page — and the attempt lands in the audit trail.
 */
export async function requireCap(pathname: string): Promise<GuardResult> {
  const admin = await requireAdmin();

  // suspended account check (always false in demo roster, works when set)
  const acct = DEMO_ADMINS.find(a => a.uid === admin.uid);
  if (acct?.suspended) {
    redirect('/login?err=suspended');
  }

  const cap = capForRoute(pathname);
  if (cap === undefined) notFound(); // unregistered → not-found
  if (cap !== null && !roleCan(admin.role, cap)) {
    pushDeniedAudit(admin, pathname, CAP_MIN_LABEL[cap]);
    return { kind: 'forbidden', admin, cap };
  }
  return { kind: 'ok', admin };
}
