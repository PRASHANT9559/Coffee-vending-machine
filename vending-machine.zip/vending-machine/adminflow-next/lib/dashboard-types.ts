/* ─────────────────────────────────────────────────────────────
   Dashboard data contracts — shared between the data layer
   (server) and every dashboard widget (client).
   ───────────────────────────────────────────────────────────── */

export type RangeKey = 'Today' | 'This Week' | 'This Month';

export const RANGE_KEYS: RangeKey[] = ['Today', 'This Week', 'This Month'];

export interface TrendData {
  labels: string[];      // bucket labels drawn on the x axis
  revenue: number[];     // ₹ per bucket
  orders: number[];      // order count per bucket
}

export interface VariantSlice {
  name: string;      // full product name
  short: string;     // short_name column
  orders: number;
  revenue: number;   // ₹
  pct: number;       // share of today's orders
  color: string;
  emoji: string;
}

export interface StatusSlice {
  name: string;      // Completed / Preparing / Pending / Cancelled
  n: number;
  pct: number;
  color: string;
}

export interface MachineChip {
  id: string;
  code: string;                       // machine_code, e.g. MCH-001
  name: string;                       // location name
  mode: 'hot' | 'cold' | 'off';
  tempC: number | null;               // latest milk_temp_c
  litres: number | null;              // latest milk_level_l
  malaiL: number | null;              // latest malai_level_l
  cups: number;                       // latest cup_count
  live: boolean;                      // pinged within 60s → pulsing dot
  online: boolean;                    // drives the ONLINE / OFFLINE badge
}

export interface DashboardStats {
  revenueToday: number;   // ₹
  revenueDelta: number;   // % vs yesterday, null if unknown
  ordersToday: number;
  ordersDelta: number;
  activeMachines: number;
  totalMachines: number;
  avgOrder: number;       // ₹
  avgDelta: number;
  revenueSpark: TrendData | null;   // today's hour buckets feed the sparklines
  ordersSpark: TrendData | null;
  avgSpark: TrendData | null;
}

export interface DashboardInsights {
  revenueDeltaPct: number | null;
  topItem: string;      // most ordered variant today
  bestSeller: string;   // highest revenue variant today
  peakHour: string;     // "11:00 AM – 1:00 PM"
  walletFloat: number;  // ₹ (sum of wallet balance_paise)
  adRevenue: number;    // ₹ (last 30 days ad_revenue_daily)
}

export interface DashboardData {
  source: 'rust' | 'supabase' | 'demo';
  date: string;         // "01 Oct 2026"
  live: MachineChip[];
  stats: DashboardStats;
  ranges: Record<RangeKey, TrendData>;
  variants: VariantSlice[];
  status: StatusSlice[];
  insights: DashboardInsights;
}
