/* ─────────────────────────────────────────────────────────────
   IST (Asia/Kolkata) time helpers — every dashboard date
   boundary is computed in IST, never in server-local time.
   ───────────────────────────────────────────────────────────── */

export interface IstParts {
  y: number;
  m: number;        // 1..12
  d: number;        // 1..31
  h: number;        // 0..23
  min: number;
  weekday: number;  // 0=Sun .. 6=Sat
}

const fmt = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'Asia/Kolkata',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
  weekday: 'short',
});

const WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function istParts(date: Date = new Date()): IstParts {
  const p = fmt.formatToParts(date);
  const get = (t: string) => p.find(x => x.type === t)?.value ?? '';
  return {
    y: +get('year'),
    m: +get('month'),
    d: +get('day'),
    h: +get('hour'),
    min: +get('minute'),
    weekday: WEEK.indexOf(get('weekday')),
  };
}

/** `YYYY-MM-DD` of the IST calendar day, `offsetDays` back (29 → 30 days ago etc.) */
export function istDateKey(offsetDays = 0): string {
  const { y, m, d } = istParts();
  const dt = new Date(Date.UTC(y, m - 1, d - offsetDays));
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`;
}

/**
 * UTC instant of IST midnight for the current IST day minus `offsetDays`.
 * IST midnight = previous UTC evening 18:30.
 */
export function istDayStart(offsetDays = 0): Date {
  const { y, m, d } = istParts();
  return new Date(Date.UTC(y, m - 1, d - offsetDays, 18, 30, 0, 0));
}

/** Monday 00:00 IST of the current IST week. */
export function istWeekStart(): Date {
  const { weekday } = istParts();
  const since = (weekday + 6) % 7; // Mon-first
  return istDayStart(since);
}

/** 1st of the current IST month, 00:00 IST. */
export function istMonthStart(): Date {
  const { y, m } = istParts();
  return new Date(Date.UTC(y, m - 1, 1, 18, 30, 0, 0));
}

/** `01 Oct 2026` style display label, exactly like the demo. */
export function istDisplayDate(date: Date = new Date()): string {
  return date.toLocaleDateString('en-GB', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function greetingByHour(h: number): string {
  if (h < 5) return 'Good Night';
  if (h < 12) return 'Good Morning';
  if (h < 17) return 'Good Afternoon';
  if (h < 21) return 'Good Evening';
  return 'Good Night';
}
