import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/* ─────────────────────────────────────────────────────────────
   Supabase access for the admin panel.

   The full production path per admin-panel-architecture.html is
   Admin → Rust microservice (service-role) → Postgres. While the
   Rust service is not wired to the Next.js panel yet, this module
   talks to Supabase directly with the anon key, exactly as the
   owner chose. Tables are RLS-protected by 004_rls_policies.sql,
   so anything the anon key cannot read simply falls back to the
   demo dataset instead of crashing the dashboard.

   Set these in .env.local (both required to leave demo mode):
     NEXT_PUBLIC_SUPABASE_URL=...
     NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   ───────────────────────────────────────────────────────────── */

export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
export const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';

let cached: SupabaseClient | null = null;

export function isSupabaseConfigured(): boolean {
  return SUPABASE_URL.length > 0 && SUPABASE_ANON_KEY.length > 0;
}

export function getSupabase(): SupabaseClient {
  if (!cached) {
    cached = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
      realtime: { params: { eventsPerSecond: 0 } },
    });
  }
  return cached;
}
