import {
  DashboardData,
  StatusSlice,
  TrendData,
  VariantSlice,
  MachineChip,
} from './dashboard-types';

/* ─────────────────────────────────────────────────────────────
   Demo dataset lifted 1:1 from admin-dashboard.html.
   Used as a graceful fallback when Supabase env vars are not
   configured (yet) so the UI can always be reviewed.
   ───────────────────────────────────────────────────────────── */

const RANGES: Record<string, TrendData> = {
  Today: {
    labels: ['12 AM', '4 AM', '8 AM', '12 PM', '4 PM', '8 PM', '11 PM'],
    revenue: [490, 650, 810, 1320, 1220, 1550, 760],
    orders: [12, 16, 20, 32, 30, 38, 20],
  },
  'This Week': {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    revenue: [18400, 21600, 19800, 26300, 24100, 31200, 16850],
    orders: [52, 61, 55, 74, 68, 88, 44],
  },
  'This Month': {
    labels: ['W1', 'W2', 'W3', 'W4'],
    revenue: [124000, 138000, 131000, 152000],
    orders: [352, 398, 374, 428],
  },
};

const VARIANTS: VariantSlice[] = [
  { name: 'Manhattan Velvet Cappuccino', short: 'Manhattan Velvet', orders: 93, revenue: 4650, pct: 55, color: '#F04E23', emoji: '👑' },
  { name: 'Classic Café Latte',          short: 'Classic Latte',     orders: 34, revenue: 680,  pct: 20, color: '#EAB308', emoji: '☕' },
  { name: 'Grande Roast',                short: 'Grande Roast',      orders: 25, revenue: 750,  pct: 15, color: '#22C55E', emoji: '🔥' },
  { name: 'Chilled Manhattan Frappe',    short: 'Chilled Frappe',    orders: 16, revenue: 720,  pct: 10, color: '#EF4444', emoji: '🧊' },
];

const STATUS: StatusSlice[] = [
  { name: 'Completed', n: 108, pct: 64, color: '#16A34A' },
  { name: 'Preparing', n: 37,  pct: 22, color: '#EAB308' },
  { name: 'Pending',   n: 17,  pct: 10, color: '#F04E23' },
  { name: 'Cancelled', n: 6,   pct: 4,  color: '#9CA3AF' },
];

const MACHINES: MachineChip[] = [
  { id: 'a1b2c3d4-0001-4000-8000-000000000001', code: 'MCH-001', name: 'Campus Hub',  mode: 'hot',  tempC: 65.4, litres: 38, malaiL: 6, cups: 142, live: true, online: true },
  { id: 'a1b2c3d4-0002-4000-8000-000000000002', code: 'MCH-002', name: 'Mall Lane',  mode: 'cold', tempC: 6.2,  litres: 21, malaiL: 4, cups: 88,  live: true, online: true },
];

export function demoData(date: string): DashboardData {
  const revSpark = RANGES.Today.revenue;
  const ordSpark = RANGES.Today.orders;
  const avgSpark = revSpark.map((r, i) => (ordSpark[i] ? Math.round(r / ordSpark[i]) : 0));

  return {
    source: 'demo',
    date,
    live: MACHINES,
    stats: {
      revenueToday: 6800,
      revenueDelta: 8.2,
      ordersToday: 168,
      ordersDelta: 6.2,
      activeMachines: 2,
      totalMachines: 2,
      avgOrder: 40,
      avgDelta: 3.7,
      revenueSpark: { labels: RANGES.Today.labels, revenue: revSpark, orders: ordSpark },
      ordersSpark: { labels: RANGES.Today.labels, revenue: revSpark, orders: ordSpark },
      avgSpark: { labels: RANGES.Today.labels, revenue: revSpark, orders: avgSpark },
    },
    ranges: RANGES,
    variants: VARIANTS,
    status: STATUS,
    insights: {
      revenueDeltaPct: 8.2,
      topItem: 'Manhattan Velvet Cappuccino',
      bestSeller: 'Classic Café Latte',
      peakHour: '11:00 AM – 2:00 PM',
      walletFloat: 5600,
      adRevenue: 1240,
    },
  };
}
