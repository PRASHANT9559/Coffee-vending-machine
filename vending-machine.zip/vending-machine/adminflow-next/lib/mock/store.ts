import type { MachineCommand, RefundRow, Ticket, LedgerTxn, Order, AuditEntry } from './types';
import { seedTickets } from './support';
import { seedOrders } from './orders';
import { seedCommands } from './fleet';

/* ─────────────────────────────────────────────────────────────
   Demo operational store — module-global, survives HMR via
   globalThis. Everything the spec lists as "actions emitted"
   that mutates state lands here (in-memory; production writes
   go through the Rust service).
   ───────────────────────────────────────────────────────────── */

interface Store {
  audit: AuditEntry[];
  denied: number;
  tickets: Ticket[];
  refunds: RefundRow[];
  commands: MachineCommand[];
  orderPatches: Record<string, Partial<Order>>;
  walletTxns: Record<string, LedgerTxn[]>;
  seq: number;   // next ticket number → TKT-1051…
}

const g = globalThis as unknown as { __mcStore?: Store };

function boot(): Store {
  return {
    audit: [
      {
        id: 'a-seed-1', at: 'Today · 9:12 AM', who: 'Chief Rohan', role: 'owner',
        action: 'settings.payments.rotate', target: 'webhook secret',
        detail: 'rotation verified — invalidates nothing', kind: 'action',
      },
      {
        id: 'a-seed-2', at: 'Yesterday · 6:40 PM', who: 'Meera Sawant', role: 'ops',
        action: 'machine.command', target: 'MCH-001',
        detail: 'lock — tank refill in progress',
        kind: 'action', before: 'locked:false', after: 'locked:true',
      },
      {
        id: 'a-seed-3', at: 'Yesterday · 5:20 PM', who: 'Arjun Khanna', role: 'support',
        action: 'ticket.resolve', target: 'TKT-1041',
        detail: 'reject with proof — variance 2%, pickup detected',
        kind: 'action',
      },
    ],
    denied: 0,
    tickets: seedTickets(),
    refunds: [],
    commands: seedCommands(),
    orderPatches: {},
    walletTxns: {},
    seq: 1051,
  };
}

export function store(): Store {
  g.__mcStore ??= boot();
  return g.__mcStore;
}

/* ── audit ──────────────────────────────────────────────────── */

export function listAudit(): AuditEntry[] {
  return [...store().audit];
}

export function pushAudit(
  who: string, role: string, action: string,
  opts: { at?: string; target?: string; detail?: string; before?: string; after?: string } = {},
): void {
  const s = store();
  s.audit.unshift({
    id: `a-${Date.now()}-${s.audit.length + 1}`,
    at: opts.at ?? 'Just now',
    who, role, action,
    target: opts.target, detail: opts.detail,
    kind: 'action', before: opts.before, after: opts.after,
  });
  if (s.audit.length > 60) s.audit.length = 60;
}

/** 403 attempts land in the audit trail (guard flow spec) */
export function pushDeniedAudit(admin: { name: string; role: string }, path: string, minRole: string): void {
  const s = store();
  s.denied += 1;
  s.audit.unshift({
    id: `a-denied-${Date.now()}-${s.denied}`,
    at: 'Just now',
    who: admin.name,
    role: admin.role,
    action: 'route.denied',
    target: path,
    detail: `requires ${minRole}+`,
    kind: 'denied',
  });
  if (s.audit.length > 60) s.audit.length = 60;
}

/* ── tickets ────────────────────────────────────────────────── */

export function listTickets(): Ticket[] {
  return store().tickets;
}

export function getTicket(id: string): Ticket | undefined {
  return store().tickets.find(t => t.id === id);
}

export function createTicket(t: Ticket): void {
  store().tickets.unshift(t);
}

export function nextTicketNum(): string {
  const s = store();
  return `TKT-${s.seq++}`;
}

export function resolveTicket(
  id: string, verdict: 'refund' | 'reject' | 'info', who: string, role: string, note: string,
): Ticket | undefined {
  const t = getTicket(id);
  if (!t) return undefined;
  t.state = verdict === 'refund' ? 'resolved-refund' : verdict === 'reject' ? 'resolved-reject' : 'awaiting';
  t.verdict = verdict === 'info' ? 'info requested' : verdict;
  t.history.push({ tsLabel: 'Just now', by: `${who} · ${role}`, text: note });
  pushAudit(who, role, 'ticket.resolve', { target: t.num, detail: `${verdict} — ${note}` });

  if (verdict === 'refund') {
    createRefund({
      id: `rf-${t.id}`,
      orderId: t.orderId,
      orderNum: getOrder(t.orderId)?.num ?? 'ORD',
      customer: t.customer,
      amount: t.amount,
      destination: 'wallet',
      requestedBy: `${who} · ${role}`,
      atLabel: 'Just now',
      state: 'pending',
      reason: 'dispute desk verdict',
    });
  }
  return t;
}

export function claimTicket(id: string, who: string): Ticket | undefined {
  const t = getTicket(id);
  if (!t) return undefined;
  t.assignedTo = who;
  t.state = 'investigating';
  t.history.push({ tsLabel: 'Just now', by: who, text: 'claimed — investigating' });
  return t;
}

/* ── refunds payout queue ───────────────────────────────────── */

const SEED_REFUNDS: RefundRow[] = [
  {
    id: 'rf-seed-1', orderId: 'o-dn-88', orderNum: 'ORD-2218', customer: 'Priya Nair',
    amount: 20, destination: 'gateway', requestedBy: 'Arjun Khanna · support',
    atLabel: 'Today · 11:02 AM', state: 'pending',
    reason: 'payment deducted, no dispense — variance 96%',
  },
  {
    id: 'rf-seed-2', orderId: 'o-wk-12', orderNum: 'ORD-2176', customer: 'Dev Patel',
    amount: 40, destination: 'wallet', requestedBy: 'Meera Sawant · ops',
    atLabel: 'Yesterday · 4:44 PM', state: 'pending',
    reason: 'cup stuck — pickup never detected',
  },
  {
    id: 'rf-seed-3', orderId: 'o-ee-30', orderNum: 'ORD-2120', customer: 'Ritika Sen',
    amount: 60, destination: 'gateway', requestedBy: 'Nikhil Rao · finance',
    atLabel: 'Yesterday · 1:20 PM', state: 'paid',
    reason: 'payout batch — wallet top-up',
  },
  {
    id: 'rf-seed-4', orderId: 'o-mm-19', orderNum: 'ORD-2062', customer: 'Sameer Verma',
    amount: 20, destination: 'wallet', requestedBy: 'Arjun Khanna · support',
    atLabel: 'Mon · 9:05 AM', state: 'rejected',
    reason: 'rejected — dispense log + pickup event clean',
  },
];

export function listRefunds(): RefundRow[] {
  return [...store().refunds, ...SEED_REFUNDS];
}

export function createRefund(r: RefundRow): void {
  store().refunds.unshift(r);
  patchOrder(r.orderId, { status: 'refunded', flagged: true });
}

export function setRefundState(id: string, state: RefundRow['state'], who: string, role: string): RefundRow | undefined {
  const row = listRefunds().find(r => r.id === id);
  if (!row) return undefined;
  row.state = state;
  pushAudit(who, role, 'refund.payout', {
    target: row.orderNum,
    detail: `${state} · ₹${row.amount} → ${row.destination}`,
    after: state,
  });
  return row;
}

/* ── orders (patch demo) ────────────────────────────────────── */

export function listOrders(): Order[] {
  const s = store();
  return seedOrders().map(o => ({ ...o, ...s.orderPatches[o.id] }));
}

export function getOrder(id: string): Order | undefined {
  return listOrders().find(o => o.id === id);
}

export function patchOrder(id: string, patch: Partial<Order>): void {
  const s = store();
  s.orderPatches[id] = { ...s.orderPatches[id], ...patch };
}

export function markRefunded(orderId: string, who: string, role: string): void {
  const o = getOrder(orderId);
  patchOrder(orderId, { status: 'refunded', flagged: true });
  pushAudit(who, role, 'order.refund', {
    target: o?.num ?? orderId,
    detail: 'marked refunded — queued to payout batch',
  });
}

export function markFraud(orderId: string, who: string, role: string): void {
  const o = getOrder(orderId);
  patchOrder(orderId, { flagged: true });
  pushAudit(who, role, 'order.flag', {
    target: o?.num ?? orderId,
    detail: 'flagged as fraud — blacklist review suggested',
  });
}

/* ── machine commands / wallet ──────────────────────────────── */

export function listCommands(): MachineCommand[] {
  return store().commands;
}

export function appendCommand(c: Omit<MachineCommand, 'id'>): MachineCommand {
  const s = store();
  const row: MachineCommand = { id: `cmd-${s.commands.length + 1}`, ...c };
  s.commands.unshift(row);
  return row;
}

export function appendWalletTxn(customerId: string, txn: LedgerTxn): void {
  const s = store();
  (s.walletTxns[customerId] ??= []).unshift(txn);
}

export function listWalletTxns(customerId: string, seed: LedgerTxn[]): LedgerTxn[] {
  return [...(store().walletTxns[customerId] ?? []), ...seed];
}

/* ── machine live patches (lock / mode) ─────────────────────── */

function patchStore(): { machine: Record<string, Partial<import('./types').Machine>> } {
  const s = store() as Store & { machine: Record<string, Partial<import('./types').Machine>> };
  s.machine ??= {};
  return s;
}

export function machinePatched(id: string): Record<string, unknown> {
  return patchStore().machine[id] ?? {};
}

export function setMachinePatch(id: string, patch: Record<string, unknown>): void {
  const s = patchStore();
  s.machine[id] = { ...s.machine[id], ...patch };
}
