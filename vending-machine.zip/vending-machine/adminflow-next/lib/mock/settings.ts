import type { AlertRule, IntegrationRow, WebhookEvent, InvoiceRow, UsageLine, Order, Ticket } from './types';

/* ─────────────────────────────────────────────────────────────
   Settings module dataset + topbar notification deep links.
   ───────────────────────────────────────────────────────────── */

export const GENERAL_CONFIG = {
  business: 'Manhattan Coffee', cities: 'Pune · Pimpri', supportNumber: '+91 78400 20048',
  logoUrl: '—', timezone: 'Asia/Kolkata', currency: 'INR ₹',
};

export const FLEET_DEFAULTS = {
  targetTempHot: 65,
  targetTempCold: 6,
  tankHoldHours: 12,
  reorder: 'cups < 50 · kits < 12 · malai < 5 L',
  checklist: 'mount tank → load kits → test dispense → sign commission tag',
};

export const ALERT_RULES: AlertRule[] = [
  { id: 'ar-1', trigger: 'Fault code raised', threshold: 'any P1 fault (F-01..F-99)', channel: 'whatsapp', recipient: 'Owner + Ops', active: true },
  { id: 'ar-2', trigger: 'Stock below threshold', threshold: 'kits < 12 or cups < 50', channel: 'in-app', recipient: 'Ops', active: true },
  { id: 'ar-3', trigger: 'Tank near expiry', threshold: '< 2h of hold window', channel: 'in-app', recipient: 'Ops', active: true },
  { id: 'ar-4', trigger: 'Machine offline', threshold: '> 10 min no telemetry', channel: 'sms', recipient: 'Owner', active: false },
];

export const CRITICAL_ALERTS: { title: string; body: string }[] = [
  { title: 'Stock below threshold', body: 'Kits < 12 or cups < 50 on any machine' },
  { title: 'Tank expiring', body: 'Tank inside 2h of its hold window' },
  { title: 'Machine offline', body: 'No telemetry heartbeat (30s cadence) for >10min' },
  { title: 'Failed dispense', body: 'Variance >15% on any dispense attempt' },
  { title: 'A-To-Let', body: 'Pump/valve thermal cutoff or mains trip' },
];

export const INTEGRATIONS: IntegrationRow[] = [
  { id: 'it-1', name: 'Supabase (Postgres 15)', desc: 'DB · realtime · storage', state: 'connected', lastCheck: '12s ago' },
  { id: 'it-2', name: 'Rust service · axum', desc: 'api · mqtt broker · HMAC signer', state: 'connected', lastCheck: '3s ago' },
  { id: 'it-3', name: 'Ad networks', desc: '3 present · 1 needs postback attention', state: 'attention', lastCheck: '8m ago' },
  { id: 'it-4', name: 'WhatsApp Business', desc: 'bot intake · ticket auto-context', state: 'connected', lastCheck: '41s ago' },
];

export const WEBHOOK_EVENTS: WebhookEvent[] = [
  { tsLabel: 'Today · 11:42 AM', event: 'payment.captured · order ORD-2250', status: 'ok', code: '200' },
  { tsLabel: 'Today · 11:20 AM', event: 'payment.captured · ORD-2249', status: 'ok', code: '200' },
  { tsLabel: 'Yesterday · 9:58 PM', event: 'payment.failed · retry 2', status: 'ok', code: '200' },
  { tsLabel: 'Yesterday · 7:56 PM', event: 'settlement.note', status: 'ok', code: '200' },
  { tsLabel: 'Yesterday · 2:14 PM', event: 'payment.captured · ORD-2224', status: 'failed', code: '500 · replayed ok' },
  { tsLabel: 'Yesterday · 1:14 PM', event: 'refund.processed · ORD-2229', status: 'ok', code: '200' },
];

export const SECURITY_SESSIONS = [
  { device: 'MacBook · Chrome 141', ip: '103.21.58.x · Pune', started: 'Today · 8:12 AM', current: true, mfa: true },
  { device: 'Pixel 8 · Admin App', ip: '10.42.x.x · VIIT wifi', started: 'Today · 6:55 AM', current: false, mfa: true },
  { device: 'Windows · Edge', ip: '117.98.x.x · Pimpri', started: 'Yesterday · 9:44 PM', current: false, mfa: false },
];

export const QR_SECRET_INFO = {
  version: 7, lastRotated: '20 Oct · MN',
  impactLabel: 'rotation invalidates every unredeemed QR in the field + requires firmware update',
};

export const APPEARANCE = { primary: '#F04E23', success: '#16A34A', warning: '#EAB308', mode: 'light', density: 'comfortable' };

export const PLAN = {
  name: 'Growth', price: 1499, period: 'month', renews: '20 Nov',
  lines: ['9 machine slots (2 used)', 'unlimited orders', '90-day telemetry', 'ad networks incl.'],
};

export const USAGE: UsageLine[] = [
  { name: 'Machines', used: 2, cap: 9, unit: 'slots' },
  { name: 'Telemetry retention', used: 90, cap: 90, unit: 'days' },
  { name: 'Admin seats', used: 6, cap: 10, unit: 'seats' },
  { name: 'Push credits', used: 1840, cap: 5000, unit: 'mo' },
];

export const INVOICES: InvoiceRow[] = [
  { id: 'INV-2026-10', dateLabel: '20 Oct', amount: 1499, state: 'paid' },
  { id: 'INV-2026-09', dateLabel: '20 Sep', amount: 1499, state: 'paid' },
  { id: 'INV-2026-08', dateLabel: '20 Aug', amount: 1499, state: 'paid' },
  { id: 'INV-2026-07', dateLabel: '20 Jul', amount: 1499, state: 'due' },
];

/* ── topbar bell deep links (routing spec Diagram 04) ───────── */
export interface BellItem { icon: string; title: string; sub: string; href: string; cta: string }

export function bellItems(orders: Order[]): BellItem[] {
  const poorest = orders.filter(o => o.dispense && o.dispense.variancePct > 80)[0];
  return [
    {
      icon: 'stock', title: 'Low stock · MCH-001', sub: 'Classic Latte 5 kits below threshold',
      href: '/machines/a1b2c3d4-0001-4000-8000-000000000001/stock', cta: 'Log refill',
    },
    {
      icon: 'tank', title: 'Tank inside 2h of expiry', sub: 'TNK-A29E · mounted Today 6:30 AM',
      href: '/machines/a1b2c3d4-0001-4000-8000-000000000001/tanks', cta: 'Mount tank',
    },
    {
      icon: 'ticket', title: 'New dispute · 5-min SLA', sub: 'TKT-1042 · Priya Nair · ₹60',
      href: '/support/tickets/tkt-1042', cta: 'Request clip',
    },
    ...(poorest ? [{
      icon: 'payment', title: 'Payment anomaly', sub: `${poorest.num} · variance ${poorest.dispense?.variancePct}%`,
      href: `/orders/${poorest.id}`, cta: 'Refund / Reissue',
    }] : []),
  ];
}
