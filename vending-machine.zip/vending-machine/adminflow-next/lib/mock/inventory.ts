import type { SupplyItem, KitTemplate, WasteRow } from './types';
import { TANKS, TANK_EVENTS } from './fleet';

/* ─────────────────────────────────────────────────────────────
   Inventory module dataset. Tanks live in fleet.ts (single
   source for both machine tabs AND the fleet-wide lifecycle).
   ───────────────────────────────────────────────────────────── */

export { TANKS as FLEET_TANKS, TANK_EVENTS as FLEET_TANK_EVENTS };

export const SUPPLIES: SupplyItem[] = [
  { id: 'sp-1', name: 'Bulk coffee powder (Classic)', unit: 'kg', onHand: 14, unitCost: 640, servingsPerUnit: 120, reorder: 5 },
  { id: 'sp-2', name: 'Bulk coffee powder (Manhattan)', unit: 'kg', onHand: 9, unitCost: 720, servingsPerUnit: 105, reorder: 6 },
  { id: 'sp-3', name: 'Nested paper cups 110ml', unit: 'pack (100)', onHand: 23, unitCost: 210, servingsPerUnit: 100, reorder: 10 },
  { id: 'sp-4', name: 'Sugar sticks', unit: 'pack (500)', onHand: 6, unitCost: 185, servingsPerUnit: 500, reorder: 3 },
  { id: 'sp-5', name: 'Stirrers', unit: 'pack (500)', onHand: 4, unitCost: 130, servingsPerUnit: 500, reorder: 2 },
  { id: 'sp-6', name: 'Kit pouches (graded)', unit: 'pack (50)', onHand: 17, unitCost: 145, servingsPerUnit: 50, reorder: 6 },
];

export const KIT_TEMPLATES: KitTemplate[] = [
  { name: 'Classic kit', emoji: '☕', components: [{ item: 'Coffee dose · Classic', qty: '1 sachet' }, { item: 'Sugar sticks', qty: '2' }, { item: 'Pouch', qty: '1' }] },
  { name: 'Manhattan kit', emoji: '👑', components: [{ item: 'Coffee dose · Manhattan blend', qty: '1 sachet' }, { item: 'Cocoa dusting', qty: '1 mini' }, { item: 'Pouch', qty: '1' }] },
  { name: 'Frappe kit (cold)', emoji: '🧊', components: [{ item: 'Coffee dose · Frappe', qty: '1 sachet' }, { item: 'Cold stabiliser', qty: '1' }, { item: 'Pouch', qty: '1' }] },
];

export const WASTE: WasteRow[] = [
  { id: 'ws-1', tsLabel: 'Today · 6:31 AM', machine: 'MCH-001 · Campus Hub', kind: 'expired-tank', qty: '4L milk', loss: 224, note: 'TNK-A29D out of hold — destroyed per SOP' },
  { id: 'ws-2', tsLabel: 'Yesterday · 2:15 PM', machine: 'MCH-002 · Mall Lane', kind: 'clog', qty: '2 kits', loss: 46, note: 'Classic kits written off during service' },
  { id: 'ws-3', tsLabel: 'Wed · 11:45 AM', machine: 'MCH-002 · Mall Lane', kind: 'over-pour', qty: '1.0L', loss: 52, note: 'flow meter overshoot — flagged for calibration' },
  { id: 'ws-4', tsLabel: 'Tue · 9:20 AM', machine: 'MCH-001 · Campus Hub', kind: 'damaged-cup', qty: '6 cups', loss: 12, note: 'jammed in conveyor, crushed' },
  { id: 'ws-5', tsLabel: 'Tue · 7:40 AM', machine: 'MCH-001 · Campus Hub', kind: 'expired-tank', qty: '2L milk', loss: 112, note: 'found above hold temp after power event' },
];

export function wasteMonthly(): { total: number; lossPctOfRevenue: number; hotMachine: string } {
  const total = WASTE.reduce((a, r) => a + r.loss, 0);
  return { total, lossPctOfRevenue: Math.round((total / 152000) * 1000) / 10, hotMachine: 'MCH-002 · Mall Lane (spoilage rate 2.8× fleet avg)' };
}

/** refill estimator — burns the last 24h of orders forward */
export function refillEstimate(machineId: 'a1b2c3d4-0001-4000-8000-000000000001' | 'a1b2c3d4-0002-4000-8000-000000000002'): { machine: string; litres: number; cups: number; kinds: string[]; verdict: string } {
  if (machineId === 'a1b2c3d4-0001-4000-8000-000000000001') {
    return { machine: 'MCH-001 · Campus Hub', litres: 15, cups: 60, kinds: ['2 Manhattan kits', '1 Frappe kit', '1 malai pouch'], verdict: 'needs ~15 L and 50 cups in the next 2 hours' };
  }
  return { machine: 'MCH-002 · Mall Lane', litres: 9, cups: 42, kinds: ['1 Classic kit round', '1 malai pouch'], verdict: 'needs ~9 L and 40 cups in the next 2 hours' };
}
