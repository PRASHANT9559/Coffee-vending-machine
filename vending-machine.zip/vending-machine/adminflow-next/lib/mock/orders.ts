import type { Order, DispenseLog } from './types';

/* ─────────────────────────────────────────────────────────────
   Orders dataset — 36 deterministic rows spanning today,
   yesterday and earlier this week. A few rows carry outlier
   dispense logs; they anchor the dispute-desk evidence and the
   refund queue so every screen tells one consistent story.
   ───────────────────────────────────────────────────────────── */

const NOW = 'Today';
const MENU: { full: string; short: string; amount: number; emoji: string }[] = [
  { full: 'Manhattan Velvet Cappuccino', short: 'Manhattan Velvet', amount: 60, emoji: '👑' },
  { full: 'Classic Café Latte', short: 'Classic Latte', amount: 20, emoji: '☕' },
  { full: 'Grande Roast', short: 'Grande Roast', amount: 40, emoji: '🔥' },
  { full: 'Chilled Manhattan Frappe', short: 'Chilled Frappe', amount: 40, emoji: '🧊' },
];

const NAMES = ['Priya Nair', 'Dev Patel', 'Ritika Sen', 'Sameer Verma', 'Aisha Khan', 'Vikas Rathod', 'Tara Bose', 'Kunal Mishra', 'Neha Joshi', 'Farhan Ali', 'Gaurav Shetty', 'Ira Sharma'];
const CUSTOMERS = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'c10', 'c11', 'c12'];

function dl(variancePct: number, overrides: Partial<DispenseLog> = {}): DispenseLog {
  const expectedMl = 180;
  const actualMl = Math.round(expectedMl * (1 - variancePct / 100));
  return {
    valveMs: 2100,
    pulses: Math.round(actualMl * 1.1),
    expectedMl,
    actualMl,
    variancePct: Math.round(Math.abs(variancePct) * 10) / 10,
    cupDetected: true,
    kitDropped: true,
    malaiPumpMs: 640,
    conveyorSteps: 3,
    windowOpened: true,
    pickupDetected: true,
    ...overrides,
  };
}

let seq = 2249;

function mk(args: {
  when: string; machineId: 'a1b2c3d4-0001-4000-8000-000000000001' | 'a1b2c3d4-0002-4000-8000-000000000002'; vi: number; cust: number | null;
  payment: Order['payment']; status: Order['status']; flagged?: boolean;
  source?: Order['code']['source']; shares?: number; redeemed?: boolean;
  dispense?: DispenseLog | null; variance?: number;
  discount?: number; costBasis?: number; anon?: boolean;
}): Order {
  seq += 1;
  const v = MENU[args.vi];
  const machine = args.machineId === 'a1b2c3d4-0001-4000-8000-000000000001' ? 'MCH-001 · Campus Hub' : 'MCH-002 · Mall Lane';
  const sla = (args.vi + seq) % 97;
  const custName = args.cust == null ? null : NAMES[args.cust];
  const num = `ORD-${seq}`;
  return {
    id: `o-${seq}`,
    num,
    tsLabel: args.when,
    machineId: args.machineId,
    machine,
    variant: v.full,
    variantShort: v.short,
    amount: v.amount,
    finalAmount: Math.max(0, v.amount - (args.discount ?? 0)),
    discount: args.discount ?? 0,
    costBasis: args.costBasis ?? 8 + args.vi * 3,
    payment: args.payment,
    status: args.status,
    flagged: args.flagged ?? false,
    customerId: args.anon || args.cust == null ? null : CUSTOMERS[args.cust - 1],
    customerName: args.anon || args.cust == null ? null : custName,
    code: {
      value: `MC${(seq * 7919) % 99999999}-${sla}`,
      source: args.source ?? 'buy',
      issuedLabel: args.when,
      expiryLabel: 'Valid · 10 min window',
      shared: args.shares ?? 0,
      redeemed: args.redeemed ?? args.status === 'completed',
      redeemedLabel: args.status === 'completed' ? args.when : null,
    },
    dispense: args.dispense ?? (args.status === 'completed' ? dl(args.variance ?? (seq % 9) * 0.6) : null),
    tankUid: args.machineId === 'a1b2c3d4-0001-4000-8000-000000000001' ? 'TNK-A29F' : 'TNK-B100',
    tankAgeH: args.when.startsWith('Today') ? 5 : 22,
    healthNotes: null,
  };
}

export function seedOrders(): Order[] {
  return [
    // today — mix of healthy + evidence rows
    mk({ when: `${NOW} · 11:42 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 0, cust: 1, payment: 'upi', status: 'completed', dispense: dl(96, { actualMl: 8, pulses: 9, pickupDetected: false, cupDetected: true, malaiPumpMs: 0, conveyorSteps: 1 }), flagged: true }),
    mk({ when: `${NOW} · 11:20 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: 2, payment: 'wallet', status: 'completed', discount: 0 }),
    mk({ when: `${NOW} · 11:04 AM`, machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 3, cust: null, source: 'ad', payment: 'coins', status: 'completed', anon: true, variance: 1.2 }),
    mk({ when: `${NOW} · 10:48 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 2, cust: 3, payment: 'upi', status: 'completed' }),
    mk({ when: `${NOW} · 10:31 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 0, cust: 4, payment: 'upi', status: 'preparing', redeemed: false, shares: 1 }),
    mk({ when: `${NOW} · 10:05 AM`, machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 1, cust: 5, payment: 'upi', status: 'completed', discount: 2, costBasis: 9 }),
    mk({ when: `${NOW} · 9:47 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: null, source: 'referral', payment: 'upi', status: 'completed', anon: true }),
    mk({ when: `${NOW} · 9:12 AM`, machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 0, cust: 6, payment: 'wallet', status: 'completed', variance: 2.4 }),
    mk({ when: `${NOW} · 8:52 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 3, cust: null, source: 'gift', payment: 'coins', status: 'completed', anon: true, shares: 2 }),
    mk({ when: `${NOW} · 8:20 AM`, machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 2, cust: 7, payment: 'upi', status: 'pending', redeemed: false }),
    mk({ when: `${NOW} · 8:02 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: 8, payment: 'upi', status: 'completed' }),
    mk({ when: `${NOW} · 7:41 AM`, machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 0, cust: 9, payment: 'upi', status: 'cancelled', dispense: null, redeemed: false }),

    // yesterday — pickup missing / tank expired + role story rows
    mk({ when: 'Yesterday · 9:58 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 0, cust: 10, payment: 'upi', status: 'completed', dispense: dl(3.1, { pickupDetected: false }), flagged: true }),
    mk({ when: 'Yesterday · 9:12 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 2, cust: 11, payment: 'wallet', status: 'completed' }),
    mk({ when: 'Yesterday · 8:33 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: null, source: 'ad', payment: 'coins', status: 'completed', anon: true, variance: 0.8 }),
    mk({ when: 'Yesterday · 7:56 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 3, cust: 12, payment: 'upi', status: 'completed', discount: 5, costBasis: 11 }),
    mk({ when: 'Yesterday · 6:44 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 0, cust: 1, payment: 'upi', status: 'completed', variance: 2.2 }),
    mk({ when: 'Yesterday · 5:29 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 1, cust: 2, payment: 'wallet', status: 'completed' }),
    mk({ when: 'Yesterday · 4:58 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 2, cust: null, source: 'referral', payment: 'upi', status: 'completed', anon: true }),
    mk({ when: 'Yesterday · 4:44 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 0, cust: 2, payment: 'upi', status: 'refunded', dispense: dl(88, { pickupDetected: false, actualMl: 22, pulses: 24 }), flagged: true }),
    mk({ when: 'Yesterday · 3:37 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: 3, payment: 'upi', status: 'completed' }),
    mk({ when: 'Yesterday · 2:52 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 3, cust: 4, payment: 'coins', status: 'completed', variance: 1.6 }),
    mk({ when: 'Yesterday · 1:21 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 0, cust: 5, payment: 'upi', status: 'completed' }),
    mk({ when: 'Yesterday · 12:04 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 2, cust: null, source: 'gift', payment: 'upi', status: 'completed', anon: true, shares: 1 }),

    // earlier this week
    mk({ when: 'Mon · 10:18 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 0, cust: 6, payment: 'upi', status: 'completed' }),
    mk({ when: 'Mon · 8:44 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 3, cust: null, source: 'ad', payment: 'coins', status: 'completed', anon: true }),
    mk({ when: 'Mon · 7:02 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 2, cust: 7, payment: 'wallet', status: 'cancelled', dispense: null, redeemed: false }),
    mk({ when: 'Mon · 5:21 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: 8, payment: 'upi', status: 'completed' }),
    mk({ when: 'Mon · 3:10 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 0, cust: 9, payment: 'upi', status: 'refunded', flagged: true, dispense: dl(41), costBasis: 8 }),
    mk({ when: 'Mon · 1:31 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: 10, payment: 'wallet', status: 'completed' }),
    mk({ when: 'Mon · 11:57 AM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 2, cust: null, source: 'referral', payment: 'upi', status: 'completed', anon: true }),
    mk({ when: 'Mon · 10:02 AM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 3, cust: 11, payment: 'upi', status: 'completed', variance: 0.4 }),
    mk({ when: 'Mon · 9:16 AM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 1, cust: 12, payment: 'wallet', status: 'completed' }),
    mk({ when: 'Mon · 8:05 AM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 0, cust: 1, payment: 'upi', status: 'completed', shares: 3 }),
    mk({ when: 'Sun · 8:44 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 2, cust: null, source: 'buy', payment: 'upi', status: 'completed', anon: true }),
    mk({ when: 'Sun · 7:12 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 1, cust: 2, payment: 'upi', status: 'completed' }),
    mk({ when: 'Sun · 5:50 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 0, cust: 3, payment: 'wallet', status: 'completed', variance: 2.8 }),
    mk({ when: 'Sun · 4:19 PM', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', vi: 3, cust: null, source: 'gift', payment: 'coins', status: 'completed', anon: true, shares: 4 }),
    mk({ when: 'Sun · 2:33 PM', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', vi: 2, cust: 4, payment: 'upi', status: 'pending', redeemed: false }),
  ];
}

/** order ids referenced by tickets & refunds (story anchors)
 *  seq starts at 2250 with the first row = o-2250 */
export const ANCHOR_ORDER_IDS = {
  noCoffee: 'o-2250',      // variance 96% — Priya Nair dispute (TKT-1042)
  pickupMissing: 'o-2268', // yesterday 4:44 PM — cup stuck (TKT-1040)
  cleanReject: 'o-2265',   // yesterday 6:44 PM — variance 2%, pickup ok (TKT-1041)
};
