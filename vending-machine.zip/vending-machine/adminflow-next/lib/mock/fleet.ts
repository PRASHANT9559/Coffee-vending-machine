import type { Machine, MachineCommand, TankRow, TankEvent, StockRow, StockEvent, CameraChannel, MaintenanceLog } from './types';

/* ─────────────────────────────────────────────────────────────
   Fleet dataset — consistent with lib/demo-data.ts machine
   chips (MCH-001 Campus Hub · MCH-002 Mall Lane).
   All timestamps are deterministic labels, no clock dependency.
   ───────────────────────────────────────────────────────────── */

export const MACHINES: Machine[] = [
  {
    id: 'a1b2c3d4-0001-4000-8000-000000000001', code: 'MCH-001', name: 'Campus Hub', city: 'Pune', venue: 'VIIT Campus · Main Gate',
    online: true, live: true, mode: 'hot', tempC: 65.4, targetTemp: 65, litres: 38, malaiL: 6,
    cups: 142, kits: 23, locked: false, signalDbm: -67, lastSeenLabel: '12s ago', lastSeenMin: 0,
    firmware: 'fw 2.4.1', fwSha: '9f21c4a7', bootCount: 1142, wdtResets: 3,
    sensors: [
      { name: 'Milk temp · DS18B20', ok: true, note: '±0.2°C' },
      { name: 'Flow meter · YF-S401', ok: false, note: 'drift ~2% — recalibrate' },
      { name: 'Cup present · IR', ok: true, note: '' },
      { name: 'Door latch', ok: true, note: '' },
      { name: 'Heater relay', ok: true, note: 'kg3 OK' },
    ],
    faults: [
      { code: 'F-12', label: 'Flow drift on YF-S401', atLabel: 'Today · 10:40 AM', critical: false, resolved: false },
      { code: 'F-03', label: '4G drop · offline 6 min', atLabel: 'Yesterday · 2:12 PM', critical: false, resolved: true },
    ],
    reorder: { cups: 50, kits: 12, malai: 5 },
  },
  {
    id: 'a1b2c3d4-0002-4000-8000-000000000002', code: 'MCH-002', name: 'Mall Lane', city: 'Pune', venue: 'Phoenix Mall · Level 2',
    online: true, live: true, mode: 'cold', tempC: 6.2, targetTemp: 6, litres: 21, malaiL: 4,
    cups: 88, kits: 15, locked: true, signalDbm: -74, lastSeenLabel: '48s ago', lastSeenMin: 0,
    firmware: 'fw 2.4.1', fwSha: '9f21c4a7', bootCount: 986, wdtResets: 1,
    sensors: [
      { name: 'Milk temp · DS18B20', ok: true, note: 'cold hold 6.0°C' },
      { name: 'Flow meter · YF-S401', ok: true, note: '' },
      { name: 'Cup present · IR', ok: true, note: '' },
      { name: 'Door latch', ok: false, note: 'intermittent — service visit booked' },
      { name: 'Compressor', ok: true, note: 'cold mode' },
    ],
    faults: [
      { code: 'F-08', label: 'Door latch intermittent', atLabel: 'Yesterday · 3:12 PM', critical: true, resolved: true },
    ],
    reorder: { cups: 50, kits: 12, malai: 5 },
  },
];

export function getMachine(id: string): Machine | undefined {
  return MACHINES.find(m => m.id === id);
}

/* ── commands history (routing spec: command log + TTL) ─────── */
export function seedCommands(): MachineCommand[] {
  return [
    { id: 'cmd-6', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', cmd: 'lock', status: 'done', ttlS: 120, by: 'Meera Sawant · ops', atLabel: 'Today · 9:02 AM', result: '{"locked":true,"ack":184}' },
    { id: 'cmd-5', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', cmd: 'test_dispense', status: 'done', ttlS: 120, by: 'Chief Rohan · owner', atLabel: 'Yesterday · 7:20 PM', result: '{"ml":112,"pulses":180,"ok":true}' },
    { id: 'cmd-4', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', cmd: 'set_target_temp', status: 'done', ttlS: 120, by: 'Chief Rohan · owner', atLabel: 'Yesterday · 7:18 PM', result: '{"target":65}' },
    { id: 'cmd-3', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', cmd: 'reboot', status: 'expired', ttlS: 0, by: 'Meera Sawant · ops', atLabel: 'Yesterday · 2:31 PM', result: '{"error":"machine offline at TTL"}' },
    { id: 'cmd-2', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', cmd: 'unlock', status: 'done', ttlS: 120, by: 'Meera Sawant · ops', atLabel: 'Yesterday · 11:00 AM', result: '{"locked":false}' },
    { id: 'cmd-1', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', cmd: 'ota_rollout', status: 'failed', ttlS: 120, by: 'Chief Rohan · owner', atLabel: 'Fri · 6:12 PM', result: '{"error":"checksum mismatch, rolled back", "sha":"1a33de"}' },
  ];
}

/* ── tanks ──────────────────────────────────────────────────── */
export const TANKS: TankRow[] = [
  { id: 'tk-1', uid: 'TNK-A29F', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub', litres: 20, filledLabel: 'Today · 6:30 AM', ageH: 5, holdH: 12, state: 'active', fssai: true },
  { id: 'tk-2', uid: 'TNK-A29E', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub', litres: 20, filledLabel: 'Today · 6:30 AM', ageH: 5, holdH: 12, state: 'near', fssai: true },
  { id: 'tk-3', uid: 'TNK-B100', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane', litres: 20, filledLabel: 'Yesterday · 9:15 AM', ageH: 20, holdH: 12, state: 'active', fssai: true },
  { id: 'tk-4', uid: 'TNK-B099', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane', litres: 10, filledLabel: 'Yesterday · 9:15 AM', ageH: 27, holdH: 12, state: 'expired', fssai: true },
  { id: 'tk-5', uid: 'TNK-A29D', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub', litres: 20, filledLabel: 'Wed · 7:00 AM', ageH: 68, holdH: 12, state: 'disposed', disposeReason: 'hold window exceeded — sanitized & returned', fssai: true },
  { id: 'tk-6', uid: 'TNK-B097', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane', litres: 20, filledLabel: 'Tue · 8:40 AM', ageH: 90, holdH: 12, state: 'disposed', disposeReason: 'crack at weld seam', fssai: true },
];

export const TANK_EVENTS: TankEvent[] = [
  { tsLabel: 'Today · 6:30 AM', machine: 'MCH-001', action: 'mounted', detail: 'TNK-A29F · 20L mounted · sealed ok', by: 'Meera Sawant' },
  { tsLabel: 'Today · 6:30 AM', machine: 'MCH-001', action: 'disposed', detail: 'TNK-A29D · hold window exceeded', by: 'Meera Sawant' },
  { tsLabel: 'Yesterday · 9:15 AM', machine: 'MCH-002', action: 'mounted', detail: 'TNK-B100 · 20L mounted', by: 'Ravi Kadam' },
  { tsLabel: 'Yesterday · 5:02 PM', machine: 'MCH-001', action: 'top-up', detail: '+4L · milk truck delivery batch M-2261', by: 'Ravi Kadam' },
  { tsLabel: 'Wed · 7:00 AM', machine: 'MCH-002', action: 'disposed', detail: 'TNK-B097 · weld crack, contents destroyed', by: 'Ravi Kadam' },
];

export function tanksFor(machineId: string): { current: TankRow[]; events: TankEvent[] } {
  return {
    current: TANKS.filter(t => t.machineId === machineId && t.state !== 'disposed'),
    events: TANK_EVENTS.filter(e => e.machine === (getMachine(machineId)?.code ?? '')),
  };
}

/* ── stock ──────────────────────────────────────────────────── */
export const STOCK: StockRow[] = [
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', variant: 'Manhattan Velvet', kind: 'kits', qty: 23, unit: 'kits', threshold: 12, lastRefillLabel: 'Today · 6:28 AM' },
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', variant: 'Classic Latte', kind: 'kits', qty: 8, unit: 'kits', threshold: 12, lastRefillLabel: 'Today · 6:28 AM' },
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', variant: 'Grande Roast', kind: 'kits', qty: 19, unit: 'kits', threshold: 10, lastRefillLabel: 'Today · 6:28 AM' },
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', variant: 'Chilled Frappe', kind: 'kits', qty: 6, unit: 'kits', threshold: 10, lastRefillLabel: 'Thu · 2:00 PM' },
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', variant: 'Cups', kind: 'cups', qty: 142, unit: 'cups', threshold: 50, lastRefillLabel: 'Today · 6:28 AM' },
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', variant: 'Malai', kind: 'malai', qty: 6, unit: 'litres', threshold: 5, lastRefillLabel: 'Yesterday · 5:02 PM' },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', variant: 'Manhattan Velvet', kind: 'kits', qty: 15, unit: 'kits', threshold: 12, lastRefillLabel: 'Yesterday · 9:10 AM' },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', variant: 'Classic Latte', kind: 'kits', qty: 5, unit: 'kits', threshold: 10, lastRefillLabel: 'Yesterday · 9:10 AM' },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', variant: 'Grande Roast', kind: 'kits', qty: 14, unit: 'kits', threshold: 10, lastRefillLabel: 'Yesterday · 9:10 AM' },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', variant: 'Chilled Frappe', kind: 'kits', qty: 11, unit: 'kits', threshold: 10, lastRefillLabel: 'Yesterday · 9:10 AM' },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', variant: 'Cups', kind: 'cups', qty: 88, unit: 'cups', threshold: 50, lastRefillLabel: 'Yesterday · 9:10 AM' },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', variant: 'Malai', kind: 'malai', qty: 4, unit: 'litres', threshold: 4, lastRefillLabel: 'Tue · 4:20 PM' },
];

export const STOCK_EVENTS: StockEvent[] = [
  { tsLabel: 'Today · 6:28 AM', machine: 'MCH-001', variant: 'all kits · cups', qty: 0, kind: 'refill', by: 'Ravi Kadam', note: 'bulk refill log — one entry covers all variants' },
  { tsLabel: 'Yesterday · 5:02 PM', machine: 'MCH-001', variant: 'malai', qty: 4, kind: 'refill', by: 'Ravi Kadam', note: 'malai top-up with tank route' },
  { tsLabel: 'Yesterday · 2:15 PM', machine: 'MCH-002', variant: 'Classic Latte', qty: 2, kind: 'waste', by: 'Meera Sawant', note: 'clog — kits destroyed, wrote off' },
  { tsLabel: 'Thu · 2:00 PM', machine: 'MCH-001', variant: 'Chilled Frappe', qty: 10, kind: 'refill', by: 'Ravi Kadam', note: 'summer switch load' },
  { tsLabel: 'Wed · 11:45 AM', machine: 'MCH-002', variant: 'malai', qty: 1, kind: 'waste', by: 'Ravi Kadam', note: 'over-pour detected by flow meter' },
];

export function stockFor(machineId: string): { rows: StockRow[]; low: StockRow[] } {
  const rows = STOCK.filter(s => s.machineId === machineId);
  return { rows, low: rows.filter(r => r.kind !== 'cups' && r.qty < r.threshold) };
}

/* low-stock across fleet (deep-link source for the bell) */
export function fleetLowStock(): { machineId: string; machine: string; variant: string; qty: number; threshold: number }[] {
  return STOCK.filter(s => s.qty < s.threshold && s.kind !== 'cups')
    .map(s => ({ machineId: s.machineId, machine: s.machineId === 'a1b2c3d4-0001-4000-8000-000000000001' ? 'MCH-001 · Campus Hub' : 'MCH-002 · Mall Lane', variant: s.variant, qty: s.qty, threshold: s.threshold }));
}

/* ── cameras ────────────────────────────────────────────────── */
export const CAMERAS: CameraChannel[] = [
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', channel: 1, label: 'Dispense cam (internal)', sdFreePct: 64, retentionDays: 7, lastFrameSec: 3 },
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', channel: 2, label: 'Customer cam (front)', sdFreePct: 64, retentionDays: 7, lastFrameSec: 5 },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', channel: 1, label: 'Dispense cam (internal)', sdFreePct: 22, retentionDays: 7, lastFrameSec: 2 },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', channel: 2, label: 'Customer cam (front)', sdFreePct: 22, retentionDays: 7, lastFrameSec: 240 },
];

export function camerasFor(machineId: string): CameraChannel[] {
  return CAMERAS.filter(c => c.machineId === machineId);
}

/* ── maintenance ────────────────────────────────────────────── */
export const MAINTENANCE: MaintenanceLog[] = [
  { tsLabel: 'Today · 6:30 AM', machine: 'MCH-001', task: 'Tank swap + bulk refill', tech: 'Ravi Kadam', mins: 22, notes: 'two tanks mounted, reorder log updated' },
  { tsLabel: 'Yesterday · 5:05 PM', machine: 'MCH-001', task: 'Malai pump inspection', tech: 'Ravi Kadam', mins: 12, notes: 'no clog; over-pour alarm cleared' },
  { tsLabel: 'Yesterday · 2:35 PM', machine: 'MCH-002', task: 'Reboot after 4G drop', tech: 'remote', mins: 4, notes: 'reconnect ok; SIM registration 12 dB gain' },
  { tsLabel: 'Wed · 7:05 AM', machine: 'MCH-002', task: 'Door latch tighten', tech: 'Ravi Kadam', mins: 9, notes: 'temporary — replacement hinge ordered' },
  { tsLabel: 'Tue · 1:00 PM', machine: 'MCH-001', task: 'Flow meter calibration', tech: 'Meera Sawant', mins: 25, notes: 'drift 2% — recalibrated, monitor next 48h' },
];

export const REFILL_ESTIMATOR: { machineId: string; burnOrderIdPerH: number; litresPerOrder: number; cupsPerOrder: number; hoursAhead: number }[] = [
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', burnOrderIdPerH: 11, litresPerOrder: 0.24, cupsPerOrder: 1, hoursAhead: 2 },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', burnOrderIdPerH: 9, litresPerOrder: 0.24, cupsPerOrder: 1, hoursAhead: 2 },
];

/* ── telemetry (deterministic pseudo-series) ────────────────── */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type TelemetryWindow = '24h' | '7d' | '30d';

export interface TelemetrySeries {
  labels: string[];
  temp: number[];
  litres: number[];
  signal: number[];
  orders: number[];
}

export function telemetryFor(machineId: string, window: TelemetryWindow): TelemetrySeries {
  const m = getMachine(machineId);
  const r = mulberry32(machineId === 'a1b2c3d4-0001-4000-8000-000000000001' ? 7 : 19);
  const n = window === '24h' ? 24 : window === '7d' ? 7 : 30;
  const labels = Array.from({ length: n }, (_, i) =>
    window === '24h' ? `${((new Date().getUTCHours() + 18 + (23 - i)) % 24).toString().padStart(2, '0')}:00`
      : window === '7d' ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]
        : `D${30 - i}`,
  );

  const temp: number[] = [];
  const litres: number[] = [];
  const signal: number[] = [];
  const orders: number[] = [];
  let lvl = m?.mode === 'cold' ? 21 : 38;

  for (let i = 0; i < n; i++) {
    const dayT = Math.sin((i / Math.max(2, n)) * Math.PI * 2);
    const base = window === '24h'
      ? (m?.mode === 'cold' ? 6.2 : 65.4) + dayT * 2.4
      : (m?.mode === 'cold' ? 6.1 : 65.1) + dayT * 3.1;
    temp.push(Math.round((base + (r() - 0.5) * 1.6) * 10) / 10);

    lvl -= (m?.mode === 'cold' ? 1.1 : 0.9) * (n > 10 ? 2 : 1) * (0.4 + r());
    if (lvl < 8 && (i % 7 === 5 || lvl < 6)) lvl = m?.mode === 'cold' ? 20 : 36;  // refill spike
    litres.push(Math.max(0, Math.round(lvl)));

    signal.push(m?.id === 'a1b2c3d4-0001-4000-8000-000000000001' ? -64 - Math.round(Math.abs(dayT) * 9 + r() * 4) : -72 - Math.round(r() * 6));
    orders.push(Math.round((m?.id === 'a1b2c3d4-0001-4000-8000-000000000001' ? 92 : 76) * (0.55 + dayT * 0.35 + r() * 0.25)));
  }
  return { labels, temp, litres, signal, orders };
}
