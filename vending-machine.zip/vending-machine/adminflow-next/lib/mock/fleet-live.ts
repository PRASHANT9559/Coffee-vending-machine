import { MACHINES } from './fleet';
import { machinePatched } from './store';
import type { Machine } from './types';

/* fleet.ts is the seed; store.ts holds live demo patches (lock /
   mode / temp changes coming from action buttons). This glue
   merges both into one live view — no import cycle. */

export function machinesLive(): Machine[] {
  return MACHINES.map(m => ({ ...m, ...(machinePatched(m.id) as Partial<Machine>) }));
}

export function machineLive(id: string): Machine | undefined {
  return machinesLive().find(m => m.id === id);
}

export function machineOnOrders(machineId: string): number {
  // static demo figure keyed to machine
  return machineId === 'a1b2c3d4-0001-4000-8000-000000000001' ? 92 : 76;
}
