import type { SalesPoint, TierMixPoint, ProductStat, MachineCompare, ProfitPoint } from './types';

/* ─────────────────────────────────────────────────────────────
   Analytics dataset — deterministic series. The seeded day
   pattern matches the dashboard demo (Diwali-ish Wed–Sat lift).
   ───────────────────────────────────────────────────────────── */

export const SALES_DAYS: SalesPoint[] = [
  { label: 'Mon', revenue: 18400, orders: 52 },
  { label: 'Tue', revenue: 21600, orders: 61 },
  { label: 'Wed', revenue: 19800, orders: 55 },
  { label: 'Thu', revenue: 26300, orders: 74 },
  { label: 'Fri', revenue: 24100, orders: 68 },
  { label: 'Sat', revenue: 31200, orders: 88 },
  { label: 'Sun', revenue: 16850, orders: 44 },
];

export const SALES_WEEKS: SalesPoint[] = [
  { label: 'W1', revenue: 124000, orders: 352 },
  { label: 'W2', revenue: 138000, orders: 398 },
  { label: 'W3', revenue: 131000, orders: 374 },
  { label: 'W4', revenue: 152000, orders: 428 },
];

export const TIER_MIX: TierMixPoint[] = [
  { label: 'Mon', t10: 5100, t20: 5200, t40: 5600, t60: 2500 },
  { label: 'Tue', t10: 4800, t20: 5600, t40: 7400, t60: 3800 },
  { label: 'Wed', t10: 5600, t20: 4400, t40: 6400, t60: 3400 },
  { label: 'Thu', t10: 6100, t20: 6200, t40: 8200, t60: 5800 },
  { label: 'Fri', t10: 5300, t20: 5800, t40: 7600, t60: 5400 },
  { label: 'Sat', t10: 6200, t20: 7600, t40: 9600, t60: 7800 },
  { label: 'Sun', t10: 4400, t20: 4600, t40: 4800, t60: 3050 },
];

export const MACHINE_SPLIT: { machine: string; city: string; revenue: number; orders: number; cupsDay: number }[] = [
  { machine: 'MCH-001 · Campus Hub', city: 'Pune', revenue: 514200, orders: 1382, cupsDay: 92 },
  { machine: 'MCH-002 · Mall Lane', city: 'Pune', revenue: 428800, orders: 1120, cupsDay: 76 },
];

export const PRODUCT_STATS: ProductStat[] = [
  { variant: 'Manhattan Velvet Cappuccino', emoji: '👑', orders: 421, revenue: 25260, costPerServing: 12.5, marginPct: 79, rank: 1, note: 'Flagship — protect the price point, never discount.' },
  { variant: 'Grande Roast', emoji: '🔥', orders: 205, revenue: 8200, costPerServing: 8.4, marginPct: 79, rank: 2, note: 'Steady afternoon seller.' },
  { variant: 'Classic Café Latte', emoji: '☕', orders: 178, revenue: 3560, costPerServing: 3.9, marginPct: 81, rank: 3, note: 'Entry tier — ₹20 quietly pulls buyers down from ₹40 when visible.' },
  { variant: 'Chilled Manhattan Frappe', emoji: '🧊', orders: 96, revenue: 3840, costPerServing: 12.1, marginPct: 70, rank: 4, note: 'Cannibalisation → when Manhattan Velvet is out of stock the Frappe sells 2.3×. Stockout problem, not demand problem.' },
];

export const HEAT_24X7: number[][] = buildHeat();
function buildHeat(): number[][] {
  const dayShape = [1, 0.5, 0.2, 0.1, 0.2, 0.9, 3.2, 6.5, 9.8, 11.4, 12.6, 10.9, 7.2, 5.6, 6.4, 8.2, 9.6, 8.4, 6.2, 4.1, 3.3, 2.6, 1.8, 1.1];
  const dayMult = [1.0, 1.0, 1.0, 1.0, 1.0, 1.25, 1.1];
  return dayMult.map(dm => dayShape.map(h => Math.round(h * dm * 4 + (dm > 1.1 ? 5 : 0))));
}

export const PEAK_WINDOWS = ['11:00 AM – 1:00 PM', '4:30 PM – 6:30 PM'];
export const NEW_VS_RETURNING = { newPct: 28, returningPct: 72, repeatPct: 61, firstOrderTime: '11:42 AM' };

export const MACHINE_COMPARE_ROWS: MachineCompare[] = [
  { machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub', city: 'Pune', uptimePct: 99.2, cupsDay: 92, revenue: 514200, failures: 2, mttrH: 1.4 },
  { machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane', city: 'Pune', uptimePct: 96.8, cupsDay: 76, revenue: 428800, failures: 5, mttrH: 3.1 },
];

export const MACHINE_FLAGS = 'MCH-002 · Mall Lane earns 78% of the fleet average — below the 60% relocation threshold but trending down.';

/* profitability — cash revenue never blended with earned revenue */
export const PROFIT: {
  revenue: number; materialPct: number; material: number;
  adRevenue: number; adSpaceRent: number; fourG: number; electricity: number;
  netProfit: number; cac: number; ltv: number; breakEvenCupsDay: number; fixedCostDay: number;
  cashVsEarned: ProfitPoint[];
} = {
  revenue: 152000,
  materialPct: 31,
  material: 47120,
  adRevenue: 1240,
  adSpaceRent: 3500,
  fourG: 900,
  electricity: 1600,
  netProfit: 101120,
  cac: 34,
  ltv: 412,
  breakEvenCupsDay: 62,
  fixedCostDay: 2100,
  cashVsEarned: [
    { label: 'Coffee sales (cash)', value: 152000, kind: 'cash' },
    { label: 'Wallet float (earnings)', value: 5600, kind: 'earned' },
    { label: 'Ad revenue (earnings)', value: 1240, kind: 'earned' },
    { label: 'Ad-space rent (earnings)', value: 3500, kind: 'earned' },
  ],
};

export const SAVED_REPORTS = ['Last week vs prior', 'Campus only · Sat peak', 'Cold mode pivot · Sep'];
