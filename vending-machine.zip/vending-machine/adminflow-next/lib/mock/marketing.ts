import type { Offer, Coupon, Banner, PushMsg, Festival, LeaderRow, FraudPair, AdNetwork, PostbackRow, AdSpace } from './types';

/* ─────────────────────────────────────────────────────────────
   Marketing module dataset.
   ───────────────────────────────────────────────────────────── */

export const OFFERS: Offer[] = [
  { id: 'of-1', name: 'Summer switch · Free upgrades', kind: 'wallet-bonus', valueLabel: '+₹10 wallet credit', minOrder: 0, segment: 'All active', budget: 5000, spent: 2480, windowLabel: '1 Oct – 10 Nov', state: 'running', uses: 248 },
  { id: 'of-2', name: 'Exam week · Flat off', kind: 'flat', valueLabel: '₹10 off ₹40', minOrder: 40, segment: 'Near a machine', budget: 3000, spent: 3000, windowLabel: '12–20 Sep', state: 'paused', uses: 300 },
  { id: 'of-3', name: 'Diwali pack 2026', kind: 'free-item', valueLabel: 'Frappe free ₹40', minOrder: 60, segment: 'High value', budget: 8000, spent: 7900, windowLabel: '25–31 Oct', state: 'ended', uses: 196 },
  { id: 'of-4', name: 'Lapsed 3d pull-back', kind: 'percent', valueLabel: '15% off', minOrder: 20, segment: 'Lapsed 3d', budget: 4000, spent: 640, windowLabel: '28 Oct – 7 Nov', state: 'running', uses: 32 },
];

export const COUPONS: Coupon[] = [
  { id: 'cp-1', code: 'MCHELLO', kind: '%', valueLabel: '10% off', perUserLimit: 1, used: 384, total: 500, expiryLabel: '12 Nov', state: 'active' },
  { id: 'cp-2', code: 'EXAM25', kind: 'flat', valueLabel: '₹25 off', perUserLimit: 2, used: 190, total: 400, expiryLabel: '7 Nov', state: 'active' },
  { id: 'cp-3', code: 'FESTIVE40', kind: 'flat', valueLabel: '₹40 off', perUserLimit: 1, used: 400, total: 400, expiryLabel: '31 Oct', state: 'paused' },
  { id: 'cp-4', code: 'BIGCUP10', kind: '%', valueLabel: '10% off', perUserLimit: 1, used: 612, total: 1000, expiryLabel: '5 Dec', state: 'active' },
  { id: 'cp-5', code: 'STUDENT', kind: '%', valueLabel: '15% off', perUserLimit: 3, used: 210, total: 900, expiryLabel: '30 Nov', state: 'active' },
];

export const BANNERS: Banner[] = [
  { id: 'bn-1', slot: 'Home carousel', name: 'Summer switch art', windowLabel: 'Now – 10 Nov', priority: 1, impressions: 41280, clicks: 2210, active: true },
  { id: 'bn-2', slot: 'Home strip', name: 'Manhattan Velvet promo', windowLabel: 'Now – 30 Nov', priority: 2, impressions: 63540, clicks: 890, active: true },
  { id: 'bn-3', slot: 'Splash', name: 'Splash · brand refresh', windowLabel: 'Fixed', priority: 3, impressions: 100240, clicks: 0, active: true },
  { id: 'bn-4', slot: 'QR success', name: 'Referral nudge', windowLabel: 'Now – 10 Nov', priority: 4, impressions: 22610, clicks: 1870, active: true },
  { id: 'bn-5', slot: 'Leaderboard', name: 'Exam week cup', windowLabel: 'Ended', priority: 5, impressions: 14220, clicks: 310, active: false },
  { id: 'bn-6', slot: 'Wallet', name: 'Recharge bonus', windowLabel: 'Now – 20 Nov', priority: 6, impressions: 31800, clicks: 1180, active: true },
];

export const PUSHES: PushMsg[] = [
  { id: 'pu-1', title: 'Your 4-day streak is alive ☕', body: 'One Manhattan Velvet between you and a badge.', segment: 'Streak 2-6d', deepLink: 'app://wallet', atLabel: 'Today · 8:00 AM', delivered: 482, opened: 173, state: 'sent' },
  { id: 'pu-2', title: 'Two machines near you', body: 'Campus Hub peeked 92 orders yesterday.', segment: 'Near a machine', deepLink: 'app://home', atLabel: 'Yesterday · 6:15 PM', delivered: 510, opened: 118, state: 'sent' },
  { id: 'pu-3', title: 'Diwali pack expired', body: '', segment: 'High value', deepLink: 'app://offers', atLabel: '31 Oct · 9:00 PM', delivered: 0, opened: 0, state: 'cancelled' },
  { id: 'pu-4', title: 'Frappe season is here 🧊', body: 'Cold mode is live. First one on the app.', segment: 'All active', deepLink: 'app://home', atLabel: '12 Nov · 9:00 AM', delivered: 0, opened: 0, state: 'scheduled' },
];

export const SEGMENTS = ['All active', 'Lapsed 3d', 'High value', 'Near a machine', 'Coin earners', 'Leaderboard viewers', 'Streak 2-6d'];

export const FESTIVALS: Festival[] = [
  { id: 'fs-1', name: 'Diwali 2026 pack', windowLabel: '25–31 Oct', state: 'past', pack: { offer: 'Diwali pack 2026', banner: 'Diwali home carousel', push: 'Diwali wallet bonus' } },
  { id: 'fs-2', name: 'Exam season pack', windowLabel: '7–14 Nov', state: 'upcoming', pack: { offer: 'Flat ₹10 off ₹40', banner: 'Home strip exam art', push: 'Streak keeper' } },
  { id: 'fs-3', name: 'New Year countdown', windowLabel: '29 Dec – 2 Jan', state: 'upcoming', pack: { offer: 'Wallet bonus @ midnight', banner: 'Splash countdown', push: 'Midnight drop' } },
  { id: 'fs-4', name: 'Summer cold switch', windowLabel: '1 Oct – 10 Nov', state: 'live', pack: { offer: 'Free upgrades', banner: 'Cold campaign art', push: 'Frappe season' } },
];

export const REFERRAL_FUNNEL = { shared: 640, installed: 214, firstOrder: 88, repeat: 41 };

export const LEADERS: LeaderRow[] = [
  { name: 'Vikas Rathod', invites: 14, qualified: 8, gain: 160 },
  { name: 'Dev Patel', invites: 9, qualified: 5, gain: 100 },
  { name: 'Priya Nair', invites: 6, qualified: 4, gain: 80 },
  { name: 'Aisha Khan', invites: 2, qualified: 1, gain: 20 },
  { name: 'Kunal Mishra', invites: 1, qualified: 1, gain: 20 },
];

export const FRAUD_PAIRS: FraudPair[] = [
  { inviter: 'c11 · Gaurav Shetty', invitee: 'c12 · Ira Sharma', device: 'same device fingerprint (OnePlus Nord)', atLabel: '18 Oct' },
  { inviter: 'c7 · Tara Bose', invitee: 'c9 · Neha Joshi', device: 'same wifi SSID × 9 events', atLabel: '2 Nov' },
];

export const AD_NETWORKS: AdNetwork[] = [
  { id: 'an-1', name: 'Zenith Reward Ads', ecpm: 118, impressions: 48200, rewarded: 1290, revenue: 590, coinsPerView: 20, state: 'connected' },
  { id: 'an-2', name: 'TapNetwork', ecpm: 96, impressions: 30100, rewarded: 640, revenue: 310, coinsPerView: 15, state: 'attention' },
  { id: 'an-3', name: 'CoinWall Media', ecpm: 74, impressions: 18600, rewarded: 310, revenue: 340, coinsPerView: 10, state: 'connected' },
];

export const POSTBACKS: PostbackRow[] = [
  { id: 'pb-1', user: 'c8 · Kunal Mishra', claimedLabel: 'Today · 7:12 AM', amount: 20, state: 'pending', reason: 'viewed 14s / postback not received' },
  { id: 'pb-2', user: 'c10 · Farhan Ali', claimedLabel: 'Yesterday · 11:44 PM', amount: 15, state: 'pending', reason: 'view ok / network retry' },
  { id: 'pb-3', user: 'anon · device 74:2f', claimedLabel: 'Yesterday · 10:02 PM', amount: 10, state: 'demoted', reason: 'no postback >24h — coins withheld' },
  { id: 'pb-4', user: 'c8 · Kunal Mishra', claimedLabel: 'Yesterday · 8:31 PM', amount: 20, state: 'pending', reason: 'recheck queued' },
];

export const AD_SPACES: AdSpace[] = [
  { id: 'as-1', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub', surface: 'side-panel', advertiser: 'Brew Bottle Co.', months: 3, ratePerMonth: 1200, startLabel: '1 Nov', endLabel: '31 Jan', invoiceNo: 'INV-1091', state: 'paid' },
  { id: 'as-2', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub', surface: 'cup-print', advertiser: 'Pune Runners Club', months: 2, ratePerMonth: 900, startLabel: '15 Nov', endLabel: '14 Jan', invoiceNo: 'INV-1102', state: 'unpaid' },
  { id: 'as-3', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane', surface: 'fascia', advertiser: 'Mall FM Radio', months: 6, ratePerMonth: 1500, startLabel: '1 Oct', endLabel: '31 Mar', invoiceNo: 'INV-1066', state: 'paid' },
  { id: 'as-4', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane', surface: 'display', advertiser: 'CampusTutors', months: 1, ratePerMonth: 700, startLabel: '20 Oct', endLabel: '19 Nov', invoiceNo: 'INV-1100', state: 'overdue' },
];

export const FESTIVAL_MODE = { coldMode: true, modes: ['hot', 'cold'] };
