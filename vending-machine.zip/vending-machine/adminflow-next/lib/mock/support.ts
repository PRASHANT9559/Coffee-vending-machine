import type { Ticket, Review, BlacklistEntry, Macro } from './types';
import { ANCHOR_ORDER_IDS } from './orders';

/* ─────────────────────────────────────────────────────────────
   Support module dataset — tickets, reviews, blacklist, macros.
   Ticket story rows ride on the anchored orders so the dispute
   desk evidence matches the order page 1:1 (one bundle rule).
   ───────────────────────────────────────────────────────────── */

export function seedTickets(): Ticket[] {
  const T = (t: Ticket) => t;
  return [
    // ── THE dispute desk anchor: payment deducted, machine empty ──
    T({
      id: 'tkt-1042', num: 'TKT-1042', type: 'no-coffee', typeLabel: 'No coffee', channel: 'bot',
      priority: 'P1', state: 'open', customer: 'Priya Nair', customerId: 'c1', phone: '+91 90045 12877',
      amount: 60, upiRef: 'UPI 5142208', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub',
      orderId: ANCHOR_ORDER_IDS.noCoffee, openedLabel: 'Today · 11:42 AM', slaMin: 5, assignedTo: null,
      message: 'Payment deducted ₹60, machine made sound only. No coffee came out, window opened with nothing.',
      contextLine: 'Server-filled: order o-2250 · MCH-001 · 11:42 AM · last 5 orders show 4 completed + 1 refund (flow-drift day)',
      history: [
        { tsLabel: 'Today · 11:42 AM', by: 'bot', text: 'ticket raised · auto-context attached (order, machine, user)' },
        { tsLabel: 'Today · 11:43 AM', by: 'system', text: 'SLA window started (5 min)' },
      ],
      evidence: {
        clipUrl: 'supabase://video_clips/tkt-1042/dispute-30s.mp4', clipLenS: 30,
        dispense: {
          valveMs: 2100, pulses: 9, expectedMl: 180, actualMl: 8, variancePct: 96,
          cupDetected: true, kitDropped: true, malaiPumpMs: 0, conveyorSteps: 1,
          windowOpened: true, pickupDetected: false,
        },
        tankUid: 'TNK-A29F', tankAgeH: 5, tankHoldOk: true,
        orderId: ANCHOR_ORDER_IDS.noCoffee, orderNum: 'ORD-2250',
        machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub',
        paymentAmount: 60, upiRef: 'UPI 5142208',
        healthStrip: [
          { at: '11:32 AM', label: 'F-12 flow drift on YF-S401', level: 'warn' },
          { at: '11:42 AM', label: 'dispense raised · pulses=9', level: 'fault' },
          { at: '11:44 AM', label: 'cup removed · weight unchanged', level: 'warn' },
        ],
      },
    }),

    // ── clean sensor log — the reject path ──
    T({
      id: 'tkt-1041', num: 'TKT-1041', type: 'quality', typeLabel: 'Quality', channel: 'whatsapp',
      priority: 'P2', state: 'closed', customer: 'Sameer Verma', customerId: 'c4', phone: '+91 98117 60392',
      amount: 40, upiRef: 'UPI 5142189', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub',
      orderId: ANCHOR_ORDER_IDS.cleanReject, openedLabel: 'Yesterday · 5:02 PM', slaMin: 5, assignedTo: 'Arjun Khanna',
      message: 'Coffee not cold, it was barely warm, scam machine.',
      contextLine: 'Server-filled: cold mode never set on MCH-001 (hot machine) · customer ordered cappuccino',
      history: [
        { tsLabel: 'Yesterday · 5:02 PM', by: 'bot', text: 'ticket raised' },
        { tsLabel: 'Yesterday · 5:04 PM', by: 'Arjun Khanna', text: 'claimed — investigating' },
        { tsLabel: 'Yesterday · 5:20 PM', by: 'Arjun Khanna · support', text: 'rejected with proof — variance 2%, pickup detected, hot mode by design' },
        { tsLabel: 'Yesterday · 5:20 PM', by: 'bot', text: 'customer notified with sensor log snapshot' },
      ],
      verdict: 'reject',
      evidence: {
        clipUrl: 'supabase://video_clips/tkt-1041/dispute-30s.mp4', clipLenS: 30,
        dispense: {
          valveMs: 2140, pulses: 196, expectedMl: 180, actualMl: 176, variancePct: 2.2,
          cupDetected: true, kitDropped: true, malaiPumpMs: 620, conveyorSteps: 3,
          windowOpened: true, pickupDetected: true,
        },
        tankUid: 'TNK-A29D', tankAgeH: 27, tankHoldOk: false,
        orderId: ANCHOR_ORDER_IDS.cleanReject, orderNum: 'ORD-2265',
        machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub',
        paymentAmount: 40, upiRef: 'UPI 5142189',
        healthStrip: [
          { at: '16:44', label: 'F-03 4G drop · 6 min', level: 'warn' },
          { at: '17:16', label: 'dispense ok · variance 2.2%', level: 'info' },
          { at: '17:16', label: 'pickup detected · -74g', level: 'info' },
        ],
      },
    }),

    // ── cup stuck claim, investigating ──
    T({
      id: 'tkt-1040', num: 'TKT-1040', type: 'cup-stuck', typeLabel: 'Cup stuck', channel: 'whatsapp',
      priority: 'P2', state: 'investigating', customer: 'Dev Patel', customerId: 'c2', phone: '+91 90281 44190',
      amount: 40, upiRef: 'UPI 5142171', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane',
      orderId: ANCHOR_ORDER_IDS.pickupMissing, openedLabel: 'Today · 8:30 AM', slaMin: 5, assignedTo: 'Meera Sawant',
      message: 'Cup stuck in dispense window, had to pull it out half spilled.',
      contextLine: 'Server-filled: yesterday 4:44 PM · MCH-002 · pickup never detected · refund already queued',
      history: [
        { tsLabel: 'Today · 8:30 AM', by: 'whatsapp', text: 'ticket raised' },
        { tsLabel: 'Today · 8:34 AM', by: 'Meera Sawant', text: 'claimed — investigating' },
      ],
      evidence: {
        clipUrl: 'supabase://video_clips/tkt-1040/dispute-30s.mp4', clipLenS: 30,
        dispense: {
          valveMs: 2080, pulses: 21, expectedMl: 180, actualMl: 22, variancePct: 88,
          cupDetected: true, kitDropped: true, malaiPumpMs: 180, conveyorSteps: 2,
          windowOpened: true, pickupDetected: false,
        },
        tankUid: 'TNK-B100', tankAgeH: 20, tankHoldOk: true,
        orderId: ANCHOR_ORDER_IDS.pickupMissing, orderNum: 'ORD-2268',
        machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane',
        paymentAmount: 40, upiRef: 'UPI 5142171',
        healthStrip: [
          { at: '16:40', label: 'F-08 door latch intermittent', level: 'warn' },
          { at: '16:44', label: 'dispense raise · conveyor step 2/3', level: 'fault' },
          { at: '16:48', label: 'no pickup event within 30 min', level: 'fault' },
        ],
      },
    }),

    // ── unassigned P2 — the SLA countdown star ──
    T({
      id: 'tkt-1039', num: 'TKT-1039', type: 'payment-deducted', typeLabel: 'Payment deducted', channel: 'bot',
      priority: 'P2', state: 'open', customer: 'Ira Sharma', customerId: 'c12', phone: '+91 98903 21147',
      amount: 40, upiRef: 'UPI 5142201', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane',
      orderId: 'o-2254', openedLabel: 'Today · 11:12 AM', slaMin: 5, assignedTo: null,
      message: 'UPI failed after deducting money. Merchant not found on retry.',
      contextLine: 'Server-filled: webhook ok_duplicate · order pending state',
      history: [{ tsLabel: 'Today · 11:12 AM', by: 'bot', text: 'ticket raised' }],
    }),

    T({
      id: 'tkt-1038', num: 'TKT-1038', type: 'no-kit', typeLabel: 'No kit', channel: 'whatsapp',
      priority: 'P3', state: 'awaiting', customer: 'Gaurav Shetty', customerId: 'c11', phone: '+91 92461 70055',
      amount: 20, upiRef: 'UPI 5141902', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub',
      orderId: 'o-2242', openedLabel: 'Yesterday · 8:02 PM', slaMin: 5, assignedTo: 'Meera Sawant',
      message: 'Latte bina garnish ke milk pouch nahi aaya. Kit check kar.',
      contextLine: 'Server-filled: info requested 18h ago · awaiting customer reply',
      history: [
        { tsLabel: 'Yesterday · 8:02 PM', by: 'whatsapp', text: 'ticket raised' },
        { tsLabel: 'Yesterday · 8:20 PM', by: 'Meera Sawant', text: 'requested kit-drop photo' },
      ],
    }),

    T({
      id: 'tkt-1037', num: 'TKT-1037', type: 'no-coffee', typeLabel: 'No coffee', channel: 'bot',
      priority: 'P2', state: 'resolved-refund', customer: 'Ritika Sen', customerId: 'c3', phone: '+91 91234 09871',
      amount: 60, upiRef: 'UPI 5141990', machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub',
      orderId: 'o-2229', openedLabel: 'Yesterday · 1:14 PM', slaMin: 5, assignedTo: 'Nikhil Rao',
      message: 'Machine turanta band, paisa kaat gaya.',
      contextLine: 'Server-filled: refund paid out 1:20 PM (gateway)',
      verdict: 'refund',
      history: [
        { tsLabel: 'Yesterday · 1:14 PM', by: 'bot', text: 'ticket raised' },
        { tsLabel: 'Yesterday · 1:16 PM', by: 'Nikhil Rao', text: 'claimed' },
        { tsLabel: 'Yesterday · 1:20 PM', by: 'Nikhil Rao · finance', text: 'approved refund — camera + log agree' },
      ],
      evidence: {
        clipUrl: 'supabase://video_clips/tkt-1037/dispute-30s.mp4', clipLenS: 30,
        dispense: {
          valveMs: 0, pulses: 0, expectedMl: 180, actualMl: 0, variancePct: 100,
          cupDetected: true, kitDropped: false, malaiPumpMs: 0, conveyorSteps: 0,
          windowOpened: false, pickupDetected: false,
        },
        tankUid: 'TNK-A29D', tankAgeH: 30, tankHoldOk: false,
        orderId: 'o-2229', orderNum: 'ORD-2229',
        machineId: 'a1b2c3d4-0001-4000-8000-000000000001', machine: 'MCH-001 · Campus Hub',
        paymentAmount: 60, upiRef: 'UPI 5141990',
        healthStrip: [
          { at: '13:10', label: 'heater relay offline', level: 'fault' },
          { at: '13:14', label: 'boiler safety cut', level: 'fault' },
        ],
      },
    }),

    T({
      id: 'tkt-1036', num: 'TKT-1036', type: 'spill', typeLabel: 'Spill', channel: 'manual',
      priority: 'P4', state: 'open', customer: 'Tara Bose', customerId: 'c7', phone: '+91 93310 44720',
      amount: 0, upiRef: '—', machineId: 'a1b2c3d4-0002-4000-8000-000000000002', machine: 'MCH-002 · Mall Lane',
      orderId: 'o-2233', openedLabel: 'Yesterday · 7:30 PM', slaMin: 5, assignedTo: null,
      message: 'Short spill at the pickup shelf below. Cleaning may be needed.',
      contextLine: 'Server-filled: no order loss · housekeeping note',
      history: [{ tsLabel: 'Yesterday · 7:30 PM', by: 'front desk', text: 'logged manually — walk-in report' }],
    }),
  ];
}

export const REVIEW_SEED: Review[] = [
  { id: 'rv-1', tsLabel: 'Today · 10:20 AM', customer: 'Aisha Khan', machine: 'MCH-002 · Mall Lane', stars: 5, tags: ['fast', 'taste'], reply: null, flagged: false },
  { id: 'rv-2', tsLabel: 'Today · 9:40 AM', customer: 'Farhan Ali', machine: 'MCH-001 · Campus Hub', stars: 3, tags: ['strength'], reply: 'Thanks — blend recalibrated Fri.', flagged: false },
  { id: 'rv-3', tsLabel: 'Yesterday · 9:02 PM', customer: 'Anon (scan)', machine: 'MCH-002 · Mall Lane', stars: 1, tags: ['spill', 'stuck'], reply: null, flagged: true },
  { id: 'rv-4', tsLabel: 'Yesterday · 6:45 PM', customer: 'Vikas Rathod', machine: 'MCH-001 · Campus Hub', stars: 5, tags: ['velvet'], reply: null, flagged: false },
  { id: 'rv-5', tsLabel: 'Yesterday · 5:31 PM', customer: 'Tara Bose', machine: 'MCH-002 · Mall Lane', stars: 2, tags: ['dirty area'], reply: null, flagged: false },
  { id: 'rv-6', tsLabel: 'Wed · 1:12 PM', customer: 'Kunal Mishra', machine: 'MCH-001 · Campus Hub', stars: 4, tags: ['queue'], reply: null, flagged: false },
  { id: 'rv-7', tsLabel: 'Wed · 11:44 AM', customer: 'Ritika Sen', machine: 'MCH-001 · Campus Hub', stars: 5, tags: ['velvet', 'fast'], reply: null, flagged: false },
  { id: 'rv-12', tsLabel: 'Wed · 10:10 AM', customer: 'anon', machine: 'MCH-002 · Mall Lane', stars: 1, tags: ['payment'], reply: null, flagged: true },
  { id: 'rv-8', tsLabel: 'Tue · 8:52 PM', customer: 'Neha Joshi', machine: 'MCH-002 · Mall Lane', stars: 3, tags: ['slow'], reply: 'We pushed fw 2.4.1 — valve timing improved.', flagged: false },
  { id: 'rv-9', tsLabel: 'Tue · 2:34 PM', customer: 'Dev Patel', machine: 'MCH-002 · Mall Lane', stars: 4, tags: ['cold'], reply: null, flagged: false },
];

export const BLACKLIST_SEED: BlacklistEntry[] = [
  { id: 'bl-1', kind: 'device', value: 'ANDROID·74:2f:11:a2', severity: 'high', addedLabel: '2 Nov', expiresLabel: '30 days', reason: 'same device × 5 self-referral attempts', by: 'Chief Rohan' },
  { id: 'bl-2', kind: 'phone', value: '+91 81712 99023', severity: 'med', addedLabel: '28 Oct', expiresLabel: '7 days', reason: 'order-fraud pattern · 3 abandoned pickup claims', by: 'Chief Rohan' },
  { id: 'bl-3', kind: 'utr', value: 'UPI 5142117', severity: 'low', addedLabel: '24 Oct', expiresLabel: '21 days', reason: 'duplicate webhook replay attempt', by: 'Nikhil Rao' },
  { id: 'bl-4', kind: 'ip', value: '103.21.*.*', severity: 'low', addedLabel: '20 Oct', expiresLabel: '14 days', reason: 'API throttled — scraping attempt', by: 'Chief Rohan' },
];

export const MACROS: Macro[] = [
  { id: 'ma-1', type: 'no-coffee', body: 'Hey {{name}} — sensor log pe dispense ke waqt {{variance}} variance dikha hai. Follow-ups ke sath sip info bhej rahe hain.', placeholders: '{{name}}, {{variance}}', lang: 'en · bot', updatedLabel: 'Yesterday', active: true },
  { id: 'ma-2', type: 'no-coffee', body: 'नमस्ते {{name}} — देखा कि डिस्पेंस समय वेरिएंस {{variance}} था। हम जाँच में हैं।', placeholders: '{{name}}, {{variance}}', lang: 'hi · bot', updatedLabel: 'Yesterday', active: true },
  { id: 'ma-3', type: 'payment-deducted', body: '{{name}}, आपका refund {{orderId}} के लिए प्रोसेसिंग में है — wallet में देखें।', placeholders: '{{name}}, {{orderId}}', lang: 'hi · bot', updatedLabel: '20 Oct', active: true },
  { id: 'ma-4', type: 'quality', body: 'स्वाद की feedback के लिए धन्यवाद — हमने node का blend recalibrate कर दिया है।', placeholders: '—', lang: 'hi · bot', updatedLabel: '18 Oct', active: true },
  { id: 'ma-5', type: 'no-kit', body: 'Kit ड्रॉप की स्थिति देख रहे हैं — कृपया फोटो भेजें।', placeholders: '—', lang: 'hi · bot', updatedLabel: '15 Oct', active: false },
];
