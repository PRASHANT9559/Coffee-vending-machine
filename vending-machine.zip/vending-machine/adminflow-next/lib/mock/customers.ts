import type { Customer, LedgerTxn, QrIssued, QrEvent } from './types';

/* ─────────────────────────────────────────────────────────────
   Customers — 12 deterministic profiles. One customer per
   story row in orders (c1 = Priya Nair, o-2250 = her dispute).
   ───────────────────────────────────────────────────────────── */

export const CUSTOMERS: Customer[] = [
  {
    id: 'c1', name: 'Priya Nair', phone: '+91 90045 12877', city: 'Pune', college: 'Symbiosis · SCIT',
    ageBand: '21-24', joinedLabel: 'Aug 2026', orders: 41, spend: 1640, lastOrderLabel: 'Today · 11:42 AM',
    wallet: 120, coins: 340, streak: { cur: 4, longest: 7 }, segments: ['Active today', 'High value'],
    repeatRatePct: 74, favourite: 'Manhattan Velvet Cappuccino',
    consents: { leaderboard: true, handle: true, avatar: true, updatedAt: 'Sep 2026' },
    badges: [{ name: '7-day streak', pinned: true }, { name: 'First 100', pinned: false }],
    leaderboard: { rank: 3, score: 842, period: 'This week' },
    referrals: { invited: 6, qualified: 4, paid: 80 },
    gifts: { sent: 3, received: 1 },
    tickets: [
      { id: 'tkt-1042', num: 'TKT-1042', subject: 'No coffee — payment deducted', atLabel: 'Today · 11:51 AM', verdict: '—' },
      { id: 'tkt-1009', num: 'TKT-1009', subject: 'Frappe too sweet', atLabel: '18 Sep', verdict: 'resolved · macro reply' },
    ],
    anonymous: false,
  },
  {
    id: 'c2', name: 'Dev Patel', phone: '+91 90281 44190', city: 'Pune', college: 'COEP',
    ageBand: '21-24', joinedLabel: 'Jul 2026', orders: 28, spend: 980, lastOrderLabel: 'Yesterday · 4:44 PM',
    wallet: 60, coins: 120, streak: { cur: 2, longest: 5 },
    segments: ['Active this week', 'Referral source'],
    repeatRatePct: 61, favourite: 'Classic Café Latte',
    consents: { leaderboard: false, handle: false, avatar: true, updatedAt: 'Aug 2026' },
    badges: [{ name: 'Wallet top-up x5', pinned: false }],
    leaderboard: { rank: 0, score: 0, period: 'opted out' },
    referrals: { invited: 9, qualified: 5, paid: 100 },
    gifts: { sent: 0, received: 2 },
    tickets: [{ id: 'tkt-1040', num: 'TKT-1040', subject: 'Cup stuck in window', atLabel: 'Today · 8:30 AM', verdict: '—' }],
    anonymous: false,
  },
  {
    id: 'c3', name: 'Ritika Sen', phone: '+91 91234 09871', city: 'Pune', college: 'MIT · Kothrud',
    ageBand: '25-30', joinedLabel: 'Jun 2026', orders: 63, spend: 2610, lastOrderLabel: 'Yesterday · 1:21 PM',
    wallet: 210, coins: 890, streak: { cur: 9, longest: 12 }, segments: ['High value', 'Active today'],
    repeatRatePct: 82, favourite: 'Manhattan Velvet Cappuccino',
    consents: { leaderboard: true, handle: true, avatar: true, updatedAt: 'Jul 2026' },
    badges: [{ name: '12-day streak', pinned: true }, { name: 'Manhattan loyalist', pinned: true }],
    leaderboard: { rank: 1, score: 1160, period: 'This week' },
    referrals: { invited: 3, qualified: 2, paid: 40 },
    gifts: { sent: 6, received: 4 },
    tickets: [],
    anonymous: false,
  },
  {
    id: 'c4', name: 'Sameer Verma', phone: '+91 98117 60392', city: 'Pune', college: 'Symbiosis · SCM',
    ageBand: '21-24', joinedLabel: 'Sep 2026', orders: 14, spend: 460, lastOrderLabel: 'Mon · 3:10 PM',
    wallet: 0, coins: 40, streak: { cur: 0, longest: 3 }, segments: ['Lapsed 7d'],
    repeatRatePct: 24, favourite: 'Grande Roast',
    consents: { leaderboard: false, handle: false, avatar: false, updatedAt: 'Sep 2026' },
    badges: [], leaderboard: { rank: 0, score: 0, period: 'opted out' },
    referrals: { invited: 0, qualified: 0, paid: 0 }, gifts: { sent: 0, received: 0 },
    tickets: [{ id: 'tkt-1041', num: 'TKT-1041', subject: 'Coffee not cold', atLabel: 'Yesterday · 5:20 PM', verdict: 'rejected with proof' }],
    anonymous: false,
  },
  { id: 'c5', name: 'Aisha Khan', phone: '+91 98999 22010', city: 'Pune', college: 'FLAME University', ageBand: '21-24', joinedLabel: 'Aug 2026', orders: 22, spend: 880, lastOrderLabel: 'Yesterday · 1:21 PM', wallet: 35, coins: 210, streak: { cur: 3, longest: 6 }, segments: ['Active today'], repeatRatePct: 55, favourite: 'Chilled Manhattan Frappe', consents: { leaderboard: true, handle: false, avatar: true, updatedAt: 'Aug 2026' }, badges: [], leaderboard: { rank: 5, score: 610, period: 'This week' }, referrals: { invited: 2, qualified: 1, paid: 20 }, gifts: { sent: 1, received: 1 }, tickets: [], anonymous: false },
  { id: 'c6', name: 'Vikas Rathod', phone: '+91 97643 88120', city: 'Pimpri', college: 'DY Patil', ageBand: '25-30', joinedLabel: 'May 2026', orders: 37, spend: 1490, lastOrderLabel: 'Yesterday · 8:44 PM', wallet: 95, coins: 460, streak: { cur: 5, longest: 9 }, segments: ['High value'], repeatRatePct: 68, favourite: 'Manhattan Velvet Cappuccino', consents: { leaderboard: true, handle: true, avatar: true, updatedAt: 'Jun 2026' }, badges: [{ name: 'Top inviter', pinned: true }], leaderboard: { rank: 2, score: 905, period: 'This week' }, referrals: { invited: 14, qualified: 8, paid: 160 }, gifts: { sent: 2, received: 3 }, tickets: [], anonymous: false },
  { id: 'c7', name: 'Tara Bose', phone: '+91 93310 44720', city: 'Pune', college: 'SPPU', ageBand: '18-21', joinedLabel: 'Sep 2026', orders: 11, spend: 300, lastOrderLabel: 'Mon · 7:02 PM', wallet: 40, coins: 60, streak: { cur: 1, longest: 4 }, segments: ['Lapsed 7d'], repeatRatePct: 33, favourite: 'Classic Café Latte', consents: { leaderboard: true, handle: true, avatar: false, updatedAt: 'Sep 2026' }, badges: [], leaderboard: { rank: 22, score: 180, period: 'This week' }, referrals: { invited: 0, qualified: 0, paid: 0 }, gifts: { sent: 0, received: 1 }, tickets: [], anonymous: false },
  { id: 'c8', name: 'Kunal Mishra', phone: '+91 91670 55308', city: 'Pune', college: 'VIT', ageBand: '21-24', joinedLabel: 'Jul 2026', orders: 31, spend: 1240, lastOrderLabel: 'Today · 8:02 AM', wallet: 75, coins: 300, streak: { cur: 6, longest: 6 }, segments: ['Active today', 'Coin earner'], repeatRatePct: 71, favourite: 'Grande Roast', consents: { leaderboard: true, handle: true, avatar: true, updatedAt: 'Jul 2026' }, badges: [{ name: 'Ad-friend (50 views)', pinned: false }], leaderboard: { rank: 6, score: 580, period: 'This week' }, referrals: { invited: 1, qualified: 1, paid: 20 }, gifts: { sent: 0, received: 0 }, tickets: [], anonymous: false },
  { id: 'c9', name: 'Neha Joshi', phone: '+91 90290 99017', city: 'Pune', college: 'Indira College', ageBand: '21-24', joinedLabel: 'Aug 2026', orders: 19, spend: 760, lastOrderLabel: 'Today · 9:12 AM', wallet: 20, coins: 90, streak: { cur: 2, longest: 3 }, segments: ['Active today'], repeatRatePct: 47, favourite: 'Chilled Manhattan Frappe', consents: { leaderboard: false, handle: false, avatar: true, updatedAt: 'Aug 2026' }, badges: [], leaderboard: { rank: 0, score: 0, period: 'opted out' }, referrals: { invited: 0, qualified: 0, paid: 0 }, gifts: { sent: 1, received: 0 }, tickets: [], anonymous: false },
  { id: 'c10', name: 'Farhan Ali', phone: '+91 97112 33680', city: 'Pune', college: 'DY Patil', ageBand: '25-30', joinedLabel: 'Jun 2026', orders: 26, spend: 1060, lastOrderLabel: 'Yesterday · 9:58 PM', wallet: 10, coins: 540, streak: { cur: 3, longest: 8 }, segments: ['Coin earner'], repeatRatePct: 58, favourite: 'Manhattan Velvet Cappuccino', consents: { leaderboard: true, handle: true, avatar: true, updatedAt: 'Jun 2026' }, badges: [{ name: 'Late-night cup', pinned: true }], leaderboard: { rank: 8, score: 520, period: 'This week' }, referrals: { invited: 0, qualified: 0, paid: 0 }, gifts: { sent: 0, received: 0 }, tickets: [], anonymous: false },
  { id: 'c11', name: 'Gaurav Shetty', phone: '+91 92461 70055', city: 'Pune', college: 'Symbiosis · SCIT', ageBand: '21-24', joinedLabel: 'Sep 2026', orders: 9, spend: 360, lastOrderLabel: 'Mon · 10:02 AM', wallet: 0, coins: 30, streak: { cur: 0, longest: 2 }, segments: ['Lapsed 30d'], repeatRatePct: 18, favourite: 'Classic Café Latte', consents: { leaderboard: true, handle: false, avatar: false, updatedAt: 'Sep 2026' }, badges: [], leaderboard: { rank: 41, score: 90, period: 'This week' }, referrals: { invited: 0, qualified: 0, paid: 0 }, gifts: { sent: 0, received: 0 }, tickets: [], anonymous: false },
  { id: 'c12', name: 'Ira Sharma', phone: '+91 98903 21147', city: 'Pune', college: 'MIT · Kothrud', ageBand: '18-21', joinedLabel: 'Oct 2026', orders: 7, spend: 280, lastOrderLabel: 'Yesterday · 7:56 PM', wallet: 50, coins: 20, streak: { cur: 1, longest: 1 }, segments: ['Active this week'], repeatRatePct: 21, favourite: 'Chilled Manhattan Frappe', consents: { leaderboard: true, handle: true, avatar: true, updatedAt: 'Oct 2026' }, badges: [], leaderboard: { rank: 17, score: 240, period: 'This week' }, referrals: { invited: 0, qualified: 0, paid: 0 }, gifts: { sent: 0, received: 2 }, tickets: [], anonymous: false },
];

export const CUSTOMERS_LIST = CUSTOMERS;

export function getCustomer(id: string): Customer | undefined {
  return CUSTOMERS.find(c => c.id === id);
}

/** list-level honesty metric (routing spec: "% anonymous") */
export function anonymousPct(): number {
  // 5 of the 36 seeded orders redeemed anonymously
  return 14;
}

/* wallet ledger — c1 & c2 get full seeded histories */
export const LEDGER_SEED: Record<string, LedgerTxn[]> = {
  c1: [
    { id: 'w-1', tsLabel: 'Today · 11:42 AM', kind: 'order', amount: -60, balanceAfter: 120, note: 'Manhattan Velvet · ORD-2250' },
    { id: 'w-2', tsLabel: 'Yesterday · 6:02 PM', kind: 'recharge', amount: 200, balanceAfter: 180, note: 'UPI · ref 5142208' },
    { id: 'w-3', tsLabel: 'Yesterday · 6:44 PM', kind: 'order', amount: -60, balanceAfter: -20, note: 'Manhattan Velvet · ORD-2265' },
    { id: 'w-4', tsLabel: 'Yesterday · 5:10 PM', kind: 'manual-credit', amount: 20, balanceAfter: 40, note: 'goodwill — flow meter drift' },
    { id: 'w-5', tsLabel: 'Sun · 7:12 PM', kind: 'coin', amount: 0, balanceAfter: 20, note: '+40 coins · ad view ×2' },
    { id: 'w-6', tsLabel: 'Sun · 2:33 PM', kind: 'order', amount: -40, balanceAfter: 20, note: 'Manhattan Velvet · ORD-2247' },
  ],
  c2: [
    { id: 'w-11', tsLabel: 'Yesterday · 4:44 PM', kind: 'refund', amount: 40, balanceAfter: 60, note: 'refund queued — ORD-2268' },
    { id: 'w-12', tsLabel: 'Yesterday · 1:20 PM', kind: 'recharge', amount: 100, balanceAfter: 20, note: 'UPI · ref 5142160' },
    { id: 'w-13', tsLabel: 'Yesterday · 12:44 PM', kind: 'order', amount: -80, balanceAfter: -60, note: '×2 Manhattan Velvet' },
  ],
};

/* QR history — c1 */
export const QR_SEED: Record<string, QrIssued[]> = {
  c1: [
    { code: 'MC55182073-61', source: 'buy', issuedLabel: 'Today · 11:42 AM', expiryLabel: 'Expired 11:52 AM', shares: 0, state: 'redeemed', redeemedLabel: 'Today · 11:42 AM' },
    { code: 'MC55127118-6b', source: 'referral', issuedLabel: 'Yesterday · 9:30 PM', expiryLabel: 'Valid 48h', shares: 2, state: 'unredeemed', redeemedLabel: null },
    { code: 'MC55109133-42', source: 'ad', issuedLabel: 'Yesterday · 9:02 PM', expiryLabel: 'Expired', shares: 1, state: 'redeemed', redeemedLabel: 'Yesterday · 9:10 PM' },
    { code: 'MC55088610-1d', source: 'gift', issuedLabel: 'Sat · 6:10 PM', expiryLabel: 'Expired', shares: 3, state: 'expired', redeemedLabel: null },
    { code: 'MC55023177-59', source: 'buy', issuedLabel: 'Fri · 8:20 PM', expiryLabel: 'Revoked', shares: 0, state: 'revoked', redeemedLabel: null },
  ],
};

export const QR_EVENTS: Record<string, QrEvent[]> = {
  'MC55182073-61': [
    { tsLabel: 'Today · 11:42 AM', event: 'created', by: 'panel · order server' },
    { tsLabel: 'Today · 11:42 AM', event: 'scanned', by: 'MCH-001 scanner' },
    { tsLabel: 'Today · 11:42 AM', event: 'authorised', by: 'rust · HMAC ok' },
    { tsLabel: 'Today · 11:42 AM', event: 'redeemed', by: 'MCH-001 · dispense' },
  ],
  'MC55127118-6b': [
    { tsLabel: 'Yesterday · 9:30 PM', event: 'created', by: 'panel · referral' },
    { tsLabel: 'Yesterday · 10:11 PM', event: 'shared', by: 'WhatsApp share' },
  ],
};
