/* ─────────────────────────────────────────────────────────────
   Panel-wide mock data contracts. Money values are ₹ INTEGERS
   (the panel format, paise only where the schema forced it).
   All labels are deterministic strings — no clock drift between
   server and client renders.
   ───────────────────────────────────────────────────────────── */

// ── shared primitive bits ────────────────────────────────────
export type Chip = { text: string; tone: 'leaf' | 'brand' | 'amber' | 'blue' | 'ink' | 'red' };
export type Cell =
  | string
  | number
  | { t: 'chip'; v: string; tone: Chip['tone'] }
  | { t: 'link'; v: string; href: string }
  | { t: 'money'; v: number }
  | { t: 'flag' }
  | { t: 'void' };

export interface AuditEntry {
  id: string;
  at: string;
  who: string;
  role: string;
  action: string;
  target?: string;
  detail?: string;
  kind: 'action' | 'denied';
  before?: string;
  after?: string;
}

// ── machines ─────────────────────────────────────────────────
export interface MachineFault { code: string; label: string; atLabel: string; critical: boolean; resolved: boolean }

export interface Machine {
  id: string;
  code: string;
  name: string;
  city: string;
  venue: string;
  online: boolean;
  live: boolean;
  mode: 'hot' | 'cold' | 'off';
  tempC: number;
  targetTemp: number;
  litres: number;
  malaiL: number;
  cups: number;
  kits: number;
  locked: boolean;
  signalDbm: number;
  lastSeenLabel: string;
  lastSeenMin: number;
  firmware: string;
  fwSha: string;
  bootCount: number;
  wdtResets: number;
  sensors: { name: string; ok: boolean; note: string }[];
  faults: MachineFault[];
  reorder: { cups: number; kits: number; malai: number };
}

export interface TankRow {
  id: string;
  uid: string;
  machineId: string;
  machine: string;
  litres: number;
  filledLabel: string;
  ageH: number;
  holdH: number;
  state: 'active' | 'near' | 'expired' | 'disposed';
  disposeReason?: string;
  fssai: boolean;
}

export interface TankEvent { tsLabel: string; machine: string; action: 'mounted' | 'top-up' | 'disposed'; detail: string; by: string }

export interface StockRow {
  machineId: string;
  variant: string;
  kind: 'kits' | 'cups' | 'malai';
  qty: number;
  unit: string;
  threshold: number;
  lastRefillLabel: string;
}

export interface StockEvent { tsLabel: string; machine: string; variant: string; qty: number; kind: 'refill' | 'waste' | 'adjust'; by: string; note: string }

export interface MachineCommand {
  id: string;
  machineId: string;
  cmd: string;
  status: 'queued' | 'sent' | 'done' | 'expired' | 'failed';
  ttlS: number;
  by: string;
  atLabel: string;
  result?: string;
}

export interface MaintenanceLog { tsLabel: string; machine: string; task: string; tech: string; mins: number; notes: string }

export interface CameraChannel {
  machineId: string;
  channel: 1 | 2;
  label: string;
  sdFreePct: number;
  retentionDays: number;
  lastFrameSec: number;
}


// ── orders & QR ──────────────────────────────────────────────
export interface DispenseLog {
  valveMs: number;
  pulses: number;
  expectedMl: number;
  actualMl: number;
  variancePct: number;
  cupDetected: boolean;
  kitDropped: boolean;
  malaiPumpMs: number;
  conveyorSteps: number;
  windowOpened: boolean;
  pickupDetected: boolean;
}

export interface QrEvent { tsLabel: string; event: 'created' | 'shared' | 'scanned' | 'authorised' | 'redeemed'; by: string }

export interface Order {
  id: string;
  num: string;
  tsLabel: string;
  machineId: string;
  machine: string;
  variant: string;
  variantShort: string;
  amount: number;
  finalAmount: number;
  discount: number;
  costBasis: number;
  payment: 'upi' | 'wallet' | 'coins';
  status: 'completed' | 'preparing' | 'pending' | 'cancelled' | 'refunded';
  flagged: boolean;
  customerId: string | null;
  customerName: string | null;
  code: { value: string; source: 'buy' | 'ad' | 'referral' | 'gift'; issuedLabel: string; expiryLabel: string; shared: number; redeemed: boolean; redeemedLabel: string | null };
  dispense: DispenseLog | null;
  tankUid: string | null;
  tankAgeH: number | null;
  healthNotes: string | null;
}

// ── customers ────────────────────────────────────────────────
export interface LedgerTxn {
  id: string;
  tsLabel: string;
  kind: 'recharge' | 'order' | 'refund' | 'manual-credit' | 'manual-debit' | 'coin';
  amount: number;             // signed ₹
  balanceAfter: number;
  note: string;
}

export interface QrIssued {
  code: string;
  source: 'buy' | 'ad' | 'referral' | 'gift';
  issuedLabel: string;
  expiryLabel: string;
  shares: number;
  state: 'redeemed' | 'unredeemed' | 'expired' | 'revoked';
  redeemedLabel: string | null;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  city: string;
  college: string;
  ageBand: string;
  joinedLabel: string;
  orders: number;
  spend: number;
  lastOrderLabel: string;
  wallet: number;
  coins: number;
  streak: { cur: number; longest: number };
  segments: string[];
  repeatRatePct: number;
  favourite: string;
  consents: { leaderboard: boolean; handle: boolean; avatar: boolean; updatedAt: string };
  badges: { name: string; pinned: boolean }[];
  leaderboard: { rank: number; score: number; period: string };
  referrals: { invited: number; qualified: number; paid: number };
  gifts: { sent: number; received: number };
  tickets: { id: string; num: string; subject: string; atLabel: string; verdict: string }[];
  anonymous: boolean;
}

// ── inventory ────────────────────────────────────────────────
export interface SupplyItem { id: string; name: string; unit: string; onHand: number; unitCost: number; servingsPerUnit: number; reorder: number }

export interface KitTemplate { name: string; emoji: string; components: { item: string; qty: string }[] }

export interface WasteRow { id: string; tsLabel: string; machine: string; kind: 'expired-tank' | 'clog' | 'damaged-cup' | 'over-pour'; qty: string; loss: number; note: string }

// ── analytics ────────────────────────────────────────────────
export interface SalesPoint { label: string; revenue: number; orders: number }
export interface TierMixPoint { label: string; t10: number; t20: number; t40: number; t60: number }
export interface ProductStat { variant: string; emoji: string; orders: number; revenue: number; costPerServing: number; marginPct: number; rank: number; note: string }
export interface MachineCompare { machineId: string; machine: string; city: string; uptimePct: number; cupsDay: number; revenue: number; failures: number; mttrH: number }
export interface ProfitPoint { label: string; value: number; kind: 'cash' | 'earned' | 'cost' }

// ── marketing ────────────────────────────────────────────────
export interface Offer {
  id: string; name: string;
  kind: 'flat' | 'percent' | 'free-item' | 'wallet-bonus';
  valueLabel: string; minOrder: number; segment: string;
  budget: number; spent: number;
  windowLabel: string;
  state: 'running' | 'paused' | 'ended';
  uses: number;
}
export interface Coupon { id: string; code: string; kind: string; valueLabel: string; perUserLimit: number; used: number; total: number; expiryLabel: string; state: 'active' | 'paused' }
export interface Banner { id: string; slot: string; name: string; windowLabel: string; priority: number; impressions: number; clicks: number; active: boolean }
export interface PushMsg { id: string; title: string; body: string; segment: string; deepLink: string; atLabel: string; delivered: number; opened: number; state: 'sent' | 'scheduled' | 'cancelled' }
export interface Festival { id: string; name: string; windowLabel: string; state: 'live' | 'upcoming' | 'past'; pack: { offer: string; banner: string; push: string } }
export interface LeaderRow { name: string; invites: number; qualified: number; gain: number }
export interface FraudPair { inviter: string; invitee: string; device: string; atLabel: string }
export interface AdNetwork { id: string; name: string; ecpm: number; impressions: number; rewarded: number; revenue: number; coinsPerView: number; state: 'connected' | 'attention' | 'paused' }
export interface PostbackRow { id: string; user: string; claimedLabel: string; amount: number; state: 'pending' | 'demoted'; reason: string }
export interface AdSpace {
  id: string; machineId: string; machine: string;
  surface: 'side-panel' | 'fascia' | 'display' | 'cup-print';
  advertiser: string; months: number; ratePerMonth: number;
  startLabel: string; endLabel: string;
  invoiceNo: string; state: 'paid' | 'unpaid' | 'overdue';
}

// ── support ──────────────────────────────────────────────────
export interface TicketEvent { tsLabel: string; by: string; text: string }

export interface Evidence {
  clipUrl: string;             // signed playback stub
  clipLenS: number;
  dispense: DispenseLog;
  tankUid: string;
  tankAgeH: number;
  tankHoldOk: boolean;
  orderId: string;
  orderNum: string;
  machineId: string;
  machine: string;
  paymentAmount: number;
  upiRef: string;
  healthStrip: { at: string; label: string; level: 'info' | 'warn' | 'fault' }[];
}

export interface Ticket {
  id: string;
  num: string;
  type: 'no-coffee' | 'payment-deducted' | 'quality' | 'cup-stuck' | 'no-kit' | 'spill' | 'other';
  typeLabel: string;
  channel: 'bot' | 'whatsapp' | 'manual';
  priority: 'P1' | 'P2' | 'P3' | 'P4';
  state: 'open' | 'investigating' | 'awaiting' | 'resolved-refund' | 'resolved-reject' | 'closed';
  customer: string;
  customerId: string;
  phone: string;
  amount: number;
  upiRef: string;
  machineId: string;
  machine: string;
  orderId: string;
  openedLabel: string;
  slaMin: number;
  assignedTo: string | null;
  message: string;
  contextLine: string;
  history: TicketEvent[];
  verdict?: string;
  evidence?: Evidence;
}

export interface RefundRow {
  id: string; orderId: string; orderNum: string; customer: string;
  amount: number; destination: 'gateway' | 'wallet';
  requestedBy: string; atLabel: string;
  state: 'pending' | 'approved' | 'rejected' | 'paid';
  reason: string;
}

export interface Review { id: string; tsLabel: string; customer: string; machine: string; stars: number; tags: string[]; reply: string | null; flagged: boolean }
export interface BlacklistEntry { id: string; kind: 'user' | 'phone' | 'utr' | 'device' | 'ip'; value: string; severity: 'low' | 'med' | 'high'; addedLabel: string; expiresLabel: string; reason: string; by: string }
export interface Macro { id: string; type: string; body: string; placeholders: string; lang: string; updatedLabel: string; active: boolean }

// ── settings ─────────────────────────────────────────────────
export interface AlertRule { id: string; trigger: string; threshold: string; channel: 'in-app' | 'whatsapp' | 'sms'; recipient: string; active: boolean }
export interface IntegrationRow { id: string; name: string; desc: string; state: 'connected' | 'attention' | 'off'; lastCheck: string }
export interface WebhookEvent { tsLabel: string; event: string; status: 'ok' | 'failed'; code: string }
export interface InvoiceRow { id: string; dateLabel: string; amount: number; state: 'paid' | 'due' }
export interface UsageLine { name: string; used: number; cap: number; unit: string }
