/**
 * Server-side live data layer.
 *
 * Every function calls the Rust Axum service (which owns the PostgreSQL
 * connection) and maps the response into the shapes the existing admin
 * components already render. Mock data is returned ONLY when
 * `DEMO_MODE=1` and `NODE_ENV !== 'production'`. Otherwise an empty result is
 * returned so the UI can show an honest "no data" state instead of fake rows.
 */

import { backendApi } from './backend-client';
import { MACHINES, STOCK, fleetLowStock } from './mock/fleet';
import { listOrders as mockOrders } from './mock/store';
import { seedTickets } from './mock/support';
import { CUSTOMERS } from './mock/customers';
import type { Machine, Order, Ticket, Customer, StockRow } from './mock/types';

export function isDemoMode(): boolean {
  return process.env.DEMO_MODE === '1' && process.env.NODE_ENV !== 'production';
}

function iso(value: unknown): string | null {
  return typeof value === 'string' ? value : null;
}

function label(value: unknown): string {
  const s = iso(value);
  if (!s) return '—';
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('en-IN', {
    day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit',
  });
}

function minutesAgo(value: unknown): number {
  const s = iso(value);
  if (!s) return Number.MAX_SAFE_INTEGER;
  const ms = Date.now() - new Date(s).getTime();
  return Math.max(0, Math.round(ms / 60_000));
}

function paiseToRupees(value: unknown): number {
  const n = typeof value === 'number' ? value : Number(value ?? 0);
  return Number.isFinite(n) ? Math.round(n / 100) : 0;
}

/* ── machines ───────────────────────────────────────────────── */

function toMachine(row: any): Machine {
  const lastSeen = row.last_seen_at ?? row.last_ping_at ?? null;
  return {
    id: row.id,
    code: row.machine_code ?? '—',
    name: row.name ?? '—',
    city: row.city ?? '—',
    venue: row.address_line ?? row.locality ?? '—',
    online: row.status === 'active',
    live: minutesAgo(lastSeen) < 2,
    mode: row.mode === 'cold' ? 'cold' : row.mode === 'off' ? 'off' : 'hot',
    tempC: Number(row.milk_temp_c ?? row.target_temp_c ?? 0),
    targetTemp: Number(row.target_temp_c ?? 0),
    litres: Number(row.milk_level_l ?? 0),
    malaiL: 0,
    cups: Number(row.cup_stack_count ?? 0),
    kits: 0,
    locked: Boolean(row.is_locked),
    signalDbm: Number(row.signal_dbm ?? 0),
    lastSeenLabel: label(lastSeen),
    lastSeenMin: minutesAgo(lastSeen),
    firmware: row.firmware_version ?? '—',
    fwSha: '—',
    bootCount: 0,
    wdtResets: 0,
    sensors: [],
    faults: [],
    reorder: { cups: 0, kits: 0, malai: 0 },
  };
}

export async function getMachines(): Promise<Machine[]> {
  const res = await backendApi.listMachines();
  if (res.success && Array.isArray(res.data?.machines)) {
    return (res.data.machines as any[]).map(toMachine);
  }
  if (isDemoMode()) return MACHINES;
  return [];
}

export interface MachineDetail {
  machine: Machine;
  raw: any;
  tanks: any[];
  telemetry: any[];
}

export async function getMachine(id: string): Promise<MachineDetail | null> {
  const res = await backendApi.getMachine(id);
  if (res.success && res.data?.machine) {
    return {
      machine: toMachine(res.data.machine),
      raw: res.data.machine,
      tanks: Array.isArray(res.data.tanks) ? res.data.tanks : [],
      telemetry: Array.isArray(res.data.recent_telemetry) ? res.data.recent_telemetry : [],
    };
  }
  if (isDemoMode()) {
    const m = MACHINES.find(x => x.id === id);
    if (m) return { machine: m, raw: {}, tanks: [], telemetry: [] };
  }
  return null;
}

export async function getLowStock() {
  const res = await backendApi.liveInventory();
  if (res.success && Array.isArray(res.data?.stock)) {
    return (res.data.stock as any[])
      .filter(s => Number(s.quantity) <= Number(s.reorder_threshold))
      .map(s => ({
        machineId: s.machine_id,
        machine: `${s.machine_code} · ${s.machine_name}`,
        variant: `${s.item_type}${s.variant_key && s.variant_key !== 'default' ? ` (${s.variant_key})` : ''}`,
        qty: Number(s.quantity ?? 0),
        threshold: Number(s.reorder_threshold ?? 0),
      }));
  }
  if (isDemoMode()) return fleetLowStock();
  return [];
}

/* ── orders ─────────────────────────────────────────────────── */

function toOrder(row: any): Order {
  const status =
    row.status === 'delivered' ? 'completed'
    : row.status === 'refunded' ? 'refunded'
    : row.status === 'failed' || row.status === 'cancelled' || row.status === 'expired' ? 'cancelled'
    : row.status === 'dispensing' ? 'preparing'
    : 'pending';

  const payment = String(row.payment_method ?? '').toLowerCase();
  const source = row.code_source === 'purchase' ? 'buy'
    : row.code_source === 'ad' ? 'ad'
    : row.code_source === 'referral' ? 'referral'
    : row.code_source === 'gift' ? 'gift'
    : 'buy';

  return {
    id: row.id,
    num: row.order_no ?? '—',
    tsLabel: label(row.ordered_at),
    machineId: row.machine_id,
    machine: `${row.machine_code ?? '—'} · ${row.machine_name ?? '—'}`,
    variant: row.product_name ?? '—',
    variantShort: row.product_short ?? row.product_name ?? '—',
    amount: paiseToRupees(row.amount_paise),
    finalAmount: paiseToRupees(row.final_paise),
    discount: paiseToRupees(row.discount_paise),
    costBasis: paiseToRupees(row.cost_basis_paise),
    payment: payment === 'wallet' ? 'wallet' : payment === 'coins' ? 'coins' : 'upi',
    status,
    flagged: row.status === 'failed',
    customerId: row.user_id ?? null,
    customerName: row.user_phone ?? null,
    code: {
      value: row.code_value ?? '—',
      source,
      issuedLabel: label(row.code_issued_at),
      expiryLabel: label(row.code_expires_at),
      shared: Number(row.code_shared ?? 0),
      redeemed: Boolean(row.code_redeemed),
      redeemedLabel: row.code_redeemed ? label(row.ordered_at) : null,
    },
    dispense: row.dispensed_ml == null ? null : {
      valveMs: 0,
      pulses: 0,
      expectedMl: Number(row.expected_ml ?? 0),
      actualMl: Number(row.dispensed_ml ?? 0),
      variancePct: Number(row.variance_pct ?? 0),
      cupDetected: Boolean(row.cup_detected),
      kitDropped: Boolean(row.kit_dropped),
      malaiPumpMs: 0,
      conveyorSteps: 0,
      windowOpened: false,
      pickupDetected: false,
    },
    tankUid: null,
    tankAgeH: null,
    healthNotes: null,
  };
}

export async function getOrders(): Promise<Order[]> {
  const res = await backendApi.liveOrders();
  if (res.success && Array.isArray(res.data?.orders)) {
    return (res.data.orders as any[]).map(toOrder);
  }
  if (isDemoMode()) return mockOrders();
  return [];
}

export async function getOrderById(id: string): Promise<Order | null> {
  const res = await backendApi.liveOrders();
  if (res.success && Array.isArray(res.data?.orders)) {
    const row = (res.data.orders as any[]).find(o => o.id === id);
    if (row) return toOrder(row);
  }
  if (isDemoMode()) return mockOrders().find(o => o.id === id) ?? null;
  return null;
}

/* ── support tickets ────────────────────────────────────────── */

const TICKET_TYPES: Record<string, { type: Ticket['type']; label: string }> = {
  no_coffee: { type: 'no-coffee', label: 'No coffee' },
  quality: { type: 'quality', label: 'Quality' },
  cup_stuck: { type: 'cup-stuck', label: 'Cup stuck' },
  payment_deducted: { type: 'payment-deducted', label: 'Payment deducted' },
  no_kit: { type: 'no-kit', label: 'No kit' },
  spill: { type: 'spill', label: 'Spill' },
};

function toTicket(row: any): Ticket {
  const meta = TICKET_TYPES[String(row.ticket_type ?? '')] ?? { type: 'other' as const, label: String(row.ticket_type ?? 'Other') };
  const verdict = String(row.verdict ?? '');
  const state: Ticket['state'] =
    row.status === 'open' ? 'open'
    : row.status === 'investigating' ? 'investigating'
    : row.status === 'awaiting_customer' ? 'awaiting'
    : row.status === 'resolved' ? (verdict === 'refund' ? 'resolved-refund' : 'resolved-reject')
    : 'closed';
  const p = Number(row.priority ?? 3);

  return {
    id: row.id,
    num: row.ticket_no ?? '—',
    type: meta.type,
    typeLabel: meta.label,
    channel: 'whatsapp',
    priority: p <= 1 ? 'P1' : p === 2 ? 'P2' : p === 3 ? 'P3' : 'P4',
    state,
    customer: row.user_phone ?? 'Unknown',
    customerId: row.user_id ?? '',
    phone: row.user_phone ?? '—',
    amount: paiseToRupees(row.claim_amount_paise),
    upiRef: '—',
    machineId: row.machine_id ?? '',
    machine: `${row.machine_code ?? '—'} · ${row.machine_name ?? '—'}`,
    orderId: '',
    openedLabel: label(row.created_at),
    slaMin: 0,
    assignedTo: row.assigned_to ?? null,
    message: row.user_message ?? '',
    contextLine: '',
    history: [],
  };
}

export async function getTickets(): Promise<Ticket[]> {
  const res = await backendApi.liveTickets();
  if (res.success && Array.isArray(res.data?.tickets)) {
    return (res.data.tickets as any[]).map(toTicket);
  }
  if (isDemoMode()) return seedTickets();
  return [];
}

/* ── customers ──────────────────────────────────────────────── */

function toCustomer(row: any): Customer {
  const orders = Number(row.order_count ?? 0);
  const spend = paiseToRupees(row.spend_paise);
  const wallet = paiseToRupees(row.wallet_paise);
  return {
    id: row.id,
    name: row.phone ?? 'Unknown',
    phone: row.phone ?? '—',
    city: '—',
    college: '—',
    ageBand: '—',
    joinedLabel: label(row.created_at),
    orders,
    spend,
    lastOrderLabel: label(row.last_order_at),
    wallet,
    coins: 0,
    streak: { cur: 0, longest: 0 },
    segments: [orders >= 10 || spend >= 1000 ? 'High value' : 'Active'],
    repeatRatePct: 0,
    favourite: '—',
    consents: { leaderboard: false, handle: false, avatar: false, updatedAt: '—' },
    badges: [],
    leaderboard: { rank: 0, score: 0, period: '—' },
    referrals: { invited: 0, qualified: 0, paid: 0 },
    gifts: { sent: 0, received: 0 },
    tickets: [],
    anonymous: false,
  };
}

export async function getCustomers(): Promise<Customer[]> {
  const res = await backendApi.liveCustomers();
  if (res.success && Array.isArray(res.data?.customers)) {
    return (res.data.customers as any[]).map(toCustomer);
  }
  if (isDemoMode()) return CUSTOMERS;
  return [];
}

export async function getCustomerById(id: string): Promise<Customer | null> {
  const all = await getCustomers();
  return all.find(c => c.id === id) ?? null;
}

export async function getOrdersForCustomer(customerId: string): Promise<Order[]> {
  const all = await getOrders();
  return all.filter(o => o.customerId === customerId);
}

/* ── inventory ──────────────────────────────────────────────── */

export async function getStock(): Promise<StockRow[]> {
  const res = await backendApi.liveInventory();
  if (res.success && Array.isArray(res.data?.stock)) {
    return (res.data.stock as any[]).map(s => ({
      machineId: s.machine_id,
      variant: s.item_type === 'cup' ? 'Paper Cups'
        : s.item_type === 'kit' ? (s.variant_key && s.variant_key !== 'default' ? s.variant_key : 'Manhattan Velvet')
        : s.item_type === 'malai' ? 'Malai'
        : s.item_type === 'coffee_powder' ? 'Coffee Powder'
        : s.item_type === 'sugar' ? 'Sugar'
        : String(s.item_type),
      kind: s.item_type === 'cup' ? 'cups' : s.item_type === 'malai' ? 'malai' : 'kits',
      qty: Number(s.quantity ?? 0),
      unit: s.item_type === 'cup' ? 'cups' : s.item_type === 'malai' ? 'L' : 'units',
      threshold: Number(s.reorder_threshold ?? 0),
      lastRefillLabel: label(s.updated_at),
    }));
  }
  if (isDemoMode()) return STOCK;
  return [];
}

/* ── analytics ──────────────────────────────────────────────── */

export async function getAnalytics() {
  const res = await backendApi.liveAnalytics();
  if (res.success && res.data) {
    return {
      sales: (res.data.sales_daily ?? []) as any[],
      products: (res.data.product_mix ?? []) as any[],
      machines: (res.data.machine_performance ?? []) as any[],
    };
  }
  return { sales: [], products: [], machines: [] };
}
