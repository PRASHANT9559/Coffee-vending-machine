/* ─────────────────────────────────────────────────────────────
   Formatting helpers — money is stored in PAISE across the
   schema (amount_paise / final_paise / balance_paise), the
   panel shows ₹ in integers like the demo (₹6,800).
   ───────────────────────────────────────────────────────────── */

export const paise = (p: number) => p / 100;

export function inr(n: number): string {
  return Math.round(n).toLocaleString('en-IN');
}

export function rs(n: number): string {
  return `₹${inr(n)}`;
}

/** Convert database integer paise to ₹ string display (e.g. 2000 paise -> "₹20") */
export function paiseToRs(p: number): string {
  return rs(p / 100);
}

/** Convert database integer paise to integer rupees */
export function paiseToInr(p: number): number {
  return Math.round(p / 100);
}

/** Convert rupees to integer paise for database insertion */
export function inrToPaise(r: number): number {
  return Math.round(r * 100);
}

/** ₹2,000 → "₹2K" · ₹1,500 → "₹1.5K" · ₹800 → "₹800" — never "₹0K" (demo rule) */
export function fmtMoney(v: number): string {
  if (v >= 10000) return '₹' + Math.round(v / 1000) + 'K';
  if (v >= 1000) return '₹' + (Math.round(v / 100) / 10) + 'K';
  if (v >= 100) return '₹' + Math.round(v);
  return '₹0';
}

/** 8.2 → "8.2%", always one decimal like the demo */
export function fmtPct(x: number): string {
  return `${(Math.round(x * 10) / 10).toFixed(1)}%`;
}

/** bucket hour index → "11:00 AM" */
export function hourLabel(h: number): string {
  const h12 = h % 12 === 0 ? 12 : h % 12;
  const ap = h < 12 ? 'AM' : 'PM';
  return `${h12}:00 ${ap}`;
}
