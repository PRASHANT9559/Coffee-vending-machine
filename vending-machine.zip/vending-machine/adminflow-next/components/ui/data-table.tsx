'use client';

/* Generic client data-table for the queue screens — search,
   select filters, CSV export, row chips/links/flags. Column
   contracts live in lib/mock/types.ts (Cell union). */

import Link from 'next/link';
import { useMemo, useState } from 'react';
import type { Cell } from '@/lib/mock/types';
import { inr } from '@/lib/format';
import { IconDownload, IconFlag, IconSearch } from '@/components/ui/icons';
import { toneCls } from './kit';

export interface DataTableCol { key: string; label: string; align?: 'right' }

function cellText(c: Cell): string {
  if (typeof c === 'string' || typeof c === 'number') return String(c);
  return c.t === 'money' ? c.v.toLocaleString('en-IN') : c.t === 'chip' ? c.v : '';
}

function cellEl(c: Cell, k: string): React.ReactNode {
  if (typeof c === 'string' || typeof c === 'number') {
    return isMoneyKey(k) ? '₹' + inr(Number(c)) : c;
  }
  switch (c.t) {
    case 'chip':
      return <span className={`inline-block text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${toneCls(c.tone)}`}>{c.v}</span>;
    case 'link':
      return <Link className="font-mono text-[11.5px] text-brand-600 hover:underline whitespace-nowrap" href={c.href}>{c.v}</Link>;
    case 'money':
      return <span className="font-semibold whitespace-nowrap">₹{inr(c.v)}</span>;
    case 'flag':
      return <IconFlag className="w-3.5 h-3.5 text-brand-500" />;
    default:
      return null;
  }
}

function isMoneyKey(k: string): boolean {
  return ['amount', 'final', 'total', 'spend', 'balance', 'wallet', 'gain', 'revenue', 'rent'].some(m => k.startsWith(m));
}

export default function DataTable({ columns, rows, searchable = true, filters, csvName, dense = false }: {
  columns: DataTableCol[]; rows: Record<string, Cell>[]; searchable?: boolean;
  filters?: { key: string; label: string; options: string[] }[];
  csvName?: string; dense?: boolean;
}) {
  const [q, setQ] = useState('');
  const [sel, setSel] = useState<Record<string, string>>({});

  const filtered = useMemo(() => rows.filter(r => {
    for (const [k, v] of Object.entries(sel)) {
      if (v && cellText(r[k] ?? '').toLowerCase() !== v.toLowerCase()) return false;
    }
    if (!q) return true;
    return columns.some(c => cellText(r[c.key] ?? '').toLowerCase().includes(q.toLowerCase()));
  }), [q, sel, rows, columns]);

  const exportCsv = () => {
    if (!csvName) return;
    const head = columns.map(c => c.label).join(',');
    const body = filtered.map(r => columns.map(c => {
      const raw = r[c.key];
      const t = cellText(raw as Cell);
      return /[",\n]/.test(t) ? `"${t.replaceAll('"', '""')}"` : t;
    }).join(','));
    const blob = new Blob([[head, ...body].join('\n')], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${csvName}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div>
      {(searchable || filters) && (
        <div className="flex flex-wrap items-center gap-2 mb-3">
          {searchable && (
            <div className="relative flex-1 min-w-[180px] max-w-[300px]">
              <IconSearch className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
              <input
                value={q}
                onChange={e => setQ(e.target.value)}
                placeholder="Search…"
                className="w-full pl-9 pr-3 py-2 text-[12.5px] bg-page border border-line rounded-lg outline-none focus:border-brand-400 focus:bg-white transition"
              />
            </div>
          )}
          {filters?.map(f => (
            <select
              key={f.key}
              value={sel[f.key] ?? ''}
              onChange={e => setSel(s => ({ ...s, [f.key]: e.target.value }))}
              className="text-[12px] bg-page border border-line rounded-lg px-2.5 py-2 outline-none focus:border-brand-400 transition"
            >
              <option value="">{f.label} · all</option>
              {f.options.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          ))}
          <span className="text-[11px] text-ink-400 ml-auto">{filtered.length} / {rows.length}</span>
          {csvName && (
            <button
              onClick={exportCsv}
              className="inline-flex items-center gap-1.5 text-[11.5px] font-semibold border border-line hover:bg-page rounded-lg px-2.5 py-1.5 transition"
            >
              <IconDownload className="w-3.5 h-3.5" /> CSV
            </button>
          )}
        </div>
      )}

      <div className="overflow-x-auto -mx-1 px-1">
        <table className="w-full border-collapse text-[12.5px]">
          <thead>
            <tr>
              {columns.map(c => (
                <th
                  key={c.key}
                  className={`text-[10px] font-semibold uppercase tracking-[.08em] text-ink-400 py-2.5 px-2 border-b border-line whitespace-nowrap ${c.align === 'right' ? 'text-right' : 'text-left'} ${isMoneyKey(c.key) ? 'text-right' : ''}`}
                >
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, i) => (
              <tr
                key={((r.id as Cell | undefined) != null ? String(r.id) : String(i))}
                className="hover:bg-[#F9FAFB] transition-colors"
              >
                {columns.map(c => {
                  const cell = r[c.key] as Cell | undefined;
                  const right = c.align === 'right' || isMoneyKey(c.key) || (cell && typeof cell !== 'string' && cell.t === 'money');
                  return (
                    <td key={c.key} className={`${dense ? 'py-1.5' : 'py-2.5'} px-2 border-b border-[#F4F5F7] align-middle ${right ? 'text-right' : ''}`}>
                      {cell !== undefined ? cellEl(cell, c.key) : <span className="text-ink-300">—</span>}
                    </td>
                  );
                })}
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={columns.length} className="py-10 text-center text-ink-400 text-[12.5px]">No rows match.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
