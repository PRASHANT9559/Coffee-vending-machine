'use client';

/* Toast dock + ActionButton — every "action emitted" in the
   route registry ends here: server action → toast → optional
   router refresh so the demo store change paints through. */

import { useEffect, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import type { ReactNode } from 'react';

type Tone = 'ok' | 'warn' | 'info';
interface ToastItem { id: number; msg: string; tone: Tone }

export function emitToast(msg: string, tone: Tone = 'ok'): void {
  window.dispatchEvent(new CustomEvent('mc-toast', { detail: { msg, tone } }));
}

export default function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  useEffect(() => {
    const on = (e: Event) => {
      const { msg, tone } = (e as CustomEvent<{ msg: string; tone: Tone }>).detail;
      const id = Date.now() + Math.random();
      setItems(s => [...s, { id, msg, tone }]);
      setTimeout(() => setItems(s => s.filter(t => t.id !== id)), 2600);
    };
    window.addEventListener('mc-toast', on);
    return () => window.removeEventListener('mc-toast', on);
  }, []);

  return (
    <>
      {children}
      <div className="fixed bottom-4 right-4 z-[80] flex flex-col gap-2 items-end pointer-events-none">
        {items.map(t => (
          <div
            key={t.id}
            className={`toast-in pointer-events-auto text-[12.5px] font-medium text-white rounded-xl px-4 py-2.5 shadow-pop max-w-[340px] ${
              t.tone === 'ok' ? 'bg-ink-900' : t.tone === 'warn' ? 'bg-brand-600' : 'bg-blue-600'
            }`}
          >
            {t.msg}
          </div>
        ))}
      </div>
    </>
  );
}

export type ActionResult = { ok?: boolean; message?: string } | void;

export function ActionButton({
  run, children, tone = 'solid', small = false, confirm, title,
  disabled = false,
}: {
  run: () => Promise<ActionResult>;
  children: ReactNode;
  tone?: 'solid' | 'soft' | 'ghost' | 'danger';
  small?: boolean;
  confirm?: string;
  title?: string;
  disabled?: boolean;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();

  return (
    <button
      type="button"
      title={title}
      disabled={disabled || pending}
      onClick={() => {
        if (confirm && !window.confirm(confirm)) return;
        start(async () => {
          const r = await run();
          if (r?.message) emitToast(r.message, r.ok === false ? 'warn' : 'ok');
          if (r?.ok !== false) router.refresh();
        });
      }}
      className={`inline-flex items-center gap-1.5 font-semibold rounded-lg transition
        disabled:opacity-50 disabled:cursor-not-allowed
        ${small ? 'text-[11px] px-2.5 py-1.5' : 'text-[12.5px] px-3.5 py-2'}
        ${tone === 'solid' ? 'bg-brand-500 hover:bg-brand-600 text-white'
          : tone === 'soft' ? 'bg-brand-50 hover:bg-brand-100 text-brand-700'
          : tone === 'danger' ? 'bg-red-50 hover:bg-red-100 text-red-600'
          : 'border border-line hover:bg-page text-ink-700'}`}
    >
      {pending ? '…' : children}
    </button>
  );
}
