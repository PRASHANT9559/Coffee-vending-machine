import Link from 'next/link';
import type { ReactNode } from 'react';
import type { AdminSession, Cap, Role } from '@/lib/auth';
import { CAP_MIN_LABEL, ROLE_META } from '@/lib/auth';
import { IconArrowLeft, IconArrowRight, IconLock, IconQr } from '@/components/ui/icons';

/* ─────────────────────────────────────────────────────────────
   Server-safe presentational kit shared by all 53 console
   routes: page headers, section cards, key-value rows, meter
   rows, the 403 screen and the module 404 screen.
   ───────────────────────────────────────────────────────────── */

/* ── page header ────────────────────────────────────────────── */
export function PageHead({ module: eyebrow, title, sub, actions }: {
  module: string; title: string; sub?: string; actions?: ReactNode;
}) {
  return (
    <div className="mb-6">
      <p className="text-[10px] font-semibold uppercase tracking-[.16em] text-brand-500">{eyebrow}</p>
      <div className="flex flex-wrap items-end justify-between gap-3 mt-1">
        <div>
          <h1 className="text-[24px] font-bold tracking-tight leading-tight">{title}</h1>
          {sub && <p className="text-[13px] text-ink-500 mt-1 max-w-[80ch] leading-relaxed">{sub}</p>}
        </div>
        {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
      </div>
    </div>
  );
}

/* ── section card ───────────────────────────────────────────── */
export function Card({ title, sub, right, children, pad = true, className = '' }: {
  title?: string; sub?: string; right?: ReactNode; children: ReactNode; pad?: boolean; className?: string;
}) {
  return (
    <section className={`card ${pad ? 'p-5' : ''} ${className}`}>
      {(title || right) && (
        <div className="flex flex-wrap items-end justify-between gap-2 mb-4">
          <div>
            {title && <h2 className="text-[15.5px] font-bold">{title}</h2>}
            {sub && <p className="text-[11.5px] text-ink-500 mt-0.5">{sub}</p>}
          </div>
          {right && <div className="flex items-center gap-2 flex-wrap">{right}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

/* ── key/value row ──────────────────────────────────────────── */
export function KV({ k, v, mono = false }: { k: string; v: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-2 border-b border-line/70 last:border-none">
      <span className="text-[11.5px] text-ink-500 shrink-0">{k}</span>
      <span className={`text-[13px] font-semibold text-right ${mono ? 'font-mono text-[12px]' : ''}`}>{v}</span>
    </div>
  );
}

/* ── chip tone helper ───────────────────────────────────────── */
export function toneCls(tone: string): string {
  switch (tone) {
    case 'leaf': return 'bg-leaf-50 text-leaf-600';
    case 'brand': return 'bg-brand-50 text-brand-600';
    case 'amber': return 'bg-amber2-50 text-amber2-600';
    case 'blue': return 'bg-blue-50 text-blue-700';
    case 'red': return 'bg-red-50 text-red-600';
    default: return 'bg-ink-300/20 text-ink-500';
  }
}

export function Tag({ tone, children }: { tone: string; children: ReactNode }) {
  return (
    <span className={`inline-block text-[10px] font-semibold px-1.5 py-0.5 rounded-md whitespace-nowrap ${toneCls(tone)}`}>
      {children}
    </span>
  );
}

export function StatusDot({ ok, title }: { ok: boolean; title?: string }) {
  return (
    <span
      title={title}
      className={`w-2 h-2 rounded-full inline-block ${ok ? 'pulse-dot bg-leaf-500' : 'bg-ink-300'}`}
    />
  );
}

/* ── role tag (topbar/content) ──────────────────────────────── */
export function RoleTag({ role, className = '' }: { role: Role; className?: string }) {
  const m = ROLE_META[role];
  return <span className={`inline-block text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${m.tint} ${className}`}>{m.label}</span>;
}

/* ── module-level 404 (guard flow: "back to module list") ───── */
export function NotFoundView({ what, back, backLabel }: { what: string; back: string; backLabel: string }) {
  return (
    <div className="max-w-lg mx-auto mt-16 text-center card p-10">
      <p className="text-[52px] font-bold text-brand-100 leading-none">404</p>
      <h2 className="text-[18px] font-bold mt-3">Record not found</h2>
      <p className="text-[13px] text-ink-500 mt-1.5">{what}</p>
      <Link
        href={back}
        className="mt-6 inline-flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white text-[13px] font-semibold rounded-lg px-4 py-2.5 transition"
      >
        <IconArrowLeft className="w-4 h-4" /> {backLabel}
      </Link>
    </div>
  );
}

/* ── the 403 screen — "guards deny, they don't hide" ────────── */
export function ForbiddenView({ admin, cap, path }: { admin: AdminSession; cap: Cap; path: string }) {
  const need = CAP_MIN_LABEL[cap];
  return (
    <div className="max-w-xl mx-auto mt-12 card overflow-hidden">
      <div className="bg-red-50 border-b border-red-100 p-6 flex items-start gap-4">
        <span className="w-11 h-11 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
          <IconLock className="w-5 h-5" />
        </span>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[.14em] text-red-500">404-R · Access denied</p>
          <h2 className="text-[19px] font-bold mt-0.5">403 — insufficient role</h2>
        </div>
      </div>
      <div className="p-6">
        <div className="rounded-lg bg-page border border-line p-4 font-mono text-[12px] text-ink-700 flex items-center gap-3">
          <IconQr className="w-4 h-4 text-ink-400 shrink-0" />
          GET {path} → <span className="text-red-600 font-semibold">403</span>
        </div>
        <div className="mt-5 grid sm:grid-cols-3 gap-3">
          <div className="rounded-xl border border-line p-3.5">
            <p className="text-[10px] uppercase tracking-wider text-ink-400 font-semibold">You are</p>
            <p className="text-[14px] font-bold mt-1">{admin.name}</p>
            <RoleTag role={admin.role} className="mt-1.5" />
          </div>
          <div className="rounded-xl border border-brand-200 bg-brand-50 p-3.5">
            <p className="text-[10px] uppercase tracking-wider text-brand-400 font-semibold">Route requires</p>
            <p className="text-[14px] font-bold mt-1 text-brand-700">{need}+</p>
            <p className="text-[10.5px] text-brand-400 mt-1.5">minimum role for this module</p>
          </div>
          <div className="rounded-xl border border-line p-3.5">
            <p className="text-[10px] uppercase tracking-wider text-ink-400 font-semibold">Mirror check</p>
            <p className="text-[12.5px] text-ink-700 mt-1 leading-snug">The Rust service re-checks this on the payload too — a forged request fails at the server, not just in the UI.</p>
          </div>
        </div>
        <p className="text-[11.5px] text-ink-400 mt-5">
          This attempt was written to the audit trail (<code className="p font-mono">route.denied · /{path}</code>).
        </p>
        <div className="flex gap-2 mt-5">
          <Link href="/" className="inline-flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white text-[12.5px] font-semibold rounded-lg px-4 py-2 transition">
            <IconArrowLeft className="w-4 h-4" /> Dashboard
          </Link>
          <Link href="/settings/team" className="inline-flex items-center gap-2 border border-line hover:bg-page text-ink-700 text-[12.5px] font-semibold rounded-lg px-4 py-2 transition">
            Role matrix <IconArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}

/* ── generic empty state ────────────────────────────────────── */
export function Empty({ msg }: { msg: string }) {
  return (
    <div className="text-center py-10 text-[13px] text-ink-400">
      {msg}
    </div>
  );
}

/* ── footer note line ───────────────────────────────────────── */
export function FootNote({ children }: { children: ReactNode }) {
  return (
    <p className="text-[11.5px] text-ink-400 mt-4 pt-3 border-t border-line leading-relaxed">
      {children}
    </p>
  );
}

/** ₹ formatter kept here so server components don't pull client code */
export function rs(n: number): string { return '₹' + Math.round(n).toLocaleString('en-IN'); }
