/* Stroke icons lifted from admin-dashboard.html so the panel
   stays visually identical to the design demo. */

import type { ReactNode, SVGProps } from 'react';

type P = SVGProps<SVGSVGElement>;

function S(props: P, body: ReactNode, sw = 1.8) {
  return (
    <svg
      className={props.className}
      fill="none"
      stroke="currentColor"
      strokeWidth={props.strokeWidth ?? sw}
      strokeLinecap="round"
      strokeLinejoin="round"
      viewBox="0 0 24 24"
      aria-hidden
    >
      {body}
    </svg>
  );
}

export const IconDashboard = (p: P) =>
  S(p, <>
    <rect x="3" y="3" width="7" height="9" rx="1.5" />
    <rect x="14" y="3" width="7" height="5" rx="1.5" />
    <rect x="14" y="12" width="7" height="9" rx="1.5" />
    <rect x="3" y="16" width="7" height="5" rx="1.5" />
  </>, 1.8);

export const IconMachine = (p: P) =>
  S(p, <>
    <rect x="4" y="2.5" width="16" height="19" rx="2.5" />
    <path d="M8 7h8M8 11h3M8 15h3" />
    <circle cx="15.5" cy="15" r="2.5" />
  </>, 1.8);

export const IconOrders = (p: P) =>
  S(p, <>
    <path d="M6 2 3 6.5V20a1.5 1.5 0 0 0 1.5 1.5h15A1.5 1.5 0 0 0 21 20V6.5L18 2z" />
    <path d="M3 6.5h18M16 10a4 4 0 0 1-8 0" />
  </>, 1.8);

export const IconCustomers = (p: P) =>
  S(p, <>
    <path d="M16 20v-1.5a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4V20" />
    <circle cx="9" cy="7" r="3.5" />
    <path d="M22 20v-1.5a4 4 0 0 0-3-3.87M16 3.6a4 4 0 0 1 0 7.75" />
  </>, 1.8);

export const IconInventory = (p: P) =>
  S(p, <>
    <path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z" />
    <path d="M3 7.5 12 12m0 0 9-4.5M12 12v9" />
  </>, 1.8);

export const IconAnalytics = (p: P) =>
  S(p, <>
    <path d="M3 3v16.5A1.5 1.5 0 0 0 4.5 21H21" />
    <path d="m7 14 3.5-4 3 2.5L20 7" />
  </>, 1.8);

export const IconMarketing = (p: P) =>
  S(p, <>
    <path d="m3 11 15-7v14L3 11z" />
    <path d="M3 11v4a2 2 0 0 0 2 2h1v-5M18 8.5a3 3 0 0 1 0 5" />
  </>, 1.8);

export const IconSupport = (p: P) =>
  S(p, <>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 16v-4M12 8h.01" />
  </>, 1.8);

export const IconSettings = (p: P) =>
  S(p, <>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6h.09A1.65 1.65 0 0 0 10 3.09V3a2 2 0 1 1 4 0v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </>, 1.8);

export const IconSearch = (p: P) =>
  S(p, <>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </>, 2);

export const IconBell = (p: P) =>
  S(p, <>
    <path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" />
    <path d="M13.7 21a2 2 0 0 1-3.4 0" />
  </>, 1.8);

export const IconMenu = (p: P) =>
  S(p, <path d="M3 6h18M3 12h18M3 18h18" />, 2);

export const IconChevronDown = (p: P) =>
  S(p, <path d="m6 9 6 6 6-6" />, 2.5);

export const IconCalendar = (p: P) =>
  S(p, <>
    <rect x="3" y="5" width="18" height="16" rx="2" />
    <path d="M16 3v4M8 3v4M3 11h18" />
  </>, 1.8);

export const IconDownload = (p: P) =>
  S(p, <>
    <path d="M12 3v12m0 0 4-4m-4 4-4-4" />
    <path d="M3 17v2a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2" />
  </>, 2);

export const IconPlus = (p: P) =>
  S(p, <path d="M12 5v14M5 12h14" />, 2);

export const IconArrowUp = (p: P) =>
  S(p, <path d="M12 19V5M5 12l7-7 7 7" />, 2.5);

export const IconMoney = (p: P) =>
  S(p, <>
    <rect x="2" y="6" width="20" height="13" rx="2" />
    <circle cx="12" cy="12.5" r="2.5" />
    <path d="M6 6V4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V6" />
  </>, 2);

export const IconTrendUp = (p: P) =>
  S(p, <>
    <path d="M3 17.5 9 11l4 4 8-8.5" />
    <path d="M15 6.5h6v6" />
  </>, 2);

export const IconClock = (p: P) =>
  S(p, <>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </>, 2);

export const IconChartLine = (p: P) =>
  S(p, <path d="M3 17.5 9 11l4 4 8-8.5" />, 2);

export const IconBulb = (p: P) =>
  S(p, <>
    <path d="M9 18h6M10 21h4" />
    <path d="M12 2a6 6 0 0 0-4 10.5V16h8v-3.5A6 6 0 0 0 12 2z" />
  </>, 2);

export const IconWallet = (p: P) =>
  S(p, <>
    <rect x="2" y="6" width="20" height="13" rx="2" />
    <circle cx="12" cy="12.5" r="2.5" />
  </>, 2);

/* ── extended set (`adminflow-next` routing build) ───────────── */

export const IconLock = (p: P) =>
  S(p, <>
    <rect x="4" y="11" width="16" height="10" rx="2" />
    <path d="M8 11V7a4 4 0 0 1 8 0v4" />
  </>, 1.8);

export const IconUnlock = (p: P) =>
  S(p, <>
    <rect x="4" y="11" width="16" height="10" rx="2" />
    <path d="M8 11V7a4 4 0 0 1 7.8-1.2" />
  </>, 1.8);

export const IconRefresh = (p: P) =>
  S(p, <>
    <path d="M21 12a9 9 0 1 1-2.6-6.4" />
    <path d="M21 4v5h-5" />
  </>, 1.8);

export const IconThermo = (p: P) =>
  S(p, <>
    <path d="M10 13.5V4a2 2 0 0 1 4 0v9.5a4 4 0 1 1-4 0z" />
    <path d="M12 9v5" />
  </>, 1.8);

export const IconDroplet = (p: P) =>
  S(p, <path d="M12 2.7S6 9.2 6 13.8a6 6 0 0 0 12 0C18 9.2 12 2.7 12 2.7z" />, 1.8);

export const IconCup = (p: P) =>
  S(p, <>
    <path d="M17 9h1.5a2.5 2.5 0 0 1 0 5H17" />
    <path d="M3 9h14v7a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9z" />
    <path d="M6 3v2M10 2v3M14 3v2" />
  </>, 1.8);

export const IconVideo = (p: P) =>
  S(p, <>
    <rect x="2" y="6" width="13" height="12" rx="2" />
    <path d="m15 10 6-3.5v11L15 14" />
  </>, 1.8);

export const IconQr = (p: P) =>
  S(p, <>
    <rect x="3" y="3" width="7" height="7" rx="1" />
    <rect x="14" y="3" width="7" height="7" rx="1" />
    <rect x="3" y="14" width="7" height="7" rx="1" />
    <path d="M14 14h3v3h-3zM20 14h1M14 20h1M20 17v4h-3" />
  </>, 1.8);

export const IconPrint = (p: P) =>
  S(p, <>
    <path d="M6 9V3h12v6" />
    <rect x="3" y="9" width="18" height="8" rx="2" />
    <path d="M6 14h12v7H6z" />
  </>, 1.8);

export const IconWifi = (p: P) =>
  S(p, <>
    <path d="M2 8.8a16 16 0 0 1 20 0" />
    <path d="M5.5 12.3a11 11 0 0 1 13 0" />
    <path d="M9 15.8a6 6 0 0 1 6 0" />
    <circle cx="12" cy="19" r="1" fill="currentColor" stroke="none" />
  </>, 1.8);

export const IconShield = (p: P) =>
  S(p, <>
    <path d="M12 2.5 4.5 5v6c0 5 3.2 8.7 7.5 10.5 4.3-1.8 7.5-5.5 7.5-10.5V5z" />
    <path d="m9 12 2 2 4-4" />
  </>, 1.8);

export const IconKey = (p: P) =>
  S(p, <>
    <circle cx="7.5" cy="15.5" r="3.5" />
    <path d="m10 13 9-9M16 7l2.5 2.5M13 10l2.5 2.5" />
  </>, 1.8);

export const IconWrench = (p: P) =>
  S(p, <>
    <path d="M14.7 6.3a4.5 4.5 0 0 0 5.8 5.8l-8 8a3 3 0 1 1-4.2-4.2z" />
    <path d="M19.4 3.9a2.1 2.1 0 0 1 0 3L17 9.2 15.7 7.9 18 5.5a2.1 2.1 0 0 1 1.4-1.6z" />
  </>, 1.8);

export const IconCoins = (p: P) =>
  S(p, <>
    <circle cx="9" cy="9" r="5.5" />
    <path d="M15.2 6.4a5.5 5.5 0 1 1-9 9" transform="translate(4 4)" />
  </>, 1.8);

export const IconGift = (p: P) =>
  S(p, <>
    <rect x="3" y="8" width="18" height="4" rx="1" />
    <path d="M5 12v8h14v-8M12 8v12" />
    <path d="M12 8c-1.5 0-4.5-.5-4.5-2.7A2 2 0 0 1 11 8zM12 8c1.5 0 4.5-.5 4.5-2.7A2 2 0 0 0 13 8z" />
  </>, 1.8);

export const IconStar = (p: P) =>
  S(p, <path d="m12 3 2.7 5.7 6.3.8-4.6 4.3 1.2 6.2L12 17l-5.6 3 1.2-6.2L3 9.5l6.3-.8z" />, 1.6);

export const IconFlag = (p: P) =>
  S(p, <>
    <path d="M5 21V4" />
    <path d="M5 4h10.5l-1.6 3.5L15.5 11H5" />
  </>, 1.8);

export const IconMic = (p: P) =>
  S(p, <>
    <rect x="9" y="2.5" width="6" height="11" rx="3" />
    <path d="M5 11a7 7 0 0 0 14 0M12 18v3.5M8.5 21.5h7" />
  </>, 1.8);

export const IconGlobe = (p: P) =>
  S(p, <>
    <circle cx="12" cy="12" r="9" />
    <path d="M3 12h18M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z" />
  </>, 1.8);

export const IconDatabase = (p: P) =>
  S(p, <>
    <ellipse cx="12" cy="5.5" rx="8" ry="3" />
    <path d="M4 5.5v13c0 1.7 3.6 3 8 3s8-1.3 8-3v-13" />
    <path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3" />
  </>, 1.8);

export const IconFile = (p: P) =>
  S(p, <>
    <path d="M6 2.5h8L19 8v13.5H6z" />
    <path d="M13.5 2.5V8H19M9 13h6M9 16.5h6" />
  </>, 1.8);

export const IconLogout = (p: P) =>
  S(p, <>
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <path d="m16 17 5-5-5-5M21 12H9" />
  </>, 1.8);

export const IconArrowRight = (p: P) =>
  S(p, <path d="M5 12h14m-6-6 6 6-6 6" />, 2);

export const IconArrowLeft = (p: P) =>
  S(p, <path d="M19 12H5m6 6-6-6 6-6" />, 2);

export const IconCheck = (p: P) =>
  S(p, <path d="m4 12.5 5 5L20 6.5" />, 2.4);

export const IconClose = (p: P) =>
  S(p, <path d="M6 6l12 12M18 6 6 18" />, 2.2);

export const IconSnow = (p: P) =>
  S(p, <>
    <path d="M12 2v20M4 6l16 12M20 6L4 18" />
    <path d="M12 6l-2.2-2.2M12 6l2.2-2.2" />
  </>, 1.6);

export const IconFlame = (p: P) =>
  S(p, <path d="M12 2.5c.4 3-.8 4.6-2.6 6.7C7.5 11.4 6 13.6 6 16a6 6 0 0 0 12 0c0-3.1-1.5-5.2-3-7-1.7-2.1-2.7-3.8-3-6.5z" />, 1.7);

export const IconUpload = (p: P) =>
  S(p, <>
    <path d="M12 16V4m0 0 4 4m-4-4L8 8" />
    <path d="M3 15v3a2.5 2.5 0 0 0 2.5 2.5h13A2.5 2.5 0 0 0 21 18v-3" />
  </>, 1.8);

export const IconFilter = (p: P) =>
  S(p, <path d="M3 5h18l-7 8.5V19l-4 2v-7.5z" />, 1.8);

export const IconSend = (p: P) =>
  S(p, <>
    <path d="m21.5 2.5-9 18-3.4-7.1L2 10z" />
    <path d="M21.5 2.5 9.1 13.4" />
  </>, 1.8);

export const IconCopy = (p: P) =>
  S(p, <>
    <rect x="9" y="9" width="12" height="12" rx="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </>, 1.8);

export const IconEye = (p: P) =>
  S(p, <>
    <path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z" />
    <circle cx="12" cy="12" r="2.8" />
  </>, 1.8);

export const IconUsers = (p: P) =>
  S(p, <>
    <circle cx="9" cy="8" r="3.5" />
    <path d="M3 20v-1.5a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5V20M16.5 3.7a3.5 3.5 0 0 1 0 6.8M21 20v-1a4.5 4.5 0 0 0-3.5-4.4" />
  </>, 1.8);

export const IconMegaphone = (p: P) =>
  S(p, <>
    <path d="M3 10.5v3a2 2 0 0 0 2 2h1L19 20V4L6 8.5H5a2 2 0 0 0-2 2z" />
    <path d="M19 8.5a3 3 0 0 1 0 6" />
  </>, 1.8);

export const IconPause = (p: P) =>
  S(p, <path d="M9 5.5v13M15 5.5v13" />, 2.4);

export const IconPlay = (p: P) =>
  S(p, <path d="M8 5.5v13l10-6.5z" />, 2);

export const IconPlusCircle = (p: P) =>
  S(p, <>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 8.5v7M8.5 12h7" />
  </>, 1.8);

export const IconTruck = (p: P) =>
  S(p, <>
    <path d="M2 6h11v10H2zM13 9h4.5L21 12.5V16h-8" />
    <circle cx="6.5" cy="17.5" r="1.8" />
    <circle cx="16.5" cy="17.5" r="1.8" />
  </>, 1.8);

export const IconHistory = (p: P) =>
  S(p, <>
    <path d="M3.5 5v4h4" />
    <path d="M4 13a8.5 8.5 0 1 0 1.5-6.5A9 9 0 0 0 3.5 9.5" />
    <path d="M12 7.5v5l3.5 2" />
  </>, 1.8);

export const IconBank = (p: P) =>
  S(p, <>
    <path d="m3 9 9-5.5L21 9v1H3zM5 10.5V19M10 10.5V19M14 10.5V19M19 10.5V19M3 21h18" />
  </>, 1.6);

export const IconRotate = IconRefresh;
