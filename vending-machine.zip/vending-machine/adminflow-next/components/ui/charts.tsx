'use client';

/* Dependency-free SVG chart kit — donut, bars, stacked bars,
   line/area series, 24×7 heatmap and an arc gauge. All animated
   via CSS transitions like the demo's donut segments. */

import { useState } from 'react';

export interface Slice { name: string; n: number; pct: number; color: string }

const TAU = Math.PI * 2;

/* ── animated donut ─────────────────────────────────────────── */
export function Donut({ segments, size = 150, thickness = 20 }: { segments: Slice[]; size?: number; thickness?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const R = (size - thickness) / 2;
  const C = R * TAU;

  let acc = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
      <circle cx={size / 2} cy={size / 2} r={R} fill="none" stroke="#F3F4F6" strokeWidth={thickness} />
      {segments.map((s, i) => {
        const frac = s.pct / 100;
        const dash = `${frac * C} ${C}`;
        const off = C - acc * C;
        acc += frac;
        return (
          <circle
            key={s.name}
            cx={size / 2} cy={size / 2} r={R} fill="none"
            stroke={s.color}
            strokeWidth={hover === i ? thickness + 4 : thickness}
            strokeDasharray={dash}
            strokeDashoffset={off}
            strokeLinecap={frac > 0.03 ? 'round' : 'butt'}
            className="donut-seg"
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
        );
      })}
      <text x={size / 2} y={size / 2 - 2} textAnchor="middle" className="fill-ink-900" fontSize="19" fontWeight="700">
        {hover !== null ? `${segments[hover].pct}%` : segments.length}
      </text>
      <text x={size / 2} y={size / 2 + 16} textAnchor="middle" fill="#9CA3AF" fontSize="9.5" fontWeight="600" letterSpacing="1">
        {hover !== null ? segments[hover].name.toUpperCase().slice(0, 10) : 'TOTAL'}
      </text>
    </svg>
  );
}

/* ── meter bar ──────────────────────────────────────────────── */
export function Meter({ pct, color = '#F04E23', h = 6, track = '#F3F4F6' }: { pct: number; color?: string; h?: number; track?: string }) {
  const w = Math.max(0, Math.min(100, pct));
  return (
    <div className="rounded-full overflow-hidden" style={{ background: track, height: h }}>
      <div className="rounded-full h-full transition-[width] duration-700" style={{ width: `${w}%`, background: color }} />
    </div>
  );
}

export function MeterRow({ label, value, color, right }: { label: string; value?: string; color?: string; right?: string }) {
  return (
    <div>
      <div className="flex justify-between items-baseline mb-1">
        <span className="text-[11.5px] font-medium text-ink-500">{label}</span>
        <span className="text-[11.5px] font-bold">{right ?? `${Math.round(value ?? 0)}%`}</span>
      </div>
      <Meter pct={value ?? 0} color={color} />
    </div>
  );
}

/* ── vertical bars ──────────────────────────────────────────── */
export function Bars({ values, labels, color = '#F04E23', height = 180, suffix = '' }: {
  values: number[]; labels: string[]; color?: string; height?: number; suffix?: string;
}) {
  const max = Math.max(...values, 1);
  return (
    <div className="flex items-end gap-1.5" style={{ height }}>
      {values.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1 group relative">
          <div
            className="w-full rounded-t-md transition-all duration-500 hover:opacity-80"
            style={{ height: `${(v / max) * (height - 30)}px`, background: color, minWidth: 14 }}
          />
          <span className="text-[9.5px] text-ink-400">{labels[i]}</span>
          <span className="absolute -top-5 text-[10px] font-bold bg-ink-900 text-white rounded px-1.5 opacity-0 group-hover:opacity-100 transition pointer-events-none">
            {v.toLocaleString('en-IN')}{suffix}
          </span>
        </div>
      ))}
    </div>
  );
}

/* ── stacked bars ───────────────────────────────────────────── */
export interface StackKey { key: string; color: string; label: string }
export function StackedBars({ points, keys, height = 200 }: {
  points: Record<string, number | string>[]; keys: StackKey[]; height?: number;
}) {
  const totals = points.map(p => keys.reduce((a, k) => a + (p[k.key] as number ?? 0), 0));
  const max = Math.max(...totals, 1);
  return (
    <div>
      <div className="flex items-end gap-2" style={{ height }}>
        {points.map((p, i) => (
          <div key={i} className="flex-1 flex flex-col justify-end items-stretch gap-0 group">
            <div className="relative flex flex-col justify-end" style={{ height: height - 28 }}>
              {keys.map(k => {
                const v = p[k.key] as number ?? 0;
                return v > 0 && (
                  <div key={k.key} className="transition-all duration-500"
                    style={{ height: `${(v / max) * 100}%`, background: k.color }} />
                );
              })}
              <span className="absolute -top-1 left-1/2 -translate-x-1/2 text-[10px] font-bold bg-ink-900 text-white rounded px-1.5 py-0.5 opacity-0 group-hover:opacity-100 transition pointer-events-none whitespace-nowrap">
                {'₹' + Math.round(totals[i]).toLocaleString('en-IN')}
              </span>
            </div>
            <span className="text-[9.5px] text-ink-400 text-center mt-1">{p.label as string}</span>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-3 mt-3">
        {keys.map(k => (
          <span key={k.key} className="flex items-center gap-1.5 text-[11px] text-ink-500">
            <i className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: k.color }} />{k.label}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ── line/area series ───────────────────────────────────────── */
export interface LineSeriesDef { label: string; color: string; values: number[]; area?: boolean }
export function LineChart({ series, labels, height = 220, suffix = '' }: {
  series: LineSeriesDef[]; labels: string[]; height?: number; suffix?: string;
}) {
  const [pt, setPt] = useState<number | null>(null);
  const W = 640;
  const P = { l: 40, r: 40, t: 14, b: 24 };
  const iw = W - P.l - P.r;
  const ih = height - P.t - P.b;
  const n = labels.length;
  const max = Math.max(...series.flatMap(s => s.values), 1) * 1.15;
  const x = (i: number) => P.l + (iw * i) / Math.max(1, n - 1);
  const y = (v: number) => P.t + ih - (v / max) * ih;

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${height}`} className="w-full" style={{ height }}>
        {[0, 1, 2, 3, 4].map(g => (
          <g key={g}>
            <line x1={P.l} x2={W - P.r} y1={P.t + (ih * (4 - g)) / 4} y2={P.t + (ih * (4 - g)) / 4} stroke="#EDEFF2" />
            <text x={P.l - 8} y={P.t + (ih * (4 - g)) / 4} textAnchor="end" fill="#9CA3AF" fontSize="9">{fmtAxis((max * g) / 4, suffix)}</text>
          </g>
        ))}
        {labels.map((l, i) => (n <= 14 || i % (n > 16 ? Math.ceil(n / 12) : 1) === 0) && (
          <text key={i} x={x(i)} y={height - 6} textAnchor="middle" fill="#9CA3AF" fontSize="9">{l}</text>
        ))}
        {pt !== null && (
          <line x1={x(pt)} x2={x(pt)} y1={P.t} y2={P.t + ih} stroke="#9CA3AF" strokeDasharray="3 3" />
        )}
        {series.map(s => (
          <g key={s.label}>
            {s.area !== false && (
              <path d={`${mkPath(s.values, x, y, labels)}L${x(n - 1)} ${P.t + ih}L${x(0)} ${P.t + ih}Z`} fill={s.color} opacity=".08" />
            )}
            <path d={mkPath(s.values, x, y, labels)} fill="none" stroke={s.color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            {pt !== null && s.values[pt] !== undefined && (
              <circle cx={x(pt)} cy={y(s.values[pt])} r="4" fill="#fff" stroke={s.color} strokeWidth="2.4" />
            )}
          </g>
        ))}
        {pt !== null && (
          <line x1={x(pt)} x2={x(pt)} y1={P.t} y2={P.t + ih} stroke="transparent" />
        )}
      </svg>
      <div
        className="absolute inset-0"
        onMouseLeave={() => setPt(null)}
        onMouseMove={e => {
          const box = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
          const rx = ((e.clientX - box.left) / box.width) * W;
          const i = Math.round(((rx - P.l) / iw) * (n - 1));
          setPt(Math.max(0, Math.min(n - 1, i)));
        }}
      />
      {pt !== null && (
        <div
          className="chart-tip absolute z-10 bg-ink-900 text-white text-[10.5px] rounded-lg px-2.5 py-1.5 whitespace-nowrap"
          style={{ left: `${(x(pt) / W) * 100}%`, top: 0, transform: 'translate(-50%, 4px)' }}
        >
          <b>{labels[pt]}</b>
          {series.map(s => (
            <div key={s.label}>{s.label}: {fmtNum(s.values[pt] ?? 0)}{suffix}</div>
          ))}
        </div>
      )}
    </div>
  );
}

function mkPath(values: number[], x: (i: number) => number, y: (v: number) => number, labels: string[]): string {
  return values.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
}

function fmtAxis(v: number, suffix: string): string {
  if (suffix === '₹') return v >= 1000 ? `${(v / 1000).toFixed(1).replace(/\.0$/, '')}K` : String(Math.round(v));
  return String(Math.round(v));
}
function fmtNum(v: number): string {
  return v.toLocaleString('en-IN');
}

/* ── 24×7 heatmap ───────────────────────────────────────────── */
export function Heatmap({ matrix, rowLabels, colLabels }: {
  matrix: number[][]; rowLabels: string[]; colLabels?: string[];
}) {
  const max = Math.max(...matrix.flat(), 1);
  const [cell, setCell] = useState<{ r: number; c: number; v: number } | null>(null);
  return (
    <div>
      {matrix.map((row, r) => (
        <div key={r} className="flex items-center gap-1 mb-1">
          <span className="w-8 text-[9.5px] text-ink-400 font-semibold shrink-0">{rowLabels[r]}</span>
          <div className="flex gap-[3px] flex-1">
            {row.map((v, c) => {
              const t = v / max;
              return (
                <div key={c}
                  title={`${rowLabels[r]} ${c}:00 — ${v} orders`}
                  onMouseEnter={() => setCell({ r, c, v })}
                  onMouseLeave={() => setCell(null)}
                  className={`h-5 flex-1 rounded-[3px] cursor-pointer transition-all ${
                    cell?.r === r && cell?.c === c ? 'ring-2 ring-brand-500' : ''
                  }`}
                  style={{ background: t === 0 ? '#F3F4F6' : `rgba(240,78,35,${0.08 + t * 0.92})` }}
                />
              );
            })}
          </div>
        </div>
      ))}
      {colLabels && (
        <div className="flex gap-[3px] pl-9">
          {colLabels.map((c, i) => (
            <span key={i} className="flex-1 text-center text-[8.5px] text-ink-400">{c}</span>
          ))}
        </div>
      )}
      {cell && (
        <p className="mt-2 text-[11.5px] text-ink-500">
          <b className="text-ink-900">{rowLabels[cell.r]} {cell.c}:00</b> — {cell.v} orders ·{' '}
          <span className="text-brand-600 font-medium">jump to order list →</span>
        </p>
      )}
    </div>
  );
}

/* ── arc gauge ──────────────────────────────────────────────── */
export function Gauge({ value, min, max, unit, label, color = '#F04E23' }: {
  value: number; min: number; max: number; unit: string; label: string; color?: string;
}) {
  const size = 170;
  const r = 64;
  const cx = size / 2;
  const cy = size / 2 + 8;
  const frac = Math.max(0, Math.min(1, (value - min) / (max - min)));
  const A = Math.PI - frac * Math.PI;
  const arc = (from: number, to: number) => {
    const x1 = cx - r * Math.cos(from), y1 = cy - r * Math.sin(from);
    const x2 = cx - r * Math.cos(to), y2 = cy - r * Math.sin(to);
    return `M${x1} ${y1}A${r} ${r} 0 0 1 ${x2} ${y2}`;
  };
  return (
    <svg width={size} height={size * 0.72} viewBox={`0 0 ${size} ${size * 0.72}`}>
      <path d={arc(Math.PI, 0)} fill="none" stroke="#F3F4F6" strokeWidth="12" strokeLinecap="round" />
      <path d={arc(Math.PI, A)} fill="none" stroke={color} strokeWidth="12" strokeLinecap="round" className="transition-all duration-700" />
      <text x={cx} y={cy - 14} textAnchor="middle" fontSize="26" fontWeight="700" className="fill-ink-900">
        {value}°
      </text>
      <text x={cx} y={cy + 10} textAnchor="middle" fill="#9CA3AF" fontSize="9" fontWeight="600" letterSpacing="1">
        {label.toUpperCase()}
      </text>
      <text x={P_(Math.PI, cx, r)} y={cy - 2} textAnchor="middle" fontSize="7.5" fill="#9CA3AF">{min}{unit}</text>
      <text x={P_(0, cx, r)} y={cy - 2} textAnchor="middle" fontSize="7.5" fill="#9CA3AF">{max}{unit}</text>
    </svg>
  );
}
function P_(a: number, cx: number, r: number): number { return cx - (r + 12) * Math.cos(a); }
