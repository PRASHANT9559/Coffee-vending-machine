'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { emitToast } from '@/components/ui/toast';
import { sendCustomerPush } from '@/lib/actions';
import { IconSend, IconFlame } from '@/components/ui/icons';

interface SendPushModalProps {
  customerId: string;
  customerName: string;
}

export default function SendPushModal({ customerId, customerName }: SendPushModalProps) {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [channel, setChannel] = useState('fcm');
  const [isPending, startTransition] = useTransition();

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) {
      emitToast('Title and message body are both required.', 'warn');
      return;
    }

    startTransition(async () => {
      const res = await sendCustomerPush(customerId, customerName, title, body, channel);
      if (res.ok) {
        emitToast(res.message, 'ok');
        setIsOpen(false);
        setTitle('');
        setBody('');
        router.refresh();
      } else {
        emitToast(res.message, 'warn');
      }
    });
  };

  return (
    <>
      <button
        type="button"
        onClick={() => {
          setTitle(`Special offer for you, ${customerName.split(' ')[0]}!`);
          setBody('Your favourite coffee is brewing at Manhattan Coffee. Enjoy fresh beans today!');
          setIsOpen(true);
        }}
        className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white border border-line hover:bg-page px-3 py-2 rounded-lg transition text-ink-700 shadow-xs"
      >
        <IconSend className="w-4 h-4 text-brand-600" /> Send Push
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-ink-950/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-line space-y-4">
            <div className="flex items-center justify-between border-b border-line pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-brand-50 text-brand-600 rounded-lg">
                  <IconSend className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-[15px] text-ink-900">Send Customer Push Message</h3>
                  <p className="text-[11.5px] text-ink-500">Dispatch direct FCM notification to {customerName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-ink-400 hover:text-ink-800 text-[18px] font-bold px-2"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSend} className="space-y-3.5">
              <div>
                <label className="block text-[11.5px] font-bold uppercase tracking-wider text-ink-600 mb-1">
                  Notification Channel
                </label>
                <select
                  value={channel}
                  onChange={e => setChannel(e.target.value)}
                  className="w-full px-3 py-2 text-[12.5px] font-medium border border-line rounded-lg outline-none focus:border-brand-500 bg-white"
                >
                  <option value="fcm">Firebase Cloud Messaging (FCM Push)</option>
                  <option value="in_app">In-App Notification Center</option>
                  <option value="sms">SMS Text Alert (Priority)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11.5px] font-bold uppercase tracking-wider text-ink-600 mb-1">
                  Notification Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Free Morning Upgrade ☕"
                  className="w-full px-3 py-2 text-[12.5px] border border-line rounded-lg outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-[11.5px] font-bold uppercase tracking-wider text-ink-600 mb-1">
                  Message Body *
                </label>
                <textarea
                  required
                  rows={3}
                  value={body}
                  onChange={e => setBody(e.target.value)}
                  placeholder="Enter message text that will display on the customer's phone..."
                  className="w-full px-3 py-2 text-[12.5px] border border-line rounded-lg outline-none focus:border-brand-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-line">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 text-[12.5px] font-semibold text-ink-600 hover:bg-page rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isPending}
                  className="px-4 py-2 text-[12.5px] font-semibold bg-brand-600 hover:bg-brand-500 text-white rounded-lg transition shadow-xs"
                >
                  {isPending ? 'Sending…' : 'Dispatch Notification'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
