'use client';

/* Dashboard view — the spec's ① section: 4 stat cards, live
   machine strip, dual-canvas trend, variant + status donuts,
   top variants and business insights. */

import { useState } from 'react';
import Link from 'next/link';
import type { DashboardData } from '@/lib/dashboard-types';
import { fmtPct } from '@/lib/format';
import StatCard from './stat-card';
import TrendChart from './trend-chart';
import LiveStrip from './live-strip';
import { Donut } from '@/components/ui/charts';
import { ActionButton, emitToast } from '@/components/ui/toast';
import {
  IconArrowRight, IconBulb, IconDownload, IconMoney, IconOrders,
  IconPlus, IconTrendUp, IconWallet,
} from '@/components/ui/icons';
import type { ComponentType, SVGProps } from 'react';

export default function DashboardView({ data, who }: { data: DashboardData; who: string }) {
  const [range, setRange] = useState<'Today' | 'This Week' | 'This Month'>('Today');
  const s = data.stats;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-5">
      {/* header row */}
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[13px] text-ink-500">Welcome back, <b className="text-ink-900">{who}</b> — {greeting()}, Manhattan Coffee</p>
          <h1 className="text-[30px] font-bold tracking-tight mt-1 leading-tight">Fleet overview</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[12px] font-semibold border border-line rounded-lg px-3 py-2 bg-white">
            {data.date} · IST
          </span>
          <ActionButton small run={async () => ({ ok: true, message: `Report for ${range} queued — CSV of the visible window.` })}>
            <IconDownload className="w-4 h-4" /> Download Report
          </ActionButton>
          <ActionButton small tone="soft" run={async () => ({ ok: true, message: 'Onboarding wizard (demo): scan pair-code, WiFi, placement survey.' })}>
            <IconPlus className="w-4 h-4" /> Add Machine
          </ActionButton>
        </div>
      </header>

      {/* live strip (spec: click any machine → its detail overview) */}
      <LiveStrip machines={data.live} source={data.source} />

      {/* four stat cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3.5">
        <StatCard Icon={IconMoney} tint="brand" title="Total Revenue" value={s.revenueToday} prefix="₹" delta={s.revenueDelta} spark={s.revenueSpark} sparkColor="#F04E23" delay={0} />
        <StatCard Icon={IconOrders} tint="leaf" title="Orders Today" value={s.ordersToday} delta={s.ordersDelta} spark={s.ordersSpark} sparkColor="#16A34A" delay={0.05} />
        <StatCard Icon={IconTrendUp} tint="brand400" title="Active Machines"
          value={s.activeMachines} suffix={{ text: String(s.totalMachines), muted: '' }} delta={null} sparkColor="#F97C4A" delay={0.1}
          footnote={<p className="mt-1.5 text-[11.5px] font-medium text-leaf-600">100% uptime — it is a state, not a trend</p>} />
        <StatCard Icon={IconWallet} tint="amber" title="Avg Order Value" value={s.avgOrder} prefix="₹" delta={s.avgDelta} spark={s.avgSpark} sparkColor="#EAB308" delay={0.15} />
      </div>

      {/* trend */}
      <TrendChart ranges={data.ranges} range={range} onRange={setRange} />

      {/* donuts */}
      <div className="grid md:grid-cols-2 gap-3.5">
        <section className="card p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-[15.5px] font-bold">Orders by Variant</h2>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-ink-400">donut · animated</span>
          </div>
          <div className="flex items-center gap-6">
            <Donut segments={data.variants.map(v => ({ name: v.short, n: v.orders, pct: v.pct, color: v.color }))} />
            <div className="flex-1 space-y-2">
              {data.variants.map(v => (
                <div key={v.short} className="flex items-center gap-2">
                  <i className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: v.color }} />
                  <span className="text-[12.5px] font-medium">{v.emoji} {v.short}</span>
                  <span className="ml-auto text-[12px] text-ink-500 font-mono">{v.orders}</span>
                </div>
              ))}
              <p className="text-[11px] text-brand-600 font-semibold pt-1.5 border-t border-line">
                👑 top variant keeps pulling — Manhattan Velvet at {fmtPct(data.variants[0]?.pct ?? 0)}
              </p>
            </div>
          </div>
        </section>

        <section className="card p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-[15.5px] font-bold">Order Status</h2>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-ink-400">completed → preparing → pending → cancelled</span>
          </div>
          <div className="flex items-center gap-6">
            <Donut segments={data.status.map(x => ({ name: x.name, n: x.n, pct: x.pct, color: x.color }))} />
            <div className="flex-1 space-y-2">
              {data.status.map(x => (
                <div key={x.name} className="flex items-center gap-2">
                  <i className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: x.color }} />
                  <span className="text-[12.5px] font-medium">{x.name}</span>
                  <span className="ml-auto text-[12px] text-ink-500 font-mono">{x.n} · {fmtPct(x.pct)}</span>
                </div>
              ))}
              <Link href="/orders" className="text-[11px] font-semibold text-brand-600 hover:underline pt-1.5 block border-t border-line">
                Open the queue → drill into any row
              </Link>
            </div>
          </div>
        </section>
      </div>

      {/* top variants + insights */}
      <div className="grid lg:grid-cols-2 gap-3.5">
        <section className="card p-5">
          <h2 className="text-[15.5px] font-bold mb-3">Top Selling Variants</h2>
          <div className="space-y-3.5">
            {data.variants.map((v, i) => (
              <div key={v.short}>
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="text-[11px] font-bold text-ink-400 w-4">#{i + 1}</span>
                  <span className="text-[13px] font-semibold">{v.emoji} {v.short}</span>
                  <span className="ml-auto text-[12.5px] font-bold">₹{v.revenue.toLocaleString('en-IN')}</span>
                  <span className="text-[11px] text-ink-500 w-14 text-right">{v.orders} orders</span>
                </div>
                <div className="tier-bar ml-6"><i style={{ width: `${v.pct}%`, background: v.color }} /></div>
              </div>
            ))}
          </div>
        </section>

        <section className="card p-5">
          <h2 className="text-[15.5px] font-bold mb-1 flex items-center gap-2">
            <IconBulb className="w-4 h-4 text-brand-500" /> Business Insights
          </h2>
          <p className="text-[11.5px] text-ink-500 mb-3">computed for {data.date}</p>
          <ul className="divide-y divide-line/70">
            <Insight Icon={IconTrendUp} label="Revenue delta" value={`${fmtPct(Math.abs(data.insights.revenueDeltaPct ?? 0))} vs yesterday`} good={(data.insights.revenueDeltaPct ?? 0) > 0} />
            <Insight Icon={IconOrders} label="Top item today" value={data.insights.topItem} />
            <Insight Icon={IconBulb} label="Best seller (₹)" value={data.insights.bestSeller} />
            <Insight Icon={IconOrders} label="Peak hour" value={data.insights.peakHour} />
            <Insight Icon={IconWallet} label="Wallet float" value={`₹${data.insights.walletFloat.toLocaleString('en-IN')}`} />
            <Insight Icon={IconMoney} label="Ad revenue · 30d" value={`₹${data.insights.adRevenue.toLocaleString('en-IN')}`} />
          </ul>
          <div className="flex gap-2 mt-4">
            <Link href="/analytics" className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-brand-600 hover:underline">
              Open Analytics <IconArrowRight className="w-3.5 h-3.5" />
            </Link>
            <button onClick={() => emitToast('Deep-link demo: /support/tickets/tkt-1042 armed from alert.')} className="text-[12px] font-semibold text-ink-500 hover:text-ink-900">
              Simulate alert deep-link
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

function Insight({ Icon, label, value, good }: { Icon: ComponentType<SVGProps<SVGSVGElement>>; label: string; value: string; good?: boolean }) {
  return (
    <li className="flex items-center gap-3 py-2.5">
      <span className={`w-8 h-8 rounded-lg flex items-center justify-center ${good === false ? 'bg-brand-50 text-brand-600' : 'bg-leaf-50 text-leaf-600'}`}>
        <Icon className="w-4 h-4" />
      </span>
      <span className="text-[12px] text-ink-500">{label}</span>
      <span className="ml-auto text-[12.5px] font-semibold text-right">{value}</span>
    </li>
  );
}

function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? 'good morning' : h < 17 ? 'good afternoon' : 'good evening';
}
