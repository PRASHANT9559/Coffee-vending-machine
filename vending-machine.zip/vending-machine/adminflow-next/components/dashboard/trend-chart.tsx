'use client';

/* Revenue & Orders trend — dual-axis canvas chart ported from the
   admin-dashboard.html demo (same geometry, peak badge and hover
   crosshair), now driven by real bucket arrays. */

import { useEffect, useRef, useState } from 'react';
import type { RangeKey, TrendData } from '@/lib/dashboard-types';
import { fmtMoney, inr } from '@/lib/format';
import { IconChartLine, IconClock, IconMoney, IconOrders } from '@/components/ui/icons';

interface TrendChartProps {
  ranges: Record<RangeKey, TrendData>;
  range: RangeKey;
  onRange: (r: RangeKey) => void;
}

const RANGE_OPTIONS: RangeKey[] = ['Today', 'This Week', 'This Month'];

/* ₹2,000 → "₹2K" · ₹1,500 → "₹1.5K" · never "₹0K" (demo rule) */
function fmtMoneyShort(v: number): string {
  if (v >= 10_000) return '₹' + Math.round(v / 1000) + 'K';
  if (v >= 1000) return '₹' + (Math.round(v / 100) / 10) + 'K';
  if (v >= 100) return '₹' + Math.round(v);
  return '₹0';
}

function peakLabel(t: TrendData, key: 'revenue' | 'orders'): string {
  const arr = t[key];
  const max = Math.max(...arr);
  if (max === 0) return '—';
  const i = arr.indexOf(max);
  return key === 'revenue' ? `${fmtMoneyShort(max)} / ${t.labels[i]}` : `${max} / ${t.labels[i]}`;
}

export default function TrendChart({ ranges, range, onRange }: TrendChartProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const cvRef = useRef<HTMLCanvasElement>(null);
  const tipRef = useRef<HTMLDivElement>(null);
  const ptsRef = useRef<{ pts: { x: number; y: number }[]; rev: number[]; ord: number[] }>({ pts: [], rev: [], ord: [] });
  const [tip, setTip] = useState<{ x: number; y: number; html: string } | null>(null);

  const t = ranges[range];

  useEffect(() => {
    const cv = cvRef.current;
    const wrap = wrapRef.current;
    if (!cv || !wrap) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      const d = ranges[range];
      if (!d || d.labels.length < 2) return;

      const box = wrap.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const H = 250;
      cv.width = box.width * dpr;
      cv.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, box.width, H);

      const W = box.width;
      const P = { l: 34, r: 34, t: 18, b: 26 };
      const iw = W - P.l - P.r;
      const ih = H - P.t - P.b;

      const rMax = Math.max(...d.revenue) * 1.18 || 1;
      const oMax = Math.max(...d.orders) * 1.18 || 1;
      const n = d.labels.length;
      const x = (i: number) => P.l + (iw * i) / (n - 1);

      // grid + axis labels
      ctx.font = '11px Inter, sans-serif';
      ctx.textBaseline = 'middle';
      for (let g = 0; g <= 4; g++) {
        const y = P.t + ih - (ih * g) / 4;
        ctx.beginPath();
        ctx.strokeStyle = '#EDEFF2';
        ctx.lineWidth = 1;
        ctx.moveTo(P.l, y);
        ctx.lineTo(W - P.r, y);
        ctx.stroke();

        ctx.fillStyle = '#9CA3AF';
        ctx.textAlign = 'right';
        ctx.fillText(fmtMoneyShort((rMax * g) / 4), P.l - 8, y);
        ctx.fillStyle = '#16A34A';
        ctx.textAlign = 'left';
        ctx.fillText(String(Math.round((oMax * g) / 4)), W - P.r + 8, y);
      }

      ctx.fillStyle = '#9CA3AF';
      ctx.textAlign = 'center';
      d.labels.forEach((l, i) => ctx.fillText(l, x(i), H - 10));

      const store = { pts: [] as { x: number; y: number }[], rev: d.revenue, ord: d.orders };

      const series = [
        { vals: d.revenue, max: rMax, stroke: '#F04E23', fill: 'rgba(240,78,35,.10)', r: 4.5, isRev: true },
        { vals: d.orders, max: oMax, stroke: '#16A34A', fill: 'rgba(22,163,74,.08)', r: 3.5, isRev: false },
      ];

      series.forEach(s => {
        const pts = s.vals.map((v, i) => ({ x: x(i), y: P.t + ih - (v / s.max) * ih }));
        if (s.isRev) store.pts = pts;

        // gradient area
        const g = ctx.createLinearGradient(0, P.t, 0, P.t + ih);
        g.addColorStop(0, s.fill);
        g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.beginPath();
        ctx.moveTo(pts[0].x, P.t + ih);
        pts.forEach(p => ctx.lineTo(p.x, p.y));
        ctx.lineTo(pts[pts.length - 1].x, P.t + ih);
        ctx.closePath();
        ctx.fillStyle = g;
        ctx.fill();

        // smooth line
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 0; i < pts.length - 1; i++) {
          const a = pts[i], b = pts[i + 1], mx = (a.x + b.x) / 2;
          ctx.bezierCurveTo(mx, a.y, mx, b.y, b.x, b.y);
        }
        ctx.strokeStyle = s.stroke;
        ctx.lineWidth = 2.2;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
        ctx.stroke();

        // peak marker
        const maxI = s.vals.indexOf(Math.max(...s.vals));
        const p = pts[maxI];
        ctx.beginPath();
        ctx.arc(p.x, p.y, 7, 0, Math.PI * 2);
        ctx.fillStyle = s.stroke + '22';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(p.x, p.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = '#fff';
        ctx.fill();
        ctx.lineWidth = 2.4;
        ctx.strokeStyle = s.stroke;
        ctx.stroke();

        // value badge on revenue peak only
        if (s.isRev && s.vals[maxI] > 0) {
          const label = '₹' + s.vals[maxI].toLocaleString('en-IN');
          ctx.font = '600 11px Inter, sans-serif';
          const w = ctx.measureText(label).width + 14;
          const bx = Math.min(Math.max(p.x - w / 2, P.l), W - P.r - w);
          ctx.fillStyle = s.stroke;
          ctx.beginPath();
          const ro = (ctx as CanvasRenderingContext2D & { roundRect?: (x: number, y: number, w: number, h: number, r: number) => void });
          if (ro.roundRect) ro.roundRect(bx, p.y - 34, w, 20, 5);
          else ctx.rect(bx, p.y - 34, w, 20);
          ctx.fill();
          ctx.fillStyle = '#fff';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(label, bx + w / 2, p.y - 24);
          ctx.textBaseline = 'alphabetic';
        }
      });

      ptsRef.current = store;
    };

    draw();
    const ro = new ResizeObserver(draw);
    ro.observe(wrap);
    window.addEventListener('resize', draw);
    return () => { ro.disconnect(); window.removeEventListener('resize', draw); };
  }, [ranges, range]);

  const onMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const cv = cvRef.current;
    if (!cv) return;
    const box = cv.getBoundingClientRect();
    const mx = e.clientX - box.left;
    const { pts, rev, ord } = ptsRef.current;
    let best: { i: number; dx: number } | null = null;
    pts.forEach((p, i) => {
      const dx = Math.abs(p.x - mx);
      if (dx < 26 && (!best || dx < best.dx)) best = { i, dx };
    });
    if (!best || !('i' in best)) { setTip(null); return; }
    const i = (best as { i: number; dx: number }).i;
    const p = pts[i];
    setTip({
      x: Math.min(p.x + 12, box.width - 170),
      y: p.y - 44,
      html: `<b>${t.labels[i]}</b><br>Revenue ₹${inr(rev[i])} · ${ord[i]} orders`,
    });
  };

  const total = (k: 'revenue' | 'orders') => t[k].reduce((a, b) => a + b, 0);

  return (
    <div className="card p-5">
      <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
        <h2 className="text-[15.5px] font-bold">Revenue &amp; Orders Trend</h2>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-[11.5px] text-ink-500">
            <i className="w-2.5 h-2.5 rounded-full bg-brand-500 inline-block" />Revenue (₹)
          </span>
          <span className="flex items-center gap-1.5 text-[11.5px] text-ink-500">
            <i className="w-2.5 h-2.5 rounded-full bg-leaf-500 inline-block" />Orders
          </span>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        {RANGE_OPTIONS.map(r => (
          <button
            key={r}
            onClick={() => onRange(r)}
            className={`tab px-3.5 py-1.5 text-[12px] ${
              r === range
                ? 'bg-brand-500 text-white font-semibold'
                : 'text-ink-500 hover:bg-page'
            } border border-line/0 transition`}
          >
            {r}
          </button>
        ))}
      </div>

      <div className="relative" ref={wrapRef}>
        <canvas ref={cvRef} style={{ display: 'block', width: '100%', height: 250 }} />
        <div
          ref={tipRef}
          className="chart-tip absolute z-10 bg-ink-900 text-white text-[11px] rounded-lg px-2.5 py-1.5 whitespace-nowrap"
          style={{
            opacity: tip ? 1 : 0,
            left: tip?.x ?? 0,
            top: tip?.y ?? 0,
          }}
          dangerouslySetInnerHTML={{ __html: tip?.html ?? '' }}
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 mt-3 border-t border-line">
        <div className="flex items-center gap-2.5">
          <span className="w-8 h-8 rounded-lg bg-brand-50 text-brand-600 flex items-center justify-center shrink-0">
            <IconMoney className="w-4 h-4" />
          </span>
          <div className="leading-tight">
            <p className="text-[11px] text-ink-500">Revenue · {range}</p>
            <p className="text-[13px] font-bold">₹{inr(total('revenue'))}</p>
          </div>
        </div>
        <div className="flex items-center gap-2.5">
          <span className="w-8 h-8 rounded-lg bg-brand-50 text-brand-400 flex items-center justify-center shrink-0">
            <IconOrders className="w-4 h-4" />
          </span>
          <div className="leading-tight">
            <p className="text-[11px] text-ink-500">Orders · {range}</p>
            <p className="text-[13px] font-bold">{inr(total('orders'))}</p>
          </div>
        </div>
        <div className="flex items-center gap-2.5">
          <span className="w-8 h-8 rounded-lg bg-leaf-50 text-leaf-500 flex items-center justify-center shrink-0">
            <IconChartLine className="w-4 h-4" />
          </span>
          <div className="leading-tight">
            <p className="text-[11px] text-ink-500">Peak Revenue</p>
            <p className="text-[13px] font-bold">{peakLabel(t, 'revenue')}</p>
          </div>
        </div>
        <div className="flex items-center gap-2.5">
          <span className="w-8 h-8 rounded-lg bg-amber2-50 text-amber2-500 flex items-center justify-center shrink-0">
            <IconClock className="w-4 h-4" />
          </span>
          <div className="leading-tight">
            <p className="text-[11px] text-ink-500">Peak Orders</p>
            <p className="text-[13px] font-bold">{peakLabel(t, 'orders')}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
