'use client';

/* Live machine strip — one chip per machine with temp / litres /
   cups, pulse on fresh pings, and a last-sync clock like the demo. */

import { useEffect, useState } from 'react';
import Link from 'next/link';
import type { MachineChip } from '@/lib/dashboard-types';

function chipIcon(m: MachineChip): { emoji: string; cls: string } {
  return m.mode === 'cold'
    ? { emoji: '🧊', cls: 'bg-amber2-50 text-amber2-600' }
    : { emoji: '🏪', cls: 'bg-brand-50 text-brand-600' };
}

function Chip({ m }: { m: MachineChip }) {
  const ic = chipIcon(m);
  const temp = m.tempC != null ? `${m.tempC.toFixed(1)}°C` : '--';
  const litres = m.litres != null ? `${Math.round(m.litres)}L` : '--L';
  return (
    <Link
      href={`/machines/${m.id}/overview`}
      title={`Open ${m.code} overview`}
      className="flex items-center gap-2.5 rounded-xl px-2 py-1 -mx-2 hover:bg-page transition"
    >
      <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-[15px] ${ic.cls}`}>{ic.emoji}</span>
      <div className="leading-tight">
        <p className="text-[12.5px] font-semibold text-ink-900">{m.code} · {m.name}</p>
        <p className="text-[11px] text-ink-500">{temp} · {litres} · {m.cups} cups</p>
      </div>
      {m.online ? (
        <span className={`ml-2 text-[10px] font-semibold px-2 py-0.5 rounded-md ${m.live ? 'bg-leaf-50 text-leaf-600' : 'bg-amber2-50 text-amber2-600'}`}>
          ONLINE
        </span>
      ) : (
        <span className="ml-2 text-[10px] font-semibold px-2 py-0.5 rounded-md bg-ink-300/20 text-ink-500">
          OFFLINE
        </span>
      )}
    </Link>
  );
}

export default function LiveStrip({ machines, source }: { machines: MachineChip[]; source: string }) {
  const [ticks, setTicks] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTicks(s => s + 1), 10_000);
    return () => clearInterval(t);
  }, []);

  const anyLive = machines.some(m => m.live);

  return (
    <div className="card p-3.5 flex flex-wrap items-center gap-x-6 gap-y-3">
      <div className="flex items-center gap-2 pr-6 border-r border-line">
        <span className={`w-2 h-2 rounded-full inline-block ${anyLive ? 'pulse-dot bg-leaf-500' : 'bg-ink-300'}`} />
        <span className="text-[13px] font-semibold">Live</span>
      </div>

      {machines.length === 0 && (
        <span className="text-[12.5px] text-ink-400">No machines configured yet.</span>
      )}
      {machines.map(m => <Chip key={m.id} m={m} />)}

      <div className="ml-auto flex items-center gap-2">
        <span
          title={
            source === 'rust'
              ? 'Live data routed via Rust Axum microservice (:8080).'
              : source === 'demo'
              ? 'Rust microservice offline — showing design-demo dataset.'
              : 'Read live from Supabase.'
          }
          className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${
            source === 'rust'
              ? 'bg-brand-50 text-brand-600 border-brand-100'
              : source === 'demo'
              ? 'bg-amber2-50 text-amber2-600 border-amber2-100'
              : 'bg-leaf-50 text-leaf-600 border-leaf-100'
          }`}
        >
          {source === 'rust' ? 'LIVE · RUST SERVICE' : source === 'demo' ? 'DEMO DATA' : 'LIVE · SUPABASE'}
        </span>
        <span className="text-[11.5px] text-ink-500">Last sync</span>
        <span className="text-[11.5px] font-semibold font-mono">{ticks === 0 ? 'just now' : `${ticks * 10}s ago`}</span>
      </div>
    </div>
  );
}
