'use client';

/* KPI card — icon chip, sparkline, animated count-up, delta row.
   Mirrors the four stat cards in admin-dashboard.html. */

import { useEffect, useRef, useState } from 'react';
import type { ComponentType, SVGProps } from 'react';
import type { TrendData } from '@/lib/dashboard-types';
import { inr, fmtPct } from '@/lib/format';
import { IconArrowUp } from '@/components/ui/icons';

type IconC = ComponentType<SVGProps<SVGSVGElement>>;

interface StatCardProps {
  Icon: IconC;
  tint: 'brand' | 'brand400' | 'leaf' | 'amber';
  title: string;
  value: number;
  prefix?: string;              // "₹"
  suffix?: { text: string; muted: string };  // "2 / 2" style
  delta: number | null;
  deltaLabel?: string;
  spark: TrendData | null;
  sparkColor: string;
  /** replaces the delta row (used by the "100% uptime" card) */
  footnote?: React.ReactNode;
  delay?: number;               // .rise stagger, seconds
}

const TINTS: Record<StatCardProps['tint'], string> = {
  brand:   'bg-brand-50 text-brand-600',
  brand400:'bg-brand-50 text-brand-400',
  leaf:    'bg-leaf-50 text-leaf-500',
  amber:   'bg-amber2-50 text-amber2-500',
};

/** min-max normalised sparkline polyline (like the demo baked paths) */
function Sparkline({ spark, color }: { spark: TrendData | null; color: string }) {
  if (!spark || spark.revenue.length < 2) {
    return <svg className="w-[72px] h-8" viewBox="0 0 72 32" fill="none" />;
  }
  const v = spark.revenue;
  const max = Math.max(...v), min = Math.min(...v);
  const span = max - min || 1;
  const pts = v.map((x, i) => [
    1 + (70 * i) / (v.length - 1),
    27 - (x - min) / span * 22,   // keep inside 5..27
  ] as const);
  const line = pts.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
  const area = `${line}L${pts[pts.length - 1][0].toFixed(1)} 32H1z`;
  const id = `sp-${color.replace('#', '')}`;
  return (
    <svg className="w-[72px] h-8" viewBox="0 0 72 32" fill="none">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".12" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${id})`} />
      <path d={line} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function StatCard({
  Icon, tint, title, value, prefix = '', suffix, delta, deltaLabel = 'vs Yesterday',
  spark, sparkColor, footnote, delay = 0,
}: StatCardProps) {
  const [shown, setShown] = useState(value);   // SSR paints the final value …
  const raf = useRef<number>(0);

  useEffect(() => {                            // … then we count up on mount/changes
    const target = Math.max(0, Math.round(value * 100) / 100);
    const t0 = performance.now();
    const dur = 900;
    let cancelled = false;
    const step = (ts: number) => {
      if (cancelled) return;
      const p = Math.min((ts - t0) / dur, 1);
      const e = 1 - Math.pow(1 - p, 3);
      setShown(target * e);
      if (p < 1) raf.current = requestAnimationFrame(step);
      else setShown(target);
    };
    raf.current = requestAnimationFrame(step);
    return () => { cancelled = true; cancelAnimationFrame(raf.current); };
  }, [value]);

  const whole = Math.round(shown) === shown;

  return (
    <div className="card p-4 rise" style={{ animationDelay: `${delay}s` }}>
      <div className="flex items-start justify-between">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${TINTS[tint]}`}>
          <Icon className="w-5 h-5" />
        </div>
        <Sparkline spark={spark} color={sparkColor} />
      </div>

      <p className="mt-3 text-[12.5px] font-medium text-ink-500">{title}</p>
      <p className="mt-0.5 text-[25px] font-bold tracking-tight">
        {prefix}
        {whole ? inr(shown) : Math.round(shown * 10) / 10}
        {suffix && (
          <span className="text-[15px] font-medium text-ink-400"> / {suffix.text}</span>
        )}
      </p>

      {footnote ?? (
        <p className={`mt-1.5 flex items-center gap-1 text-[11.5px] ${delta == null ? 'text-ink-400' : 'text-leaf-600'} font-medium`}>
          {delta != null && (
            <IconArrowUp className={`w-3 h-3 ${delta < 0 ? 'rotate-180' : ''}`} />
          )}
          {delta != null ? fmtPct(Math.abs(delta)) : '—'} <span className="text-ink-400 font-normal">{deltaLabel}</span>
        </p>
      )}
    </div>
  );
}
