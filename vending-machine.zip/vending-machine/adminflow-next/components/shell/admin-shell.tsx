'use client';

/* Persistent admin shell: fixed sidebar + scrim on mobile,
   sticky topbar, read-only maintenance overlay per guard flow,
   toast dock. Mounted once per navigation — never remounted
   between modules. */

import { useState } from 'react';
import Sidebar from './sidebar';
import Topbar from './topbar';
import ToastProvider from '@/components/ui/toast';
import type { BellItem } from '@/lib/mock/settings';
import type { AdminSession } from '@/lib/auth';

export default function AdminShell({
  children, admin, maintenance, notifications,
}: {
  children: React.ReactNode;
  admin: AdminSession | null;
  maintenance: boolean;
  notifications: BellItem[];
}) {
  const [open, setOpen] = useState(false);

  return (
    <ToastProvider>
      <div className="flex min-h-screen">
        <Sidebar open={open} onNavigate={() => setOpen(false)} />

        {/* scrim */}
        <div
          onClick={() => setOpen(false)}
          className={`fixed inset-0 bg-black/40 z-30 transition-opacity lg:hidden ${
            open ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        />

        <main className="flex-1 min-w-0 flex flex-col">
          <Topbar onMenu={() => setOpen(true)} admin={admin} notifications={notifications} />
          {maintenance && (
            <div className="bg-amber2-50 border-b border-amber2-100 px-5 py-2.5 text-center text-[12px] font-semibold text-amber2-600">
              ⚠ Maintenance mode is ON — every route renders read-only. Clear it in Settings → Security.
            </div>
          )}
          {children}
        </main>
      </div>
    </ToastProvider>
  );
}
