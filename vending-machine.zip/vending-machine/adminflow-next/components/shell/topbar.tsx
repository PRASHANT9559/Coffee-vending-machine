'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  IconBell, IconChevronDown, IconMenu, IconSearch, IconSettings, IconLogout,
  IconCup, IconDroplet, IconSupport, IconMoney,
} from '@/components/ui/icons';
import { logout } from '@/lib/actions';
import { RoleTag } from '@/components/ui/kit';
import type { BellItem } from '@/lib/mock/settings';
import type { AdminSession } from '@/lib/auth';

const TITLES: [string, string][] = [
  ['/', 'Dashboard'],
  ['/machines', 'Machines'],
  ['/orders', 'Orders'],
  ['/customers', 'Customers'],
  ['/inventory', 'Inventory'],
  ['/analytics', 'Analytics'],
  ['/marketing', 'Marketing'],
  ['/support', 'Support'],
  ['/settings', 'Settings'],
];

function titleFor(pathname: string): string {
  const hit = TITLES.find(([route]) => pathname === route || pathname.startsWith(`${route}/`));
  return hit?.[1] ?? 'Dashboard';
}

function bellIcon(name: string) {
  const cls = 'w-4 h-4 text-brand-600';
  if (name === 'stock') return <IconCup className={cls} />;
  if (name === 'tank') return <IconDroplet className={cls} />;
  if (name === 'ticket') return <IconSupport className={cls} />;
  return <IconMoney className={cls} />;
}

export default function Topbar({
  onMenu, admin, notifications,
}: {
  onMenu: () => void;
  admin: AdminSession | null;
  notifications: BellItem[];
}) {
  const pathname = usePathname();
  const [bellOpen, setBellOpen] = useState(false);

  const initials = (admin?.name ?? 'MC')
    .split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

  return (
    <header className="h-[68px] bg-white border-b border-line flex items-center gap-4 px-5 shrink-0 sticky top-0 z-20">
      <button
        onClick={onMenu}
        aria-label="Open menu"
        className="lg:hidden w-9 h-9 rounded-lg border border-line flex items-center justify-center"
      >
        <IconMenu className="w-5 h-5" />
      </button>

      <div className="hidden sm:block text-[15px] font-semibold">{titleFor(pathname)}</div>

      <div className="flex-1" />

      <div className="relative hidden md:block">
        <IconSearch className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
        <input
          type="text"
          placeholder="Search machines, orders, customers…"
          className="w-[250px] pl-9 pr-3 py-2 text-[13px] bg-page border border-line rounded-lg outline-none focus:border-brand-400 focus:bg-white transition"
        />
      </div>

      {/* deep-link bell — every notification lands on the exact
          record with its tab pre-opened (routing spec Diagram 04) */}
      <div className="relative">
        <button
          aria-label="Notifications"
          onClick={() => setBellOpen(o => !o)}
          className="w-9 h-9 rounded-lg border border-line flex items-center justify-center hover:bg-page transition"
        >
          <IconBell className="w-[18px] h-[18px]" />
          {notifications.length > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-brand-500 text-white text-[10px] font-bold flex items-center justify-center">
              {notifications.length}
            </span>
          )}
        </button>

        {bellOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setBellOpen(false)} />
            <div className="absolute right-0 top-11 z-20 w-[340px] card p-2 shadow-pop rise">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-400 px-2.5 pt-1.5 pb-1">
                Alerts · deep links pre-armed
              </p>
              {notifications.map(n => (
                <Link
                  key={n.href + n.title}
                  href={n.href}
                  onClick={() => setBellOpen(false)}
                  className="flex items-start gap-3 px-2.5 py-2.5 rounded-lg hover:bg-page transition"
                >
                  <span className="w-8 h-8 rounded-lg bg-brand-50 flex items-center justify-center shrink-0">
                    {bellIcon(n.icon)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[12.5px] font-semibold text-ink-900">{n.title}</span>
                    <span className="block text-[11px] text-ink-500 truncate">{n.sub}</span>
                  </span>
                  <span className="text-[10px] font-bold text-brand-600 whitespace-nowrap mt-1">{n.cta}</span>
                </Link>
              ))}
              <p className="text-[10px] text-ink-400 px-2.5 pb-1 pt-2 border-t border-line mt-1">
                One tap lands on the exact machine/order/ticket with the relevant tab open.
              </p>
            </div>
          </>
        )}
      </div>

      <Link
        href="/settings/general"
        aria-label="Settings"
        className="w-9 h-9 rounded-lg border border-line flex items-center justify-center hover:bg-page transition"
      >
        <IconSettings className="w-[18px] h-[18px]" />
      </Link>

      <div className="flex items-center gap-2.5 pl-3 ml-1 border-l border-line">
        <span className="w-9 h-9 rounded-full bg-brand-500 text-white font-bold text-[12px] flex items-center justify-center">
          {initials}
        </span>
        <div className="hidden sm:block leading-tight">
          <p className="text-[13px] font-semibold">{admin?.name ?? '—'}</p>
          <div className="mt-0.5"><RoleTag role={admin?.role ?? 'viewer'} /></div>
        </div>
      </div>

      <form action={logout}>
        <button
          type="submit"
          title="Sign out"
          className="w-9 h-9 rounded-lg border border-line flex items-center justify-center hover:bg-brand-50 hover:text-brand-600 transition"
        >
          <IconLogout className="w-[17px] h-[17px]" />
        </button>
      </form>
    </header>
  );
}
