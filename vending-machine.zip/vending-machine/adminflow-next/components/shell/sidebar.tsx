'use client';

/* Persistent admin shell — the sidebar stays mounted across every
   module (per admin-routing-workflow.html Diagram 01) so filters,
   scroll position and live state survive navigation. */

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  IconAnalytics,
  IconCustomers,
  IconDashboard,
  IconInventory,
  IconMachine,
  IconMarketing,
  IconOrders,
  IconSettings,
  IconSupport,
} from '@/components/ui/icons';
import type { ComponentType, SVGProps } from 'react';

interface NavItem {
  href: string;
  label: string;
  Icon: ComponentType<SVGProps<SVGSVGElement>>;
  badge?: { text: string; tone?: 'leaf' | 'brand' | 'solid' };
}

const GROUPS: { title: string; items: NavItem[] }[] = [
  {
    title: 'Operations',
    items: [
      { href: '/', label: 'Dashboard', Icon: IconDashboard },
      { href: '/machines', label: 'Machines', Icon: IconMachine, badge: { text: '2', tone: 'leaf' } },
      { href: '/orders', label: 'Orders', Icon: IconOrders, badge: { text: '168', tone: 'brand' } },
      { href: '/customers', label: 'Customers', Icon: IconCustomers },
      { href: '/inventory', label: 'Inventory', Icon: IconInventory },
    ],
  },
  {
    title: 'Growth',
    items: [
      { href: '/analytics', label: 'Analytics', Icon: IconAnalytics },
      { href: '/marketing', label: 'Marketing', Icon: IconMarketing },
      { href: '/support', label: 'Support', Icon: IconSupport, badge: { text: '4', tone: 'solid' } },
      { href: '/settings', label: 'Settings', Icon: IconSettings },
    ],
  },
];

function isActive(pathname: string, href: string): boolean {
  if (href === '/') return pathname === '/';
  return pathname === href || pathname.startsWith(`${href}/`);
}

export default function Sidebar({ open, onNavigate }: { open: boolean; onNavigate: () => void }) {
  const pathname = usePathname();

  return (
    <aside
      className={`w-[248px] shrink-0 bg-white border-r border-line flex flex-col
        fixed lg:static inset-y-0 z-40 transition-transform duration-200
        ${open ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}
    >
      {/* brand */}
      <div className="h-[68px] flex items-center gap-2.5 px-5 border-b border-line shrink-0">
        <div className="w-9 h-9 rounded-lg bg-brand-500 flex items-center justify-center text-white font-bold text-[15px]">M</div>
        <div className="leading-tight">
          <p className="text-[15px] font-bold tracking-tight">
            Manhattan<span className="text-brand-500">Coffee</span>
          </p>
          <p className="text-[11px] text-ink-500">Vending Network</p>
        </div>
      </div>

      {/* nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {GROUPS.map(group => (
          <div key={group.title}>
            <p className="px-3 pb-2 pt-1 text-[10px] font-semibold uppercase tracking-wider text-ink-400">
              {group.title}
            </p>
            {group.items.map(({ href, label, Icon, badge }) => {
              const active = isActive(pathname, href);
              return (
                <Link
                  key={href}
                  href={href}
                  onClick={onNavigate}
                  className={`nav-item flex items-center gap-3 px-3 py-2.5 rounded-lg text-[13.5px]
                    ${active
                      ? 'bg-brand-500 text-white font-semibold [&_svg]:opacity-100'
                      : 'text-ink-700 [&_svg]:opacity-55 hover:bg-page'}`}
                >
                  <Icon className="nav-ico w-[18px] h-[18px] shrink-0 transition-opacity" />
                  {label}
                  {badge && (
                    <span
                      className={`ml-auto text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${
                        active
                          ? 'bg-white/15 text-white'
                          : badge.tone === 'solid'
                            ? 'bg-brand-500 text-white'
                            : badge.tone === 'leaf'
                              ? 'bg-leaf-50 text-leaf-600'
                              : 'bg-brand-50 text-brand-600'
                      }`}
                    >
                      {badge.text}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      {/* upgrade card */}
      <div className="p-3 shrink-0">
        <div className="rounded-xl bg-brand-50 border border-brand-100 p-4 relative overflow-hidden">
          <div className="text-[26px] leading-none mb-2">☕</div>
          <p className="text-[13px] font-bold">Go Pro</p>
          <p className="text-[11.5px] text-ink-500 mt-1 leading-relaxed">
            Unlock multi-machine fleet, subscriptions &amp; advanced fraud rules.
          </p>
          <button className="mt-3 w-full bg-brand-500 hover:bg-brand-600 text-white text-[12px] font-semibold rounded-lg py-2 transition">
            Upgrade Now
          </button>
        </div>
      </div>
    </aside>
  );
}
