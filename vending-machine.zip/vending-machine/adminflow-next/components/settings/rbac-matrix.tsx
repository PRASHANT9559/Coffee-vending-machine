'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import {
  ROLES, ROLE_META, roleCan, CAP_MIN_LABEL,
  type Role, type Cap,
} from '@/lib/auth';
import { emitToast } from '@/components/ui/toast';
import { inviteAdminUser, resetAdminMfa } from '@/lib/actions';
import {
  IconSearch, IconCheck, IconShield, IconUsers, IconPlus,
} from '@/components/ui/icons';

interface CapDetail {
  cap: Cap;
  label: string;
  category: 'IoT & Hardware' | 'Customer & Support' | 'Financial & P&L' | 'Governance';
  desc: string;
}

const CAPABILITIES: CapDetail[] = [
  // IoT & Hardware
  { cap: 'machines', label: 'Machine Control & Locks', category: 'IoT & Hardware', desc: 'Mutate telemetry, emergency lock/unlock, reboot, and tank calibration.' },
  { cap: 'hardware', label: 'Firmware & OTA Flashing', category: 'IoT & Hardware', desc: 'Low-level ESP32 flashing, secure boot signing, and mass OTA rollouts.' },
  { cap: 'cctv', label: 'Dual CCTV & Evidence Clips', category: 'IoT & Hardware', desc: 'Nozzle dispense cam and front user cam live feeds & clip inspection.' },
  { cap: 'inventoryRead', label: 'Inventory & Tank Telemetry', category: 'IoT & Hardware', desc: 'View milk, beans, syrups, and cup dispenser stock levels.' },

  // Customer & Support
  { cap: 'customersRead', label: 'Customer 360° Profiles', category: 'Customer & Support', desc: 'Access customer roster, gamification streak, and cohort telemetry.' },
  { cap: 'support', label: 'Support & Dispute Desk', category: 'Customer & Support', desc: 'Manage WhatsApp intake, claim tickets, and resolve no-coffee complaints.' },
  { cap: 'marketing', label: 'Campaigns & Push Broadcasts', category: 'Customer & Support', desc: 'Create promotional vouchers, referral programs, and customer push notifications.' },

  // Financial & P&L
  { cap: 'wallet', label: 'Wallet Float & Manual Credits', category: 'Financial & P&L', desc: 'Inspect customer wallet ledger and perform manual credit adjustments.' },
  { cap: 'refunds', label: 'Refund Payout Authorization', category: 'Financial & P&L', desc: 'Release cash and wallet refunds for verified machine dispense failures.' },
  { cap: 'inventoryWrite', label: 'Cost Basis & Stock Write-Offs', category: 'Financial & P&L', desc: 'Record ingredient procurement prices and physical wastage write-offs.' },
  { cap: 'profitability', label: 'Unit Economics & Margins', category: 'Financial & P&L', desc: 'Deep dive into per-cup gross margins, auxiliary ad revenue, CAC and LTV.' },

  // Governance
  { cap: 'blacklist', label: 'Security Blacklist Control', category: 'Governance', desc: 'Flag and ban abusive device IDs or high-fraud phone numbers.' },
  { cap: 'settings', label: 'Fleet Defaults & RBAC Admin', category: 'Governance', desc: 'Configure system-wide temperature defaults and provision team accounts.' },
];

export default function RbacMatrix({ isOwner }: { isOwner: boolean }) {
  const router = useRouter();
  const [activeRole, setActiveRole] = useState<Role | 'all'>('all');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isInviteOpen, setIsInviteOpen] = useState(false);

  // Invite Form State
  const [inviteName, setInviteName] = useState('');
  const [invitePhone, setInvitePhone] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<Role>('support');
  const [isSubmitting, startTransition] = useTransition();

  const filteredCaps = CAPABILITIES.filter(c => {
    if (categoryFilter !== 'all' && c.category !== categoryFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        c.label.toLowerCase().includes(q) ||
        c.cap.toLowerCase().includes(q) ||
        c.desc.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim() || !invitePhone.trim()) {
      emitToast('Name and phone number are required.', 'warn');
      return;
    }

    startTransition(async () => {
      const res = await inviteAdminUser(inviteName, invitePhone, inviteEmail, inviteRole);
      if (res.ok) {
        emitToast(res.message, 'ok');
        setIsInviteOpen(false);
        setInviteName('');
        setInvitePhone('');
        setInviteEmail('');
        router.refresh();
      } else {
        emitToast(res.message, 'warn');
      }
    });
  };

  return (
    <div className="space-y-4">
      {/* ── Matrix Controls Bar ──────────────────────────────── */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-page/70 p-3 rounded-xl border border-line">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[240px]">
          <div className="relative min-w-[180px] max-w-[280px]">
            <IconSearch className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search 13 capabilities..."
              className="w-full pl-9 pr-3 py-1.5 text-[12px] bg-white border border-line rounded-lg outline-none focus:border-brand-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="text-[12px] bg-white border border-line rounded-lg px-2.5 py-1.5 font-medium outline-none text-ink-700"
          >
            <option value="all">All 4 Domains</option>
            <option value="IoT & Hardware">IoT & Hardware</option>
            <option value="Customer & Support">Customer & Support</option>
            <option value="Financial & P&L">Financial & P&L</option>
            <option value="Governance">Governance</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          {/* Highlight Role Pills */}
          <div className="hidden sm:inline-flex items-center bg-white border border-line rounded-lg p-0.5 gap-0.5">
            <button
              type="button"
              onClick={() => setActiveRole('all')}
              className={`px-2 py-1 rounded text-[11px] font-semibold transition ${
                activeRole === 'all' ? 'bg-ink-900 text-white' : 'text-ink-600 hover:text-ink-900'
              }`}
            >
              All Roles
            </button>
            {ROLES.map(r => (
              <button
                key={r}
                type="button"
                onClick={() => setActiveRole(r)}
                className={`px-2 py-1 rounded text-[11px] font-semibold capitalize transition ${
                  activeRole === r ? 'bg-brand-600 text-white' : 'text-ink-600 hover:text-ink-900'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          {isOwner && (
            <button
              type="button"
              onClick={() => setIsInviteOpen(true)}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-brand-600 hover:bg-brand-500 text-white px-3 py-1.5 rounded-lg shadow-xs transition"
            >
              <IconPlus className="w-3.5 h-3.5" /> Invite Staff
            </button>
          )}
        </div>
      </div>

      {/* ── 6-Role × 13-Capability Matrix Grid Table ──────────── */}
      <div className="overflow-x-auto -mx-1 px-1 border border-line rounded-xl bg-white shadow-xs">
        <table className="w-full border-collapse text-[12px]">
          <thead>
            <tr className="border-b border-line bg-page/40">
              <th className="py-3 px-4 text-left font-bold text-[11px] uppercase tracking-wider text-ink-500 min-w-[220px]">
                Capability & Domain
              </th>
              <th className="py-3 px-3 text-left font-bold text-[10px] uppercase tracking-wider text-ink-400 w-24">
                Min Role
              </th>
              {ROLES.map(role => {
                const meta = ROLE_META[role];
                const isHighlighted = activeRole === role;
                return (
                  <th
                    key={role}
                    onClick={() => setActiveRole(role === activeRole ? 'all' : role)}
                    className={`py-3 px-3 text-center cursor-pointer transition-colors ${
                      isHighlighted ? 'bg-brand-50/80 text-brand-900 font-black' : 'text-ink-700'
                    }`}
                  >
                    <span className="block text-[11.5px] font-bold capitalize">{meta.label}</span>
                    <span className="block text-[9.5px] font-normal text-ink-400 mt-0.5">{role}</span>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#F2F4F7]">
            {filteredCaps.map(c => {
              const minRole = CAP_MIN_LABEL[c.cap];
              return (
                <tr key={c.cap} className="hover:bg-page/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-ink-900">{c.label}</div>
                    <div className="text-[11px] text-ink-500 mt-0.5 leading-snug">{c.desc}</div>
                    <div className="mt-1">
                      <span className="text-[9.5px] font-semibold uppercase tracking-wider px-1.5 py-0.5 bg-page rounded text-ink-400 border border-line/60">
                        {c.category}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-3 align-middle">
                    <span className="inline-block text-[10px] font-bold px-1.5 py-0.5 rounded bg-ink-100 text-ink-700">
                      {minRole}+
                    </span>
                  </td>
                  {ROLES.map(role => {
                    const hasCap = roleCan(role, c.cap);
                    const isHighlighted = activeRole === role;
                    return (
                      <td
                        key={role}
                        className={`py-3 px-3 text-center align-middle transition-colors ${
                          isHighlighted ? 'bg-brand-50/40' : ''
                        }`}
                      >
                        {hasCap ? (
                          <span className="inline-flex items-center justify-center gap-1 text-[10.5px] font-bold text-leaf-700 bg-leaf-50 border border-leaf-200/60 px-2 py-0.5 rounded-md">
                            <IconCheck className="w-3 h-3 text-leaf-600" /> Granted
                          </span>
                        ) : (
                          <span className="text-[11px] font-medium text-ink-300">
                            — Denied
                          </span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* ── Invite Administrator Modal ───────────────────────── */}
      {isInviteOpen && (
        <div className="fixed inset-0 bg-ink-950/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-line space-y-4">
            <div className="flex items-center justify-between border-b border-line pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-brand-50 text-brand-600 rounded-lg">
                  <IconUsers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-[15px] text-ink-900">Invite Administrator</h3>
                  <p className="text-[11.5px] text-ink-500">Provision console access with RBAC role binding</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsInviteOpen(false)}
                className="text-ink-400 hover:text-ink-800 text-[18px] font-bold px-2"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleInviteSubmit} className="space-y-3.5">
              <div>
                <label className="block text-[11.5px] font-bold uppercase tracking-wider text-ink-600 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={inviteName}
                  onChange={e => setInviteName(e.target.value)}
                  placeholder="e.g. Anand Kulkarni"
                  className="w-full px-3 py-2 text-[12.5px] border border-line rounded-lg outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-[11.5px] font-bold uppercase tracking-wider text-ink-600 mb-1">
                  Mobile Phone (SMS OTP) *
                </label>
                <input
                  type="tel"
                  required
                  value={invitePhone}
                  onChange={e => setInvitePhone(e.target.value)}
                  placeholder="+91 98XXX XXXXX"
                  className="w-full px-3 py-2 text-[12.5px] font-mono border border-line rounded-lg outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-[11.5px] font-bold uppercase tracking-wider text-ink-600 mb-1">
                  Staff Email (Optional)
                </label>
                <input
                  type="email"
                  value={inviteEmail}
                  onChange={e => setInviteEmail(e.target.value)}
                  placeholder="staff@manhattancoffee.in"
                  className="w-full px-3 py-2 text-[12.5px] border border-line rounded-lg outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-[11.5px] font-bold uppercase tracking-wider text-ink-600 mb-1">
                  Assigned RBAC Role *
                </label>
                <select
                  value={inviteRole}
                  onChange={e => setInviteRole(e.target.value as Role)}
                  className="w-full px-3 py-2 text-[12.5px] font-medium border border-line rounded-lg outline-none focus:border-brand-500 bg-white"
                >
                  <option value="viewer">Viewer (Read-Only Console)</option>
                  <option value="support">Support (Dispute Desk & Telemetry)</option>
                  <option value="ops">Ops (Field Ops & Machine Commands)</option>
                  <option value="marketing">Marketing (Campaigns & Vouchers)</option>
                  <option value="finance">Finance (Refunds & Ledger Ledgers)</option>
                </select>
                <p className="text-[11px] text-ink-400 mt-1">
                  {ROLE_META[inviteRole].blurb}. Enforces two-factor cryptographic challenges on login.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-line">
                <button
                  type="button"
                  onClick={() => setIsInviteOpen(false)}
                  className="px-4 py-2 text-[12.5px] font-semibold text-ink-600 hover:bg-page rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-[12.5px] font-semibold bg-brand-600 hover:bg-brand-500 text-white rounded-lg transition shadow-xs"
                >
                  {isSubmitting ? 'Provisioning…' : 'Send Console Invite'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
