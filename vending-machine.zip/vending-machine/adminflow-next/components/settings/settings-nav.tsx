'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export const SETTINGS_TABS = [
  { href: '/settings/general', label: 'Brand & General' },
  { href: '/settings/machines', label: 'Fleet Defaults' },
  { href: '/settings/payments', label: 'Payment Gateways' },
  { href: '/settings/notifications', label: 'Alert Rules' },
  { href: '/settings/team', label: 'Team & Roles' },
  { href: '/settings/integrations', label: 'Integrations' },
  { href: '/settings/security', label: 'Security & Secrets' },
  { href: '/settings/appearance', label: 'Theme' },
  { href: '/settings/billing', label: 'Billing' },
];

export default function SettingsNav() {
  const pathname = usePathname();

  return (
    <nav className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1 mb-6 border-b border-line">
      {SETTINGS_TABS.map(tab => {
        const active = pathname === tab.href;
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`shrink-0 text-[12.5px] font-semibold px-3 py-2 border-b-2 -mb-px transition ${
              active
                ? 'border-brand-500 text-brand-600 font-bold'
                : 'border-transparent text-ink-600 hover:text-ink-900 hover:border-line'
            }`}
          >
            {tab.label}
          </Link>
        );
      })}
    </nav>
  );
}
