'use client';

import { useState, useRef } from 'react';
import { IconVideo } from '@/components/ui/icons';

interface EvidenceVideoPlayerProps {
  clipUrl?: string;
  clipLenS?: number;
  ticketNo?: string;
}

export default function EvidenceVideoPlayer({
  clipUrl,
  clipLenS = 30,
  ticketNo = 'TKT-EVIDENCE',
}: EvidenceVideoPlayerProps) {
  const [channel, setChannel] = useState<'dispense' | 'front'>('dispense');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const effectiveUrl =
    clipUrl && clipUrl.startsWith('http')
      ? clipUrl
      : 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
    }
  };

  const formatTime = (secs: number) => {
    const s = Math.floor(secs);
    const ms = Math.floor((secs - s) * 100);
    return `00:${s.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-3">
      {/* Channel Switcher */}
      <div className="flex items-center justify-between text-[11.5px]">
        <div className="flex gap-1.5 p-1 bg-page rounded-lg border border-line">
          <button
            type="button"
            onClick={() => setChannel('dispense')}
            className={`px-3 py-1 rounded font-semibold transition ${
              channel === 'dispense'
                ? 'bg-brand-500 text-white shadow-sm'
                : 'text-ink-600 hover:text-ink-900'
            }`}
          >
            🎥 Dispense Cam (Nozzle)
          </button>
          <button
            type="button"
            onClick={() => setChannel('front')}
            className={`px-3 py-1 rounded font-semibold transition ${
              channel === 'front'
                ? 'bg-brand-500 text-white shadow-sm'
                : 'text-ink-600 hover:text-ink-900'
            }`}
          >
            👤 Front User Camera
          </button>
        </div>

        <span className="font-mono text-[10.5px] text-leaf-600 bg-leaf-50 border border-leaf-100 px-2 py-0.5 rounded font-semibold">
          ±20ms Clock Matched
        </span>
      </div>

      {/* Video Viewport */}
      <div className="aspect-video rounded-xl bg-ink-950 border border-line relative overflow-hidden group shadow-inner">
        <video
          ref={videoRef}
          src={effectiveUrl}
          playsInline
          onTimeUpdate={handleTimeUpdate}
          onEnded={() => setIsPlaying(false)}
          className="w-full h-full object-cover"
        />

        {/* Center Play Overlay if paused */}
        {!isPlaying && (
          <div
            onClick={togglePlay}
            className="absolute inset-0 bg-ink-950/50 backdrop-blur-[1px] flex flex-col items-center justify-center cursor-pointer transition"
          >
            <div className="w-14 h-14 rounded-full bg-brand-500/90 text-white flex items-center justify-center shadow-lg hover:scale-105 transition">
              <svg className="w-6 h-6 ml-0.5 fill-current" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
            <p className="mt-3 text-white font-semibold text-[13px] tracking-wide">
              {channel === 'dispense' ? 'Dispense Nozzle Camera' : 'Front Customer Camera'}
            </p>
            <p className="text-ink-300 font-mono text-[11px] mt-0.5">30s Evidence Clip · Synchronized Extract</p>
          </div>
        )}

        {/* Bottom HUD */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-ink-950/90 via-ink-950/60 to-transparent p-3 pt-6 flex flex-col gap-1.5 opacity-90 group-hover:opacity-100 transition">
          {/* Timeline slider */}
          <input
            type="range"
            min={0}
            max={clipLenS}
            step={0.1}
            value={currentTime}
            onChange={handleSeek}
            className="w-full h-1 bg-ink-700 accent-brand-500 rounded cursor-pointer"
          />

          <div className="flex items-center justify-between text-white font-mono text-[10.5px]">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={togglePlay}
                className="hover:text-brand-400 font-bold px-1"
              >
                {isPlaying ? '⏸ PAUSE' : '▶ PLAY'}
              </button>
              <span>{formatTime(currentTime)} / 00:30.00</span>
            </div>

            <div className="flex items-center gap-2 text-ink-300">
              <span className="truncate max-w-[200px] text-[10px]">
                {clipUrl ?? 'supabase://clips/extract.mp4'}
              </span>
              <a
                href={effectiveUrl}
                target="_blank"
                rel="noreferrer"
                download={`${ticketNo}_evidence.mp4`}
                className="bg-ink-800 hover:bg-ink-700 text-white px-2 py-0.5 rounded text-[10px] transition"
              >
                Signed Clip
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
