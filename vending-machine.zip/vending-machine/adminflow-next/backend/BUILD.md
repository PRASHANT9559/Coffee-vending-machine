# Backend build notes (P0-03)

The Rust crate no longer needs a live database at compile time: all
`sqlx::query!` / `query_as!` macros were replaced with runtime `sqlx::query(...)`
calls, so no `.sqlx/` offline cache is required.

## First build (needs network once)

```bash
cd backend
cargo build --release
```

This creates `Cargo.lock` and populates `~/.cargo/registry`. Commit `Cargo.lock`
so every environment resolves the exact same dependency versions.

## Offline builds (after the first fetch)

```bash
cd backend
cargo build --release --offline
```

## Environment

Copy `.env.example` to `.env` (create it if missing) and set:

| Variable | Required | Notes |
|---|---|---|
| `DATABASE_URL` | yes | `postgresql://user:pass@host:5432/manhattan_coffee` |
| `ADMIN_JWT_SECRET` | yes (prod) | ≥ 32 chars; shared with the Next.js app |
| `JWT_SECRET` | legacy | accepted as a fallback for `ADMIN_JWT_SECRET` |
| `APP_ENV` | prod only | set to `production` to enable fail-fast checks |
| `PORT` | no | default `8080` |

In production (`APP_ENV=production`) the process refuses to start without
`ADMIN_JWT_SECRET` / `DATABASE_URL` instead of using insecure defaults.
