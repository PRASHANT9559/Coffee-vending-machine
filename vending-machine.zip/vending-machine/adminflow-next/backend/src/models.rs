use chrono::{DateTime, NaiveDate, Utc};
use serde::{Deserialize, Serialize};
use sqlx::FromRow;
use uuid::Uuid;

// =============================================================================
//  ENUM TYPES (PostgreSQL custom enum mappings)
// =============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "machine_status", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum MachineStatus {
    #[default]
    Provisioning,
    Active,
    Maintenance,
    Offline,
    Suspended,
    Retired,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "machine_mode", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum MachineMode {
    #[default]
    Hot,
    Cold,
    Off,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "tank_status", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum TankStatus {
    #[default]
    Empty,
    Mounted,
    InUse,
    Draining,
    Expired,
    Disposed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type)]
#[sqlx(type_name = "tank_event_type", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum TankEventType {
    Filled,
    Mounted,
    Unmounted,
    Expired,
    Disposed,
    ToppedUp,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type)]
#[sqlx(type_name = "item_type", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum ItemType {
    Cup,
    Kit,
    Malai,
    CoffeePowder,
    Sugar,
    Stirrer,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type)]
#[sqlx(type_name = "stock_reason", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum StockReason {
    Dispense,
    Refill,
    Waste,
    AuditAdjust,
    Initial,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "health_severity", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum HealthSeverity {
    #[default]
    Info,
    Warn,
    Error,
    Critical,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type)]
#[sqlx(type_name = "command_type", rename_all = "lowercase")]
#[serde(rename_all = "snake_case")]
pub enum CommandType {
    Lock,
    Unlock,
    Reboot,
    HeaterOn,
    HeaterOff,
    SetTemp,
    SetMode,
    TestDispense,
    FlushLine,
    OtaUpdate,
    FactoryReset,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "command_status", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum CommandStatus {
    #[default]
    Queued,
    Sent,
    Acked,
    Success,
    Failed,
    Expired,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "order_status", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum OrderStatus {
    #[default]
    Created,
    Paid,
    Authorised,
    Dispensing,
    Delivered,
    Failed,
    Refunded,
    Cancelled,
    Expired,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "payment_gateway", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum PaymentGateway {
    #[default]
    Razorpay,
    Phonepe,
    Paytm,
    Cashfree,
    UpiMandate,
    Manual,
    Wallet,
    Coins,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "payment_status", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum PaymentStatus {
    #[default]
    Initiated,
    Pending,
    Success,
    Failed,
    Refunded,
    Captured,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type)]
#[sqlx(type_name = "wallet_tx_type", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum WalletTxType {
    Recharge,
    Order,
    Refund,
    Coupon,
    Bonus,
    Referral,
    GiftRedeem,
    AdminCredit,
    AdminDebit,
    Expiry,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "ticket_status", rename_all = "lowercase")]
#[serde(rename_all = "snake_case")]
pub enum TicketStatus {
    #[default]
    Open,
    Investigating,
    AwaitingCustomer,
    ResolvedRefund,
    ResolvedReject,
    Rejected,
    Closed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "ticket_type", rename_all = "lowercase")]
#[serde(rename_all = "snake_case")]
pub enum TicketType {
    #[default]
    NoCoffee,
    NoKit,
    CupStuck,
    PaymentDeducted,
    QualityIssue,
    Spill,
    Other,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "verdict", rename_all = "lowercase")]
#[serde(rename_all = "snake_case")]
pub enum Verdict {
    #[default]
    Pending,
    LegitIssue,
    Fraud,
    Inconclusive,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, sqlx::Type, Default)]
#[sqlx(type_name = "camera_channel", rename_all = "lowercase")]
#[serde(rename_all = "lowercase")]
pub enum CameraChannel {
    #[default]
    Dispense,
    Face,
    Combo,
}

// =============================================================================
//  AUTHENTICATION & ADMIN CLAIMS
// =============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdminClaims {
    pub sub: String, // admin_user UUID
    pub email: String,
    pub name: String,
    pub role: String,
    pub permissions: serde_json::Value,
    pub exp: usize,
    pub iat: usize,
}

impl AdminClaims {
    pub fn is_owner(&self) -> bool {
        self.role == "owner" || self.role == "superadmin"
    }

    pub fn can_manage_machines(&self) -> bool {
        self.is_owner() || self.role == "ops"
    }

    pub fn can_approve_refund(&self) -> bool {
        self.is_owner() || self.role == "finance" || self.role == "ops"
    }

    pub fn can_resolve_tickets(&self) -> bool {
        self.is_owner() || self.role == "support" || self.role == "ops"
    }

    pub fn can_write_settings(&self) -> bool {
        self.is_owner()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct AdminUser {
    pub id: Uuid,
    pub email: String,
    #[serde(skip_serializing)]
    pub password_hash: String,
    pub full_name: String,
    pub mfa_enabled: bool,
    pub status: String,
    pub role: String,
    pub failed_logins: i16,
    pub locked_until: Option<DateTime<Utc>>,
    pub last_login_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct AdminRole {
    pub id: Uuid,
    pub name: String,
    pub permissions: serde_json::Value,
    pub is_superadmin: bool,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Deserialize)]
pub struct LoginRequest {
    pub email: String,
    pub password: Option<String>,
    pub phone: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct OtpVerifyRequest {
    pub email: Option<String>,
    pub phone: Option<String>,
    pub otp: String,
}

#[derive(Debug, Serialize)]
pub struct AuthResponse {
    pub token: String,
    pub user: AdminUserSummary,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdminUserSummary {
    pub id: Uuid,
    pub email: String,
    pub full_name: String,
    pub role: String,
}

// =============================================================================
//  DOMAIN 2 — MACHINES & IoT
// =============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Machine {
    pub id: Uuid,
    pub machine_code: String,
    pub name: String,
    pub status: MachineStatus,
    pub mode: MachineMode,
    pub firmware_version: Option<String>,
    pub sim_msisdn: Option<String>,
    pub sim_iccid: Option<String>,
    pub latitude: Option<f64>,
    pub longitude: Option<f64>,
    pub address_line: Option<String>,
    pub city: Option<String>,
    pub locality: Option<String>,
    pub place_id: Option<String>,
    pub timezone: String,
    pub target_temp_c: f64,
    pub cup_stack_count: i32,
    pub max_cup_stack: i32,
    pub is_locked: bool,
    pub lock_reason: Option<String>,
    pub last_ping_at: Option<DateTime<Utc>>,
    pub last_seen_at: Option<DateTime<Utc>>,
    pub commissioned_at: Option<DateTime<Utc>>,
    pub notes: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct MachineTelemetry {
    pub id: i64,
    pub machine_id: Uuid,
    pub recorded_at: DateTime<Utc>,
    pub milk_temp_c: Option<f64>,
    pub milk_level_l: Option<f64>,
    pub malai_level_l: Option<f64>,
    pub signal_dbm: Option<i16>,
    pub cup_count: Option<i32>,
    pub kit_count: Option<i32>,
    pub is_locked: Option<bool>,
    pub heater_on: Option<bool>,
    pub fault_code: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct TelemetryUpdateRequest {
    pub milk_temp_c: Option<f64>,
    pub milk_level_l: Option<f64>,
    pub malai_level_l: Option<f64>,
    pub signal_dbm: Option<i16>,
    pub cup_count: Option<i32>,
    pub kit_count: Option<i32>,
    pub is_locked: Option<bool>,
    pub heater_on: Option<bool>,
    pub fault_code: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct MachineTank {
    pub id: Uuid,
    pub tank_uid: String,
    pub machine_id: Option<Uuid>,
    pub capacity_l: f64,
    pub filled_l: Option<f64>,
    pub filled_at: Option<DateTime<Utc>>,
    pub max_hold_hours: i32,
    pub expires_at: Option<DateTime<Utc>>,
    pub mounted_at: Option<DateTime<Utc>>,
    pub unmounted_at: Option<DateTime<Utc>>,
    pub status: TankStatus,
    pub min_temp_c: f64,
    pub max_temp_c: f64,
    pub source: Option<String>,
    pub batch_ref: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct MachineStock {
    pub id: Uuid,
    pub machine_id: Uuid,
    pub item_type: ItemType,
    pub variant_key: String,
    pub quantity: i32,
    pub reorder_threshold: i32,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct MachineCommand {
    pub id: Uuid,
    pub machine_id: Uuid,
    pub command_type: CommandType,
    pub payload: serde_json::Value,
    pub status: CommandStatus,
    pub requested_by: Option<Uuid>,
    pub requested_at: DateTime<Utc>,
    pub sent_at: Option<DateTime<Utc>>,
    pub acked_at: Option<DateTime<Utc>>,
    pub completed_at: Option<DateTime<Utc>>,
    pub expires_at: Option<DateTime<Utc>>,
    pub result: Option<serde_json::Value>,
    pub error: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct HardwareCommandRequest {
    pub command_type: CommandType,
    pub payload: Option<serde_json::Value>,
}

#[derive(Debug, Deserialize)]
pub struct AckCommandRequest {
    pub result: Option<serde_json::Value>,
    pub error: Option<String>,
}

// =============================================================================
//  DOMAIN 3 & 4 — CATALOG, CODES, ORDERS, & DISPENSE
// =============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Product {
    pub id: Uuid,
    pub slug: String,
    pub name: String,
    pub short_name: String,
    pub tagline: Option<String>,
    pub description: Option<String>,
    pub milk_ml: i32,
    pub malai_ml: i32,
    pub cup_gsm: Option<i32>,
    pub has_malai: bool,
    pub is_seasonal: bool,
    pub season: Option<String>,
    pub display_order: i32,
    pub image_url: Option<String>,
    pub is_active: bool,
    pub is_stockout_visible: bool,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct QrCode {
    pub id: Uuid,
    pub code_hash: String,
    pub random_id: String,
    pub signature: String,
    pub batch_id: Option<Uuid>,
    pub user_id: Option<Uuid>,
    pub product_id: Uuid,
    pub amount_paise: i32,
    pub cost_basis_paise: i32,
    pub machine_ids: Vec<Uuid>,
    pub issued_at: DateTime<Utc>,
    pub expires_at: DateTime<Utc>,
    pub delivered: bool,
    pub delivered_at: Option<DateTime<Utc>>,
    pub redeemed_order_id: Option<Uuid>,
    pub source: String,
    pub share_count: i32,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Order {
    pub id: Uuid,
    pub order_no: String,
    pub code_id: Option<Uuid>,
    pub user_id: Option<Uuid>,
    pub machine_id: Uuid,
    pub product_id: Uuid,
    pub amount_paise: i32,
    pub discount_paise: i32,
    pub tax_paise: i32,
    pub final_paise: i32,
    pub cost_basis_paise: i32,
    pub payment_method: PaymentGateway,
    pub coupon_id: Option<Uuid>,
    pub status: OrderStatus,
    pub is_subscription: bool,
    pub ordered_at: DateTime<Utc>,
    pub authorised_at: Option<DateTime<Utc>>,
    pub dispensing_at: Option<DateTime<Utc>>,
    pub delivered_at: Option<DateTime<Utc>>,
    pub failure_reason: Option<String>,
    pub offline_synced: bool,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct DispenseLog {
    pub id: i64,
    pub order_id: Uuid,
    pub machine_id: Uuid,
    pub code_id: Option<Uuid>,
    pub valve_open_ms: i32,
    pub flow_pulses: i32,
    pub dispensed_ml: f64,
    pub expected_ml: f64,
    pub variance_pct: Option<f64>,
    pub cup_detected: bool,
    pub cup_detect_ts: Option<DateTime<Utc>>,
    pub kit_dropped: bool,
    pub malai_pumped_ms: i32,
    pub conveyor_steps: Option<i32>,
    pub window_opened: bool,
    pub window_opened_at: Option<DateTime<Utc>>,
    pub pickup_detected: bool,
    pub watchdog_resets: i16,
    pub firmware_version: Option<String>,
    pub recorded_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct PaymentTransaction {
    pub id: Uuid,
    pub user_id: Option<Uuid>,
    pub order_id: Option<Uuid>,
    pub subscription_id: Option<Uuid>,
    pub gateway: PaymentGateway,
    pub gateway_order_id: Option<String>,
    pub gateway_payment_id: Option<String>,
    pub utr: Option<String>,
    pub amount_paise: i32,
    pub fee_paise: i32,
    pub status: PaymentStatus,
    pub method_detail: Option<String>,
    pub raw_payload: Option<serde_json::Value>,
    pub initiated_at: DateTime<Utc>,
    pub captured_at: Option<DateTime<Utc>>,
    pub failed_reason: Option<String>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Refund {
    pub id: Uuid,
    pub refund_no: String,
    pub order_id: Uuid,
    pub payment_tx_id: Option<Uuid>,
    pub user_id: Option<Uuid>,
    pub amount_paise: i32,
    pub destination: String,
    pub reason: String,
    pub verdict: Option<Verdict>,
    pub approved_by: Option<Uuid>,
    pub gateway_ref: Option<String>,
    pub status: PaymentStatus,
    pub requested_at: DateTime<Utc>,
    pub processed_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Deserialize)]
pub struct RefundRequest {
    pub reason: String,
    pub destination: Option<String>, // 'original', 'wallet', 'replacement_code'
}

// =============================================================================
//  DOMAIN 5 — USERS & WALLET
// =============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct User {
    pub id: Uuid,
    pub phone: String,
    pub country_code: String,
    pub status: String,
    pub is_verified: bool,
    pub fcm_token: Option<String>,
    pub phone_verified_at: Option<DateTime<Utc>>,
    pub referred_by: Option<Uuid>,
    pub referrer_token: Option<String>,
    pub is_anonymous_leaderboard: bool,
    pub last_seen_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub deleted_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct UserProfile {
    pub user_id: Uuid,
    pub display_name: Option<String>,
    pub avatar_url: Option<String>,
    pub date_of_birth: Option<NaiveDate>,
    pub age_band: Option<String>,
    pub gender: Option<String>,
    pub city: Option<String>,
    pub locality: Option<String>,
    pub college_work: Option<String>,
    pub bio: Option<String>,
    pub instagram_handle: Option<String>,
    pub show_on_leaderboard: bool,
    pub show_handle_publicly: bool,
    pub show_avatar_publicly: bool,
    pub terms_accepted_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Wallet {
    pub user_id: Uuid,
    pub balance_paise: i64,
    pub locked_paise: i64,
    pub lifetime_added_paise: i64,
    pub lifetime_spent_paise: i64,
    pub last_transaction_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct WalletTransaction {
    pub id: i64,
    pub user_id: Uuid,
    pub tx_type: WalletTxType,
    pub direction: String,
    pub amount_paise: i64,
    pub balance_after: i64,
    pub ref_type: Option<String>,
    pub ref_id: Option<Uuid>,
    pub payment_tx_id: Option<Uuid>,
    pub order_id: Option<Uuid>,
    pub description: Option<String>,
    pub metadata: Option<serde_json::Value>,
    pub created_at: DateTime<Utc>,
}

// =============================================================================
//  DOMAIN 8 — SUPPORT & DISPUTE DESK
// =============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct SupportTicket {
    pub id: Uuid,
    pub ticket_no: String,
    pub user_id: Option<Uuid>,
    pub machine_id: Option<Uuid>,
    pub order_id: Option<Uuid>,
    pub payment_tx_id: Option<Uuid>,
    pub ticket_type: TicketType,
    pub claim_amount_paise: i32,
    pub claimed_time: Option<DateTime<Utc>>,
    pub utr: Option<String>,
    pub user_message: Option<String>,
    pub auto_context: Option<serde_json::Value>,
    pub status: TicketStatus,
    pub priority: i16,
    pub verdict: Verdict,
    pub assigned_to: Option<Uuid>,
    pub resolution: Option<String>,
    pub refund_id: Option<Uuid>,
    pub whatsapp_sent_at: Option<DateTime<Utc>>,
    pub resolved_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct TicketEvidence {
    pub id: i64,
    pub ticket_id: Uuid,
    pub evidence_type: String,
    pub ref_table: Option<String>,
    pub ref_id: Option<Uuid>,
    pub clip_start: Option<DateTime<Utc>>,
    pub clip_end: Option<DateTime<Utc>>,
    pub sensor_snapshot: Option<serde_json::Value>,
    pub note: Option<String>,
    pub added_by: Option<Uuid>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Deserialize)]
pub struct DisputeResolutionRequest {
    pub verdict: Verdict,
    pub action: String, // 'refund_now', 'issue_voucher', 'reject_fraud', 'close'
    pub resolution_notes: String,
}

#[derive(Debug, Deserialize)]
pub struct WhatsAppTicketIntakeRequest {
    pub phone: String,
    pub message: String,
    pub ticket_type: Option<String>,
    pub order_no: Option<String>,
    pub upi_ref: Option<String>,
    pub machine_code: Option<String>,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn claims(role: &str) -> AdminClaims {
        AdminClaims {
            sub: "00000000-0000-4000-8000-000000000000".to_string(),
            email: "test@example.com".to_string(),
            name: "Test".to_string(),
            role: role.to_string(),
            permissions: serde_json::json!({}),
            exp: 0,
            iat: 0,
        }
    }

    #[test]
    fn owner_can_manage_everything() {
        let c = claims("owner");
        assert!(c.is_owner());
        assert!(c.can_manage_machines());
        assert!(c.can_approve_refund());
        assert!(c.can_resolve_tickets());
        assert!(c.can_write_settings());
    }

    #[test]
    fn support_only_resolves_tickets() {
        let c = claims("support");
        assert!(!c.is_owner());
        assert!(!c.can_manage_machines());
        assert!(!c.can_approve_refund());
        assert!(c.can_resolve_tickets());
        assert!(!c.can_write_settings());
    }

    #[test]
    fn finance_can_refund_but_not_settings() {
        let c = claims("finance");
        assert!(c.can_approve_refund());
        assert!(!c.can_manage_machines());
        assert!(!c.can_write_settings());
    }

    #[test]
    fn legacy_superadmin_is_treated_as_owner() {
        assert!(claims("superadmin").is_owner());
    }
}

