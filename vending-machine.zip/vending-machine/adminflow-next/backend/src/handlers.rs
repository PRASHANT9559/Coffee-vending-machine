use axum::{
    extract::{Extension, Path, State},
    http::StatusCode,
    response::{IntoResponse, Json},
};
use chrono::{DateTime, Utc};
use jsonwebtoken::{encode, EncodingKey, Header};
use serde_json::json;
use sqlx::{PgPool, Row};
use uuid::Uuid;

use crate::{
    config::AppConfig,
    error::AppError,
    models::*,
};

// =============================================================================
//  SYSTEM & HEALTH
// =============================================================================

/// System health check endpoint
pub async fn health_check() -> impl IntoResponse {
    (
        StatusCode::OK,
        Json(json!({
            "status": "online",
            "service": "manhattan-coffee-backend",
            "version": "1.0.0",
            "environment": "production",
            "timestamp": Utc::now()
        })),
    )
}

// =============================================================================
//  AUTHENTICATION & IDENTITY
// =============================================================================

/// Load the RBAC permission bundle for an admin role (P0-06).
async fn load_role_permissions(pool: &PgPool, role: &str) -> serde_json::Value {
    match sqlx::query_as::<_, AdminRole>(
        "SELECT id, name, permissions, is_superadmin, created_at FROM admin_roles WHERE name = $1 LIMIT 1",
    )
    .bind(role)
    .fetch_optional(pool)
    .await
    {
        Ok(Some(r)) if r.is_superadmin => json!({ "*": true }),
        Ok(Some(r)) => r.permissions,
        _ => json!({}),
    }
}

/// Best-effort audit trail writer (P1-12). Never blocks the operation.
async fn write_audit(
    pool: &PgPool,
    actor_id: Option<Uuid>,
    action: &str,
    entity_type: &str,
    entity_id: Option<Uuid>,
    after: serde_json::Value,
) {
    let _ = sqlx::query(
        r#"
        INSERT INTO audit_logs
            (actor_type, actor_id, action, entity_type, entity_id, after_state)
        VALUES (
            CASE WHEN $1::uuid IS NULL THEN 'system'::sub_entity_type
                 ELSE 'admin'::sub_entity_type END,
            $1, $2, $3, $4, $5::jsonb
        )
        "#,
    )
    .bind(actor_id)
    .bind(action)
    .bind(entity_type)
    .bind(entity_id)
    .bind(after)
    .execute(pool)
    .await;
}

/// Admin user login handler with JWT generation
pub async fn login_handler(
    State(pool): State<PgPool>,
    Json(payload): Json<LoginRequest>,
) -> Result<impl IntoResponse, AppError> {
    // 1. Load the admin identity (P0-06: never authenticate on email alone)
    let config = AppConfig::from_env();
    let email = payload.email.trim().to_lowercase();

    let user = sqlx::query_as::<_, AdminUser>(
        r#"
        SELECT id, email, password_hash, full_name, mfa_enabled, status, role,
               failed_logins, locked_until, last_login_at, created_at, updated_at
        FROM admin_users
        WHERE lower(email) = $1 AND status = 'active'
        "#,
    )
    .bind(&email)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::Unauthorized("Invalid email or credentials".to_string()))?;

    // P0-09: honour an existing lockout before doing any hashing work.
    if let Some(until) = user.locked_until {
        if until > Utc::now() {
            return Err(AppError::TooManyRequests(
                "Account temporarily locked after repeated failed logins. Try again later."
                    .to_string(),
            ));
        }
    }

    // P0-06: verify the supplied password against the stored bcrypt hash.
    let password = payload.password.clone().unwrap_or_default();
    let password_ok = !password.is_empty()
        && bcrypt::verify(password.as_bytes(), &user.password_hash).unwrap_or(false);

    if !password_ok {
        let failed = user.failed_logins.saturating_add(1);
        let lock_until = if failed >= 5 {
            Some(Utc::now() + chrono::Duration::minutes(15))
        } else {
            None
        };
        let _ = sqlx::query(
            r#"
            UPDATE admin_users
               SET failed_logins = $2,
                   locked_until  = coalesce($3, locked_until),
                   updated_at    = now()
             WHERE id = $1
            "#,
        )
        .bind(user.id)
        .bind(failed)
        .bind(lock_until)
        .execute(&pool)
        .await;

        return Err(AppError::Unauthorized(
            "Invalid email or credentials".to_string(),
        ));
    }

    // Successful credential check — reset the counter and stamp the login.
    let _ = sqlx::query(
        "UPDATE admin_users SET failed_logins = 0, locked_until = NULL, last_login_at = now(), updated_at = now() WHERE id = $1",
    )
    .bind(user.id)
    .execute(&pool)
    .await;

    let admin_id = user.id;
    let admin_name = user.full_name.clone();
    let admin_role = user.role.clone();
    let permissions = load_role_permissions(&pool, &admin_role).await;

    write_audit(
        &pool,
        Some(admin_id),
        "auth.login",
        "admin_users",
        Some(admin_id),
        json!({ "email": email.clone(), "role": admin_role.clone() }),
    )
    .await;

    // 2. Generate signed JWT token
    let expiration = Utc::now()
        .checked_add_signed(chrono::Duration::hours(24))
        .expect("Valid timestamp")
        .timestamp() as usize;

    let claims = AdminClaims {
        sub: admin_id.to_string(),
        email: email.clone(),
        name: admin_name.clone(),
        role: admin_role.clone(),
        permissions,
        exp: expiration,
        iat: Utc::now().timestamp() as usize,
    };

    let token = encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(config.jwt_secret.as_bytes()),
    )
    .map_err(|e| AppError::Internal(format!("JWT Generation Error: {e}")))?;

    // 3. Return authenticated response
    Ok((
        StatusCode::OK,
        Json(json!({
            "success": true,
            "token": token,
            "user": {
                "id": admin_id,
                "email": email,
                "full_name": admin_name,
                "role": admin_role,
            }
        })),
    ))
}

/// OTP verification handler
pub async fn otp_verify_handler(
    State(pool): State<PgPool>,
    Json(payload): Json<OtpVerifyRequest>,
) -> Result<impl IntoResponse, AppError> {
    let email = payload.email.as_deref().unwrap_or("").trim().to_lowercase();
    let otp = payload.otp.trim();
    if email.is_empty() || otp.is_empty() {
        return Err(AppError::BadRequest("Email and OTP code are required".to_string()));
    }

    // NOTE: runtime queries (not `sqlx::query!`) so the crate compiles without a
    // live DATABASE_URL or a `.sqlx/` offline cache. See P0-02.
    let record_id: Option<Uuid> = sqlx::query_scalar(
        "SELECT id FROM otp_codes WHERE lower(email) = $1 AND code = $2 AND used = FALSE AND attempts < 5 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1",
    )
    .bind(&email)
    .bind(otp)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?;

    let record_id = match record_id {
        Some(id) => id,
        None => {
            // P0-09: throttle brute-force attempts against live OTP rows.
            let _ = sqlx::query(
                "UPDATE otp_codes SET attempts = attempts + 1 WHERE lower(email) = $1 AND used = FALSE AND expires_at > NOW()",
            )
            .bind(&email)
            .execute(&pool)
            .await;
            return Err(AppError::Unauthorized(
                "Invalid or expired OTP code".to_string(),
            ));
        }
    };

    let _ = sqlx::query("UPDATE otp_codes SET used = TRUE WHERE id = $1")
        .bind(record_id)
        .execute(&pool)
        .await;

    let user_record = sqlx::query_as::<_, AdminUser>(
        r#"
        SELECT id, email, password_hash, full_name, mfa_enabled, status, role,
               failed_logins, locked_until, last_login_at, created_at, updated_at
        FROM admin_users
        WHERE lower(email) = $1 AND status = 'active'
        "#,
    )
    .bind(&email)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::Unauthorized("Admin user not found or inactive".to_string()))?;

    let config = AppConfig::from_env();
    let admin_id = user_record.id;
    let admin_name = user_record.full_name.clone();
    let admin_role = user_record.role.clone();
    let permissions = load_role_permissions(&pool, &admin_role).await;

    let claims = AdminClaims {
        sub: admin_id.to_string(),
        email: email.clone(),
        name: admin_name.clone(),
        role: admin_role.clone(),
        permissions,
        exp: (Utc::now() + chrono::Duration::hours(24)).timestamp() as usize,
        iat: Utc::now().timestamp() as usize,
    };

    let token = encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(config.jwt_secret.as_bytes()),
    )
    .map_err(|e| AppError::Internal(e.to_string()))?;

    Ok(Json(json!({
        "success": true,
        "token": token,
        "user": {
            "id": admin_id,
            "email": email,
            "role": admin_role
        }
    })))
}

/// Current admin session handler
pub async fn me_handler(
    Extension(claims): Extension<AdminClaims>,
) -> Result<impl IntoResponse, AppError> {
    Ok(Json(json!({
        "success": true,
        "claims": claims
    })))
}

// =============================================================================
//  LIVE DASHBOARD & SSE STREAMS
// =============================================================================

/// Global high-level fleet dashboard telemetry summary
pub async fn live_dashboard(
    State(pool): State<PgPool>,
) -> Result<impl IntoResponse, AppError> {
    // 1. Machine aggregate counts
    let machine_row = sqlx::query(
        r#"
        SELECT
            count(*) FILTER (WHERE status = 'active')::int8 as active_count,
            count(*) FILTER (WHERE status = 'offline')::int8 as offline_count,
            count(*) FILTER (WHERE status = 'maintenance')::int8 as maintenance_count,
            count(*)::int8 as total_count
        FROM machines
        "#,
    )
    .fetch_one(&pool)
    .await
    .map_err(AppError::Database)?;

    let active_count: i64 = machine_row.try_get("active_count").unwrap_or(0);
    let offline_count: i64 = machine_row.try_get("offline_count").unwrap_or(0);
    let maintenance_count: i64 = machine_row.try_get("maintenance_count").unwrap_or(0);
    let total_count: i64 = machine_row.try_get("total_count").unwrap_or(0);

    // 2. Orders & Revenue today
    let order_row = sqlx::query(
        r#"
        SELECT
            count(*)::int8 as today_orders,
            coalesce(sum(final_paise), 0)::int8 as today_revenue_paise
        FROM orders
        WHERE ordered_at >= current_date
        "#,
    )
    .fetch_one(&pool)
    .await
    .map_err(AppError::Database)?;

    let today_orders: i64 = order_row.try_get("today_orders").unwrap_or(0);
    let today_revenue_paise: i64 = order_row.try_get("today_revenue_paise").unwrap_or(0);

    // 3. Open disputes & tickets
    let ticket_row = sqlx::query(
        r#"
        SELECT
            count(*) FILTER (WHERE status in ('open', 'investigating'))::int8 as open_tickets,
            count(*) FILTER (WHERE verdict = 'pending')::int8 as pending_disputes
        FROM support_tickets
        "#,
    )
    .fetch_one(&pool)
    .await
    .map_err(AppError::Database)?;

    let open_tickets: i64 = ticket_row.try_get("open_tickets").unwrap_or(0);
    let pending_disputes: i64 = ticket_row.try_get("pending_disputes").unwrap_or(0);

    Ok(Json(json!({
        "timestamp": Utc::now(),
        "machines": {
            "total": total_count,
            "active": active_count,
            "offline": offline_count,
            "maintenance": maintenance_count,
            "online_pct": if total_count > 0 {
                (active_count as f64 / total_count as f64) * 100.0
            } else {
                100.0
            }
        },
        "sales": {
            "today_orders": today_orders,
            "today_revenue_paise": today_revenue_paise,
            "today_revenue_inr": (today_revenue_paise as f64) / 100.0
        },
        "support": {
            "open_tickets": open_tickets,
            "pending_disputes": pending_disputes
        }
    })))
}

/// Real-time live status for all machines
pub async fn live_machines(
    State(pool): State<PgPool>,
) -> Result<impl IntoResponse, AppError> {
    let rows = sqlx::query(
        r#"
        SELECT
            m.id,
            m.machine_code,
            m.name,
            m.status::text as status,
            m.mode::text as mode,
            m.target_temp_c::float8 as target_temp_c,
            m.cup_stack_count,
            m.max_cup_stack,
            m.is_locked,
            m.last_ping_at,
            t.milk_temp_c::float8 as milk_temp_c,
            t.milk_level_l::float8 as milk_level_l,
            t.signal_dbm
        FROM machines m
        LEFT JOIN LATERAL (
            SELECT milk_temp_c, milk_level_l, signal_dbm
            FROM machine_telemetry
            WHERE machine_id = m.id
            ORDER BY recorded_at DESC
            LIMIT 1
        ) t ON true
        ORDER BY m.machine_code ASC
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let machines_json: Vec<_> = rows
        .into_iter()
        .map(|r| {
            let id: Uuid = r.get("id");
            let machine_code: String = r.get("machine_code");
            let name: String = r.get("name");
            let status: String = r.get("status");
            let mode: String = r.get("mode");
            let target_temp_c: f64 = r.get("target_temp_c");
            let cup_stack_count: i32 = r.get("cup_stack_count");
            let max_cup_stack: i32 = r.get("max_cup_stack");
            let is_locked: bool = r.get("is_locked");
            let last_ping_at: Option<DateTime<Utc>> = r.get("last_ping_at");
            let milk_temp_c: Option<f64> = r.get("milk_temp_c");
            let milk_level_l: Option<f64> = r.get("milk_level_l");
            let signal_dbm: Option<i16> = r.get("signal_dbm");

            json!({
                "id": id,
                "machine_code": machine_code,
                "name": name,
                "status": status,
                "mode": mode,
                "target_temp_c": target_temp_c,
                "cup_stack_count": cup_stack_count,
                "max_cup_stack": max_cup_stack,
                "is_locked": is_locked,
                "last_ping_at": last_ping_at,
                "milk_temp_c": milk_temp_c,
                "milk_level_l": milk_level_l,
                "signal_dbm": signal_dbm
            })
        })
        .collect();

    Ok(Json(json!({
        "timestamp": Utc::now(),
        "total": machines_json.len(),
        "machines": machines_json
    })))
}

// =============================================================================
//  DOMAIN 2 — MACHINES API
// =============================================================================

/// List machines in the network
pub async fn list_machines(
    State(pool): State<PgPool>,
) -> Result<impl IntoResponse, AppError> {
    let machines = sqlx::query_as::<_, Machine>(
        r#"
        SELECT id, machine_code, name, status, mode, firmware_version, sim_msisdn, sim_iccid,
               latitude::float8, longitude::float8, address_line, city, locality, place_id,
               timezone, target_temp_c::float8, cup_stack_count, max_cup_stack, is_locked,
               lock_reason, last_ping_at, last_seen_at, commissioned_at, notes,
               created_at, updated_at
        FROM machines
        ORDER BY machine_code ASC
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    Ok(Json(json!({
        "success": true,
        "count": machines.len(),
        "machines": machines
    })))
}

/// Retrieve single machine with tanks, stock, and latest telemetry
pub async fn get_machine(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
) -> Result<impl IntoResponse, AppError> {
    let machine = sqlx::query_as::<_, Machine>(
        r#"
        SELECT id, machine_code, name, status, mode, firmware_version, sim_msisdn, sim_iccid,
               latitude::float8, longitude::float8, address_line, city, locality, place_id,
               timezone, target_temp_c::float8, cup_stack_count, max_cup_stack, is_locked,
               lock_reason, last_ping_at, last_seen_at, commissioned_at, notes,
               created_at, updated_at
        FROM machines
        WHERE id = $1
        "#,
    )
    .bind(id)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound(format!("Machine with id {id} not found")))?;

    // Fetch mounted tanks
    let tanks = sqlx::query_as::<_, MachineTank>(
        r#"
        SELECT id, tank_uid, machine_id, capacity_l::float8, filled_l::float8, filled_at,
               max_hold_hours, expires_at, mounted_at, unmounted_at, status,
               min_temp_c::float8, max_temp_c::float8, source, batch_ref,
               created_at, updated_at
        FROM machine_tanks
        WHERE machine_id = $1
        ORDER BY mounted_at DESC NULLS LAST
        "#,
    )
    .bind(id)
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    // Fetch recent 10 telemetry points
    let telemetry = sqlx::query_as::<_, MachineTelemetry>(
        r#"
        SELECT id, machine_id, recorded_at, milk_temp_c::float8, milk_level_l::float8,
               malai_level_l::float8, signal_dbm, cup_count, kit_count, is_locked,
               heater_on, fault_code
        FROM machine_telemetry
        WHERE machine_id = $1
        ORDER BY recorded_at DESC
        LIMIT 10
        "#,
    )
    .bind(id)
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    Ok(Json(json!({
        "success": true,
        "machine": machine,
        "tanks": tanks,
        "recent_telemetry": telemetry
    })))
}

/// Push telemetry update from machine hardware
pub async fn update_telemetry(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
    Json(payload): Json<TelemetryUpdateRequest>,
) -> Result<impl IntoResponse, AppError> {
    // 1. Insert telemetry row
    sqlx::query(
        r#"
        INSERT INTO machine_telemetry (
            machine_id, recorded_at, milk_temp_c, milk_level_l, malai_level_l,
            signal_dbm, cup_count, kit_count, is_locked, heater_on, fault_code
        ) VALUES (
            $1, now(), $2, $3, $4, $5, $6, $7, $8, $9, $10
        )
        "#,
    )
    .bind(id)
    .bind(payload.milk_temp_c)
    .bind(payload.milk_level_l)
    .bind(payload.malai_level_l)
    .bind(payload.signal_dbm)
    .bind(payload.cup_count)
    .bind(payload.kit_count)
    .bind(payload.is_locked)
    .bind(payload.heater_on)
    .bind(payload.fault_code)
    .execute(&pool)
    .await
    .map_err(AppError::Database)?;

    // 2. Touch machines last_ping_at and last_seen_at
    sqlx::query(
        r#"
        UPDATE machines
        SET last_ping_at = now(),
            last_seen_at = now(),
            cup_stack_count = coalesce($2, cup_stack_count),
            is_locked = coalesce($3, is_locked)
        WHERE id = $1
        "#,
    )
    .bind(id)
    .bind(payload.cup_count)
    .bind(payload.is_locked)
    .execute(&pool)
    .await
    .map_err(AppError::Database)?;

    // 3. FSSAI Health Watchdog: Milk temp > 8°C triggers emergency lockout
    let mut auto_locked = false;
    if let Some(milk_temp) = payload.milk_temp_c {
        if milk_temp > 8.0 {
            auto_locked = true;
            tracing::warn!(
                "🚨 FSSAI SPOILAGE ALARM: Milk temperature {:.1}°C on machine {} > 8.0°C! Triggering emergency lockout.",
                milk_temp, id
            );

            let _ = sqlx::query(
                r#"
                UPDATE machines
                SET is_locked = true,
                    status = 'maintenance',
                    updated_at = now()
                WHERE id = $1
                "#,
            )
            .bind(id)
            .execute(&pool)
            .await;

            let _ = sqlx::query(
                r#"
                INSERT INTO machine_commands (
                    machine_id, command_type, payload, status, requested_at
                ) VALUES (
                    $1, 'lock', '{"reason":"FSSAI milk temperature limit exceeded (>8.0C)","automated":true}', 'queued', now()
                )
                "#,
            )
            .bind(id)
            .execute(&pool)
            .await;
        }
    }

    Ok(Json(json!({
        "success": true,
        "machine_id": id,
        "recorded_at": Utc::now(),
        "fssai_alarm": auto_locked
    })))
}

/// Enqueue remote hardware command
pub async fn dispatch_hardware_command(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
    Extension(claims): Extension<AdminClaims>,
    Json(payload): Json<HardwareCommandRequest>,
) -> Result<impl IntoResponse, AppError> {
    if !claims.can_manage_machines() {
        return Err(AppError::Forbidden(
            "Access denied: Only ops and owner roles can dispatch hardware commands".to_string(),
        ));
    }

    let admin_id = Uuid::parse_str(&claims.sub).ok();
    let command_payload = payload.payload.unwrap_or_else(|| json!({}));

    let command_record = sqlx::query_as::<_, MachineCommand>(
        r#"
        INSERT INTO machine_commands (
            machine_id, command_type, payload, status, requested_by
        ) VALUES (
            $1, $2::command_type, $3::jsonb, 'queued', $4
        )
        RETURNING id, machine_id, command_type, payload, status, requested_by,
                  requested_at, sent_at, acked_at, completed_at, expires_at, result, error
        "#,
    )
    .bind(id)
    .bind(payload.command_type)
    .bind(&command_payload)
    .bind(admin_id)
    .fetch_one(&pool)
    .await
    .map_err(AppError::Database)?;

    write_audit(
        &pool,
        admin_id,
        "machine.command",
        "machine_commands",
        Some(command_record.id),
        json!({ "machine_id": id, "command_type": command_record.command_type }),
    )
    .await;

    Ok((
        StatusCode::CREATED,
        Json(json!({
            "success": true,
            "command": command_record
        })),
    ))
}

/// List commands for a machine with auto-TTL expiration
pub async fn list_machine_commands(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
) -> Result<impl IntoResponse, AppError> {
    // 1. Auto-expire commands whose TTL has elapsed (120s)
    let _ = sqlx::query(
        r#"
        UPDATE machine_commands
        SET status = 'expired'
        WHERE machine_id = $1
          AND status IN ('queued', 'sent')
          AND expires_at < now()
        "#,
    )
    .bind(id)
    .execute(&pool)
    .await;

    // 2. Fetch recent commands
    let commands = sqlx::query_as::<_, MachineCommand>(
        r#"
        SELECT id, machine_id, command_type, payload, status, requested_by,
               requested_at, sent_at, acked_at, completed_at, expires_at, result, error
        FROM machine_commands
        WHERE machine_id = $1
        ORDER BY requested_at DESC
        LIMIT 50
        "#,
    )
    .bind(id)
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    Ok(Json(json!({
        "success": true,
        "machine_id": id,
        "count": commands.len(),
        "commands": commands
    })))
}

/// Acknowledge hardware execution of a command (completes MQTT lifecycle)
pub async fn ack_machine_command(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
    Json(payload): Json<AckCommandRequest>,
) -> Result<impl IntoResponse, AppError> {
    let status = if payload.error.is_some() { "failed" } else { "success" };

    let updated = sqlx::query_as::<_, MachineCommand>(
        r#"
        UPDATE machine_commands
        SET status = $2::command_status,
            acked_at = coalesce(acked_at, now()),
            completed_at = now(),
            result = coalesce($3, result),
            error = coalesce($4, error)
        WHERE id = $1
        RETURNING id, machine_id, command_type, payload, status, requested_by,
                  requested_at, sent_at, acked_at, completed_at, expires_at, result, error
        "#,
    )
    .bind(id)
    .bind(status)
    .bind(payload.result)
    .bind(payload.error)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound(format!("Command {id} not found")))?;

    Ok(Json(json!({
        "success": true,
        "command": updated
    })))
}

// =============================================================================
//  DOMAIN 4 — ORDERS & DISPENSE
// =============================================================================

/// List recent orders with pagination
pub async fn list_orders(
    State(pool): State<PgPool>,
) -> Result<impl IntoResponse, AppError> {
    let orders = sqlx::query_as::<_, Order>(
        r#"
        SELECT id, order_no, code_id, user_id, machine_id, product_id,
               amount_paise, discount_paise, tax_paise, final_paise, cost_basis_paise,
               payment_method, coupon_id, status, is_subscription,
               ordered_at, authorised_at, dispensing_at, delivered_at, failure_reason,
               offline_synced, created_at, updated_at
        FROM orders
        ORDER BY ordered_at DESC
        LIMIT 50
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    Ok(Json(json!({
        "success": true,
        "count": orders.len(),
        "orders": orders
    })))
}

/// Retrieve single order with dispense logs and payment transaction
pub async fn get_order(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
) -> Result<impl IntoResponse, AppError> {
    let order = sqlx::query_as::<_, Order>(
        r#"
        SELECT id, order_no, code_id, user_id, machine_id, product_id,
               amount_paise, discount_paise, tax_paise, final_paise, cost_basis_paise,
               payment_method, coupon_id, status, is_subscription,
               ordered_at, authorised_at, dispensing_at, delivered_at, failure_reason,
               offline_synced, created_at, updated_at
        FROM orders
        WHERE id = $1
        "#,
    )
    .bind(id)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound(format!("Order {id} not found")))?;

    // Fetch dispense log
    let dispense_log = sqlx::query_as::<_, DispenseLog>(
        r#"
        SELECT id, order_id, machine_id, code_id, valve_open_ms, flow_pulses,
               dispensed_ml::float8, expected_ml::float8, variance_pct::float8,
               cup_detected, cup_detect_ts, kit_dropped, malai_pumped_ms, conveyor_steps,
               window_opened, window_opened_at, pickup_detected, watchdog_resets,
               firmware_version, recorded_at
        FROM dispense_logs
        WHERE order_id = $1
        LIMIT 1
        "#,
    )
    .bind(id)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?;

    Ok(Json(json!({
        "success": true,
        "order": order,
        "dispense_log": dispense_log
    })))
}

/// Process refund for an order (Atomic transaction + Ledger Invariant compliant)
pub async fn process_refund(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
    Extension(claims): Extension<AdminClaims>,
    Json(payload): Json<RefundRequest>,
) -> Result<impl IntoResponse, AppError> {
    if !claims.can_approve_refund() {
        return Err(AppError::Forbidden(
            "Access denied: Only finance, ops, and owner roles can authorize refunds".to_string(),
        ));
    }

    let admin_id = Uuid::parse_str(&claims.sub).ok();

    // 1. Begin atomic transaction
    let mut tx = pool.begin().await.map_err(AppError::Database)?;

    // 2. Fetch order with exclusive row lock
    let order = sqlx::query_as::<_, Order>(
        r#"
        SELECT id, order_no, code_id, user_id, machine_id, product_id,
               amount_paise, discount_paise, tax_paise, final_paise, cost_basis_paise,
               payment_method, coupon_id, status, is_subscription,
               ordered_at, authorised_at, dispensing_at, delivered_at, failure_reason,
               offline_synced, created_at, updated_at
        FROM orders
        WHERE id = $1
        FOR UPDATE
        "#,
    )
    .bind(id)
    .fetch_optional(&mut *tx)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound(format!("Order {id} not found")))?;

    if order.status == OrderStatus::Refunded {
        return Err(AppError::BadRequest("Order has already been refunded".to_string()));
    }

    // 3. Generate unique refund number
    let refund_no = format!("REF-{}", Utc::now().timestamp_millis());
    let destination = payload.destination.unwrap_or_else(|| "wallet".to_string());

    // 4. Insert refund record into refunds table
    let refund = sqlx::query_as::<_, Refund>(
        r#"
        INSERT INTO refunds (
            refund_no, order_id, user_id, amount_paise, destination,
            reason, verdict, approved_by, status, processed_at
        ) VALUES (
            $1, $2, $3, $4, $5, $6, 'legit_issue', $7, 'success', now()
        )
        RETURNING id, refund_no, order_id, payment_tx_id, user_id, amount_paise,
                  destination, reason, verdict, approved_by, gateway_ref, status,
                  requested_at, processed_at, created_at
        "#,
    )
    .bind(&refund_no)
    .bind(order.id)
    .bind(order.user_id)
    .bind(order.final_paise)
    .bind(&destination)
    .bind(&payload.reason)
    .bind(admin_id)
    .fetch_one(&mut *tx)
    .await
    .map_err(AppError::Database)?;

    // 5. Update order status to refunded
    sqlx::query("UPDATE orders SET status = 'refunded', updated_at = now() WHERE id = $1")
        .bind(id)
        .execute(&mut *tx)
        .await
        .map_err(AppError::Database)?;

    // 6. If wallet destination, invoke fn_wallet_credit to preserve append-only accounting ledger
    if destination == "wallet" && order.user_id.is_some() {
        let user_id = order.user_id.unwrap();
        sqlx::query(
            r#"
            SELECT fn_wallet_credit(
                $1,
                $2::int8,
                'refund'::wallet_tx_type,
                'refund',
                $3,
                NULL,
                $4
            )
            "#,
        )
        .bind(user_id)
        .bind(order.final_paise as i64)
        .bind(refund.id)
        .bind(format!("Refund for order {}", order.order_no))
        .execute(&mut *tx)
        .await
        .map_err(AppError::Database)?;
    }

    // 7. Commit atomic transaction
    tx.commit().await.map_err(AppError::Database)?;

    write_audit(
        &pool,
        admin_id,
        "order.refund",
        "orders",
        Some(order.id),
        json!({ "refund_id": refund.id, "amount_paise": refund.amount_paise, "destination": refund.destination }),
    )
    .await;

    Ok(Json(json!({
        "success": true,
        "refund": refund
    })))
}

// =============================================================================
//  DOMAIN 8 — SUPPORT & DISPUTE DESK
// =============================================================================

/// List support tickets
pub async fn list_tickets(
    State(pool): State<PgPool>,
) -> Result<impl IntoResponse, AppError> {
    let tickets = sqlx::query_as::<_, SupportTicket>(
        r#"
        SELECT id, ticket_no, user_id, machine_id, order_id, payment_tx_id,
               ticket_type, claim_amount_paise, claimed_time, utr, user_message,
               auto_context, status, priority, verdict, assigned_to, resolution,
               refund_id, whatsapp_sent_at, resolved_at, created_at, updated_at
        FROM support_tickets
        ORDER BY created_at DESC
        LIMIT 50
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    Ok(Json(json!({
        "success": true,
        "count": tickets.len(),
        "tickets": tickets
    })))
}

/// Retrieve single dispute ticket with evidence and order sensor logs
pub async fn get_ticket(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
) -> Result<impl IntoResponse, AppError> {
    let ticket = sqlx::query_as::<_, SupportTicket>(
        r#"
        SELECT id, ticket_no, user_id, machine_id, order_id, payment_tx_id,
               ticket_type, claim_amount_paise, claimed_time, utr, user_message,
               auto_context, status, priority, verdict, assigned_to, resolution,
               refund_id, whatsapp_sent_at, resolved_at, created_at, updated_at
        FROM support_tickets
        WHERE id = $1
        "#,
    )
    .bind(id)
    .fetch_optional(&pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound(format!("Ticket {id} not found")))?;

    let evidence = sqlx::query_as::<_, TicketEvidence>(
        r#"
        SELECT id, ticket_id, evidence_type::text as evidence_type, ref_table, ref_id,
               clip_start, clip_end, sensor_snapshot, note, added_by, created_at
        FROM ticket_evidence
        WHERE ticket_id = $1
        ORDER BY created_at ASC
        "#,
    )
    .bind(id)
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let evidence_bundle: Option<serde_json::Value> = sqlx::query_scalar(
        "SELECT fn_ticket_evidence_bundle($1)"
    )
    .bind(id)
    .fetch_optional(&pool)
    .await
    .unwrap_or(None);

    Ok(Json(json!({
        "success": true,
        "ticket": ticket,
        "evidence": evidence,
        "evidence_bundle": evidence_bundle
    })))
}

/// Dispute Desk: Resolve ticket with verdict, optional refund or replacement code
pub async fn resolve_dispute(
    State(pool): State<PgPool>,
    Path(id): Path<Uuid>,
    Extension(claims): Extension<AdminClaims>,
    Json(payload): Json<DisputeResolutionRequest>,
) -> Result<impl IntoResponse, AppError> {
    if !claims.can_resolve_tickets() {
        return Err(AppError::Forbidden(
            "Access denied: Only support, ops, and owner roles can resolve dispute tickets".to_string(),
        ));
    }

    let admin_id = Uuid::parse_str(&claims.sub).ok();

    let target_status = match payload.action.as_str() {
        "refund_now" => TicketStatus::ResolvedRefund,
        "reject_fraud" => TicketStatus::Rejected,
        "await_info" => TicketStatus::AwaitingCustomer,
        _ => TicketStatus::Closed,
    };

    // 1. Audit status transition in ticket_status_history
    let _ = sqlx::query(
        r#"
        INSERT INTO ticket_status_history (
            ticket_id, from_status, to_status, from_verdict, to_verdict, changed_by, note
        ) VALUES (
            $1, (SELECT status FROM support_tickets WHERE id = $1), $2,
            (SELECT verdict FROM support_tickets WHERE id = $1), $3, $4, $5
        )
        "#,
    )
    .bind(id)
    .bind(target_status)
    .bind(payload.verdict)
    .bind(admin_id)
    .bind(&payload.resolution_notes)
    .execute(&pool)
    .await;

    // 2. Update ticket status and resolution
    let updated_ticket = sqlx::query_as::<_, SupportTicket>(
        r#"
        UPDATE support_tickets
        SET status = $2,
            verdict = $3,
            resolution = $4,
            assigned_to = coalesce(assigned_to, $5),
            resolved_at = now(),
            updated_at = now()
        WHERE id = $1
        RETURNING id, ticket_no, user_id, machine_id, order_id, payment_tx_id,
                  ticket_type, claim_amount_paise, claimed_time, utr, user_message,
                  auto_context, status, priority, verdict, assigned_to, resolution,
                  refund_id, whatsapp_sent_at, resolved_at, created_at, updated_at
        "#,
    )
    .bind(id)
    .bind(target_status)
    .bind(payload.verdict)
    .bind(&payload.resolution_notes)
    .bind(admin_id)
    .fetch_one(&pool)
    .await
    .map_err(AppError::Database)?;

    write_audit(
        &pool,
        admin_id,
        "ticket.resolve",
        "support_tickets",
        Some(updated_ticket.id),
        json!({ "verdict": updated_ticket.verdict, "status": updated_ticket.status }),
    )
    .await;

    Ok(Json(json!({
        "success": true,
        "resolved_ticket": updated_ticket
    })))
}

/// WhatsApp grievance intake webhook: creates ticket & compiles fn_ticket_evidence_bundle
pub async fn whatsapp_intake_handler(
    State(pool): State<PgPool>,
    Json(payload): Json<WhatsAppTicketIntakeRequest>,
) -> Result<impl IntoResponse, AppError> {
    let clean_phone = payload.phone.trim();
    if clean_phone.is_empty() {
        return Err(AppError::BadRequest("Phone number is required for WhatsApp intake".to_string()));
    }

    // 1. Resolve user by phone
    let user_id: Option<Uuid> = sqlx::query_scalar("SELECT id FROM users WHERE phone = $1 OR phone = $2 LIMIT 1")
        .bind(clean_phone)
        .bind(format!("+91{}", clean_phone.trim_start_matches("+91").trim_start_matches('0')))
        .fetch_optional(&pool)
        .await
        .unwrap_or(None);

    // 2. Resolve order & machine if order_no or upi_ref provided
    let order_info: Option<(Uuid, Option<Uuid>, i32)> = if let Some(ref ono) = payload.order_no {
        sqlx::query_as("SELECT id, machine_id, final_paise FROM orders WHERE order_no = $1 LIMIT 1")
            .bind(ono)
            .fetch_optional(&pool)
            .await
            .unwrap_or(None)
    } else if let Some(ref utr) = payload.upi_ref {
        sqlx::query_as("SELECT o.id, o.machine_id, o.final_paise FROM payment_transactions pt JOIN orders o ON o.id = pt.order_id WHERE pt.gateway_ref = $1 LIMIT 1")
            .bind(utr)
            .fetch_optional(&pool)
            .await
            .unwrap_or(None)
    } else {
        None
    };

    let (order_id, machine_id, claim_amount) = match order_info {
        Some((oid, mid, amt)) => (Some(oid), mid, amt),
        None => (None, None, 0),
    };

    let ticket_no = format!("TKT-{}", Utc::now().timestamp_millis() % 100000);
    let t_type = payload.ticket_type.unwrap_or_else(|| "no_coffee".to_string());

    // 3. Create ticket in support_tickets table
    let ticket = sqlx::query_as::<_, SupportTicket>(
        r#"
        INSERT INTO support_tickets (
            ticket_no, user_id, machine_id, order_id, ticket_type,
            claim_amount_paise, utr, user_message, status, priority,
            verdict, auto_context, created_at, updated_at
        ) VALUES (
            $1, $2, $3, $4, $5::ticket_type,
            $6, $7, $8, 'open', 2,
            'pending', jsonb_build_object('source', 'whatsapp_bot', 'phone', $9), now(), now()
        )
        RETURNING id, ticket_no, user_id, machine_id, order_id, payment_tx_id,
                  ticket_type, claim_amount_paise, claimed_time, utr, user_message,
                  auto_context, status, priority, verdict, assigned_to, resolution,
                  refund_id, whatsapp_sent_at, resolved_at, created_at, updated_at
        "#
    )
    .bind(&ticket_no)
    .bind(user_id)
    .bind(machine_id)
    .bind(order_id)
    .bind(&t_type)
    .bind(claim_amount)
    .bind(&payload.upi_ref)
    .bind(&payload.message)
    .bind(clean_phone)
    .fetch_one(&pool)
    .await
    .map_err(AppError::Database)?;

    // 4. Generate evidence bundle via PostgreSQL fn_ticket_evidence_bundle
    let evidence_bundle: Option<serde_json::Value> = sqlx::query_scalar(
        "SELECT fn_ticket_evidence_bundle($1)"
    )
    .bind(ticket.id)
    .fetch_optional(&pool)
    .await
    .unwrap_or(None);

    Ok((
        StatusCode::CREATED,
        Json(json!({
            "success": true,
            "message": format!("WhatsApp ticket {} registered successfully", ticket.ticket_no),
            "ticket": ticket,
            "evidence_bundle": evidence_bundle
        }))
    ))
}

/// Sweep ticket SLA timers:
/// 1. Auto-close tickets in 'awaiting_customer' older than 48 hours
/// 2. Auto-close resolved tickets ('resolved_refund', 'resolved_reject') older than 7 days
pub async fn sweep_ticket_timers(
    State(pool): State<PgPool>,
) -> Result<impl IntoResponse, AppError> {
    // 1. Auto-close 48h awaiting_customer
    let awaiting_closed = sqlx::query(
        r#"
        WITH expired AS (
            UPDATE support_tickets
            SET status = 'closed',
                resolution = coalesce(resolution, 'Auto-closed: No response from customer within 48h SLA window'),
                resolved_at = coalesce(resolved_at, now()),
                updated_at = now()
            WHERE status = 'awaiting_customer'
              AND updated_at < (now() - interval '48 hours')
            RETURNING id, status, verdict
        )
        INSERT INTO ticket_status_history (ticket_id, from_status, to_status, from_verdict, to_verdict, changed_by, note)
        SELECT id, 'awaiting_customer'::ticket_status, 'closed'::ticket_status, verdict, verdict, NULL, 'System SLA watchdog: 48h customer timeout'
        FROM expired
        "#,
    )
    .execute(&pool)
    .await
    .map_err(AppError::Database)?
    .rows_affected();

    // 2. Terminal closure: 7d post-resolution
    let resolved_closed = sqlx::query(
        r#"
        WITH terminal AS (
            UPDATE support_tickets
            SET status = 'closed',
                updated_at = now()
            WHERE status IN ('resolved_refund', 'resolved_reject')
              AND resolved_at < (now() - interval '7 days')
            RETURNING id, status, verdict
        )
        INSERT INTO ticket_status_history (ticket_id, from_status, to_status, from_verdict, to_verdict, changed_by, note)
        SELECT id, status, 'closed'::ticket_status, verdict, verdict, NULL, 'Terminal 7-day post-resolution closure'
        FROM terminal
        "#,
    )
    .execute(&pool)
    .await
    .map_err(AppError::Database)?
    .rows_affected();

    Ok(Json(json!({
        "success": true,
        "awaiting_customer_closed_48h": awaiting_closed,
        "resolved_closed_7d": resolved_closed,
        "total_closed": awaiting_closed + resolved_closed,
        "swept_at": Utc::now()
    })))
}

// =============================================================================
//  LIVE READ MODELS — admin panel adapters (P1)
//  Read-only, joined projections consumed by the Next.js server components.
// =============================================================================

/// GET /api/live/orders — orders enriched with machine, product, customer, code.
pub async fn live_orders(State(pool): State<PgPool>) -> Result<impl IntoResponse, AppError> {
    let rows = sqlx::query(
        r#"
        SELECT o.id, o.order_no, o.status::text AS status,
               o.machine_id, m.machine_code, m.name AS machine_name,
               o.product_id, p.name AS product_name, p.short_name AS product_short,
               o.amount_paise, o.discount_paise, o.final_paise, o.cost_basis_paise,
               o.payment_method::text AS payment_method,
               o.ordered_at, o.user_id, u.phone AS user_phone,
               q.random_id AS code_value, q.source AS code_source,
               q.issued_at AS code_issued_at, q.expires_at AS code_expires_at,
               q.share_count AS code_shared, q.delivered AS code_redeemed,
               d.dispensed_ml::float8 AS dispensed_ml, d.expected_ml::float8 AS expected_ml,
               d.variance_pct::float8 AS variance_pct, d.cup_detected, d.kit_dropped
        FROM orders o
        JOIN machines m ON m.id = o.machine_id
        JOIN products p ON p.id = o.product_id
        LEFT JOIN users u ON u.id = o.user_id
        LEFT JOIN qr_codes q ON q.id = o.code_id
        LEFT JOIN dispense_logs d ON d.order_id = o.id
        ORDER BY o.ordered_at DESC
        LIMIT 200
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let orders: Vec<serde_json::Value> = rows
        .iter()
        .map(|r| {
            json!({
                "id": r.try_get::<Uuid, _>("id").ok(),
                "order_no": r.try_get::<String, _>("order_no").ok(),
                "status": r.try_get::<String, _>("status").ok(),
                "machine_id": r.try_get::<Uuid, _>("machine_id").ok(),
                "machine_code": r.try_get::<String, _>("machine_code").ok(),
                "machine_name": r.try_get::<String, _>("machine_name").ok(),
                "product_id": r.try_get::<Uuid, _>("product_id").ok(),
                "product_name": r.try_get::<String, _>("product_name").ok(),
                "product_short": r.try_get::<String, _>("product_short").ok(),
                "amount_paise": r.try_get::<i32, _>("amount_paise").ok(),
                "discount_paise": r.try_get::<i32, _>("discount_paise").ok(),
                "final_paise": r.try_get::<i32, _>("final_paise").ok(),
                "cost_basis_paise": r.try_get::<i32, _>("cost_basis_paise").ok(),
                "payment_method": r.try_get::<String, _>("payment_method").ok(),
                "ordered_at": r.try_get::<DateTime<Utc>, _>("ordered_at").ok(),
                "user_id": r.try_get::<Option<Uuid>, _>("user_id").ok().flatten(),
                "user_phone": r.try_get::<Option<String>, _>("user_phone").ok().flatten(),
                "code_value": r.try_get::<Option<String>, _>("code_value").ok().flatten(),
                "code_source": r.try_get::<Option<String>, _>("code_source").ok().flatten(),
                "code_issued_at": r.try_get::<Option<DateTime<Utc>>, _>("code_issued_at").ok().flatten(),
                "code_expires_at": r.try_get::<Option<DateTime<Utc>>, _>("code_expires_at").ok().flatten(),
                "code_shared": r.try_get::<Option<i32>, _>("code_shared").ok().flatten(),
                "code_redeemed": r.try_get::<Option<bool>, _>("code_redeemed").ok().flatten(),
                "dispensed_ml": r.try_get::<Option<f64>, _>("dispensed_ml").ok().flatten(),
                "expected_ml": r.try_get::<Option<f64>, _>("expected_ml").ok().flatten(),
                "variance_pct": r.try_get::<Option<f64>, _>("variance_pct").ok().flatten(),
                "cup_detected": r.try_get::<Option<bool>, _>("cup_detected").ok().flatten(),
                "kit_dropped": r.try_get::<Option<bool>, _>("kit_dropped").ok().flatten(),
            })
        })
        .collect();

    Ok(Json(json!({ "success": true, "count": orders.len(), "orders": orders })))
}

/// GET /api/live/tickets — support queue with machine + customer context.
pub async fn live_tickets(State(pool): State<PgPool>) -> Result<impl IntoResponse, AppError> {
    let rows = sqlx::query(
        r#"
        SELECT t.id, t.ticket_no, t.status::text AS status, t.ticket_type::text AS ticket_type,
               t.verdict::text AS verdict, t.priority, t.claim_amount_paise,
               t.user_message, t.assigned_to, t.created_at, t.resolved_at,
               t.machine_id, m.machine_code, m.name AS machine_name,
               t.user_id, u.phone AS user_phone
        FROM support_tickets t
        LEFT JOIN machines m ON m.id = t.machine_id
        LEFT JOIN users u ON u.id = t.user_id
        ORDER BY t.created_at DESC
        LIMIT 200
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let tickets: Vec<serde_json::Value> = rows
        .iter()
        .map(|r| {
            json!({
                "id": r.try_get::<Uuid, _>("id").ok(),
                "ticket_no": r.try_get::<String, _>("ticket_no").ok(),
                "status": r.try_get::<String, _>("status").ok(),
                "ticket_type": r.try_get::<String, _>("ticket_type").ok(),
                "verdict": r.try_get::<String, _>("verdict").ok(),
                "priority": r.try_get::<i16, _>("priority").ok(),
                "claim_amount_paise": r.try_get::<i32, _>("claim_amount_paise").ok(),
                "user_message": r.try_get::<Option<String>, _>("user_message").ok().flatten(),
                "assigned_to": r.try_get::<Option<Uuid>, _>("assigned_to").ok().flatten(),
                "created_at": r.try_get::<DateTime<Utc>, _>("created_at").ok(),
                "resolved_at": r.try_get::<Option<DateTime<Utc>>, _>("resolved_at").ok().flatten(),
                "machine_id": r.try_get::<Option<Uuid>, _>("machine_id").ok().flatten(),
                "machine_code": r.try_get::<Option<String>, _>("machine_code").ok().flatten(),
                "machine_name": r.try_get::<Option<String>, _>("machine_name").ok().flatten(),
                "user_id": r.try_get::<Option<Uuid>, _>("user_id").ok().flatten(),
                "user_phone": r.try_get::<Option<String>, _>("user_phone").ok().flatten(),
            })
        })
        .collect();

    Ok(Json(json!({ "success": true, "count": tickets.len(), "tickets": tickets })))
}

/// GET /api/live/customers — users with wallet balance + lifetime order stats.
pub async fn live_customers(State(pool): State<PgPool>) -> Result<impl IntoResponse, AppError> {
    let rows = sqlx::query(
        r#"
        SELECT u.id, u.phone, u.status::text AS status, u.is_verified,
               u.created_at, u.last_seen_at,
               coalesce(w.balance_paise, 0)::int8 AS wallet_paise,
               coalesce(w.lifetime_spent_paise, 0)::int8 AS lifetime_spent_paise,
               count(o.id)::int8 AS order_count,
               coalesce(sum(o.final_paise), 0)::int8 AS spend_paise,
               max(o.ordered_at) AS last_order_at
        FROM users u
        LEFT JOIN wallets w ON w.user_id = u.id
        LEFT JOIN orders o ON o.user_id = u.id
        GROUP BY u.id, u.phone, u.status, u.is_verified, u.created_at, u.last_seen_at,
                 w.balance_paise, w.lifetime_spent_paise
        ORDER BY u.created_at DESC
        LIMIT 200
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let customers: Vec<serde_json::Value> = rows
        .iter()
        .map(|r| {
            json!({
                "id": r.try_get::<Uuid, _>("id").ok(),
                "phone": r.try_get::<String, _>("phone").ok(),
                "status": r.try_get::<String, _>("status").ok(),
                "is_verified": r.try_get::<bool, _>("is_verified").ok(),
                "created_at": r.try_get::<DateTime<Utc>, _>("created_at").ok(),
                "last_seen_at": r.try_get::<Option<DateTime<Utc>>, _>("last_seen_at").ok().flatten(),
                "wallet_paise": r.try_get::<i64, _>("wallet_paise").ok(),
                "lifetime_spent_paise": r.try_get::<i64, _>("lifetime_spent_paise").ok(),
                "order_count": r.try_get::<i64, _>("order_count").ok(),
                "spend_paise": r.try_get::<i64, _>("spend_paise").ok(),
                "last_order_at": r.try_get::<Option<DateTime<Utc>>, _>("last_order_at").ok().flatten(),
            })
        })
        .collect();

    Ok(Json(json!({ "success": true, "count": customers.len(), "customers": customers })))
}

/// GET /api/live/inventory — per-machine stock rows with reorder thresholds.
pub async fn live_inventory(State(pool): State<PgPool>) -> Result<impl IntoResponse, AppError> {
    let rows = sqlx::query(
        r#"
        SELECT s.id, s.machine_id, m.machine_code, m.name AS machine_name, m.city,
               s.item_type::text AS item_type, s.variant_key, s.quantity,
               s.reorder_threshold, s.updated_at
        FROM machine_stock s
        JOIN machines m ON m.id = s.machine_id
        ORDER BY m.machine_code ASC, s.item_type ASC
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let stock: Vec<serde_json::Value> = rows
        .iter()
        .map(|r| {
            json!({
                "id": r.try_get::<Uuid, _>("id").ok(),
                "machine_id": r.try_get::<Uuid, _>("machine_id").ok(),
                "machine_code": r.try_get::<String, _>("machine_code").ok(),
                "machine_name": r.try_get::<String, _>("machine_name").ok(),
                "city": r.try_get::<Option<String>, _>("city").ok().flatten(),
                "item_type": r.try_get::<String, _>("item_type").ok(),
                "variant_key": r.try_get::<String, _>("variant_key").ok(),
                "quantity": r.try_get::<i32, _>("quantity").ok(),
                "reorder_threshold": r.try_get::<i32, _>("reorder_threshold").ok(),
                "updated_at": r.try_get::<DateTime<Utc>, _>("updated_at").ok(),
            })
        })
        .collect();

    Ok(Json(json!({ "success": true, "count": stock.len(), "stock": stock })))
}

/// GET /api/live/tanks — milk tank lifecycle rows.
pub async fn live_tanks(State(pool): State<PgPool>) -> Result<impl IntoResponse, AppError> {
    let rows = sqlx::query(
        r#"
        SELECT t.id, t.tank_uid, t.machine_id, m.machine_code, m.name AS machine_name,
               t.capacity_l::float8 AS capacity_l, t.filled_l::float8 AS filled_l,
               t.status::text AS status, t.filled_at, t.expires_at, t.mounted_at,
               t.source, t.batch_ref
        FROM machine_tanks t
        LEFT JOIN machines m ON m.id = t.machine_id
        ORDER BY t.created_at DESC
        LIMIT 200
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let tanks: Vec<serde_json::Value> = rows
        .iter()
        .map(|r| {
            json!({
                "id": r.try_get::<Uuid, _>("id").ok(),
                "tank_uid": r.try_get::<String, _>("tank_uid").ok(),
                "machine_id": r.try_get::<Option<Uuid>, _>("machine_id").ok().flatten(),
                "machine_code": r.try_get::<Option<String>, _>("machine_code").ok().flatten(),
                "machine_name": r.try_get::<Option<String>, _>("machine_name").ok().flatten(),
                "capacity_l": r.try_get::<f64, _>("capacity_l").ok(),
                "filled_l": r.try_get::<Option<f64>, _>("filled_l").ok().flatten(),
                "status": r.try_get::<String, _>("status").ok(),
                "filled_at": r.try_get::<Option<DateTime<Utc>>, _>("filled_at").ok().flatten(),
                "expires_at": r.try_get::<Option<DateTime<Utc>>, _>("expires_at").ok().flatten(),
                "mounted_at": r.try_get::<Option<DateTime<Utc>>, _>("mounted_at").ok().flatten(),
                "source": r.try_get::<Option<String>, _>("source").ok().flatten(),
                "batch_ref": r.try_get::<Option<String>, _>("batch_ref").ok().flatten(),
            })
        })
        .collect();

    Ok(Json(json!({ "success": true, "count": tanks.len(), "tanks": tanks })))
}

/// GET /api/live/analytics — pre-computed reporting views.
pub async fn live_analytics(State(pool): State<PgPool>) -> Result<impl IntoResponse, AppError> {
    let daily = sqlx::query("SELECT * FROM v_admin_sales_daily ORDER BY sales_date DESC LIMIT 60")
        .fetch_all(&pool)
        .await
        .map_err(AppError::Database)?;
    let products = sqlx::query("SELECT * FROM v_admin_product_mix ORDER BY revenue_paise DESC")
        .fetch_all(&pool)
        .await
        .map_err(AppError::Database)?;
    let machines = sqlx::query("SELECT * FROM v_admin_machine_performance ORDER BY revenue_paise DESC")
        .fetch_all(&pool)
        .await
        .map_err(AppError::Database)?;

    let to_daily = |rows: &[sqlx::postgres::PgRow]| -> Vec<serde_json::Value> {
        rows.iter()
            .map(|r| json!({
                "sales_date": r.try_get::<chrono::NaiveDate, _>("sales_date").ok(),
                "orders": r.try_get::<i64, _>("orders").ok(),
                "delivered": r.try_get::<i64, _>("delivered").ok(),
                "refunded": r.try_get::<i64, _>("refunded").ok(),
                "gross_paise": r.try_get::<i64, _>("gross_paise").ok(),
                "net_paise": r.try_get::<i64, _>("net_paise").ok(),
                "cost_paise": r.try_get::<i64, _>("cost_paise").ok(),
            }))
            .collect()
    };
    let to_products = |rows: &[sqlx::postgres::PgRow]| -> Vec<serde_json::Value> {
        rows.iter()
            .map(|r| json!({
                "product_id": r.try_get::<Uuid, _>("product_id").ok(),
                "slug": r.try_get::<String, _>("slug").ok(),
                "name": r.try_get::<String, _>("name").ok(),
                "orders": r.try_get::<i64, _>("orders").ok(),
                "revenue_paise": r.try_get::<i64, _>("revenue_paise").ok(),
                "cost_paise": r.try_get::<i64, _>("cost_paise").ok(),
                "gross_margin_paise": r.try_get::<i64, _>("gross_margin_paise").ok(),
            }))
            .collect()
    };
    let to_machines = |rows: &[sqlx::postgres::PgRow]| -> Vec<serde_json::Value> {
        rows.iter()
            .map(|r| json!({
                "machine_id": r.try_get::<Uuid, _>("machine_id").ok(),
                "machine_code": r.try_get::<String, _>("machine_code").ok(),
                "name": r.try_get::<String, _>("name").ok(),
                "total_orders": r.try_get::<i64, _>("total_orders").ok(),
                "failed_orders": r.try_get::<i64, _>("failed_orders").ok(),
                "revenue_paise": r.try_get::<i64, _>("revenue_paise").ok(),
                "avg_variance_pct": r.try_get::<f64, _>("avg_variance_pct").ok(),
            }))
            .collect()
    };

    Ok(Json(json!({
        "success": true,
        "sales_daily": to_daily(&daily),
        "product_mix": to_products(&products),
        "machine_performance": to_machines(&machines),
    })))
}

/// GET /api/live/audit — recent admin/system audit trail.
pub async fn live_audit(State(pool): State<PgPool>) -> Result<impl IntoResponse, AppError> {
    let rows = sqlx::query(
        r#"
        SELECT id, actor_type::text AS actor_type, actor_id, action, entity_type,
               entity_id, created_at
        FROM audit_logs
        ORDER BY created_at DESC
        LIMIT 200
        "#,
    )
    .fetch_all(&pool)
    .await
    .map_err(AppError::Database)?;

    let entries: Vec<serde_json::Value> = rows
        .iter()
        .map(|r| {
            json!({
                "id": r.try_get::<i64, _>("id").ok(),
                "actor_type": r.try_get::<String, _>("actor_type").ok(),
                "actor_id": r.try_get::<Option<Uuid>, _>("actor_id").ok().flatten(),
                "action": r.try_get::<String, _>("action").ok(),
                "entity_type": r.try_get::<String, _>("entity_type").ok(),
                "entity_id": r.try_get::<Option<Uuid>, _>("entity_id").ok().flatten(),
                "created_at": r.try_get::<DateTime<Utc>, _>("created_at").ok(),
            })
        })
        .collect();

    Ok(Json(json!({ "success": true, "count": entries.len(), "entries": entries })))
}
