use std::net::SocketAddr;
use axum::{
    middleware::from_fn,
    routing::{get, patch, post},
    Router,
};
use tower_http::{
    cors::{Any, CorsLayer},
    trace::TraceLayer,
};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

mod config;
mod error;

// ─────────────────────────────────────────────────────────────────────────────
// MODULE SELECTION (P0-01)
//
// Both a monolithic file (`handlers.rs`) and a stale split tree
// (`handlers/mod.rs` + `handlers/*.rs`) exist in this crate. Rust refuses to
// compile when it finds both (`E0761: file for module found at both ...`).
//
// The monolithic files below are the CANONICAL implementation — they match
// `001_full_schema.sql` and contain the routes wired up in this file.
// The split tree is archived and must NOT be compiled. Explicit `#[path]`
// attributes make the selection unambiguous without deleting anything.
// ─────────────────────────────────────────────────────────────────────────────
#[path = "db.rs"]
mod db;
#[path = "handlers.rs"]
mod handlers;
#[path = "middleware.rs"]
mod middleware;
#[path = "models.rs"]
mod models;

use config::AppConfig;
use handlers::*;
use middleware::auth_middleware;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 1. Initialize Tracing & Logger
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info,manhattan_coffee_backend=debug".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    // 2. Load Configuration from Environment
    let config = AppConfig::from_env();
    tracing::info!("☕ Initializing Manhattan Coffee Rust Core Engine...");
    tracing::info!("📡 Database URL target: {}", &config.database_url);

    // 3. Connect to PostgreSQL via SQLx Connection Pool
    let pool = match db::create_pool(&config.database_url).await {
        Ok(pool) => {
            tracing::info!("✅ Connected to PostgreSQL database pool successfully.");
            pool
        }
        Err(err) => {
            tracing::warn!("⚠️ PostgreSQL connection warning: {}. Using fallback resilience mode.", err);
            // Attempt fallback or retry
            db::create_pool(&config.database_url).await.unwrap_or_else(|e| {
                tracing::error!("Fatal DB connection failure: {:?}", e);
                panic!("Cannot proceed without database pool: {}", e);
            })
        }
    };

    // 4. Setup CORS Layer
    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any);

    // 5. Build Public & Authenticated Routes
    let public_routes = Router::new()
        .route("/health", get(health_check))
        .route("/api/auth/login", post(login_handler))
        .route("/api/auth/otp/verify", post(otp_verify_handler))
        .route("/api/support/webhook/whatsapp", post(whatsapp_intake_handler))
        .route("/api/support/tickets/whatsapp", post(whatsapp_intake_handler));

    let protected_routes = Router::new()
        .route("/api/live/dashboard", get(live_dashboard))
        .route("/api/live/machines", get(live_machines))
        .route("/api/live/orders", get(live_orders))
        .route("/api/live/tickets", get(live_tickets))
        .route("/api/live/customers", get(live_customers))
        .route("/api/live/inventory", get(live_inventory))
        .route("/api/live/tanks", get(live_tanks))
        .route("/api/live/analytics", get(live_analytics))
        .route("/api/live/audit", get(live_audit))
        .route("/api/auth/me", get(me_handler))
        .route("/api/machines", get(list_machines))
        .route("/api/machines/:id", get(get_machine))
        .route("/api/machines/:id/telemetry", patch(update_telemetry))
        .route("/api/machines/:id/command", post(dispatch_hardware_command))
        .route("/api/machines/:id/commands", get(list_machine_commands))
        .route("/api/commands/:id/ack", post(ack_machine_command))
        .route("/api/orders", get(list_orders))
        .route("/api/orders/:id", get(get_order))
        .route("/api/orders/:id/refund", post(process_refund))
        .route("/api/support/tickets", get(list_tickets))
        .route("/api/support/tickets/:id", get(get_ticket))
        .route("/api/support/tickets/:id/resolve", post(resolve_dispute))
        .route("/api/support/tickets/sweep", post(sweep_ticket_timers))
        .layer(from_fn(auth_middleware));

    // Combine all routes
    let app = Router::new()
        .merge(public_routes)
        .merge(protected_routes)
        .layer(cors)
        .layer(TraceLayer::new_for_http())
        .with_state(pool);

    // 6. Bind TCP Listener and Run Server
    let addr = SocketAddr::from(([0, 0, 0, 0], config.server_port));
    tracing::info!("🚀 Manhattan Coffee Rust Backend listening on http://{}", addr);

    let listener = tokio::net::TcpListener::bind(&addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}
