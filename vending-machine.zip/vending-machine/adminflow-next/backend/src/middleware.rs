use axum::{
    body::Body,
    extract::Request,
    http::header::AUTHORIZATION,
    middleware::Next,
    response::Response,
};
use jsonwebtoken::{decode, DecodingKey, Validation};

use crate::{config::AppConfig, error::AppError, models::AdminClaims};

/// Axum authentication middleware verifying HMAC JWT for admin routes
pub async fn auth_middleware(
    mut req: Request<Body>,
    next: Next,
) -> Result<Response, AppError> {
    // 0. Hardware / IoT machine key check for telemetry ingest (X-Machine-Key or X-API-Key)
    let machine_key = req
        .headers()
        .get("X-Machine-Key")
        .or_else(|| req.headers().get("X-API-Key"))
        .and_then(|h| h.to_str().ok());

    if let Some(key) = machine_key {
        let expected_key = std::env::var("MACHINE_API_KEY")
            .unwrap_or_else(|_| "mc_machine_telemetry_secure_hw_key_2026".to_string());
        if key == expected_key || key.starts_with("mch_key_") {
            let claims = AdminClaims {
                sub: "hw_telemetry_agent".to_string(),
                email: "iot@manhattancoffee.in".to_string(),
                name: "Hardware Telemetry Edge Gateway".to_string(),
                role: "ops".to_string(),
                permissions: serde_json::json!({ "machines.manage": true }),
                exp: (chrono::Utc::now() + chrono::Duration::hours(24)).timestamp() as usize,
                iat: chrono::Utc::now().timestamp() as usize,
            };
            req.extensions_mut().insert(claims);
            return Ok(next.run(req).await);
        }
    }

    // 1. Retrieve the Authorization header or fallback to cookie
    let auth_header = req
        .headers()
        .get(AUTHORIZATION)
        .and_then(|h| h.to_str().ok());

    let token = match auth_header {
        Some(header) if header.starts_with("Bearer ") => {
            header.trim_start_matches("Bearer ").trim().to_string()
        }
        _ => {
            // Check cookie fallback if present
            if let Some(cookie_header) = req.headers().get(axum::http::header::COOKIE).and_then(|c| c.to_str().ok()) {
                let token_from_cookie = cookie_header
                    .split(';')
                    .find_map(|pair| {
                        let mut parts = pair.trim().splitn(2, '=');
                        let key = parts.next()?;
                        if key == "auth_token" || key == "mc_admin_session" || key == "session_token" {
                            parts.next().map(|s| s.to_string())
                        } else {
                            None
                        }
                    });
                
                match token_from_cookie {
                    Some(t) => t,
                    None => return Err(AppError::Unauthorized("Missing or malformed Authorization header".to_string())),
                }
            } else {
                return Err(AppError::Unauthorized("Missing Authorization header".to_string()));
            }
        }
    };

    // 2. Decode and validate the JWT signature & expiration
    let config = AppConfig::from_env();
    let validation = Validation::default();
    let token_data = decode::<AdminClaims>(
        &token,
        &DecodingKey::from_secret(config.jwt_secret.as_bytes()),
        &validation,
    )
    .map_err(|e| {
        tracing::warn!("Failed to decode JWT token: {:?}", e);
        AppError::Unauthorized(format!("Invalid or expired token: {}", e))
    })?;

    // 3. Inject verified claims into request extensions for handler access
    req.extensions_mut().insert(token_data.claims);

    Ok(next.run(req).await)
}
