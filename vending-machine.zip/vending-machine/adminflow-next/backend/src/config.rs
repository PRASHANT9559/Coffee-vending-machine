use std::env;

#[derive(Clone, Debug)]
pub struct AppConfig {
    pub server_host: String,
    pub server_port: u16,
    pub database_url: String,
    pub jwt_secret: String,
    pub upload_dir: String,
    pub is_production: bool,
}

const MIN_SECRET_LEN: usize = 32;
const DEV_SECRET: &str = "dev-only-insecure-secret-change-me-32+chars";

fn is_production() -> bool {
    ["APP_ENV", "ENVIRONMENT", "NODE_ENV"]
        .iter()
        .find_map(|k| env::var(k).ok())
        .map(|v| v.eq_ignore_ascii_case("production") || v.eq_ignore_ascii_case("prod"))
        .unwrap_or(false)
}

impl AppConfig {
    pub fn from_env() -> Self {
        dotenvy::dotenv().ok();
        let is_production = is_production();

        let server_host = env::var("SERVER_HOST").unwrap_or_else(|_| "0.0.0.0".to_string());
        let server_port = env::var("PORT")
            .unwrap_or_else(|_| env::var("SERVER_PORT").unwrap_or_else(|_| "8080".to_string()))
            .parse::<u16>()
            .unwrap_or(8080);

        // P0-07: one secret name shared with the Next.js app, with a hard
        // failure in production instead of a silent, forgeable fallback.
        let jwt_secret = env::var("ADMIN_JWT_SECRET")
            .or_else(|_| env::var("JWT_SECRET"))
            .unwrap_or_else(|_| {
                if is_production {
                    panic!(
                        "FATAL: ADMIN_JWT_SECRET is not set. Refusing to start in production \
                         with an insecure default."
                    );
                }
                DEV_SECRET.to_string()
            });

        if jwt_secret.len() < MIN_SECRET_LEN {
            panic!(
                "FATAL: ADMIN_JWT_SECRET must be at least {} characters (got {}).",
                MIN_SECRET_LEN,
                jwt_secret.len()
            );
        }

        let database_url = env::var("DATABASE_URL").unwrap_or_else(|_| {
            if is_production {
                panic!("FATAL: DATABASE_URL is not set.");
            }
            "postgresql://manhattan_user:manhattan_secure_pass@localhost:5432/manhattan_coffee"
                .to_string()
        });

        let upload_dir = env::var("UPLOAD_DIR").unwrap_or_else(|_| {
            "/var/www/manhattan/uploads".to_string()
        });

        Self {
            server_host,
            server_port,
            database_url,
            jwt_secret,
            upload_dir,
            is_production,
        }
    }
}
