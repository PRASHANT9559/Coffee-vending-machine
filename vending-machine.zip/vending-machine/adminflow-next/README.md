# Manhattan Coffee — Admin Panel

Next.js 15 admin console for the Manhattan Coffee vending fleet.

- Full setup instructions: see the repository root `README.md`.
- Rust API lives in `backend/` (canonical entry point: `backend/src/handlers.rs`).
- Auth: OTP + RFC-6238 TOTP; secrets are shared with the Rust service through
  `ADMIN_JWT_SECRET` (see `.env.example`).
- Mock data is only used when `DEMO_MODE=1` and `NODE_ENV !== production`.

## Scripts

```bash
npm install
npm run dev      # local dev server
npm run build    # production build
npm run lint     # eslint
npx tsc --noEmit # type check
```

The dashboard and machine-command history read from the Rust service; most
other list pages are still being migrated from `lib/mock/*` (tracked in
`PROJECT-READINESS-REPORT.md`).
