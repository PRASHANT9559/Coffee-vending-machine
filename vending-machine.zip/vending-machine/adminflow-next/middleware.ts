import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from 'jose';

/* ─────────────────────────────────────────────────────────────
   Guard pipeline step 1 — session token check (edge).
   Steps 2..n (expiry semantics, MFA, role gate, maintenance
   overlay) run server-side in lib/auth.ts + (admin)/layout.tsx.
   Unauthenticated navigation → redirect /login, keeping the
   intended path so the panel lands exactly where the admin
   tried to go (routing spec · guard flow).
   ───────────────────────────────────────────────────────────── */

export const SESSION_COOKIE = 'mc_admin_session';

const AUTH_PATHS = ['/login', '/mfa', '/forgot-password'];

function secret() {
  const raw = process.env.ADMIN_JWT_SECRET ?? process.env.JWT_SECRET;
  if (raw && raw.length >= 32) return new TextEncoder().encode(raw);
  if (process.env.NODE_ENV === 'production') {
    // Fail closed: never sign or accept sessions with a known dev secret.
    throw new Error('ADMIN_JWT_SECRET (>= 32 chars) must be set in production.');
  }
  return new TextEncoder().encode('dev-only-insecure-secret-change-me-32+chars');
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isAuthPage = AUTH_PATHS.some(p => pathname === p || pathname.startsWith(`${p}/`));

  const token = req.cookies.get(SESSION_COOKIE)?.value;
  let valid = false;
  if (token) {
    try {
      await jwtVerify(token, secret());
      valid = true;
    } catch {
      valid = false; // expired or forged — treated as absent
    }
  }

  if (isAuthPage) {
    // already signed in → never bounce back to login screens
    if (valid && (pathname === '/login' || pathname === '/')) {
      const url = req.nextUrl.clone();
      url.pathname = '/';
      url.search = '';
      return NextResponse.redirect(url);
    }
    return NextResponse.next();
  }

  if (!valid) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    url.search = '';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|ico|txt)).*)'],
};
