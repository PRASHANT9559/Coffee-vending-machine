import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { getMachines, getStock } from '@/lib/live';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconDroplet, IconCup, IconPlusCircle } from '@/components/ui/icons';

export default async function FleetInventoryPage() {
  const g = await requireCap('/inventory');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/inventory" />;

  const admin = g.admin;
  const canOps = roleCan(admin.role, 'machines');
  const machines = await getMachines();
  const stock = await getStock();

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑤ Inventory"
        title="Fleet Stock & Consumables Matrix"
        sub="Centralised matrix of kits, paper cups, milk volumes, and malai tanks across all deployed nodes."
        actions={
          <div className="flex gap-2">
            <Link
              href="/inventory/tanks"
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white border border-line hover:bg-page px-3 py-2 rounded-lg transition"
            >
              <IconDroplet className="w-4 h-4 text-brand-500" /> Tank Lifecycle
            </Link>
            <Link
              href="/inventory/supplies"
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white border border-line hover:bg-page px-3 py-2 rounded-lg transition"
            >
              Raw Supplies & Cost Basis
            </Link>
            <Link
              href="/inventory/waste"
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white border border-line hover:bg-page px-3 py-2 rounded-lg transition"
            >
              Waste Loss Log
            </Link>
            {canOps && (
              <ActionButton
                run={async () => demoAudit('inventory.bulk_refill', 'Fleet', 'bulk route refill executed for all nodes', admin.name, admin.role)}
                tone="primary"
              >
                <IconPlusCircle className="w-4 h-4" /> Bulk Route Refill
              </ActionButton>
            )}
          </div>
        }
      />

      <Card title="Node Stock Matrix" sub="Per-machine consumable inventories (machine_stock)">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Machine</th>
                <th className="py-2.5 px-3 text-left">City / Venue</th>
                <th className="py-2.5 px-3 text-right">Milk (L)</th>
                <th className="py-2.5 px-3 text-right">Cups</th>
                <th className="py-2.5 px-3 text-right">Manhattan Kits</th>
                <th className="py-2.5 px-3 text-right">Classic Kits</th>
                <th className="py-2.5 px-3 text-right">Frappe Kits</th>
                <th className="py-2.5 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {machines.map(m => {
                const machineStock = stock.filter(s => s.machineId === m.id);
                const mht = machineStock.find(s => s.variant === 'Manhattan Velvet')?.qty ?? 0;
                const cls = machineStock.find(s => s.variant === 'Classic Latte')?.qty ?? 0;
                const frp = machineStock.find(s => s.variant === 'Chilled Frappe')?.qty ?? 0;

                return (
                  <tr key={m.id} className="hover:bg-page/60">
                    <td className="py-3 px-3 font-semibold text-ink-900">
                      <Link href={`/machines/${m.id}/stock`} className="text-brand-600 hover:underline">
                        {m.code} · {m.name}
                      </Link>
                    </td>
                    <td className="py-3 px-3 text-ink-500">{m.venue}</td>
                    <td className="py-3 px-3 text-right font-mono font-semibold">{m.litres} L</td>
                    <td className="py-3 px-3 text-right font-mono font-semibold">{m.cups}</td>
                    <td className="py-3 px-3 text-right font-mono font-semibold">{mht}</td>
                    <td className="py-3 px-3 text-right font-mono font-semibold">
                      <span className={cls < 10 ? 'text-amber2-600 font-bold' : ''}>{cls}</span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-semibold">{frp}</td>
                    <td className="py-3 px-3 text-center">
                      <Tag tone={cls < 10 ? 'amber' : 'leaf'}>
                        {cls < 10 ? 'ATTENTION' : 'HEALTHY'}
                      </Tag>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <FootNote>
          Cells highlighted in amber reflect stock levels below warning thresholds. When an ingredient hits 0, the recipe is immediately blocked at the front-end kiosk.
        </FootNote>
      </Card>
    </div>
  );
}
