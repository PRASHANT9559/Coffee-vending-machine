import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconDownload } from '@/components/ui/icons';
import type { WasteRow } from '@/lib/mock/types';

export default async function InventoryWastePage() {
  const g = await requireCap('/inventory/waste');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/inventory/waste" />;

  const admin = g.admin;
  const canFinance = roleCan(admin.role, 'inventoryWrite');

  const wasteRows: WasteRow[] = [
    { id: 'w-1', tsLabel: 'Today · 6:30 AM', machine: 'MCH-001 · Campus Hub', kind: 'expired-tank', qty: '8 Litres', loss: 384, note: 'TNK-A29D exceeded 12h hold window — sanitized' },
    { id: 'w-2', tsLabel: 'Yesterday · 2:15 PM', machine: 'MCH-002 · Mall Lane', kind: 'clog', qty: '2 kits', loss: 50, note: 'Nozzle obstruction on Classic Latte recipe' },
    { id: 'w-3', tsLabel: 'Wed · 11:45 AM', machine: 'MCH-002 · Mall Lane', kind: 'over-pour', qty: '1 Litre malai', loss: 120, note: 'Peristaltic pump calibration over-pour' },
    { id: 'w-4', tsLabel: '28 Oct · 4:10 PM', machine: 'MCH-001 · Campus Hub', kind: 'damaged-cup', qty: '5 cups', loss: 15, note: 'Cup separator jam during rush hour' },
  ];

  const totalLoss = wasteRows.reduce((acc, r) => acc + r.loss, 0);

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <PageHead
        module="⑤ Inventory · Waste"
        title="Physical Waste & Ingredient Loss Audit"
        sub="Comprehensive write-off ledger for expired dairy tanks, mechanical nozzle clogs, damaged cups, and over-pour variance."
        actions={
          <div className="flex gap-2">
            <ActionButton
              run={async () => demoAudit('waste.export', 'Loss Ledger', 'exported monthly waste write-off ledger CSV', admin.name, admin.role)}
            >
              <IconDownload className="w-4 h-4" /> Export Loss Sheet
            </ActionButton>
            {canFinance && (
              <ActionButton
                run={async () => demoAudit('waste.log', 'Manual Write-off', 'logged 1 damaged cup pouch', admin.name, admin.role)}
                tone="primary"
              >
                Log Write-Off
              </ActionButton>
            )}
          </div>
        }
      />

      <div className="grid sm:grid-cols-3 gap-4">
        <div className="card p-5 bg-red-50/60 border-red-200">
          <p className="text-[11px] font-semibold text-red-600 uppercase tracking-wider">Total Monthly Loss</p>
          <p className="text-[28px] font-bold text-red-900 mt-1">{rs(totalLoss)}</p>
          <p className="text-[11px] text-red-700 mt-1">Direct material write-offs</p>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Loss as % of Revenue</p>
          <p className="text-[28px] font-bold text-ink-900 mt-1">0.38%</p>
          <p className="text-[11px] text-leaf-600 font-medium mt-1">Well within 1.5% target tolerance</p>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Main Driver</p>
          <p className="text-[28px] font-bold text-ink-900 mt-1">Dairy Hold</p>
          <p className="text-[11px] text-ink-500 mt-1">FSSAI 12h expiry compliance</p>
        </div>
      </div>

      <Card title="Detailed Waste Log" sub="machine_stock_events + machine_tank_events (kind = waste)">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Incident Timestamp</th>
                <th className="py-2.5 px-3 text-left">Node Location</th>
                <th className="py-2.5 px-3 text-left">Loss Category</th>
                <th className="py-2.5 px-3 text-left">Quantity</th>
                <th className="py-2.5 px-3 text-right">Write-off Cost</th>
                <th className="py-2.5 px-3 text-left">Technician Incident Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {wasteRows.map(w => (
                <tr key={w.id} className="hover:bg-page/60">
                  <td className="py-3 px-3 font-mono text-[11.5px] text-ink-500">{w.tsLabel}</td>
                  <td className="py-3 px-3 font-semibold text-ink-800">{w.machine}</td>
                  <td className="py-3 px-3">
                    <Tag tone={w.kind === 'expired-tank' ? 'red' : 'amber'}>
                      {w.kind.toUpperCase()}
                    </Tag>
                  </td>
                  <td className="py-3 px-3 font-mono font-semibold">{w.qty}</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-red-600">{rs(w.loss)}</td>
                  <td className="py-3 px-3 text-ink-600 text-[12px]">{w.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <FootNote>
          If any node exceeds 3× the fleet average in ingredient write-offs, automated preventative maintenance is scheduled.
        </FootNote>
      </Card>
    </div>
  );
}
