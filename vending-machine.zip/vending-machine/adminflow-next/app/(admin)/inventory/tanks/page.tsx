import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { FLEET_TANKS, FLEET_TANK_EVENTS } from '@/lib/mock/inventory';
import { Meter } from '@/components/ui/charts';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconDroplet, IconDownload } from '@/components/ui/icons';

export default async function FleetTanksPage() {
  const g = await requireCap('/inventory/tanks');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/inventory/tanks" />;

  const admin = g.admin;
  const canOps = roleCan(admin.role, 'machines');

  const activeTanks = FLEET_TANKS.filter(t => t.state !== 'disposed');
  const disposedTanks = FLEET_TANKS.filter(t => t.state === 'disposed');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑤ Inventory · Tanks"
        title="Fleet Milk Tank Lifecycle & FSSAI Bundle"
        sub="Every 20L fresh milk tank across all nodes. Real-time 12-hour hold compliance countdowns, pasteurization batch verification, and food safety disposal logs."
        actions={
          <div className="flex gap-2">
            <ActionButton
              run={async () => demoAudit('tank.export_fssai', 'All Nodes', 'exported FSSAI compliance evidence bundle PDF', admin.name, admin.role)}
              tone="primary"
            >
              <IconDownload className="w-4 h-4" /> Export FSSAI Evidence Bundle
            </ActionButton>
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Active & Near-Expiry Tanks in Circulation" sub="12-hour hard limit from pasteurization fill time">
            <div className="space-y-4 mt-2">
              {activeTanks.map(t => {
                const pct = Math.min(100, Math.round((t.ageH / t.holdH) * 100));
                const isNear = t.state === 'near';
                const isExp = t.state === 'expired';

                return (
                  <div key={t.id} className="p-4 rounded-xl border border-line bg-page/40">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <IconDroplet className="w-4 h-4 text-brand-500" />
                        <span className="font-mono font-bold text-[13px] text-ink-900">{t.uid}</span>
                        <Tag tone={isExp ? 'red' : isNear ? 'amber' : 'leaf'}>
                          {t.state.toUpperCase()}
                        </Tag>
                        {t.fssai && <Tag tone="leaf">FSSAI AUDITED</Tag>}
                      </div>
                      <span className="font-bold text-[14px]">{t.litres} L</span>
                    </div>

                    <div className="flex justify-between text-[11.5px] text-ink-500 mb-1.5">
                      <span>Mounted at: <strong>{t.machine}</strong></span>
                      <span className={isExp ? 'text-red-600 font-bold' : isNear ? 'text-amber2-600 font-semibold' : ''}>
                        {t.ageH}h elapsed of {t.holdH}h limit ({pct}%)
                      </span>
                    </div>

                    <Meter pct={pct} color={isExp ? '#DC2626' : isNear ? '#EAB308' : '#16A34A'} h={7} />

                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-line/60 text-[11px] text-ink-400">
                      <span>Filled at dairy: {t.filledLabel}</span>
                      {canOps && (
                        <div className="flex gap-2">
                          <ActionButton
                            small
                            run={async () => demoAudit('tank.dispose', `${t.machine} · ${t.uid}`, 'marked for immediate sanitization & disposal', admin.name, admin.role)}
                            tone={isExp ? 'danger' : 'neutral'}
                            confirm={`Mark tank ${t.uid} as disposed and log FSSAI waste write-off?`}
                          >
                            Mark Disposed
                          </ActionButton>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            <FootNote>
              FSSAI compliance mandates that HTST pasteurized milk must be maintained at &lt;6°C and used or disposed strictly within 12 hours of tank mounting.
            </FootNote>
          </Card>

          <Card title="Disposed & Sanitized Tanks" sub="Decommissioned batches and historical waste evidence">
            <div className="space-y-3">
              {disposedTanks.map(t => (
                <div key={t.id} className="p-3 bg-page rounded-xl border border-line flex items-center justify-between text-[12px]">
                  <div>
                    <span className="font-mono font-bold text-ink-800">{t.uid}</span>
                    <span className="text-ink-400 ml-2">from {t.machine}</span>
                    <p className="text-[11px] text-ink-500 mt-0.5">Reason: {t.disposeReason ?? 'Hold window expired'}</p>
                  </div>
                  <Tag tone="ink">DISPOSED & SANITIZED</Tag>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Dairy Supply Batch Details" sub="Supplier batch verification">
            <div className="space-y-3 text-[12.5px]">
              <div className="p-3 bg-leaf-50 border border-leaf-200 rounded-xl">
                <p className="font-bold text-leaf-900">Certified Supplier: Gowardhan Dairy</p>
                <p className="text-[11.5px] text-leaf-700 mt-1">
                  Daily refrigerated van deliveries at 05:30 AM. Temp on arrival logged at 3.8°C.
                </p>
              </div>
              <div className="p-3 bg-page border border-line rounded-xl">
                <p className="font-bold text-ink-800">FSSAI Central License</p>
                <p className="text-[11px] font-mono text-ink-500 mt-0.5">#11524036000192 · Valid thru 2029</p>
              </div>
            </div>
          </Card>

          <Card title="Recent Fleet Tank Events" sub="machine_tank_events across all nodes">
            <div className="space-y-3">
              {FLEET_TANK_EVENTS.map((ev, i) => (
                <div key={i} className="text-[12px] pb-2.5 border-b border-line last:border-none">
                  <div className="flex items-center justify-between font-semibold">
                    <span>{ev.machine}</span>
                    <Tag tone={ev.action === 'disposed' ? 'red' : 'leaf'}>{ev.action.toUpperCase()}</Tag>
                  </div>
                  <p className="text-ink-600 text-[11px] mt-0.5">{ev.detail}</p>
                  <div className="flex justify-between text-[10px] text-ink-400 mt-1 font-mono">
                    <span>{ev.tsLabel}</span>
                    <span>{ev.by}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
