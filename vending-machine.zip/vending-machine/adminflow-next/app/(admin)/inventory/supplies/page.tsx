import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { SUPPLIES, KIT_TEMPLATES } from '@/lib/mock/inventory';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';

export default async function InventorySuppliesPage() {
  const g = await requireCap('/inventory/supplies');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/inventory/supplies" />;

  const admin = g.admin;
  const canFinance = roleCan(admin.role, 'inventoryWrite');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑤ Inventory · Supplies"
        title="Raw Material Procurement & Cost Basis"
        sub="Raw ingredients, pouch packaging, unit costs, and kit recipe templates. Directly drives the dynamic cost basis calculation for order margins."
        actions={
          canFinance && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => demoAudit('supplies.adjust_cost', 'Supplies', 'updated coffee bean wholesale benchmark', admin.name, admin.role)}
                tone="primary"
              >
                Update Cost Basis
              </ActionButton>
            </div>
          )
        }
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Raw Material Supplies Inventory" sub="Current warehouse & node stockpile">
            <div className="overflow-x-auto -mx-1 px-1">
              <table className="w-full text-[12.5px] border-collapse">
                <thead>
                  <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                    <th className="py-2.5 px-3 text-left">Item Name</th>
                    <th className="py-2.5 px-3 text-right">On Hand</th>
                    <th className="py-2.5 px-3 text-right">Unit Wholesale Cost</th>
                    <th className="py-2.5 px-3 text-right">Cost Per Cup</th>
                    <th className="py-2.5 px-3 text-right">Reorder Threshold</th>
                    {canFinance && <th className="py-2.5 px-3 text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/60">
                  {SUPPLIES.map(sp => {
                    const costPerCup = sp.unitCost / Math.max(1, sp.servingsPerUnit);
                    const isLow = sp.onHand <= sp.reorder;

                    return (
                      <tr key={sp.id} className="hover:bg-page/60">
                        <td className="py-3 px-3 font-semibold text-ink-900">{sp.name}</td>
                        <td className="py-3 px-3 text-right font-mono font-bold">
                          <span className={isLow ? 'text-amber2-600' : ''}>
                            {sp.onHand} {sp.unit}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono">{rs(sp.unitCost)}</td>
                        <td className="py-3 px-3 text-right font-mono font-semibold text-brand-600">
                          ₹{costPerCup.toFixed(2)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-ink-400">
                          {sp.reorder} {sp.unit}
                        </td>
                        {canFinance && (
                          <td className="py-3 px-3 text-right">
                            <ActionButton
                              small
                              run={async () => demoAudit('supplies.adjust_stock', sp.name, '+10 units received', admin.name, admin.role)}
                            >
                              +Stock
                            </ActionButton>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <FootNote>
              Modifying unit costs recalculates gross profit margins for all subsequent dispenses in real time.
            </FootNote>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Recipe Kit Templates" sub="Component breakdown per cup recipe">
            <div className="space-y-4">
              {KIT_TEMPLATES.map((kt, i) => (
                <div key={i} className="p-3.5 bg-page rounded-xl border border-line space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{kt.emoji}</span>
                    <h4 className="font-bold text-[13px] text-ink-900">{kt.name}</h4>
                  </div>
                  <ul className="text-[11.5px] text-ink-600 space-y-1 divide-y divide-line/50">
                    {kt.components.map((c, ci) => (
                      <li key={ci} className="pt-1 flex justify-between">
                        <span>{c.item}</span>
                        <span className="font-mono text-ink-400">{c.qty}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
