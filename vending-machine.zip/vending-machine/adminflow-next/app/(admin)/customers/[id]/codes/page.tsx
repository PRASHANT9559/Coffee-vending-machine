import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, FootNote } from '@/components/ui/kit';
import { CUSTOMERS } from '@/lib/mock/customers';
import { IconArrowLeft } from '@/components/ui/icons';
import type { QrIssued } from '@/lib/mock/types';
import CustomerCodesClient from './customer-codes-client';

export default async function CustomerCodesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/customers/${id}/codes`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/customers/${id}/codes`} />;

  const c = CUSTOMERS.find(cust => cust.id === id);
  if (!c) {
    notFound();
    return null;
  }

  const codes: QrIssued[] = [
    { code: 'MC5142208-14', source: 'buy', issuedLabel: 'Today · 11:42 AM', expiryLabel: 'Expired · 10m window', shares: 0, state: 'redeemed', redeemedLabel: 'Today · 11:44 AM' },
    { code: 'MC3918274-02', source: 'gift', issuedLabel: 'Yesterday · 4:10 PM', expiryLabel: 'Valid', shares: 2, state: 'unredeemed', redeemedLabel: null },
    { code: 'MC9941029-88', source: 'ad', issuedLabel: 'Mon · 8:15 PM', expiryLabel: 'Redeemed', shares: 0, state: 'redeemed', redeemedLabel: 'Mon · 8:20 PM' },
    { code: 'MC1209441-33', source: 'referral', issuedLabel: '28 Oct', expiryLabel: 'Revoked', shares: 1, state: 'revoked', redeemedLabel: null },
  ];

  const admin = g.admin;
  const canSupport = roleCan(admin.role, 'support') || roleCan(admin.role, 'machines');

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href={`/customers/${c.id}`} className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to {c.name}&apos;s Profile
        </Link>
      </div>

      <PageHead
        module={`④ Customers · ${c.name}`}
        title="QR Code & Token History"
        sub="Cryptographic coffee authorization vouchers generated for purchases, rewarded ads, referral incentives, and peer-to-peer gifts."
      />

      <Card title="Issued QR Codes" sub="qr_codes and redemption lifecycle events">
        <CustomerCodesClient
          customerId={c.id}
          customerName={c.name}
          initialCodes={codes}
          canSupport={canSupport}
          adminName={admin.name}
          adminRole={admin.role}
        />
        <FootNote>
          Codes are signed via HMAC with rotating server secrets; once redeemed at any node camera, double-spend prevention is guaranteed by PostgreSQL unique constraints.
        </FootNote>
      </Card>
    </div>
  );
}
