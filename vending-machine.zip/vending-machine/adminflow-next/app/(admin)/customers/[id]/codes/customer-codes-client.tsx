'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import type { QrIssued } from '@/lib/mock/types';
import { emitToast } from '@/components/ui/toast';
import { reissueCustomerCode, demoAudit } from '@/lib/actions';
import { IconQr, IconPlus, IconCheck } from '@/components/ui/icons';
import { Tag } from '@/components/ui/kit';

interface CustomerCodesClientProps {
  customerId: string;
  customerName: string;
  initialCodes: QrIssued[];
  canSupport: boolean;
  adminName: string;
  adminRole: string;
}

export default function CustomerCodesClient({
  customerId,
  customerName,
  initialCodes,
  canSupport,
  adminName,
  adminRole,
}: CustomerCodesClientProps) {
  const router = useRouter();
  const [codes, setCodes] = useState<QrIssued[]>(initialCodes);
  const [isPending, startTransition] = useTransition();

  const handleReissue = (targetCode: string) => {
    startTransition(async () => {
      const res = await reissueCustomerCode(customerId, customerName, targetCode);
      if (res.ok) {
        emitToast(res.message, 'ok');
        if (res.newCode) {
          const freshVoucher: QrIssued = {
            code: res.newCode,
            source: 'gift',
            issuedLabel: 'Just now',
            expiryLabel: 'Valid · 10m window',
            shares: 0,
            state: 'unredeemed',
            redeemedLabel: null,
          };
          setCodes(prev => [freshVoucher, ...prev]);
        }
        router.refresh();
      } else {
        emitToast(res.message, 'warn');
      }
    });
  };

  const handleRevoke = (code: string) => {
    if (!window.confirm(`Revoke unredeemed code ${code}? The holder will no longer be able to dispense with it.`)) {
      return;
    }
    startTransition(async () => {
      const res = await demoAudit('qr.revoke', code, 'revoked unredeemed QR voucher', adminName, adminRole);
      if (res.ok) {
        emitToast(`Voucher ${code} revoked.`, 'ok');
        setCodes(prev => prev.map(c => c.code === code ? { ...c, state: 'revoked', expiryLabel: 'Revoked' } : c));
        router.refresh();
      }
    });
  };

  return (
    <div className="space-y-4">
      {/* ── Top Header Actions ───────────────────────────────── */}
      <div className="flex items-center justify-between border-b border-line pb-3">
        <div>
          <h4 className="text-[13px] font-bold text-ink-900">Cryptographic QR Tokens</h4>
          <p className="text-[11.5px] text-ink-500">
            HMAC-signed 10-minute dispensing vouchers tied to customer wallet &amp; loyalty entitlements
          </p>
        </div>

        {canSupport && (
          <button
            type="button"
            disabled={isPending}
            onClick={() => handleReissue('MC-NEW')}
            className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-brand-600 hover:bg-brand-500 text-white px-3 py-1.5 rounded-lg shadow-xs transition"
          >
            <IconPlus className="w-3.5 h-3.5" /> Issue New Voucher
          </button>
        )}
      </div>

      {/* ── Voucher Table ────────────────────────────────────── */}
      <div className="overflow-x-auto -mx-1 px-1">
        <table className="w-full text-[12.5px] border-collapse">
          <thead>
            <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
              <th className="py-2.5 px-3 text-left">QR Authorization Token</th>
              <th className="py-2.5 px-3 text-left">Origin / Source</th>
              <th className="py-2.5 px-3 text-left">Issued At</th>
              <th className="py-2.5 px-3 text-left">Shares</th>
              <th className="py-2.5 px-3 text-left">Status</th>
              <th className="py-2.5 px-3 text-left">Redemption Time</th>
              {canSupport && <th className="py-2.5 px-3 text-right">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-line/60">
            {codes.map((qr, i) => (
              <tr key={i} className="hover:bg-page/60">
                <td className="py-2.5 px-3 font-mono font-bold text-ink-900 flex items-center gap-1.5">
                  <IconQr className="w-4 h-4 text-brand-600 shrink-0" />
                  {qr.code}
                </td>
                <td className="py-2.5 px-3">
                  <Tag tone={qr.source === 'buy' ? 'leaf' : qr.source === 'gift' ? 'brand' : 'blue'}>
                    {qr.source.toUpperCase()}
                  </Tag>
                </td>
                <td className="py-2.5 px-3 text-ink-500 font-mono text-[11.5px]">{qr.issuedLabel}</td>
                <td className="py-2.5 px-3 text-ink-600">{qr.shares} times</td>
                <td className="py-2.5 px-3">
                  <Tag tone={qr.state === 'redeemed' ? 'leaf' : qr.state === 'unredeemed' ? 'amber' : 'ink'}>
                    {qr.state.toUpperCase()}
                  </Tag>
                </td>
                <td className="py-2.5 px-3 text-ink-500 font-mono text-[11.5px]">
                  {qr.redeemedLabel ?? (qr.state === 'unredeemed' ? 'Valid (Not Scanned)' : '—')}
                </td>
                {canSupport && (
                  <td className="py-2.5 px-3 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={isPending}
                        onClick={() => handleReissue(qr.code)}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-brand-600 hover:text-brand-700 bg-brand-50 hover:bg-brand-100 border border-brand-200/60 px-2 py-1 rounded transition"
                      >
                        Reissue Code
                      </button>

                      {qr.state === 'unredeemed' && (
                        <button
                          type="button"
                          disabled={isPending}
                          onClick={() => handleRevoke(qr.code)}
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 border border-red-200/60 px-2 py-1 rounded transition"
                        >
                          Revoke
                        </button>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
