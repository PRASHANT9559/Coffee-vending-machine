import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, rs } from '@/components/ui/kit';
import { CUSTOMERS } from '@/lib/mock/customers';
import { listWalletTxns } from '@/lib/mock/store';
import { ActionButton } from '@/components/ui/toast';
import { creditWallet, demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconWallet } from '@/components/ui/icons';
import type { LedgerTxn } from '@/lib/mock/types';

export default async function CustomerWalletPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/customers/${id}/wallet`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/customers/${id}/wallet`} />;

  const c = CUSTOMERS.find(cust => cust.id === id);
  if (!c) notFound();

  const seedTxns: LedgerTxn[] = [
    { id: 'tx-4', tsLabel: 'Today · 11:42 AM', kind: 'order', amount: -60, balanceAfter: c.wallet, note: 'Payment for order ORD-2250' },
    { id: 'tx-3', tsLabel: 'Today · 8:10 AM', kind: 'recharge', amount: 200, balanceAfter: c.wallet + 60, note: 'UPI Auto-Topup via PhonePe' },
    { id: 'tx-2', tsLabel: 'Yesterday · 4:44 PM', kind: 'refund', amount: 40, balanceAfter: c.wallet - 140, note: 'Refund credited for TKT-1040 (cup stuck)' },
    { id: 'tx-1', tsLabel: 'Mon · 9:15 AM', kind: 'order', amount: -40, balanceAfter: c.wallet - 180, note: 'Payment for order ORD-2176' },
  ];

  const txns = listWalletTxns(id, seedTxns);
  const admin = g.admin;
  const canFinance = roleCan(admin.role, 'wallet');

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href={`/customers/${c.id}`} className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to {c.name}&apos;s Profile
        </Link>
      </div>

      <PageHead
        module={`④ Customers · ${c.name}`}
        title="Wallet Transaction Ledger"
        sub="Double-entry wallet store credit ledger, running balances, UPI top-ups, and customer refund audit trail."
        actions={
          canFinance && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => creditWallet(c.id, c.name, 100, admin.name, admin.role)}
                tone="primary"
              >
                +₹100 Manual Credit
              </ActionButton>
              <ActionButton
                run={async () => demoAudit('wallet.manual_debit', `${c.name} · ₹50`, 'manual debit adjustment', admin.name, admin.role)}
                tone="danger"
                confirm="Post a manual debit adjustment of ₹50 to this user wallet?"
              >
                -₹50 Debit Adjust
              </ActionButton>
            </div>
          )
        }
      />

      <div className="grid sm:grid-cols-3 gap-4">
        <div className="card p-5 bg-brand-50 border-brand-200">
          <p className="text-[11px] font-semibold text-brand-600 uppercase tracking-wider">Current Wallet Balance</p>
          <p className="text-[28px] font-bold text-brand-900 mt-1">{rs(c.wallet)}</p>
          <p className="text-[11px] text-brand-700 mt-1">Available for instant dispensing</p>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Lifetime Recharges</p>
          <p className="text-[28px] font-bold text-ink-900 mt-1">{rs(c.spend + c.wallet)}</p>
          <p className="text-[11px] text-ink-500 mt-1">Total top-ups via UPI/Cards</p>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Total Disbursed Refunds</p>
          <p className="text-[28px] font-bold text-ink-900 mt-1">₹40</p>
          <p className="text-[11px] text-ink-500 mt-1">Dispute resolution credits</p>
        </div>
      </div>

      <Card title="Ledger Audit Table" sub="wallets + wallet_transactions with running balance integrity">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Transaction ID</th>
                <th className="py-2.5 px-3 text-left">Timestamp</th>
                <th className="py-2.5 px-3 text-left">Category</th>
                <th className="py-2.5 px-3 text-left">Description</th>
                <th className="py-2.5 px-3 text-right">Amount</th>
                <th className="py-2.5 px-3 text-right">Running Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {txns.map(tx => {
                const isCredit = tx.amount > 0;
                return (
                  <tr key={tx.id} className="hover:bg-page/60">
                    <td className="py-2.5 px-3 font-mono text-[11px] text-ink-500">{tx.id}</td>
                    <td className="py-2.5 px-3 text-ink-500 font-mono text-[11.5px]">{tx.tsLabel}</td>
                    <td className="py-2.5 px-3">
                      <Tag tone={isCredit ? 'leaf' : 'ink'}>{tx.kind.toUpperCase()}</Tag>
                    </td>
                    <td className="py-2.5 px-3 text-ink-700">{tx.note}</td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isCredit ? 'text-leaf-600' : 'text-ink-800'}`}>
                      {isCredit ? `+₹${tx.amount}` : `-₹${Math.abs(tx.amount)}`}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-ink-900">
                      {rs(tx.balanceAfter)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
