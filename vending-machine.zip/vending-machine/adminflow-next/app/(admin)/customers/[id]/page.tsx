import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote, rs } from '@/components/ui/kit';
import { getCustomerById, getOrdersForCustomer } from '@/lib/live';
import { ActionButton } from '@/components/ui/toast';
import { creditWallet, blockCustomer, demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconWallet, IconQr, IconGift, IconCoins, IconShield, IconCup, IconClock } from '@/components/ui/icons';
import SendPushModal from '@/components/customers/send-push-modal';

export default async function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/customers/${id}`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/customers/${id}`} />;

  const c = await getCustomerById(id);
  if (!c) {
    notFound();
    return null;
  }

  const customerOrders = await getOrdersForCustomer(id);
  const admin = g.admin;
  const canWallet = roleCan(admin.role, 'wallet');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/customers" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Customers
        </Link>
      </div>

      <PageHead
        module="④ Customers · 360° Profile"
        title={c.name}
        sub={`${c.phone} · Member since ${c.joinedLabel} · ${c.city} (${c.college})`}
        actions={
          <div className="flex flex-wrap gap-2 items-center">
            <Link
              href={`/customers/${c.id}/wallet`}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white border border-line hover:bg-page px-3 py-2 rounded-lg transition"
            >
              <IconWallet className="w-4 h-4 text-ink-600" /> Wallet Ledger
            </Link>
            <Link
              href={`/customers/${c.id}/codes`}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white border border-line hover:bg-page px-3 py-2 rounded-lg transition"
            >
              <IconQr className="w-4 h-4 text-ink-600" /> QR Code Vault
            </Link>
            <SendPushModal customerId={c.id} customerName={c.name} />
            {canWallet && (
              <ActionButton
                run={async () => creditWallet(c.id, c.name, 50, admin.name, admin.role)}
                tone="solid"
              >
                +₹50 Manual Credit
              </ActionButton>
            )}
            <ActionButton
              run={async () => blockCustomer(c.name, c.id, admin.name, admin.role)}
              tone="danger"
              confirm={`Block customer ${c.name} and flag account for suspicious activity?`}
            >
              Block Customer
            </ActionButton>
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left column: Identity, Wallets, Preferences, Gamification */}
        <div className="space-y-6">
          <Card title="Account Balances & Gamification" sub="Store credits and reward token balances">
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3.5 bg-brand-50 border border-brand-200 rounded-xl text-center">
                <p className="text-[11px] font-semibold text-brand-600 uppercase">Wallet Float</p>
                <p className="text-[22px] font-bold text-brand-900 mt-0.5">{rs(c.wallet)}</p>
              </div>
              <div className="p-3.5 bg-amber2-50 border border-amber2-200 rounded-xl text-center">
                <p className="text-[11px] font-semibold text-amber2-600 uppercase">Coffee Coins</p>
                <p className="text-[22px] font-bold text-amber2-900 mt-0.5">{c.coins}</p>
              </div>
            </div>

            <KV k="Repeat Order Rate" v={`${c.repeatRatePct}%`} />
            <KV k="Streak Level" v={<Tag tone="leaf">{c.streak.cur} Day Active (Best: {c.streak.longest}d)</Tag>} />
            <KV k="Leaderboard Rank" v={`#${c.leaderboard.rank} (${c.leaderboard.score} pts)`} />
            <KV k="Favourite Coffee" v={c.favourite} />
          </Card>

          {/* Variant Consumption & Repeat Rate Analytics Card */}
          <Card title="Drink Consumption & Preferences" sub="Cohort telemetry and purchase patterns">
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-[11.5px] font-semibold text-ink-800 mb-1">
                  <span>{c.favourite.split(' ')[0]} {c.favourite.split(' ')[1] || ''}</span>
                  <span className="text-brand-600">58% of orders</span>
                </div>
                <div className="w-full bg-page rounded-full h-2 overflow-hidden border border-line/60">
                  <div className="bg-brand-500 h-full rounded-full" style={{ width: '58%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11.5px] font-semibold text-ink-800 mb-1">
                  <span>Classic Café Latte</span>
                  <span className="text-ink-600">26% of orders</span>
                </div>
                <div className="w-full bg-page rounded-full h-2 overflow-hidden border border-line/60">
                  <div className="bg-blue-500 h-full rounded-full" style={{ width: '26%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11.5px] font-semibold text-ink-800 mb-1">
                  <span>Grande Roast / Frappe</span>
                  <span className="text-ink-600">16% of orders</span>
                </div>
                <div className="w-full bg-page rounded-full h-2 overflow-hidden border border-line/60">
                  <div className="bg-amber2-500 h-full rounded-full" style={{ width: '16%' }} />
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-line space-y-2">
              <KV k="Cohort Repeat Rate" v={`${c.repeatRatePct}% (Fleet Avg: 58%)`} />
              <KV k="Primary Demand Hours" v="09:00 AM – 11:30 AM" />
              <KV k="Secondary Demand Hours" v="04:15 PM – 05:45 PM" />
              <KV k="Preferred Node" v="MCH-001 · Campus Hub (82%)" />
            </div>
          </Card>

          <Card title="Privacy & Opt-In Consents" sub="DPDP / user consent registry">
            <KV k="Leaderboard Display" v={c.consents.leaderboard ? <Tag tone="leaf">OPTED IN</Tag> : <Tag tone="ink">MASKED</Tag>} />
            <KV k="Public Handle" v={c.consents.handle ? <Tag tone="leaf">VISIBLE</Tag> : <Tag tone="ink">ANONYMOUS</Tag>} />
            <KV k="Avatar Display" v={c.consents.avatar ? <Tag tone="leaf">ALLOWED</Tag> : <Tag tone="ink">DEFAULT</Tag>} />
            <KV k="Last Consent Audit" v={c.consents.updatedAt} />
            <div className="mt-3 pt-2 flex justify-end">
              <ActionButton
                small
                run={async () => demoAudit('customer.force_mask', c.name, 'force-masked from public leaderboard', admin.name, admin.role)}
              >
                Force Mask from Leaderboard
              </ActionButton>
            </div>
          </Card>

          <Card title="Earned Badges & Social" sub="P2P gift economy and referral tree">
            <div className="flex flex-wrap gap-1.5 mb-4">
              {c.badges.map((b, i) => (
                <span key={i} className="inline-flex items-center gap-1 px-2.5 py-1 bg-page border border-line rounded-lg text-[11.5px] font-semibold">
                  ☕ {b.name} {b.pinned && <Tag tone="brand">PINNED</Tag>}
                </span>
              ))}
            </div>

            <div className="border-t border-line pt-2">
              <KV k="Referrals Invited" v={`${c.referrals.invited} friends (${c.referrals.qualified} converted)`} />
              <KV k="Referral Rewards Paid" v={rs(c.referrals.paid)} />
              <KV k="P2P Coffee Gifts Sent" v={`${c.gifts.sent} cups`} />
              <KV k="P2P Coffee Gifts Received" v={`${c.gifts.received} cups`} />
            </div>
          </Card>
        </div>

        {/* Right column: Orders & Support Tickets */}
        <div className="lg:col-span-2 space-y-6">
          <Card title="Order History" sub="Recent orders placed by this customer">
            <div className="overflow-x-auto -mx-1 px-1">
              <table className="w-full text-[12.5px] border-collapse">
                <thead>
                  <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                    <th className="py-2.5 px-3 text-left">Order</th>
                    <th className="py-2.5 px-3 text-left">Time</th>
                    <th className="py-2.5 px-3 text-left">Machine</th>
                    <th className="py-2.5 px-3 text-left">Variant</th>
                    <th className="py-2.5 px-3 text-right">Amount</th>
                    <th className="py-2.5 px-3 text-left">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/60">
                  {customerOrders.map(o => (
                    <tr key={o.id} className="hover:bg-page/60">
                      <td className="py-2.5 px-3">
                        <Link href={`/orders/${o.id}`} className="font-mono text-brand-600 hover:underline font-semibold">
                          {o.num}
                        </Link>
                      </td>
                      <td className="py-2.5 px-3 text-ink-500 font-mono text-[11.5px]">{o.tsLabel}</td>
                      <td className="py-2.5 px-3 text-ink-700">{o.machine.split('·')[0]}</td>
                      <td className="py-2.5 px-3 font-medium">{o.variantShort}</td>
                      <td className="py-2.5 px-3 text-right font-semibold">{rs(o.finalAmount)}</td>
                      <td className="py-2.5 px-3">
                        <Tag tone={o.status === 'completed' ? 'leaf' : o.status === 'refunded' ? 'red' : 'amber'}>
                          {o.status.toUpperCase()}
                        </Tag>
                      </td>
                    </tr>
                  ))}
                  {customerOrders.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-ink-400">
                        No recent orders found in active window.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>

          <Card title="Support Desk Disputes & Complaints" sub="History of customer support interactions">
            <div className="space-y-3">
              {c.tickets.map(t => (
                <div key={t.id} className="p-3.5 bg-page rounded-xl border border-line flex items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <Link href={`/support/tickets/${t.id}`} className="font-mono font-bold text-brand-600 hover:underline">
                        {t.num}
                      </Link>
                      <span className="text-[12.5px] font-semibold text-ink-900">{t.subject}</span>
                    </div>
                    <p className="text-[11px] text-ink-400 mt-0.5">Filed {t.atLabel}</p>
                  </div>
                  <Tag tone={t.verdict.includes('resolved') ? 'leaf' : 'amber'}>
                    {t.verdict === '—' ? 'UNDER INVESTIGATION' : t.verdict.toUpperCase()}
                  </Tag>
                </div>
              ))}
              {c.tickets.length === 0 && (
                <p className="text-center py-6 text-ink-400 text-[12.5px]">Clean support record — no disputes filed.</p>
              )}
            </div>
            <FootNote>
              Customers with &gt;3 unverified no-coffee claims are flagged for dispute desk evidence scrutiny.
            </FootNote>
          </Card>
        </div>
      </div>
    </div>
  );
}
