import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView } from '@/components/ui/kit';
import { getCustomers } from '@/lib/live';
import DataTable, { type DataTableCol } from '@/components/ui/data-table';
import type { Cell } from '@/lib/mock/types';

export default async function CustomersPage() {
  const g = await requireCap('/customers');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/customers" />;

  const customers = await getCustomers();

  const columns: DataTableCol[] = [
    { key: 'name', label: 'Customer' },
    { key: 'phone', label: 'Phone' },
    { key: 'city', label: 'City' },
    { key: 'orders', label: 'Orders', align: 'right' },
    { key: 'spend', label: 'Total Spend (LTV)', align: 'right' },
    { key: 'wallet', label: 'Wallet', align: 'right' },
    { key: 'coins', label: 'Coins', align: 'right' },
    { key: 'streak', label: 'Streak' },
    { key: 'segment', label: 'Segment' },
  ];

  const rows: Record<string, Cell>[] = customers.map(c => ({
    id: c.id,
    name: { t: 'link', v: c.name, href: `/customers/${c.id}` },
    phone: c.phone,
    city: c.city,
    orders: c.orders,
    spend: { t: 'money', v: c.spend },
    wallet: { t: 'money', v: c.wallet },
    coins: c.coins,
    streak: `${c.streak.cur} days (max ${c.streak.longest})`,
    segment: {
      t: 'chip',
      v: c.segments[0] ?? 'Active',
      tone: c.segments.includes('High value') ? 'brand' : 'leaf',
    },
  }));

  const filters = [
    { key: 'city', label: 'City', options: ['Pune', 'Mumbai', 'Bangalore'] },
    { key: 'segment', label: 'Segment', options: ['Active today', 'High value', 'Lapsed 7d'] },
  ];

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="④ Customers"
        title="Customer Intelligence & Profiles"
        sub="Consumer accounts, wallet floats, gamification streaks, and lifetime value across the vending network."
        actions={
          <div className="flex items-center gap-2">
            <span className="text-[12px] bg-amber2-50 text-amber2-800 border border-amber2-200 px-3 py-1.5 rounded-lg">
              Honest Metric: ~24% of redemptions are anonymous P2P gifts/ads
            </span>
          </div>
        }
      />

      <div className="card p-5">
        <DataTable
          columns={columns}
          rows={rows}
          filters={filters}
          csvName="manhattan-coffee-customers"
          searchable
        />
      </div>
    </div>
  );
}
