import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView } from '@/components/ui/kit';
import { getOrders } from '@/lib/live';
import OrdersQueueClient from './orders-queue-client';

export default async function OrdersPage() {
  const g = await requireCap('/orders');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/orders" />;

  const orders = await getOrders();

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="③ Orders"
        title="Order Queue & Dispense Ledger"
        sub="Granular 6-axis filtered queue with saved views, dispute desk flags, and batch actions across the entire automated coffee fleet."
        actions={
          <div className="flex items-center gap-2">
            <span className="text-[12px] font-semibold text-ink-600 bg-page px-3 py-1.5 rounded-lg border border-line">
              Total Roster: {orders.length} orders
            </span>
          </div>
        }
      />

      <div className="card p-5">
        <OrdersQueueClient initialOrders={orders} />
      </div>
    </div>
  );
}
