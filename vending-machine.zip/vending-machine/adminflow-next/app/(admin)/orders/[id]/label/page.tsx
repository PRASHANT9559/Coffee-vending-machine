import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireCap } from '@/lib/auth';
import { ForbiddenView, rs } from '@/components/ui/kit';
import { getOrder } from '@/lib/mock/store';
import { IconArrowLeft, IconPrint, IconQr } from '@/components/ui/icons';

export default async function OrderLabelPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/orders/${id}/label`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/orders/${id}/label`} />;

  const o = getOrder(id);
  if (!o) notFound();

  return (
    <div className="p-5 lg:p-8 max-w-2xl mx-auto space-y-6">
      <div className="print:hidden flex items-center justify-between text-[12px]">
        <Link href={`/orders/${o.id}`} className="hover:text-brand-600 inline-flex items-center gap-1 text-ink-500">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Order Detail
        </Link>
        <button
          onClick={undefined}
          className="inline-flex items-center gap-1.5 bg-brand-500 hover:bg-brand-600 text-white font-semibold px-4 py-2 rounded-lg transition"
        >
          <IconPrint className="w-4 h-4" /> Print A5 Receipt Stub
        </button>
      </div>

      {/* A5 Printable Voucher / Slip */}
      <div className="card p-8 border-2 border-dashed border-ink-300 bg-white shadow-sm space-y-6 print:border-solid print:shadow-none">
        <div className="text-center pb-4 border-b border-line space-y-1">
          <p className="text-[11px] uppercase tracking-widest font-semibold text-brand-500">Manhattan Coffee Network</p>
          <h2 className="text-[20px] font-bold text-ink-900 tracking-tight">Offline Audit & Dispense Stub</h2>
          <p className="text-[12px] text-ink-500">Machine Point-of-Sale Voucher</p>
        </div>

        <div className="grid grid-cols-2 gap-4 text-[12.5px]">
          <div>
            <p className="text-ink-400 text-[11px] uppercase tracking-wider font-semibold">Order Reference</p>
            <p className="font-mono text-[16px] font-bold text-ink-900 mt-0.5">{o.num}</p>
          </div>
          <div className="text-right">
            <p className="text-ink-400 text-[11px] uppercase tracking-wider font-semibold">Dispense Time</p>
            <p className="font-mono text-[13px] text-ink-800 mt-0.5">{o.tsLabel}</p>
          </div>
          <div>
            <p className="text-ink-400 text-[11px] uppercase tracking-wider font-semibold">Vending Node</p>
            <p className="font-semibold text-ink-800 mt-0.5">{o.machine}</p>
          </div>
          <div className="text-right">
            <p className="text-ink-400 text-[11px] uppercase tracking-wider font-semibold">Tank Trace UID</p>
            <p className="font-mono text-[13px] text-ink-800 mt-0.5">{o.tankUid ?? 'TNK-A29F'}</p>
          </div>
        </div>

        <div className="p-4 bg-page rounded-xl border border-line space-y-2">
          <div className="flex justify-between text-[14px] font-bold text-ink-900">
            <span>{o.variant}</span>
            <span>{rs(o.finalAmount)}</span>
          </div>
          <div className="flex justify-between text-[11.5px] text-ink-500 pt-1 border-t border-line/60">
            <span>Payment Mode: {o.payment.toUpperCase()}</span>
            <span>Status: {o.status.toUpperCase()}</span>
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between border-t border-line text-[11px] text-ink-400 font-mono">
          <div className="flex items-center gap-2">
            <IconQr className="w-5 h-5 text-ink-600" />
            <span>TOKEN: {o.code.value}</span>
          </div>
          <span>FSSAI LIC: 11524036000192</span>
        </div>
      </div>
    </div>
  );
}
