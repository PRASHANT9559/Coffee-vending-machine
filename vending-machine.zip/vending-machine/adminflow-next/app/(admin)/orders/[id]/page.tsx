import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote, rs } from '@/components/ui/kit';
import { getOrderById } from '@/lib/live';
import { ActionButton } from '@/components/ui/toast';
import { orderRefund, orderFraud, reissueQr, openDispute } from '@/lib/actions';
import { IconArrowLeft, IconPrint, IconQr, IconFlag, IconShield, IconClock } from '@/components/ui/icons';

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/orders/${id}`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/orders/${id}`} />;

  const o = await getOrderById(id);
  if (!o) notFound();

  const admin = g.admin;
  const d = o.dispense;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/orders" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Orders
        </Link>
      </div>

      <PageHead
        module="③ Orders · Detail"
        title={`Order ${o.num}`}
        sub={`Placed ${o.tsLabel} at ${o.machine}. Dispense telemetry, FSSAI tank audit, and QR redemption tracking.`}
        actions={
          <div className="flex flex-wrap gap-2">
            <Link
              href={`/orders/${o.id}/label`}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white border border-line hover:bg-page px-3 py-2 rounded-lg transition"
            >
              <IconPrint className="w-4 h-4 text-ink-600" /> Print A5 Stub
            </Link>
            <ActionButton
              run={async () => openDispute(o.id, o.num, admin.name, admin.role)}
              tone="primary"
            >
              <IconFlag className="w-4 h-4" /> Open Dispute Ticket
            </ActionButton>
            <ActionButton
              run={async () => orderRefund(o.id, o.num, admin.name, admin.role)}
              confirm={`Queue ${o.num} for a refund of ₹${o.finalAmount}?`}
            >
              Request Refund
            </ActionButton>
            <ActionButton
              run={async () => orderFraud(o.id, o.num, admin.name, admin.role)}
              tone="danger"
              confirm={`Flag order ${o.num} as fraudulent?`}
            >
              Flag Fraud
            </ActionButton>
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left Column: Summary & Dispense Telemetry */}
        <div className="lg:col-span-2 space-y-6">
          <Card title="Order & Pricing Breakdown" sub="Receipt and margin structure">
            <div className="grid sm:grid-cols-2 gap-4 pt-1">
              <div>
                <KV k="Variant" v={o.variant} />
                <KV k="Base Price" v={rs(o.amount)} />
                <KV k="Discount Applied" v={o.discount > 0 ? `-${rs(o.discount)}` : 'None'} />
                <KV k="Final Paid" v={<span className="text-brand-600 font-bold">{rs(o.finalAmount)}</span>} />
              </div>
              <div>
                <KV k="Payment Instrument" v={<Tag tone="leaf">{o.payment.toUpperCase()}</Tag>} />
                <KV k="Gross Cost Basis" v={rs(o.costBasis)} />
                <KV k="Net Margin" v={`${Math.round(((o.finalAmount - o.costBasis) / Math.max(1, o.finalAmount)) * 100)}%`} />
                <KV k="Order Status" v={<Tag tone={o.status === 'completed' ? 'leaf' : o.status === 'refunded' ? 'red' : 'amber'}>{o.status.toUpperCase()}</Tag>} />
              </div>
            </div>
          </Card>

          <Card title="Dispense Sensor Log (Physical Verification)" sub="Flow meter pulses, valve timings, and infrared optical sensors">
            {d ? (
              <div className="space-y-4">
                <div className={`p-4 rounded-xl border ${d.variancePct > 15 ? 'bg-red-50/60 border-red-200' : 'bg-page border-line'}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">Volumetric Variance</p>
                      <p className={`text-[22px] font-bold ${d.variancePct > 15 ? 'text-red-600' : 'text-leaf-600'}`}>
                        {d.variancePct}% {d.variancePct > 15 ? '· UNEXPECTED DEFICIT' : '· NOMINAL'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[11px] text-ink-400">Actual vs Target</p>
                      <p className="text-[14px] font-mono font-semibold">{d.actualMl} ml / {d.expectedMl} ml</p>
                    </div>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-x-6 gap-y-1">
                  <KV k="Solenoid Valve Time" v={`${d.valveMs} ms`} mono />
                  <KV k="YF-S401 Flow Pulses" v={`${d.pulses} pulses`} mono />
                  <KV k="Malai Peristaltic Pump" v={`${d.malaiPumpMs} ms`} mono />
                  <KV k="Conveyor Stepper Cycles" v={`${d.conveyorSteps} steps`} mono />
                  <KV k="Cup Sensor (IR)" v={d.cupDetected ? <Tag tone="leaf">DETECTED</Tag> : <Tag tone="red">MISSING</Tag>} />
                  <KV k="Kit Drop Sensor" v={d.kitDropped ? <Tag tone="leaf">DROPPED</Tag> : <Tag tone="red">FAILED</Tag>} />
                  <KV k="Dispense Window Latch" v={d.windowOpened ? <Tag tone="leaf">OPENED</Tag> : <Tag tone="red">LOCKED</Tag>} />
                  <KV k="Customer Pickup Detected" v={d.pickupDetected ? <Tag tone="leaf">PICKED UP</Tag> : <Tag tone="amber">NOT PICKED</Tag>} />
                </div>
              </div>
            ) : (
              <p className="text-[12.5px] text-ink-400 py-6 text-center">
                Dispense log unavailable — order was cancelled or pending before physical sequence initiated.
              </p>
            )}
            <FootNote>
              Dispense metrics are logged by the ESP32 in flash and synced over MQTTS; variance over 15% immediately alerts support.
            </FootNote>
          </Card>

          <Card title="Tank Snapshot at Dispense (FSSAI Traceability)" sub="Dairy batch safety at the moment of pouring">
            <KV k="Mounted Tank UID" v={<span className="font-mono font-bold">{o.tankUid ?? 'TNK-A29F'}</span>} />
            <KV k="Tank Age at Dispense" v={`${o.tankAgeH ?? 5} Hours since fill`} />
            <KV k="Hold Window Status" v={<Tag tone={(o.tankAgeH ?? 5) < 12 ? 'leaf' : 'red'}>{(o.tankAgeH ?? 5) < 12 ? 'VALID (<12H)' : 'EXPIRED'}</Tag>} />
            <KV k="Milk Batch Source" v="Batch M-2261 · Gowardhan HTST Fresh Milk" />
          </Card>
        </div>

        {/* Right Column: QR Code, Customer & Timeline */}
        <div className="space-y-6">
          <Card title="Authorization Token (QR Code)" sub="Cryptographic redemption state">
            <div className="p-4 bg-page rounded-xl border border-line text-center space-y-2">
              <div className="mx-auto w-10 h-10 rounded-lg bg-brand-500/10 text-brand-600 flex items-center justify-center">
                <IconQr className="w-6 h-6" />
              </div>
              <p className="font-mono font-bold text-[14px] text-ink-900 tracking-wider">{o.code.value}</p>
              <div className="flex justify-center gap-2">
                <Tag tone={o.code.redeemed ? 'leaf' : 'amber'}>
                  {o.code.redeemed ? 'REDEEMED' : 'UNREDEEMED'}
                </Tag>
                <Tag tone="blue">SOURCE: {o.code.source.toUpperCase()}</Tag>
              </div>
            </div>

            <div className="pt-2">
              <KV k="Issued At" v={o.code.issuedLabel} />
              <KV k="Validity" v={o.code.expiryLabel} />
              <KV k="P2P Share Count" v={`${o.code.shared} times`} />
              <KV k="Redemption Time" v={o.code.redeemedLabel ?? 'Not yet scanned'} />
            </div>

            <div className="pt-3">
              <ActionButton
                run={async () => reissueQr(o.id, o.num, admin.name, admin.role)}
                tone="primary"
                confirm="Invalidate old code and reissue a fresh QR code to the customer?"
              >
                Reissue Fresh QR
              </ActionButton>
            </div>
          </Card>

          <Card title="Customer Association" sub="Account profile linking">
            {o.customerId ? (
              <div className="space-y-2">
                <KV
                  k="Customer"
                  v={<Link href={`/customers/${o.customerId}`} className="text-brand-600 hover:underline font-semibold">{o.customerName}</Link>}
                />
                <KV k="Account ID" v={<span className="font-mono text-[11px]">{o.customerId}</span>} />
                <KV k="Attribution" v={<Tag tone="leaf">AUTHENTICATED USER</Tag>} />
              </div>
            ) : (
              <div className="p-3 bg-page rounded-xl border border-line text-[12px] text-ink-600">
                <p className="font-semibold text-ink-800">Anonymous P2P Gift / Ad Reward</p>
                <p className="text-[11px] text-ink-500 mt-1">
                  Redeemed without a logged-in user session. The panel displays honest anonymous attribution.
                </p>
              </div>
            )}
          </Card>

          <Card title="Order Event Timeline" sub="Chronological event stream">
            <ol className="relative pl-4 space-y-3 before:absolute before:left-[5px] before:top-2 before:bottom-2 before:w-px before:bg-line text-[12px]">
              <li className="relative">
                <span className="absolute -left-4 top-1 w-2.5 h-2.5 rounded-full bg-leaf-500 border-2 border-white" />
                <p className="font-bold text-ink-800">Order Placed & Payment Captured</p>
                <p className="text-[10.5px] text-ink-400 font-mono">{o.tsLabel}</p>
              </li>
              <li className="relative">
                <span className="absolute -left-4 top-1 w-2.5 h-2.5 rounded-full bg-leaf-500 border-2 border-white" />
                <p className="font-bold text-ink-800">QR Code Minted & Delivered</p>
                <p className="text-[10.5px] text-ink-400 font-mono">HMAC signed with secret v7</p>
              </li>
              {o.code.redeemed && (
                <li className="relative">
                  <span className="absolute -left-4 top-1 w-2.5 h-2.5 rounded-full bg-brand-500 border-2 border-white" />
                  <p className="font-bold text-ink-800">Camera Scanned at Dispenser</p>
                  <p className="text-[10.5px] text-ink-400 font-mono">{o.code.redeemedLabel}</p>
                </li>
              )}
            </ol>
          </Card>
        </div>
      </div>
    </div>
  );
}
