'use client';

import { useMemo, useState, useTransition } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import type { Order } from '@/lib/mock/types';
import { inr } from '@/lib/format';
import { emitToast } from '@/components/ui/toast';
import { batchReviewOrders } from '@/lib/actions';
import {
  IconSearch, IconDownload, IconFlag, IconCheck, IconFilter,
  IconClock, IconArrowRight,
} from '@/components/ui/icons';

interface OrdersQueueClientProps {
  initialOrders: Order[];
}

type SavedView = 'all' | 'flagged' | 'refunded' | 'preparing';

export default function OrdersQueueClient({ initialOrders }: OrdersQueueClientProps) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<SavedView>('all');
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [paymentFilter, setPaymentFilter] = useState('all');
  const [machineFilter, setMachineFilter] = useState('all');
  const [variantFilter, setVariantFilter] = useState('all');
  const [disputeFilter, setDisputeFilter] = useState('all');
  const [windowFilter, setWindowFilter] = useState('all');

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isPending, startTransition] = useTransition();

  // Tab switch handler
  const handleTabChange = (tab: SavedView) => {
    setActiveTab(tab);
    if (tab === 'flagged') {
      setDisputeFilter('flagged');
      setStatusFilter('all');
    } else if (tab === 'refunded') {
      setStatusFilter('refunded');
      setDisputeFilter('all');
    } else if (tab === 'preparing') {
      setStatusFilter('preparing');
      setDisputeFilter('all');
    } else {
      setStatusFilter('all');
      setDisputeFilter('all');
    }
  };

  // Reset all filters
  const resetFilters = () => {
    setActiveTab('all');
    setQ('');
    setStatusFilter('all');
    setPaymentFilter('all');
    setMachineFilter('all');
    setVariantFilter('all');
    setDisputeFilter('all');
    setWindowFilter('all');
    setSelectedIds([]);
  };

  // 6 Filters + Search Query Filtering
  const filteredOrders = useMemo(() => {
    return initialOrders.filter(o => {
      // 1. Search Query
      if (q) {
        const query = q.toLowerCase();
        const matchesQuery =
          o.num.toLowerCase().includes(query) ||
          (o.customerName && o.customerName.toLowerCase().includes(query)) ||
          o.variant.toLowerCase().includes(query) ||
          o.variantShort.toLowerCase().includes(query) ||
          o.machine.toLowerCase().includes(query);
        if (!matchesQuery) return false;
      }

      // 2. Status Filter
      if (statusFilter !== 'all') {
        if (o.status !== statusFilter) return false;
      }

      // 3. Payment Filter
      if (paymentFilter !== 'all') {
        if (o.payment !== paymentFilter) return false;
      }

      // 4. Machine Filter
      if (machineFilter !== 'all') {
        if (o.machineId !== machineFilter) return false;
      }

      // 5. Variant Filter
      if (variantFilter !== 'all') {
        if (!o.variantShort.toLowerCase().includes(variantFilter.toLowerCase())) return false;
      }

      // 6. Dispute Filter
      if (disputeFilter === 'flagged' && !o.flagged) return false;
      if (disputeFilter === 'unflagged' && o.flagged) return false;

      // 7. Time Window Filter
      if (windowFilter === 'today') {
        if (!o.tsLabel.startsWith('Today')) return false;
      } else if (windowFilter === 'yesterday') {
        if (!o.tsLabel.startsWith('Yesterday')) return false;
      } else if (windowFilter === '7d') {
        if (!o.tsLabel.startsWith('Today') && !o.tsLabel.startsWith('Yesterday') && !o.tsLabel.startsWith('Mon')) return false;
      }

      return true;
    });
  }, [initialOrders, q, statusFilter, paymentFilter, machineFilter, variantFilter, disputeFilter, windowFilter]);

  // Tab count badges
  const counts = useMemo(() => {
    return {
      all: initialOrders.length,
      flagged: initialOrders.filter(o => o.flagged).length,
      refunded: initialOrders.filter(o => o.status === 'refunded').length,
      preparing: initialOrders.filter(o => o.status === 'preparing' || o.status === 'pending').length,
    };
  }, [initialOrders]);

  // Bulk Selection Logic
  const allFilteredSelected = filteredOrders.length > 0 && filteredOrders.every(o => selectedIds.includes(o.id));
  const someFilteredSelected = filteredOrders.some(o => selectedIds.includes(o.id)) && !allFilteredSelected;

  const toggleSelectAll = () => {
    if (allFilteredSelected) {
      setSelectedIds(prev => prev.filter(id => !filteredOrders.some(fo => fo.id === id)));
    } else {
      const visibleIds = filteredOrders.map(o => o.id);
      setSelectedIds(prev => Array.from(new Set([...prev, ...visibleIds])));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  // CSV Export for filtered or selected
  const exportCsv = (onlySelected = false) => {
    const list = onlySelected
      ? initialOrders.filter(o => selectedIds.includes(o.id))
      : filteredOrders;

    if (list.length === 0) return;

    const headers = ['Order ID', 'Timestamp', 'Machine', 'Customer', 'Variant', 'Amount (INR)', 'Payment', 'Status', 'Flagged'];
    const rows = list.map(o => [
      o.num,
      o.tsLabel,
      `"${o.machine.replace(/"/g, '""')}"`,
      `"${(o.customerName || 'Anonymous').replace(/"/g, '""')}"`,
      `"${o.variantShort.replace(/"/g, '""')}"`,
      o.finalAmount,
      o.payment.toUpperCase(),
      o.status.toUpperCase(),
      o.flagged ? 'YES' : 'NO',
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `manhattan-orders-${onlySelected ? 'selected' : 'export'}-${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    emitToast(`Exported ${list.length} orders to CSV`, 'ok');
  };

  // Batch action executions
  const handleBatchAction = (action: 'examine' | 'flag_dispute') => {
    if (selectedIds.length === 0) return;
    startTransition(async () => {
      const res = await batchReviewOrders(selectedIds, action);
      if (res.ok) {
        emitToast(res.message, 'ok');
        setSelectedIds([]);
        router.refresh();
      } else {
        emitToast(res.message, 'warn');
      }
    });
  };

  return (
    <div className="space-y-4">
      {/* ── Saved Views Tabs ─────────────────────────────────── */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => handleTabChange('all')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition ${
              activeTab === 'all'
                ? 'bg-ink-900 text-white shadow-sm'
                : 'bg-page text-ink-600 hover:text-ink-900 hover:bg-page/80'
            }`}
          >
            All Orders
            <span className={`text-[10.5px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === 'all' ? 'bg-white/20 text-white' : 'bg-line text-ink-500'
            }`}>
              {counts.all}
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('flagged')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition ${
              activeTab === 'flagged'
                ? 'bg-brand-600 text-white shadow-sm'
                : 'bg-page text-ink-600 hover:text-ink-900 hover:bg-page/80'
            }`}
          >
            <IconFlag className="w-3.5 h-3.5 text-amber2-400" />
            Dispute Flags
            <span className={`text-[10.5px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === 'flagged' ? 'bg-white/20 text-white' : 'bg-brand-100 text-brand-700'
            }`}>
              {counts.flagged}
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('refunded')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition ${
              activeTab === 'refunded'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-page text-ink-600 hover:text-ink-900 hover:bg-page/80'
            }`}
          >
            Refund Requests
            <span className={`text-[10.5px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === 'refunded' ? 'bg-white/20 text-white' : 'bg-line text-ink-500'
            }`}>
              {counts.refunded}
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('preparing')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition ${
              activeTab === 'preparing'
                ? 'bg-leaf-600 text-white shadow-sm'
                : 'bg-page text-ink-600 hover:text-ink-900 hover:bg-page/80'
            }`}
          >
            Active Dispensing
            <span className={`text-[10.5px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === 'preparing' ? 'bg-white/20 text-white' : 'bg-line text-ink-500'
            }`}>
              {counts.preparing}
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => exportCsv(false)}
            className="inline-flex items-center gap-1.5 text-[12px] font-semibold border border-line bg-white hover:bg-page rounded-lg px-3 py-1.5 transition text-ink-700 shadow-xs"
          >
            <IconDownload className="w-3.5 h-3.5 text-ink-500" /> Export CSV ({filteredOrders.length})
          </button>
          {(statusFilter !== 'all' || paymentFilter !== 'all' || machineFilter !== 'all' || variantFilter !== 'all' || disputeFilter !== 'all' || windowFilter !== 'all' || q) && (
            <button
              type="button"
              onClick={resetFilters}
              className="text-[11.5px] font-semibold text-brand-600 hover:underline px-2 py-1"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* ── 6 Filter Controls + Real-Time Search ─────────────── */}
      <div className="bg-page/70 border border-line rounded-xl p-3 space-y-3">
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search bar */}
          <div className="relative flex-1 min-w-[220px]">
            <IconSearch className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
            <input
              type="text"
              value={q}
              onChange={e => setQ(e.target.value)}
              placeholder="Search by order ID, customer name, drink variant, or machine..."
              className="w-full pl-9 pr-3 py-2 text-[12.5px] bg-white border border-line rounded-lg outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-200 transition"
            />
          </div>

          {/* Filter 1: Status */}
          <div className="flex items-center gap-1 bg-white border border-line rounded-lg px-2 py-1">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-ink-400 px-1">Status:</span>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="text-[12px] font-medium bg-transparent outline-none cursor-pointer text-ink-800"
            >
              <option value="all">All</option>
              <option value="completed">Completed</option>
              <option value="preparing">Preparing</option>
              <option value="pending">Pending</option>
              <option value="refunded">Refunded</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          {/* Filter 2: Payment Method */}
          <div className="flex items-center gap-1 bg-white border border-line rounded-lg px-2 py-1">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-ink-400 px-1">Payment:</span>
            <select
              value={paymentFilter}
              onChange={e => setPaymentFilter(e.target.value)}
              className="text-[12px] font-medium bg-transparent outline-none cursor-pointer text-ink-800"
            >
              <option value="all">All</option>
              <option value="upi">UPI Auto-pay</option>
              <option value="wallet">Wallet Float</option>
              <option value="coins">Coffee Coins</option>
            </select>
          </div>

          {/* Filter 3: Machine */}
          <div className="flex items-center gap-1 bg-white border border-line rounded-lg px-2 py-1">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-ink-400 px-1">Machine:</span>
            <select
              value={machineFilter}
              onChange={e => setMachineFilter(e.target.value)}
              className="text-[12px] font-medium bg-transparent outline-none cursor-pointer text-ink-800"
            >
              <option value="all">All Fleets</option>
              <option value="a1b2c3d4-0001-4000-8000-000000000001">MCH-001 · Campus Hub</option>
              <option value="a1b2c3d4-0002-4000-8000-000000000002">MCH-002 · Mall Lane</option>
            </select>
          </div>

          {/* Filter 4: Variant */}
          <div className="flex items-center gap-1 bg-white border border-line rounded-lg px-2 py-1">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-ink-400 px-1">Variant:</span>
            <select
              value={variantFilter}
              onChange={e => setVariantFilter(e.target.value)}
              className="text-[12px] font-medium bg-transparent outline-none cursor-pointer text-ink-800"
            >
              <option value="all">All Drinks</option>
              <option value="Manhattan Velvet">Manhattan Velvet</option>
              <option value="Classic Latte">Classic Latte</option>
              <option value="Grande Roast">Grande Roast</option>
              <option value="Chilled Frappe">Chilled Frappe</option>
            </select>
          </div>

          {/* Filter 5: Dispute Flag */}
          <div className="flex items-center gap-1 bg-white border border-line rounded-lg px-2 py-1">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-ink-400 px-1">Dispute:</span>
            <select
              value={disputeFilter}
              onChange={e => setDisputeFilter(e.target.value)}
              className="text-[12px] font-medium bg-transparent outline-none cursor-pointer text-ink-800"
            >
              <option value="all">All</option>
              <option value="flagged">Flagged Disputes Only</option>
              <option value="unflagged">Unflagged Only</option>
            </select>
          </div>

          {/* Filter 6: Time Window */}
          <div className="flex items-center gap-1 bg-white border border-line rounded-lg px-2 py-1">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-ink-400 px-1">Window:</span>
            <select
              value={windowFilter}
              onChange={e => setWindowFilter(e.target.value)}
              className="text-[12px] font-medium bg-transparent outline-none cursor-pointer text-ink-800"
            >
              <option value="all">All Time</option>
              <option value="today">Today Only</option>
              <option value="yesterday">Yesterday</option>
              <option value="7d">Last 7 Days</option>
            </select>
          </div>
        </div>
      </div>

      {/* ── Bulk Actions Floating / Sticky Toolbar ─────────────── */}
      {selectedIds.length > 0 && (
        <div className="bg-ink-900 text-white rounded-xl px-4 py-3 shadow-lg flex flex-wrap items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center justify-center bg-brand-500 text-white font-bold text-[12px] px-2.5 py-0.5 rounded-full">
              {selectedIds.length}
            </span>
            <span className="text-[13px] font-medium text-ink-100">
              {selectedIds.length === 1 ? '1 order selected' : `${selectedIds.length} orders selected`}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => exportCsv(true)}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg transition"
            >
              <IconDownload className="w-3.5 h-3.5" /> Export Selected CSV
            </button>

            <button
              type="button"
              disabled={isPending}
              onClick={() => handleBatchAction('examine')}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg transition"
            >
              <IconCheck className="w-3.5 h-3.5 text-leaf-400" /> Batch Mark Examined
            </button>

            <button
              type="button"
              disabled={isPending}
              onClick={() => handleBatchAction('flag_dispute')}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold bg-brand-600 hover:bg-brand-500 text-white px-3 py-1.5 rounded-lg transition"
            >
              <IconFlag className="w-3.5 h-3.5" /> Flag for Dispute Desk
            </button>

            <button
              type="button"
              onClick={() => setSelectedIds([])}
              className="text-[12px] text-ink-300 hover:text-white hover:underline px-2 py-1 ml-2"
            >
              Deselect All
            </button>
          </div>
        </div>
      )}

      {/* ── Orders Table ─────────────────────────────────────── */}
      <div className="overflow-x-auto -mx-1 px-1">
        <table className="w-full border-collapse text-[12.5px]">
          <thead>
            <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
              <th className="py-2.5 px-3 w-8 text-center">
                <input
                  type="checkbox"
                  checked={allFilteredSelected}
                  ref={el => { if (el) el.indeterminate = someFilteredSelected; }}
                  onChange={toggleSelectAll}
                  className="rounded border-line text-brand-600 focus:ring-brand-500 cursor-pointer"
                />
              </th>
              <th className="py-2.5 px-3 text-left">Order No</th>
              <th className="py-2.5 px-3 text-left">Time</th>
              <th className="py-2.5 px-3 text-left">Machine</th>
              <th className="py-2.5 px-3 text-left">Customer</th>
              <th className="py-2.5 px-3 text-left">Variant</th>
              <th className="py-2.5 px-3 text-right">Amount</th>
              <th className="py-2.5 px-3 text-center">Payment</th>
              <th className="py-2.5 px-3 text-center">Status</th>
              <th className="py-2.5 px-3 text-center">Dispute</th>
              <th className="py-2.5 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#F4F5F7]">
            {filteredOrders.map(o => {
              const isSelected = selectedIds.includes(o.id);
              return (
                <tr
                  key={o.id}
                  className={`transition-colors ${isSelected ? 'bg-brand-50/40 hover:bg-brand-50/60' : 'hover:bg-[#F9FAFB]'}`}
                >
                  <td className="py-3 px-3 text-center">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelectOne(o.id)}
                      className="rounded border-line text-brand-600 focus:ring-brand-500 cursor-pointer"
                    />
                  </td>
                  <td className="py-3 px-3">
                    <Link
                      href={`/orders/${o.id}`}
                      className="font-mono font-bold text-[12px] text-brand-600 hover:underline"
                    >
                      {o.num}
                    </Link>
                  </td>
                  <td className="py-3 px-3 font-mono text-[11.5px] text-ink-500 whitespace-nowrap">
                    {o.tsLabel}
                  </td>
                  <td className="py-3 px-3 text-ink-800 font-medium whitespace-nowrap">
                    {o.machine.split('·')[0].trim()}
                  </td>
                  <td className="py-3 px-3 text-ink-700 whitespace-nowrap">
                    {o.customerId ? (
                      <Link href={`/customers/${o.customerId}`} className="hover:text-brand-600 hover:underline">
                        {o.customerName || 'Customer'}
                      </Link>
                    ) : (
                      <span className="text-ink-400">Anonymous</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-ink-900 font-medium whitespace-nowrap">
                    {o.variantShort}
                  </td>
                  <td className="py-3 px-3 text-right font-semibold text-ink-900 whitespace-nowrap">
                    ₹{inr(o.finalAmount)}
                  </td>
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                      o.payment === 'upi' ? 'bg-leaf-50 text-leaf-600' :
                      o.payment === 'wallet' ? 'bg-blue-50 text-blue-600' :
                      'bg-amber2-50 text-amber2-600'
                    }`}>
                      {o.payment.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                      o.status === 'completed' ? 'bg-leaf-50 text-leaf-600' :
                      o.status === 'preparing' ? 'bg-amber2-50 text-amber2-600' :
                      o.status === 'refunded' ? 'bg-red-50 text-red-600' :
                      'bg-ink-100 text-ink-600'
                    }`}>
                      {o.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    {o.flagged ? (
                      <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-md">
                        <IconFlag className="w-3 h-3 text-brand-600" /> FLAGGED
                      </span>
                    ) : (
                      <span className="text-ink-300">—</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-right whitespace-nowrap">
                    <Link
                      href={`/orders/${o.id}`}
                      className="inline-flex items-center gap-1 text-[11.5px] font-semibold text-ink-600 hover:text-brand-600 bg-page hover:bg-brand-50 px-2.5 py-1 rounded-lg border border-line transition"
                    >
                      Audit →
                    </Link>
                  </td>
                </tr>
              );
            })}
            {filteredOrders.length === 0 && (
              <tr>
                <td colSpan={11} className="py-12 text-center text-ink-400">
                  <p className="text-[13.5px] font-medium text-ink-600">No orders match your filter criteria.</p>
                  <button
                    type="button"
                    onClick={resetFilters}
                    className="mt-2 text-[12px] font-semibold text-brand-600 hover:underline"
                  >
                    Clear all filters
                  </button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
