import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, FootNote } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { GENERAL_CONFIG } from '@/lib/mock/settings';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';

export default async function SettingsGeneralPage() {
  const g = await requireCap('/settings/general');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/general" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · General"
        title="Brand Identity & Global Configuration"
        sub="Company business name, support hotline, supported metropolitan cities, currency formats, and brand marks."
      />

      <SettingsNav />

      <div className="max-w-2xl space-y-6">
        <Card title="Brand Identity" sub="Displayed across kiosks, stubs, and consumer app">
          <div className="space-y-4 mt-2">
            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">Business Name</label>
              <input
                type="text"
                defaultValue={GENERAL_CONFIG.business}
                disabled={!isOwner}
                className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[13px]"
              />
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">Operational Metropolitan Cities</label>
              <input
                type="text"
                defaultValue={GENERAL_CONFIG.cities}
                disabled={!isOwner}
                className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[13px]"
              />
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">Customer Support Hotline</label>
              <input
                type="text"
                defaultValue={GENERAL_CONFIG.supportNumber}
                disabled={!isOwner}
                className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[13px] font-mono"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Network Timezone</label>
                <input
                  type="text"
                  defaultValue={GENERAL_CONFIG.timezone}
                  disabled
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12px] text-ink-500 font-mono"
                />
              </div>
              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Currency Code</label>
                <input
                  type="text"
                  defaultValue={GENERAL_CONFIG.currency}
                  disabled
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12px] text-ink-500 font-mono"
                />
              </div>
            </div>

            {isOwner && (
              <div className="pt-2 flex justify-end">
                <ActionButton
                  run={async () => demoAudit('settings.save_general', 'General Config', 'saved brand general identity', admin.name, admin.role)}
                  tone="primary"
                >
                  Save Brand Settings
                </ActionButton>
              </div>
            )}
          </div>
          <FootNote>
            Settings mutations are cryptographically signed and logged with before/after state diffs to audit_logs.
          </FootNote>
        </Card>
      </div>
    </div>
  );
}
