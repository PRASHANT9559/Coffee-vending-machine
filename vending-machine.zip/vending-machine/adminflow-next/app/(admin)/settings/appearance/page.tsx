import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, FootNote } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { APPEARANCE } from '@/lib/mock/settings';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';

export default async function SettingsAppearancePage() {
  const g = await requireCap('/settings/appearance');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/appearance" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Appearance"
        title="Theme & Visual Palette Customization"
        sub="Brand primary, leaf success, and amber warning accent palettes, kiosk display mode, and table data density."
      />

      <SettingsNav />

      <div className="max-w-2xl space-y-6">
        <Card title="Brand Color Palettes" sub="Custom tailwind token hex codes">
          <div className="space-y-4 mt-2">
            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                Brand Primary Accent (Brand 500)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  defaultValue={APPEARANCE.primary}
                  disabled={!isOwner}
                  className="w-10 h-10 rounded border border-line cursor-pointer"
                />
                <input
                  type="text"
                  defaultValue={APPEARANCE.primary}
                  disabled={!isOwner}
                  className="w-36 bg-page border border-line rounded-lg px-3 py-2 text-[12.5px] font-mono font-semibold"
                />
              </div>
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                Success Status Green (Leaf 500)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  defaultValue={APPEARANCE.success}
                  disabled={!isOwner}
                  className="w-10 h-10 rounded border border-line cursor-pointer"
                />
                <input
                  type="text"
                  defaultValue={APPEARANCE.success}
                  disabled={!isOwner}
                  className="w-36 bg-page border border-line rounded-lg px-3 py-2 text-[12.5px] font-mono font-semibold"
                />
              </div>
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                Attention Warning Amber (Amber2 500)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  defaultValue={APPEARANCE.warning}
                  disabled={!isOwner}
                  className="w-10 h-10 rounded border border-line cursor-pointer"
                />
                <input
                  type="text"
                  defaultValue={APPEARANCE.warning}
                  disabled={!isOwner}
                  className="w-36 bg-page border border-line rounded-lg px-3 py-2 text-[12.5px] font-mono font-semibold"
                />
              </div>
            </div>

            <div className="pt-2">
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">Console UI Density</label>
              <div className="flex gap-3 text-[12px]">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="density" defaultChecked disabled={!isOwner} />
                  <span>Comfortable (Default)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="density" disabled={!isOwner} />
                  <span>Compact (High-Density Tables)</span>
                </label>
              </div>
            </div>

            {isOwner && (
              <div className="pt-3 flex justify-end">
                <ActionButton
                  run={async () => demoAudit('settings.save_theme', 'Theme', 'saved custom brand accent palettes', admin.name, admin.role)}
                  tone="primary"
                >
                  Save Theme Palettes
                </ActionButton>
              </div>
            )}
          </div>
          <FootNote>
            Colors cascade into CSS variables defined in globals.css and apply immediately across the admin shell.
          </FootNote>
        </Card>
      </div>
    </div>
  );
}
