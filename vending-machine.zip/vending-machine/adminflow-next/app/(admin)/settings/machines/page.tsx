import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, FootNote } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { FLEET_DEFAULTS } from '@/lib/mock/settings';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';

export default async function SettingsFleetDefaultsPage() {
  const g = await requireCap('/settings/machines');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/machines" />;

  const admin = g.admin;
  const canOps = roleCan(admin.role, 'machines');

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Fleet Defaults"
        title="Fleet-Wide Machine Operating Standards"
        sub="Default boiler and chiller temperature targets, FSSAI dairy hold ceilings, reorder thresholds, and the new-machine commissioning checklist."
      />

      <SettingsNav />

      <div className="max-w-2xl space-y-6">
        <Card title="Thermal & Dairy Standards" sub="Inherited by newly provisioned kiosks">
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                  Default Hot Boiler Target (°C)
                </label>
                <input
                  type="number"
                  defaultValue={FLEET_DEFAULTS.targetTempHot}
                  disabled={!canOps}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[13px] font-mono"
                />
              </div>
              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                  Default Cold Chiller Target (°C)
                </label>
                <input
                  type="number"
                  defaultValue={FLEET_DEFAULTS.targetTempCold}
                  disabled={!canOps}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[13px] font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                FSSAI Dairy Maximum Hold Time (Hours)
              </label>
              <input
                type="number"
                defaultValue={FLEET_DEFAULTS.tankHoldHours}
                disabled={!canOps}
                className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[13px] font-mono"
              />
              <p className="text-[11px] text-ink-400 mt-1">
                Hard ceiling: machines lock automatic dispensing when hold time reaches this limit.
              </p>
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                Standard Reorder Warning Triggers
              </label>
              <input
                type="text"
                defaultValue={FLEET_DEFAULTS.reorder}
                disabled={!canOps}
                className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12.5px] font-mono"
              />
            </div>
          </div>
        </Card>

        <Card title="New Node Commissioning Checklist" sub="Mandatory technician sign-off procedure before first dispense">
          <div className="p-3.5 bg-page rounded-xl border border-line text-[12px] text-ink-700 font-mono space-y-1">
            <p>1. {FLEET_DEFAULTS.checklist.split('→')[0]?.trim()}</p>
            <p>2. {FLEET_DEFAULTS.checklist.split('→')[1]?.trim()}</p>
            <p>3. {FLEET_DEFAULTS.checklist.split('→')[2]?.trim()}</p>
            <p>4. {FLEET_DEFAULTS.checklist.split('→')[3]?.trim()}</p>
          </div>

          {canOps && (
            <div className="pt-4 flex justify-end">
              <ActionButton
                run={async () => demoAudit('settings.save_fleet_defaults', 'Fleet Defaults', 'saved fleet thermal & hold defaults', admin.name, admin.role)}
                tone="primary"
              >
                Save Fleet Defaults
              </ActionButton>
            </div>
          )}
          <FootNote>
            Updating fleet defaults applies to newly onboarded machines; existing units preserve their local overrides unless manually reset.
          </FootNote>
        </Card>
      </div>
    </div>
  );
}
