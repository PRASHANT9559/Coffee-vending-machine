import Link from 'next/link';
import { requireCap, roleCan, DEMO_ADMINS, ROLES, ROLE_META } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, RoleTag, FootNote } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit, resetAdminMfa } from '@/lib/actions';
import { IconUsers, IconShield } from '@/components/ui/icons';
import RbacMatrix from '@/components/settings/rbac-matrix';

export default async function SettingsTeamPage() {
  const g = await requireCap('/settings/team');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/team" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Team & Roles"
        title="Admin User Roster & RBAC Permission Matrix"
        sub="Granular 6-role × 13-capability access control matrix with strict server-side capability guards and cryptographic two-factor enforcement."
        actions={
          <div className="flex items-center gap-2">
            <span className="text-[12px] font-semibold text-ink-600 bg-page px-3 py-1.5 rounded-lg border border-line">
              Active Admins: {DEMO_ADMINS.length} Accounts
            </span>
          </div>
        }
      />

      <SettingsNav />

      {/* ── 6-Role × 13-Capability Permission Matrix Grid ───────── */}
      <Card
        title="Fleet RBAC Permission Matrix Grid"
        sub="Interactive 6-role × 13-capability authorization matrix. Capabilities are evaluated server-side on every API mutation and page transition."
      >
        <RbacMatrix isOwner={isOwner} />
      </Card>

      {/* ── Console Administrator Roster ──────────────────────── */}
      <Card
        title="Console Administrator Roster"
        sub="admin_users enrolled with SMS OTP and TOTP authenticator MFA bindings"
      >
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Staff Name</th>
                <th className="py-2.5 px-3 text-left">Phone Number</th>
                <th className="py-2.5 px-3 text-left">Assigned Role</th>
                <th className="py-2.5 px-3 text-left">Access Scope</th>
                {isOwner && <th className="py-2.5 px-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {DEMO_ADMINS.map(staff => (
                <tr key={staff.uid} className="hover:bg-page/60">
                  <td className="py-3 px-3 font-semibold text-ink-900">{staff.name}</td>
                  <td className="py-3 px-3 font-mono text-[11.5px] text-ink-500">{staff.phone}</td>
                  <td className="py-3 px-3">
                    <RoleTag role={staff.role} />
                  </td>
                  <td className="py-3 px-3 text-[11.5px] text-ink-500">{ROLE_META[staff.role].blurb}</td>
                  {isOwner && (
                    <td className="py-3 px-3 text-right">
                      {staff.role !== 'owner' && (
                        <div className="inline-flex gap-1.5">
                          <ActionButton
                            small
                            run={async () => resetAdminMfa(staff.uid, staff.name)}
                            confirm={`Reset 2FA secret for ${staff.name}? They will be forced to re-enroll MFA on next login.`}
                          >
                            Reset MFA
                          </ActionButton>
                          <ActionButton
                            small
                            tone="danger"
                            run={async () => demoAudit('team.suspend', staff.name, 'suspended admin console privileges', admin.name, admin.role)}
                            confirm={`Suspend console privileges for ${staff.name}?`}
                          >
                            Suspend
                          </ActionButton>
                        </div>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <FootNote>
          Guards deny, they do not hide. If a staff member attempts navigating to a forbidden route, a cryptographic 403 denial event is immediately written to PostgreSQL audit logs.
        </FootNote>
      </Card>
    </div>
  );
}
