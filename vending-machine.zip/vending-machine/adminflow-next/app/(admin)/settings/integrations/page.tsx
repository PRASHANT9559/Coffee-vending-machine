import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { INTEGRATIONS } from '@/lib/mock/settings';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconRefresh } from '@/components/ui/icons';

export default async function SettingsIntegrationsPage() {
  const g = await requireCap('/settings/integrations');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/integrations" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Integrations"
        title="Microservices & External Cloud Connectors"
        sub="Health checks, TLS connection handshakes, and connectivity diagnostics for Supabase Postgres, Rust Axum Core, WhatsApp, and Ad Networks."
      />

      <SettingsNav />

      <Card title="Active Network Services" sub="Real-time ping latency and TLS handshake status">
        <div className="divide-y divide-line">
          {INTEGRATIONS.map(it => (
            <div key={it.id} className="py-4 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-[14px] text-ink-900">{it.name}</h4>
                  <Tag tone={it.state === 'connected' ? 'leaf' : 'amber'}>
                    {it.state.toUpperCase()}
                  </Tag>
                </div>
                <p className="text-[12px] text-ink-500 mt-0.5">{it.desc}</p>
                <p className="text-[10.5px] font-mono text-ink-400 mt-1">Last health verification: {it.lastCheck}</p>
              </div>

              {isOwner && (
                <div className="flex gap-2">
                  <ActionButton
                    small
                    run={async () => demoAudit('integrations.test', it.name, 'manual health check ping verified 200 OK', admin.name, admin.role)}
                  >
                    <IconRefresh className="w-3.5 h-3.5" /> Re-test Connection
                  </ActionButton>
                </div>
              )}
            </div>
          ))}
        </div>
        <FootNote>
          The admin console connects through the Supabase edge gateway; the Rust microservice holds the unbypassable database service-role key.
        </FootNote>
      </Card>
    </div>
  );
}
