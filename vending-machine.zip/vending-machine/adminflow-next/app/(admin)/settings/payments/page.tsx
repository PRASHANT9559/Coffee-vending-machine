import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { WEBHOOK_EVENTS } from '@/lib/mock/settings';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';

export default async function SettingsPaymentsPage() {
  const g = await requireCap('/settings/payments');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/payments" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Payments"
        title="Payment Gateways & Webhooks"
        sub="Razorpay and PhonePe production credentials, webhook endpoint signing secrets, delivery logs, and webhook replay diagnostics."
      />

      <SettingsNav />

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card title="UPI Payment Gateway Credentials" sub="Integrated Razorpay / PhonePe live keys">
            <div className="space-y-4 mt-2">
              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Razorpay Key ID</label>
                <input
                  type="text"
                  defaultValue="rzp_live_9a2f7c01824b"
                  disabled={!isOwner}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12.5px] font-mono"
                />
              </div>

              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Razorpay Secret Key</label>
                <input
                  type="password"
                  defaultValue="••••••••••••••••••••••••••••••"
                  disabled={!isOwner}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12.5px] font-mono"
                />
              </div>

              <div className="pt-2 border-t border-line">
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Public Inbound Webhook URL</label>
                <input
                  type="text"
                  readOnly
                  defaultValue="https://api.manhattancoffee.in/webhooks/razorpay"
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12px] font-mono text-ink-600"
                />
              </div>

              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Webhook HMAC Signing Secret</label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    defaultValue="whsec_0a91fbc829471de99"
                    disabled={!isOwner}
                    className="flex-1 bg-page border border-line rounded-lg px-3 py-2 text-[12px] font-mono"
                  />
                  {isOwner && (
                    <ActionButton
                      small
                      run={async () => demoAudit('payments.rotate_secret', 'Webhook Secret', 'webhook HMAC secret rotated', admin.name, admin.role)}
                      confirm="Rotate inbound webhook secret? (Safe operation — invalidates no past orders)."
                    >
                      Rotate
                    </ActionButton>
                  )}
                </div>
              </div>

              {isOwner && (
                <div className="pt-2 flex justify-between items-center">
                  <ActionButton
                    small
                    run={async () => demoAudit('payments.test_ping', 'Razorpay Gateway', 'test ping successfully acknowledged 200 OK', admin.name, admin.role)}
                  >
                    Send Gateway Test Ping
                  </ActionButton>
                  <ActionButton
                    run={async () => demoAudit('payments.save_keys', 'Gateways', 'saved production payment gateway keys', admin.name, admin.role)}
                    tone="primary"
                  >
                    Save API Keys
                  </ActionButton>
                </div>
              )}
            </div>
            <FootNote>
              Rotating webhook secrets invalidates nothing in the field; the Rust service handles overlapping signing windows gracefully.
            </FootNote>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Recent Inbound Webhook Events" sub="Last 10 gateway payment notifications">
            <div className="space-y-3">
              {WEBHOOK_EVENTS.map((ev, i) => (
                <div key={i} className="p-3 bg-page rounded-xl border border-line flex items-center justify-between text-[12px]">
                  <div>
                    <span className="font-semibold text-ink-800">{ev.event}</span>
                    <p className="text-[11px] font-mono text-ink-400 mt-0.5">{ev.tsLabel}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] text-ink-500">{ev.code}</span>
                    <Tag tone={ev.status === 'ok' ? 'leaf' : 'red'}>{ev.status.toUpperCase()}</Tag>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
