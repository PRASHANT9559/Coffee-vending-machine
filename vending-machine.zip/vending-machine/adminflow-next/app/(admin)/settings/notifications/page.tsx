import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { ALERT_RULES, CRITICAL_ALERTS } from '@/lib/mock/settings';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconBell, IconPlus } from '@/components/ui/icons';

export default async function SettingsNotificationsPage() {
  const g = await requireCap('/settings/notifications');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/notifications" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Notifications"
        title="Automated Alert Rules & Escalation Policies"
        sub="Dispatch real-time emergency notifications across WhatsApp, SMS, and in-app bell indicators when hardware faults or stock deficits occur."
        actions={
          isOwner && (
            <ActionButton
              run={async () => demoAudit('alerts.create_rule', 'Alert Rule', 'created new escalation rule', admin.name, admin.role)}
              tone="primary"
            >
              <IconPlus className="w-4 h-4" /> Create Alert Rule
            </ActionButton>
          )
        }
      />

      <SettingsNav />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Configured Alert Trigger Rules" sub="Active condition monitors and notification delivery channels">
            <div className="space-y-4">
              {ALERT_RULES.map(ar => (
                <div key={ar.id} className="p-4 bg-page rounded-xl border border-line space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <IconBell className="w-4 h-4 text-brand-500" />
                      <h4 className="font-bold text-[13.5px] text-ink-900">{ar.trigger}</h4>
                    </div>
                    <Tag tone={ar.active ? 'leaf' : 'ink'}>
                      {ar.active ? 'ACTIVE' : 'MUTED'}
                    </Tag>
                  </div>

                  <p className="text-[12px] text-ink-600">Threshold: <strong className="text-ink-800">{ar.threshold}</strong></p>

                  <div className="flex items-center justify-between text-[11.5px] text-ink-500 pt-2 border-t border-line/60">
                    <span>Channel: <Tag tone="brand">{ar.channel.toUpperCase()}</Tag></span>
                    <span>Recipient: <strong>{ar.recipient}</strong></span>
                    {isOwner && (
                      <ActionButton
                        small
                        run={async () => demoAudit('alert.toggle', ar.trigger, `toggled status to ${!ar.active}`, admin.name, admin.role)}
                      >
                        {ar.active ? 'Mute Rule' : 'Enable'}
                      </ActionButton>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Critical Fleet Triggers" sub="Default system health alarms">
            <div className="space-y-3">
              {CRITICAL_ALERTS.map((ca, i) => (
                <div key={i} className="p-3 bg-page rounded-lg border border-line text-[12px]">
                  <p className="font-bold text-ink-800">{ca.title}</p>
                  <p className="text-[11px] text-ink-500 mt-0.5">{ca.body}</p>
                </div>
              ))}
            </div>
            <FootNote>
              Critical P1 fault codes automatically ping on-call technician phones via WhatsApp Business API within 60 seconds.
            </FootNote>
          </Card>
        </div>
      </div>
    </div>
  );
}
