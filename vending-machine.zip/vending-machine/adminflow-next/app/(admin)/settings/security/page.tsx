import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, KV } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { SECURITY_SESSIONS, QR_SECRET_INFO } from '@/lib/mock/settings';
import { listAudit } from '@/lib/mock/store';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit, toggleMaintenance } from '@/lib/actions';
import { IconShield, IconKey, IconDownload } from '@/components/ui/icons';

export default async function SettingsSecurityPage() {
  const g = await requireCap('/settings/security');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/security" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');
  const auditLogs = listAudit();

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Security"
        title="Security, HMAC Secrets & Audit Trail"
        sub="Cryptographic HMAC QR signing secret rotation, active session management, maintenance mode toggling, and the complete immutable before/after audit trail."
        actions={
          isOwner && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => toggleMaintenance()}
                tone="danger"
                confirm="Toggle network maintenance mode overlay? This sets the entire operator panel into read-only mode."
              >
                Toggle Maintenance Mode
              </ActionButton>
              <ActionButton
                run={async () => demoAudit('audit.export', 'Audit Log', 'exported cryptographic audit logs JSON', admin.name, admin.role)}
              >
                <IconDownload className="w-4 h-4" /> Export Audit Log
              </ActionButton>
            </div>
          )
        }
      />

      <SettingsNav />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* QR Signing Secret Rotation Warning Block */}
          <Card title="Cryptographic QR Signing Secret" sub="HMAC-SHA256 master authorization key">
            <div className="p-4 bg-amber2-50 border border-amber2-200 rounded-xl space-y-3">
              <div className="flex items-start gap-3">
                <IconKey className="w-5 h-5 text-amber2-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-[13.5px] text-amber2-900">
                    Active Secret Version: v{QR_SECRET_INFO.version} (Last rotated: {QR_SECRET_INFO.lastRotated})
                  </h4>
                  <p className="text-[12px] text-amber2-800 mt-1 leading-relaxed">
                    ⚠️ <strong>High Impact Operation:</strong> {QR_SECRET_INFO.impactLabel}.
                    New codes will immediately be signed with the next revision, and vending machine ESP32 firmware requires an updated key schedule.
                  </p>
                </div>
              </div>

              {isOwner && (
                <div className="pt-2 flex justify-end">
                  <ActionButton
                    small
                    tone="danger"
                    run={async () => demoAudit('security.rotate_qr_secret', `HMAC v${QR_SECRET_INFO.version + 1}`, 'rotated master QR authorization secret', admin.name, admin.role)}
                    confirm="DANGER: Rotate QR master secret? Every unredeemed voucher currently held by customers will be invalidated unless reissued!"
                  >
                    Initiate Secret Rotation Flow
                  </ActionButton>
                </div>
              )}
            </div>
          </Card>

          {/* Immutable Audit Log */}
          <Card title="Immutable Audit Trail" sub="Full before/after state diffs (audit_logs table)">
            <div className="overflow-x-auto -mx-1 px-1">
              <table className="w-full text-[12px] border-collapse">
                <thead>
                  <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                    <th className="py-2.5 px-3 text-left">Timestamp</th>
                    <th className="py-2.5 px-3 text-left">Administrator</th>
                    <th className="py-2.5 px-3 text-left">Action</th>
                    <th className="py-2.5 px-3 text-left">Target</th>
                    <th className="py-2.5 px-3 text-left">Audit Detail</th>
                    <th className="py-2.5 px-3 text-center">Type</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/60 font-mono text-[11.5px]">
                  {auditLogs.slice(0, 15).map(a => (
                    <tr key={a.id} className="hover:bg-page/60">
                      <td className="py-2.5 px-3 text-ink-500 whitespace-nowrap">{a.at}</td>
                      <td className="py-2.5 px-3 font-sans font-semibold text-ink-800">{a.who}</td>
                      <td className="py-2.5 px-3 text-brand-600 font-bold">{a.action}</td>
                      <td className="py-2.5 px-3 text-ink-700">{a.target ?? '—'}</td>
                      <td className="py-2.5 px-3 text-ink-600 font-sans max-w-[280px] truncate">{a.detail ?? '—'}</td>
                      <td className="py-2.5 px-3 text-center font-sans">
                        <Tag tone={a.kind === 'denied' ? 'red' : 'leaf'}>
                          {a.kind.toUpperCase()}
                        </Tag>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <FootNote>
              Security log captures all mutations and 403 access attempts. Records cannot be deleted or pruned via the console UI.
            </FootNote>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Active Operator Sessions" sub="Currently authenticated browser and app tokens">
            <div className="space-y-3">
              {SECURITY_SESSIONS.map((ses, i) => (
                <div key={i} className="p-3 bg-page rounded-xl border border-line text-[12px] space-y-1">
                  <div className="flex items-center justify-between font-semibold">
                    <span>{ses.device}</span>
                    {ses.current && <Tag tone="leaf">THIS DEVICE</Tag>}
                  </div>
                  <p className="text-[11px] font-mono text-ink-400">IP: {ses.ip} · Started: {ses.started}</p>
                  <p className="text-[11px] text-ink-500">2FA Verified: {ses.mfa ? 'TOTP Authenticator' : 'Password Only'}</p>
                  {isOwner && !ses.current && (
                    <div className="pt-2 flex justify-end">
                      <ActionButton
                        small
                        tone="danger"
                        run={async () => demoAudit('security.revoke_session', ses.device, 'revoked active JWT operator session', admin.name, admin.role)}
                      >
                        Revoke Session
                      </ActionButton>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
