import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import SettingsNav from '@/components/settings/settings-nav';
import { PLAN, USAGE, INVOICES } from '@/lib/mock/settings';
import { Meter } from '@/components/ui/charts';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconDownload } from '@/components/ui/icons';

export default async function SettingsBillingPage() {
  const g = await requireCap('/settings/billing');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/settings/billing" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'settings');

  return (
    <div className="p-5 lg:p-8 max-w-[1200px] w-full mx-auto space-y-6">
      <PageHead
        module="⑨ Settings · Billing"
        title="Subscription Plan & Network Utilization"
        sub="Software plan tier, machine slot quotas, cloud telemetry retention windows, and tax invoices."
      />

      <SettingsNav />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Current Subscription Plan" sub="Billed monthly via autopay">
            <div className="p-4 bg-brand-50 border border-brand-200 rounded-xl flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-[18px] font-bold text-brand-900">{PLAN.name} Tier</h3>
                  <Tag tone="brand">ACTIVE</Tag>
                </div>
                <p className="text-[12px] text-brand-700 mt-1">
                  Renews automatically on <strong className="font-semibold">{PLAN.renews}</strong>
                </p>
              </div>
              <div className="text-right">
                <span className="text-[24px] font-bold text-brand-900">{rs(PLAN.price)}</span>
                <span className="text-[11px] text-brand-600 block">/ {PLAN.period}</span>
              </div>
            </div>

            <div className="space-y-3 mt-4">
              <h4 className="font-bold text-[13px] text-ink-900">Network Resource Quotas:</h4>
              {USAGE.map(u => {
                const pct = Math.min(100, Math.round((u.used / u.cap) * 100));
                return (
                  <div key={u.name} className="space-y-1 text-[12px]">
                    <div className="flex justify-between font-semibold">
                      <span className="text-ink-800">{u.name}</span>
                      <span className="font-mono text-ink-500">
                        {u.used} of {u.cap} {u.unit} ({pct}%)
                      </span>
                    </div>
                    <Meter pct={pct} color={pct > 80 ? '#EAB308' : '#F04E23'} h={5} />
                  </div>
                );
              })}
            </div>

            {isOwner && (
              <div className="pt-4 flex justify-end">
                <ActionButton
                  run={async () => demoAudit('billing.upgrade', 'Enterprise Tier', 'initiated enterprise plan upgrade inquiry', admin.name, admin.role)}
                  tone="primary"
                >
                  Upgrade Network Capacity
                </ActionButton>
              </div>
            )}
          </Card>

          <Card title="Tax Invoices & Receipts" sub="subscription_invoices ledger">
            <div className="space-y-2">
              {INVOICES.map(inv => (
                <div key={inv.id} className="p-3 bg-page rounded-xl border border-line flex items-center justify-between text-[12px]">
                  <div>
                    <span className="font-mono font-bold text-ink-900">{inv.id}</span>
                    <span className="text-ink-400 ml-2">Issued {inv.dateLabel}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-ink-900">{rs(inv.amount)}</span>
                    <Tag tone={inv.state === 'paid' ? 'leaf' : 'amber'}>{inv.state.toUpperCase()}</Tag>
                    {isOwner && (
                      <ActionButton
                        small
                        run={async () => demoAudit('billing.download_invoice', inv.id, 'downloaded PDF tax invoice', admin.name, admin.role)}
                      >
                        <IconDownload className="w-3.5 h-3.5" /> PDF
                      </ActionButton>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Payment Method" sub="Configured billing card">
            <div className="p-3.5 bg-page rounded-xl border border-line text-[12.5px] space-y-1.5">
              <p className="font-bold text-ink-900">HDFC Corporate Credit Card</p>
              <p className="font-mono text-[11px] text-ink-500">•••• •••• •••• 4092</p>
              <p className="text-[11px] text-ink-400">Expires 09/2028 · Autopay verified</p>
            </div>
            <FootNote>
              Invoices include 18% GST and are generated automatically on the 20th of each calendar month.
            </FootNote>
          </Card>
        </div>
      </div>
    </div>
  );
}
