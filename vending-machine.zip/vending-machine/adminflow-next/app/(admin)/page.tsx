import { getDashboardData } from '@/lib/dashboard';
import DashboardView from '@/components/dashboard/dashboard-view';
import { getAdmin } from '@/lib/auth';

// live data — never prerender at build time (build machine has no Supabase env)
export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const admin = await getAdmin();

  let data: Awaited<ReturnType<typeof getDashboardData>> | null = null;
  let error: string | null = null;
  try {
    data = await getDashboardData();
  } catch (err) {
    error = err instanceof Error ? err.message : 'Dashboard data could not be loaded.';
  }

  if (!data) {
    return (
      <div className="p-5 lg:p-8 max-w-[900px] w-full mx-auto">
        <div className="card p-6 border border-amber2-200 bg-amber2-50">
          <p className="text-[11px] font-bold uppercase tracking-wider text-amber2-800">
            Data source unavailable
          </p>
          <h1 className="text-[18px] font-bold text-ink-900 mt-1">
            Rust backend is not reachable
          </h1>
          <p className="text-[12.5px] text-ink-600 mt-2 leading-relaxed">
            {error ?? 'No dashboard payload was returned.'}
          </p>
          <p className="text-[11.5px] text-ink-500 mt-3">
            Start the service with <code className="font-mono">cargo run</code> in
            <code className="font-mono"> adminflow-next/backend</code> and confirm
            <code className="font-mono"> RUST_BACKEND_URL</code> points at it. Demo data is only
            served when <code className="font-mono">DEMO_MODE=1</code> in a non-production build.
          </p>
        </div>
      </div>
    );
  }

  return <DashboardView data={data} who={admin?.name ?? 'Admin'} />;
}
