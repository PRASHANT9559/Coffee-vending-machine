import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { listRefunds } from '@/lib/mock/store';
import { ActionButton } from '@/components/ui/toast';
import { refundPayout } from '@/lib/actions';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function SupportRefundsPage() {
  const g = await requireCap('/support/refunds');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/support/refunds" />;

  const refunds = listRefunds();
  const admin = g.admin;
  const canFinance = roleCan(admin.role, 'refunds');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/support" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to SLA Board
        </Link>
      </div>

      <PageHead
        module="⑧ Support · Refunds"
        title="Refund Authorization & Payout Queue"
        sub="Financial disbursement queue. Support agents request refunds during dispute investigation, but only Finance or Owner can authorize releasing funds."
      />

      <Card title="Refund Authorization Ledger" sub="refunds + payment_transactions">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Order No</th>
                <th className="py-2.5 px-3 text-left">Customer</th>
                <th className="py-2.5 px-3 text-right">Refund Amount</th>
                <th className="py-2.5 px-3 text-left">Destination</th>
                <th className="py-2.5 px-3 text-left">Requested By</th>
                <th className="py-2.5 px-3 text-left">Reason / Note</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                {canFinance && <th className="py-2.5 px-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {refunds.map(r => (
                <tr key={r.id} className="hover:bg-page/60">
                  <td className="py-3 px-3 font-mono font-bold text-brand-600">
                    <Link href={`/orders/${r.orderId}`} className="hover:underline">
                      {r.orderNum}
                    </Link>
                  </td>
                  <td className="py-3 px-3 font-semibold text-ink-800">{r.customer}</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-ink-900">{rs(r.amount)}</td>
                  <td className="py-3 px-3">
                    <Tag tone={r.destination === 'wallet' ? 'leaf' : 'blue'}>
                      {r.destination.toUpperCase()}
                    </Tag>
                  </td>
                  <td className="py-3 px-3 text-ink-500 text-[11.5px]">{r.requestedBy}</td>
                  <td className="py-3 px-3 text-ink-600 max-w-[260px] truncate">{r.reason}</td>
                  <td className="py-3 px-3 text-center">
                    <Tag tone={r.state === 'paid' ? 'leaf' : r.state === 'pending' ? 'amber' : 'red'}>
                      {r.state.toUpperCase()}
                    </Tag>
                  </td>
                  {canFinance && (
                    <td className="py-3 px-3 text-right">
                      {r.state === 'pending' && (
                        <div className="inline-flex gap-1.5">
                          <ActionButton
                            small
                            tone="primary"
                            run={async () => refundPayout(r.id, 'paid', admin.name, admin.role)}
                            confirm={`Release payout of ₹${r.amount} to ${r.customer}?`}
                          >
                            Approve Payout
                          </ActionButton>
                          <ActionButton
                            small
                            tone="danger"
                            run={async () => refundPayout(r.id, 'rejected', admin.name, admin.role)}
                            confirm={`Reject refund payout for ${r.orderNum}?`}
                          >
                            Reject
                          </ActionButton>
                        </div>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <FootNote>
          Separation of duties: Support agents request refunds on the dispute desk; finance authorizes actual payout disbursements to prevent internal fraud.
        </FootNote>
      </Card>
    </div>
  );
}
