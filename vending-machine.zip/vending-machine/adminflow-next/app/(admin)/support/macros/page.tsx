import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { MACROS } from '@/lib/mock/support';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconPlus } from '@/components/ui/icons';

export default async function SupportMacrosPage() {
  const g = await requireCap('/support/macros');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/support/macros" />;

  const admin = g.admin;
  const canSupport = roleCan(admin.role, 'support');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/support" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to SLA Board
        </Link>
      </div>

      <PageHead
        module="⑧ Support · Macros"
        title="Automated WhatsApp & Bot Canned Macros"
        sub="Multilingual automated reply templates with dynamic server variable interpolation for instant ticket dispute handling."
        actions={
          canSupport && (
            <ActionButton
              run={async () => demoAudit('macro.create', 'New Macro', 'created new macro response template', admin.name, admin.role)}
              tone="primary"
            >
              <IconPlus className="w-4 h-4" /> Create New Macro
            </ActionButton>
          )
        }
      />

      <div className="grid md:grid-cols-2 gap-6">
        {MACROS.map(m => (
          <Card key={m.id} title={`Category: ${m.type}`} sub={`Language: ${m.lang} · Updated ${m.updatedLabel}`}>
            <div className="mb-2">
              <Tag tone={m.active ? 'leaf' : 'ink'}>
                {m.active ? 'ACTIVE' : 'RETIRED'}
              </Tag>
            </div>

            <p className="p-3 bg-page rounded-xl border border-line text-[12.5px] text-ink-800 leading-relaxed my-3 font-mono">
              &ldquo;{m.body}&rdquo;
            </p>

            <div className="text-[11px] text-ink-500">
              Interpolated Placeholders: <code className="bg-white px-1.5 py-0.5 rounded border border-line text-brand-600">{m.placeholders}</code>
            </div>

            {canSupport && (
              <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-line">
                <ActionButton
                  small
                  run={async () => demoAudit('macro.toggle', m.id, `toggled macro ${m.id}`, admin.name, admin.role)}
                >
                  {m.active ? 'Retire' : 'Activate'}
                </ActionButton>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
