import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { getTickets } from '@/lib/live';
import { ActionButton } from '@/components/ui/toast';
import { claimNext } from '@/lib/actions';
import { IconSupport, IconClock, IconShield } from '@/components/ui/icons';

export default async function SupportSlaBoardPage() {
  const g = await requireCap('/support');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/support" />;

  const tickets = await getTickets();
  const openTickets = tickets.filter(t => t.state === 'open' || t.state === 'investigating');
  const unassigned = openTickets.find(t => !t.assignedTo);
  const oldest = openTickets[0];
  const admin = g.admin;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑧ Support · SLA Board"
        title="Dispute Desk & Support SLA Cockpit"
        sub="5-minute resolution response countdown, automated evidence bundles, multi-channel intake (WhatsApp, Bot, Kiosk), and fraud dispute queue."
        actions={
          unassigned && (
            <ActionButton
              run={async () => claimNext(unassigned.id, admin.name)}
              tone="primary"
            >
              Claim Next Priority ({unassigned.num})
            </ActionButton>
          )
        }
      />

      {/* SLA Status Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5 bg-brand-50/60 border-brand-200">
          <p className="text-[11px] font-semibold text-brand-600 uppercase tracking-wider">Active Open Claims</p>
          <p className="text-[28px] font-bold text-brand-900 mt-1">{openTickets.length} tickets</p>
          <span className="text-[11px] text-brand-700">Needs agent resolution</span>
        </div>

        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">5-Minute SLA Breach Window</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
            <p className="text-[28px] font-bold text-red-600 font-mono">03:42</p>
          </div>
          <span className="text-[11px] text-ink-500 font-medium">Nearest deadline: {oldest?.num ?? 'None'}</span>
        </div>

        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Channel Intake Mix</p>
          <p className="text-[22px] font-bold text-ink-900 mt-1">68% Bot · 24% WA</p>
          <span className="text-[11px] text-ink-400">8% Front desk manual</span>
        </div>

        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Today&apos;s Resolution Verdicts</p>
          <p className="text-[22px] font-bold text-leaf-600 mt-1">1 Refund · 1 Rejected</p>
          <span className="text-[11px] text-leaf-700">Zero false refund release</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card title="Immediate Priority Dispute Queue" sub="Highest urgency customer claims">
            <div className="divide-y divide-line">
              {openTickets.map(t => (
                <div key={t.id} className="py-3.5 flex items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <Link href={`/support/tickets/${t.id}`} className="font-mono font-bold text-brand-600 hover:underline">
                        {t.num}
                      </Link>
                      <span className="font-bold text-[13px] text-ink-900">{t.customer}</span>
                      <Tag tone={t.priority === 'P1' ? 'red' : 'amber'}>{t.priority}</Tag>
                      <Tag tone="ink">{t.typeLabel}</Tag>
                    </div>
                    <p className="text-[12px] text-ink-600 mt-1 line-clamp-1">{t.message}</p>
                    <p className="text-[10.5px] text-ink-400 mt-1 font-mono">
                      {t.openedLabel} · at {t.machine} · Ref: {t.upiRef}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-mono font-bold text-[15px] text-ink-900 block">{rs(t.amount)}</span>
                    <Link
                      href={`/support/tickets/${t.id}`}
                      className="mt-1 inline-block text-[11.5px] font-semibold text-brand-600 hover:underline"
                    >
                      Open Dispute Desk →
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Support Desk Navigation" sub="Dedicated queues and desks">
            <div className="space-y-2.5">
              <Link href="/support/tickets" className="block p-3 rounded-lg border border-line bg-page hover:bg-white transition">
                <p className="font-bold text-[13px] text-ink-900">Support Ticket Queue →</p>
                <p className="text-[11.5px] text-ink-500 mt-0.5">Full filterable queue of complaints</p>
              </Link>
              <Link href="/support/refunds" className="block p-3 rounded-lg border border-line bg-page hover:bg-white transition">
                <p className="font-bold text-[13px] text-ink-900">Refund Payout Queue (Finance) →</p>
                <p className="text-[11.5px] text-ink-500 mt-0.5">Authorised gateway & wallet disbursements</p>
              </Link>
              <Link href="/support/reviews" className="block p-3 rounded-lg border border-line bg-page hover:bg-white transition">
                <p className="font-bold text-[13px] text-ink-900">Customer Ratings & Feedback →</p>
                <p className="text-[11.5px] text-ink-500 mt-0.5">Star ratings and blend reviews</p>
              </Link>
              <Link href="/support/blacklist" className="block p-3 rounded-lg border border-line bg-page hover:bg-white transition">
                <p className="font-bold text-[13px] text-ink-900">Fraud Blacklist (Owner Only) →</p>
                <p className="text-[11.5px] text-ink-500 mt-0.5">Blocked phone numbers, IMEI & UTRs</p>
              </Link>
              <Link href="/support/macros" className="block p-3 rounded-lg border border-line bg-page hover:bg-white transition">
                <p className="font-bold text-[13px] text-ink-900">Canned Macro Bot Replies →</p>
                <p className="text-[11.5px] text-ink-500 mt-0.5">Standard multilingual automated answers</p>
              </Link>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
