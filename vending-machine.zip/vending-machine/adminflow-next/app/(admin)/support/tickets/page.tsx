import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView } from '@/components/ui/kit';
import { getTickets } from '@/lib/live';
import DataTable, { type DataTableCol } from '@/components/ui/data-table';
import type { Cell } from '@/lib/mock/types';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function SupportTicketsQueuePage() {
  const g = await requireCap('/support/tickets');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/support/tickets" />;

  const tickets = await getTickets();

  const columns: DataTableCol[] = [
    { key: 'ticketNum', label: 'Ticket ID' },
    { key: 'customer', label: 'Customer' },
    { key: 'priority', label: 'Priority' },
    { key: 'type', label: 'Issue Type' },
    { key: 'machine', label: 'Machine' },
    { key: 'amount', label: 'Claim Amount', align: 'right' },
    { key: 'state', label: 'Status' },
    { key: 'assigned', label: 'Assigned To' },
  ];

  const rows: Record<string, Cell>[] = tickets.map(t => ({
    id: t.id,
    ticketNum: { t: 'link', v: t.num, href: `/support/tickets/${t.id}` },
    customer: t.customer,
    priority: {
      t: 'chip',
      v: t.priority,
      tone: t.priority === 'P1' ? 'red' : t.priority === 'P2' ? 'amber' : 'ink',
    },
    type: t.typeLabel,
    machine: t.machine.split('·')[0].trim(),
    amount: { t: 'money', v: t.amount },
    state: {
      t: 'chip',
      v: t.state.toUpperCase(),
      tone:
        t.state === 'open' ? 'red' :
        t.state === 'investigating' ? 'amber' :
        t.state === 'resolved-refund' ? 'leaf' : 'ink',
    },
    assigned: t.assignedTo ?? 'Unassigned',
  }));

  const filters = [
    { key: 'priority', label: 'Priority', options: ['P1', 'P2', 'P3', 'P4'] },
    { key: 'type', label: 'Category', options: ['No coffee', 'Quality', 'Cup stuck', 'Payment deducted', 'No kit'] },
    { key: 'state', label: 'Status', options: ['OPEN', 'INVESTIGATING', 'RESOLVED-REFUND', 'RESOLVED-REJECT', 'CLOSED'] },
  ];

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/support" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to SLA Board
        </Link>
      </div>

      <PageHead
        module="⑧ Support · Tickets"
        title="Support Ticket Queue"
        sub="Priority-sorted complaint queue. Click any ticket to open the side-by-side video clip and sensor evidence dispute desk."
      />

      <div className="card p-5">
        <DataTable
          columns={columns}
          rows={rows}
          filters={filters}
          csvName="manhattan-coffee-tickets"
          searchable
        />
      </div>
    </div>
  );
}
