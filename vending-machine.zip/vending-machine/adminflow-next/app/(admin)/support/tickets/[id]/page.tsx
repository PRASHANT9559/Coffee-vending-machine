import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote, rs } from '@/components/ui/kit';
import { getTicket } from '@/lib/mock/store';
import { ActionButton } from '@/components/ui/toast';
import { disputeResolve, demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconVideo, IconShield, IconClock } from '@/components/ui/icons';
import EvidenceVideoPlayer from '@/components/support/evidence-video-player';

export default async function DisputeDeskPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/support/tickets/${id}`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/support/tickets/${id}`} />;

  const t = getTicket(id);
  if (!t) notFound();

  const ev = t.evidence;
  const admin = g.admin;
  const canSupport = roleCan(admin.role, 'support');
  const canRefund = roleCan(admin.role, 'refunds');
  const canOwner = roleCan(admin.role, 'blacklist');

  const varianceDeficit = (ev?.dispense?.variancePct ?? 0) > 15;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/support/tickets" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Ticket Queue
        </Link>
      </div>

      <PageHead
        module="⑧ Support · Dispute Desk"
        title={`Dispute Desk — ${t.num}`}
        sub={`Claimed by ${t.customer} (${t.phone}) · ${t.openedLabel} at ${t.machine}. One-bundle video clip & sensor flow verification.`}
        actions={
          <div className="flex items-center gap-2">
            <Tag tone={t.priority === 'P1' ? 'red' : 'amber'}>{t.priority}</Tag>
            <Tag tone={t.state.includes('resolved') ? 'leaf' : 'amber'}>{t.state.toUpperCase()}</Tag>
          </div>
        }
      />

      {/* VERDICT BAR — The decision panel */}
      <div className="card p-5 bg-gradient-to-r from-page to-brand-50/40 border-brand-200">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-brand-600">
                1-Minute Dispute Verdict
              </span>
              {varianceDeficit ? (
                <Tag tone="red">VARIANCE WARNING (&gt;15%)</Tag>
              ) : (
                <Tag tone="leaf">FLOW LOG CLEAN</Tag>
              )}
            </div>
            <p className="text-[13px] text-ink-700 mt-1">
              {varianceDeficit
                ? 'High volumetric variance detected. Evidence indicates genuine dispense interruption.'
                : 'Sensor pulses and pickup detected within normal limits. Candidate for rejection with proof.'}
            </p>
          </div>

          {canSupport && (
            <div className="flex flex-wrap gap-2">
              <ActionButton
                run={async () => disputeResolve(t.id, 'refund', 'variance verified — refund requested', admin.name, admin.role)}
                tone="primary"
                confirm={`Approve refund of ₹${t.amount} for ${t.customer}? Money will be queued to the payout batch.`}
              >
                ✓ Approve Refund ({rs(t.amount)})
              </ActionButton>
              <ActionButton
                run={async () => disputeResolve(t.id, 'reject', 'sensor pulses + pickup event clean — rejected with proof snapshot', admin.name, admin.role)}
                tone="danger"
                confirm="Reject claim with proof? A signed evidence snapshot of sensor pulses and pickup timing will be sent to the customer."
              >
                ✕ Reject With Proof
              </ActionButton>
              <ActionButton
                run={async () => disputeResolve(t.id, 'info', 'requested additional payment screenshot from customer', admin.name, admin.role)}
              >
                Request Info (48h)
              </ActionButton>
              {canOwner && (
                <ActionButton
                  run={async () => demoAudit('blacklist.add', t.phone, 'blacklisted after repeated false claims', admin.name, admin.role)}
                  tone="danger"
                  confirm="Blacklist this phone number from ordering across all vending machines?"
                >
                  Blacklist User
                </ActionButton>
              )}
            </div>
          )}
        </div>
      </div>

      {/* SIDE-BY-SIDE EVIDENCE PANES — Diagram 03 Architecture */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* LEFT PANE: CLAIM & AUTO-CONTEXT */}
        <div className="space-y-6">
          <Card title="Customer Claim & Auto-Context" sub="Customer provided details + server auto-hydration">
            <div className="p-4 bg-page rounded-xl border border-line space-y-3">
              <div className="flex justify-between items-baseline">
                <span className="text-[11px] uppercase font-semibold text-ink-400">Claim Amount</span>
                <span className="font-mono font-bold text-[18px] text-brand-600">{rs(t.amount)}</span>
              </div>
              <KV k="Customer" v={<Link href={`/customers/${t.customerId}`} className="text-brand-600 hover:underline font-semibold">{t.customer}</Link>} />
              <KV k="Phone Number" v={t.phone} />
              <KV k="UPI Reference UTR" v={<span className="font-mono">{t.upiRef}</span>} />
              <KV k="Issue Category" v={t.typeLabel} />
              <div className="pt-2 border-t border-line">
                <p className="text-[11.5px] font-semibold text-ink-700 mb-1">Customer Statement:</p>
                <p className="p-3 bg-white rounded-lg border border-line text-[12.5px] text-ink-800 italic">
                  &ldquo;{t.message}&rdquo;
                </p>
              </div>
            </div>

            <div className="mt-4 p-4 bg-blue-50/50 border border-blue-200 rounded-xl space-y-2 text-[12px]">
              <p className="font-bold text-blue-900">Server Auto-Hydrated Context:</p>
              <p className="text-blue-800 leading-relaxed">{t.contextLine}</p>
            </div>
          </Card>

          {/* Machine Health Window */}
          <Card title="±10 Minute Machine Fault Timeline" sub="Hardware alarms around the timestamp of this order">
            {ev?.healthStrip ? (
              <div className="space-y-2">
                {ev.healthStrip.map((item, i) => (
                  <div key={i} className="p-3 bg-page rounded-lg border border-line flex items-center justify-between text-[12px]">
                    <span className="font-mono text-ink-500">{item.at}</span>
                    <span className="font-medium text-ink-800">{item.label}</span>
                    <Tag tone={item.level === 'fault' ? 'red' : item.level === 'warn' ? 'amber' : 'leaf'}>
                      {item.level.toUpperCase()}
                    </Tag>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center py-4 text-ink-400 text-[12px]">No faults recorded in this ±10min window.</p>
            )}
          </Card>
        </div>

        {/* RIGHT PANE: VIDEO CLIP & SENSOR DISPENSE LOG */}
        <div className="space-y-6">
          <Card title="Synchronized 30s Dual Camera Extract" sub="Internal nozzle camera & front customer interaction">
            <EvidenceVideoPlayer
              clipUrl={ev?.clipUrl}
              clipLenS={ev?.clipLenS ?? 30}
              ticketNo={t.num}
            />
          </Card>

          <Card title="Physical Dispense Sensor Log" sub="Logged in local SPIFFS flash and synced over MQTTS">
            {ev?.dispense ? (
              <div className="grid sm:grid-cols-2 gap-x-4 gap-y-1">
                <KV k="Valve Open Duration" v={`${ev.dispense.valveMs} ms`} mono />
                <KV k="Flow Meter Pulses" v={`${ev.dispense.pulses} pulses`} mono />
                <KV k="Actual Liquid Dispensed" v={`${ev.dispense.actualMl} ml (exp: ${ev.dispense.expectedMl}ml)`} mono />
                <KV k="Volumetric Variance" v={<span className={ev.dispense.variancePct > 15 ? 'text-red-600 font-bold' : ''}>{ev.dispense.variancePct}%</span>} mono />
                <KV k="Infrared Cup Detected" v={ev.dispense.cupDetected ? <Tag tone="leaf">DETECTED</Tag> : <Tag tone="red">MISSING</Tag>} />
                <KV k="Kit Drop Switch" v={ev.dispense.kitDropped ? <Tag tone="leaf">DROPPED</Tag> : <Tag tone="red">FAILED</Tag>} />
                <KV k="Dispense Window Latch" v={ev.dispense.windowOpened ? <Tag tone="leaf">OPENED</Tag> : <Tag tone="red">CLOSED</Tag>} />
                <KV k="Physical Pickup Detected" v={ev.dispense.pickupDetected ? <Tag tone="leaf">PICKED UP</Tag> : <Tag tone="amber">NO PICKUP</Tag>} />
              </div>
            ) : (
              <p className="text-center py-4 text-ink-400 text-[12px]">Sensor log unavailable.</p>
            )}
            <FootNote>
              Single-bundle rule: Both panes hydrate from the same PostgreSQL transaction via fn_ticket_evidence_bundle().
            </FootNote>
          </Card>
        </div>
      </div>

      {/* Ticket State History */}
      <Card title="Ticket State Transition History" sub="Audit of all actions taken on this ticket">
        <ol className="relative pl-4 space-y-3 before:absolute before:left-[5px] before:top-2 before:bottom-2 before:w-px before:bg-line text-[12px]">
          {t.history.map((h, i) => (
            <li key={i} className="relative">
              <span className="absolute -left-4 top-1 w-2.5 h-2.5 rounded-full bg-brand-500 border-2 border-white" />
              <div className="flex items-baseline gap-2">
                <span className="font-bold text-ink-800">{h.by}</span>
                <span className="text-[10.5px] text-ink-400 font-mono">{h.tsLabel}</span>
              </div>
              <p className="text-ink-600 mt-0.5">{h.text}</p>
            </li>
          ))}
        </ol>
      </Card>
    </div>
  );
}
