import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { REVIEW_SEED } from '@/lib/mock/support';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconStar } from '@/components/ui/icons';

export default async function SupportReviewsPage() {
  const g = await requireCap('/support/reviews');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/support/reviews" />;

  const admin = g.admin;
  const canSupport = roleCan(admin.role, 'support');

  const avgRating = (REVIEW_SEED.reduce((a, b) => a + b.stars, 0) / REVIEW_SEED.length).toFixed(1);

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/support" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to SLA Board
        </Link>
      </div>

      <PageHead
        module="⑧ Support · Feedback"
        title="Customer Ratings & Blend Reviews"
        sub="Consumer post-dispense star ratings, taste profiles, feedback tags, and automated barista bot replies."
      />

      <div className="grid sm:grid-cols-3 gap-4">
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Average Network Rating</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-[28px] font-bold text-amber2-600 font-mono">{avgRating}</span>
            <span className="text-amber2-500">★★★★☆</span>
          </div>
          <span className="text-[11px] text-ink-500">From {REVIEW_SEED.length} verified ratings</span>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Top Compliment</p>
          <p className="text-[24px] font-bold text-leaf-600 mt-1">Velvet Froth</p>
          <span className="text-[11px] text-ink-500">Mentioned in 62% of 5-star ratings</span>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Attention Metric</p>
          <p className="text-[24px] font-bold text-red-600 mt-1">2 Flagged</p>
          <span className="text-[11px] text-ink-500">1-star ratings regarding dispense wait</span>
        </div>
      </div>

      <Card title="Feedback Stream" sub="feedback_ratings across nodes">
        <div className="space-y-4">
          {REVIEW_SEED.map(rv => (
            <div key={rv.id} className="p-4 bg-page rounded-xl border border-line space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[13px] text-ink-900">{rv.customer}</span>
                  <span className="text-amber2-500 text-xs">{'★'.repeat(rv.stars)}{'☆'.repeat(5 - rv.stars)}</span>
                  <span className="text-ink-400 text-[11px]">at {rv.machine}</span>
                </div>
                <span className="text-[10.5px] font-mono text-ink-400">{rv.tsLabel}</span>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {rv.tags.map(t => (
                  <Tag key={t} tone="brand">{t}</Tag>
                ))}
              </div>

              {rv.reply && (
                <div className="mt-2 p-2.5 bg-white border border-line rounded-lg text-[11.5px] text-ink-700">
                  <strong className="text-brand-600 block mb-0.5">Barista Reply:</strong>
                  {rv.reply}
                </div>
              )}

              {canSupport && !rv.reply && (
                <div className="pt-2 flex justify-end gap-2">
                  <ActionButton
                    small
                    run={async () => demoAudit('review.reply', rv.id, 'sent canned feedback thank-you reply', admin.name, admin.role)}
                  >
                    Quick Reply
                  </ActionButton>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
