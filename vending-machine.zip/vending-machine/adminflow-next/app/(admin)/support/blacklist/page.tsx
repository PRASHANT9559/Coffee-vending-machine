import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { BLACKLIST_SEED } from '@/lib/mock/support';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconShield, IconPlus } from '@/components/ui/icons';

export default async function SupportBlacklistPage() {
  const g = await requireCap('/support/blacklist');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/support/blacklist" />;

  const admin = g.admin;
  const isOwner = roleCan(admin.role, 'blacklist');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/support" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to SLA Board
        </Link>
      </div>

      <PageHead
        module="⑧ Support · Anti-Fraud"
        title="Network Security Blacklist (Owner Only)"
        sub="Hardware IMEI identifiers, phone numbers, UPI UTR numbers, and IP ranges prohibited from dispensing or claiming refunds across the network."
        actions={
          isOwner && (
            <ActionButton
              run={async () => demoAudit('blacklist.add_entry', 'Manual Blacklist', 'added suspicious device IMEI to blacklist', admin.name, admin.role)}
              tone="danger"
            >
              <IconPlus className="w-4 h-4" /> Add Blacklist Entry
            </ActionButton>
          )
        }
      />

      <Card title="Restricted Entities Ledger" sub="fraud_blacklist table — strict edge enforcement">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Blocked Entity Value</th>
                <th className="py-2.5 px-3 text-left">Identifier Type</th>
                <th className="py-2.5 px-3 text-left">Severity</th>
                <th className="py-2.5 px-3 text-left">Reason / Pattern</th>
                <th className="py-2.5 px-3 text-left">Added On</th>
                <th className="py-2.5 px-3 text-left">Expiry</th>
                {isOwner && <th className="py-2.5 px-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {BLACKLIST_SEED.map(bl => (
                <tr key={bl.id} className="hover:bg-page/60">
                  <td className="py-3 px-3 font-mono font-bold text-red-600">{bl.value}</td>
                  <td className="py-3 px-3">
                    <Tag tone="brand">{bl.kind.toUpperCase()}</Tag>
                  </td>
                  <td className="py-3 px-3">
                    <Tag tone={bl.severity === 'high' ? 'red' : bl.severity === 'med' ? 'amber' : 'ink'}>
                      {bl.severity.toUpperCase()}
                    </Tag>
                  </td>
                  <td className="py-3 px-3 text-ink-700">{bl.reason}</td>
                  <td className="py-3 px-3 font-mono text-[11.5px] text-ink-500">{bl.addedLabel}</td>
                  <td className="py-3 px-3 font-mono text-[11.5px] text-ink-500">{bl.expiresLabel}</td>
                  {isOwner && (
                    <td className="py-3 px-3 text-right">
                      <ActionButton
                        small
                        run={async () => demoAudit('blacklist.remove', bl.value, 'removed from network blacklist', admin.name, admin.role)}
                        confirm={`Remove ${bl.value} from the network blacklist?`}
                      >
                        Remove
                      </ActionButton>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <FootNote>
          The blacklist is checked at the edge gateway before creating orders or processing webhook events. Only the Owner role can modify this table.
        </FootNote>
      </Card>
    </div>
  );
}
