import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { REFERRAL_FUNNEL, LEADERS, FRAUD_PAIRS } from '@/lib/mock/marketing';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconUsers, IconShield } from '@/components/ui/icons';

export default async function MarketingReferralsPage() {
  const g = await requireCap('/marketing/referrals');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/referrals" />;

  const admin = g.admin;
  const canMkt = roleCan(admin.role, 'marketing');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Referrals"
        title="Referral Viral Funnel & Anti-Fraud"
        sub="P2P invite mechanics, top campus advocates, conversion rates, and hardware fingerprinting for self-referral ring detection."
      />

      {/* Conversion Funnel */}
      <div className="grid sm:grid-cols-4 gap-4 text-center">
        <div className="card p-5">
          <span className="text-[11px] font-semibold text-ink-400 uppercase">1. Links Shared</span>
          <p className="text-[26px] font-bold text-ink-900 mt-1">{REFERRAL_FUNNEL.shared}</p>
          <span className="text-[11px] text-ink-500">WhatsApp & Social shares</span>
        </div>
        <div className="card p-5">
          <span className="text-[11px] font-semibold text-ink-400 uppercase">2. App Downloads</span>
          <p className="text-[26px] font-bold text-brand-600 mt-1">{REFERRAL_FUNNEL.installed}</p>
          <span className="text-[11px] text-ink-500">{Math.round((REFERRAL_FUNNEL.installed / REFERRAL_FUNNEL.shared) * 100)}% install rate</span>
        </div>
        <div className="card p-5">
          <span className="text-[11px] font-semibold text-ink-400 uppercase">3. First Order Completed</span>
          <p className="text-[26px] font-bold text-leaf-600 mt-1">{REFERRAL_FUNNEL.firstOrder}</p>
          <span className="text-[11px] text-ink-500">{Math.round((REFERRAL_FUNNEL.firstOrder / REFERRAL_FUNNEL.installed) * 100)}% activation</span>
        </div>
        <div className="card p-5">
          <span className="text-[11px] font-semibold text-ink-400 uppercase">4. Repeat Customers</span>
          <p className="text-[26px] font-bold text-blue-600 mt-1">{REFERRAL_FUNNEL.repeat}</p>
          <span className="text-[11px] text-ink-500">{Math.round((REFERRAL_FUNNEL.repeat / REFERRAL_FUNNEL.firstOrder) * 100)}% retention</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Leaderboard */}
        <Card title="Top Campus Inviters" sub="Advocate leaderboard ranked by qualified redemptions">
          <div className="divide-y divide-line">
            {LEADERS.map((ldr, i) => (
              <div key={i} className="py-3 flex items-center justify-between text-[12.5px]">
                <div className="flex items-center gap-2.5">
                  <span className="w-6 h-6 rounded-full bg-brand-50 text-brand-600 font-bold text-[11px] flex items-center justify-center">
                    {i + 1}
                  </span>
                  <div>
                    <span className="font-semibold text-ink-900">{ldr.name}</span>
                    <p className="text-[11px] text-ink-400">{ldr.invites} invited · {ldr.qualified} qualified</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-leaf-600">+{rs(ldr.gain)}</span>
                  <p className="text-[10px] text-ink-400">wallet bonuses paid</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Fraud Pairs */}
        <Card title="Flagged Self-Referral Fraud Pairs" sub="Detected by Android IMEI / device fingerprint & Wi-Fi SSID correlation">
          <div className="space-y-3">
            {FRAUD_PAIRS.map((fp, i) => (
              <div key={i} className="p-3.5 bg-red-50/50 border border-red-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-[12.5px]">
                  <span className="font-bold text-red-900">{fp.inviter} ➔ {fp.invitee}</span>
                  <Tag tone="red">SUSPECTED FRAUD</Tag>
                </div>
                <p className="text-[11.5px] text-red-700 leading-relaxed">
                  Correlation trigger: <strong>{fp.device}</strong>
                </p>
                <div className="flex items-center justify-between pt-2 border-t border-red-200/60 text-[11px]">
                  <span className="text-red-600 font-mono">Flagged on {fp.atLabel}</span>
                  {canMkt && (
                    <ActionButton
                      small
                      tone="danger"
                      run={async () => demoAudit('referral.void', `${fp.inviter} / ${fp.invitee}`, 'voided fraudulent referral payout', admin.name, admin.role)}
                      confirm="Void referral bonus and clawback wallet balance?"
                    >
                      Void Bonus
                    </ActionButton>
                  )}
                </div>
              </div>
            ))}
          </div>
          <FootNote>
            Self-referrals are automatically held in escrow until a qualified physical dispense event occurs on a verified vending machine.
          </FootNote>
        </Card>
      </div>
    </div>
  );
}
