import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { BANNERS } from '@/lib/mock/marketing';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconPlus } from '@/components/ui/icons';

export default async function MarketingBannersPage() {
  const g = await requireCap('/marketing/banners');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/banners" />;

  const admin = g.admin;
  const canMkt = roleCan(admin.role, 'marketing');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Banners"
        title="In-App Promotional Banners & Slots"
        sub="Control placement slots across consumer mobile app surfaces: Home Carousel, Home Strip, Splash, QR Success, Wallet, and Leaderboard."
        actions={
          canMkt && (
            <ActionButton
              run={async () => demoAudit('banner.create', 'New Slot Asset', 'created new promotional banner art', admin.name, admin.role)}
              tone="primary"
            >
              <IconPlus className="w-4 h-4" /> Add Banner Asset
            </ActionButton>
          )
        }
      />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {BANNERS.map(b => {
          const ctr = b.impressions > 0 ? ((b.clicks / b.impressions) * 100).toFixed(1) : '0.0';

          return (
            <Card key={b.id} title={b.name} sub={`Slot Placement: ${b.slot}`}>
              <div className="aspect-[2/1] rounded-xl bg-ink-900 border border-line flex flex-col items-center justify-center text-white my-3 relative overflow-hidden">
                <span className="text-[12px] font-bold tracking-tight text-white/90">
                  {b.name}
                </span>
                <span className="text-[10px] text-white/60 font-mono mt-1">
                  Slot: {b.slot} · P{b.priority}
                </span>
                <div className="absolute top-2 right-2">
                  <Tag tone={b.active ? 'leaf' : 'ink'}>
                    {b.active ? 'LIVE' : 'INACTIVE'}
                  </Tag>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[12px] pt-1">
                <div className="p-2.5 bg-page rounded-lg border border-line">
                  <span className="text-[10px] uppercase font-semibold text-ink-400 block">Impressions</span>
                  <span className="font-mono font-bold text-ink-900">{b.impressions.toLocaleString()}</span>
                </div>
                <div className="p-2.5 bg-page rounded-lg border border-line">
                  <span className="text-[10px] uppercase font-semibold text-ink-400 block">Clicks / CTR</span>
                  <span className="font-mono font-bold text-brand-600">{b.clicks} ({ctr}%)</span>
                </div>
              </div>

              <p className="text-[11px] text-ink-400 mt-2 font-mono">Schedule: {b.windowLabel}</p>

              {canMkt && (
                <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-line">
                  <ActionButton
                    small
                    run={async () => demoAudit('banner.toggle', b.name, `toggled status to ${!b.active}`, admin.name, admin.role)}
                  >
                    {b.active ? 'Deactivate' : 'Activate'}
                  </ActionButton>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
