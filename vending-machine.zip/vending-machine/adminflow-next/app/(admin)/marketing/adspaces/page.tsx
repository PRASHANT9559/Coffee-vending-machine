import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { AD_SPACES } from '@/lib/mock/marketing';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function MarketingAdSpacesPage() {
  const g = await requireCap('/marketing/adspaces');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/adspaces" />;

  const admin = g.admin;
  const canFinance = roleCan(admin.role, 'wallet');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Physical Ad Spaces"
        title="Machine Physical Surface Rentals & Invoices"
        sub="Inventory of rentable advertising surfaces on physical vending kiosks: Side Panels, Fascia Wraps, Idle Kiosk Displays, and Custom Paper Cup Prints."
      />

      <Card title="Surface Inventory & Client Bookings" sub="ad_spaces and ad_space_bookings">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Machine Node</th>
                <th className="py-2.5 px-3 text-left">Surface Slot</th>
                <th className="py-2.5 px-3 text-left">Advertiser / Brand</th>
                <th className="py-2.5 px-3 text-left">Rental Period</th>
                <th className="py-2.5 px-3 text-right">Monthly Rate</th>
                <th className="py-2.5 px-3 text-left">Invoice No</th>
                <th className="py-2.5 px-3 text-center">Payment Status</th>
                {canFinance && <th className="py-2.5 px-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {AD_SPACES.map(sp => (
                <tr key={sp.id} className="hover:bg-page/60">
                  <td className="py-3 px-3 font-semibold text-ink-900">{sp.machine}</td>
                  <td className="py-3 px-3">
                    <Tag tone="brand">{sp.surface.toUpperCase()}</Tag>
                  </td>
                  <td className="py-3 px-3 font-medium text-ink-800">{sp.advertiser}</td>
                  <td className="py-3 px-3 text-ink-500 font-mono text-[11.5px]">
                    {sp.startLabel} – {sp.endLabel} ({sp.months} mo)
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-ink-900">
                    {rs(sp.ratePerMonth)}/mo
                  </td>
                  <td className="py-3 px-3 font-mono text-[11.5px] text-ink-500">{sp.invoiceNo}</td>
                  <td className="py-3 px-3 text-center">
                    <Tag tone={sp.state === 'paid' ? 'leaf' : sp.state === 'unpaid' ? 'amber' : 'red'}>
                      {sp.state.toUpperCase()}
                    </Tag>
                  </td>
                  {canFinance && (
                    <td className="py-3 px-3 text-right">
                      {sp.state !== 'paid' && (
                        <ActionButton
                          small
                          tone="primary"
                          run={async () => demoAudit('adspace.mark_paid', `${sp.machine} · ${sp.advertiser}`, 'marked rental invoice as paid', admin.name, admin.role)}
                        >
                          Mark Paid
                        </ActionButton>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <FootNote>
          Surface rental income is accounted for separately from coffee margins across all profitability dashboards.
        </FootNote>
      </Card>
    </div>
  );
}
