import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { OFFERS } from '@/lib/mock/marketing';
import { Meter } from '@/components/ui/charts';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconPlus } from '@/components/ui/icons';

export default async function MarketingOffersPage() {
  const g = await requireCap('/marketing/offers');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/offers" />;

  const admin = g.admin;
  const canMkt = roleCan(admin.role, 'marketing');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Offers"
        title="Promotional Offer Rules & Budget Caps"
        sub="Targeted pricing rules, wallet credit bonuses, and free item incentives with hard budgetary caps that automatically stop campaigns."
        actions={
          canMkt && (
            <ActionButton
              run={async () => demoAudit('offer.create', 'New Offer', 'created seasonal offer rule', admin.name, admin.role)}
              tone="primary"
            >
              <IconPlus className="w-4 h-4" /> Create Offer
            </ActionButton>
          )
        }
      />

      <div className="grid md:grid-cols-2 gap-6">
        {OFFERS.map(of => {
          const pct = Math.min(100, Math.round((of.spent / of.budget) * 100));

          return (
            <Card key={of.id} title={of.name} sub={`Active Window: ${of.windowLabel}`}>
              <div className="flex items-center gap-2 mb-3">
                <Tag tone={of.state === 'running' ? 'leaf' : of.state === 'paused' ? 'amber' : 'ink'}>
                  {of.state.toUpperCase()}
                </Tag>
                <Tag tone="brand">{of.kind.toUpperCase()}</Tag>
                <span className="text-[12.5px] font-bold text-ink-800 ml-auto">{of.valueLabel}</span>
              </div>

              <div className="p-3 bg-page rounded-xl border border-line space-y-2 text-[12px] mb-4">
                <div className="flex justify-between">
                  <span className="text-ink-500">Target Segment</span>
                  <span className="font-semibold">{of.segment}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-500">Min Order Requirement</span>
                  <span className="font-semibold">{of.minOrder > 0 ? rs(of.minOrder) : 'No Minimum'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-500">Times Claimed</span>
                  <span className="font-mono font-bold">{of.uses} customers</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] text-ink-500">
                  <span>Burn: {rs(of.spent)} spent</span>
                  <span>Budget Cap: {rs(of.budget)}</span>
                </div>
                <Meter pct={pct} color={pct > 90 ? '#DC2626' : '#F04E23'} h={6} />
              </div>

              {canMkt && (
                <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-line">
                  <ActionButton
                    small
                    run={async () => demoAudit('offer.duplicate', of.name, 'duplicated offer config', admin.name, admin.role)}
                  >
                    Duplicate
                  </ActionButton>
                  <ActionButton
                    small
                    tone={of.state === 'running' ? 'danger' : 'neutral'}
                    run={async () => demoAudit('offer.toggle_state', of.name, `offer state changed from ${of.state}`, admin.name, admin.role)}
                  >
                    {of.state === 'running' ? 'Pause Campaign' : 'Resume'}
                  </ActionButton>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      <FootNote>
        Campaigns are paused but never permanently deleted in the database, preserving all historical receipt calculations and foreign keys.
      </FootNote>
    </div>
  );
}
