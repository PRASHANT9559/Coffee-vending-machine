import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { AD_NETWORKS, POSTBACKS } from '@/lib/mock/marketing';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function MarketingAdsPage() {
  const g = await requireCap('/marketing/ads');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/ads" />;

  const admin = g.admin;
  const canMkt = roleCan(admin.role, 'marketing');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Ads"
        title="Rewarded Video Networks & Postback Reconciliation"
        sub="Third-party video SDK monetization, eCPM yields, Coffee Coins reward exchange rates, and the anti-infinite-coin-farm postback verification queue."
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Ad Networks & Performance" sub="Rewarded video SSP connections">
            <div className="space-y-4">
              {AD_NETWORKS.map(net => (
                <div key={net.id} className="p-4 bg-page rounded-xl border border-line space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-[14px] text-ink-900">{net.name}</h4>
                      <p className="text-[11px] text-ink-400">eCPM: ₹{net.ecpm} · {net.rewarded} rewarded views</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-[14px] text-leaf-600">+{rs(net.revenue)}</span>
                      <Tag tone={net.state === 'connected' ? 'leaf' : 'amber'}>
                        {net.state.toUpperCase()}
                      </Tag>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[12px] pt-2 border-t border-line/60">
                    <span className="text-ink-600">
                      Coins Awarded per Completed View: <strong>{net.coinsPerView} Coins</strong>
                    </span>
                    <span className="text-[11px] text-ink-400">
                      (~{Math.ceil(200 / net.coinsPerView)} views needed for a ₹20 cup)
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <FootNote>
              Coins can only be redeemed for physical coffee dispensing at vending machines; they cannot be cashed out to UPI bank accounts.
            </FootNote>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Postback Reconciliation Queue" sub="Anti-infinite-coin-farm audit queue">
            <div className="space-y-3">
              {POSTBACKS.map(pb => (
                <div key={pb.id} className="p-3 bg-page rounded-xl border border-line text-[12px] space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-ink-800">{pb.user}</span>
                    <Tag tone={pb.state === 'pending' ? 'amber' : 'red'}>
                      {pb.state.toUpperCase()}
                    </Tag>
                  </div>
                  <p className="text-[11px] text-ink-500 font-mono">Claimed: {pb.amount} coins · {pb.claimedLabel}</p>
                  <p className="text-[11.5px] text-ink-700">{pb.reason}</p>
                  {canMkt && pb.state === 'pending' && (
                    <div className="pt-2 flex justify-end">
                      <ActionButton
                        small
                        run={async () => demoAudit('ad.recheck_postback', pb.id, 'rechecked ad SSP postback server', admin.name, admin.role)}
                      >
                        Recheck Postback
                      </ActionButton>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
