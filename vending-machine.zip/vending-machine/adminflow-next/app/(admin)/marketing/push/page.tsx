import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { PUSHES, SEGMENTS } from '@/lib/mock/marketing';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconSend } from '@/components/ui/icons';

export default async function MarketingPushPage() {
  const g = await requireCap('/marketing/push');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/push" />;

  const admin = g.admin;
  const canMkt = roleCan(admin.role, 'marketing');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Push"
        title="Push Broadcasts & Notifications"
        sub="Targeted mobile pushes, geo-fenced campus alerts, deep-link routing, and open rate analytics."
      />

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Push Composer */}
        <div className="space-y-4">
          <Card title="Notification Composer" sub="Broadcast message to customer app">
            <div className="space-y-3 mt-2">
              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Notification Title</label>
                <input
                  type="text"
                  placeholder="e.g. Free Frappe Upgrade Today ☕"
                  disabled={!canMkt}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12.5px]"
                />
              </div>

              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Message Body</label>
                <textarea
                  rows={3}
                  placeholder="Keep your coffee streak alive before 2 PM..."
                  disabled={!canMkt}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12.5px]"
                />
              </div>

              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">Target Segment</label>
                <select
                  disabled={!canMkt}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12px]"
                >
                  {SEGMENTS.map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[12px] font-semibold text-ink-700 mb-1">App Deep Link</label>
                <input
                  type="text"
                  defaultValue="app://wallet"
                  disabled={!canMkt}
                  className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12px] font-mono text-brand-600"
                />
              </div>

              {canMkt && (
                <div className="pt-2 flex gap-2">
                  <ActionButton
                    run={async () => demoAudit('push.send_broadcast', 'Campaign', 'broadcasted push notification', admin.name, admin.role)}
                    tone="primary"
                    className="flex-1"
                  >
                    <IconSend className="w-4 h-4" /> Send Now
                  </ActionButton>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Push History */}
        <div className="lg:col-span-2 space-y-4">
          <Card title="Push Notification History" sub="Delivered broadcasts and engagement metrics">
            <div className="space-y-4">
              {PUSHES.map(p => {
                const openRate = p.delivered > 0 ? ((p.opened / p.delivered) * 100).toFixed(1) : '—';

                return (
                  <div key={p.id} className="p-4 rounded-xl border border-line bg-page/40">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-[13.5px] text-ink-900">{p.title}</h4>
                          <Tag tone={p.state === 'sent' ? 'leaf' : p.state === 'scheduled' ? 'blue' : 'ink'}>
                            {p.state.toUpperCase()}
                          </Tag>
                        </div>
                        {p.body && <p className="text-[12px] text-ink-600 mt-1">{p.body}</p>}
                      </div>
                      <span className="text-[10.5px] font-mono text-ink-400 shrink-0">{p.atLabel}</span>
                    </div>

                    <div className="flex items-center justify-between text-[11.5px] text-ink-500 mt-3 pt-2 border-t border-line/60">
                      <span>Segment: <strong>{p.segment}</strong></span>
                      <span className="font-mono text-brand-600">{p.deepLink}</span>
                      <span className="font-semibold text-ink-800">
                        {p.delivered > 0 ? `${p.delivered} sent · ${openRate}% open rate` : 'Not delivered'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
            <FootNote>
              Push notifications link directly into consumer deep links (e.g. app://wallet or app://order) ensuring zero lost attribution.
            </FootNote>
          </Card>
        </div>
      </div>
    </div>
  );
}
