import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { FESTIVALS, FESTIVAL_MODE } from '@/lib/mock/marketing';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconFlame, IconSnow } from '@/components/ui/icons';

export default async function MarketingFestivalsPage() {
  const g = await requireCap('/marketing/festivals');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/festivals" />;

  const admin = g.admin;
  const canMkt = roleCan(admin.role, 'marketing');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Festivals"
        title="Seasonal Festival Packs & Fleet Operating Mode"
        sub="One-click campaign packages bundling promotional banners, push notifications, and recipe discounts. Includes the network Master Hot/Cold mode switch."
        actions={
          canMkt && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => demoAudit('festival.create_pack', 'New Festival Pack', 'created seasonal campaign pack', admin.name, admin.role)}
                tone="primary"
              >
                + Create Festival Pack
              </ActionButton>
            </div>
          )
        }
      />

      {/* Master Mode Switch Banner */}
      <div className="card p-6 bg-gradient-to-r from-brand-50 to-blue-50 border-line flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-blue-500 text-white flex items-center justify-center">
              <IconSnow className="w-5 h-5" />
            </span>
            <h3 className="text-[17px] font-bold text-ink-900">Fleet Master Hot / Cold Mode Switch</h3>
          </div>
          <p className="text-[12.5px] text-ink-600 mt-1 max-w-2xl leading-relaxed">
            Flips eligible vending machines and the mobile consumer kiosk into Summer/Winter seasonal framing in a single command. Currently: <strong className="text-blue-700">Cold Mode Active</strong> (Chilled Frappe prioritised).
          </p>
        </div>

        {canMkt && (
          <div className="flex items-center gap-2">
            <ActionButton
              run={async () => demoAudit('fleet.master_mode', 'Fleet Nodes', 'switched fleet mode to HOT', admin.name, admin.role)}
              tone="primary"
            >
              <IconFlame className="w-4 h-4" /> Switch to Hot Mode
            </ActionButton>
            <ActionButton
              run={async () => demoAudit('fleet.master_mode', 'Fleet Nodes', 'switched fleet mode to COLD', admin.name, admin.role)}
            >
              <IconSnow className="w-4 h-4" /> Switch to Cold Mode
            </ActionButton>
          </div>
        )}
      </div>

      {/* Festival Packs Calendar */}
      <div className="grid md:grid-cols-2 gap-6">
        {FESTIVALS.map(f => (
          <Card key={f.id} title={f.name} sub={`Target Calendar Window: ${f.windowLabel}`}>
            <div className="mb-3">
              <Tag tone={f.state === 'live' ? 'leaf' : f.state === 'upcoming' ? 'blue' : 'ink'}>
                {f.state.toUpperCase()}
              </Tag>
            </div>

            <div className="p-3.5 bg-page rounded-xl border border-line space-y-2 text-[12px]">
              <p className="font-semibold text-ink-800">Bundled Assets in this Pack:</p>
              <div className="space-y-1 text-ink-600">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-brand-500" />
                  <span>Offer Rule: <strong>{f.pack.offer}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                  <span>App Banner: <strong>{f.pack.banner}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber2-500" />
                  <span>Push Broadcast: <strong>{f.pack.push}</strong></span>
                </div>
              </div>
            </div>

            {canMkt && (
              <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-line">
                <ActionButton
                  small
                  run={async () => demoAudit('festival.deploy', f.name, 'deployed one-click seasonal pack across fleet', admin.name, admin.role)}
                >
                  Deploy Bundle
                </ActionButton>
              </div>
            )}
          </Card>
        ))}
      </div>

      <FootNote>
        One-click festival packs prevent human error by coordinating app marketing assets, machine temperature profiles, and discount rules simultaneously.
      </FootNote>
    </div>
  );
}
