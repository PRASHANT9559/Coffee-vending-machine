import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { COUPONS } from '@/lib/mock/marketing';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconArrowLeft, IconPlus } from '@/components/ui/icons';

export default async function MarketingCouponsPage() {
  const g = await requireCap('/marketing/coupons');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing/coupons" />;

  const admin = g.admin;
  const canMkt = roleCan(admin.role, 'marketing');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/marketing" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Marketing Overview
        </Link>
      </div>

      <PageHead
        module="⑦ Marketing · Coupons"
        title="Promotional Coupon Vouchers"
        sub="Redeemable promo codes, per-user usage limits, redemption velocity counters, and batch generation."
        actions={
          canMkt && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => demoAudit('coupon.bulk_generate', '500 codes', 'batch generated 500 campus welcome codes', admin.name, admin.role)}
                tone="primary"
              >
                <IconPlus className="w-4 h-4" /> Bulk Generate 500 Codes
              </ActionButton>
            </div>
          )
        }
      />

      <Card title="Active Promo Codes" sub="coupons + coupon_redemptions ledger">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase font-semibold">
                <th className="py-2.5 px-3 text-left">Coupon Code</th>
                <th className="py-2.5 px-3 text-left">Discount Value</th>
                <th className="py-2.5 px-3 text-right">Redemptions</th>
                <th className="py-2.5 px-3 text-right">Per-User Cap</th>
                <th className="py-2.5 px-3 text-left">Expiration</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                {canMkt && <th className="py-2.5 px-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {COUPONS.map(cp => (
                <tr key={cp.id} className="hover:bg-page/60">
                  <td className="py-3 px-3 font-mono font-bold text-brand-600">{cp.code}</td>
                  <td className="py-3 px-3 font-semibold text-ink-800">{cp.valueLabel}</td>
                  <td className="py-3 px-3 text-right font-mono">
                    <span className="font-semibold text-ink-900">{cp.used}</span> / {cp.total}
                  </td>
                  <td className="py-3 px-3 text-right text-ink-500">{cp.perUserLimit} per user</td>
                  <td className="py-3 px-3 font-mono text-ink-500 text-[11.5px]">{cp.expiryLabel}</td>
                  <td className="py-3 px-3 text-center">
                    <Tag tone={cp.state === 'active' ? 'leaf' : 'amber'}>
                      {cp.state.toUpperCase()}
                    </Tag>
                  </td>
                  {canMkt && (
                    <td className="py-3 px-3 text-right">
                      <ActionButton
                        small
                        run={async () => demoAudit('coupon.toggle', cp.code, 'toggled active status', admin.name, admin.role)}
                      >
                        {cp.state === 'active' ? 'Pause' : 'Activate'}
                      </ActionButton>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <FootNote>
          Redemptions are validated by the Rust microservice with database-level isolation to prevent race-condition concurrency double-claims.
        </FootNote>
      </Card>
    </div>
  );
}
