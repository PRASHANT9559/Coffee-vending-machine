import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, rs } from '@/components/ui/kit';
import { OFFERS, BANNERS, REFERRAL_FUNNEL, FESTIVALS } from '@/lib/mock/marketing';
import { Meter } from '@/components/ui/charts';
import { IconMegaphone, IconGift, IconUsers } from '@/components/ui/icons';

export default async function MarketingOverviewPage() {
  const g = await requireCap('/marketing');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/marketing" />;

  const subroutes = [
    { href: '/marketing/offers', label: 'Offers & Discounts', sub: 'Budget-capped offers and dynamic price rules' },
    { href: '/marketing/coupons', label: 'Coupon Codes', sub: 'Promo voucher generation and redemption caps' },
    { href: '/marketing/banners', label: 'In-App Banners', sub: 'Placement slots, carousels, and visual previews' },
    { href: '/marketing/push', label: 'Push Broadcasts', sub: 'Segmented messaging, open rates, and deep links' },
    { href: '/marketing/festivals', label: 'Festival Packs', sub: 'Seasonal campaign bundles & Master Hot/Cold switch' },
    { href: '/marketing/referrals', label: 'Referral Engine', sub: 'Viral inviters, conversion funnels, and fraud pairs' },
    { href: '/marketing/ads', label: 'Ad Monetization', sub: 'Rewarded video networks, eCPM, and postback checks' },
    { href: '/marketing/adspaces', label: 'Physical Ad Spaces', sub: 'Rentable node fascia, side panels, and cup prints' },
  ];

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑦ Marketing"
        title="Growth, Campaigns & Monetization"
        sub="Customer acquisition, promotional offers, coupon code engines, rewarded advertising networks, and physical machine surface rentals."
      />

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Active Campaigns</p>
          <p className="text-[26px] font-bold text-ink-900 mt-1">{OFFERS.filter(o => o.state === 'running').length} running</p>
          <span className="text-[11px] text-leaf-600 font-medium">Budget burn monitored</span>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Banner Impressions</p>
          <p className="text-[26px] font-bold text-ink-900 mt-1">273k</p>
          <span className="text-[11px] text-brand-600 font-medium">6 active app slots</span>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Referral Conversions</p>
          <p className="text-[26px] font-bold text-ink-900 mt-1">{REFERRAL_FUNNEL.firstOrder} first orders</p>
          <span className="text-[11px] text-ink-400">From {REFERRAL_FUNNEL.shared} shared links</span>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Auxiliary Ad Revenue</p>
          <p className="text-[26px] font-bold text-leaf-700 mt-1">₹4,740</p>
          <span className="text-[11px] text-leaf-600 font-medium">Ads + rentals this month</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Marketing Modules & Campaign Tools" sub="Manage marketing workflows and ad channels">
            <div className="grid sm:grid-cols-2 gap-3 mt-2">
              {subroutes.map((sub, i) => (
                <Link
                  key={i}
                  href={sub.href}
                  className="p-4 rounded-xl border border-line bg-page/50 hover:bg-page hover:border-brand-300 transition-all group block"
                >
                  <p className="font-bold text-[13.5px] text-ink-900 group-hover:text-brand-600 transition-colors">
                    {sub.label} →
                  </p>
                  <p className="text-[11.5px] text-ink-500 mt-1 leading-relaxed">{sub.sub}</p>
                </Link>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Live Campaign Budget Burn" sub="Automated shutdown triggers when cap is reached">
            <div className="space-y-4">
              {OFFERS.map(of => {
                const pct = Math.min(100, Math.round((of.spent / of.budget) * 100));
                return (
                  <div key={of.id} className="space-y-1.5 text-[12px]">
                    <div className="flex justify-between font-semibold">
                      <span className="text-ink-800">{of.name}</span>
                      <Tag tone={of.state === 'running' ? 'leaf' : of.state === 'paused' ? 'amber' : 'ink'}>
                        {of.state.toUpperCase()}
                      </Tag>
                    </div>
                    <div className="flex justify-between text-[11px] text-ink-400">
                      <span>Spent {rs(of.spent)}</span>
                      <span>Cap: {rs(of.budget)}</span>
                    </div>
                    <Meter pct={pct} color={pct > 90 ? '#DC2626' : '#F04E23'} h={5} />
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
