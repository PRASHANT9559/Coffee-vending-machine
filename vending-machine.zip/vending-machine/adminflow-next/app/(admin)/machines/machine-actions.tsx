'use client';

/* Client islands for the machine write controls. Server pages
   render them conditionally — a viewer sees the numbers but never
   the buttons (routing spec: "in-page write controls hide
   cosmetically, the route itself denies"). */

import { machineCommand, setMode, pushOta, logRefill, mountTank, demoAudit } from '@/lib/actions';
import { ActionButton } from '@/components/ui/toast';
import type { Role } from '@/lib/auth';

/** generic "write happens Rust-side, panel records the audit line" button */
export function AuditButton({ action, target, detail, who, role, children, tone = 'ghost', small = true, confirm, title }: {
  action: string; target: string; detail: string; who: string; role: Role;
  children: React.ReactNode; tone?: 'solid' | 'soft' | 'ghost' | 'danger';
  small?: boolean; confirm?: string; title?: string;
}) {
  return (
    <ActionButton small={small} tone={tone} confirm={confirm} title={title}
      run={() => demoAudit(action, target, detail, who, role)}>
      {children}
    </ActionButton>
  );
}

export function LockToggle({ machineId, locked, who, role }: {
  machineId: string; locked: boolean; who: string; role: Role;
}) {
  return (
    <ActionButton
      small
      tone={locked ? 'soft' : 'ghost'}
      run={() => machineCommand(machineId, locked ? 'unlock' : 'lock', who, role)}
      title={locked ? 'Unlock the machine' : 'Lock for refills / service'}
    >
      {locked ? '🔓 Unlock' : '🔒 Lock'}
    </ActionButton>
  );
}

export function CommandRow({ machineId, who, role }: { machineId: string; who: string; role: Role }) {
  return (
    <div className="flex flex-wrap gap-2">
      <ActionButton
        small tone="ghost"
        title="TTL 120s · publish after ack"
        run={() => machineCommand(machineId, 'reboot', who, role)}
      >
        ⏻ Reboot
      </ActionButton>
      <ActionButton
        small tone="ghost"
        title="Pulses → PWM test, no order charge"
        run={() => machineCommand(machineId, 'test_dispense', who, role)}
      >
        ☕ Test dispense
      </ActionButton>
      <ActionButton
        small tone="soft"
        title="fw 2.4.2 · deferred to the 02:00–04:00 idle window"
        run={() => pushOta(machineId, who, role)}
      >
        ↑ Push OTA
      </ActionButton>
    </div>
  );
}

export function ModeButtons({ machineId, mode, who, role }: {
  machineId: string; mode: 'hot' | 'cold'; who: string; role: Role;
}) {
  return (
    <div className="grid grid-cols-2 gap-2">
      <ActionButton
        small tone={mode === 'hot' ? 'solid' : 'ghost'}
        title="Hot mode · 65°C hold"
        run={() => setMode(machineId, 'hot', who, role)}
      >
        🔥 Hot 65°C
      </ActionButton>
      <ActionButton
        small tone={mode === 'cold' ? 'solid' : 'ghost'}
        title="Cold mode · 6°C hold"
        run={() => setMode(machineId, 'cold', who, role)}
      >
        ❄️ Cold 6°C
      </ActionButton>
    </div>
  );
}

export function TempControl({ machineId, target, who, role }: {
  machineId: string; target: number; who: string; role: Role;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <ActionButton
        small tone="ghost"
        title="lower target by 5"
        run={() => machineCommand(machineId, 'set_target_temp', who, role)}
      >
        −5°
      </ActionButton>
      <span className="font-mono text-[14px] font-bold tabular-nums">{target}°C</span>
      <ActionButton
        small tone="ghost"
        title="raise target by 5"
        run={() => machineCommand(machineId, 'set_target_temp', who, role)}
      >
        +5°
      </ActionButton>
    </div>
  );
}

export function RefillButton({ machineId, variant, qty, who, role }: {
  machineId: string; variant: string; qty: number; who: string; role: Role;
}) {
  return (
    <ActionButton
      small tone="soft"
      title="Appends to the refill log + reorder bar"
      run={() => logRefill(machineId, variant, qty, who, role)}
    >
      Log refill
    </ActionButton>
  );
}

export function MountTankButton({ machineId, who, role }: {
  machineId: string; who: string; role: Role;
}) {
  return (
    <ActionButton
      small
      title="20L sealed tank · FSSAI bundle attached"
      run={async () => {
        const uid = `TNK-${machineId === 'a1b2c3d4-0001-4000-8000-000000000001' ? 'A29' : 'B10'}${(Date.now() % 90 + 10)}`;
        return mountTank(machineId, uid, who, role);
      }}
    >
      ⬆ Mount new tank
    </ActionButton>
  );
}
