'use client';

/* Fleet list — card grid with status/mode/city filters, sort
   switcher, "needs attention" filter and inline quick actions
   (Lock · Unlock · Reboot · Test dispense per the spec list). */

import { useMemo, useState } from 'react';
import Link from 'next/link';
import type { Machine } from '@/lib/mock/types';
import type { AdminSession } from '@/lib/auth';
import { LockToggle } from './machine-actions';
import { machineCommand } from '@/lib/actions';
import { ActionButton } from '@/components/ui/toast';
import { StatusDot, Tag } from '@/components/ui/kit';
import { Meter } from '@/components/ui/charts';
import { IconChevronDown, IconFlame, IconPlus, IconSnow, IconWrench } from '@/components/ui/icons';

interface LowRow { machineId: string; machine: string; variant: string; qty: number; threshold: number }

const SORTS = ['Last seen', 'Temperature', 'Stock level'] as const;

export default function MachinesBrowser({ admin, machines, low, canOps }: {
  admin: AdminSession;
  machines: Machine[];
  low: LowRow[];
  canOps: boolean;
}) {
  const [status, setStatus] = useState('');      // '', 'online', 'locked'
  const [mode, setMode] = useState('');          // '', 'hot', 'cold'
  const [city, setCity] = useState('');
  const [attention, setAttention] = useState(false);
  const [sort, setSort] = useState<typeof SORTS[number]>('Last seen');

  const rows = useMemo(() => {
    let out = [...machines];
    if (status === 'online') out = out.filter(m => m.online);
    if (status === 'locked') out = out.filter(m => m.locked);
    if (mode) out = out.filter(m => m.mode === mode);
    if (city) out = out.filter(m => m.city === city);
    if (attention) out = out.filter(m => m.faults.some(f => !f.resolved) || low.some(l => l.machineId === m.id));
    out.sort((a, b) => {
      if (sort === 'Temperature') return b.tempC - a.tempC;
      if (sort === 'Stock level') return (a.kits + a.cups) - (b.kits + b.cups);
      return a.lastSeenMin - b.lastSeenMin;
    });
    return out;
  }, [machines, status, mode, city, attention, sort, low]);

  const sel = 'text-[12px] bg-white border border-line rounded-lg px-2.5 py-2 outline-none focus:border-brand-400 transition';

  return (
    <div>
      {/* filter bar */}
      <div className="card p-3 mb-4 flex flex-wrap items-center gap-2">
        <select value={status} onChange={e => setStatus(e.target.value)} className={sel}>
          <option value="">Status · all</option>
          <option value="online">Online</option>
          <option value="locked">Locked</option>
        </select>
        <select value={mode} onChange={e => setMode(e.target.value)} className={sel}>
          <option value="">Mode · all</option>
          <option value="hot">Hot</option>
          <option value="cold">Cold</option>
        </select>
        <select value={city} onChange={e => setCity(e.target.value)} className={sel}>
          <option value="">City · all</option>
          {[...new Set(machines.map(m => m.city))].map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button
          onClick={() => setAttention(a => !a)}
          className={`text-[12px] font-semibold rounded-lg px-3 py-2 border transition ${
            attention ? 'bg-red-50 border-red-200 text-red-600' : 'bg-white border-line text-ink-700 hover:bg-page'
          }`}
        >
          ⚠ Needs attention only
        </button>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-[11px] text-ink-400 font-semibold">Sort</span>
          <div className="relative">
            <select value={sort} onChange={e => setSort(e.target.value as typeof SORTS[number])} className={`${sel} pr-7 appearance-none`}>
              {SORTS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <IconChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-ink-400 pointer-events-none" />
          </div>
          {canOps && (
            <ActionButton small tone="soft" run={async () => ({ ok: true, message: 'Onboarding wizard (demo): scan pair-code, WiFi handoff, placement survey.' })} title="Demo wizard — real one lives in the backend">
              <IconPlus className="w-3.5 h-3.5" /> Add machine
            </ActionButton>
          )}
        </div>
      </div>

      {/* card grid */}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {rows.map(m => <MachineCard key={m.id} m={m} admin={admin} canOps={canOps} low={low.filter(l => l.machineId === m.id)} />)}
        {rows.length === 0 && (
          <p className="col-span-full text-center text-[13px] text-ink-400 py-12 card">No machine matches those filters.</p>
        )}
      </div>
    </div>
  );
}

function MachineCard({ m, admin, canOps, low }: {
  m: Machine; admin: AdminSession; canOps: boolean; low: LowRow[];
}) {
  const fault = m.faults.find(f => !f.resolved);
  const stockPct = Math.min(100, Math.round(((m.kits / 25) * 100)));
  const lowRows = low.map(l => `${l.variant} ${l.qty}/${l.threshold}`);

  return (
    <section className="card p-5 flex flex-col gap-3 relative overflow-hidden">
      {fault && (
        <div
          className={`absolute inset-x-0 top-0 text-[10.5px] font-semibold px-4 py-1.5 flex items-center gap-1.5 ${
            fault.critical ? 'bg-red-50 text-red-600' : 'bg-amber2-50 text-amber2-600'
          }`}
        >
          <IconWrench className="w-3.5 h-3.5" /> Unresolved fault {fault.code} · {fault.label}
          <Link href={`/machines/${m.id}/overview`} className="ml-auto underline">open →</Link>
        </div>
      )}

      <header className={`flex items-start gap-3 ${fault ? 'mt-3' : ''}`}>
        <span className="w-10 h-10 rounded-xl bg-brand-500 text-white flex items-center justify-center shrink-0">
          {m.mode === 'cold' ? <IconSnow className="w-5 h-5" /> : <IconFlame className="w-5 h-5" />}
        </span>
        <div className="min-w-0 flex-1">
          <Link href={`/machines/${m.id}/overview`} className="block text-[15px] font-bold hover:underline leading-tight">
            {m.name}
          </Link>
          <p className="text-[11px] text-ink-500 mt-0.5 font-mono">{m.code} · {m.venue}</p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <span className="flex items-center gap-1.5 text-[11px] font-semibold text-leaf-600">
            <StatusDot ok={m.online} title={m.online ? `online · ${m.lastSeenLabel}` : 'offline'} />
            {m.online ? 'online' : 'offline'}
          </span>
          <Tag tone={m.mode === 'cold' ? 'blue' : 'red'}>{m.mode.toUpperCase()} {m.tempC}°</Tag>
        </div>
      </header>

      {/* numbers — same live tile vocabulary the overview tab uses */}
      <div className="grid grid-cols-4 gap-2 text-center">
        <Metric k="Milk" v={`${Math.round(m.litres)}L`} />
        <Metric k="Cups" v={m.cups} />
        <Metric k="Kits" v={m.kits} />
        <Metric k="Signal" v={`${m.signalDbm} dbm`} />
      </div>

      <div>
        <div className="flex justify-between items-baseline mb-1">
          <span className="text-[10.5px] font-semibold uppercase tracking-wider text-ink-400">Kit stock</span>
          <span className={`text-[11px] font-bold ${lowRows.length ? 'text-red-600' : 'text-leaf-600'}`}>
            {lowRows.length ? `low · ${lowRows[0]}` : 'healthy'}
          </span>
        </div>
        <Meter pct={stockPct} color={stockPct < 40 ? '#DC2626' : '#16A34A'} />
      </div>

      <p className="text-[11px] text-ink-400">
        last seen {m.lastSeenLabel} · fw {m.firmware.replace('fw ', '')} {m.fwSha} · boots {m.bootCount.toLocaleString('en-IN')}
      </p>

      {/* inline quick actions */}
      <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-line">
        {canOps ? (
          <>
            <LockToggle machineId={m.id} locked={m.locked} who={admin.name} role={admin.role} />
            <ActionButton small tone="ghost" run={() => machineCommand(m.id, 'reboot', admin.name, admin.role)} title="TTL 120s">
              ⏻ Reboot
            </ActionButton>
            <ActionButton small tone="ghost" run={() => machineCommand(m.id, 'test_dispense', admin.name, admin.role)} title="test pour — no charge">
              ☕ Test
            </ActionButton>
          </>
        ) : (
          <span className="text-[11px] text-ink-400 italic">read-only session — write needs Ops+</span>
        )}
        <Link href={`/machines/${m.id}/overview`} className="ml-auto text-[12px] font-semibold text-brand-600 hover:underline">
          Detail →
        </Link>
      </div>
    </section>
  );
}

function Metric({ k, v }: { k: string; v: string | number }) {
  return (
    <div className="rounded-lg bg-page border border-line py-2">
      <p className="text-[13px] font-bold leading-none">{v}</p>
      <p className="text-[9.5px] text-ink-400 font-semibold uppercase tracking-wider mt-1">{k}</p>
    </div>
  );
}
