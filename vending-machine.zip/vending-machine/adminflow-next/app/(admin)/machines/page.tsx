import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView } from '@/components/ui/kit';
import { getMachines, getLowStock } from '@/lib/live';
import MachinesBrowser from './machines-browser';

/* ② Machines · fleet list — /machines (10 routes deep).
   Card grid, not a table (few units, high info density). */

export default async function MachinesPage() {
  const g = await requireCap('/machines');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/machines" />;

  const machines = await getMachines();
  const low = await getLowStock();
  const canOps = roleCan(g.admin.role, 'machines');

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto">
      <PageHead
        module="② Machines"
        title="Fleet"
        sub="Two live machines, one fabric. Every card deep-links into the nine-tab detail shell — filters and scroll state survive each hop."
        actions={<span className="text-[11.5px] text-ink-400 font-semibold">/machines · 10 routes</span>}
      />
      <MachinesBrowser admin={g.admin} machines={machines} low={low} canOps={canOps} />
    </div>
  );
}
