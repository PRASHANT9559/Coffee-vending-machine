import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { camerasFor } from '@/lib/mock/fleet';
import { Meter } from '@/components/ui/charts';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconVideo, IconRefresh } from '@/components/ui/icons';

export default async function MachineCamerasPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/cameras`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/cameras`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;

  const cameras = camerasFor(id);
  const canCctv = roleCan(g.admin.role, 'cctv');
  const admin = g.admin;

  return (
    <>
      <PageHead
        module={`${m.code} · Cameras`}
        title="Surveillance & Video Verification"
        sub="Dual channel internal dispense and front customer cameras. Used for 1-minute dispute resolution and anti-fraud verification."
        actions={
          canCctv && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => demoAudit('camera.extract_clip', m.code, 'requested 30s dual clip', admin.name, admin.role)}
                tone="primary"
              >
                <IconVideo className="w-4 h-4" /> Request Dual 30s Clip
              </ActionButton>
              <ActionButton
                run={async () => demoAudit('camera.restart_stream', m.code, 'RTSP stream service restarted', admin.name, admin.role)}
              >
                <IconRefresh className="w-4 h-4" /> Restart RTSP Stream
              </ActionButton>
            </div>
          )
        }
      />

      <div className="grid lg:grid-cols-2 gap-6">
        {cameras.map(cam => (
          <Card key={cam.channel} title={cam.label} sub={`Channel 0${cam.channel} · 1080p 15fps H.265`} className="space-y-4">
            {/* Live frame preview placeholder */}
            <div className="relative aspect-video rounded-xl bg-ink-900 border border-line overflow-hidden flex flex-col items-center justify-center text-white">
              <div className="absolute top-3 left-3 flex items-center gap-2 z-10">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
                <span className="text-[10px] font-mono tracking-wider font-semibold uppercase bg-ink-900/80 px-2 py-0.5 rounded">
                  LIVE CH-{cam.channel}
                </span>
              </div>
              <div className="absolute top-3 right-3 text-[10px] font-mono text-ink-300 bg-ink-900/80 px-2 py-0.5 rounded">
                Updated {cam.lastFrameSec}s ago
              </div>

              <IconVideo className="w-12 h-12 text-ink-700 mb-2 opacity-50" />
              <p className="text-[12px] text-ink-400 font-mono">Stream Active · Buffer Synchronized</p>
              <p className="text-[10px] text-ink-500 mt-1">Clock sync: ±20ms against flow meter pulse train</p>

              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[11px] bg-ink-900/90 backdrop-blur-sm p-2 rounded-lg border border-white/10">
                <span className="text-ink-300">Local Loop: 7-day FIFO</span>
                <span className="text-leaf-400 font-medium">Auto-purge active</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <div className="flex justify-between text-[12px]">
                <span className="text-ink-500">SD Card Free Space</span>
                <span className="font-semibold">{cam.sdFreePct}% Available</span>
              </div>
              <Meter pct={cam.sdFreePct} color={cam.sdFreePct < 15 ? '#DC2626' : '#16A34A'} h={6} />
            </div>

            <div className="pt-2 border-t border-line">
              <KV k="Retention Window" v={`${cam.retentionDays} Days rolling`} />
              <KV k="Latest Frame Time" v={`${cam.lastFrameSec}s ago`} />
              <KV k="Bitrate / Codec" v="1.2 Mbps · H.265 / AAC" mono />
            </div>

            {canCctv && (
              <div className="flex justify-end gap-2 pt-2">
                <ActionButton
                  small
                  run={async () => demoAudit('camera.sd_wipe', `${m.code} · CH${cam.channel}`, 'SD storage loop wiped', admin.name, admin.role)}
                  confirm="Wipe this camera's SD loop buffer? Historical offline clips prior to today will be erased."
                  tone="danger"
                >
                  Wipe SD Storage
                </ActionButton>
              </div>
            )}
          </Card>
        ))}
      </div>

      <div className="mt-6">
        <Card title="CCTV Evidence Policy & GDPR/FSSAI Compliance" sub="Rules governing camera recordings">
          <div className="grid md:grid-cols-3 gap-4 text-[12.5px] text-ink-600">
            <div className="p-3 bg-page rounded-xl border border-line">
              <p className="font-bold text-ink-900 mb-1">7-Day Local Retention</p>
              <p className="text-[11.5px] leading-relaxed">
                Footage stays exclusively on machine flash memory and is overwritten automatically unless extracted for a disputed ticket.
              </p>
            </div>
            <div className="p-3 bg-page rounded-xl border border-line">
              <p className="font-bold text-ink-900 mb-1">Single-Bundle Rule</p>
              <p className="text-[11.5px] leading-relaxed">
                When a support ticket is filed, a 30s clip is permanently bound to the ticket evidence bundle in Supabase object storage.
              </p>
            </div>
            <div className="p-3 bg-page rounded-xl border border-line">
              <p className="font-bold text-ink-900 mb-1">Auto-Purge After Resolution</p>
              <p className="text-[11.5px] leading-relaxed">
                Extracted evidence clips are automatically purged 7 days after ticket closure to minimize privacy exposure.
              </p>
            </div>
          </div>
          <FootNote>
            Internal dispense camera angle is focused on the cup platform and nozzle exclusively; front camera captures pickup interaction.
          </FootNote>
        </Card>
      </div>
    </>
  );
}
