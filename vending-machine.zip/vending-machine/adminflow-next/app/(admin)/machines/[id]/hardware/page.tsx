import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote, StatusDot } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { ActionButton } from '@/components/ui/toast';
import { pushOta, demoAudit } from '@/lib/actions';
import { IconShield, IconRefresh } from '@/components/ui/icons';

export default async function MachineHardwarePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/hardware`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/hardware`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;

  const isOwner = roleCan(g.admin.role, 'hardware');
  const admin = g.admin;

  return (
    <>
      <PageHead
        module={`${m.code} · Hardware`}
        title="Microcontroller & Firmware"
        sub="ESP32-S3 firmware, cryptographic checksums, hardware watchdog counters, and sensor diagnostics."
        actions={
          isOwner && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => pushOta(m.id, admin.name, admin.role)}
                tone="primary"
                confirm="Schedule OTA firmware push for the upcoming 02:00-04:00 maintenance window?"
              >
                <IconRefresh className="w-4 h-4" /> Push OTA Update
              </ActionButton>
              <ActionButton
                run={async () => demoAudit('machine.rollback', m.code, 'firmware rollback to fw 2.3.9 queued', admin.name, admin.role)}
                tone="danger"
                confirm="Rollback to previous stable firmware release fw 2.3.9?"
              >
                Rollback Firmware
              </ActionButton>
            </div>
          )
        }
      />

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <Card title="Firmware Diagnostics" sub="ESP32-S3 dual-core 240MHz · SIM7600 4G LTE modem">
            <KV k="Firmware version" v={<span className="font-mono text-brand-600 font-bold">{m.firmware}</span>} />
            <KV k="SHA-256 Checksum" v={<span className="font-mono text-[11px]">{m.fwSha}…b7e190</span>} />
            <KV k="Boot Cycle Count" v={m.bootCount.toLocaleString()} />
            <KV k="Watchdog Timer (WDT) Resets" v={<span className={m.wdtResets > 5 ? 'text-red-600 font-bold' : ''}>{m.wdtResets} (30d)</span>} />
            <KV k="OTA Partition Table" v="Dual ota_0 / ota_1 fail-safe fallback" />
            <KV k="Secure Boot Status" v={<Tag tone="leaf">ACTIVE · RSA-3072</Tag>} />
            <KV k="Flash Encryption" v={<Tag tone="leaf">AES-256-XTS</Tag>} />
          </Card>

          <Card title="Telemetry Uplink & Signal" sub="MQTTS TLS 1.3 over port 8883">
            <KV k="Modem Model" v="SIMCOM SIM7600E-H1C" />
            <KV k="Cellular Signal Strength" v={`${m.signalDbm} dBm (RSRP)`} />
            <KV k="Packet Cadence" v="30 seconds heartbeat" />
            <KV k="Last Seen Heartbeat" v={m.lastSeenLabel} />
            <KV k="Offline Sync Buffer" v="Local SPIFFS Flash (holds ~4,000 dispenses)" />
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Sensor Health Matrix" sub="Real-time peripheral loop diagnostics">
            <div className="divide-y divide-line">
              {m.sensors.map((s, i) => (
                <div key={i} className="py-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <StatusDot ok={s.ok} />
                    <span className="text-[13px] font-medium text-ink-800">{s.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {s.note && <span className="text-[11px] text-ink-400 italic">{s.note}</span>}
                    <Tag tone={s.ok ? 'leaf' : 'amber'}>{s.ok ? 'ONLINE' : 'ATTENTION'}</Tag>
                  </div>
                </div>
              ))}
            </div>
            <FootNote>
              Sensor drift exceeding ±5% on flow rate or ±1.5°C on dairy thermal bounds raises an automated P2 ticket.
            </FootNote>
          </Card>

          {isOwner && (
            <Card title="Danger Zone" sub="Superadmin maintenance commands">
              <div className="p-3.5 border border-red-200 bg-red-50/50 rounded-xl space-y-3">
                <div className="flex items-start gap-3">
                  <IconShield className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-[13px] font-bold text-red-900">Factory Diagnostic Reset</p>
                    <p className="text-[11.5px] text-red-700 mt-0.5 leading-relaxed">
                      Wipes NVS runtime configuration and recalibrates pump flow and valve step timings to factory defaults.
                    </p>
                  </div>
                </div>
                <div className="pt-2 flex justify-end">
                  <ActionButton
                    small
                    tone="danger"
                    run={async () => demoAudit('machine.factory_reset', m.code, 'factory diagnostic reset queued', admin.name, admin.role)}
                    confirm="Are you sure you want to trigger a factory reset? The machine will reboot into diagnostic mode."
                  >
                    Factory Reset Peripheral Board
                  </ActionButton>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
