import Link from 'next/link';
import type { Machine } from '@/lib/mock/types';
import { StatusDot, Tag } from '@/components/ui/kit';
import { IconChevronDown, IconFlame, IconSnow } from '@/components/ui/icons';

/* Detail header — breadcrumbs, identity, live status chips.
   Quick actions slot in from the layout only for Ops+. */

export default function MachineHeader({ m, canWrite, children }: {
  m: Machine; canWrite: boolean; children?: React.ReactNode;
}) {
  return (
    <div className="card p-5">
      <nav className="flex items-center gap-1.5 text-[11.5px] text-ink-400 font-medium mb-3">
        <Link href="/machines" className="hover:text-brand-600 transition">Machines</Link>
        <IconChevronDown className="w-3 h-3 rotate-[-90deg]" />
        <span className="font-mono text-ink-700">{m.code}</span>
      </nav>

      <div className="flex flex-wrap items-start gap-4">
        <span className="w-12 h-12 rounded-xl bg-brand-500 text-white flex items-center justify-center shrink-0">
          {m.mode === 'cold' ? <IconSnow className="w-6 h-6" /> : <IconFlame className="w-6 h-6" />}
        </span>

        <div className="min-w-0 flex-1">
          <h1 className="text-[22px] font-bold tracking-tight leading-tight">{m.name}</h1>
          <p className="text-[12px] text-ink-500 mt-1">
            <span className="font-mono">{m.code}</span> · {m.venue} · {m.city} · fw {m.firmware.replace('fw ', '')}{' '}
            <span className="font-mono text-ink-400">{m.fwSha}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-1.5 text-[11.5px] font-semibold text-leaf-600 bg-leaf-50 border border-leaf-100 rounded-lg px-2.5 py-1.5">
            <StatusDot ok={m.online} title={`last seen ${m.lastSeenLabel}`} />
            {m.online ? `online · ${m.lastSeenLabel}` : 'offline'}
          </span>
          <Tag tone={m.mode === 'cold' ? 'blue' : 'red'}>{m.mode.toUpperCase()} · {m.tempC}°→{m.targetTemp}°</Tag>
          <Tag tone={m.locked ? 'red' : 'leaf'}>{m.locked ? '🔒 locked' : 'unlocked'}</Tag>
          <Tag tone={m.mode === 'cold' ? 'blue' : 'brand'}>{m.signalDbm} dBm</Tag>
        </div>

        {children /* quick actions island */}
        {!canWrite && <span className="text-[11px] italic text-ink-400 self-center">read-only for Viewer — controls need Ops+</span>}
      </div>
    </div>
  );
}
