import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { MAINTENANCE, REFILL_ESTIMATOR } from '@/lib/mock/fleet';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit } from '@/lib/actions';
import { IconWrench, IconClock } from '@/components/ui/icons';

export default async function MachineMaintenancePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/maintenance`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/maintenance`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;

  const logs = MAINTENANCE.filter(l => l.machine === m.code);
  const est = REFILL_ESTIMATOR.find(e => e.machineId === id);
  const canOps = roleCan(g.admin.role, 'machines');
  const admin = g.admin;

  return (
    <>
      <PageHead
        module={`${m.code} · Maintenance`}
        title="Field Service & Maintenance"
        sub="Technician visit logs, scheduled preventative maintenance, nozzle descaling, CIP sanitation, and refill burn estimator."
        actions={
          canOps && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => demoAudit('maintenance.log_task', m.code, 'logged quick CIP flush task', admin.name, admin.role)}
                tone="primary"
              >
                <IconWrench className="w-4 h-4" /> Log Service Task
              </ActionButton>
              <ActionButton
                run={async () => demoAudit('maintenance.schedule_visit', m.code, 'scheduled preventative field technician visit', admin.name, admin.role)}
              >
                Schedule Visit
              </ActionButton>
            </div>
          )
        }
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card title="Service Task Timeline" sub="Chronological technician task logs (machine_maintenance_logs)">
            <div className="space-y-4 mt-2">
              {logs.map((log, i) => (
                <div key={i} className="p-4 rounded-xl border border-line bg-page/40">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-[14px] text-ink-900">{log.task}</h4>
                      <p className="text-[12px] text-ink-600 mt-1">{log.notes}</p>
                    </div>
                    <Tag tone="leaf">COMPLETED</Tag>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-ink-400 mt-3 pt-2 border-t border-line/60">
                    <span className="font-medium text-ink-700">Technician: {log.tech}</span>
                    <span className="flex items-center gap-1 font-mono">
                      <IconClock className="w-3.5 h-3.5" />
                      Duration: {log.mins} mins
                    </span>
                    <span className="font-mono">{log.tsLabel}</span>
                  </div>
                </div>
              ))}
              {logs.length === 0 && (
                <p className="text-center py-8 text-ink-400 text-[12.5px]">
                  No maintenance visits recorded for this machine.
                </p>
              )}
            </div>
            <FootNote>
              CIP (Clean-in-Place) hot water flush must be performed within 2 hours of every dairy tank mount.
            </FootNote>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Refill Burn Estimator" sub="Predictive depletion forecast">
            <div className="p-4 bg-brand-50 border border-brand-200 rounded-xl space-y-3">
              <p className="text-[13px] font-bold text-brand-900">
                Next Refill Window: ~{est?.hoursAhead ?? 2} Hours
              </p>
              <p className="text-[12px] text-brand-700 leading-relaxed">
                Based on the trailing 24h order velocity of <span className="font-semibold">{est?.burnOrderIdPerH ?? 10} cups/hr</span>,
                this unit will require approx <span className="font-semibold">15 Litres milk</span> and <span className="font-semibold">50 cups</span> before the afternoon peak.
              </p>
              <div className="pt-1 text-[11px] font-mono text-brand-600">
                Confidence: 94% (Historical Campus Model)
              </div>
            </div>

            <div className="mt-4 pt-2">
              <KV k="Burn rate" v={`${est?.burnOrderIdPerH ?? 10} orders / hr`} />
              <KV k="Milk per dispense" v={`${Math.round((est?.litresPerOrder ?? 0.24) * 1000)} ml`} />
              <KV k="Average cup pickup time" v="14 seconds" />
            </div>
          </Card>

          <Card title="Scheduled Tasks" sub="Upcoming maintenance checklist">
            <div className="space-y-2.5 text-[12px]">
              <div className="p-3 border border-line rounded-lg bg-page">
                <p className="font-semibold text-ink-800">Bi-weekly Nozzle Descaling</p>
                <p className="text-[11px] text-ink-400 mt-0.5">Due in 3 days · Field Tech: Ravi Kadam</p>
              </div>
              <div className="p-3 border border-line rounded-lg bg-page">
                <p className="font-semibold text-ink-800">SIM Modem Antenna Check</p>
                <p className="text-[11px] text-ink-400 mt-0.5">Scheduled for next routine refill route</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
