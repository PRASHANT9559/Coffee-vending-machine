'use client';

/* Header quick actions (Lock · Reboot · Test dispense) — same
   endpoints the Rust service exposes; demo writes go through the
   in-memory store so the audit trail records every hop. */

import { machineCommand } from '@/lib/actions';
import { ActionButton } from '@/components/ui/toast';
import type { Role } from '@/lib/auth';

export default function QuickIsland({ machineId, locked, who, role }: {
  machineId: string; locked: boolean; who?: string; role?: Role;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      <ActionButton
        small tone={locked ? 'soft' : 'ghost'}
        run={() => machineCommand(machineId, locked ? 'unlock' : 'lock', who ?? '—', role ?? 'viewer')}
        title={locked ? 'Unlock machine' : 'Lock for refill / service'}
      >
        {locked ? '🔓 Unlock' : '🔒 Lock'}
      </ActionButton>
      <ActionButton
        small tone="ghost"
        run={() => machineCommand(machineId, 'reboot', who ?? '—', role ?? 'viewer')}
        title="TTL 120s · publish after ack"
      >
        ⏻ Reboot
      </ActionButton>
      <ActionButton
        small tone="ghost"
        run={() => machineCommand(machineId, 'test_dispense', who ?? '—', role ?? 'viewer')}
        title="test pour — no order charge"
      >
        ☕ Test dispense
      </ActionButton>
    </div>
  );
}
