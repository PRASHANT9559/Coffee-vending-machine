import { getAdmin, roleCan } from '@/lib/auth';
import { getMachine } from '@/lib/live';
import { notFound } from 'next/navigation';
import MachineHeader from './machine-header';
import TabNav from './tab-nav';
import QuickIsland from './quick-island';

/* Machine detail shell — the header + nine-tab nav persist across
   all 9 child routes so switching tabs never remounts the shell.
   Guarding happens per tab route (guards deny, never hide:
   a viewer gets 403 content but keeps the shell chrome). */

export default async function MachineLayout({ children, params }: {
  children: React.ReactNode;
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const detail = await getMachine(id);
  if (!detail) notFound();
  const m = detail.machine;

  const admin = await getAdmin();
  const canWrite = admin ? roleCan(admin.role, 'machines') : false;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto">
      <MachineHeader m={m} canWrite={canWrite}>
        {canWrite && <QuickIsland machineId={m.id} locked={m.locked} who={admin?.name} role={admin?.role} />}
      </MachineHeader>
      <TabNav id={m.id} />
      <div className="mt-5">{children}</div>
    </div>
  );
}
