import { redirect } from 'next/navigation';

/* /machines/:id resolves to the live-tile overview tab. */

export default async function MachineIndex({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  redirect(`/machines/${id}/overview`);
}
