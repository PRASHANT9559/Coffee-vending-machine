import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { listCommands } from '@/lib/mock/store';
import { backendApi } from '@/lib/backend-client';
import { ActionButton } from '@/components/ui/toast';
import { machineCommand, demoAudit } from '@/lib/actions';
import { IconClock } from '@/components/ui/icons';

export default async function MachineCommandsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/commands`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/commands`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;

  let commands: {
    id: string;
    cmd: string;
    status: string;
    by: string;
    atLabel: string;
    ttlS: number;
    result?: string;
  }[] = [];

  try {
    const res = await backendApi.listMachineCommands(id);
    if (res.success && res.data?.commands) {
      commands = res.data.commands.map(c => ({
        id: c.id,
        cmd: c.command_type,
        status: c.status === 'success' ? 'done' : c.status,
        by: c.requested_by ? `Admin (${c.requested_by.slice(0, 8)})` : 'System',
        atLabel: new Date(c.requested_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        ttlS: c.expires_at ? Math.max(0, Math.floor((new Date(c.expires_at).getTime() - Date.now()) / 1000)) : 0,
        result: typeof c.result === 'object' ? JSON.stringify(c.result) : (c.result ?? '—'),
      }));
    }
  } catch {
    // Rust backend offline fallback
  }

  if (
    commands.length === 0
    && process.env.DEMO_MODE === '1'
    && process.env.NODE_ENV !== 'production'
  ) {
    commands = listCommands().filter(c => c.machineId === id);
  }

  const canOps = roleCan(g.admin.role, 'machines');
  const admin = g.admin;

  return (
    <>
      <PageHead
        module={`${m.code} · Commands`}
        title="Remote Command Audit"
        sub="MQTTS command dispatch history, delivery acknowledgements, device response payloads, and TTL countdown."
        actions={
          canOps && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => machineCommand(m.id, 'ping', admin.name, admin.role)}
              >
                Send Ping Check
              </ActionButton>
            </div>
          )
        }
      />

      <Card title="Command Execution Log" sub="machine_commands table — ordered by descending timestamp">
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="border-b border-line text-ink-400 text-[10px] uppercase tracking-wider font-semibold">
                <th className="py-2.5 px-3 text-left">Command</th>
                <th className="py-2.5 px-3 text-left">Status</th>
                <th className="py-2.5 px-3 text-left">Requested By</th>
                <th className="py-2.5 px-3 text-left">Timestamp</th>
                <th className="py-2.5 px-3 text-left">TTL</th>
                <th className="py-2.5 px-3 text-left">Result JSON</th>
                {canOps && <th className="py-2.5 px-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60">
              {commands.map((cmd) => {
                const tone =
                  cmd.status === 'done' ? 'leaf' :
                  cmd.status === 'queued' ? 'amber' :
                  cmd.status === 'sent' ? 'blue' : 'red';

                return (
                  <tr key={cmd.id} className="hover:bg-page/60 transition-colors">
                    <td className="py-3 px-3 font-mono font-semibold text-brand-600">
                      {cmd.cmd}
                    </td>
                    <td className="py-3 px-3">
                      <Tag tone={tone}>{cmd.status.toUpperCase()}</Tag>
                    </td>
                    <td className="py-3 px-3 text-ink-700">
                      {cmd.by}
                    </td>
                    <td className="py-3 px-3 text-ink-500 font-mono text-[11.5px]">
                      {cmd.atLabel}
                    </td>
                    <td className="py-3 px-3">
                      <span className="inline-flex items-center gap-1 text-[11px] font-mono text-ink-500">
                        <IconClock className="w-3.5 h-3.5" />
                        {cmd.ttlS > 0 ? `${cmd.ttlS}s` : 'Expired'}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <code className="text-[11px] font-mono bg-page px-2 py-1 rounded border border-line text-ink-600 block max-w-[260px] truncate">
                        {cmd.result ?? '—'}
                      </code>
                    </td>
                    {canOps && (
                      <td className="py-3 px-3 text-right">
                        <div className="inline-flex gap-1.5">
                          {cmd.status === 'queued' ? (
                            <ActionButton
                              small
                              tone="danger"
                              run={async () => demoAudit('command.cancel', cmd.id, 'cancelled queued command', admin.name, admin.role)}
                            >
                              Cancel
                            </ActionButton>
                          ) : (
                            <ActionButton
                              small
                              run={async () => machineCommand(m.id, cmd.cmd, admin.name, admin.role)}
                            >
                              Re-issue
                            </ActionButton>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
              {commands.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-ink-400">
                    No commands issued for this machine yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <FootNote>
          Commands carry a 2-minute hard TTL. If an ESP32 microcontroller drops offline, queued commands expire automatically to prevent stale state changes on reconnection.
        </FootNote>
      </Card>
    </>
  );
}
