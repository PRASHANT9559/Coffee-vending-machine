import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { stockFor, seedCommands } from '@/lib/mock/fleet';
import { Meter, Gauge } from '@/components/ui/charts';
import { ModeButtons, CommandRow, LockToggle } from '../../machine-actions';
import { IconArrowRight } from '@/components/ui/icons';

/* ② /machines/:id/overview — big live tile, temp gauge, milk bar,
   cup/kit counters, signal dBm, mode switch, lock toggle.
   Source: machine_telemetry (latest) + machines. */

export default async function MachineOverview({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/overview`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/overview`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null; // layout 404s first
  const canOps = roleCan(g.admin.role, 'machines');

  const faults = m.faults.filter(f => !f.resolved);
  const { low } = stockFor(m.id);
  const cmd = seedCommands().filter(c => c.machineId === m.id).slice(0, 3);

  return (
    <>
      <PageHead
        module={`${m.code} · Overview`}
        title="Live tile"
        sub="machine_telemetry (latest) + machines row — values mirror what the board uploads every heartbeat."
        actions={<span className="text-[11.5px] text-ink-400 font-semibold">runtime · last heartbeat {m.lastSeenLabel}</span>}
      />

      {/* fault banner → deep-links to hardware */}
      {faults.map(f => (
        <div key={f.code} className={`card p-0 mb-4 overflow-hidden ${f.critical ? 'border-red-200' : ''}`}>
          <div className={`flex flex-wrap items-center gap-3 px-5 py-3.5 ${f.critical ? 'bg-red-50' : 'bg-amber2-50'}`}>
            <Tag tone={f.critical ? 'red' : 'amber'}>{f.critical ? 'CRITICAL' : 'FAULT'} · {f.code}</Tag>
            <p className={`text-[13px] font-semibold ${f.critical ? 'text-red-600' : 'text-amber2-600'}`}>{f.label}</p>
            <span className="text-[11px] text-ink-500">since {f.atLabel}</span>
            <Link href={`/machines/${m.id}/commands`} className="ml-auto text-[12px] font-semibold text-brand-600 hover:underline">
              Send corrective command <IconArrowRight className="w-3.5 h-3.5 inline" />
            </Link>
          </div>
        </div>
      ))}

      <div className="grid lg:grid-cols-3 gap-4">
        {/* live tile */}
        <Card title="State" sub={`poured at ${m.mode} hold`} className="lg:col-span-2">
          <div className="flex flex-wrap items-center gap-6">
            <Gauge value={m.tempC} min={0} max={m.mode === 'cold' ? 20 : 80} unit="°" label={m.mode === 'cold' ? 'cold hold' : 'hot hold'} color={m.mode === 'cold' ? '#2563EB' : '#F04E23'} />
            <div className="flex-1 min-w-[220px] space-y-4">
              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <span className="text-[11.5px] font-semibold text-ink-500">Milk level</span>
                  <span className="text-[12.5px] font-bold">{Math.round(m.litres)} of 40 L</span>
                </div>
                <Meter pct={(m.litres / 40) * 100} color={m.litres < 10 ? '#DC2626' : '#16A34A'} h={8} />
              </div>
              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <span className="text-[11.5px] font-semibold text-ink-500">Malai tank</span>
                  <span className="text-[12.5px] font-bold">{m.malaiL} L</span>
                </div>
                <Meter pct={(m.malaiL / 10) * 100} color="#EAB308" />
              </div>
              <div className="grid grid-cols-4 gap-2 text-center pt-1">
                <Tile v={m.cups} k="cups" />
                <Tile v={m.kits} k="kits" />
                <Tile v={`${m.signalDbm}`} k="dBm" />
                <Tile v={m.lastSeenLabel.replace(' ago', '')} k="last seen" small />
              </div>
            </div>
          </div>
          <FootNote>
            Every heartbeat writes telemetry partitions — <Link href={`/machines/${m.id}/telemetry`} className="text-brand-600 font-semibold hover:underline">history → telemetry tab</Link>.
          </FootNote>
        </Card>

        {/* write controls */}
        <div className="space-y-4">
          <Card title="Controls" sub={canOps ? 'commands publish after MQTT ack · TTL 120s' : 'read-only view for your role'}>
            <div className="space-y-3">
              {canOps ? (
                <>
                  <div>
                    <p className="text-[10.5px] font-semibold uppercase tracking-wider text-ink-400 mb-1.5">Mode</p>
                    <ModeButtons machineId={m.id} mode={m.mode === 'cold' ? 'cold' : 'hot'} who={g.admin.name} role={g.admin.role} />
                  </div>
                  <div className="pt-1 border-t border-line">
                    <p className="text-[10.5px] font-semibold uppercase tracking-wider text-ink-400 mb-2">Lock</p>
                    <LockToggle machineId={m.id} locked={m.locked} who={g.admin.name} role={g.admin.role} />
                  </div>
                </>
              ) : (
                <p className="text-[12px] text-ink-400 italic">Viewer session — mode / lock controls render for Ops and above only.</p>
              )}
              <KV k="Target temp" v={`${m.targetTemp}°C`} mono />
              <KV k="Machine id" v={m.id} mono />
              <KV k="Venue" v={m.venue} />
            </div>
          </Card>

          <Card title="Recent commands" right={<Link href={`/machines/${m.id}/commands`} className="text-[11.5px] font-semibold text-brand-600 hover:underline">all →</Link>}>
            <div className="space-y-2.5">
              {cmd.map(c => (
                <div key={c.id} className="flex items-center gap-2">
                  <Tag tone={c.status === 'done' ? 'leaf' : c.status === 'failed' || c.status === 'expired' ? 'red' : 'amber'}>{c.status}</Tag>
                  <span className="font-mono text-[11.5px] font-semibold">{c.cmd}</span>
                  <span className="ml-auto text-[10.5px] text-ink-400 whitespace-nowrap">{c.atLabel}</span>
                </div>
              ))}
            </div>
          </Card>

          {canOps && (
            <Card title="Maintenance cmds" sub="diagnostics">
              <CommandRow machineId={m.id} who={g.admin.name} role={g.admin.role} />
            </Card>
          )}

          {low.length > 0 && (
            <Card title="Reorder warnings">
              <div className="space-y-2">
                {low.map(l => (
                  <div key={l.variant} className="flex items-center gap-2 text-[12px]">
                    <Tag tone="red">{l.qty}/{l.threshold}</Tag>
                    <span>{l.variant}</span>
                    <Link href={`/machines/${m.id}/stock`} className="ml-auto text-[11.5px] font-semibold text-brand-600 hover:underline">stock →</Link>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}

function Tile({ v, k, small }: { v: string | number; k: string; small?: boolean }) {
  return (
    <div className="rounded-lg bg-page border border-line py-2">
      <p className={`${small ? 'text-[11px]' : 'text-[13.5px]'} font-bold leading-none`}>{v}</p>
      <p className="text-[9px] text-ink-400 font-semibold uppercase tracking-wider mt-1">{k}</p>
    </div>
  );
}
