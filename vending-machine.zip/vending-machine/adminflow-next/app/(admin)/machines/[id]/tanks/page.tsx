import Link from 'next/link';
import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote, Empty } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { tanksFor } from '@/lib/mock/fleet';
import { Meter } from '@/components/ui/charts';
import { MountTankButton } from '../../machine-actions';
import { ActionButton } from '@/components/ui/toast';
import { pushAudit } from '@/lib/mock/store';
import type { TankRow } from '@/lib/mock/types';
import { IconDroplet } from '@/components/ui/icons';

/* ② /machines/:id/tanks — current tank cards (uid, litres, age,
   expiry bar), mounted history, expired list, Mount Tank action.
   Source: machine_tanks + machine_tank_events. */

export default async function MachineTanks({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/tanks`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/tanks`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;
  const ops = roleCan(g.admin.role, 'machines');
  const admin = g.admin;

  const { current, events } = tanksFor(id);
  const expired = current.filter(t => t.state === 'expired');
  const live = current.filter(t => t.state !== 'expired');

  return (
    <>
      <PageHead
        module={`${m.code} · Tanks`}
        title="Tank lifecycle"
        sub="machine_tanks + machine_tank_events — every tank is RFID/QR-tagged; FSSAI hold window is 12h from fill."
        actions={ops ? <MountTankButton machineId={m.id} who={admin.name} role={admin.role} /> : (
          <span className="text-[11px] italic text-ink-400">mount needs Ops+</span>
        )}
      />

      <div className="grid lg:grid-cols-2 gap-4">
        {/* current tanks */}
        <div className="space-y-4">
          {live.map(t => <TankCard key={t.id} t={t} canOps={ops} />)}
          {live.length === 0 && <Card title="Mounted"><Empty msg="No tank mounted — mount a fresh 20L to resume service." /></Card>}

          {expired.length > 0 && (
            <Card title="Expired · needing disposal" sub="hold window exceeded — contents must be destroyed, tank sanitized">
              <div className="space-y-3">
                {expired.map(t => (
                  <div key={t.id} className="rounded-xl border border-red-200 bg-red-50/50 p-4">
                    <div className="flex items-center gap-2">
                      <Tag tone="red">EXPIRED · {t.ageH}h</Tag>
                      <span className="font-mono text-[12px] font-bold">{t.uid}</span>
                      <span className="ml-auto text-[11px] text-ink-500">{t.litres} L</span>
                    </div>
                    {ops && (
                      <div className="mt-3 flex gap-2">
                        <ActionButton
                          small tone="danger"
                          run={async () => { pushAudit(admin.name, admin.role, 'tank.dispose', { target: `${m.code} · ${t.uid}`, detail: 'contents destroyed, tank sanitized' }); return { ok: true, message: `${t.uid} marked disposed — audit trail updated.` }; }}
                          confirm={`Dispose ${t.uid} contents? This writes the FSSAI disposal record.`}
                        >
                          Mark disposed
                        </ActionButton>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>

        {/* events + compliance */}
        <div className="space-y-4">
          <Card title="Mounted history" sub="machine_tank_events (machine = this unit)">
            {events.length === 0 ? <Empty msg="No events for this machine yet." /> : (
              <ol className="relative pl-4 space-y-3.5 before:absolute before:left-[5px] before:top-2 before:bottom-2 before:w-px before:bg-line">
                {events.map((e, i) => (
                  <li key={i} className="relative">
                    <span className={`absolute -left-4 top-1 w-2.5 h-2.5 rounded-full border-2 border-white ${
                      e.action === 'disposed' ? 'bg-red-500' : e.action === 'top-up' ? 'bg-amber2-500' : 'bg-leaf-500'
                    }`} />
                    <div className="flex items-baseline gap-2 flex-wrap">
                      <span className="text-[12px] font-bold capitalize">{e.action}</span>
                      <span className="text-[10.5px] text-ink-400">{e.tsLabel}</span>
                      <span className="ml-auto text-[10.5px] text-ink-500">{e.by}</span>
                    </div>
                    <p className="text-[11.5px] text-ink-500 mt-0.5">{e.detail}</p>
                  </li>
                ))}
              </ol>
            )}
          </Card>

          <Card title="FSSAI bundle" sub="demo compliance snapshot">
            <KV k="Milk source" v="Batch M-2261 · Gowardhan Dairy" />
            <KV k="Pasteurised" v="Yes · HTST" />
            <KV k="Hold rule" v="12h hard · dispose beyond" />
            <KV k="Sanitize cycle" v="CIP after every mount" />
            <FootNote>
              Expiry math runs from <code className="p font-mono">filled_at</code>; the meter below is exactly what the mount history shows ops staff.
            </FootNote>
          </Card>
        </div>
      </div>
    </>
  );
}

function TankCard({ t, canOps }: { t: TankRow; canOps: boolean }) {
  const pct = Math.min(100, (t.ageH / t.holdH) * 100);
  const tone = t.state === 'expired' ? 'red' : t.state === 'near' ? 'amber' : 'leaf';
  return (
    <section className="card p-5">
      <div className="flex items-center gap-2 mb-1.5">
        <IconDroplet className="w-4 h-4 text-brand-500" />
        <span className="font-mono text-[13px] font-bold">{t.uid}</span>
        <Tag tone={tone}>{t.state.toUpperCase()}</Tag>
        {t.fssai && <Tag tone="leaf">FSSAI ✓</Tag>}
        <span className="ml-auto text-[12.5px] font-bold">{t.litres} L</span>
      </div>
      <div className="flex items-baseline gap-2 mb-1">
        <span className="text-[11.5px] text-ink-500">age {t.ageH}h of {t.holdH}h hold</span>
        <span className={`ml-auto text-[11px] font-semibold ${pct > 85 ? 'text-red-600' : 'text-ink-400'}`}>
          {Math.round(pct)}% of hold window
        </span>
      </div>
      <Meter pct={pct} color={pct > 85 ? '#DC2626' : pct > 60 ? '#EAB308' : '#16A34A'} h={7} />
      <p className="text-[11px] text-ink-400 mt-2">filled {t.filledLabel}</p>
    </section>
  );
}
