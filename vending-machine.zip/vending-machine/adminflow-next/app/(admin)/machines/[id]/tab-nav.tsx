'use client';

/* Nine-tab nav — the routing spec's "detail shell" navigation.
   Active tab derives from the URL; tabs never hide for role
   reasons (guards deny content, chrome stays). */

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'telemetry', label: 'Telemetry' },
  { id: 'tanks', label: 'Tanks' },
  { id: 'stock', label: 'Stock' },
  { id: 'hardware', label: 'Hardware' },
  { id: 'cameras', label: 'Cameras' },
  { id: 'commands', label: 'Commands' },
  { id: 'maintenance', label: 'Maintenance' },
  { id: 'settings', label: 'Settings' },
];

export default function TabNav({ id }: { id: string }) {
  const pathname = usePathname();
  const segs = pathname.split('/').filter(Boolean);
  const active = TABS.find(t => segs[segs.length - 1] === t.id)?.id ?? 'overview';

  return (
    <nav className="mt-5 flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1" aria-label="Machine detail tabs">
      {TABS.map(t => {
        const href = `/machines/${id}/${t.id}`;
        const on = active === t.id;
        return (
          <Link key={t.id} href={href}
            className={`tab shrink-0 text-[12.5px] font-semibold px-3.5 py-2 border transition ${
              on ? 'bg-brand-500 border-brand-500 text-white' : 'bg-white border-line text-ink-700 hover:bg-page'
            }`}
          >
            {t.label}
          </Link>
        );
      })}
    </nav>
  );
}
