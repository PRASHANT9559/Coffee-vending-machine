import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, FootNote } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { ActionButton } from '@/components/ui/toast';
import { demoAudit, setMode } from '@/lib/actions';

export default async function MachineSettingsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/settings`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/settings`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;

  const canOps = roleCan(g.admin.role, 'machines');
  const admin = g.admin;

  return (
    <>
      <PageHead
        module={`${m.code} · Settings`}
        title="Machine Configuration"
        sub="Unit-level operating parameters, thermal set-points, antenna placement notes, and fleet overrides."
        actions={
          canOps && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => demoAudit('machine.reset_defaults', m.code, 'reset parameters to fleet defaults', admin.name, admin.role)}
                confirm="Reset this machine to fleet-wide default parameters?"
              >
                Reset to Fleet Defaults
              </ActionButton>
            </div>
          )
        }
      />

      <div className="max-w-2xl space-y-6">
        <Card title="Operational Mode & Temperature Target" sub="Overrides fleet defaults for this specific unit">
          <div className="space-y-4 mt-2">
            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                Seasonal Operating Mode
              </label>
              <div className="flex gap-3">
                <ActionButton
                  run={async () => setMode(m.id, 'hot', admin.name, admin.role)}
                  tone={m.mode === 'hot' ? 'primary' : 'neutral'}
                  disabled={!canOps}
                >
                  🔥 Hot Mode (65°C Boiler)
                </ActionButton>
                <ActionButton
                  run={async () => setMode(m.id, 'cold', admin.name, admin.role)}
                  tone={m.mode === 'cold' ? 'primary' : 'neutral'}
                  disabled={!canOps}
                >
                  🧊 Cold Mode (6°C Chiller)
                </ActionButton>
              </div>
              <p className="text-[11px] text-ink-400 mt-1">
                Changing mode commands the valve controller to adjust boiler thermal set-point.
              </p>
            </div>

            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">
                Target Temperature Set-Point (°C)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  defaultValue={m.targetTemp}
                  disabled={!canOps}
                  className="w-32 bg-page border border-line rounded-lg px-3 py-2 text-[13px] font-mono font-semibold"
                />
                <span className="text-[12px] text-ink-500">
                  Current tank reading: <strong className="text-ink-800">{m.tempC}°C</strong>
                </span>
              </div>
            </div>
          </div>
        </Card>

        <Card title="Lockout & Safety Policy" sub="Defines automated emergency shutdown conditions">
          <div className="space-y-3 text-[12.5px]">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input type="checkbox" defaultChecked disabled={!canOps} className="mt-1 rounded text-brand-500" />
              <div>
                <span className="font-semibold text-ink-800">Auto-lock on Tank Expiry</span>
                <p className="text-[11.5px] text-ink-500">
                  Immediately cease dispensing when current milk tank reaches 12 hours of hold time.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-2.5 cursor-pointer">
              <input type="checkbox" defaultChecked disabled={!canOps} className="mt-1 rounded text-brand-500" />
              <div>
                <span className="font-semibold text-ink-800">Auto-lock on Door Breach</span>
                <p className="text-[11.5px] text-ink-500">
                  Lock dispensing valves if door latch sensor is triggered during non-technician hours.
                </p>
              </div>
            </label>
          </div>
        </Card>

        <Card title="Location & Installation Metadata" sub="Field technician venue notes">
          <div className="space-y-3">
            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">Machine Display Name</label>
              <input
                type="text"
                defaultValue={m.name}
                disabled={!canOps}
                className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[13px]"
              />
            </div>
            <div>
              <label className="block text-[12px] font-semibold text-ink-700 mb-1">Venue Location & Installation Notes</label>
              <textarea
                rows={3}
                defaultValue={m.venue}
                disabled={!canOps}
                className="w-full bg-page border border-line rounded-lg px-3 py-2 text-[12.5px]"
              />
            </div>
            {canOps && (
              <div className="flex justify-end pt-2">
                <ActionButton
                  run={async () => demoAudit('machine.save_settings', m.code, 'saved location & operating settings', admin.name, admin.role)}
                  tone="primary"
                >
                  Save Settings
                </ActionButton>
              </div>
            )}
          </div>
          <FootNote>
            Every save generates a cryptographic audit trail event with previous and new JSON state comparison.
          </FootNote>
        </Card>
      </div>
    </>
  );
}
