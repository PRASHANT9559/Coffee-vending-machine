import { requireCap, roleCan } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { stockFor, STOCK_EVENTS } from '@/lib/mock/fleet';
import { Meter } from '@/components/ui/charts';
import { ActionButton } from '@/components/ui/toast';
import { logRefill, demoAudit } from '@/lib/actions';
import { IconDroplet, IconCup, IconPlusCircle } from '@/components/ui/icons';

export default async function MachineStockPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const g = await requireCap(`/machines/${id}/stock`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/stock`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;

  const { rows, low } = stockFor(id);
  const ops = roleCan(g.admin.role, 'machines');
  const admin = g.admin;

  return (
    <>
      <PageHead
        module={`${m.code} · Stock`}
        title="Consumables & Inventory"
        sub="Per-variant rows, reorder thresholds, automated low-stock warnings and refill event ledger."
        actions={
          ops && (
            <div className="flex gap-2">
              <ActionButton
                run={async () => logRefill(m.id, 'All Kits & Cups', 50, admin.name, admin.role)}
                tone="primary"
              >
                <IconPlusCircle className="w-4 h-4" /> Quick Bulk Refill
              </ActionButton>
            </div>
          )
        }
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card title="Variant & Consumable Levels" sub="Real-time count vs threshold trigger level">
            <div className="space-y-4 mt-3">
              {rows.map((r, i) => {
                const isLow = r.qty <= r.threshold;
                const pct = Math.min(100, Math.round((r.qty / (r.threshold * 2.5)) * 100));
                return (
                  <div key={i} className="p-3.5 rounded-xl border border-line bg-page/40">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {r.kind === 'cups' ? (
                          <IconCup className="w-4 h-4 text-ink-500" />
                        ) : r.kind === 'malai' ? (
                          <IconDroplet className="w-4 h-4 text-brand-500" />
                        ) : (
                          <span className="text-sm">☕</span>
                        )}
                        <span className="font-semibold text-[13.5px] text-ink-900">{r.variant}</span>
                        {isLow ? (
                          <Tag tone="amber">LOW STOCK</Tag>
                        ) : (
                          <Tag tone="leaf">HEALTHY</Tag>
                        )}
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-[14px] text-ink-900">{r.qty}</span>
                        <span className="text-[11px] text-ink-400 ml-1">{r.unit}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex-1">
                        <Meter pct={pct} color={isLow ? '#EAB308' : '#16A34A'} h={6} />
                      </div>
                      <span className="text-[11px] font-mono text-ink-400 shrink-0">
                        min: {r.threshold} {r.unit}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-line/50 text-[11px] text-ink-400">
                      <span>Last Refilled: {r.lastRefillLabel}</span>
                      {ops && (
                        <div className="flex gap-2">
                          <ActionButton
                            small
                            run={async () => logRefill(m.id, r.variant, 20, admin.name, admin.role)}
                          >
                            +20 Refill
                          </ActionButton>
                          <ActionButton
                            small
                            run={async () => demoAudit('stock.waste', `${m.code} · ${r.variant}`, 'waste adjust -1 logged', admin.name, admin.role)}
                          >
                            Waste Log
                          </ActionButton>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            <FootNote>
              Threshold breaches trigger auto-pause on that specific recipe on the machine while keeping other recipes active.
            </FootNote>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Low Stock Alerts" sub="Items nearing depletion">
            {low.length === 0 ? (
              <p className="text-[12.5px] text-leaf-600 bg-leaf-50 p-3 rounded-lg border border-leaf-100">
                All stock levels are currently above reorder safety buffers.
              </p>
            ) : (
              <div className="space-y-2">
                {low.map((item, idx) => (
                  <div key={idx} className="p-3 bg-amber2-50 border border-amber2-200 rounded-lg text-[12px]">
                    <div className="flex justify-between font-semibold text-amber2-900">
                      <span>{item.variant}</span>
                      <span>{item.qty} {item.unit}</span>
                    </div>
                    <p className="text-amber2-700 text-[11px] mt-0.5">
                      Threshold {item.threshold} {item.unit} — schedule refill before peak window.
                    </p>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card title="Recent Refill Events" sub="Fleet stock logs">
            <div className="space-y-3">
              {STOCK_EVENTS.map((ev, i) => (
                <div key={i} className="text-[12px] pb-2.5 border-b border-line last:border-none">
                  <div className="flex items-center justify-between font-semibold">
                    <span>{ev.variant}</span>
                    <Tag tone={ev.kind === 'waste' ? 'red' : 'leaf'}>{ev.kind.toUpperCase()}</Tag>
                  </div>
                  <p className="text-ink-500 text-[11px] mt-0.5">{ev.note}</p>
                  <div className="flex justify-between text-[10px] text-ink-400 mt-1 font-mono">
                    <span>{ev.tsLabel}</span>
                    <span>{ev.by}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
