import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, FootNote } from '@/components/ui/kit';
import { getMachine } from '@/lib/live';
import { telemetryFor, type TelemetryWindow } from '@/lib/mock/fleet';
import { LineChart, Bars } from '@/components/ui/charts';
import { IconArrowRight } from '@/components/ui/icons';
import Link from 'next/link';

/* ② /machines/:id/telemetry — temp line, milk-level area, signal
   bars; window 24h / 7d / 30d (deep-linkable ?w=). */

const WINDOWS: { id: TelemetryWindow; label: string }[] = [
  { id: '24h', label: '24 hours' },
  { id: '7d', label: '7 days' },
  { id: '30d', label: '30 days' },
];

export default async function MachineTelemetry({ params, searchParams }: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ w?: string }>;
}) {
  const [{ id }, sp] = await Promise.all([params, searchParams]);
  const g = await requireCap(`/machines/${id}/telemetry`);
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path={`/machines/${id}/telemetry`} />;

  const m = (await getMachine(id))?.machine;
  if (!m) return null;

  const w = (WINDOWS.find(x => x.id === sp.w)?.id ?? '24h') as TelemetryWindow;
  const t = telemetryFor(id, w);

  return (
    <>
      <PageHead
        module={`${m.code} · Telemetry`}
        title="History"
        sub="machine_telemetry (partitioned by day) — charts render from stored buckets, never live patches."
        actions={
          <div className="flex gap-1.5">
            {WINDOWS.map(x => (
              <Link key={x.id} href={`/machines/${id}/telemetry?w=${x.id}`}
                className={`tab text-[12px] font-semibold px-3 py-2 border transition ${
                  w === x.id ? 'bg-brand-500 border-brand-500 text-white' : 'bg-white border-line text-ink-700 hover:bg-page'
                }`}
              >
                {x.label}
              </Link>
            ))}
          </div>
        }
      />

      <div className="space-y-4">
        <Card title="Milk temperature" sub={`line · ${WINDOWS.find(x => x.id === w)?.label} window`}>
          <LineChart
            labels={t.labels}
            series={[{ label: 'Temp °C', color: '#F04E23', values: t.temp }]}
            height={210}
            suffix="°"
          />
        </Card>

        <div className="grid lg:grid-cols-2 gap-4">
          <Card title="Milk level" sub="area · refill spikes visible">
            <LineChart
              labels={t.labels}
              series={[{ label: 'Litres', color: '#16A34A', values: t.litres }]}
              height={190}
              suffix="L"
            />
          </Card>

          <Card title="4G signal" sub="bars · dBm (worse is lower)">
            <Bars values={t.signal} labels={w === '24h' ? t.labels.map((l, i) => (i % 4 === 0 ? l : '')) : t.labels} color="#2563EB" height={190} suffix=" dBm" />
          </Card>
        </div>

        <Card title="Orders per bucket" sub="orders joined on machine_id + ts bucket">
          <Bars values={t.orders} labels={w === '24h' ? t.labels.map((l, i) => (i % 4 === 0 ? l : '')) : t.labels} color="#F97C4A" height={160} />
        </Card>
      </div>

      <FootNote>
        The audit trail records exports; event webhook <code className="p font-mono">machine.telemetry.sync</code> fires per day partition by the Rust service. Detail drill →{' '}
        <Link href={`/machines/${id}/commands`} className="text-brand-600 font-semibold hover:underline">command log <IconArrowRight className="w-3 h-3 inline" /></Link>
      </FootNote>
    </>
  );
}
