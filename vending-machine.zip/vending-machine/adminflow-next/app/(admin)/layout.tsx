import type { Metadata } from 'next';
import AdminShell from '@/components/shell/admin-shell';
import { getAdmin, isMaintenance } from '@/lib/auth';
import { listOrders } from '@/lib/mock/store';
import { bellItems } from '@/lib/mock/settings';

/* Route-group layout: mounts the persistent shell once per
   navigation and never remounts it between modules (routing
   spec Diagram 01) — sidebar scroll, filters and the live
   strip survive every list→detail hop. */

export const metadata: Metadata = {
  title: 'Manhattan Coffee · Admin',
  description: 'Operator console — 9 modules, 53 routes, 6 roles.',
};

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const admin = await getAdmin();
  const maintenance = await isMaintenance();
  const bell = admin ? bellItems(listOrders()) : [];
  return <AdminShell admin={admin} maintenance={maintenance} notifications={bell}>{children}</AdminShell>;
}
