import Link from 'next/link';
import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote, rs } from '@/components/ui/kit';
import { PROFIT } from '@/lib/mock/analytics';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function AnalyticsProfitabilityPage() {
  const g = await requireCap('/analytics/profitability');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/analytics/profitability" />;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/analytics" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Analytics Overview
        </Link>
      </div>

      <PageHead
        module="⑥ Analytics · Profitability"
        title="Unit Economics & Net Profitability"
        sub="Blends direct coffee sales margins with non-dispense auxiliary income (app ad networks, machine physical ad rentals, and unspent wallet float)."
      />

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Gross Coffee Revenue</p>
          <p className="text-[26px] font-bold text-ink-900 mt-1">{rs(PROFIT.revenue)}</p>
          <span className="text-[11px] text-ink-400">Cash paid at machines</span>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Raw Material Cost</p>
          <p className="text-[26px] font-bold text-red-600 mt-1">-{rs(PROFIT.material)}</p>
          <span className="text-[11px] text-ink-400">{PROFIT.materialPct}% of gross revenue</span>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Auxiliary Income</p>
          <p className="text-[26px] font-bold text-brand-600 mt-1">+{rs(PROFIT.adRevenue + PROFIT.adSpaceRent)}</p>
          <span className="text-[11px] text-ink-400">Ads ({rs(PROFIT.adRevenue)}) + Rentals ({rs(PROFIT.adSpaceRent)})</span>
        </div>
        <div className="card p-5 bg-leaf-50/60 border-leaf-200">
          <p className="text-[11px] font-semibold text-leaf-700 uppercase tracking-wider">Estimated Net Profit</p>
          <p className="text-[26px] font-bold text-leaf-800 mt-1">{rs(PROFIT.netProfit)}</p>
          <span className="text-[11px] text-leaf-600 font-semibold">After materials & fixed utilities</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Cash Revenue vs Earned Revenue Split" sub="Separates customer cash flows from ancillary monetization">
            <div className="space-y-3 mt-2">
              {PROFIT.cashVsEarned.map((item, i) => (
                <div key={i} className="p-3 bg-page rounded-xl border border-line flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-ink-800 text-[13px]">{item.label}</span>
                    <p className="text-[11px] text-ink-400">
                      {item.kind === 'cash' ? 'Primary Point-of-Sale' : 'Auxiliary Margin Booster'}
                    </p>
                  </div>
                  <span className="font-mono font-bold text-[15px] text-ink-900">{rs(item.value)}</span>
                </div>
              ))}
            </div>
            <FootNote>
              Cash revenue and wallet float are never blended in financial reporting — float remains a liability until redeemed for coffee.
            </FootNote>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Customer Acquisition & LTV" sub="Growth unit economics">
            <div className="space-y-2">
              <KV k="Customer Acquisition Cost (CAC)" v={rs(PROFIT.cac)} />
              <KV k="Customer Lifetime Value (LTV)" v={rs(PROFIT.ltv)} />
              <KV k="LTV / CAC Ratio" v={<Tag tone="leaf">{(PROFIT.ltv / PROFIT.cac).toFixed(1)}× (Exceptional)</Tag>} />
              <KV k="Break-even output" v={`${PROFIT.breakEvenCupsDay} cups / day / machine`} />
              <KV k="Fixed costs / node / day" v={rs(PROFIT.fixedCostDay)} />
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
