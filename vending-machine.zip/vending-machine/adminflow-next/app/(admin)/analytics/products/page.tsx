import Link from 'next/link';
import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { PRODUCT_STATS } from '@/lib/mock/analytics';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function AnalyticsProductsPage() {
  const g = await requireCap('/analytics/products');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/analytics/products" />;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/analytics" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Analytics Overview
        </Link>
      </div>

      <PageHead
        module="⑥ Analytics · Products"
        title="Recipe Variant Margins & Cannibalization"
        sub="Per-cup unit economics, sales volumes, gross margins after ingredients, and substitution cannibalization analysis."
      />

      <div className="grid md:grid-cols-2 gap-6">
        {PRODUCT_STATS.map(ps => (
          <Card key={ps.rank} title={`${ps.emoji} ${ps.variant}`} sub={`Popularity Rank #${ps.rank}`}>
            <div className="grid grid-cols-3 gap-2 my-3 text-center">
              <div className="p-2.5 bg-page rounded-xl border border-line">
                <p className="text-[10.5px] uppercase font-semibold text-ink-400">Total Cups</p>
                <p className="text-[18px] font-bold text-ink-900 mt-0.5">{ps.orders}</p>
              </div>
              <div className="p-2.5 bg-page rounded-xl border border-line">
                <p className="text-[10.5px] uppercase font-semibold text-ink-400">Revenue</p>
                <p className="text-[18px] font-bold text-brand-600 mt-0.5">{rs(ps.revenue)}</p>
              </div>
              <div className="p-2.5 bg-page rounded-xl border border-line">
                <p className="text-[10.5px] uppercase font-semibold text-ink-400">Gross Margin</p>
                <p className="text-[18px] font-bold text-leaf-600 mt-0.5">{ps.marginPct}%</p>
              </div>
            </div>

            <div className="p-3 bg-brand-50/60 border border-brand-100 rounded-xl text-[12px] text-ink-700 leading-relaxed mb-3">
              <strong className="text-brand-800 font-semibold block mb-0.5">Analyst Note:</strong>
              {ps.note}
            </div>

            <div className="flex items-center justify-between text-[11.5px] text-ink-500 pt-2 border-t border-line">
              <span>Ingredient Cost / Cup: <strong>₹{ps.costPerServing.toFixed(2)}</strong></span>
              <span className="text-leaf-600 font-medium">Margin Protected</span>
            </div>
          </Card>
        ))}
      </div>

      <Card title="Product Architecture Rule" sub="Design philosophy from system architecture doc">
        <p className="text-[12.5px] text-ink-600 leading-relaxed max-w-4xl">
          The menu is intentionally limited to 4 core recipes (Manhattan Velvet Cappuccino, Grande Roast, Classic Latte, Chilled Frappe).
          This prevents inventory fragmentation and eliminates slow-moving powdered ingredients that spoil in high humidity.
        </p>
      </Card>
    </div>
  );
}
