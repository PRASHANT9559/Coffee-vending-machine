'use client';

import { useState } from 'react';
import Link from 'next/link';
import { inr } from '@/lib/format';
import { rs } from '@/components/ui/kit';
import {
  IconTrendUp, IconCup, IconAnalytics, IconWallet,
  IconArrowRight, IconCalendar, IconMachine, IconFlame,
} from '@/components/ui/icons';

type DateWindow = 'today' | '7d' | '30d' | 'qtd';

interface WindowMetrics {
  label: string;
  sub: string;
  revenue: number;
  revenueDelta: string;
  orders: number;
  ordersSub: string;
  marginPct: number;
  marginSub: string;
  adRevenue: number;
  adSub: string;
  bars: { label: string; rev: number; cups: number }[];
}

const WINDOW_DATA: Record<DateWindow, WindowMetrics> = {
  today: {
    label: 'Today (Intraday Telemetry)',
    sub: 'Live 30s aggregate from all online nodes',
    revenue: 18400,
    revenueDelta: '+9.4% vs yesterday',
    orders: 52,
    ordersSub: 'Peak at 11:30 AM (14 cups/hr)',
    marginPct: 72,
    marginSub: 'Ingredient basis: ₹16.80/cup',
    adRevenue: 1850,
    adSub: 'Dual LCD loop ad impressions',
    bars: [
      { label: '8 AM', rev: 1400, cups: 4 },
      { label: '10 AM', rev: 4200, cups: 12 },
      { label: '12 PM', rev: 5600, cups: 16 },
      { label: '2 PM', rev: 2100, cups: 6 },
      { label: '4 PM', rev: 3500, cups: 10 },
      { label: '6 PM', rev: 1600, cups: 4 },
    ],
  },
  '7d': {
    label: 'Last 7 Days (Trailing Week)',
    sub: 'Full week performance across Pune campus & mall nodes',
    revenue: 158250,
    revenueDelta: '+14.2% vs previous 7d',
    orders: 442,
    ordersSub: 'Avg 63 cups/day across fleet',
    marginPct: 69,
    marginSub: 'After ingredient + cup packaging costs',
    adRevenue: 4740,
    adSub: 'LCD loop ads + kiosk vinyl wrap lease',
    bars: [
      { label: 'Mon', rev: 18400, cups: 52 },
      { label: 'Tue', rev: 21600, cups: 61 },
      { label: 'Wed', rev: 19800, cups: 55 },
      { label: 'Thu', rev: 26300, cups: 74 },
      { label: 'Fri', rev: 24100, cups: 68 },
      { label: 'Sat', rev: 31200, cups: 88 },
      { label: 'Sun', rev: 16850, cups: 44 },
    ],
  },
  '30d': {
    label: 'Last 30 Days (Trailing Month)',
    sub: 'Monthly aggregate cohort retention & fleet output',
    revenue: 545000,
    revenueDelta: '+18.5% vs previous 30d',
    orders: 1552,
    ordersSub: 'Avg 51 cups/day · 74% repeat customer cohort',
    marginPct: 68,
    marginSub: 'Net operating profit ₹3,70,600',
    adRevenue: 18960,
    adSub: 'Campus sponsored display brand slots',
    bars: [
      { label: 'W1', rev: 124000, cups: 352 },
      { label: 'W2', rev: 138000, cups: 398 },
      { label: 'W3', rev: 131000, cups: 374 },
      { label: 'W4', rev: 152000, cups: 428 },
    ],
  },
  qtd: {
    label: 'Quarter to Date (Q3 FY26)',
    sub: 'Strategic quarterly unit economics & fleet scalability',
    revenue: 1580000,
    revenueDelta: '+22.4% YoY expansion',
    orders: 4680,
    ordersSub: 'Avg 52 cups/day · Node MTTR 1.8h',
    marginPct: 70,
    marginSub: 'Bulk dairy & bean procurement savings',
    adRevenue: 56880,
    adSub: 'Brand sponsorships across college campuses',
    bars: [
      { label: 'Month 1', rev: 490000, cups: 1450 },
      { label: 'Month 2', rev: 545000, cups: 1552 },
      { label: 'Month 3 (MTD)', rev: 545000, cups: 1678 },
    ],
  },
};

export default function AnalyticsOverviewClient() {
  const [window, setWindow] = useState<DateWindow>('7d');
  const d = WINDOW_DATA[window];

  const maxBarRev = Math.max(...d.bars.map(b => b.rev));

  const subroutes = [
    {
      href: '/analytics/sales',
      label: 'Sales & Revenue Ledger',
      sub: 'Revenue trends, day-by-day cash intake, and ₹10/₹20/₹40/₹60 price tier mix.',
      icon: IconTrendUp,
      tone: 'text-leaf-600 bg-leaf-50',
    },
    {
      href: '/analytics/products',
      label: 'Variant Performance & Cannibalisation',
      sub: 'Cup volumes, profit margins per recipe, and Velvet vs Frappe stockout cannibalisation.',
      icon: IconCup,
      tone: 'text-brand-600 bg-brand-50',
    },
    {
      href: '/analytics/consumption',
      label: '24×7 Consumption Heatmap',
      sub: 'Peak demand hours (11am & 4:30pm) and repeat customer cohort retention trends.',
      icon: IconFlame,
      tone: 'text-amber2-600 bg-amber2-50',
    },
    {
      href: '/analytics/machines',
      label: 'Node Comparison & Uptime MTTR',
      sub: 'Side-by-side uptime (99.2% vs 96.8%), sensor failure MTTR, and revenue per venue.',
      icon: IconMachine,
      tone: 'text-blue-600 bg-blue-50',
    },
    {
      href: '/analytics/profitability',
      label: 'Unit Economics & Auxiliary Profitability',
      sub: 'Net cash vs earned ad revenue, CAC (₹34) vs LTV (₹412), break-even cups/day.',
      icon: IconAnalytics,
      tone: 'text-purple-600 bg-purple-50',
    },
  ];

  return (
    <div className="space-y-6">
      {/* ── Interactive Date-Window Picker ─────────────────────── */}
      <div className="bg-white border border-line rounded-2xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-page text-ink-600 border border-line">
            <IconCalendar className="w-4 h-4 text-brand-600" />
          </div>
          <div>
            <h3 className="text-[13px] font-bold text-ink-900">{d.label}</h3>
            <p className="text-[11.5px] text-ink-500">{d.sub}</p>
          </div>
        </div>

        {/* Date Window Toggle Pills */}
        <div className="inline-flex items-center bg-page border border-line rounded-xl p-1 gap-1">
          <button
            type="button"
            onClick={() => setWindow('today')}
            className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold transition ${
              window === 'today'
                ? 'bg-ink-900 text-white shadow-xs'
                : 'text-ink-600 hover:text-ink-900 hover:bg-white/60'
            }`}
          >
            Today
          </button>

          <button
            type="button"
            onClick={() => setWindow('7d')}
            className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold transition ${
              window === '7d'
                ? 'bg-ink-900 text-white shadow-xs'
                : 'text-ink-600 hover:text-ink-900 hover:bg-white/60'
            }`}
          >
            7D
          </button>

          <button
            type="button"
            onClick={() => setWindow('30d')}
            className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold transition ${
              window === '30d'
                ? 'bg-ink-900 text-white shadow-xs'
                : 'text-ink-600 hover:text-ink-900 hover:bg-white/60'
            }`}
          >
            30D
          </button>

          <button
            type="button"
            onClick={() => setWindow('qtd')}
            className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold transition ${
              window === 'qtd'
                ? 'bg-ink-900 text-white shadow-xs'
                : 'text-ink-600 hover:text-ink-900 hover:bg-white/60'
            }`}
          >
            QTD
          </button>
        </div>
      </div>

      {/* ── 4 Clickable Metric Cards with Drill-Down Links ──────── */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Revenue -> Sales */}
        <Link
          href="/analytics/sales"
          className="card p-5 hover:border-brand-300 hover:shadow-md transition-all group block cursor-pointer"
        >
          <div className="flex items-center justify-between text-ink-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">
              {window === 'today' ? "Today's Revenue" : `${window.toUpperCase()} Revenue`}
            </span>
            <IconTrendUp className="w-4 h-4 text-leaf-500" />
          </div>
          <p className="text-[26px] font-bold text-ink-900 mt-1">₹{inr(d.revenue)}</p>
          <div className="flex items-center justify-between mt-1">
            <span className="text-[11px] text-leaf-600 font-semibold">{d.revenueDelta}</span>
            <span className="text-[11px] font-medium text-brand-600 opacity-0 group-hover:opacity-100 transition-opacity">
              Drill down →
            </span>
          </div>
        </Link>

        {/* Metric 2: Orders -> Products */}
        <Link
          href="/analytics/products"
          className="card p-5 hover:border-brand-300 hover:shadow-md transition-all group block cursor-pointer"
        >
          <div className="flex items-center justify-between text-ink-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">
              Total Cup Dispenses
            </span>
            <IconCup className="w-4 h-4 text-brand-500" />
          </div>
          <p className="text-[26px] font-bold text-ink-900 mt-1">{d.orders} cups</p>
          <div className="flex items-center justify-between mt-1">
            <span className="text-[11px] text-ink-500">{d.ordersSub}</span>
            <span className="text-[11px] font-medium text-brand-600 opacity-0 group-hover:opacity-100 transition-opacity">
              Drill down →
            </span>
          </div>
        </Link>

        {/* Metric 3: Gross Margin -> Profitability */}
        <Link
          href="/analytics/profitability"
          className="card p-5 hover:border-brand-300 hover:shadow-md transition-all group block cursor-pointer"
        >
          <div className="flex items-center justify-between text-ink-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">
              Gross Margin
            </span>
            <IconAnalytics className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-[26px] font-bold text-ink-900 mt-1">{d.marginPct}%</p>
          <div className="flex items-center justify-between mt-1">
            <span className="text-[11px] text-leaf-600 font-semibold">{d.marginSub}</span>
            <span className="text-[11px] font-medium text-brand-600 opacity-0 group-hover:opacity-100 transition-opacity">
              Drill down →
            </span>
          </div>
        </Link>

        {/* Metric 4: Auxiliary & Ad Revenue -> Profitability */}
        <Link
          href="/analytics/profitability"
          className="card p-5 hover:border-brand-300 hover:shadow-md transition-all group block cursor-pointer"
        >
          <div className="flex items-center justify-between text-ink-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">
              Auxiliary & Ad Revenue
            </span>
            <IconWallet className="w-4 h-4 text-amber2-500" />
          </div>
          <p className="text-[26px] font-bold text-ink-900 mt-1">₹{inr(d.adRevenue)}</p>
          <div className="flex items-center justify-between mt-1">
            <span className="text-[11px] text-ink-500">{d.adSub}</span>
            <span className="text-[11px] font-medium text-brand-600 opacity-0 group-hover:opacity-100 transition-opacity">
              Drill down →
            </span>
          </div>
        </Link>
      </div>

      {/* ── Interactive Distribution Visual Bars ───────────────── */}
      <div className="card p-5">
        <div className="flex items-center justify-between border-b border-line pb-3 mb-4">
          <div>
            <h4 className="text-[13px] font-bold text-ink-900">Period Distribution & Volume Timeline</h4>
            <p className="text-[11.5px] text-ink-500">
              Interactive timeline for window <strong className="text-ink-800">{d.label}</strong>
            </p>
          </div>
          <span className="text-[11px] font-semibold text-ink-400">Values in INR (₹)</span>
        </div>

        <div className="grid grid-flow-col auto-cols-fr gap-3 items-end h-40 pt-4 px-2">
          {d.bars.map((bar, i) => {
            const heightPct = Math.max(12, Math.round((bar.rev / maxBarRev) * 100));
            return (
              <div key={i} className="flex flex-col items-center h-full justify-end group">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-mono font-bold text-ink-700 mb-1 whitespace-nowrap bg-white border border-line px-1.5 py-0.5 rounded shadow-xs">
                  ₹{inr(bar.rev)} · {bar.cups}c
                </div>
                <div
                  style={{ height: `${heightPct}%` }}
                  className="w-full max-w-[48px] bg-brand-500 hover:bg-brand-600 rounded-t-md transition-all relative"
                />
                <span className="text-[11px] font-medium text-ink-500 mt-2 whitespace-nowrap">
                  {bar.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Drill-Down Navigation Hub ──────────────────────────── */}
      <div className="space-y-4">
        <div>
          <h3 className="text-[14px] font-bold text-ink-900">Specialized Fleet Intelligence Hubs</h3>
          <p className="text-[12px] text-ink-500">
            Click any module below for deep-dive multi-dimensional reporting:
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {subroutes.map((sub, i) => {
            const Icon = sub.icon;
            return (
              <Link
                key={i}
                href={sub.href}
                className="p-4 rounded-xl border border-line bg-white hover:border-brand-400 hover:shadow-sm transition-all group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-2 rounded-lg ${sub.tone}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <p className="font-bold text-[13.5px] text-ink-900 group-hover:text-brand-600 transition-colors">
                      {sub.label}
                    </p>
                  </div>
                  <p className="text-[11.5px] text-ink-500 leading-relaxed">{sub.sub}</p>
                </div>
                <div className="mt-4 pt-2 border-t border-line/60 flex items-center justify-between text-[11.5px] font-semibold text-brand-600">
                  <span>Explore data view</span>
                  <span className="group-hover:translate-x-1 transition-transform">→</span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
