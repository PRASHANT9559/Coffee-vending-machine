import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag } from '@/components/ui/kit';
import { SAVED_REPORTS } from '@/lib/mock/analytics';
import AnalyticsOverviewClient from './analytics-overview-client';

export default async function AnalyticsOverviewPage() {
  const g = await requireCap('/analytics');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/analytics" />;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <PageHead
        module="⑥ Analytics"
        title="Fleet Intelligence & Growth Analytics"
        sub="Granular financial, physical machine, product variant, and customer consumption analytics across the network."
      />

      <AnalyticsOverviewClient />

      <div className="card p-5">
        <div className="flex items-center justify-between border-b border-line pb-3 mb-4">
          <div>
            <h4 className="text-[13px] font-bold text-ink-900">Saved Analytical Snapshots</h4>
            <p className="text-[11.5px] text-ink-500">
              Pre-computed operational filter queries and pinned cohort metrics
            </p>
          </div>
          <span className="text-[11px] font-semibold text-brand-600 bg-brand-50 px-2 py-0.5 rounded">
            {SAVED_REPORTS.length} Snapshots
          </span>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SAVED_REPORTS.map((r, i) => (
            <div
              key={i}
              className="p-3.5 bg-page border border-line rounded-xl flex items-center justify-between text-[12px] hover:border-brand-300 transition"
            >
              <span className="font-semibold text-ink-800">{r}</span>
              <Tag tone="brand">SAVED</Tag>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
