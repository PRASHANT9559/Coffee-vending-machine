import Link from 'next/link';
import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, KV, Tag, FootNote, rs } from '@/components/ui/kit';
import { MACHINE_COMPARE_ROWS, MACHINE_FLAGS } from '@/lib/mock/analytics';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function AnalyticsMachinesPage() {
  const g = await requireCap('/analytics/machines');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/analytics/machines" />;

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/analytics" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Analytics Overview
        </Link>
      </div>

      <PageHead
        module="⑥ Analytics · Machines"
        title="Fleet Node Performance Comparison"
        sub="Side-by-side hardware reliability, uptime percentages, revenue per venue, and underperformer relocation flags."
      />

      <div className="p-4 bg-amber2-50 border border-amber2-200 rounded-xl text-[12.5px] text-amber2-900 font-medium">
        ⚠️ <strong>Fleet Warning:</strong> {MACHINE_FLAGS}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {MACHINE_COMPARE_ROWS.map(mc => (
          <Card key={mc.machineId} title={mc.machine} sub={`Location: ${mc.city}`}>
            <div className="grid grid-cols-2 gap-3 my-3">
              <div className="p-3 bg-page rounded-xl border border-line text-center">
                <p className="text-[11px] font-semibold text-ink-400 uppercase">Uptime</p>
                <p className="text-[22px] font-bold text-leaf-600 mt-0.5">{mc.uptimePct}%</p>
              </div>
              <div className="p-3 bg-page rounded-xl border border-line text-center">
                <p className="text-[11px] font-semibold text-ink-400 uppercase">Daily Output</p>
                <p className="text-[22px] font-bold text-ink-900 mt-0.5">{mc.cupsDay} cups/d</p>
              </div>
            </div>

            <div className="space-y-1">
              <KV k="Total Revenue Generated" v={<span className="text-brand-600 font-bold">{rs(mc.revenue)}</span>} />
              <KV k="Hardware Failures (30d)" v={`${mc.failures} incidents`} />
              <KV k="Mean Time to Repair (MTTR)" v={`${mc.mttrH} hours`} />
            </div>

            <div className="mt-4 pt-3 border-t border-line flex justify-end">
              <Link
                href={`/machines/${mc.machineId}`}
                className="text-[12px] font-semibold text-brand-600 hover:underline"
              >
                Open Machine Detail Telemetry →
              </Link>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
