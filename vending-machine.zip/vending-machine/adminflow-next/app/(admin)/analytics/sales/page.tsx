import Link from 'next/link';
import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote, rs } from '@/components/ui/kit';
import { SALES_DAYS, SALES_WEEKS, TIER_MIX, MACHINE_SPLIT } from '@/lib/mock/analytics';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function AnalyticsSalesPage() {
  const g = await requireCap('/analytics/sales');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/analytics/sales" />;

  const maxDay = Math.max(...SALES_DAYS.map(d => d.revenue));

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/analytics" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Analytics Overview
        </Link>
      </div>

      <PageHead
        module="⑥ Analytics · Sales"
        title="Revenue & Price Tier Mix"
        sub="Daily and weekly sales trajectories, pricing tier cannibalization distribution (₹10, ₹20, ₹40, ₹60), and node location contributions."
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Daily Revenue Velocity" sub="Trailing 7-day revenue and order volume">
            <div className="h-48 flex items-end gap-3 pt-6 pb-2 px-2 border-b border-line">
              {SALES_DAYS.map((d, i) => {
                const heightPct = Math.round((d.revenue / maxDay) * 100);
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    <span className="text-[10px] font-mono font-semibold text-ink-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      {rs(d.revenue)}
                    </span>
                    <div
                      style={{ height: `${heightPct}%` }}
                      className="w-full bg-brand-500/80 hover:bg-brand-500 rounded-t-lg transition-all"
                    />
                    <span className="text-[11px] font-medium text-ink-600">{d.label}</span>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between items-center text-[12px] text-ink-500 pt-3">
              <span>Peak Day: Saturday ({rs(31200)} · 88 orders)</span>
              <span>Total 7d: {rs(SALES_DAYS.reduce((a, b) => a + b.revenue, 0))}</span>
            </div>
          </Card>

          <Card title="Pricing Tier Mix Breakdown" sub="Monitors whether entry ₹20 cups cannibalize ₹40 & ₹60 flagship blends">
            <div className="space-y-3 mt-2">
              {TIER_MIX.map((tm, i) => {
                const total = tm.t10 + tm.t20 + tm.t40 + tm.t60;
                const p20 = Math.round((tm.t20 / total) * 100);
                const p40 = Math.round((tm.t40 / total) * 100);
                const p60 = Math.round((tm.t60 / total) * 100);

                return (
                  <div key={i} className="text-[12px]">
                    <div className="flex justify-between font-semibold text-ink-700 mb-1">
                      <span>{tm.label}</span>
                      <span className="font-mono text-ink-400">{rs(total)} total</span>
                    </div>
                    <div className="h-4 rounded-full overflow-hidden flex bg-page border border-line">
                      <div style={{ width: `${p20}%` }} className="bg-ink-300" title={`₹20 Classic: ${p20}%`} />
                      <div style={{ width: `${p40}%` }} className="bg-brand-400" title={`₹40 Roast/Frappe: ${p40}%`} />
                      <div style={{ width: `${p60}%` }} className="bg-brand-600" title={`₹60 Manhattan Velvet: ${p60}%`} />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-4 text-[11px] pt-4 text-ink-500 border-t border-line">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-ink-300" /> ₹20 Classic</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-400" /> ₹40 Grande Roast / Frappe</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-600" /> ₹60 Manhattan Velvet</span>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Node Revenue Contribution" sub="Machine split across venues">
            <div className="space-y-4">
              {MACHINE_SPLIT.map((ms, i) => (
                <div key={i} className="p-3.5 bg-page rounded-xl border border-line">
                  <p className="font-bold text-[13px] text-ink-900">{ms.machine}</p>
                  <p className="text-[11px] text-ink-400">{ms.city} · {ms.orders} total orders</p>
                  <div className="flex justify-between items-baseline mt-3 pt-2 border-t border-line/60">
                    <span className="text-[11.5px] text-ink-500">Total Revenue</span>
                    <span className="font-mono font-bold text-[15px] text-ink-900">{rs(ms.revenue)}</span>
                  </div>
                  <p className="text-[11px] text-leaf-600 font-medium text-right mt-0.5">
                    Avg {ms.cupsDay} cups/day
                  </p>
                </div>
              ))}
            </div>
          </Card>

          <Card title="Monthly Week Trajectory" sub="4-week performance">
            <div className="space-y-2 text-[12px]">
              {SALES_WEEKS.map((w, i) => (
                <div key={i} className="flex justify-between py-1.5 border-b border-line last:border-none">
                  <span className="font-semibold text-ink-800">{w.label}</span>
                  <span className="text-ink-500">{w.orders} cups</span>
                  <span className="font-mono font-bold text-ink-900">{rs(w.revenue)}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
