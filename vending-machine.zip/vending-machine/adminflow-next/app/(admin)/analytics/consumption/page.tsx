import Link from 'next/link';
import { requireCap } from '@/lib/auth';
import { PageHead, ForbiddenView, Card, Tag, FootNote } from '@/components/ui/kit';
import { HEAT_24X7, PEAK_WINDOWS, NEW_VS_RETURNING } from '@/lib/mock/analytics';
import { IconArrowLeft } from '@/components/ui/icons';

export default async function AnalyticsConsumptionPage() {
  const g = await requireCap('/analytics/consumption');
  if (g.kind === 'forbidden') return <ForbiddenView admin={g.admin} cap={g.cap} path="/analytics/consumption" />;

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const hours = Array.from({ length: 24 }, (_, i) => i);

  return (
    <div className="p-5 lg:p-8 max-w-[1400px] w-full mx-auto space-y-6">
      <div className="flex items-center gap-2 text-[12px] text-ink-500 mb-1">
        <Link href="/analytics" className="hover:text-brand-600 inline-flex items-center gap-1">
          <IconArrowLeft className="w-3.5 h-3.5" /> Back to Analytics Overview
        </Link>
      </div>

      <PageHead
        module="⑥ Analytics · Consumption"
        title="24×7 Demand Heatmap & Customer Behavior"
        sub="Hour-by-hour order intensity across the week. Identifies peak refill windows and retention patterns between new and returning coffee drinkers."
      />

      <div className="grid sm:grid-cols-3 gap-4">
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Primary Peak Window</p>
          <p className="text-[20px] font-bold text-brand-600 mt-1">{PEAK_WINDOWS[0]}</p>
          <p className="text-[11px] text-ink-500 mt-1">College recess & mid-day campus rush</p>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Secondary Peak Window</p>
          <p className="text-[20px] font-bold text-amber2-600 mt-1">{PEAK_WINDOWS[1]}</p>
          <p className="text-[11px] text-ink-500 mt-1">Evening study session demand spike</p>
        </div>
        <div className="card p-5">
          <p className="text-[11px] font-semibold text-ink-400 uppercase tracking-wider">Returning vs New Split</p>
          <p className="text-[20px] font-bold text-leaf-600 mt-1">{NEW_VS_RETURNING.returningPct}% Returning</p>
          <p className="text-[11px] text-ink-500 mt-1">{NEW_VS_RETURNING.repeatPct}% 30-day repeat customer rate</p>
        </div>
      </div>

      <Card title="24×7 Hourly Demand Heatmap" sub="Rows: Day of week · Columns: Hour of day (00:00 - 23:00)">
        <div className="overflow-x-auto -mx-1 px-1 mt-3">
          <div className="min-w-[700px]">
            <div className="flex text-[10px] text-ink-400 font-mono mb-1 pl-12">
              {hours.map(h => (
                <div key={h} className="flex-1 text-center">
                  {h % 3 === 0 ? `${h}h` : ''}
                </div>
              ))}
            </div>

            <div className="space-y-1.5">
              {days.map((day, di) => (
                <div key={day} className="flex items-center gap-2">
                  <span className="w-10 text-[11px] font-semibold text-ink-600 shrink-0">{day}</span>
                  <div className="flex-1 flex gap-1">
                    {hours.map(h => {
                      const val = HEAT_24X7[di]?.[h] ?? 0;
                      const opacity = Math.min(1, Math.max(0.08, val / 45));
                      return (
                        <div
                          key={h}
                          title={`${day} @ ${h}:00 — ~${val} cups`}
                          style={{
                            backgroundColor: `rgba(240, 78, 35, ${opacity})`,
                          }}
                          className="flex-1 h-7 rounded-sm hover:ring-2 hover:ring-brand-500 transition cursor-pointer"
                        />
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 text-[10.5px] text-ink-400 font-mono mt-4">
              <span>Low Intensity</span>
              <div className="flex gap-1">
                <span className="w-4 h-3 bg-brand-500/10 rounded-sm" />
                <span className="w-4 h-3 bg-brand-500/30 rounded-sm" />
                <span className="w-4 h-3 bg-brand-500/60 rounded-sm" />
                <span className="w-4 h-3 bg-brand-500 rounded-sm" />
              </div>
              <span>Peak Demand (~45 cups/hr)</span>
            </div>
          </div>
        </div>
        <FootNote>
          The 24×7 heatmap is the single most actionable chart for scheduling daily milk deliveries and route replenishments.
        </FootNote>
      </Card>
    </div>
  );
}
