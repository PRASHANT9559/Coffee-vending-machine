import React from 'react';
import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="min-h-screen p-6 md:p-12 max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">☕</span>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Manhattan <span className="text-amber-500">Coffee</span> Operations
            </h1>
            <span className="px-2 py-0.5 text-xs font-semibold rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
              Rust Backend Powered
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Automated Vending Telemetry &amp; Microservices Architecture
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Rust Axum Core: Online
          </span>
          <span className="text-xs text-slate-500 font-mono">Port 8080</span>
        </div>
      </header>

      {/* Grid Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs font-medium text-slate-400">Total Vending Units</p>
          <p className="text-2xl font-bold text-white mt-1">12 Machines</p>
          <p className="text-xs text-emerald-400 mt-2">● 12 Connected via Tokio WebSocket</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs font-medium text-slate-400">Dispenses Today</p>
          <p className="text-2xl font-bold text-white mt-1">842 Cups</p>
          <p className="text-xs text-amber-400 mt-2">Avg duration 38.2s</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs font-medium text-slate-400">Daily Revenue</p>
          <p className="text-2xl font-bold text-white mt-1">₹89,450</p>
          <p className="text-xs text-emerald-400 mt-2">+14.2% vs yesterday</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <p className="text-xs font-medium text-slate-400">Memory Footprint</p>
          <p className="text-2xl font-bold text-white mt-1">14.8 MB</p>
          <p className="text-xs text-indigo-400 mt-2">Zero-cost abstractions in Rust</p>
        </div>
      </div>

      {/* Rust Backend Overview */}
      <section className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">
              🦀 Rust Backend Codebase (/backend)
            </h2>
            <p className="text-xs text-slate-400">
              High-performance, memory-safe Axum + Tokio + SQLx REST &amp; WebSocket microservice
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 bg-slate-800 text-slate-300 rounded border border-slate-700">
            Cargo.toml · Axum 0.7 · SQLx
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2">
            <h3 className="font-semibold text-amber-400">1. Async Telemetry Engine</h3>
            <p className="text-slate-400">
              Axum handlers with Tokio asynchronous runtime for sub-millisecond machine telemetry ingestion, boiler pressure tracking, and milk cold-chain monitoring.
            </p>
            <div className="font-mono text-[11px] text-slate-500">
              backend/src/handlers/machines.rs
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2">
            <h3 className="font-semibold text-amber-400">2. JWT &amp; 6-Role RBAC</h3>
            <p className="text-slate-400">
              Rust Tower middleware validating HMAC-SHA256 JWT tokens, enforcing role permissions: Viewer, Support, Ops, Marketing, Finance, and Owner.
            </p>
            <div className="font-mono text-[11px] text-slate-500">
              backend/src/middleware/auth.rs
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2">
            <h3 className="font-semibold text-amber-400">3. PostgreSQL Connection Pool</h3>
            <p className="text-slate-400">
              SQLx compile-time checked queries and connection pooling directly accessing self-hosted PostgreSQL without ORM bloat or garbage collection pauses.
            </p>
            <div className="font-mono text-[11px] text-slate-500">
              backend/src/db/pool.rs
            </div>
          </div>
        </div>
      </section>

      {/* Rust Project Structure */}
      <section className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 space-y-3">
        <h3 className="text-sm font-semibold text-white">📁 Directory Layout in /backend:</h3>
        <pre className="p-4 rounded-lg bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto border border-slate-800">
{`backend/
├── Cargo.toml               # Rust dependencies: axum, tokio, sqlx, jsonwebtoken, serde
├── Dockerfile               # Multi-stage production container build
├── README.md                # Build, run & API documentation
└── src/
    ├── main.rs              # App entry point, Router setup, TCP listener
    ├── config.rs            # Env configuration (PORT, DATABASE_URL, JWT_SECRET)
    ├── error.rs             # Custom AppError with HTTP status code mapping
    ├── db/
    │   ├── mod.rs
    │   └── pool.rs          # SQLx PgPool connection manager
    ├── middleware/
    │   ├── mod.rs
    │   └── auth.rs          # JWT validation & RBAC Tower layer
    ├── models/
    │   ├── mod.rs
    │   ├── user.rs          # Operator & auth entities
    │   ├── machine.rs       # Vending machine telemetry models
    │   ├── order.rs         # Order & dispense payload
    │   └── support.rs       # Dispute tickets & SLA tracking
    └── handlers/
        ├── mod.rs
        ├── health.rs        # Health check & system metrics
        ├── auth.rs          # Login, OTP verification & token generation
        ├── machines.rs      # Machine telemetry & hardware commands
        ├── orders.rs        # Orders list, dispense logs & refunds
        └── live.rs          # Realtime polling & telemetry snapshot`}
        </pre>
      </section>
    </main>
  );
}
