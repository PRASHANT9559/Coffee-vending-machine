import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Manhattan Coffee — Admin Console & Routing Architecture',
  description:
    'Complete operations and growth administration platform for Manhattan Coffee vending network, featuring full 9-module routing architecture, live telemetry, dispute desk, RBAC, and fleet management.',
  openGraph: {
    title: 'Manhattan Coffee — Admin Console & Routing Architecture',
    description:
      'Complete operations and growth administration platform for Manhattan Coffee vending network.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-page text-ink-900 font-sans antialiased selection:bg-brand-100 selection:text-brand-700">
        {children}
      </body>
    </html>
  );
}
