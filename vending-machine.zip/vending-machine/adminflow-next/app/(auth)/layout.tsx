import Link from 'next/link';
import type { ReactNode } from 'react';

/* Auth shell — 3 routes · no sidebar (routing spec S1).
   Left: brand story + live machine teaser. Right: form. */

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* brand panel */}
      <aside className="hidden lg:flex flex-col justify-between bg-ink-900 text-white p-10 relative overflow-hidden">
        <div className="relative z-10">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-lg bg-brand-500 flex items-center justify-center font-bold text-[17px]">M</span>
            <span className="text-[17px] font-bold tracking-tight">Manhattan<span className="text-brand-400">Coffee</span></span>
          </Link>
          <p className="mt-14 text-[11px] font-semibold uppercase tracking-[.18em] text-white/40">Operator console</p>
          <h1 className="text-[34px] font-bold leading-tight mt-3 max-w-[22ch]">
            Every machine, every cup, every rupee — from one desk.
          </h1>
          <p className="text-[13.5px] text-white/60 mt-4 max-w-[52ch] leading-relaxed">
            Nine modules, 53 routes, six roles. The dispute desk, tank cold-chain,
            30-second clip evidence and the refund split — all one system.
          </p>
        </div>

        {/* machine teaser — the same chips that greet you inside */}
        <div className="relative z-10 space-y-3">
          <div className="rounded-xl bg-white/5 border border-white/10 p-4">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-leaf-400 pulse-dot" />
              <p className="text-[12.5px] font-semibold">MCH-001 · Campus Hub</p>
              <span className="ml-auto text-[10px] font-semibold px-2 py-0.5 rounded bg-leaf-400/20 text-leaf-400">ONLINE</span>
            </div>
            <p className="text-[11.5px] text-white/50 mt-1.5">65.4°C · 38L milk · 142 cups · hot mode</p>
          </div>
          <div className="rounded-xl bg-white/5 border border-white/10 p-4">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-leaf-400 pulse-dot" />
              <p className="text-[12.5px] font-semibold">MCH-002 · Mall Lane</p>
              <span className="ml-auto text-[10px] font-semibold px-2 py-0.5 rounded bg-leaf-400/20 text-leaf-400">ONLINE</span>
            </div>
            <p className="text-[11.5px] text-white/50 mt-1.5">6.2°C cold hold · 21L · 88 cups</p>
          </div>
          <p className="text-[10.5px] font-mono text-white/30 tracking-wider uppercase">
            6 roles · guard denies nothing silently · audit every mutation
          </p>
        </div>
      </aside>

      {/* form panel */}
      <main className="flex items-center justify-center p-6 bg-page">
        <div className="w-full max-w-[420px]">
          {children}
        </div>
      </main>
    </div>
  );
}
