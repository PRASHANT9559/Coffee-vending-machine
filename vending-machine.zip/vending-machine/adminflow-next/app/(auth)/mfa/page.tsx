import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { readToken, type PendingToken } from '@/lib/auth';
import MfaForm from './mfa-form';

export const metadata: Metadata = { title: 'Two-factor · Manhattan Coffee Admin' };

export const dynamic = 'force-dynamic';

/* Auth route 2 of 3 — second factor. Runs the guard pipeline's
   MFA step; suspended accounts were filtered server-side. */
export default async function MfaPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; err?: string }>;
}) {
  const { next = '/', err } = await searchParams;
  const jar = await cookies();
  const raw = jar.get('mc_auth_pending')?.value;
  const payload = await readToken<PendingToken>(raw);
  if (!payload || payload.kind !== 'pending') redirect('/login');

  return (
    <MfaForm
      phone={payload.phone}
      role={payload.role}
      next={next}
      wrong={err === 'wrong'}
    />
  );
}
