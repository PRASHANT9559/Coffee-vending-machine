'use client';

import { useRef, useState, useTransition } from 'react';
import { verifyMfa } from '@/lib/actions';
import { RoleTag } from '@/components/ui/kit';
import type { Role } from '@/lib/auth';

const BOXES = [0, 1, 2, 3, 4, 5];

export default function MfaForm({
  phone, role, next, wrong,
}: {
  phone: string; role: Role; next: string; wrong?: boolean;
}) {
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const [digits, setDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [trust, setTrust] = useState(true);
  const [pending, start] = useTransition();
  const code = digits.join('');

  const set = (i: number, v: string) => {
    const d = v.replace(/\D/g, '').slice(-1);
    setDigits(ds => { ds[i] = d; return [...ds]; });
    if (d && i < 5) refs.current[i + 1]?.focus();
  };

  const send = () => start(async () => {
    const fd = new FormData();
    fd.set('code', code);
    fd.set('trust', trust ? '1' : '0');
    fd.set('next', next);
    await verifyMfa(fd);
  });

  return (
    <div className="card p-7">
      <p className="text-[10px] font-semibold uppercase tracking-[.16em] text-brand-500">Step 3 · 2FA</p>
      <h1 className="text-[22px] font-bold mt-1.5">Second factor</h1>
      <p className="text-[13px] text-ink-500 mt-1">
        TOTP on <span className="font-mono">{phone}</span> <RoleTag role={role} className="align-middle ml-1" />
      </p>

      {wrong && (
        <div className="mt-4 rounded-lg bg-red-50 border border-red-100 text-red-600 text-[12px] font-semibold px-3.5 py-2.5">
          Invalid or expired 2FA code.
        </div>
      )}

      <div className="flex gap-2 mt-6">
        {BOXES.map(i => (
          <input
            key={i}
            ref={el => { refs.current[i] = el; }}
            value={digits[i]}
            onChange={e => set(i, e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Backspace' && !digits[i] && i > 0) refs.current[i - 1]?.focus();
            }}
            inputMode="numeric" maxLength={1} aria-label={`digit ${i + 1}`}
            className="w-full aspect-square text-center text-[20px] font-bold border border-line rounded-lg outline-none focus:border-brand-400 focus:bg-brand-50/40 transition font-mono"
          />
        ))}
      </div>

      <label className="flex items-center gap-2.5 mt-4 text-[12.5px] text-ink-700 select-none cursor-pointer">
        <input type="checkbox" checked={trust} onChange={e => setTrust(e.target.checked)} className="accent-brand-500 w-4 h-4" />
        Trust this device for 30 days · skip TOTP next time
      </label>

      <button
        type="button" onClick={send} disabled={pending || code.length < 6}
        className="mt-5 w-full bg-brand-500 hover:bg-brand-600 text-white text-[14px] font-semibold rounded-lg py-3 transition disabled:opacity-50"
      >
        {pending ? 'Opening console…' : 'Open the console'}
      </button>

      <p className="text-[11px] text-ink-400 mt-4 text-center font-mono">guard · steps 3-4 — role map next</p>
    </div>
  );
}
