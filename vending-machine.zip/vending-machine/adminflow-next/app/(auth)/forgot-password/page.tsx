'use client';

import { useState, useTransition } from 'react';
import { sendRecovery } from '@/lib/actions';
import { emitToast } from '@/components/ui/toast';

/* Auth route 3 of 3 — recovery stub per spec: email + recovery
   code, 15-min token, one state only. */
export default function ForgotPasswordPage() {
  const [pending, start] = useTransition();
  const [sent, setSent] = useState<string | null>(null);

  return (
    <div className="card p-7">
      <p className="text-[10px] font-semibold uppercase tracking-[.16em] text-brand-500">Recovery</p>
      <h1 className="text-[22px] font-bold mt-1.5">Reset access</h1>
      <p className="text-[13px] text-ink-500 mt-1">Email + recovery code · token valid 15 min.</p>

      {sent && (
        <div className="mt-4 rounded-lg bg-leaf-50 border border-leaf-100 text-leaf-600 text-[12px] font-semibold px-3.5 py-2.5">
          {sent}
        </div>
      )}

      <form
        className="mt-6 space-y-4"
        onSubmit={e => { e.preventDefault(); const fd = new FormData(e.currentTarget); start(async () => { const r = await sendRecovery(fd); emitToast(r.message, r.ok ? 'ok' : 'warn'); if (r.ok) setSent(r.message); }); }}
      >
        <div>
          <label className="block text-[11px] font-semibold text-ink-500 uppercase tracking-wider mb-1.5">Admin email</label>
          <input name="email" type="email" placeholder="you@manhattancoffee.in"
            className="w-full border border-line rounded-lg px-3.5 py-2.5 text-[14px] outline-none focus:border-brand-400 transition" />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-ink-500 uppercase tracking-wider mb-1.5">Recovery code</label>
          <input name="recovery" placeholder="8 letters, issued on the security page"
            className="w-full border border-line rounded-lg px-3.5 py-2.5 text-[14px] font-mono outline-none focus:border-brand-400 transition" />
        </div>
        <button type="submit" disabled={pending}
          className="w-full bg-brand-500 hover:bg-brand-600 text-white text-[14px] font-semibold rounded-lg py-3 transition disabled:opacity-50">
          {pending ? 'Sending…' : 'Send recovery link'}
        </button>
        <a href="/login" className="block text-center text-[12px] text-ink-500 hover:text-brand-600">← back to sign in</a>
      </form>
    </div>
  );
}
