'use client';

import { useState, useTransition } from 'react';
import { useSearchParams } from 'next/navigation';
import { requestOtp, verifyLoginOtp } from '@/lib/actions';
import { emitToast } from '@/components/ui/toast';
import type { Role } from '@/lib/auth';

interface RosterEntry { role: Role; name: string; phone: string }

export default function LoginForm({ roster }: { roster: RosterEntry[] }) {
  const params = useSearchParams();
  const next = params.get('next') ?? '/';
  const suspended = params.get('err') === 'suspended';

  const [role, setRole] = useState<Role>('owner');
  const [phone, setPhone] = useState(roster[0].phone);
  const [otp, setOtp] = useState('');

  const [pending, start] = useTransition();
  const active = roster.find(r => r.role === role)!;

  const send = () => start(async () => {
    const fd = new FormData();
    fd.set('phone', phone);
    const r = await requestOtp(fd);
    if (r.ok) {
      emitToast(r.message, 'ok');
    } else emitToast(r.message, 'warn');
  });

  const verify = () => start(async () => {
    const fd = new FormData();
    fd.set('otp', otp);
    const r = await verifyLoginOtp(fd);
    if (r && !r.ok) emitToast(r.message, 'warn');
  });

  return (
    <div className="card p-7">
      <p className="text-[10px] font-semibold uppercase tracking-[.16em] text-brand-500">Manhattan Coffee</p>
      <h1 className="text-[22px] font-bold mt-1.5">Sign in to the console</h1>
      <p className="text-[13px] text-ink-500 mt-1">6-box TOTP + device trust on the next step.</p>

      {suspended && (
        <div className="mt-4 rounded-lg bg-red-50 border border-red-100 text-red-600 text-[12px] font-semibold px-3.5 py-2.5">
          Account suspended — the owner has been notified.
        </div>
      )}

      {/* role chips — demo affordance to walk the permission matrix */}
      <p className="text-[11px] font-semibold text-ink-500 uppercase tracking-wider mt-6 mb-2">Sign in as</p>
      <div className="grid grid-cols-3 gap-1.5">
        {roster.map(r => (
          <button
            key={r.role}
            type="button"
            onClick={() => { setRole(r.role); setPhone(r.phone); }}
            className={`text-left rounded-lg border p-2.5 transition ${r.role === role
              ? 'border-brand-400 bg-brand-50' : 'border-line hover:bg-page'}`}
          >
            <span className="block text-[11.5px] font-bold">{RoleLabel(r.role)}</span>
            <span className="block text-[9.5px] text-ink-400 truncate">{r.name}</span>
          </button>
        ))}
      </div>

      <label className="block text-[11px] font-semibold text-ink-500 uppercase tracking-wider mt-5 mb-2" htmlFor="phone">
        Phone · {active.name}
      </label>
      <div className="flex gap-2">
        <input
          id="phone" value={phone} onChange={e => setPhone(e.target.value)}
          className="flex-1 border border-line rounded-lg px-3.5 py-2.5 text-[14px] outline-none focus:border-brand-400 transition font-mono"
        />
        <button
          type="button" onClick={send} disabled={pending}
          className="bg-brand-50 text-brand-700 hover:bg-brand-100 text-[12.5px] font-semibold rounded-lg px-3.5 transition disabled:opacity-50"
        >
          {pending ? '…' : 'Request OTP'}
        </button>
      </div>

      <label className="block text-[11px] font-semibold text-ink-500 uppercase tracking-wider mt-5 mb-2" htmlFor="otp">
        6-digit OTP
      </label>
      <input
        id="otp" value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
        placeholder="••••••" inputMode="numeric"
        className="w-full border border-line rounded-lg px-3.5 py-2.5 text-[16px] tracking-[.4em] text-center outline-none focus:border-brand-400 transition font-mono"
      />

      <button
        type="button" onClick={verify} disabled={pending || otp.length < 6}
        className="mt-5 w-full bg-brand-500 hover:bg-brand-600 text-white text-[14px] font-semibold rounded-lg py-3 transition disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {pending ? 'Checking…' : 'Verify & continue'}
      </button>

      <div className="flex items-center justify-between mt-4 text-[12px]">
        <a href="/forgot-password" className="text-ink-500 hover:text-brand-600">Forgot password?</a>
        <span className="text-ink-400 font-mono">guard · step 1-2/6</span>
      </div>
    </div>
  );
}

function RoleLabel(r: Role): string {
  const map: Record<Role, string> = {
    viewer: 'Viewer', support: 'Support', ops: 'Ops',
    marketing: 'Marketing', finance: 'Finance', owner: 'Owner',
  };
  return map[r];
}
