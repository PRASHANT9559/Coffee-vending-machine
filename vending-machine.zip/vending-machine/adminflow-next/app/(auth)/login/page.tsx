import type { Metadata } from 'next';
import LoginForm from './login-form';
import { DEMO_ADMINS, ROLES } from '@/lib/auth';

export const metadata: Metadata = { title: 'Sign in · Manhattan Coffee Admin' };

/* Auth route 1 of 3 — phone + OTP. Role chips are a demo affordance
   mapping the 6 admin roles (production reads role from admin_users). */
export default function LoginPage() {
  const roster = ROLES.map(r => {
    const a = DEMO_ADMINS.find(x => x.role === r)!;
    return { role: r, name: a.name, phone: a.phone };
  });
  return <LoginForm roster={roster} />;
}
