-- =============================================================================
--  COFFEE VENDING MACHINE ECOSYSTEM — PRODUCTION SCHEMA
--  PostgreSQL 15+ / Supabase compatible
--  Version: 1.0.0
--  Tables : 68 across 10 domains
-- =============================================================================
--
--  CONVENTIONS
--  ----------
--  * Primary key        : uuid  (entity tables) / bigint identity (append-only logs)
--  * Timestamps         : timestamptz, UTC everywhere
--  * Money              : store in paise as integer (BIGINT). NEVER float.
--  * Volatile vocab     : text + CHECK (easy to ALTER)
--  * Stable state machine: native ENUM (type safety)
--  * High-volume logs   : append-only, partitioned, never UPDATE/DELETE
--  * FK columns         : every one indexed (Postgres does NOT auto-index FKs)
--
--  RUN ORDER
--  --------
--    001_full_schema.sql   (this file)
--    002_functions.sql
--    003_views.sql
--    004_rls_policies.sql
--    005_seed.sql
--
-- =============================================================================

create extension if not exists "pgcrypto";
create extension if not exists "pg_trgm";


-- =============================================================================
--  ENUM TYPES
-- =============================================================================
create type machine_status     as enum ('provisioning','active','maintenance','offline','suspended','retired');
create type machine_mode       as enum ('hot','cold','off');
create type tank_status        as enum ('empty','mounted','in_use','draining','expired','disposed');
create type tank_event_type    as enum ('filled','mounted','unmounted','expired','disposed','topped_up');
create type item_type          as enum ('cup','kit','malai','coffee_powder','sugar','stirrer');
create type stock_reason       as enum ('dispense','refill','waste','audit_adjust','initial');
create type health_severity    as enum ('info','warn','error','critical');
create type command_type       as enum ('lock','unlock','reboot','heater_on','heater_off','set_temp','set_mode','test_dispense','flush_line','ota_update','factory_reset');
create type command_status     as enum ('queued','sent','acked','success','failed','expired');
create type maintenance_task   as enum ('tank_swap','cleaning','refill_cups','refill_kits','refill_malai','service','inspection');
create type order_status       as enum ('created','paid','authorised','dispensing','delivered','failed','refunded','cancelled','expired');
create type code_event_type    as enum ('created','shared','viewed','scanned','authorised','redeemed','rejected','expired','revoked');
create type payment_gateway    as enum ('razorpay','phonepe','paytm','cashfree','upi_mandate','manual','wallet','coins');
create type payment_status     as enum ('initiated','pending','success','failed','refunded','captured');
create type wallet_tx_type     as enum ('recharge','order','refund','coupon','bonus','referral','gift_redeem','admin_credit','admin_debit','expiry');
create type coin_tx_type       as enum ('ad_watch','ad_reward','redeem','referral','signup','streak','leaderboard','admin_credit','admin_debit','expiry');
create type ticket_status      as enum ('open','investigating','awaiting_customer','resolved_refund','resolved_reject','rejected','closed');
create type ticket_type        as enum ('no_coffee','no_kit','cup_stuck','payment_deducted','quality_issue','spill','other');
create type evidence_type      as enum ('camera_clip','sensor_log','dispense_log','utr','payment_screenshot','chat_transcript');
create type verdict            as enum ('pending','legit_issue','fraud','inconclusive');
create type camera_channel     as enum ('dispense','face','combo');
create type ref_status         as enum ('pending','qualified','rewarded','rejected','fraud');
create type period_status      as enum ('scheduled','live','closed','archived');
create type subscription_status as enum ('active','past_due','cancelled','expired','paused');
create type offer_type         as enum ('flat_discount','percent_discount','free_item','wallet_bonus','coin_bonus','free_delivery');
create type sub_entity_type    as enum ('user','admin','machine','system');


-- =============================================================================
--  SHARED TRIGGER: updated_at
-- =============================================================================
create or replace function fn_set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;


-- =============================================================================
--  DOMAIN 1 — IDENTITY & ACCESS  (8 tables)
-- =============================================================================

-- 1.1 ── users : core identity -----------------------------------------------------
create table users (
  id              uuid primary key default gen_random_uuid(),
  phone           text not null unique,
  country_code    text not null default '+91',
  status          text not null default 'active'
                    check (status in ('active','dormant','blocked','deleted','pending_verification')),
  is_verified     boolean not null default false,
  fcm_token       text,
  phone_verified_at timestamptz,
  referred_by     uuid references users(id) on delete set null,
  referrer_token  text unique,
  is_anonymous_leaderboard boolean not null default false,
  last_seen_at    timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz
);
comment on table users is 'Core user identity. One row per phone number. Never hard-delete — soft delete via deleted_at.';

create index idx_users_phone           on users (phone);
create index idx_users_referred_by     on users (referred_by);
create index idx_users_referrer_token  on users (referrer_token);
create index idx_users_status_created  on users (status, created_at desc);
create index idx_users_last_seen       on users (last_seen_at desc) where status = 'active';
create index idx_users_fcm             on users (fcm_token) where fcm_token is not null;

create trigger trg_users_updated_at before update on users
  for each row execute function fn_set_updated_at();

-- 1.2 ── user_profiles : mutable personal data ------------------------------------
create table user_profiles (
  user_id        uuid primary key references users(id) on delete cascade,
  display_name   text,
  avatar_url     text,
  date_of_birth  date,
  age_band       text check (age_band in ('under_18','18_24','25_34','35_44','45_plus','hidden')),
  gender         text check (gender in ('male','female','non_binary','prefer_not_to_say','hidden')),
  city           text,
  locality       text,
  college_work   text,
  bio            text,
  instagram_handle text,
  show_on_leaderboard   boolean not null default false,
  show_handle_publicly  boolean not null default false,
  show_avatar_publicly  boolean not null default true,
  terms_accepted_at     timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
comment on column user_profiles.show_handle_publicly is 'Separate opt-in from leaderboard visibility. Handle only rendered when both are true AND user confirmed by typing it.';
comment on column user_profiles.age_band is 'Used for safe leaderboard anonymisation — under_18 rows are masked regardless of opt-in flags.';

create index idx_profiles_city            on user_profiles (city);
create index idx_profiles_instagram       on user_profiles (instagram_handle) where instagram_handle is not null;
create index idx_profiles_leaderboard_opt on user_profiles (show_on_leaderboard) where show_on_leaderboard;

create trigger trg_profiles_updated_at before update on user_profiles
  for each row execute function fn_set_updated_at();

-- 1.3 ── user_devices --------------------------------------------------------------
create table user_devices (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references users(id) on delete cascade,
  device_id     text not null,
  platform      text not null check (platform in ('android','ios','web')),
  os_version    text,
  app_version   text,
  model         text,
  push_token    text,
  is_active     boolean not null default true,
  last_active_at timestamptz,
  created_at    timestamptz not null default now(),
  unique (user_id, device_id)
);
create index idx_devices_user   on user_devices (user_id);
create index idx_devices_token  on user_devices (push_token) where push_token is not null and is_active;

-- 1.4 ── user_consents : legal record ----------------------------------------------
create table user_consents (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references users(id) on delete cascade,
  consent_type  text not null
                  check (consent_type in ('privacy_policy','terms_of_service','marketing','leaderboard','camera','location','ad_personalisation','data_export')),
  policy_version text not null,
  granted       boolean not null,
  granted_at    timestamptz not null default now(),
  revoked_at    timestamptz,
  ip_address    inet,
  user_agent    text
);
comment on table user_consents is 'Immutable legal record. Never UPDATE granted_at; revoke by setting revoked_at. Required for DPDP audit.';
create index idx_consents_user    on user_consents (user_id, consent_type);
create index idx_consents_granted on user_consents (granted_at desc) where granted;

-- 1.5 ── user_preferences ----------------------------------------------------------
create table user_preferences (
  user_id            uuid primary key references users(id) on delete cascade,
  language           text not null default 'en' check (language in ('en','hi','mr','ta','te','bn','gu','kn','ml','pa')),
  push_offers        boolean not null default true,
  push_reminders     boolean not null default true,
  push_festivals     boolean not null default true,
  push_marketing     boolean not null default false,
  default_machine_id uuid,
  favourite_variant  text,
  reduced_data_mode  boolean not null default false,
  updated_at         timestamptz not null default now()
);
create trigger trg_prefs_updated_at before update on user_preferences
  for each row execute function fn_set_updated_at();

-- 1.6 ── user_fav_machines ---------------------------------------------------------
create table user_fav_machines (
  user_id      uuid not null references users(id) on delete cascade,
  machine_id   uuid not null,
  visit_count  integer not null default 0,
  last_visit_at timestamptz,
  created_at   timestamptz not null default now(),
  primary key (user_id, machine_id)
);
create index idx_fav_machine on user_fav_machines (machine_id);

-- 1.7 ── admin_users : SEPARATE security boundary ----------------------------------
create table admin_users (
  id            uuid primary key default gen_random_uuid(),
  email         text not null unique,
  password_hash text not null,
  full_name     text not null,
  mfa_secret    text,
  mfa_enabled   boolean not null default false,
  status        text not null default 'active' check (status in ('active','suspended','pending')),
  role          text not null default 'support'
                  check (role in ('viewer','support','ops','marketing','finance','owner')),
  failed_logins smallint not null default 0,
  locked_until  timestamptz,
  last_login_at timestamptz,
  last_login_ip inet,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index idx_admin_email_status on admin_users (email, status);
create trigger trg_admin_users_updated_at before update on admin_users
  for each row execute function fn_set_updated_at();

-- 1.8 ── admin_roles : RBAC --------------------------------------------------------
create table admin_roles (
  id           uuid primary key default gen_random_uuid(),
  name         text not null unique,
  permissions  jsonb not null default '{}'::jsonb,
  is_superadmin boolean not null default false,
  created_at   timestamptz not null default now()
);
comment on column admin_roles.permissions is 'JSON: {"machine.lock":true,"pricing.edit":false,"refund.approve":true}';
create index idx_admin_roles_perms on admin_roles using gin (permissions);

-- 1.10 ── otp_codes : short-lived login / recovery OTPs -----------------------------
-- Queried by the Rust `otp_verify_handler`. Codes are single-use and time-boxed.
create table otp_codes (
  id         uuid primary key default gen_random_uuid(),
  email      text not null,
  code       text not null,
  purpose    text not null default 'login' check (purpose in ('login','recovery','mfa_reset')),
  used       boolean not null default false,
  attempts   smallint not null default 0,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index idx_otp_email_created on otp_codes (lower(email), created_at desc);
create index idx_otp_active on otp_codes (expires_at) where used = false;


-- =============================================================================
--  DOMAIN 2 — MACHINE / IoT  (10 tables)
-- =============================================================================

-- 2.1 ── machines ------------------------------------------------------------------
create table machines (
  id                uuid primary key default gen_random_uuid(),
  machine_code      text not null unique,
  name              text not null,
  status            machine_status not null default 'provisioning',
  mode              machine_mode not null default 'hot',
  firmware_version  text,
  sim_msisdn        text,
  sim_iccid         text,
  latitude          numeric(10,7),
  longitude         numeric(10,7),
  address_line      text,
  city              text,
  locality          text,
  place_id          text,
  timezone          text not null default 'Asia/Kolkata',
  target_temp_c     numeric(4,1) not null default 65.0 check (target_temp_c between 40 and 90),
  cup_stack_count   integer not null default 0 check (cup_stack_count >= 0),
  max_cup_stack     integer not null default 200,
  is_locked         boolean not null default false,
  lock_reason       text,
  last_ping_at      timestamptz,
  last_seen_at      timestamptz,
  commissioned_at   timestamptz,
  notes             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index idx_machines_status   on machines (status);
create index idx_machines_city     on machines (city) where status = 'active';
create index idx_machines_lastseen on machines (last_seen_at desc);
create index idx_machines_geo      on machines (latitude, longitude) where status = 'active';
create trigger trg_machines_updated_at before update on machines
  for each row execute function fn_set_updated_at();

-- 2.2 ── machine_tanks : swappable tank identity (core hygiene tracking) -----------
create table machine_tanks (
  id            uuid primary key default gen_random_uuid(),
  tank_uid      text not null unique,
  machine_id    uuid references machines(id) on delete set null,
  capacity_l    numeric(6,2) not null check (capacity_l > 0),
  filled_l      numeric(6,2) check (filled_l >= 0),
  filled_at     timestamptz,
  max_hold_hours integer not null default 12 check (max_hold_hours between 1 and 24),
  expires_at    timestamptz generated always as
                  (case when filled_at is null then null else filled_at + (max_hold_hours || ' hours')::interval end) stored,
  mounted_at    timestamptz,
  unmounted_at  timestamptz,
  status        tank_status not null default 'empty',
  min_temp_c    numeric(4,1) not null default 60.0,
  max_temp_c    numeric(4,1) not null default 75.0,
  source        text,
  batch_ref     text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
comment on table machine_tanks is 'Every physical tank is a tracked object with its own lifecycle. Drives the "fresh tank 2h ago" app badge and FSSAI evidence.';
create index idx_tanks_machine  on machine_tanks (machine_id);
create index idx_tanks_status   on machine_tanks (status);
create index idx_tanks_expires  on machine_tanks (expires_at) where status in ('mounted','in_use');
create trigger trg_tanks_updated_at before update on machine_tanks
  for each row execute function fn_set_updated_at();

-- 2.3 ── machine_tank_events : append-only ----------------------------------------
create table machine_tank_events (
  id          bigint generated always as identity primary key,
  tank_id     uuid not null references machine_tanks(id) on delete cascade,
  machine_id  uuid references machines(id) on delete set null,
  event_type  tank_event_type not null,
  litres      numeric(6,2),
  temp_c      numeric(4,1),
  actor_id    uuid references admin_users(id) on delete set null,
  notes       text,
  recorded_at timestamptz not null default now()
);
create index idx_tank_events_tank    on machine_tank_events (tank_id, recorded_at desc);
create index idx_tank_events_machine on machine_tank_events (machine_id, recorded_at desc);

-- 2.4 ── machine_stock -------------------------------------------------------------
create table machine_stock (
  id          uuid primary key default gen_random_uuid(),
  machine_id  uuid not null references machines(id) on delete cascade,
  item_type   item_type not null,
  variant_key text not null default 'default',
  quantity    integer not null default 0 check (quantity >= 0),
  reorder_threshold integer not null default 0,
  updated_at  timestamptz not null default now(),
  unique (machine_id, item_type, variant_key)
);
create index idx_stock_machine on machine_stock (machine_id);
create index idx_stock_low     on machine_stock (machine_id) where quantity <= reorder_threshold;

create trigger trg_stock_updated_at before update on machine_stock
  for each row execute function fn_set_updated_at();

-- 2.5 ── machine_stock_events : append-only ---------------------------------------
create table machine_stock_events (
  id          bigint generated always as identity primary key,
  machine_id  uuid not null references machines(id) on delete cascade,
  item_type   item_type not null,
  variant_key text not null default 'default',
  delta       integer not null,
  reason      stock_reason not null,
  order_id    uuid,
  actor_id    uuid references admin_users(id) on delete set null,
  balance_after integer,
  recorded_at timestamptz not null default now()
);
create index idx_stock_events_machine on machine_stock_events (machine_id, recorded_at desc);
create index idx_stock_events_order   on machine_stock_events (order_id) where order_id is not null;

-- 2.6 ── machine_telemetry : PARTITIONED by month --------------------------------
create table machine_telemetry (
  id            bigint generated always as identity,
  machine_id    uuid not null,
  recorded_at   timestamptz not null default now(),
  milk_temp_c   numeric(4,1),
  milk_level_l  numeric(6,2),
  malai_level_l numeric(6,2),
  signal_dbm    smallint,
  cup_count     integer,
  kit_count     integer,
  is_locked     boolean,
  heater_on     boolean,
  fault_code    text,
  primary key (id, recorded_at)
) partition by range (recorded_at);

comment on table machine_telemetry is 'High volume. Partition monthly. Raw retention 90 days, then roll up to hourly averages. NEVER queried without machine_id + time range.';
create index idx_telemetry_machine_time on machine_telemetry (machine_id, recorded_at desc);
create table machine_telemetry_default partition of machine_telemetry default;

-- 2.7 ── machine_health_logs ------------------------------------------------------
create table machine_health_logs (
  id          bigint generated always as identity primary key,
  machine_id  uuid not null references machines(id) on delete cascade,
  severity    health_severity not null,
  fault_code  text not null
                check (fault_code in ('JAM','CLOG','VALVE_FAIL','PUMP_FAIL','SENSOR_FAIL','IR_FAIL',
                                      'CONVEYOR_FAIL','DOOR_OPEN','TEMP_HIGH','TEMP_LOW','NETWORK_FAIL',
                                      'SIM_FAIL','MQTT_FAIL','STEPPER_FAIL','SERVO_FAIL','WDT_RESET','UNKNOWN')),
  message     text,
  context     jsonb,
  auto_resolved boolean not null default false,
  resolved_at timestamptz,
  resolved_by uuid references admin_users(id) on delete set null,
  recorded_at timestamptz not null default now()
);
create index idx_health_machine on machine_health_logs (machine_id, recorded_at desc);
create index idx_health_open     on machine_health_logs (machine_id) where resolved_at is null;
create index idx_health_fault    on machine_health_logs (fault_code, recorded_at desc);

-- 2.8 ── machine_commands : remote command queue ----------------------------------
create table machine_commands (
  id           uuid primary key default gen_random_uuid(),
  machine_id   uuid not null references machines(id) on delete cascade,
  command_type command_type not null,
  payload      jsonb not null default '{}'::jsonb,
  status       command_status not null default 'queued',
  requested_by uuid references admin_users(id) on delete set null,
  requested_at timestamptz not null default now(),
  sent_at      timestamptz,
  acked_at     timestamptz,
  completed_at timestamptz,
  expires_at   timestamptz default (now() + interval '2 minutes'),
  result       jsonb,
  error        text
);
comment on table machine_commands is 'Every OTA/remote action is a row. Machine polls or receives via MQTT. Full audit trail of who locked what and when.';
create index idx_commands_pending on machine_commands (machine_id, requested_at desc) where status in ('queued','sent');
create index idx_commands_requested on machine_commands (requested_at desc);

-- 2.9 ── machine_maintenance_logs -------------------------------------------------
create table machine_maintenance_logs (
  id          bigint generated always as identity primary key,
  machine_id  uuid not null references machines(id) on delete cascade,
  task        maintenance_task not null,
  performed_by uuid references admin_users(id) on delete set null,
  tank_id     uuid references machine_tanks(id) on delete set null,
  cups_added  integer,
  kits_added  integer,
  malai_added numeric(6,2),
  duration_min integer,
  notes       text,
  performed_at timestamptz not null default now()
);
create index idx_maint_machine on machine_maintenance_logs (machine_id, performed_at desc);
create index idx_maint_date    on machine_maintenance_logs (performed_at desc);

-- 2.10 ── machine_firmware_versions ------------------------------------------------
create table machine_firmware_versions (
  id            uuid primary key default gen_random_uuid(),
  version       text not null unique,
  binary_url    text not null,
  binary_sha256 text not null,
  size_bytes    bigint,
  release_notes text,
  is_rollback_target boolean not null default false,
  is_stable     boolean not null default true,
  released_by   uuid references admin_users(id) on delete set null,
  released_at   timestamptz not null default now()
);
create index idx_fw_version on machine_firmware_versions (version);


-- =============================================================================
--  DOMAIN 3 — CATALOG  (4 tables)
-- =============================================================================

-- 3.1 ── products ------------------------------------------------------------------
create table products (
  id             uuid primary key default gen_random_uuid(),
  slug           text not null unique,
  name           text not null,
  short_name     text not null,
  tagline        text,
  description    text,
  milk_ml        integer not null check (milk_ml > 0),
  malai_ml       integer not null default 0 check (malai_ml >= 0),
  cup_gsm        integer,
  has_malai      boolean not null default false,
  is_seasonal    boolean not null default false,
  season         text check (season in ('hot','cold','both')),
  display_order  integer not null default 0,
  image_url      text,
  is_active      boolean not null default true,
  is_stockout_visible boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index idx_products_active  on products (is_active, display_order);
create index idx_products_slug    on products (slug);
create trigger trg_products_updated_at before update on products
  for each row execute function fn_set_updated_at();

-- 3.2 ── product_prices : time-bound, history preserved ---------------------------
create table product_prices (
  id         bigint generated always as identity primary key,
  product_id uuid not null references products(id) on delete cascade,
  price_paise integer not null check (price_paise > 0),
  season     text not null default 'both' check (season in ('hot','cold','both')),
  valid_from timestamptz not null default now(),
  valid_to   timestamptz,
  created_by uuid references admin_users(id) on delete set null,
  created_at timestamptz not null default now(),
  check (valid_to is null or valid_to > valid_from)
);
create index idx_prices_product on product_prices (product_id, valid_from desc);
create index idx_prices_active  on product_prices (product_id) where valid_to is null;

-- 3.3 ── kit_templates -------------------------------------------------------------
create table kit_templates (
  id            uuid primary key default gen_random_uuid(),
  product_id    uuid references products(id) on delete cascade,
  name          text not null,
  cup_gsm       integer not null default 250,
  coffee_grams  numeric(5,2) not null default 0,
  sugar_grams   numeric(5,2) not null default 0,
  stirrer_qty   integer not null default 1,
  pouch_grams   numeric(5,2),
  unit_cost_paise integer not null default 0,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index idx_kit_product on kit_templates (product_id) where is_active;
create trigger trg_kit_updated_at before update on kit_templates
  for each row execute function fn_set_updated_at();

-- 3.4 ── kit_components ------------------------------------------------------------
create table kit_components (
  id            bigint generated always as identity primary key,
  template_id   uuid not null references kit_templates(id) on delete cascade,
  component     text not null
                  check (component in ('cup','coffee','sugar','stirrer','pouch','malai','cocoa','choco_chip','ice_brew')),
  quantity      numeric(8,2) not null check (quantity > 0),
  unit          text not null,
  unit_cost_paise integer not null default 0
);
create index idx_kitcomp_template on kit_components (template_id);


-- =============================================================================
--  DOMAIN 4 — CODES & ORDERS  (8 tables)
-- =============================================================================

-- 4.1 ── code_batches --------------------------------------------------------------
create table code_batches (
  id             uuid primary key default gen_random_uuid(),
  batch_ref      text not null unique,
  product_id     uuid references products(id) on delete set null,
  qty            integer not null check (qty > 0),
  generated_qty  integer not null default 0,
  redeemed_qty   integer not null default 0,
  campaign_tag   text,
  cost_basis_paise bigint not null default 0,
  created_by     uuid references admin_users(id) on delete set null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index idx_batches_tag on code_batches (campaign_tag, created_at desc);
create trigger trg_batches_updated_at before update on code_batches
  for each row execute function fn_set_updated_at();

-- 4.2 ── qr_codes : THE core voucher object ---------------------------------------
create table qr_codes (
  id              uuid primary key default gen_random_uuid(),
  code_hash       text not null unique,   -- sha256(full_code). Lookup + leak-proof.
  random_id       text not null unique,   -- human-readable part, e.g. rjivxxch68
  signature       text not null,          -- truncated HMAC-SHA256, verified offline by machine
  batch_id        uuid references code_batches(id) on delete set null,
  user_id         uuid references users(id) on delete set null,  -- NULL for ad-earned / gifted
  product_id      uuid not null references products(id) on delete restrict,
  amount_paise    integer not null check (amount_paise > 0),
  cost_basis_paise integer not null default 0,
  -- AFFINITY: offline double-spend prevention. Empty array = any machine in fleet.
  machine_ids     uuid[] not null default '{}',
  issued_at       timestamptz not null default now(),
  expires_at      timestamptz not null,
  delivered       boolean not null default false,
  delivered_at    timestamptz,
  redeemed_order_id uuid,
  source          text not null default 'purchase'
                   check (source in ('purchase','ad_reward','referral','signup_bonus','gifted','campaign','admin')),
  share_count     integer not null default 0,
  created_at      timestamptz not null default now(),
  check (expires_at > issued_at)
);
comment on table qr_codes is 'Pre-generated single-use voucher. Static-code model: machine verifies HMAC + delivered flag in LOCAL FLASH, so redemption works fully offline. Signature is computed server-side from the secret key, never stored in plaintext payload form.';
create index idx_qr_user      on qr_codes (user_id, issued_at desc) where user_id is not null;
create index idx_qr_batch     on qr_codes (batch_id) where batch_id is not null;
create index idx_qr_unredeemed on qr_codes (expires_at) where delivered = false;
create index idx_qr_pending_delivery on qr_codes (user_id) where delivered = false;
create index idx_qr_machine_affinity on qr_codes using gin (machine_ids);
create index idx_qr_source    on qr_codes (source, issued_at desc);

-- 4.3 ── qr_code_events : lifecycle audit, append-only ----------------------------
create table qr_code_events (
  id         bigint generated always as identity primary key,
  code_id    uuid not null references qr_codes(id) on delete cascade,
  event_type code_event_type not null,
  actor_user_id uuid references users(id) on delete set null,
  machine_id uuid references machines(id) on delete set null,
  ip_address inet,
  metadata   jsonb,
  recorded_at timestamptz not null default now()
);
create index idx_qr_events_code    on qr_code_events (code_id, recorded_at);
create index idx_qr_events_machine on qr_code_events (machine_id, recorded_at desc) where machine_id is not null;

-- 4.4 ── orders --------------------------------------------------------------------
create table orders (
  id              uuid primary key default gen_random_uuid(),
  order_no        text not null unique,
  code_id         uuid references qr_codes(id) on delete set null,
  user_id         uuid references users(id) on delete set null,
  machine_id      uuid not null references machines(id) on delete restrict,
  product_id      uuid not null references products(id) on delete restrict,
  amount_paise    integer not null check (amount_paise >= 0),
  discount_paise  integer not null default 0,
  tax_paise       integer not null default 0,
  final_paise     integer not null check (final_paise >= 0),
  cost_basis_paise integer not null default 0,
  payment_method  payment_gateway not null,
  coupon_id       uuid,
  status          order_status not null default 'created',
  is_subscription boolean not null default false,
  ordered_at      timestamptz not null default now(),
  authorised_at   timestamptz,
  dispensing_at   timestamptz,
  delivered_at    timestamptz,
  failure_reason  text,
  offline_synced  boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
comment on column orders.offline_synced is 'TRUE when order was dispensed while machine had no uplink. On reconnect, server must reconcile against local logs.';
create index idx_orders_user      on orders (user_id, ordered_at desc) where user_id is not null;
create index idx_orders_machine   on orders (machine_id, ordered_at desc);
create index idx_orders_status    on orders (status, ordered_at desc);
create index idx_orders_product   on orders (product_id, ordered_at desc);
create index idx_orders_unsynced  on orders (offline_synced) where offline_synced = false;
create index idx_orders_no        on orders (order_no);
create index idx_orders_analytics on orders (ordered_at, product_id, machine_id);
create trigger trg_orders_updated_at before update on orders
  for each row execute function fn_set_updated_at();

-- 4.5 ── order_items : future combo/multi-item support ----------------------------
create table order_items (
  id           bigint generated always as identity primary key,
  order_id     uuid not null references orders(id) on delete cascade,
  product_id   uuid not null references products(id) on delete restrict,
  quantity     integer not null default 1 check (quantity > 0),
  unit_paise   integer not null check (unit_paise >= 0),
  total_paise  integer not null check (total_paise >= 0)
);
create index idx_orderitems_order on order_items (order_id);

-- 4.6 ── dispense_logs : APPEND-ONLY FRAUD EVIDENCE -------------------------------
create table dispense_logs (
  id            bigint generated always as identity primary key,
  order_id      uuid not null references orders(id) on delete cascade,
  machine_id    uuid not null references machines(id) on delete restrict,
  code_id       uuid references qr_codes(id) on delete set null,
  valve_open_ms integer not null default 0,
  flow_pulses   integer not null default 0,
  dispensed_ml  numeric(6,2) not null default 0,
  expected_ml   numeric(6,2) not null default 0,
  variance_pct  numeric(5,2) generated always as
                  (case when expected_ml > 0
                        then round(((dispensed_ml - expected_ml) / expected_ml) * 100, 2)
                        else null end) stored,
  cup_detected  boolean not null default false,
  cup_detect_ts timestamptz,
  kit_dropped   boolean not null default false,
  malai_pumped_ms integer not null default 0,
  conveyor_steps integer,
  window_opened boolean not null default false,
  window_opened_at timestamptz,
  pickup_detected boolean not null default false,
  watchdog_resets smallint not null default 0,
  firmware_version text,
  recorded_at   timestamptz not null default now()
);
comment on table dispense_logs is 'IMMUTABLE. Append-only fraud evidence for dispute resolution. Never UPDATE or DELETE — retention enforced by purge job only after dispute window (180 days) closes.';
create index idx_dispense_order   on dispense_logs (order_id);
create index idx_dispense_machine on dispense_logs (machine_id, recorded_at desc);
create index idx_dispense_variance on dispense_logs (machine_id, recorded_at desc) where abs(coalesce(variance_pct,0)) > 15;

-- 4.7 ── payment_transactions ------------------------------------------------------
create table payment_transactions (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid references users(id) on delete set null,
  order_id         uuid references orders(id) on delete set null,
  subscription_id  uuid,
  gateway          payment_gateway not null,
  gateway_order_id text,
  gateway_payment_id text,
  utr              text,
  amount_paise     integer not null check (amount_paise > 0),
  fee_paise        integer not null default 0,
  status           payment_status not null default 'initiated',
  method_detail    text,
  raw_payload      jsonb,
  initiated_at     timestamptz not null default now(),
  captured_at      timestamptz,
  failed_reason    text,
  created_at       timestamptz not null default now()
);
create index idx_pay_user    on payment_transactions (user_id, initiated_at desc);
create index idx_pay_order   on payment_transactions (order_id) where order_id is not null;
create index idx_pay_utr     on payment_transactions (utr) where utr is not null;
create index idx_pay_gw_order on payment_transactions (gateway, gateway_order_id);
create index idx_pay_status  on payment_transactions (status, initiated_at desc);

-- 4.8 ── refunds -------------------------------------------------------------------
create table refunds (
  id            uuid primary key default gen_random_uuid(),
  refund_no     text not null unique,
  order_id      uuid not null references orders(id) on delete restrict,
  payment_tx_id uuid references payment_transactions(id) on delete set null,
  user_id       uuid references users(id) on delete set null,
  amount_paise  integer not null check (amount_paise > 0),
  destination   text not null default 'original'
                  check (destination in ('original','wallet','coins','replacement_code')),
  reason        text not null,
  verdict       verdict,
  approved_by   uuid references admin_users(id) on delete set null,
  gateway_ref   text,
  status        payment_status not null default 'pending',
  requested_at  timestamptz not null default now(),
  processed_at  timestamptz,
  created_at    timestamptz not null default now()
);
create index idx_refunds_order  on refunds (order_id);
create index idx_refunds_status on refunds (status, requested_at desc);


-- =============================================================================
--  DOMAIN 5 — WALLET, COINS, COUPONS  (6 tables)
-- =============================================================================

-- 5.1 ── wallets -------------------------------------------------------------------
create table wallets (
  user_id         uuid primary key references users(id) on delete cascade,
  balance_paise   bigint not null default 0 check (balance_paise >= 0),
  locked_paise    bigint not null default 0 check (locked_paise >= 0),
  lifetime_added_paise  bigint not null default 0,
  lifetime_spent_paise  bigint not null default 0,
  last_transaction_at   timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  check (balance_paise >= locked_paise)
);
comment on table wallets is 'Prepaid float. Money collected at recharge is already yours; unspent balance is a liability on your books, not revenue. Track lifetime_added/spent for reconciliation.';
create trigger trg_wallets_updated_at before update on wallets
  for each row execute function fn_set_updated_at();

-- 5.2 ── wallet_transactions : append-only ledger ---------------------------------
create table wallet_transactions (
  id             bigint generated always as identity primary key,
  user_id        uuid not null references users(id) on delete restrict,
  tx_type        wallet_tx_type not null,
  direction      text not null check (direction in ('credit','debit')),
  amount_paise   bigint not null check (amount_paise > 0),
  balance_after  bigint not null check (balance_after >= 0),
  ref_type       text,
  ref_id         uuid,
  payment_tx_id  uuid references payment_transactions(id) on delete set null,
  order_id       uuid references orders(id) on delete set null,
  description    text,
  metadata       jsonb,
  created_at     timestamptz not null default now()
);
comment on column wallet_transactions.balance_after is 'MANDATORY running balance. This is the reconciliation trail — without it you cannot answer "mera paisa kahan gaya".';
create index idx_wtx_user    on wallet_transactions (user_id, created_at desc);
create index idx_wtx_order   on wallet_transactions (order_id) where order_id is not null;
create index idx_wtx_type    on wallet_transactions (tx_type, created_at desc);
create index idx_wtx_created on wallet_transactions (created_at desc);

-- 5.3 ── coin_balances -------------------------------------------------------------
create table coin_balances (
  user_id           uuid primary key references users(id) on delete cascade,
  coins             integer not null default 0 check (coins >= 0),
  lifetime_earned   integer not null default 0,
  lifetime_spent    integer not null default 0,
  ad_watch_count    integer not null default 0,
  last_ad_at        timestamptz,
  updated_at        timestamptz not null default now()
);
create trigger trg_coins_updated_at before update on coin_balances
  for each row execute function fn_set_updated_at();

-- 5.4 ── coin_transactions ---------------------------------------------------------
create table coin_transactions (
  id          bigint generated always as identity primary key,
  user_id     uuid not null references users(id) on delete restrict,
  tx_type     coin_tx_type not null,
  direction   text not null check (direction in ('credit','debit')),
  coins       integer not null check (coins > 0),
  balance_after integer not null check (balance_after >= 0),
  ref_type    text,
  ref_id      uuid,
  ad_network  text,
  postback_status text not null default 'n/a'
                  check (postback_status in ('n/a','pending','confirmed','failed')),
  created_at  timestamptz not null default now()
);
create index idx_ctx_user   on coin_transactions (user_id, created_at desc);
create index idx_ctx_type   on coin_transactions (tx_type, created_at desc);
create index idx_ctx_postback on coin_transactions (postback_status) where postback_status = 'pending';

-- 5.5 ── coupons -------------------------------------------------------------------
create table coupons (
  id             uuid primary key default gen_random_uuid(),
  code           text not null unique,
  description    text,
  discount_type  text not null check (discount_type in ('flat','percent','free_item','wallet_bonus')),
  value          integer not null check (value > 0),
  max_discount_paise integer,
  min_order_paise integer not null default 0,
  usage_limit    integer,
  per_user_limit integer not null default 1,
  used_count     integer not null default 0,
  is_active      boolean not null default true,
  starts_at      timestamptz not null default now(),
  expires_at     timestamptz not null,
  created_by     uuid references admin_users(id) on delete set null,
  created_at     timestamptz not null default now(),
  check (expires_at > starts_at)
);
create index idx_coupons_active on coupons (is_active, expires_at) where is_active;
create index idx_coupons_code   on coupons (lower(code));

-- 5.6 ── coupon_redemptions --------------------------------------------------------
create table coupon_redemptions (
  id             bigint generated always as identity primary key,
  coupon_id      uuid not null references coupons(id) on delete cascade,
  user_id        uuid not null references users(id) on delete cascade,
  order_id       uuid references orders(id) on delete set null,
  discount_paise integer not null check (discount_paise >= 0),
  created_at     timestamptz not null default now()
);
create index idx_couponred_coupon on coupon_redemptions (coupon_id);
create index idx_couponred_user   on coupon_redemptions (user_id, created_at desc);
create unique index uq_coupon_user_order on coupon_redemptions (coupon_id, user_id, order_id) where order_id is not null;


-- =============================================================================
--  DOMAIN 6 — GROWTH & SOCIAL  (8 tables)
-- =============================================================================

-- 6.1 ── referrals -----------------------------------------------------------------
create table referrals (
  id             uuid primary key default gen_random_uuid(),
  referrer_id    uuid not null references users(id) on delete cascade,
  referee_id     uuid not null unique references users(id) on delete cascade,
  referrer_token text not null,
  status         ref_status not null default 'pending',
  referrer_reward_paise integer not null default 0,
  referee_reward_paise   integer not null default 0,
  rewarded_at    timestamptz,
  device_fingerprint text,
  ip_address     inet,
  created_at     timestamptz not null default now()
);
comment on column referrals.device_fingerprint is 'Anti-self-referral. Same device cannot generate a second referral reward.';
create index idx_ref_referrer on referrals (referrer_id, created_at desc);
create index idx_ref_status   on referrals (status, created_at desc);
create index idx_ref_token    on referrals (referrer_token);

-- 6.2 ── gifts ---------------------------------------------------------------------
create table gifts (
  id            uuid primary key default gen_random_uuid(),
  code_id       uuid not null unique references qr_codes(id) on delete cascade,
  from_user_id  uuid references users(id) on delete set null,
  to_phone      text,
  to_user_id    uuid references users(id) on delete set null,
  message       text,
  share_channel text check (share_channel in ('whatsapp','sms','email','copy','telegram','instagram','other','in_app')),
  status        text not null default 'sent' check (status in ('sent','viewed','redeemed','expired','cancelled')),
  viewed_at     timestamptz,
  redeemed_at   timestamptz,
  created_at    timestamptz not null default now()
);
create index idx_gifts_from   on gifts (from_user_id, created_at desc) where from_user_id is not null;
create index idx_gifts_phone  on gifts (to_phone);
create index idx_gifts_status on gifts (status, created_at desc);

-- 6.3 ── leaderboard_periods -------------------------------------------------------
create table leaderboard_periods (
  id          uuid primary key default gen_random_uuid(),
  period_key  text not null unique,       -- '2026-09'
  label       text not null,              -- 'September 2026'
  starts_at   timestamptz not null,
  ends_at     timestamptz not null,
  status      period_status not null default 'scheduled',
  scoring_formula text,
  finalised_at timestamptz,
  created_at  timestamptz not null default now(),
  check (ends_at > starts_at)
);
create index idx_period_status on leaderboard_periods (status, starts_at desc);

-- 6.4 ── leaderboard_entries : anti-farm weighted score ----------------------------
create table leaderboard_entries (
  id              uuid primary key default gen_random_uuid(),
  period_id       uuid not null references leaderboard_periods(id) on delete cascade,
  user_id         uuid not null references users(id) on delete cascade,
  orders_count    integer not null default 0,
  distinct_days   integer not null default 0,
  friend_orders   integer not null default 0,
  total_paise     bigint not null default 0,
  weighted_score  numeric(10,2) not null default 0,
  rank            integer,
  prev_rank       integer,
  is_verified     boolean not null default false,
  is_masked       boolean not null default false,  -- true for under-18 / opted-out
  is_eligible     boolean not null default true,  -- false if excluded by admin
  updated_at      timestamptz not null default now(),
  unique (period_id, user_id)
);
comment on column leaderboard_entries.weighted_score is 'Anti-farm: orders + (distinct_days * 0.5) - (friend_orders * 0.3). A burst of 20 same-day orders scores 20.5; a genuine 20 orders over 15 days scores 27.5.';
comment on column leaderboard_entries.is_masked is 'Rendered as anonymous regardless of user privacy flags — set for under-18 or admin-excluded accounts.';
create index idx_lb_period_rank  on leaderboard_entries (period_id, weighted_score desc);
create index idx_lb_user         on leaderboard_entries (user_id, period_id);
create index idx_lb_rank_lookup  on leaderboard_entries (period_id, rank);
create trigger trg_lb_entries_updated_at before update on leaderboard_entries
  for each row execute function fn_set_updated_at();

-- 6.5 ── leaderboard_prizes ---------------------------------------------------------
create table leaderboard_prizes (
  id            uuid primary key default gen_random_uuid(),
  period_id     uuid not null references leaderboard_periods(id) on delete cascade,
  rank_from     integer not null check (rank_from > 0),
  rank_to       integer,
  scope         text not null default 'monthly' check (scope in ('monthly','weekly','all_time','special')),
  prize_type    text not null check (prize_type in ('subscription_months','wallet_bonus','coins','free_cups','feature_slot','merch')),
  prize_value   integer not null default 0,
  description   text,
  winner_user_id uuid references users(id) on delete set null,
  claimed_at    timestamptz,
  created_at    timestamptz not null default now()
);
create index idx_prizes_period on leaderboard_prizes (period_id, rank_from);

-- 6.6 ── badges ---------------------------------------------------------------------
create table badges (
  id            uuid primary key default gen_random_uuid(),
  code          text not null unique,
  name          text not null,
  description   text,
  icon_url      text,
  criteria_type text not null check (criteria_type in ('orders_count','streak_days','spend_paise','referrals','variety','leaderboard_rank','reviews','early_bird')),
  criteria_value integer not null,
  tier          text not null default 'bronze' check (tier in ('bronze','silver','gold','platinum','legend')),
  is_rare       boolean not null default false,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);
create index idx_badges_criteria on badges (criteria_type, criteria_value) where is_active;

-- 6.7 ── user_badges ----------------------------------------------------------------
create table user_badges (
  user_id     uuid not null references users(id) on delete cascade,
  badge_id    uuid not null references badges(id) on delete cascade,
  earned_at   timestamptz not null default now(),
  is_displayed boolean not null default false,
  is_pinned   boolean not null default false,
  primary key (user_id, badge_id)
);
create index idx_userbadges_badge on user_badges (badge_id, earned_at desc);

-- 6.8 ── user_stats : denormalised counters ---------------------------------------
create table user_stats (
  user_id             uuid primary key references users(id) on delete cascade,
  total_orders        integer not null default 0,
  total_redeemed      integer not null default 0,
  total_spent_paise   bigint not null default 0,
  total_saved_paise   bigint not null default 0,
  favourite_product_id uuid references products(id) on delete set null,
  current_streak      integer not null default 0,
  longest_streak      integer not null default 0,
  referral_count      integer not null default 0,
  coupons_redeemed    integer not null default 0,
  last_order_at       timestamptz,
  last_machine_id     uuid references machines(id) on delete set null,
  first_order_at      timestamptz,
  updated_at          timestamptz not null default now()
);
create index idx_stats_streak  on user_stats (current_streak desc);
create index idx_stats_recent on user_stats (last_order_at desc);
create trigger trg_stats_updated_at before update on user_stats
  for each row execute function fn_set_updated_at();


-- =============================================================================
--  DOMAIN 7 — ADS & SPONSORSHIP  (6 tables)
-- =============================================================================

-- 7.1 ── ad_impressions : highest volume, short retention -------------------------
create table ad_impressions (
  id           bigint generated always as identity primary key,
  user_id      uuid references users(id) on delete set null,
  ad_network   text not null,
  ad_unit      text not null,
  ad_id        text,
  is_rewarded  boolean not null default false,
  placement    text,
  country      text,
  ip_address   inet,
  created_at   timestamptz not null default now()
);
create index idx_adsimp_user    on ad_impressions (user_id, created_at desc);
create index idx_adsimp_created on ad_impressions (created_at desc);
create index idx_adsimp_network on ad_impressions (ad_network, created_at desc);

-- 7.2 ── ad_reward_events : postback-tracked, prevents infinite coin farming ------
create table ad_reward_events (
  id             bigint generated always as identity primary key,
  user_id        uuid not null references users(id) on delete cascade,
  ad_network     text not null,
  ad_id          text,
  coins_granted  integer not null default 0 check (coins_granted >= 0),
  postback_status text not null default 'pending'
                   check (postback_status in ('pending','confirmed','failed','reversed')),
  postback_payload jsonb,
  confirmed_at   timestamptz,
  failed_reason  text,
  created_at     timestamptz not null default now()
);
comment on table ad_reward_events is 'Coins are granted optimistically but marked PENDING. A reconciliation job demotes to FAILED if no network postback arrives — without this, a scripted client can farm infinite coins.';
create index idx_adreward_pending on ad_reward_events (created_at) where postback_status = 'pending';
create index idx_adreward_user    on ad_reward_events (user_id, created_at desc);

-- 7.3 ── ad_networks ---------------------------------------------------------------
create table ad_networks (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  sdk_key_enc bytea,
  app_id      text,
  ecpm_paise  numeric(8,2) not null default 0,
  reward_coins integer not null default 0,
  daily_cap   integer,
  is_active   boolean not null default true,
  config      jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger trg_adnet_updated_at before update on ad_networks
  for each row execute function fn_set_updated_at();

-- 7.4 ── ad_revenue_daily ----------------------------------------------------------
create table ad_revenue_daily (
  id           bigint generated always as identity primary key,
  ad_network_id uuid references ad_networks(id) on delete set null,
  report_date  date not null,
  impressions  integer not null default 0,
  rewarded_views integer not null default 0,
  clicks       integer not null default 0,
  revenue_paise bigint not null default 0,
  payout_paise bigint,
  is_reconciled boolean not null default false,
  created_at   timestamptz not null default now(),
  unique (ad_network_id, report_date)
);
create index idx_adrev_date on ad_revenue_daily (report_date desc);

-- 7.5 ── ad_spaces : machine surface inventory ------------------------------------
create table ad_spaces (
  id          uuid primary key default gen_random_uuid(),
  machine_id  uuid references machines(id) on delete cascade,
  surface     text not null check (surface in ('side_panel','front_fascia','display_idle','cup_print','sticker')),
  slot_code   text not null,
  dimensions  text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  unique (machine_id, slot_code)
);
create index idx_adspace_machine on ad_spaces (machine_id) where is_active;

-- 7.6 ── ad_space_bookings : rental revenue tracking ------------------------------
create table ad_space_bookings (
  id            uuid primary key default gen_random_uuid(),
  ad_space_id   uuid not null references ad_spaces(id) on delete cascade,
  advertiser_name text not null,
  contact_name  text,
  contact_phone text,
  contact_email text,
  months        integer not null default 1 check (months > 0),
  rate_paise    bigint not null check (rate_paise >= 0),
  amount_paise  bigint not null check (amount_paise >= 0),
  starts_on     date not null,
  ends_on       date not null,
  creative_url  text,
  invoice_no    text,
  invoice_status text not null default 'unpaid'
                  check (invoice_status in ('unpaid','partial','paid','overdue','cancelled')),
  amount_paid_paise bigint not null default 0,
  notes         text,
  created_at    timestamptz not null default now(),
  check (ends_on > starts_on)
);
create index idx_booking_space    on ad_space_bookings (ad_space_id, starts_on desc);
create index idx_booking_invoice  on ad_space_bookings (invoice_status, ends_on);
create index idx_booking_expiring on ad_space_bookings (ends_on) where invoice_status <> 'cancelled';


-- =============================================================================
--  DOMAIN 8 — SUPPORT & TRUST  (7 tables)
-- =============================================================================

-- 8.1 ── support_tickets -----------------------------------------------------------
create table support_tickets (
  id             uuid primary key default gen_random_uuid(),
  ticket_no      text not null unique,       -- TKT-104
  user_id        uuid references users(id) on delete set null,
  machine_id     uuid references machines(id) on delete set null,
  order_id       uuid references orders(id) on delete set null,
  payment_tx_id  uuid references payment_transactions(id) on delete set null,
  ticket_type    ticket_type not null,
  claim_amount_paise integer not null default 0,
  claimed_time   timestamptz,
  utr            text,
  user_message   text,
  auto_context   jsonb,     -- auto-pulled: nearby machines, last 5 orders, timestamps
  status         ticket_status not null default 'open',
  priority       smallint not null default 3 check (priority between 1 and 5),
  verdict        verdict not null default 'pending',
  assigned_to    uuid references admin_users(id) on delete set null,
  resolution     text,
  refund_id      uuid references refunds(id) on delete set null,
  whatsapp_sent_at timestamptz,
  resolved_at    timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
comment on column support_tickets.auto_context is 'Server-populated at creation so the customer never types manual details — reduces both fraud and effort.';
create index idx_ticket_no      on support_tickets (ticket_no);
create index idx_ticket_status  on support_tickets (status, priority, created_at desc);
create index idx_ticket_user    on support_tickets (user_id, created_at desc) where user_id is not null;
create index idx_ticket_machine on support_tickets (machine_id, created_at desc) where machine_id is not null;
create index idx_ticket_open    on support_tickets (created_at desc) where status in ('open','investigating');
create index idx_ticket_utr     on support_tickets (utr) where utr is not null;
create trigger trg_ticket_updated_at before update on support_tickets
  for each row execute function fn_set_updated_at();

-- 8.2 ── ticket_evidence : side-by-side camera + sensor proof ----------------------
create table ticket_evidence (
  id           bigint generated always as identity primary key,
  ticket_id    uuid not null references support_tickets(id) on delete cascade,
  evidence_type evidence_type not null,
  ref_table    text,
  ref_id       uuid,
  clip_start   timestamptz,
  clip_end     timestamptz,
  sensor_snapshot jsonb,
  note         text,
  added_by     uuid references admin_users(id) on delete set null,
  created_at   timestamptz not null default now()
);
create index idx_evidence_ticket on ticket_evidence (ticket_id);
create index idx_evidence_ref    on ticket_evidence (ref_table, ref_id);

-- 8.3 ── ticket_status_history -----------------------------------------------------
create table ticket_status_history (
  id          bigint generated always as identity primary key,
  ticket_id   uuid not null references support_tickets(id) on delete cascade,
  from_status ticket_status,
  to_status   ticket_status not null,
  from_verdict verdict,
  to_verdict  verdict,
  changed_by  uuid references admin_users(id) on delete set null,
  note        text,
  changed_at  timestamptz not null default now()
);
create index idx_tsh_ticket on ticket_status_history (ticket_id, changed_at);

-- 8.4 ── feedback_ratings ----------------------------------------------------------
create table feedback_ratings (
  id          bigint generated always as identity primary key,
  user_id     uuid references users(id) on delete set null,
  machine_id  uuid references machines(id) on delete set null,
  order_id    uuid references orders(id) on delete set null,
  rating      smallint not null check (rating between 1 and 5),
  tags        text[] not null default '{}',
  comment     text,
  coupon_id   uuid references coupons(id) on delete set null,
  coupon_given boolean not null default false,
  created_at  timestamptz not null default now()
);
create index idx_feedback_machine on feedback_ratings (machine_id, created_at desc);
create index idx_feedback_user    on feedback_ratings (user_id, created_at desc);
create index idx_feedback_rating  on feedback_ratings (rating) where rating <= 3;
create index idx_feedback_tags    on feedback_ratings using gin (tags);

-- 8.5 ── cameras -------------------------------------------------------------------
create table cameras (
  id           uuid primary key default gen_random_uuid(),
  machine_id   uuid not null references machines(id) on delete cascade,
  channel      camera_channel not null,
  name         text not null,
  rtsp_path    text,
  storage_type text not null default 'sd' check (storage_type in ('sd','cloud','hybrid')),
  sd_card_path text,
  retention_hours integer not null default 48,
  resolution    text not null default '720p',
  fps          smallint not null default 15,
  is_recording boolean not null default true,
  last_frame_at timestamptz,
  last_online_at timestamptz,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (machine_id, channel)
);
comment on table cameras is 'Continuous recording stays LOCAL on SD (48h rolling loop). Only clips extracted at ticket time are pushed to cloud. Avoids ~₹3.5L/month cloud storage cost.';
create index idx_cameras_machine on cameras (machine_id);
create index idx_cameras_online  on cameras (last_online_at desc) where is_recording;
create trigger trg_cameras_updated_at before update on cameras
  for each row execute function fn_set_updated_at();

-- 8.6 ── video_clips : cloud-stored, ticket-linked, auto-purged ------------------
create table video_clips (
  id            uuid primary key default gen_random_uuid(),
  camera_id     uuid not null references cameras(id) on delete cascade,
  machine_id    uuid references machines(id) on delete set null,
  clip_type     text not null default 'ticket' check (clip_type in ('ticket','incident','manual','snapshot')),
  linked_ticket_id uuid references support_tickets(id) on delete set null,
  start_at      timestamptz not null,
  end_at        timestamptz not null,
  duration_sec  integer generated always as (extract(epoch from (end_at - start_at))::int) stored,
  storage_path  text not null,
  size_mb       numeric(8,2),
  checksum      text,
  retention_expiry timestamptz not null default (now() + interval '30 days'),
  is_purged     boolean not null default false,
  purged_at     timestamptz,
  created_at    timestamptz not null default now(),
  check (end_at > start_at)
);
comment on column video_clips.retention_expiry is 'A purge job sets is_purged and deletes the object. Keep 30 days for disputes, purge 7 days after ticket closure.';
create index idx_clips_camera  on video_clips (camera_id, start_at desc);
create index idx_clips_ticket  on video_clips (linked_ticket_id) where linked_ticket_id is not null;
create index idx_clips_purge   on video_clips (retention_expiry) where is_purged = false;
create index idx_clips_window  on video_clips (machine_id, start_at, end_at);

-- 8.7 ── fraud_blacklist ------------------------------------------------------------
create table fraud_blacklist (
  id          uuid primary key default gen_random_uuid(),
  identifier_type text not null check (identifier_type in ('user','phone','utr','device_id','ip','card_hash')),
  identifier_value text not null,
  reason      text not null,
  severity    text not null default 'medium' check (severity in ('low','medium','high','permanent')),
  created_by  uuid references admin_users(id) on delete set null,
  expires_at  timestamptz,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);
create unique index uq_blacklist_ident on fraud_blacklist (identifier_type, identifier_value);
create index idx_blacklist_active on fraud_blacklist (identifier_type) where is_active;


-- =============================================================================
--  DOMAIN 9 — SUBSCRIPTION  (4 tables)
-- =============================================================================

-- 9.1 ── subscription_plans ---------------------------------------------------------
create table subscription_plans (
  id             uuid primary key default gen_random_uuid(),
  code           text not null unique,
  name           text not null,
  price_paise    integer not null check (price_paise > 0),
  duration_days  integer not null default 30,
  cups_included  integer,       -- NULL = unlimited
  is_unlimited   boolean not null default true,
  benefits       jsonb not null default '[]'::jsonb,
  min_machines   integer not null default 1,
  is_active      boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index idx_plans_active on subscription_plans (is_active) where is_active;
create trigger trg_plans_updated_at before update on subscription_plans
  for each row execute function fn_set_updated_at();

-- 9.2 ── user_subscriptions --------------------------------------------------------
create table user_subscriptions (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references users(id) on delete cascade,
  plan_id        uuid not null references subscription_plans(id) on delete restrict,
  status         subscription_status not null default 'active',
  starts_at      timestamptz not null default now(),
  ends_at        timestamptz not null,
  auto_renew     boolean not null default true,
  mandate_id     text,
  cups_used      integer not null default 0,
  paused_at      timestamptz,
  cancelled_at   timestamptz,
  cancel_reason  text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index idx_subs_user   on user_subscriptions (user_id, status);
create index idx_subs_active on user_subscriptions (ends_at) where status = 'active';
create index idx_subs_expiry on user_subscriptions (ends_at) where status in ('active','past_due');
create trigger trg_subs_updated_at before update on user_subscriptions
  for each row execute function fn_set_updated_at();

-- 9.3 ── subscription_invoices -----------------------------------------------------
create table subscription_invoices (
  id              uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references user_subscriptions(id) on delete cascade,
  user_id         uuid not null references users(id) on delete cascade,
  invoice_no      text not null unique,
  amount_paise    integer not null check (amount_paise > 0),
  period_start    timestamptz not null,
  period_end      timestamptz not null,
  payment_status  payment_status not null default 'pending',
  payment_tx_id   uuid references payment_transactions(id) on delete set null,
  paid_at         timestamptz,
  created_at      timestamptz not null default now()
);
create index idx_invoice_user on subscription_invoices (user_id, created_at desc);
create index idx_invoice_sub  on subscription_invoices (subscription_id);

-- 9.4 ── upi_mandates --------------------------------------------------------------
create table upi_mandates (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references users(id) on delete cascade,
  gateway        payment_gateway not null,
  mandate_id     text not null,
  vpa            text,
  max_amount_paise bigint not null,
  debit_count    integer not null default 0,
  total_debited_paise bigint not null default 0,
  first_debited_at timestamptz,
  last_debited_at  timestamptz,
  next_debit_at    timestamptz,
  status         text not null default 'active' check (status in ('active','paused','revoked','expired','failed')),
  raw_payload    jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (gateway, mandate_id)
);
create index idx_mandate_user   on upi_mandates (user_id, status);
create index idx_mandate_debit  on upi_mandates (next_debit_at) where status = 'active';
create trigger trg_mandate_updated_at before update on upi_mandates
  for each row execute function fn_set_updated_at();


-- =============================================================================
--  DOMAIN 10 — MARKETING & SYSTEM  (7 tables)
-- =============================================================================

-- 10.1 ── offers --------------------------------------------------------------------
create table offers (
  id             uuid primary key default gen_random_uuid(),
  code           text unique,
  name           text not null,
  offer_type     offer_type not null,
  value          integer not null check (value > 0),
  max_discount_paise integer,
  min_order_paise integer not null default 0,
  segment        jsonb not null default '{}'::jsonb,  -- {cities:[], machines:[], new_users_only:true}
  total_budget_paise bigint not null default 0,
  consumed_paise bigint not null default 0,
  usage_cap      integer,
  used_count     integer not null default 0,
  per_user_limit integer not null default 1,
  is_active      boolean not null default true,
  starts_at      timestamptz not null default now(),
  ends_at        timestamptz not null,
  created_by     uuid references admin_users(id) on delete set null,
  created_at     timestamptz not null default now(),
  check (ends_at > starts_at)
);
create index idx_offers_active on offers (is_active, starts_at, ends_at) where is_active;
create index idx_offers_seg    on offers using gin (segment);

-- 10.2 ── banners -------------------------------------------------------------------
create table banners (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  subtitle      text,
  image_url     text not null,
  placement     text not null default 'home_carousel'
                  check (placement in ('home_carousel','home_strip','splash','qr_success','wallet','leaderboard')),
  link_type     text not null default 'none'
                  check (link_type in ('none','offer','product','recharge','leaderboard','url','screen')),
  link_ref      text,
  deep_link     text,
  priority      smallint not null default 0,
  starts_at     timestamptz not null default now(),
  ends_at       timestamptz,
  is_active     boolean not null default true,
  impressions   integer not null default 0,
  clicks        integer not null default 0,
  created_by    uuid references admin_users(id) on delete set null,
  created_at    timestamptz not null default now()
);
create index idx_banners_slot on banners (placement, is_active, priority desc, starts_at);

-- 10.3 ── push_notifications --------------------------------------------------------
create table push_notifications (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  body          text not null,
  segment       jsonb not null default '{}'::jsonb,
  deep_link     text,
  category      text not null default 'general'
                  check (category in ('general','offer','reminder','festival','system','leaderboard','abandoned_qr')),
  scheduled_at  timestamptz,
  sent_at       timestamptz,
  target_count  integer not null default 0,
  sent_count    integer not null default 0,
  delivered_count integer not null default 0,
  opened_count  integer not null default 0,
  status        text not null default 'draft' check (status in ('draft','scheduled','sending','sent','failed','cancelled')),
  created_by    uuid references admin_users(id) on delete set null,
  created_at    timestamptz not null default now()
);
create index idx_push_sched  on push_notifications (scheduled_at) where status = 'scheduled';
create index idx_push_status on push_notifications (status, created_at desc);

-- 10.4 ── notification_deliveries ---------------------------------------------------
create table notification_deliveries (
  id              bigint generated always as identity primary key,
  notification_id uuid references push_notifications(id) on delete cascade,
  user_id         uuid not null references users(id) on delete cascade,
  status          text not null default 'queued'
                    check (status in ('queued','sent','delivered','opened','failed','bounced')),
  opened_at       timestamptz,
  created_at      timestamptz not null default now()
);
create index idx_notifdel_user    on notification_deliveries (user_id, created_at desc);
create index idx_notifdel_notif   on notification_deliveries (notification_id, status);
create unique index uq_notifdel_user on notification_deliveries (notification_id, user_id)
  where notification_id is not null;

-- 10.5 ── app_config : remote config / feature flags / kill switch -----------------
create table app_config (
  key          text primary key,
  value        jsonb not null,
  value_type   text not null default 'json'
                  check (value_type in ('json','bool','int','string','float')),
  description  text,
  scope        text not null default 'global' check (scope in ('global','app','machine','user_segment')),
  updated_by   uuid references admin_users(id) on delete set null,
  updated_at   timestamptz not null default now()
);
comment on table app_config is 'Remote kill switch. Flip maintenance_mode or disable a feature without shipping an app update. This is what saves you during an incident.';
create index idx_config_updated on app_config (updated_at desc);
create trigger trg_config_updated_at before update on app_config
  for each row execute function fn_set_updated_at();

-- 10.6 ── app_versions --------------------------------------------------------------
create table app_versions (
  id              uuid primary key default gen_random_uuid(),
  platform        text not null check (platform in ('android','ios','web')),
  version         text not null,
  min_supported   text not null,
  is_forced_update boolean not null default false,
  release_notes   text,
  store_url       text,
  is_active       boolean not null default true,
  released_at     timestamptz not null default now(),
  unique (platform, version)
);
create index idx_appver_active on app_versions (platform, is_active, min_supported desc);

-- 10.7 ── audit_logs : full admin/system trail -------------------------------------
create table audit_logs (
  id          bigint generated always as identity primary key,
  actor_type  sub_entity_type not null,
  actor_id    uuid,
  action      text not null,
  entity_type text not null,
  entity_id   uuid,
  before_state jsonb,
  after_state  jsonb,
  ip_address  inet,
  user_agent  text,
  created_at  timestamptz not null default now()
);
comment on table audit_logs is 'before_state + after_state stored as JSONB. Answer "who changed this price and what was it before" without guessing.';
create index idx_audit_entity on audit_logs (entity_type, entity_id, created_at desc);
create index idx_audit_actor  on audit_logs (actor_id, created_at desc);
create index idx_audit_action on audit_logs (action, created_at desc);
create index idx_audit_created on audit_logs (created_at desc);


-- =============================================================================
--  MONTHLY PARTITION MAINTENANCE
-- =============================================================================
--  Run via pg_cron (or Supabase scheduled function) on the 1st of each month.
--  Creates next month's partition and drops partitions older than retention.

create or replace function fn_manage_telemetry_partitions()
returns void
language plpgsql
as $$
declare
  v_start date := date_trunc('month', now())::date;
  v_end   date := (date_trunc('month', now()) + interval '1 month')::date;
  v_name  text := 'machine_telemetry_' || to_char(v_start, 'YYYY_MM');
  v_drop  record;
begin
  execute format(
    'create table if not exists %I partition of machine_telemetry for values from (%L) to (%L)',
    v_name, v_start, v_end
  );

  -- drop partitions older than 3 months (raw retention policy)
  for v_drop in
    select c.relname
    from pg_class c
    join pg_inherits i on i.inhrelid = c.oid
    join pg_class p on p.oid = i.inhparent
    where p.relname = 'machine_telemetry'
      and c.relname ~ '^machine_telemetry_\d{4}_\d{2}$'
      and c.relname < 'machine_telemetry_' || to_char(v_start - interval '3 months', 'YYYY_MM')
  loop
    execute format('drop table if exists %I', v_drop.relname);
  end loop;
end;
$$;


-- =============================================================================
--  HELPER: auto-create user + wallet + coins + stats on signup
-- =============================================================================
create or replace function fn_bootstrap_user()
returns trigger
language plpgsql
as $$
begin
  insert into user_profiles (user_id) values (new.id) on conflict do nothing;
  insert into user_preferences (user_id) values (new.id) on conflict do nothing;
  insert into wallets (user_id) values (new.id) on conflict do nothing;
  insert into coin_balances (user_id) values (new.id) on conflict do nothing;
  insert into user_stats (user_id) values (new.id) on conflict do nothing;
  return new;
end;
$$;

create trigger trg_user_bootstrap
  after insert on users
  for each row execute function fn_bootstrap_user();


-- =============================================================================
--  HELPER: maintain wallets.balance_paise from the ledger
--  NOTE: the ledger row is still the source of truth. This keeps the cached
--  balance in sync inside the same transaction as the insert.
-- =============================================================================
create or replace function fn_apply_wallet_delta()
returns trigger
language plpgsql
as $$
begin
  update wallets
     set balance_paise = new.balance_after,
         lifetime_added_paise = lifetime_added_paise
           + case when new.direction = 'credit' then new.amount_paise else 0 end,
         lifetime_spent_paise = lifetime_spent_paise
           + case when new.direction = 'debit' then new.amount_paise else 0 end,
         last_transaction_at = now()
   where user_id = new.user_id;

  -- hard guard: wallet can never go negative
  if (select balance_paise from wallets where user_id = new.user_id) < 0 then
    raise exception 'Wallet balance would go negative for user %', new.user_id;
  end if;

  return new;
end;
$$;

create trigger trg_wallet_apply
  after insert on wallet_transactions
  for each row execute function fn_apply_wallet_delta();


-- =============================================================================
--  HELPER: maintain coin_balances.coins from the ledger
-- =============================================================================
create or replace function fn_apply_coin_delta()
returns trigger
language plpgsql
as $$
begin
  update coin_balances
     set coins = new.balance_after,
         lifetime_earned = lifetime_earned
           + case when new.direction = 'credit' then new.coins else 0 end,
         lifetime_spent = lifetime_spent
           + case when new.direction = 'debit' then new.coins else 0 end,
         ad_watch_count = ad_watch_count
           + case when new.tx_type = 'ad_watch' then 1 else 0 end,
         last_ad_at = case when new.tx_type = 'ad_watch' then now() else last_ad_at end
   where user_id = new.user_id;

  return new;
end;
$$;

create trigger trg_coins_apply
  after insert on coin_transactions
  for each row execute function fn_apply_coin_delta();


-- =============================================================================
--  DONE
-- =============================================================================
--  68 tables, 10 domains.
--  Next: 002_functions.sql (atomic QR redeem, leaderboard scoring, telemetry rollup)
--         003_views.sql
--         004_rls_policies.sql
--         005_seed.sql
-- =============================================================================
