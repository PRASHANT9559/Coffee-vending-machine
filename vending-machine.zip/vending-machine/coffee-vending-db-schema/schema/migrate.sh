#!/usr/bin/env bash
# Apply the coffee-vending schema in order.
#
# RLS policies (004) rely on Supabase's auth.uid() and the `anon` /
# `authenticated` roles, so they are skipped by default. Set WITH_RLS=1 when
# running against Supabase.
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is required}"

SCHEMA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "→ 001_full_schema.sql"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$SCHEMA_DIR/001_full_schema.sql"
echo "→ 002_functions.sql"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$SCHEMA_DIR/002_functions.sql"
echo "→ 003_views.sql"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$SCHEMA_DIR/003_views.sql"

if [[ "${WITH_RLS:-0}" == "1" ]]; then
  echo "→ 004_rls_policies.sql (Supabase only)"
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$SCHEMA_DIR/004_rls_policies.sql"
else
  echo "– skipping 004_rls_policies.sql (set WITH_RLS=1 on Supabase)"
fi

echo "→ 005_seed.sql"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$SCHEMA_DIR/005_seed.sql"

echo "✅ schema applied"
