-- =============================================================================
--  ROW LEVEL SECURITY  (Supabase / PostgreSQL)
--  Requires: 001_full_schema.sql, 002_functions.sql
--  Version: 1.0.0
--
--  WHY THIS FILE MATTERS
--  ---------------------
--  In Supabase the browser holds the anon key. Without RLS, ANY authenticated
--  user can `select * from orders` and read every transaction in the system.
--  RLS is the ONLY thing standing between a curious user and the whole database.
--
--  ROLES
--  -----
--  anon        : unauthenticated visitors. Sees almost nothing.
--  authenticated: logged-in customer. Sees only their own rows.
--  service_role : backend / Rust microservice / Edge Functions. BYPASSES RLS.
--  admin_users : staff. Access is granted via SECURITY DEFINER functions only —
--                the admin panel talks to the Rust service, never direct-to-table.
--
-- =============================================================================

-- ── Enable RLS everywhere. No exceptions. ───────────────────────────────────
do $$
declare t text;
begin
  for t in
    select tablename from pg_tables
     where schemaname = 'public'
       and tablename not in ('spatial_ref_sys')
  loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end;
$$;

-- Force RLS even for the table owner (prevents accidental owner-side bypass).
do $$
declare t text;
begin
  for t in
    select tablename from pg_tables
     where schemaname = 'public'
  loop
    execute format('alter table public.%I force row level security', t);
  end loop;
end;
$$;


-- =============================================================================
--  HELPERS
-- =============================================================================
create or replace function fn_current_admin_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  -- populated from a custom JWT claim set by the admin auth layer
  select nullif(current_setting('request.jwt.claims', true)::jsonb ->> 'admin_id', '')::uuid;
$$;

create or replace function fn_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (current_setting('request.jwt.claims', true)::jsonb ->> 'is_admin')::boolean,
    false
  );
$$;

-- Under-18 accounts are never readable as leaderboard rows, no matter the
-- customer's own privacy toggles.
create or replace function fn_is_masked_user(p_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select age_band = 'under_18' from user_profiles where user_id = p_user_id),
    true
  );
$$;


-- =============================================================================
--  1. IDENTITY — users see only themselves
-- =============================================================================
create policy users_select_own on users
  for select to authenticated
  using (id = (select auth.uid()) or fn_is_admin());

create policy users_update_own on users
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- insert happens through signup trigger; no client insert policy by design
create policy users_insert_self on users
  for insert to authenticated
  with check (id = (select auth.uid()));

-- ── profiles: own row writable, leaderboard-relevant columns are NOT ────────
-- A user must not be able to flip show_handle_publicly from the client without
-- the server recording the confirmation. That is why these are blocked here.
create policy profiles_select_own on user_profiles
  for select to authenticated
  using (user_id = (select auth.uid()) or fn_is_admin());

create policy profiles_update_own on user_profiles
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- Opt-in columns are server-managed. Blocked from direct client UPDATE.
create or replace function fn_block_privacy_selfservice()
returns trigger
language plpgsql
as $$
begin
  if new.show_handle_publicly is distinct from old.show_handle_publicly
     or new.show_on_leaderboard is distinct from old.show_on_leaderboard
     or new.instagram_handle is distinct from old.instagram_handle then
    -- allowed only when running as service_role (the Rust service, via the
    -- typed-confirmation endpoint) — not when a raw client UPDATE is attempted
    if current_setting('role', true) <> 'service_role' then
      raise exception 'Privacy fields must be changed through the verified opt-in endpoint';
    end if;
  end if;
  return new;
end;
$$;

create trigger trg_block_privacy_selfservice
  before update on user_profiles
  for each row execute function fn_block_privacy_selfservice();

-- ── devices / consents / preferences / fav machines: own rows only ──────────
create policy devices_own on user_devices
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy devices_insert_own on user_devices
  for insert to authenticated
  with check (user_id = (select auth.uid()));

-- consents are append-only from the client; the server writes the grant
create policy consents_select_own on user_consents
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy consents_insert_own on user_consents
  for insert to authenticated
  with check (user_id = (select auth.uid()));

create policy prefs_own on user_preferences
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy favmachines_own on user_fav_machines
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));


-- =============================================================================
--  2. MACHINES & CATALOG — public read, admin write
-- =============================================================================
create policy machines_public_read on machines
  for select to anon, authenticated
  using (status in ('active','maintenance','offline'));

create policy machines_admin_write on machines
  for all to authenticated
  using (fn_is_admin()) with check (fn_is_admin());

-- telemetry / health / commands / maintenance: admin only, never exposed
create policy telemetry_admin on machine_telemetry
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy tanks_read_public on machine_tanks
  for select to anon, authenticated
  using (status in ('mounted','in_use'));

create policy tanks_admin_write on machine_tanks
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy tank_events_admin on machine_tank_events
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy stock_read_public on machine_stock
  for select to anon, authenticated using (true);

create policy stock_admin_write on machine_stock
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy stock_events_admin on machine_stock_events
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy health_admin on machine_health_logs
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy commands_admin on machine_commands
  for select to authenticated using (fn_is_admin());

create policy maintenance_admin on machine_maintenance_logs
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy firmware_admin on machine_firmware_versions
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

-- catalog is public read
create policy products_public_read on products
  for select to anon, authenticated using (is_active or fn_is_admin());

create policy products_admin_write on products
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy prices_public_read on product_prices
  for select to anon, authenticated using (valid_to is null or fn_is_admin());

create policy prices_admin_write on product_prices
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy kits_admin on kit_templates
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy kitcomp_admin on kit_components
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());


-- =============================================================================
--  3. CODES & ORDERS — the money tables
-- =============================================================================

-- A user sees their OWN codes only. code_hash and signature are excluded from
-- the payload by the column list below so a client cannot harvest them.
create policy qr_codes_own_read on qr_codes
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy qr_codes_no_client_write on qr_codes
  for insert to authenticated
  with check (false);   -- codes are minted ONLY by fn_generate_qr_code

-- orders: own rows only
create policy orders_own_read on orders
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy orders_no_client_write on orders
  for insert to authenticated
  with check (false);   -- created ONLY by fn_redeem_qr_code

create policy orderitems_own_read on order_items
  for select to authenticated
  using (exists (select 1 from orders o
                  where o.id = order_items.order_id
                    and o.user_id = (select auth.uid())));

-- dispense_logs: the user may see the proof of their own dispense. This is a
-- deliberate transparency choice — it also defuses "paise kat gaye" disputes.
create policy dispense_own_read on dispense_logs
  for select to authenticated
  using (exists (select 1 from orders o
                  where o.id = dispense_logs.order_id
                    and o.user_id = (select auth.uid())));

-- code events: own codes only
create policy qrevents_own_read on qr_code_events
  for select to authenticated
  using (exists (select 1 from qr_codes c
                  where c.id = qr_code_events.code_id
                    and c.user_id = (select auth.uid())));

-- payments: own only, and never expose raw_payload
create policy payments_own_read on payment_transactions
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy refunds_own_read on refunds
  for select to authenticated
  using (user_id = (select auth.uid()));

-- batches: admin only
create policy batches_admin on code_batches
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());


-- =============================================================================
--  4. WALLET / COINS / COUPONS
-- =============================================================================
create policy wallets_own_read on wallets
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy wallet_tx_own_read on wallet_transactions
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy coins_own_read on coin_balances
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy coin_tx_own_read on coin_transactions
  for select to authenticated
  using (user_id = (select auth.uid()));

-- coupons are public-read so the app can show available offers
create policy coupons_public_read on coupons
  for select to anon, authenticated
  using (is_active and expires_at > now());

create policy coupon_redemptions_own_read on coupon_redemptions
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy coupons_admin_write on coupons
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());


-- =============================================================================
--  5. GROWTH & SOCIAL
-- =============================================================================
create policy referrals_own_read on referrals
  for select to authenticated
  using (referrer_id = (select auth.uid()) or referee_id = (select auth.uid()));

create policy gifts_own_read on gifts
  for select to authenticated
  using (from_user_id = (select auth.uid()) or to_user_id = (select auth.uid()));

create policy gifts_insert_own on gifts
  for insert to authenticated
  with check (from_user_id = (select auth.uid()));

-- LEADERBOARD — deliberately NO direct select policy.
-- Clients must call fn_leaderboard_public(), which is SECURITY DEFINER and
-- applies masking + handle opt-in in SQL. This makes privacy unbypassable
-- from the client regardless of what the app code does.
create policy leaderboard_periods_public_read on leaderboard_periods
  for select to anon, authenticated
  using (status in ('live','closed'));

create policy leaderboard_entries_admin on leaderboard_entries
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy leaderboard_prizes_public_read on leaderboard_prizes
  for select to anon, authenticated using (true);

create policy badges_public_read on badges
  for select to anon, authenticated using (is_active);

create policy userbadges_public_read on user_badges
  for select to anon, authenticated
  using (not fn_is_masked_user(user_id));

create policy userbadges_own_write on user_badges
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy userstats_own_read on user_stats
  for select to authenticated
  using (user_id = (select auth.uid()));


-- =============================================================================
--  6. ADS
-- =============================================================================
create policy adimp_own_read on ad_impressions
  for select to authenticated
  using (user_id = (select auth.uid()));

-- Clients claim rewards; they never confirm them. postback_status stays pending.
create policy adreward_insert_own on ad_reward_events
  for insert to authenticated
  with check (user_id = (select auth.uid()));

create policy adreward_own_read on ad_reward_events
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy adnet_admin on ad_networks
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy adrev_admin on ad_revenue_daily
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy adspace_public_read on ad_spaces
  for select to anon, authenticated using (is_active);

create policy adspace_admin on ad_spaces
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy adbooking_admin on ad_space_bookings
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());


-- =============================================================================
--  7. SUPPORT & TRUST
-- =============================================================================
create policy tickets_own_read on support_tickets
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy tickets_own_insert on support_tickets
  for insert to authenticated
  with check (user_id = (select auth.uid()));

create policy tickets_admin_all on support_tickets
  for all to authenticated
  using (fn_is_admin()) with check (fn_is_admin());

-- ticket evidence and camera footage are admin-only. A user can raise a
-- ticket and see the outcome, but never browse the footage archive.
create policy evidence_admin on ticket_evidence
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy tsh_admin on ticket_status_history
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy feedback_insert_own on feedback_ratings
  for insert to authenticated with check (true);

create policy feedback_own_read on feedback_ratings
  for select to authenticated
  using (user_id = (select auth.uid()) or fn_is_admin());

create policy feedback_public_summary on feedback_ratings
  for select to anon, authenticated
  using (rating >= 4);   -- only positive reviews surface publicly

create policy cameras_admin on cameras
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy clips_admin on video_clips
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy blacklist_admin on fraud_blacklist
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());


-- =============================================================================
--  8. SUBSCRIPTION
-- =============================================================================
create policy plans_public_read on subscription_plans
  for select to anon, authenticated
  using (is_active);

create policy subs_own_read on user_subscriptions
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy invoices_own_read on subscription_invoices
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy mandates_own_read on upi_mandates
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy plans_admin_write on subscription_plans
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());


-- =============================================================================
--  9. MARKETING & SYSTEM
-- =============================================================================
create policy offers_public_read on offers
  for select to anon, authenticated
  using (is_active and now() between starts_at and ends_at);

create policy banners_public_read on banners
  for select to anon, authenticated
  using (is_active and now() >= starts_at and (ends_at is null or now() < ends_at));

create policy offers_admin_write on offers
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy banners_admin_write on banners
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy push_admin on push_notifications
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy notifdel_own_read on notification_deliveries
  for select to authenticated
  using (user_id = (select auth.uid()));

-- app_config: PUBLIC READ. Feature flags and prices must reach the app without
-- auth. Never put secrets in this table.
create policy config_public_read on app_config
  for select to anon, authenticated using (true);

create policy config_admin_write on app_config
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy appver_public_read on app_versions
  for select to anon, authenticated using (is_active);

create policy appver_admin_write on app_versions
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy audit_admin on audit_logs
  for all to authenticated using (fn_is_admin()) with check (fn_is_admin());

create policy adminusers_self on admin_users
  for select to authenticated
  using (fn_current_admin_id() is not null or fn_is_admin());


-- =============================================================================
--  10. AUDIT TRIGGER — capture admin writes automatically
-- =============================================================================
create or replace function fn_write_audit()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'UPDATE' then
    insert into audit_logs (actor_type, actor_id, action, entity_type, entity_id,
                            before_state, after_state)
    values (case when fn_is_admin() then 'admin'::sub_entity_type else 'system'::sub_entity_type end,
            fn_current_admin_id(),
            'update', tg_table_name, (to_jsonb(old) ->> 'id')::uuid,
            to_jsonb(old), to_jsonb(new));
  elsif tg_op = 'DELETE' then
    insert into audit_logs (actor_type, actor_id, action, entity_type, entity_id, before_state)
    values (case when fn_is_admin() then 'admin'::sub_entity_type else 'system'::sub_entity_type end,
            fn_current_admin_id(), 'delete', tg_table_name,
            (to_jsonb(old) ->> 'id')::uuid, to_jsonb(old));
  end if;
  return coalesce(new, old);
end;
$$;

-- Audit the tables where an admin mistake is most expensive.
do $$
declare t text;
begin
  foreach t in array array[
    'products','product_prices','machines','machine_stock','machine_tanks',
    'coupons','offers','subscription_plans','admin_users','app_config',
    'support_tickets','refunds','ad_space_bookings','leaderboard_entries'
  ] loop
    execute format(
      'create trigger trg_audit_%1$s after update or delete on %1$I
       for each row execute function fn_write_audit()', t);
  end loop;
end;
$$;


-- =============================================================================
--  DONE
-- =============================================================================
--  VERIFICATION QUERIES (run these as service_role after going live)
-- -----------------------------------------------------------------------------
--  -- Can a normal user read someone else's orders?
--  set role authenticated;
--  set request.jwt.claims = '{"sub":"<user_a_uuid>"}';
--  select count(*) from orders;                    -- expect ONLY user_a's rows
--
--  -- Can they read the leaderboard directly (bypassing masking)?
--  select count(*) from leaderboard_entries;      -- expect 0 rows (no policy)
--
--  -- Can they flip their own privacy flags client-side?
--  update user_profiles set show_handle_publicly = true
--   where user_id = '<user_a_uuid>';              -- expect: exception raised
--
--  -- Can they mint a QR code directly?
--  insert into qr_codes (code_hash, random_id, signature, product_id, amount_paise, expires_at)
--  values ('x','y','z','<pid>',2000, now());     -- expect: 0 rows inserted
-- =============================================================================
