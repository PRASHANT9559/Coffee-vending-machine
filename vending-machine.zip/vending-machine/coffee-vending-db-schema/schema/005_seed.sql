-- =============================================================================
--  SEED DATA — minimum viable production data
--  Requires: 001_full_schema.sql, 002_functions.sql
-- =============================================================================


-- =============================================================================
--  APP CONFIG — the signing secret MUST be replaced with a real random value.
--  Generate with:  openssl rand -hex 32
--  The machine firmware holds the same value. Never rotate it casually:
--  rotating invalidates every un-redeemed code in the field.
-- =============================================================================
insert into app_config (key, value, value_type, description) values
  ('qr_signing_secret', '"CHANGE-ME-openssl-rand-hex-32"', 'string',
   'HMAC-SHA256 key for QR signatures. Shared with machine firmware. Rotate = invalidate all live codes.'),

  ('maintenance_mode', 'false', 'bool',
   'Global kill switch. When true the app shows a maintenance banner and the Rust service rejects dispense authorisations.'),

  ('codes_default_valid_hours', '24', 'int',
   'Default validity window for generated codes.'),

  ('codes_ad_reward_valid_hours', '720', 'int',
   'Ad-earned / free codes get a much longer window than purchased ones.'),

  ('coins_per_ad_view', '20', 'int',
   'Rewarded video ad grant.'),

  ('coins_to_redeem_paise', '2000', 'int',
   'Coins needed to redeem one ₹20 coffee.'),

  ('wallet_recharge_bonus', '{"100":0,"200":20,"500":50,"1000":150}', 'json',
   'Bonus paise by recharge tier. Larger tier = larger effective bonus.'),

  ('leaderboard_public_limit', '50', 'int',
   'Rows returned to the app. Capped at 100 inside the function.'),

  ('leaderboard_formula', '{"orders":1.0,"distinct_day":0.5,"friend_penalty":0.3}', 'json',
   'Anti-farm weights. Changing these re-scores the current period.'),

  ('support_response_target_minutes', '5', 'int',
   'SLA target surfaced on the admin dashboard.'),

  ('video_clip_retention_days', '30', 'int',
   'Cloud retention for ticket-extracted clips. SD card keeps 48h locally.'),

  ('telemetry_raw_retention_months', '3', 'int',
   'Raw telemetry retention before partition drop.'),

  ('min_under_18_auto_mask', 'true', 'bool',
   'Force-mask leaderboard rows for under-18 accounts regardless of opt-in.')
on conflict (key) do nothing;


-- =============================================================================
--  ADMIN ROLES
-- =============================================================================
insert into admin_roles (name, permissions, is_superadmin) values
  ('owner',    '{"*":true}', true),
  ('ops',      '{"machine.view":true,"machine.lock":true,"machine.command":true,
                "maintenance.write":true,"tank.write":true,"stock.write":true,
                "ticket.view":true,"ticket.resolve":true,"refund.approve":true,
                "video.view":true,"app_config.view":true}', false),
  ('support',  '{"ticket.view":true,"ticket.resolve":true,"refund.approve":false,
                "refund.request":true,"video.view":true,"user.view":true}', false),
  ('finance',  '{"finance.view":true,"refund.approve":true,"pricing.edit":true,
                "coupon.write":true,"adspace.write":true,"report.export":true}', false),
  ('marketing', '{"offer.write":true,"banner.write":true,"push.write":true,
                 "leaderboard.write":true,"adspace.write":true,"report.export":true}', false),
  ('viewer',   '{"machine.view":true,"ticket.view":true,"finance.view":true,
                "app_config.view":true,"report.export":true}', false)
on conflict (name) do nothing;

-- Bootstrap admin identities. Passwords are stored as pgcrypto bcrypt hashes;
-- replace the temporary password before any real deployment.
--   ChangeMe!2026  (rotate immediately)
-- IDs are deterministic so the Next.js session token can carry a real
-- admin_users.id (`sub`), which the Rust service and audit FKs expect.
insert into admin_users (id, email, password_hash, full_name, role, mfa_enabled, status) values
  ('c0ffee00-0001-4000-8000-000000000001', 'owner@manhattancoffee.in',   crypt('ChangeMe!2026', gen_salt('bf', 12)), 'Chief Rohan',   'owner',     false, 'active'),
  ('c0ffee00-0002-4000-8000-000000000002', 'ops@manhattancoffee.in',     crypt('ChangeMe!2026', gen_salt('bf', 12)), 'Meera Sawant',  'ops',       false, 'active'),
  ('c0ffee00-0003-4000-8000-000000000003', 'support@manhattancoffee.in', crypt('ChangeMe!2026', gen_salt('bf', 12)), 'Arjun Khanna',  'support',   false, 'active'),
  ('c0ffee00-0004-4000-8000-000000000004', 'finance@manhattancoffee.in', crypt('ChangeMe!2026', gen_salt('bf', 12)), 'Nikhil Rao',    'finance',   false, 'active'),
  ('c0ffee00-0005-4000-8000-000000000005', 'mkt@manhattancoffee.in',     crypt('ChangeMe!2026', gen_salt('bf', 12)), 'Sana Qureshi',  'marketing', false, 'active'),
  ('c0ffee00-0006-4000-8000-000000000006', 'viewer@manhattancoffee.in',  crypt('ChangeMe!2026', gen_salt('bf', 12)), 'Aman Gupta',    'viewer',    false, 'active')
on conflict (email) do nothing;


-- =============================================================================
--  PRODUCTS
--  Pricing matches the unit-economics model:
--    ₹20 → cost ≈ ₹10.05  (50% margin)
--    ₹30 → cost ≈ ₹13.15  (56% margin)
--    ₹50 → cost ≈ ₹17.80  (64% margin)
--  cost_basis_paise below is the MATERIAL cost only.
-- =============================================================================
insert into products
  (slug, name, short_name, tagline, description, milk_ml, malai_ml, has_malai, season, display_order, cup_gsm)
values
  ('classic-latte', 'Classic Café Latte', 'Classic Latte',
   '130ml · Simple · Every day',
   'Hot full-cream milk, classic coffee kit, your choice of sugar.',
   130, 0, false, 'hot', 10, 250),

  ('grande-roast', 'Grande Roast', 'Grande Roast',
   '180ml · Strong · Extra bold',
   'Bigger serve with an extra gram of coffee. For the 4 PM crowd.',
   180, 0, false, 'hot', 20, 250),

  ('manhattan-velvet', 'Manhattan Velvet Cappuccino', 'Manhattan Velvet',
   '250ml · Signature Crema Float',
   'Our signature. 250ml rich brew crowned with thick malai. Best one in the city.',
   250, 20, true, 'hot', 30, 250),

  ('chilled-manhattan', 'Chilled Manhattan Frappe', 'Chilled Frappe',
   '220ml · Cold · No milk spoilage risk',
   'Summer mode. Cold milk, ice-brew kit, cocoa and choco chips. Shake and serve.',
   220, 0, false, 'cold', 40, 300)
on conflict (slug) do nothing;

-- ── prices ──────────────────────────────────────────────────────────────────
insert into product_prices (product_id, price_paise, season, valid_from)
select p.id, v.price, v.season, now()
  from (values
    ('classic-latte',    2000, 'hot'),
    ('grande-roast',     3000, 'hot'),
    ('manhattan-velvet', 5000, 'hot'),
    ('chilled-manhattan',4500,'cold')
  ) as v(slug, price, season)
  join products p on p.slug = v.slug
 where not exists (
   select 1 from product_prices pp
    where pp.product_id = p.id and pp.valid_to is null
 );

-- ── kit templates with the self-manufactured cost basis ─────────────────────
insert into kit_templates (product_id, name, cup_gsm, coffee_grams, sugar_grams, stirrer_qty, unit_cost_paise)
select p.id,
       p.short_name || ' Kit',
       case p.slug when 'chilled-manhattan' then 300 else 250 end,
       case p.slug when 'manhattan-velvet' then 3.00 when 'grande-roast' then 2.00 else 1.75 end,
       case p.slug when 'manhattan-velvet' then 10.00 when 'grande-roast' then 5.00 else 5.00 end,
       1,
       case p.slug when 'manhattan-velvet' then 480
                   when 'grande-roast'     then 380
                   when 'classic-latte'    then 330
                   else 420 end
  from products p
 where p.slug in ('classic-latte','grande-roast','manhattan-velvet','chilled-manhattan')
   and not exists (select 1 from kit_templates k where k.product_id = p.id);

insert into kit_components (template_id, component, quantity, unit, unit_cost_paise)
select k.id, v.component, v.qty, v.unit, v.cost
  from kit_templates k
  cross join lateral (values
    ('cup'::text,     1.0::numeric,            'nos'::text, 100::integer),
    ('coffee',        k.coffee_grams,          'gm',          90),
    ('sugar',         k.sugar_grams,           'gm',           4),
    ('stirrer',       k.stirrer_qty::numeric,  'nos',         30),
    ('pouch',         1.0,                     'nos',         40)
  ) as v(component, qty, unit, cost)
 where k.product_id is not null
   and not exists (
     select 1 from kit_components c where c.template_id = k.id and c.component = v.component
   );


-- =============================================================================
--  SUBSCRIPTION PLAN
--  Break-even: ₹499 / ~₹17 avg material cost ≈ 30 cups/month.
--  One daily user covers the cost. Everything above that is margin.
-- =============================================================================
insert into subscription_plans
  (code, name, price_paise, duration_days, cups_included, is_unlimited, benefits, min_machines)
values
  ('coffee-unlimited-499', 'Coffee Unlimited', 49900, 30, null, true,
   '["Unlimited hot coffee at any machine","No QR scanning friction — walk in and take","Priority malai variants","Free carry cup upgrade","Works across all machines"]'::jsonb, 1)
on conflict (code) do nothing;


-- =============================================================================
--  BADGES
-- =============================================================================
insert into badges (code, name, description, criteria_type, criteria_value, tier, is_rare) values
  ('first-cup',      'First Sip',        'Your first coffee',                          'orders_count',    1,  'bronze',  false),
  ('regular-10',     'Regular',          '10 coffees in',                              'orders_count',    10, 'bronze',  false),
  ('regular-50',     'Regular',          '50 coffees in',                              'orders_count',    50, 'silver',  false),
  ('centurion',      'Centurion',       '100 coffees in',                             'orders_count',    100,'gold',    false),
  ('streak-7',       'Week Warrior',    '7-day streak',                               'streak_days',     7,  'silver',  false),
  ('streak-30',      'Month Warrior',   '30-day streak',                              'streak_days',     30, 'gold',    true),
  ('early-bird',     'Early Bird',      '20 orders before 9 AM',                      'early_bird',      20, 'silver',  false),
  ('explorer',       'Explorer',        'Tried every variant',                        'variety',         4,  'gold',    false),
  ('connector',      'Connector',       '5 friends joined via your link',             'referrals',       5,  'silver',  false),
  ('influencer',     'Connector x10',   '10 friends joined via your link',            'referrals',       10, 'gold',    false),
  ('legend',         'Legend',          'Finished #1 on a monthly leaderboard',       'leaderboard_rank',1,  'platinum',true)
on conflict (code) do nothing;


-- =============================================================================
--  FEATURE FLAGS (can also live in app_config, kept here for the admin UI)
-- =============================================================================
insert into app_config (key, value, value_type, description) values
  ('feature_subscription',  'false', 'bool', 'Monthly unlimited plan. Flip once billing is live.'),
  ('feature_leaderboard',   'true',  'bool', 'Monthly coffee league.'),
  ('feature_referral',      'true',  'bool', 'Invite-and-earn.'),
  ('feature_gifting',       'true',  'bool', 'P2P QR gifting via WhatsApp.'),
  ('feature_ad_coins',      'true',  'bool', 'Rewarded video ads paying coins.'),
  ('feature_cold_mode',     'false', 'bool', 'Enable on machines fitted with a chiller.'),
  ('feature_coupons',       'true',  'bool', 'Discount coupons at checkout.'),
  ('feature_subscription_flow', 'false', 'bool', 'Show the subscribe CTA in-app.')
on conflict (key) do nothing;


-- =============================================================================
--  LAUNCH COUPONS
-- =============================================================================
insert into coupons (code, description, discount_type, value, max_discount_paise, min_order_paise, usage_limit, per_user_limit, starts_at, expires_at) values
  ('FIRSTCUP',  'Flat ₹10 off your first coffee',        'flat',    1000, 1000, 2000, 50000, 1, now(), now() + interval '90 days'),
  ('PAYA10',    'Flat ₹10 off on orders above ₹20',      'flat',    1000, 1000, 2000, 100000,3, now(), now() + interval '90 days'),
  ('WINTER50',  '₹5 off during winter special hours',    'flat',     500,  500, 3000, 20000, 2, now(), now() + interval '60 days'),
  ('MINT50',    'Free 250ml upgrade — one time',         'flat',    1000, 1000, 5000,  5000, 1, now(), now() + interval '45 days')
on conflict (code) do nothing;


-- =============================================================================
--  PRE-SEED MACHINES (2 units: hot + cold, as per the deployment plan)
-- =============================================================================
insert into machines (id, machine_code, name, mode, status, city, locality, address_line, latitude, longitude, target_temp_c, commissioned_at)
values
  ('a1b2c3d4-0001-4000-8000-000000000001', 'MCH-001', 'Manhattan — Campus Hub',  'hot',  'active', 'Delhi', 'Dwarka Sector 4',  'Plot 22, Main Market, Dwarka Sector 4', 28.5921000, 77.0460000, 65.0, now()),
  ('a1b2c3d4-0002-4000-8000-000000000002', 'MCH-002', 'Manhattan — Mall Lane',   'cold', 'active', 'Delhi', 'Nehru Place',      'Block B, Nehru Place Market',          28.5677000, 77.2500000,  6.0, now())
on conflict (machine_code) do nothing;

-- stock rows for both machines
insert into machine_stock (machine_id, item_type, variant_key, quantity, reorder_threshold)
select m.id, v.item_type, v.variant_key, v.qty, v.thr
  from machines m
  cross join (values
    ('cup',         'default',        150, 30),
    ('kit',         'classic-latte',  100, 20),
    ('kit',         'grande-roast',    80, 20),
    ('kit',         'manhattan-velvet',60, 15),
    ('kit',         'chilled-manhattan',40, 10),
    ('malai',       'default',          5,  2)
  ) as v(item_type, variant_key, qty, thr)
 where m.machine_code in ('MCH-001','MCH-002')
on conflict (machine_id, item_type, variant_key) do nothing;

-- cameras per machine (2 channels — the anti-fraud pair)
insert into cameras (machine_id, channel, name, storage_type, retention_hours, resolution)
select m.id, v.channel, v.name, 'sd', 48, '720p'
  from machines m
  cross join (values
    ('dispense', 'Internal Dispense Cam'),
    ('face',     'Customer Cam')
  ) as v(channel, name)
 where m.machine_code in ('MCH-001','MCH-002')
on conflict (machine_id, channel) do nothing;

-- first firmware version row (upload binary separately)
insert into machine_firmware_versions (version, binary_url, binary_sha256, release_notes, is_stable)
values ('1.0.0', 'https://cdn.example.com/fw/1.0.0.bin', '0000000000000000000000000000000000000000000000000000000000000000',
        'Initial production release.', true)
on conflict (version) do nothing;


-- =============================================================================
--  ANDROID/iOS APP VERSIONS
-- =============================================================================
insert into app_versions (platform, version, min_supported, is_forced_update, release_notes, store_url) values
  ('android', '1.0.0', '1.0.0', false, 'Launch build.', 'https://play.google.com/store/apps/details?id=com.example.app'),
  ('ios',     '1.0.0', '1.0.0', false, 'Launch build.', 'https://apps.apple.com/app/id000000000')
on conflict (platform, version) do nothing;


-- =============================================================================
--  LEADERBOARD PERIOD — current month
-- =============================================================================
insert into leaderboard_periods (period_key, label, starts_at, ends_at, status, scoring_formula)
select
  to_char(date_trunc('month', now()), 'YYYY-MM'),
  to_char(date_trunc('month', now()), 'FMMonth YYYY'),
  date_trunc('month', now()),
  date_trunc('month', now()) + interval '1 month',
  'live',
  '{"orders":1.0,"distinct_day":0.5,"friend_penalty":0.3}'::jsonb
where not exists (
  select 1 from leaderboard_periods
   where period_key = to_char(date_trunc('month', now()), 'YYYY-MM')
);

-- prizes for the live month
insert into leaderboard_prizes (period_id, rank_from, rank_to, scope, prize_type, prize_value, description)
select p.id, v.rf, v.rt, 'monthly', v.ptype, v.val, v.descr
  from leaderboard_periods p
  cross join (values
    (1, 1,  'subscription_months'::text, 1::integer,  '1 month Coffee Unlimited'::text),
    (2, 3,  'coins'::text,             200::integer, '200 coins + Verified Legend badge'::text),
    (4, 10, 'coins'::text,             100::integer, '100 coins + featured on machine display'::text)
  ) as v(rf, rt, ptype, val, descr)
 where p.status = 'live'
   and not exists (select 1 from leaderboard_prizes lp where lp.period_id = p.id);


-- =============================================================================
--  POST-SEED CHECKS
-- =============================================================================
--  select count(*) as tables from pg_tables where schemaname='public';        -- 69
--  select * from products order by display_order;                             -- 4 rows
--  select p.slug, pp.price_paise from products p
--    join product_prices pp on pp.product_id=p.id where pp.valid_to is null;   -- 4 rows
--  select machine_code, mode, status from machines;                           -- 2 rows
-- =============================================================================
