-- =============================================================================
--  003_views.sql — Reporting / analytics views
--  PostgreSQL 15+ (Supabase compatible)
--
--  This file was referenced by the schema run order but previously missing.
--  Views are read-only projections used by the admin panel and reporting
--  functions. All views run with `security_invoker = true` so the caller's
--  RLS policies still apply.
--
--  Run order: 001 → 002 → 003 (this file) → 004 → 005
-- =============================================================================

-- -----------------------------------------------------------------------------
--  V1. Fleet overview — one row per machine with live operational counters
-- -----------------------------------------------------------------------------
create or replace view v_admin_machine_overview
with (security_invoker = true) as
select
  m.id,
  m.machine_code,
  m.name,
  m.status::text              as status,
  m.mode::text                as mode,
  m.city,
  m.locality,
  m.target_temp_c::float8     as target_temp_c,
  m.cup_stack_count,
  m.max_cup_stack,
  m.is_locked,
  m.last_seen_at,
  coalesce(t.orders_today, 0)    as orders_today,
  coalesce(t.revenue_today, 0)   as revenue_today_paise,
  coalesce(t.cups_today, 0)      as cups_today
from machines m
left join lateral (
  select
    count(*)                                         as orders_today,
    coalesce(sum(o.final_paise), 0)                  as revenue_today,
    coalesce(count(*) filter (where o.status = 'delivered'), 0) as cups_today
  from orders o
  where o.machine_id = m.id
    and o.ordered_at >= current_date
) t on true;

-- -----------------------------------------------------------------------------
--  V2. Daily sales — one row per day (IST business day)
-- -----------------------------------------------------------------------------
create or replace view v_admin_sales_daily
with (security_invoker = true) as
select
  (o.ordered_at at time zone 'Asia/Kolkata')::date as sales_date,
  count(*)                                          as orders,
  count(*) filter (where o.status = 'delivered')    as delivered,
  count(*) filter (where o.status = 'refunded')     as refunded,
  coalesce(sum(o.final_paise), 0)                   as gross_paise,
  coalesce(sum(o.final_paise) filter (where o.status = 'delivered'), 0) as net_paise,
  coalesce(sum(o.cost_basis_paise) filter (where o.status = 'delivered'), 0) as cost_paise
from orders o
group by 1;

-- -----------------------------------------------------------------------------
--  V3. Product mix — units, revenue and margin per product
-- -----------------------------------------------------------------------------
create or replace view v_admin_product_mix
with (security_invoker = true) as
select
  p.id            as product_id,
  p.slug,
  p.name,
  count(o.id)                                     as orders,
  coalesce(sum(o.final_paise), 0)                 as revenue_paise,
  coalesce(sum(o.cost_basis_paise), 0)            as cost_paise,
  coalesce(sum(o.final_paise - o.cost_basis_paise), 0) as gross_margin_paise
from products p
left join orders o
  on o.product_id = p.id
 and o.status = 'delivered'
group by p.id, p.slug, p.name;

-- -----------------------------------------------------------------------------
--  V4. Machine performance — revenue, dispense failures and variance
-- -----------------------------------------------------------------------------
create or replace view v_admin_machine_performance
with (security_invoker = true) as
select
  m.id            as machine_id,
  m.machine_code,
  m.name,
  count(o.id)                                   as total_orders,
  count(o.id) filter (where o.status = 'failed') as failed_orders,
  coalesce(sum(o.final_paise) filter (where o.status = 'delivered'), 0) as revenue_paise,
  coalesce(round(avg(d.variance_pct)::numeric, 2), 0)::float8            as avg_variance_pct
from machines m
left join orders o       on o.machine_id = m.id
left join dispense_logs d on d.order_id = o.id
group by m.id, m.machine_code, m.name;

-- -----------------------------------------------------------------------------
--  V5. Support queue — open tickets joined to machine + latest verdict
-- -----------------------------------------------------------------------------
create or replace view v_admin_ticket_queue
with (security_invoker = true) as
select
  t.id,
  t.ticket_no,
  t.status::text        as status,
  t.ticket_type::text   as ticket_type,
  t.verdict::text       as verdict,
  t.priority,
  t.claim_amount_paise,
  t.machine_id,
  m.machine_code,
  t.user_id,
  t.assigned_to,
  t.created_at,
  t.resolved_at,
  extract(epoch from (now() - t.created_at))::bigint as age_seconds
from support_tickets t
left join machines m on m.id = t.machine_id;

-- -----------------------------------------------------------------------------
--  V6. Refund queue — pending payouts with order context
-- -----------------------------------------------------------------------------
create or replace view v_admin_refund_queue
with (security_invoker = true) as
select
  r.id,
  r.refund_no,
  r.order_id,
  o.order_no,
  r.user_id,
  r.amount_paise,
  r.destination,
  r.reason,
  r.verdict::text   as verdict,
  r.status::text    as status,
  r.requested_at,
  r.processed_at
from refunds r
join orders o on o.id = r.order_id;

-- -----------------------------------------------------------------------------
--  V7. Wallet ledger summary — balances + last movement per user
-- -----------------------------------------------------------------------------
create or replace view v_admin_wallet_summary
with (security_invoker = true) as
select
  w.user_id,
  w.balance_paise,
  w.locked_paise,
  w.lifetime_added_paise,
  w.lifetime_spent_paise,
  w.last_transaction_at,
  u.phone
from wallets w
join users u on u.id = w.user_id;

comment on view v_admin_machine_overview     is 'Fleet KPIs per machine for the admin dashboard.';
comment on view v_admin_sales_daily          is 'Daily gross/net revenue in paise (IST business day).';
comment on view v_admin_product_mix          is 'Per-product units, revenue and gross margin.';
comment on view v_admin_machine_performance  is 'Per-machine reliability + revenue for ops review.';
comment on view v_admin_ticket_queue         is 'Support desk queue with SLA age.';
comment on view v_admin_refund_queue         is 'Finance payout queue with order context.';
comment on view v_admin_wallet_summary       is 'Wallet balances with user phone for support lookups.';
