# Coffee Vending Machine Ecosystem — Database Schema

Production-grade PostgreSQL schema for the vending machine platform.
68 tables · 26 enums · 151 indexes · 93 RLS policies · 17 business functions.

---

## File order (run in this sequence)

| # | File | Purpose |
|---|------|---------|
| 1 | `001_full_schema.sql` | All 68 tables, enums, indexes, constraints, triggers |
| 2 | `002_functions.sql` | Atomic QR redeem, wallet/coin ledger, leaderboard scoring, cron jobs |
| 3 | `004_rls_policies.sql` | Row Level Security + audit triggers |
| 4 | `005_seed.sql` | Products, prices, kits, subscription plan, badges, 2 machines, coupons |

```bash
psql "$DATABASE_URL" -f 001_full_schema.sql
psql "$DATABASE_URL" -f 002_functions.sql
psql "$DATABASE_URL" -f 004_rls_policies.sql
psql "$DATABASE_URL" -f 005_seed.sql
```

Supabase: run via SQL Editor, in order. 004 must run after 002 —
it enables RLS on tables and creates the privacy trigger.

---

## The three functions that matter

### `fn_redeem_qr_code(code, machine_id, user_id)`
Atomic single-use redemption. `SELECT ... FOR UPDATE` on the code row serialises
concurrent scans, so a code can never dispense twice. Machine affinity
(`qr_codes.machine_ids`) prevents offline cross-machine double-spend.

### `fn_refresh_leaderboard(period_id)`
Anti-farm scoring:
```
weighted_score = orders + (distinct_days × 0.5) − (friend_orders × 0.3)
```
20 orders in one day scores 20.5. 20 orders over 15 days scores 27.5.
Under-18 rows are force-masked regardless of user opt-in.

### `fn_ticket_evidence_bundle(ticket_id)`
One call returns camera clips, dispense logs, payment, tank lifecycle and machine
health logs around the claimed timestamp. Drives the admin dispute screen.

---

## Required before production

1. **Replace the signing secret** in `app_config`:
   ```sql
   update app_config
      set value = to_jsonb(encode(gen_random_bytes(32), 'hex'))
    where key = 'qr_signing_secret';
   ```
   Same value must be compiled into the machine firmware. Rotating it
   invalidates every un-redeemed code in the field.

2. **Create your admin account** with a bcrypt password hash.

3. **Assign a role** — insert into the role mapping with
   `permissions = '{"*": true}'` (owner).

4. **Schedule the cron jobs** listed at the bottom of `002_functions.sql`:
   tank expiry hourly, leaderboard refresh hourly, telemetry partitions monthly,
   video clip purge daily, ad postback reconciliation every 15 min.

---

## Privacy enforcement

`leaderboard_entries` has **no SELECT policy** for clients. The app must call
`fn_leaderboard_public()`, which is `SECURITY DEFINER` and applies masking and
handle opt-in inside SQL. `user_profiles.show_handle_publicly` cannot be flipped
by a client UPDATE — a trigger raises an exception unless the write comes from
`service_role` via the typed-confirmation endpoint.

Verification queries are at the bottom of `004_rls_policies.sql`.

---

## Data volume expectations (2 machines, 150 cups/day, 300 users)

| Table | Rows/month | Retention |
|---|---|---|
| `machine_telemetry` | ~230,000 | 90 days raw, then partition drop |
| `wallet_transactions` | ~30,000 | permanent |
| `orders` | ~9,000 | 7 years (accounting) |
| `ad_impressions` | ~27,000 | 6 months |
| `video_clips` | ~300 | 30 days (ticket clips only) |

Estimated 12-month total: 15–20 GB. Cloud storage for continuous camera
recording is explicitly avoided — SD card keeps a 48-hour rolling loop and only
ticket-time clips are pushed to cloud.
