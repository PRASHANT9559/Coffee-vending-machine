-- =============================================================================
--  COFFEE VENDING MACHINE ECOSYSTEM — FUNCTIONS & BUSINESS LOGIC
--  Requires: 001_full_schema.sql
--  Version: 1.0.0
-- =============================================================================
--
--  This file contains the logic that MUST be atomic and MUST live in the
--  database, not in application code. Anything here cannot be bypassed by a
--  buggy client, a race between two workers, or a malicious app.
--
-- =============================================================================


-- =============================================================================
--  1. QR CODE GENERATION
--  code = random_id + "#" + signature
--  signature = HMAC-SHA256(secret, payload) truncated
--  Stored  = SHA-256(full_code) — lookup + leak protection
-- =============================================================================

create sequence if not exists orders_seq start 1;

create or replace function fn_generate_qr_code(
  p_user_id      uuid,
  p_product_id   uuid,
  p_amount_paise integer,
  p_machine_ids  uuid[]  default '{}',
  p_valid_hours  integer default 24,
  p_source       text    default 'purchase',
  p_batch_id     uuid    default null,
  p_cost_basis   integer default 0
)
returns table (code text, code_id uuid, expires_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_secret    text;
  v_random    text;
  v_payload   text;
  v_signature text;
  v_code      text;
  v_code_hash text;
  v_expires   timestamptz;
  v_id        uuid;
  v_nonce     int;
  v_price     integer;
begin
  -- secret key drives every offline signature the machine will ever verify
  select value #>> '{}' into v_secret
    from app_config where key = 'qr_signing_secret';
  if v_secret is null then
    raise exception 'app_config.qr_signing_secret is not configured';
  end if;

  -- resolve the live price; never trust a client-supplied amount
  select price_paise into v_price
    from product_prices
   where product_id = p_product_id
     and valid_to is null
     and (season = 'both' or season = 'hot')
   order by valid_from desc
   limit 1;

  if v_price is null then
    raise exception 'No active price for product %', p_product_id;
  end if;
  if p_amount_paise is distinct from v_price then
    raise exception 'Amount mismatch: client % vs server %', p_amount_paise, v_price;
  end if;

  -- bounded retry on the astronomically unlikely hash collision
  for v_nonce in 1..5 loop
    v_random  := substr(encode(gen_random_bytes(8), 'hex'), 1, 10);
    v_payload := format(
      '%s|%s|%s|%s|%s',
      coalesce(p_user_id::text, 'anon'),
      p_product_id::text,
      v_price,
      extract(epoch from now())::bigint,
      v_nonce
    );
    v_signature := substr(encode(hmac(v_payload, v_secret, 'sha256'), 'hex'), 1, 12);
    v_code      := v_random || '#' || v_signature;
    v_code_hash := encode(digest(v_code, 'sha256'), 'hex');

    if not exists (select 1 from qr_codes where code_hash = v_code_hash) then
      v_expires := now() + make_interval(hours => p_valid_hours);
      insert into qr_codes (
        code_hash, random_id, signature, batch_id, user_id,
        product_id, amount_paise, cost_basis_paise, machine_ids,
        expires_at, source
      ) values (
        v_code_hash, v_random, v_signature, p_batch_id, p_user_id,
        p_product_id, v_price, p_cost_basis, p_machine_ids,
        v_expires, p_source
      )
      returning id into v_id;

      insert into qr_code_events (code_id, event_type, actor_user_id, metadata)
      values (v_id, 'created', p_user_id,
              jsonb_build_object('source', p_source, 'valid_hours', p_valid_hours));

      return query select v_code, v_id, v_expires;
      return;
    end if;
  end loop;

  raise exception 'Could not generate unique QR code after 5 attempts';
end;
$$;

comment on function fn_generate_qr_code is 'Server-authoritative code minting. Price resolved from DB, amount mismatch rejected, signature computed from shared secret for offline machine verification.';


-- =============================================================================
--  2. QR CODE VERIFY (read-only, no mutation)
--  Used by the mobile app to show "valid / expired / used" BEFORE scanning.
--  fn_redeem_qr_code below remains the only authoritative mutation path.
-- =============================================================================
create or replace function fn_verify_qr_code(p_code text, p_machine_id uuid default null)
returns table (
  is_valid     boolean,
  status       text,
  product_id   uuid,
  product_name text,
  amount_paise integer,
  milk_ml      integer,
  malai_ml     integer,
  expires_at   timestamptz,
  code_id      uuid
)
language sql
stable
security definer
set search_path = public
as $$
  with found as (
    select c.id, c.product_id, c.amount_paise, c.delivered,
           c.expires_at, c.machine_ids,
           pr.name  as pname,
           pr.milk_ml, pr.malai_ml, pr.is_active as product_active
      from qr_codes c
      join products pr on pr.id = c.product_id
     where c.code_hash = encode(digest(p_code, 'sha256'), 'hex')
  ),
  m as (
    select status, is_locked, mode
      from machines
     where id = p_machine_id
  )
  select
    f.id is not null
      and not f.delivered
      and f.expires_at > now()
      and f.product_active
      and (p_machine_id is null or (coalesce(mm.status::text,'active') = 'active'
                                    and not coalesce(mm.is_locked, false)
                                    and coalesce(mm.mode,'hot') <> 'off'))
      and (f.machine_ids = '{}'::uuid[]
           or p_machine_id is null
           or p_machine_id = any(f.machine_ids))                              as is_valid,

    case
      when f.id is null                                then 'invalid'
      when f.delivered                                 then 'already_used'
      when f.expires_at <= now()                       then 'expired'
      when not f.product_active                        then 'product_unavailable'
      when p_machine_id is not null
       and coalesce(mm.status::text,'active') <> 'active' then 'machine_locked'
      when p_machine_id is not null and coalesce(mm.is_locked, false) then 'machine_locked'
      when p_machine_id is not null and coalesce(mm.mode,'hot') = 'off' then 'machine_off'
      when f.machine_ids <> '{}'::uuid[]
       and p_machine_id is not null
       and not (p_machine_id = any(f.machine_ids))     then 'wrong_machine'
      else 'valid'
    end                                                                        as status,

    f.product_id, f.pname, f.amount_paise, f.milk_ml, f.malai_ml,
    f.expires_at, f.id
  from (select 1) seed
  left join found f on true
  left join m mm     on true;
$$;

comment on function fn_verify_qr_code is 'Read-only pre-flight check for the mobile app. Returns a precise status string so the UI can show "already used" instead of a useless generic error.';


--  3. ATOMIC QR REDEMPTION  ← the single most important function in the system
--
--  Guarantees, under concurrent execution:
--    * a code can be redeemed exactly ONCE, ever
--    * machine affinity is enforced (offline double-spend impossible)
--    * expiry and machine status are checked inside the same transaction
--    * stock is decremented atomically with the flag flip
--    * an order row is always created — no orphaned redemptions
--
--  Offline machines use the identical decision tree locally in Rust, against
--  the same rules, and set orders.offline_synced = TRUE on reconciliation.
-- =============================================================================
create or replace function fn_redeem_qr_code(
  p_code       text,
  p_machine_id uuid,
  p_user_id    uuid default null
)
returns table (
  ok           boolean,
  error_code   text,
  order_id     uuid,
  order_no     text,
  product_id   uuid,
  amount_paise integer,
  milk_ml      integer,
  malai_ml     integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code        qr_codes%rowtype;
  v_machine     machines%rowtype;
  v_product     products%rowtype;
  v_order_id    uuid;
  v_order_no    text;
  v_stock       integer;
begin
  -- ── resolve code ──────────────────────────────────────────────────────────
  select * into v_code
    from qr_codes
   where code_hash = encode(digest(p_code, 'sha256'), 'hex')
   for update;                                  -- pessimistic lock: serialises concurrent scans
  if not found then
    return query select false, 'invalid_code', null, null, null, null, null, null;
    return;
  end if;

  -- ── machine checks ────────────────────────────────────────────────────────
  select * into v_machine from machines where id = p_machine_id;
  if not found then
    return query select false, 'unknown_machine', null, null, null, null, null, null;
    return;
  end if;
  if v_machine.status <> 'active' or v_machine.is_locked then
    return query select false, 'machine_locked', null, null, null, null, null, null;
    return;
  end if;
  if v_machine.mode = 'off' then
    return query select false, 'machine_off', null, null, null, null, null, null;
    return;
  end if;

  -- ── affinity: is this code valid on THIS machine? ─────────────────────────
  if v_code.machine_ids <> '{}'::uuid[] and not (p_machine_id = any(v_code.machine_ids)) then
    return query select false, 'wrong_machine', null, null, null, null, null, null;
    return;
  end if;

  -- ── state checks ──────────────────────────────────────────────────────────
  if v_code.delivered then
    return query select false, 'already_used', null, null, null, null, null, null;
    return;
  end if;
  if v_code.expires_at <= now() then
    return query select false, 'expired', null, null, null, null, null, null;
    return;
  end if;

  select * into v_product from products where id = v_code.product_id;
  if not found or not v_product.is_active then
    return query select false, 'product_unavailable', null, null, null, null, null, null;
    return;
  end if;

  -- ── stock gate ────────────────────────────────────────────────────────────
  select quantity into v_stock
    from machine_stock
   where machine_id = p_machine_id
     and item_type = 'kit'
     and variant_key = v_product.slug;
  if v_stock is not null and v_stock <= 0 then
    return query select false, 'out_of_stock', null, null, null, null, null, null;
    return;
  end if;

  -- ── the flip. one row or bust. ────────────────────────────────────────────
  update qr_codes
     set delivered = true,
         delivered_at = now()
   where id = v_code.id
     and delivered = false;                 -- double-guard under the lock
  if not found then
    return query select false, 'already_used', null, null, null, null, null, null;
    return;
  end if;

  -- ── create the order ──────────────────────────────────────────────────────
  v_order_no := 'ORD-' || to_char(now(), 'YYMM') || '-' ||
                lpad((nextval('orders_seq'))::text, 6, '0');
  insert into orders (
    order_no, code_id, user_id, machine_id, product_id,
    amount_paise, final_paise, cost_basis_paise,
    payment_method, status, authorised_at
  ) values (
    v_order_no, v_code.id, coalesce(p_user_id, v_code.user_id), p_machine_id, v_code.product_id,
    v_code.amount_paise, v_code.amount_paise, v_code.cost_basis_paise,
    case when v_code.user_id is null then 'manual'::payment_gateway else 'wallet'::payment_gateway end,
    'authorised', now()
  )
  returning id into v_order_id;

  update qr_codes set redeemed_order_id = v_order_id where id = v_code.id;

  insert into qr_code_events (code_id, event_type, actor_user_id, machine_id)
  values (v_code.id, 'redeemed', coalesce(p_user_id, v_code.user_id), p_machine_id);

  -- ── decrement stock, never below zero ─────────────────────────────────────
  update machine_stock
     set quantity = greatest(quantity - 1, 0)
   where machine_id = p_machine_id
     and item_type = 'kit'
     and variant_key = v_product.slug;

  insert into machine_stock_events (machine_id, item_type, variant_key, delta, reason, order_id)
  values (p_machine_id, 'kit', v_product.slug, -1, 'dispense', v_order_id);

  update machine_stock
     set quantity = greatest(quantity - 1, 0)
   where machine_id = p_machine_id
     and item_type = 'cup'
     and variant_key = 'default';

  update machines
     set cup_stack_count = greatest(cup_stack_count - 1, 0)
   where id = p_machine_id;

  return query
    select true, null, v_order_id, v_order_no, v_product.id,
           v_code.amount_paise, v_product.milk_ml, v_product.malai_ml;
end;
$$;

comment on function fn_redeem_qr_code is 'Atomic single-use redemption. SELECT ... FOR UPDATE on the code row serialises concurrent scans so a code can never dispense twice. Machine affinity prevents offline cross-machine double-spend.';


-- =============================================================================
--  4. WALLET: atomic debit with balance check
-- =============================================================================
create or replace function fn_wallet_debit(
  p_user_id   uuid,
  p_amount    bigint,
  p_tx_type   wallet_tx_type,
  p_ref_type  text default null,
  p_ref_id    uuid default null,
  p_order_id  uuid default null,
  p_desc      text default null
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_balance bigint;
  v_after   bigint;
begin
  select balance_paise into v_balance
    from wallets where user_id = p_user_id
    for update;                                  -- serialise concurrent debits
  if not found then
    return false;
  end if;

  if v_balance < p_amount then
    return false;                                -- insufficient balance
  end if;

  v_after := v_balance - p_amount;

  insert into wallet_transactions (
    user_id, tx_type, direction, amount_paise, balance_after,
    ref_type, ref_id, order_id, description
  ) values (
    p_user_id, p_tx_type, 'debit', p_amount, v_after,
    p_ref_type, p_ref_id, p_order_id, p_desc
  );
  return true;
end;
$$;

-- ── wallet credit ───────────────────────────────────────────────────────────
create or replace function fn_wallet_credit(
  p_user_id  uuid,
  p_amount   bigint,
  p_tx_type  wallet_tx_type,
  p_ref_type text default null,
  p_ref_id   uuid default null,
  p_payment_tx_id uuid default null,
  p_desc     text default null
)
returns bigint
language plpgsql
security definer
set search_path = public
as $$
declare
  v_balance bigint;
  v_after   bigint;
begin
  select balance_paise into v_balance from wallets where user_id = p_user_id for update;
  if not found then
    insert into wallets (user_id) values (p_user_id);
    v_balance := 0;
  end if;

  v_after := v_balance + p_amount;

  insert into wallet_transactions (
    user_id, tx_type, direction, amount_paise, balance_after,
    ref_type, ref_id, payment_tx_id, description
  ) values (
    p_user_id, p_tx_type, 'credit', p_amount, v_after,
    p_ref_type, p_ref_id, p_payment_tx_id, p_desc
  );
  return v_after;
end;
$$;


-- =============================================================================
--  5. COINS: atomic credit / debit
-- =============================================================================
create or replace function fn_coins_credit(
  p_user_id uuid, p_coins integer,
  p_tx_type coin_tx_type, p_ref_type text default null,
  p_ref_id uuid default null, p_ad_network text default null,
  p_postback text default 'n/a'
) returns integer
language plpgsql security definer set search_path = public as $$
declare v_bal bigint; v_after integer;
begin
  select coins into v_bal from coin_balances where user_id = p_user_id for update;
  if not found then
    insert into coin_balances (user_id) values (p_user_id);
    v_bal := 0;
  end if;
  v_after := v_bal + p_coins;
  insert into coin_transactions (user_id, tx_type, direction, coins, balance_after, ref_type, ref_id, ad_network, postback_status)
  values (p_user_id, p_tx_type, 'credit', p_coins, v_after, p_ref_type, p_ref_id, p_ad_network, p_postback);
  return v_after;
end;
$$;

create or replace function fn_coins_debit(
  p_user_id uuid, p_coins integer,
  p_tx_type coin_tx_type, p_ref_type text default null, p_ref_id uuid default null
) returns boolean
language plpgsql security definer set search_path = public as $$
declare v_bal integer; v_after integer;
begin
  select coins into v_bal from coin_balances where user_id = p_user_id for update;
  if not found or v_bal < p_coins then return false; end if;
  v_after := v_bal - p_coins;
  insert into coin_transactions (user_id, tx_type, direction, coins, balance_after, ref_type, ref_id)
  values (p_user_id, p_tx_type, 'debit', p_coins, v_after, p_ref_type, p_ref_id);
  return true;
end;
$$;


-- =============================================================================
--  6. LEADERBOARD: anti-farm weighted scoring
--     score = orders + (distinct_days * 0.5) - (friend_orders * 0.3)
--     A 20-order same-day burst scores 20.5.
--     A genuine 20 orders over 15 days scores 27.5.
-- =============================================================================
create or replace function fn_refresh_leaderboard(p_period_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  -- base counts from delivered orders
  with base as (
    select
      o.user_id,
      count(*)                                              as orders_count,
      count(distinct o.ordered_at::date)                    as distinct_days,
      sum(o.final_paise)::bigint                            as total_paise
    from orders o
    where o.status = 'delivered'
      and o.user_id is not null
      and o.ordered_at >= (select starts_at from leaderboard_periods where id = p_period_id)
      and o.ordered_at <  (select ends_at   from leaderboard_periods where id = p_period_id)
    group by o.user_id
  ),
  -- orders sourced from a referral link (suspected collusion)
  friend as (
    select o.user_id, count(*) as friend_orders
    from orders o
    join referrals r on r.referee_id = o.user_id and r.referrer_id = o.user_id
    where o.status = 'delivered'
      and o.ordered_at >= (select starts_at from leaderboard_periods where id = p_period_id)
    group by o.user_id
  ),
  scored as (
    select
      b.user_id, b.orders_count, b.distinct_days, b.total_paise,
      coalesce(f.friend_orders, 0) as friend_orders,
      round(
        ( b.orders_count
        + (b.distinct_days * 0.5)
        - (coalesce(f.friend_orders, 0) * 0.3)
      )::numeric, 2) as weighted_score
    from base b
    left join friend f on f.user_id = b.user_id
  )
  insert into leaderboard_entries (
    period_id, user_id, orders_count, distinct_days, friend_orders,
    total_paise, weighted_score, is_verified, is_masked
  )
  select
    p_period_id, s.user_id, s.orders_count, s.distinct_days, s.friend_orders,
    s.total_paise, s.weighted_score,
    -- verified only if at least one of THIS user's delivered orders has a sensor log
    exists (
      select 1
        from orders o2
        join dispense_logs d2 on d2.order_id = o2.id
       where o2.user_id = s.user_id
         and o2.status = 'delivered'
    ) as is_verified,
    -- forced mask for under-18, regardless of the user's own privacy flags
    coalesce(up.age_band = 'under_18', false)
  from scored s
  join users u          on u.id = s.user_id
  join user_profiles up on up.user_id = s.user_id
  where u.status = 'active'
  on conflict (period_id, user_id) do update set
    orders_count   = excluded.orders_count,
    distinct_days  = excluded.distinct_days,
    friend_orders  = excluded.friend_orders,
    total_paise    = excluded.total_paise,
    weighted_score = excluded.weighted_score,
    is_verified    = excluded.is_verified,
    is_masked      = excluded.is_masked,
    updated_at     = now();

  -- assign dense ranks
  with ranked as (
    select id,
           row_number() over (order by weighted_score desc, distinct_days desc, total_paise desc) as r
      from leaderboard_entries
     where period_id = p_period_id and is_eligible
  )
  update leaderboard_entries le
     set rank = ranked.r
    from ranked
   where le.id = ranked.id;
end;
$$;

comment on function fn_refresh_leaderboard is 'Recompute scores and ranks. Distinct-day weighting defeats burst-farming; friend_orders discount detects self-referral rings. Under-18 rows are force-masked.';


-- =============================================================================
--  7. LEADERBOARD: privacy-safe public view of entries
--     Returns only what the viewer is permitted to see.
-- =============================================================================
create or replace function fn_leaderboard_public(p_period_id uuid, p_viewer uuid default null, p_limit int default 50)
returns table (
  rank        integer,
  display_name text,
  avatar_url  text,
  instagram_handle text,
  orders_count integer,
  is_verified boolean,
  is_masked   boolean,
  is_self     boolean
)
language sql
stable
security definer
set search_path = public
as $$
  select
    le.rank,
    case when le.is_masked then 'Anonymous'
         else coalesce(up.display_name, 'Coffee lover') end as display_name,
    case when le.is_masked then null
         when not coalesce(up.show_on_leaderboard, false) then null
         when not coalesce(up.show_avatar_publicly, true) then null
         else up.avatar_url end as avatar_url,
    -- handle requires BOTH leaderboard opt-in AND explicit handle opt-in AND not masked
    case when le.is_masked then null
         when not (coalesce(up.show_on_leaderboard, false) and coalesce(up.show_handle_publicly, false)) then null
         else up.instagram_handle end as instagram_handle,
    le.orders_count,
    le.is_verified,
    le.is_masked,
    (p_viewer is not null and le.user_id = p_viewer) as is_self
  from leaderboard_entries le
  join users u          on u.id = le.user_id
  join user_profiles up on up.user_id = le.user_id
  where le.period_id = p_period_id
    and le.is_eligible
    and u.status = 'active'
  order by le.rank
  limit least(p_limit, 100);
$$;

comment on function fn_leaderboard_public is 'Privacy is enforced in the database, not the client. Handle is returned only when show_on_leaderboard AND show_handle_publicly are both true and the row is not masked. Clients cannot bypass this.';


-- =============================================================================
--  8. TANK LIFECYCLE: mount a fresh tank, expire stale ones
-- =============================================================================
create or replace function fn_mount_tank(
  p_tank_uid     text,
  p_machine_id   uuid,
  p_capacity_l   numeric,
  p_filled_l     numeric,
  p_max_hold_hours integer default 12,
  p_source       text default null,
  p_actor        uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_tank_id uuid;
begin
  -- unmount anything currently in the machine
  update machine_tanks
     set status = 'drained', unmounted_at = now()
   where machine_id = p_machine_id
     and status in ('mounted','in_use');

  insert into machine_tanks (
    tank_uid, machine_id, capacity_l, filled_l, filled_at,
    max_hold_hours, mounted_at, status, source
  ) values (
    p_tank_uid, p_machine_id, p_capacity_l, p_filled_l, now(),
    p_max_hold_hours, now(), 'mounted', p_source
  )
  returning id into v_tank_id;

  insert into machine_tank_events (tank_id, machine_id, event_type, litres, actor_id)
  values (v_tank_id, p_machine_id, 'filled', p_filled_l, p_actor);

  return v_tank_id;
end;
$$;

-- auto-expire stale tanks (cron, hourly)
create or replace function fn_expire_stale_tanks()
returns integer
language plpgsql
as $$
declare v_count integer;
begin
  with expired as (
    update machine_tanks
       set status = 'expired'
     where status in ('mounted','in_use')
       and expires_at is not null
       and expires_at <= now()
    returning id, machine_id
  )
  insert into machine_tank_events (tank_id, machine_id, event_type, notes)
  select id, machine_id, 'expired', 'Auto-expired: max hold hours exceeded' from expired;

  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- app badge: "fresh tank 2h ago" — the trust signal that drives sales
create or replace function fn_machine_freshness(p_machine_id uuid)
returns table (
  tank_uid    text,
  filled_at   timestamptz,
  age_minutes integer,
  is_fresh    boolean,
  is_expired  boolean,
  litres_left numeric
)
language sql
stable
as $$
  select
    t.tank_uid,
    t.filled_at,
    extract(epoch from (now() - t.filled_at))::int / 60,
    t.expires_at > now() and (now() - t.filled_at) < interval '4 hours',
    t.expires_at <= now(),
    t.filled_l
  from machine_tanks t
  where t.machine_id = p_machine_id
    and t.status in ('mounted','in_use')
  order by t.mounted_at desc
  limit 1;
$$;


-- =============================================================================
--  9. DISPUTE: bundle all evidence for a ticket in one call
--     This is what the admin "one-click" review screen renders.
-- =============================================================================
create or replace function fn_ticket_evidence_bundle(p_ticket_id uuid)
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'ticket', to_jsonb(t) - 'raw_payload',
    'order',  case when o.id is null then null else to_jsonb(o) end,
    'dispense_log', dl.j,
    'payment', case when pt.id is null then null else to_jsonb(pt) - 'raw_payload' end,
    'code_events', coalesce((
      select jsonb_agg(to_jsonb(e) - 'ip_address')
        from qr_code_events e
       where e.code_id = o.code_id
    ), '[]'::jsonb),
    'machine', case when m.id is null then null else to_jsonb(m) end,
    'machine_health', coalesce((
      select jsonb_agg(to_jsonb(h))
        from machine_health_logs h
       where h.machine_id = t.machine_id
         and h.recorded_at between t.claimed_time - interval '10 minutes'
                              and t.claimed_time + interval '10 minutes'
    ), '[]'::jsonb),
    'tank', tk.j,
    'clips', coalesce((
      select jsonb_agg(jsonb_build_object(
               'id', vc.id, 'camera_id', vc.camera_id,
               'start_at', vc.start_at, 'end_at', vc.end_at,
               'storage_path', vc.storage_path, 'size_mb', vc.size_mb))
        from video_clips vc
       where vc.linked_ticket_id = p_ticket_id
    ), '[]'::jsonb)
  )
  from support_tickets t
  left join orders o              on o.id = t.order_id
  left join payment_transactions pt on pt.id = t.payment_tx_id
  left join machines m            on m.id = t.machine_id
  left join lateral (
      select to_jsonb(x) as j from dispense_logs x where x.order_id = t.order_id
      order by x.recorded_at desc limit 1
  ) dl on true
  left join lateral (
      select to_jsonb(x) as j from machine_tanks x
       where x.machine_id = t.machine_id and x.status in ('mounted','in_use')
       order by x.mounted_at desc limit 1
  ) tk on true
  where t.id = p_ticket_id;
$$;

comment on function fn_ticket_evidence_bundle is 'Single call returning camera clips, sensor log, dispense log, payment, tank and machine health around the claimed time. Drives the side-by-side admin review screen.';


-- =============================================================================
-- 10. DISPUTE VERDICT: record decision + trigger refund or rejection
-- =============================================================================
create or replace function fn_resolve_ticket(
  p_ticket_id   uuid,
  p_verdict     verdict,
  p_admin_id    uuid,
  p_note        text default null,
  p_refund_paise integer default 0,
  p_destination text default 'original'
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_ticket support_tickets%rowtype;
  v_refund uuid;
begin
  select * into v_ticket from support_tickets where id = p_ticket_id for update;
  if not found then return false; end if;

  insert into ticket_status_history (ticket_id, from_status, to_status, from_verdict, to_verdict, changed_by, note)
  values (p_ticket_id, v_ticket.status,
          case when p_verdict = 'legit_issue' then 'resolved_refund'::ticket_status
               when p_verdict = 'fraud'      then 'resolved_reject'::ticket_status
               else 'closed'::ticket_status end,
          v_ticket.verdict, p_verdict, p_admin_id, p_note);

  if p_verdict = 'legit_issue' and p_refund_paise > 0 then
    insert into refunds (refund_no, order_id, payment_tx_id, user_id, amount_paise,
                         destination, reason, verdict, approved_by, status)
    values (
      'RFD-' || to_char(now(),'YYMM') || '-' || lpad((nextval('orders_seq'))::text, 6, '0'),
      v_ticket.order_id, v_ticket.payment_tx_id, v_ticket.user_id,
      p_refund_paise, p_destination, p_note, p_verdict, p_admin_id, 'pending'
    )
    returning id into v_refund;

    -- wallet refunds credit immediately; gateway refunds stay pending
    if p_destination = 'wallet' and v_ticket.user_id is not null then
      perform fn_wallet_credit(v_ticket.user_id, p_refund_paise, 'refund',
                               'ticket', p_ticket_id, null, 'Refund for ticket ' || v_ticket.ticket_no);
    end if;
  end if;

  update support_tickets
     set status = case when p_verdict = 'legit_issue' then 'resolved_refund'
                       when p_verdict = 'fraud'      then 'resolved_reject'
                       else 'closed' end,
         verdict = p_verdict,
         resolution = p_note,
         assigned_to = p_admin_id,
         refund_id = v_refund,
         resolved_at = now()
   where id = p_ticket_id;

  return true;
end;
$$;


-- =============================================================================
-- 11. ANALYTICS: hourly consumption heatmap
-- =============================================================================
create or replace function fn_consumption_heatmap(p_from timestamptz, p_to timestamptz, p_machine uuid default null)
returns table (hour_slot int, orders bigint, revenue_paise bigint)
language sql
stable
as $$
  select
    extract(hour from ordered_at)::int as hour_slot,
    count(*)                        as orders,
    sum(final_paise)::bigint        as revenue_paise
  from orders
  where status = 'delivered'
    and ordered_at >= p_from
    and ordered_at <  p_to
    and (p_machine is null or machine_id = p_machine)
  group by 1
  order by 1;
$$;


-- =============================================================================
-- 12. REFILL ESTIMATOR: "machine #1 needs 15L and 50 cups in 2 hours"
-- =============================================================================
create or replace function fn_refill_estimate(p_machine_id uuid, p_lookahead_hours int default 4)
returns table (
  tank_uid        text,
  litres_remaining numeric,
  hours_remaining numeric,
  burn_rate_lph   numeric,
  est_litres_needed numeric,
  cups_remaining  integer,
  burn_rate_cph   numeric,
  est_cups_needed integer,
  kits_low        integer
)
language sql
stable
as $$
  with usage as (
    -- actual dispensed volume comes from the sensor log, not the nominal menu size
    select
      coalesce(avg(d.dispensed_ml), avg(pr.milk_ml), 0) as avg_ml_per_order,
      count(*)                                           as orders_in_window
    from orders o
    join products pr on pr.id = o.product_id
    left join dispense_logs d on d.order_id = o.id
    where o.machine_id = p_machine_id
      and o.status = 'delivered'
      and o.ordered_at >= now() - interval '24 hours'
  ),
  tank as (
    select t.tank_uid, t.filled_l, t.expires_at
      from machine_tanks t
     where t.machine_id = p_machine_id and t.status in ('mounted','in_use')
     order by t.mounted_at desc limit 1
  ),
  rate as (
    select
      (u.avg_ml_per_order * u.orders_in_window) / 1000.0 / 24.0 as lph,
      (u.orders_in_window / 24.0) as cph
    from usage u
  )
  select
    tk.tank_uid,
    coalesce(tk.filled_l, 0),
    greatest(extract(epoch from (tk.expires_at - now())) / 3600.0, 0),
    round(coalesce(r.lph, 0), 2),
    round(coalesce(r.lph, 0) * p_lookahead_hours + 5, 1),   -- +5L buffer
    m.cup_stack_count,
    round(coalesce(r.cph, 0), 2),
    greatest((coalesce(r.cph, 0) * p_lookahead_hours)::int + 10, 0),
    (select count(*)::int from machine_stock s
      where s.machine_id = p_machine_id and s.item_type = 'kit'
        and s.quantity <= s.reorder_threshold)
  from machines m
  left join tank tk on true
  cross join rate r
  where m.id = p_machine_id;
$$;


-- =============================================================================
-- 13. FINANCIAL SUMMARY (admin dashboard tiles)
-- =============================================================================
create or replace function fn_revenue_summary(p_from timestamptz, p_to timestamptz, p_machine uuid default null)
returns jsonb
language sql
stable
as $$
  select jsonb_build_object(
    'orders',           count(*),
    'gross_revenue_paise', coalesce(sum(final_paise), 0),
    'material_cost_paise', coalesce(sum(cost_basis_paise), 0),
    'gross_profit_paise',  coalesce(sum(final_paise - cost_basis_paise), 0),
    'margin_pct', round(
      case when coalesce(sum(final_paise), 0) > 0
           then (sum(final_paise - cost_basis_paise)::numeric / sum(final_paise)) * 100
           else 0 end, 2),
    'wallet_float_paise',  (select coalesce(sum(balance_paise), 0) from wallets),
    'coins_outstanding',   (select coalesce(sum(coins), 0) from coin_balances),
    'unredeemed_codes',    (select count(*) from qr_codes where delivered = false and expires_at > now()),
    'codes_expiring_24h',  (select count(*) from qr_codes
                             where delivered = false
                               and expires_at between now() and now() + interval '24 hours'),
    'ads_revenue_paise_30d', (select coalesce(sum(revenue_paise), 0) from ad_revenue_daily
                                where report_date >= (current_date - 30)),
    'ad_space_income_paise', (select coalesce(sum(amount_paid_paise), 0) from ad_space_bookings
                                where invoice_status = 'paid'),
    'open_tickets',        (select count(*) from support_tickets
                             where status in ('open','investigating'))
  )
  from orders
  where ordered_at >= p_from and ordered_at < p_to
    and (p_machine is null or machine_id = p_machine);
$$;


-- =============================================================================
-- 14. MAINTENANCE JOBS (schedule these)
-- =============================================================================
--  create or replace view v_cron_jobs as select ...

--  Daily 02:00 IST — expire stale tanks
--  select fn_expire_stale_tanks();

--  Hourly — refresh the live leaderboard
--  select fn_refresh_leaderboard(id) from leaderboard_periods where status = 'live';

--  Monthly 1st 03:00 — telemetry partitions
--  select fn_manage_telemetry_partitions();

--  Daily 04:00 — purge expired video clips
--  update video_clips set is_purged = true, purged_at = now()
--   where is_purged = false and retention_expiry < now();
--   delete from storage.objects
--    where name in (select storage_path from video_clips where is_purged);

--  Every 15 min — ad postback reconciliation
--  update ad_reward_events
--     set postback_status = 'failed', failed_reason = 'no postback within 30 min'
--   where postback_status = 'pending' and created_at < now() - interval '30 minutes';

--  Every 5 min — detect offline machines
--  update machines set status = 'offline'
--   where status = 'active' and last_seen_at < now() - interval '10 minutes';
--  update machines set status = 'active'
--   where status = 'offline' and last_seen_at >= now() - interval '5 minutes';


-- =============================================================================
--  DONE
-- =============================================================================
