# Manhattan Coffee — Vending Machine Platform

Admin console (Next.js) + Rust/Axum API + PostgreSQL schema for a coffee
vending-machine fleet.

```
adminflow-next/                 Next.js admin panel + Rust backend
  app/                          routes (auth, dashboard, machines, orders, …)
  lib/                          auth, server actions, data clients, mock data
  backend/                      Rust Axum service (src/handlers.rs is canonical)
coffee-vending-db-schema/       SQL schema (001→005) + migrate.sh
docker-compose.yml              postgres + mosquitto + backend + web
```

## Quick start (local)

1. **Database** (PostgreSQL 15+):

   ```bash
   export DATABASE_URL=postgresql://user:pass@localhost:5432/manhattan_coffee
   bash coffee-vending-db-schema/schema/migrate.sh
   ```

   `004_rls_policies.sql` is Supabase-only; run it with `WITH_RLS=1` on Supabase.

2. **Backend**:

   ```bash
   cd adminflow-next/backend
   cp .env.example .env       # set DATABASE_URL + ADMIN_JWT_SECRET (32+ chars)
   cargo run
   ```

3. **Admin panel**:

   ```bash
   cd adminflow-next
   cp .env.example .env.local # same ADMIN_JWT_SECRET as the backend
   npm install
   npm run dev
   ```

Seeded admin logins use the password `ChangeMe!2026` — **rotate before deploying**.
MFA is a real RFC-6238 TOTP check; set `ADMIN_TOTP_SECRET` (base32) in production.

## Docker

```bash
echo "ADMIN_JWT_SECRET=$(openssl rand -hex 32)" > .env
docker compose up --build
```

## Security notes

- `ADMIN_JWT_SECRET` is required in production; both services refuse to start
  with a default secret.
- OTP and TOTP codes are never returned to the browser.
- Rust login verifies bcrypt hashes, enforces lockout after 5 failed attempts,
  and reads role/permissions from `admin_users` / `admin_roles`.
- Mock data is only used when `DEMO_MODE=1` **and** `NODE_ENV !== production`.

## Known gaps

- MQTT delivery of hardware commands is not implemented yet (commands are
  queued in `machine_commands` but no broker worker publishes them).
- CCTV clip storage, WhatsApp provider verification, and per-machine API keys
  still need production implementations.
- Most admin list pages still read `lib/mock/*`; only dashboard, machines,
  orders, customers, inventory and support lists call the Rust API. Machine
  sub-tabs (telemetry, tanks, maintenance, cameras) and marketing/settings
  pages are the remaining migration surface.
