# P1 Real Persistence & MQTT Lifecycle Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace volatile JavaScript in-memory mocks with real database-backed operations for hardware commands and refunds, enforce atomic ledger transactions in the Rust microservice, and implement the DB-first MQTT command + ACK + TTL lifecycle.

---

### Task 1: Enforce Transactional Integrity & Ledger Invariants in Rust `process_refund`

- [x] **Step 1.1: Atomic transaction & ledger execution in `process_refund`**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L627-L720)
  - Wrapped the entire refund flow in an atomic transaction (`pool.begin()`).
  - Row-locked order with `SELECT ... FOR UPDATE` and checked against double-refund.
  - Replaced manual `UPDATE wallets` with stored procedure `fn_wallet_credit`, preserving the append-only `wallet_transactions` accounting ledger.
  - Committed transaction atomically (`tx.commit().await?`).

---

### Task 2: Implement Real Command Persistence & MQTT Lifecycle Endpoints in Rust

- [x] **Step 2.1: Robust `dispatch_hardware_command` with DB-first lifecycle**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L506-L547)
  - Inserts command into PostgreSQL `machine_commands` table with status `'queued'`, 120s TTL, and admin actor attribution.

- [x] **Step 2.2: Add `list_machine_commands` endpoint with auto-TTL expiration**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L549-L592)
  - Implemented `GET /api/machines/:id/commands`.
  - Automatically expires outdated commands (`UPDATE machine_commands SET status = 'expired' WHERE expires_at < now() AND status IN ('queued', 'sent')`).
  - Returns recent commands ordered by `requested_at DESC`.

- [x] **Step 2.3: Add `ack_machine_command` endpoint for hardware confirmation**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L594-L626)
  - Implemented `POST /api/commands/:id/ack`.
  - Marks command as `'success'` (or `'failed'`), sets `acked_at = now()`, `completed_at = now()`, and stores device execution result.

- [x] **Step 2.4: Register new command routes in Axum router**
  - File: [`backend/src/main.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/main.rs#L74-L78)
  - Registered `/api/machines/:id/commands` (GET) and `/api/commands/:id/ack` (POST) in protected routes.

---

### Task 3: Expose Command Lifecycle in Next.js `backend-client.ts`

- [x] **Step 3.1: Add typed client methods for commands & ACKs**
  - File: [`lib/backend-client.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/backend-client.ts#L46-L59)
  - Added typed interface `RustMachineCommand`.
  - Added `backendApi.listMachineCommands(id, token?)` and `backendApi.ackCommand(id, result?, error?, token?)`.

---

### Task 4: Connect Machines Commands UI Page to Real Microservice

- [x] **Step 4.1: Fetch persistent commands from Rust microservice**
  - File: [`app/(admin)/machines/[id]/commands/page.tsx`](file:///sdcard/download/vending-machine/adminflow-next/app/(admin)/machines/[id]/commands/page.tsx#L18-L47)
  - Queries real persistent command audit trail from `backendApi.listMachineCommands(id)`.
  - Seamlessly falls back to mock storage if the backend is offline during frontend development.
