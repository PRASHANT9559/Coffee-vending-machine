# P1 Trust Boundary & Rust Microservice Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restore the architectural trust boundary so that the Next.js admin panel never communicates directly with the database via Supabase anon key, and instead routes all data reads and mutation dispatches through the high-performance Rust Axum microservice (`backend-client.ts`).

---

### Task 1: Enhance `backend-client.ts` for Server Context & Auto-Authentication

- [x] **Step 1.1: Add cookie-based session extraction and header propagation**
  - File: [`lib/backend-client.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/backend-client.ts)
  - Added auto-resolution of `mc_admin_session`, `session_token`, and `auth_token` in server execution contexts.
  - Passes `Authorization: Bearer <token>` and `Cookie: mc_admin_session=<token>` on all requests.

- [x] **Step 1.2: Add typed API methods for dashboard and machine queries**
  - File: [`lib/backend-client.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/backend-client.ts)
  - Added `backendApi.getLiveDashboard()`, `backendApi.getLiveMachines()`, `backendApi.listOrders()`, and typed response interfaces (`RustLiveDashboardMetrics`, `RustLiveMachine`).

---

### Task 2: Shift Dashboard Data Fetching to Rust Backend

- [x] **Step 2.1: Update `DashboardData` types for Rust source**
  - File: [`lib/dashboard-types.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/dashboard-types.ts#L69-L73)
  - Expanded `source: 'rust' | 'supabase' | 'demo'`.

- [x] **Step 2.2: Rewrite `lib/dashboard.ts` to consume Rust Axum endpoints**
  - File: [`lib/dashboard.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/dashboard.ts)
  - Removed direct Supabase client queries.
  - Queries Rust endpoints `backendApi.getLiveDashboard()` and `backendApi.getLiveMachines()`.
  - Sets `source: 'rust'` when connected; falls back gracefully to `demoData(date)` only if microservice is offline.

---

### Task 3: Update Dashboard Live Strip UI

- [x] **Step 3.1: Update badge and sync tooltip in `live-strip.tsx`**
  - File: [`components/dashboard/live-strip.tsx`](file:///sdcard/download/vending-machine/adminflow-next/components/dashboard/live-strip.tsx#L66-L80)
  - Added styling and label `LIVE · RUST SERVICE` when `source === 'rust'`.

---

### Task 4: Connect Critical Server Actions to Rust Backend

- [x] **Step 4.1: Route hardware commands and refunds through Rust microservice**
  - File: [`lib/actions.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/actions.ts)
  - Dispatches `machineCommand` to `backendApi.dispatchCommand`.
  - Dispatches `pushOta` to `backendApi.dispatchCommand`.
  - Dispatches `orderRefund` to `backendApi.refundOrder`.
  - Dispatches `disputeResolve` to `backendApi.resolveDispute`.
