# P2 Operational Flows Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement end-to-end operational flows identified in the audit: hardware telemetry ingest with machine keys and FSSAI milk watchdog, WhatsApp bot intake with deep `fn_ticket_evidence_bundle` generation, ticket state machine SLA timers (48h/7d auto-close), and interactive CCTV evidence clip playback.

---

### Task 1: IoT Telemetry Ingest & FSSAI Milk Spoilage Watchdog

- [x] **Step 1.1: Support Machine API Keys in Auth Middleware**
  - File: [`backend/src/middleware.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/middleware.rs#L13-L37)
  - Accepted `X-Machine-Key` and `X-API-Key` headers for automated hardware telemetry without browser cookies.

- [x] **Step 1.2: Add FSSAI Temperature Watchdog & Emergency Lockout**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L480-L530)
  - In `update_telemetry`: If `milk_temp_c > 8.0` °C, triggers emergency machine lockout (`is_locked = true`, `status = 'maintenance'`) and queues an automated `lock` command in `machine_commands`.

---

### Task 2: WhatsApp Bot Ticket Intake & Evidence Bundle Generation

- [x] **Step 2.1: Wire `fn_ticket_evidence_bundle` in `get_ticket`**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L910-L935)
  - Queries database `SELECT fn_ticket_evidence_bundle($1)` and returns the comprehensive PostgreSQL evidence bundle.

- [x] **Step 2.2: Implement WhatsApp Bot Intake Handler**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L980-L1070)
  - Implemented `whatsapp_intake_handler` (`POST /api/support/tickets/whatsapp`).
  - Creates ticket, links user/order, and executes `fn_ticket_evidence_bundle` to generate dispute pack.

- [x] **Step 2.3: Register WhatsApp webhook routes in Axum router**
  - File: [`backend/src/main.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/main.rs#L62-L68)
  - Exposes `/api/support/tickets/whatsapp` and `/api/support/webhook/whatsapp`.

---

### Task 3: Ticket State Machine Timers & Auto-Close Sweep

- [x] **Step 3.1: Record Status Transitions in `ticket_status_history`**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L940-L970)
  - In `resolve_dispute`, writes audit row to `ticket_status_history` on every transition.

- [x] **Step 3.2: Implement Ticket SLA Timer Sweep (48h / 7d Auto-Close)**
  - File: [`backend/src/handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs#L1070-L1130)
  - Implemented `sweep_ticket_timers` (`POST /api/support/tickets/sweep`).
  - Auto-closes `awaiting_customer` tickets (>48h) and `resolved_*` tickets (>7d).
  - Registered route in [`backend/src/main.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/main.rs#L85-L88).

---

### Task 4: CCTV Evidence Clip Player in Dispute Desk UI

- [x] **Step 4.1: Create Interactive Evidence Video Player Component**
  - File: [`components/support/evidence-video-player.tsx`](file:///sdcard/download/vending-machine/adminflow-next/components/support/evidence-video-player.tsx)
  - Built HTML5 dual-camera player with channel selector (Dispense Camera vs Front User Camera), play/pause controls, time scrubber, and signed clip download button.

- [x] **Step 4.2: Embed Player in Ticket Dispute Desk Page**
  - File: [`app/(admin)/support/tickets/[id]/page.tsx`](file:///sdcard/download/vending-machine/adminflow-next/app/(admin)/support/tickets/[id]/page.tsx#L151-L162)
  - Replaced static placeholder div with `<EvidenceVideoPlayer />`.

---

### Task 5: Expose New Flows in Next.js `backend-client.ts`

- [x] **Step 5.1: Add typed client helpers for WhatsApp intake and ticket sweep**
  - File: [`lib/backend-client.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/backend-client.ts#L205-L220)
  - Added `intakeWhatsAppTicket` and `sweepTicketTimers`.
