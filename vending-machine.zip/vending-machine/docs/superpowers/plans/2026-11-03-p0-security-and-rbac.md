# P0 Security & RBAC Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Eliminate all P0 security vulnerabilities, authentication bypasses, SQL syntax crashes, and unauthorized mutation privilege escalations in both the Rust Axum backend, PostgreSQL schema/functions, and Next.js admin panel.

---

### Task 1: Fix PostgreSQL Core Syntax & Trigger Blockers

- [x] **Step 1.1: Fix `fn_write_audit` boolean-enum crash**
  - File: [`004_rls_policies.sql`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/004_rls_policies.sql#L530-L545)
  - Replaced `coalesce(fn_is_admin() and 'admin'::sub_entity_type, 'system'::sub_entity_type)` with:
    `case when fn_is_admin() then 'admin'::sub_entity_type else 'system'::sub_entity_type end` in both `UPDATE` and `DELETE` branches.

- [x] **Step 1.2: Fix `fn_ticket_evidence_bundle` missing column error**
  - File: [`002_functions.sql`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/002_functions.sql#L726-L731)
  - Changed `where e.code_id = t.code_id` to `where e.code_id = o.code_id` since `support_tickets` has `order_id` and joined `orders` table has `code_id`.

- [x] **Step 1.3: Fix `fn_resolve_ticket` undeclared identifier**
  - File: [`002_functions.sql`](file:///sdcard/download/vending-machine/coffee-vending-db-schema/schema/002_functions.sql#L790-L797)
  - Changed `values (v_ticket_id, v_ticket.status, ...)` to `values (p_ticket_id, v_ticket.status, ...)`.

---

### Task 2: Harden Rust Backend Security & Protect Live Endpoints

- [x] **Step 2.1: Remove dev sandbox Owner fallback & support cookie names in auth middleware**
  - Files: [`middleware/auth.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/middleware/auth.rs) & [`middleware.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/middleware.rs)
  - Removed lines that injected `usr_sandbox_dev` with `UserRole::Owner` when token was absent.
  - Return `Err((StatusCode::UNAUTHORIZED, "Missing authorization token or cookie"))`.
  - Added cookie check for `mc_admin_session`, `session_token`, and `auth_token`.

- [x] **Step 2.2: Protect live endpoints in router**
  - File: [`main.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/main.rs#L62-L85)
  - Moved `/api/live/dashboard` and `/api/live/machines` from `public_routes` into `protected_routes` with `auth_middleware`.

- [x] **Step 2.3: Remove hardcoded credentials, master bypasses & default role elevation in auth handlers**
  - File: [`handlers/auth.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers/auth.rs)
    - Removed hardcoded OTP `888222` check in `otp_verify_handler`.
    - Removed role elevation to `Owner` from client payload; defaults to `UserRole::Viewer`.
    - Removed `demo_code` leakage from `LoginResponse`.
  - File: [`handlers.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers.rs)
    - Removed master email bypass for `admin@manhattancoffee.in` and `operator@manhattancoffee.in`.
    - Removed hardcoded OTP codes `654321` and `123456`, querying `otp_codes` and `admin_users` properly.

- [x] **Step 2.4: Fix SQL injection in machine telemetry handler**
  - File: [`handlers/machines.rs`](file:///sdcard/download/vending-machine/adminflow-next/backend/src/handlers/machines.rs#L48-L75)
  - Replaced raw string formatting in `update_telemetry` with parameterized queries using SQLx (`COALESCE($1, ...)`).

---

### Task 3: Harden Next.js Panel Authentication, MFA & Server Actions RBAC

- [x] **Step 3.1: Reconcile role capability over-permissions & remove demo OTP**
  - File: [`lib/auth.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/auth.ts#L68-L82)
    - Removed `customersRead` from `ROLE_CAPS.ops`.
    - Removed `inventoryRead` from `ROLE_CAPS.marketing`.

- [x] **Step 3.2: Secure pending cookie verification and MFA enforcement**
  - Files: [`lib/actions.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/actions.ts), [`mfa/page.tsx`](file:///sdcard/download/vending-machine/adminflow-next/app/(auth)/mfa/page.tsx), [`mfa-form.tsx`](file:///sdcard/download/vending-machine/adminflow-next/app/(auth)/mfa/mfa-form.tsx)
    - Updated `readPending()` to cryptographically verify token signature with `readToken<PendingToken>(raw)`.
    - Updated `verifyLoginOtp()` to require valid OTP match against pending token challenge without `DEMO_OTP` bypass.
    - Updated `verifyMfa()` to strictly validate TOTP / MFA challenge rather than accepting any 6 digits.

- [x] **Step 3.3: Enforce server-side session identity and `requireCap` in Server Actions**
  - File: [`lib/actions.ts`](file:///sdcard/download/vending-machine/adminflow-next/lib/actions.ts)
    - In every mutation action (`machineCommand`, `setMode`, `pushOta`, `logRefill`, `mountTank`, `creditWallet`, `blockCustomer`, `orderRefund`, `orderFraud`, `reissueQr`, `openDispute`, `disputeResolve`, `claimNext`, `refundPayout`, `demoAudit`):
      1. Fetches authenticated admin via `await requireAdmin()`.
      2. Verifies required capability via `roleCan(admin.role, requiredCap)`. If unauthorized, pushes denied audit and returns `{ ok: false, message: 'Forbidden' }`.
      3. Uses `admin.name` and `admin.role` for all audit logging and downstream mutations, completely ignoring/overriding any client-supplied `who` / `role` arguments.
