Update the Next.js 15 frontend in `adminflow-next` for production so that TypeScript models, the in-memory mock store, data formatters, and UI views across Fleet, Orders, Inventory, and Support accurately reflect and match the PostgreSQL database schema in `/sdcard/download/vending-machine/coffee-vending-db-schema/schema` without modifying database tables or SQL files.

Working directory: /sdcard/download/vending-machine/adminflow-next
Integrity mode: development

## Requirements

### R1. Schema Alignment in Frontend Models and Store
Update frontend TypeScript models, interfaces, in-memory mock store, and data formatters in `adminflow-next` to match PostgreSQL schema tables, columns, enums (including `order_status`, `machine_status`, and `ticket_category`), and integer paise currency values.

### R2. UI Views Synchronization
Update the UI pages and components across Fleet, Orders, Inventory, and Support to render the updated schema fields, display formatted paise values, and correctly present enum statuses.

### R3. Strict Database Immutability
Do not make any modifications, additions, or deletions to database tables, migrations, or SQL files in `/sdcard/download/vending-machine/coffee-vending-db-schema/schema`.

## Acceptance Criteria

### Schema and Type Alignment
- [ ] TypeScript interfaces in `adminflow-next` match the PostgreSQL schema column names and enum definitions (`order_status`, `machine_status`, `ticket_category`).
- [ ] Mock data store and formatters handle monetary amounts as integer paise and format them correctly for display.

### UI Views
- [ ] Fleet, Orders, Inventory, and Support views render matching schema properties and valid enum states from the updated mock store.
- [ ] User interactions and status badges across Fleet, Orders, Inventory, and Support reflect the PostgreSQL enum definitions.

### Database Immutability
- [ ] `git status --porcelain /sdcard/download/vending-machine/coffee-vending-db-schema` produces no output (no modified, added, or deleted schema files).

### Verification
- [ ] `npm run build` succeeds in `/sdcard/download/vending-machine/adminflow-next` with zero TypeScript or lint compilation errors.
