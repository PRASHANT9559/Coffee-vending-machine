# 🏗️ project_Architecture.md

> Complete System Architecture — ChartDB Clone (Flutter + Rust + Supabase)
> Cross-platform: Windows, Linux, macOS, Android, iOS

---

## 1. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Flutter UI Layer                      │
│  Canvas Editor | Table Editor | Relation Editor             │
│  SQL Preview   | Mermaid Preview | Export Center            │
│  Live Animation | AI Chat Panel | Profile & Billing         │
└────────────────────┬────────────────────────────────────────┘
                     │ flutter_rust_bridge (FFI)
┌────────────────────▼────────────────────────────────────────┐
│                    Rust Core Engine (On-Device)              │
│  core          : Domain models (Table, Column, Schema)       │
│  dialects      : 30 dialect definitions + type maps          │
│  sqlgen        : Schema → SQL DDL generator                  │
│  converter     : Format, Dialect, SQL↔NoSQL converters       │
│  dataflow      : Dependency graph + BFS + error prediction   │
│  diff          : Schema diff + migration + rollback          │
│  mockdata      : Mock data generator                         │
│  mermaid       : Mermaid erDiagram generation                │
│  docsgen       : Markdown/HTML/PDF documentation             │
│  ai-client     : Cloud AI HTTP client (NO model on device)   │
│  cloud         : Supabase sync client                        │
│  subscription  : Plan gating & entitlements                  │
│  ffi           : Public API bridge to Flutter                │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTPS (OAuth, Management API, AI API)
┌────────────────────▼────────────────────────────────────────┐
│                        Cloud Services                         │
│  Supabase   : Auth, Database, Storage, Management API        │
│  Cloud AI   : OpenAI / Claude / Custom (GPT, Claude, etc.)   │
│  Payments   : Stripe / Razorpay / Google Play / App Store    │
└─────────────────────────────────────────────────────────────┘
```

### Key Design Principles

| Principle | Description |
|-----------|-------------|
| **On-Device Rust** | Heavy logic runs locally — privacy, offline, zero server cost |
| **AI = Cloud Only** | No ML model on device; only HTTP client calls cloud AI API |
| **Workspace Crates** | Each feature is a separate Rust crate; independent testing |
| **Core = Single Source of Truth** | All domain models in `core` crate |
| **Dialects = Pluggable** | New dialect = one file + registration |
| **FFI = Thin Layer** | Bridge only; no business logic in FFI |
| **Feature Flags** | Tier-based binary size control |
| **Typed Errors** | `thiserror` per crate; user-friendly messages in Flutter |

---

## 2. Crate Structure (Rust Workspace)

```
chartdb-engine/                          # Root Workspace
├── Cargo.toml                           # Workspace manifest
├── Cargo.lock
├── rust-toolchain.toml                  # Rust version pin
├── rustfmt.toml
├── clippy.toml
├── deny.toml                            # License + vulnerability audit
├── .gitignore
├── README.md
├── ARCHITECTURE.md
├── CHANGELOG.md
├── LICENSE
├── .cargo/config.toml                   # Platform targets + linker
├── .github/workflows/
│   ├── ci.yml, build-android.yml, build-ios.yml
│   ├── build-desktop.yml, release.yml
├── crates/
│   ├── core/                            # Domain models
│   ├── dialects/                        # 30 dialect definitions
│   ├── parser/                          # SQL / NoSQL / Mermaid import
│   ├── sqlgen/                          # SQL DDL export
│   ├── converter/                       # Format / Dialect / NoSQL converters
│   ├── inference/                       # Schema inference from data
│   ├── dataflow/                        # Live data flow engine
│   ├── diff/                            # Schema diff + migrations
│   ├── mockdata/                        # Mock data generator
│   ├── mermaid/                         # Mermaid generation
│   ├── docsgen/                         # Documentation generator
│   ├── ai-client/                       # Cloud AI HTTP client
│   ├── cloud/                           # Supabase sync client
│   ├── subscription/                    # Plan gating
│   └── ffi/                             # Flutter FFI bridge
├── integration-tests/                   # Cross-crate tests
├── benches/                             # Performance benchmarks
├── scripts/                             # Build automation
├── docs/                                # Documentation
└── target/                              # Build output (gitignored)
```

### Crate Responsibilities

| Crate | Responsibility | On-Device? |
|-------|---------------|------------|
| core | Domain models (Table, Column, Schema, Relationship) | ✅ Yes |
| dialects | 30 dialect definitions + type maps | ✅ Yes |
| parser | Import: SQL/NoSQL/Mermaid → Schema | ✅ Yes |
| sqlgen | Export: Schema → SQL DDL | ✅ Yes |
| converter | Format + Dialect + NoSQL converters | ✅ Yes |
| inference | Schema inference from data | ✅ Yes |
| dataflow | Dependency graph + BFS + error prediction | ✅ Yes |
| diff | Schema diff + migrations + rollback | ✅ Yes |
| mockdata | Mock data generation | ✅ Yes |
| mermaid | Mermaid erDiagram generation | ✅ Yes |
| docsgen | Markdown/HTML/PDF documentation | ✅ Yes |
| ai-client | Cloud AI HTTP calls (OpenAI/Claude) | ⚠️ HTTP only |
| cloud | Supabase sync (OAuth, Management API) | ⚠️ HTTP only |
| subscription | Plan gating & entitlements | ✅ Yes |
| ffi | Flutter bridge (public API surface) | ✅ Yes |

---

## 3. Flutter Architecture

```
lib/
├── main.dart
├── ui/                          # Screens & widgets
│   ├── splash/
│   ├── onboarding/
│   ├── home/
│   ├── editor/                  # Canvas editor, panels, modals
│   ├── preview/                 # SQL preview, Mermaid preview
│   ├── export/                  # Export center
│   ├── deploy/                  # Supabase connect, project select, diff, progress
│   ├── simulation/              # Simulation setup, live animation
│   ├── ai/                      # AI assistant panel
│   ├── profile/                 # Profile, subscription, payment history
│   └── settings/
├── services/                    # Business logic
│   ├── supabase_service.dart
│   ├── auth_service.dart
│   ├── payment_service.dart
│   ├── cloud_sync_service.dart
│   └── subscription_service.dart
├── generated/                   # Auto-generated FFI bindings
├── models/                      # Dart data models
├── providers/                   # Riverpod / Bloc state management
└── utils/                       # Helpers, constants, extensions
```

### State Management
- **Riverpod** or **Bloc** for complex state (tables, columns, relationships)
- **flutter_secure_storage** for token storage (iOS Keychain / Android Keystore)
- **Hive / SQLite** for offline local storage of schema designs

---

## 4. Platform-Specific Build Targets

| Platform | Rust Target | Output | Build Tool |
|----------|-------------|--------|------------|
| Android | aarch64-linux-android, armv7-linux-androideabi, x86_64-linux-android | .so | cargo-ndk + NDK |
| iOS | aarch64-apple-ios, aarch64-apple-ios-sim | Static lib (.a) | Xcode + cargo-lipo |
| macOS | aarch64-apple-darwin, x86_64-apple-darwin | .dylib | Xcode CLI tools |
| Windows | x86_64-pc-windows-msvc | .dll | MSVC Build Tools |
| Linux | x86_64-unknown-linux-gnu | .so | gcc/clang |

### App Size Estimates

| Platform | Base Flutter | + Rust Lib | Total (approx) |
|----------|-------------|------------|----------------|
| Android APK | ~15 MB | +3-5 MB | ~20 MB |
| iOS IPA | ~20 MB | +3-5 MB | ~25 MB |
| macOS | ~30 MB | +4-6 MB | ~36 MB |
| Windows | ~25 MB | +4-6 MB | ~31 MB |
| Linux | ~25 MB | +4-6 MB | ~31 MB |

---

## 5. Data Flow Algorithm (Live Animation)

The algorithm answers 3 questions:
1. Data kahan-kahan jaayega? (Propagation path)
2. Kaunsi cheezein change hongi? (Impact)
3. Kahan error aayega? (Failure points)

### 5 Phases

1. **Graph Banao** — Build dependency graph from schema (tables, columns, FKs, triggers, views, indexes, constraints)
2. **Operation Samjho** — INSERT / UPDATE / DELETE + target table + columns + condition
3. **Traversal (BFS)** — Layer-by-layer propagation (Level 0 = source, Level 1 = direct connections, etc.)
4. **Error Detection** — FK violation, NOT NULL, UNIQUE, CHECK, RESTRICT block, type mismatch
5. **Animation Sequence** — Ordered animation steps for Flutter to render

### Cascade Rules
- ON DELETE CASCADE → delete child rows, continue
- ON DELETE SET NULL → null FK, continue
- ON DELETE RESTRICT → ERROR, stop
- ON DELETE NO ACTION → ERROR, stop

### Edge Cases Handled
- Circular dependency (visited set)
- Self-referencing FK (depth limit)
- Deep chains (max depth ~20)
- Multiple paths to same table
- Soft deletes (deleted_at column)
- Triggers on triggers (recursive check)

---

## 6. Subscription Tiers

| Feature | Free | Pro ($9/mo) | Team ($29/mo) |
|---------|------|-------------|---------------|
| Tables | 5 | Unlimited | Unlimited |
| Drawing & Edit | ✅ | ✅ | ✅ |
| SQL Preview | ✅ | ✅ | ✅ |
| Live Data Animation | ❌ | ✅ | ✅ |
| Deploy to Supabase | ❌ | ✅ | ✅ |
| Export (PNG/PDF) | Watermark | ✅ | ✅ |
| Mermaid Export | ❌ | ✅ | ✅ |
| Mock Data | 10 rows | Unlimited | Unlimited |
| AI Assistant | ❌ | ❌ | ✅ |
| Team Collaboration | ❌ | ❌ | ✅ |
| Cloud Projects | 1 | Unlimited | Unlimited |
| Storage | 100 MB | 5 GB | 50 GB |

---

## 7. Security Considerations

- Never hardcode Supabase Service Role Key in Flutter
- Use User Access Token / OAuth
- Store tokens in `flutter_secure_storage`
- SECURITY DEFINER functions in Supabase need RLS policies
- Validate all input in Rust before generating SQL
- API keys for cloud AI stored securely, never exposed to client

---

## 8. Development Priority (Revised)

| Phase | Focus | Deliverable |
|-------|-------|-------------|
| 1 | Core Editor + Drawing | Basic diagram tool |
| 2 | SQL Gen + Deploy | Working deploy to Supabase |
| 3 | Live Animation ⭐ | USP feature |
| 4 | Profile + Subscription | Monetization |
| 5 | AI Assistant | Team tier value |
| 6 | Polish + Multi-platform | Release |

---

## 9. Production Checklist

- [ ] Workspace dependencies shared in `Cargo.toml`
- [ ] `lto = true`, `strip = true`, `opt-level = "z"` in release profile
- [ ] Feature flags for optional dialects/converters
- [ ] CI/CD: clippy + fmt + test + build all targets
- [ ] Unit tests per crate, integration tests for cross-crate flows
- [ ] Error types with `thiserror`; FFI boundary converts to codes
- [ ] Code signing for Windows/macOS distribution
- [ ] Supabase redirect URLs whitelisted for all 5 platforms

---

*Architecture based on 14-turn design session covering ChartDB analysis, Flutter+Rust+Supabase stack, 26 screens, live data flow animation, AI assistant, export/cloud/subscription, 30 SQL dialects, and converter engine.*