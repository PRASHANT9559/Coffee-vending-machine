# 🦀 Rust Folder Structure

> Production-ready Rust workspace for the ChartDB Clone.
> Cross-platform: Windows, Linux, macOS, Android, iOS.
> AI model runs on cloud only (NOT on-device).
> Built for Professional Engineers: Schema-as-Code, Multi-Environment, Performance, Security.

---

## 🎯 High-Level Architecture

```mermaid
flowchart TD
    subgraph FLUTTER["Flutter App"]
        UI[UI Layer]
    end
    
    subgraph RUST["Rust Workspace - On Device"]
        FFI[ffi crate<br/>Public API Bridge]
        
        FFI --> CORE[core<br/>Domain Models]
        FFI --> SQLGEN[sqlgen]
        FFI --> CONV[converter]
        FFI --> FLOW[dataflow]
        FFI --> DIFF[diff]
        FFI --> MOCK[mockdata]
        FFI --> AI[ai-client<br/>HTTP only]
        FFI --> CLOUD[cloud sync]
        FFI --> LINT[lint<br/>Schema rules]
        FFI --> CI[ci-cd<br/>Pipeline integration]
        FFI --> INFRA[infra<br/>Docker/K8s/Terraform]
    end
    
    subgraph CLOUDAI["☁️ Cloud - NOT on device"]
        AIMODEL[AI Model API<br/>OpenAI/Claude]
        SUPA[Supabase]
    end
    
    UI <-->|FFI| FFI
    AI -.->|HTTPS| AIMODEL
    CLOUD -.->|HTTPS| SUPA
    
    style RUST fill:#4f46e5,color:#fff
    style CLOUDAI fill:#f59e0b,color:#fff
    style AI fill:#ef4444,color:#fff
    style INFRA fill:#8b5cf6,color:#fff
```

---

## 📁 Complete Rust Folder Structure

```
chartdb-engine/                          # 🏠 Root Workspace
│
├── 📄 Cargo.toml                        # Workspace manifest + shared deps
├── 📄 Cargo.lock                        # Locked dependency versions
├── 📄 rust-toolchain.toml               # Rust version pin (e.g., 1.75)
├── 📄 rustfmt.toml                      # Code formatting rules
├── 📄 clippy.toml                       # Linting configuration
├── 📄 deny.toml                         # cargo-deny (license + vuln audit)
├── 📄 .gitignore
├── 📄 README.md
├── 📄 ARCHITECTURE.md                   # Architecture documentation
├── 📄 CHANGELOG.md
├── 📄 LICENSE
│
├── 📂 .cargo/
│   └── config.toml                      # Platform targets + linker config
│
├── 📂 .github/
│   └── 📂 workflows/
│       ├── ci.yml                       # Test + lint on every PR
│       ├── schema-migration.yml         # Schema migration on deploy
│       ├── build-android.yml            # Android .so builds
│       ├── build-ios.yml                # iOS static lib builds
│       ├── build-desktop.yml            # Win/Mac/Linux builds
│       └── release.yml                  # Tagged releases
│
├── 📂 crates/                           # 🔧 All library crates
│   │
│   ├── 📂 core/                         # ⭐ schema-core: Domain Models
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── 📂 schema/
│   │       │   ├── mod.rs
│   │       │   ├── table.rs             # Table struct
│   │       │   ├── column.rs            # Column struct
│   │       │   ├── relationship.rs      # FK, 1:1, 1:N, N:M
│   │       │   ├── constraint.rs        # PK, UNIQUE, CHECK, NOT NULL
│   │       │   ├── index.rs             # Index definitions
│   │       │   ├── view.rs              # Views
│   │       │   ├── trigger.rs           # Triggers
│   │       │   ├── sequence.rs          # Sequences
│   │       │   └── schema.rs            # Schema/namespace
│   │       ├── 📂 types/
│   │       │   ├── mod.rs
│   │       │   ├── data_type.rs         # Abstract data types
│   │       │   └── enums.rs             # Shared enums
│   │       ├── error.rs                 # Core error types (thiserror)
│   │       └── result.rs                # Result alias
│   │
│   ├── 📂 dialects/                     # 🌍 Dialect Definitions
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── dialect.rs               # Dialect trait/contract
│   │       ├── registry.rs              # Dialect registry (30+ dialects)
│   │       ├── type_mapping.rs          # Type conversion rules
│   │       ├── quoting.rs               # Identifier quoting rules
│   │       ├── keywords.rs              # Reserved keywords
│   │       ├── capabilities.rs          # Feature support matrix
│   │       └── 📂 impls/
│   │           ├── mod.rs
│   │           ├── 📂 relational/
│   │           │   ├── postgresql.rs
│   │           │   ├── mysql.rs
│   │           │   ├── mariadb.rs
│   │           │   ├── sqlite.rs
│   │           │   ├── sqlserver.rs
│   │           │   ├── oracle.rs
│   │           │   └── db2.rs
│   │           ├── 📂 warehouse/
│   │           │   ├── snowflake.rs
│   │           │   ├── bigquery.rs
│   │           │   ├── redshift.rs
│   │           │   └── databricks.rs
│   │           ├── 📂 newsql/
│   │           │   ├── cockroachdb.rs
│   │           │   ├── yugabytedb.rs
│   │           │   └── tidb.rs
│   │           ├── 📂 serverless/
│   │           │   ├── supabase.rs
│   │           │   ├── neon.rs
│   │           │   ├── planetscale.rs
│   │           │   └── cloudflare_d1.rs
│   │           └── 📂 nosql/
│   │               ├── mongodb.rs
│   │               ├── redis.rs
│   │               ├── cassandra.rs
│   │               ├── neo4j.rs
│   │               ├── elasticsearch.rs
│   │               └── dynamodb.rs
│   │
│   ├── 📂 dbx-adapter/                  # 🗄️ 100+ Database Drivers (via dbx)
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── drivers/                 # 100+ DB drivers
│   │       ├── introspection/           # Read live schema from DB
│   │       └── translation/             # SQL dialect translation
│   │
│   ├── 📂 parser/                       # 📥 Import: Parse → Schema
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── 📂 sql/
│   │       │   ├── mod.rs
│   │       │   └── ddl_parser.rs        # Parse SQL DDL
│   │       ├── 📂 nosql/
│   │       │   ├── mod.rs
│   │       │   └── schema_parser.rs     # Parse NoSQL schemas
│   │       ├── 📂 mermaid/
│   │       │   ├── mod.rs
│   │       │   └── erd_parser.rs        # Parse mermaid erDiagram
│   │       └── 📂 introspection/
│   │           ├── mod.rs
│   │           └── live_schema.rs       # Read live DB schema
│   │
│   ├── 📂 sqlgen/                       # 📤 Export: Schema → SQL DDL
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── generator.rs             # Main generator orchestrator
│   │       ├── options.rs               # Export options (naming, format)
│   │       ├── formatter.rs             # Pretty/compact formatting
│   │       └── 📂 statements/
│   │           ├── mod.rs
│   │           ├── create_table.rs
│   │           ├── create_index.rs
│   │           ├── create_view.rs
│   │           ├── create_trigger.rs
│   │           ├── alter_table.rs
│   │           └── constraints.rs
│   │
│   ├── 📂 migration/                    # 📦 Migration Files
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── versioned.rs             # V1__init.sql, V2__add_users.sql
│   │       ├── flyway.rs                # Flyway format
│   │       ├── liquibase.rs             # Liquibase format
│   │       ├── alembic.rs               # Alembic format
│   │       ├── knex.rs                  # Knex format
│   │       └── rollback.rs              # Rollback generation
│   │
│   ├── 📂 converter/                    # 🔄 All Converters
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── 📂 format/               # SQL ↔ CSV/JSON/Excel...
│   │       │   ├── mod.rs
│   │       │   ├── csv.rs
│   │       │   ├── json.rs
│   │       │   ├── jsonl.rs
│   │       │   ├── excel.rs
│   │       │   ├── xml.rs
│   │       │   ├── yaml.rs
│   │       │   ├── parquet.rs
│   │       │   ├── avro.rs
│   │       │   └── protobuf.rs
│   │       ├── 📂 dialect/              # SQL dialect ↔ dialect
│   │       │   ├── mod.rs
│   │       │   ├── converter.rs
│   │       │   └── feature_resolver.rs  # Handle unsupported features
│   │       └── 📂 nosql/                # SQL ↔ NoSQL
│   │           ├── mod.rs
│   │           ├── mapping_strategy.rs  # Embed vs Reference logic
│   │           ├── 📂 to_nosql/
│   │           │   ├── to_mongodb.rs
│   │           │   ├── to_redis.rs
│   │           │   ├── to_cassandra.rs
│   │           │   ├── to_neo4j.rs
│   │           │   └── to_elasticsearch.rs
│   │           └── 📂 from_nosql/       # Reverse conversion
│   │               ├── from_mongodb.rs
│   │               └── from_redis.rs
│   │
│   ├── 📂 infra/                        # 🏗️ Infrastructure as Code (NEW)
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── docker_compose.rs        # docker-compose.yml
│   │       ├── k8s_manifests.rs         # K8s Deployment/Service/StatefulSet
│   │       ├── terraform.rs             # Terraform HCL
│   │       ├── helm.rs                  # Helm charts
│   │       ├── ansible.rs               # Ansible playbooks
│   │       └── cloudformation.rs        # AWS CloudFormation
│   │
│   ├── 📂 inference/                    # 🔍 Schema Inference
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── type_inference.rs        # Guess data types
│   │       ├── structure_inference.rs   # Guess relationships
│   │       ├── sampling.rs              # Sample documents
│   │       └── confidence.rs            # Confidence scoring
│   │
│   ├── 📂 dataflow/                     # 🎬 Live Data Flow Engine
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── 📂 graph/
│   │       │   ├── mod.rs
│   │       │   ├── dependency_graph.rs  # Build graph
│   │       │   ├── node.rs              # Graph nodes
│   │       │   ├── edge.rs              # Graph edges + rules
│   │       │   └── cache.rs             # Graph caching
│   │       ├── 📂 traversal/
│   │       │   ├── mod.rs
│   │       │   ├── bfs.rs               # BFS traversal
│   │       │   ├── cascade.rs           # Cascade rule logic
│   │       │   └── cycle_detection.rs   # Circular dependency
│   │       ├── 📂 validation/
│   │       │   ├── mod.rs
│   │       │   ├── constraint_checker.rs
│   │       │   └── error_predictor.rs   # Predict failures
│   │       └── 📂 sequence/
│   │           ├── mod.rs
│   │           ├── step.rs              # Animation step
│   │           └── sequence_builder.rs  # Build animation seq
│   │
│   ├── 📂 diff/                         # 📊 Schema Diff Engine
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── differ.rs                # Compare two schemas
│   │       ├── change.rs                # Change types (add/mod/del)
│   │       ├── migration.rs             # Generate migration
│   │       └── rollback.rs              # Generate rollback
│   │
│   ├── 📂 lint/                         # 🔍 Schema Linting (NEW)
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── rules.rs                 # Linting rules
│   │       ├── naming.rs                # Naming convention checks
│   │       ├── index_advisor.rs         # Missing index suggestions
│   │       └── breaking_change.rs       # Breaking change detection
│   │
│   ├── 📂 mockdata/                     # 🎲 Mock Data Generator
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── generator.rs             # Main generator
│   │       ├── 📂 faker/
│   │       │   ├── mod.rs
│   │       │   ├── names.rs
│   │       │   ├── emails.rs
│   │       │   ├── addresses.rs
│   │       │   └── dates.rs
│   │       ├── rules.rs                 # Generation rules
│   │       └── 📂 output/
│   │           ├── csv_writer.rs
│   │           ├── json_writer.rs
│   │           └── sql_writer.rs
│   │
│   ├── 📂 mermaid/                      # 📈 Mermaid Generation
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── erd_generator.rs         # Schema → erDiagram
│   │       └── flow_generator.rs        # Dataflow → flowchart
│   │
│   ├── 📂 docsgen/                      # 📖 Documentation Generator
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── markdown.rs
│   │       ├── html.rs
│   │       ├── data_dictionary.rs       # Excel/CSV dictionary
│   │       └── templates/               # Doc templates
│   │
│   ├── 📂 ai-client/                    # 🤖 Cloud AI Client (HTTP ONLY)
│   │   ├── Cargo.toml                   # ⚠️ NO model, NO inference
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── client.rs                # HTTP client wrapper
│   │       ├── auth.rs                  # API key management
│   │       ├── 📂 prompts/
│   │       │   ├── mod.rs
│   │       │   ├── schema_review.rs
│   │       │   ├── error_explain.rs
│   │       │   ├── optimize.rs
│   │       │   └── explain_flow.rs
│   │       ├── 📂 models/
│   │       │   ├── request.rs           # API request types
│   │       │   └── response.rs          # API response types
│   │       └── 📂 providers/
│   │           ├── mod.rs
│   │           ├── openai.rs
│   │           ├── claude.rs
│   │           └── custom.rs            # Self-hosted AI
│   │
│   ├── 📂 cloud/                        # ☁️ Cloud Sync Client
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── 📂 supabase/
│   │       │   ├── mod.rs
│   │       │   ├── client.rs
│   │       │   ├── auth.rs              # OAuth handling
│   │       │   ├── management.rs        # Management API
│   │       │   └── storage.rs           # File storage
│   │       ├── sync.rs                  # Sync logic
│   │       ├── conflict.rs              # Conflict resolution
│   │       └── versioning.rs            # Version snapshots
│   │
│   ├── 📂 subscription/                 # 💳 Plan Validation
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── plan.rs                  # Plan definitions
│   │       ├── entitlements.rs          # Feature gating logic
│   │       └── limits.rs                # Usage limits
│   │
│   ├── 📂 ci-cd/                        # 🔄 CI/CD Integration (NEW)
│   │   ├── Cargo.toml
│   │   └── 📂 src/
│   │       ├── lib.rs
│   │       ├── github_actions.rs        # GitHub Actions templates
│   │       ├── gitlab_ci.rs             # GitLab CI templates
│   │       └── schema_deploy.rs         # Schema deploy in pipeline
│   │
│   └── 📂 ffi/                          # 🌉 Flutter FFI Bridge
│       ├── Cargo.toml                   # (Public API to Flutter)
│       ├── build.rs                     # Build script
│       └── 📂 src/
│           ├── lib.rs
│           ├── 📂 api/                  # Public API surface
│           │   ├── mod.rs
│   │       │   ├── schema_api.rs        # Create/edit schema
│   │       │   ├── parser_api.rs        # Import functions
│   │       │   ├── sqlgen_api.rs        # SQL export
│   │       │   ├── converter_api.rs     # All converters
│   │       │   ├── dataflow_api.rs      # Simulation
│   │       │   ├── diff_api.rs          # Diff + migration
│   │       │   ├── mockdata_api.rs      # Mock data
│   │       │   ├── ai_api.rs            # AI (cloud calls)
│   │       │   ├── cloud_api.rs         # Sync functions
│   │       │   ├── subscription_api.rs  # Plan checks
│   │       │   ├── lint_api.rs          # Schema linting
│   │       │   ├── infra_api.rs         # Infrastructure export
│   │       │   └── ci_cd_api.rs         # CI/CD integration
│   │           └── bridge_generated.rs  # Auto-generated (flutter_rust_bridge)
│
├── 📂 integration-tests/                # 🧪 Cross-crate tests
│   ├── 📂 scenarios/
│   │   ├── sql_to_mysql_test.rs
│   │   ├── postgres_to_snowflake_test.rs
│   │   ├── sql_to_mongodb_test.rs
│   │   └── dataflow_simulation_test.rs
│   └── 📂 fixtures/                     # Test data files
│       ├── 📂 sql/
│   │       ├── sample_postgres.sql
│   │       └── sample_mysql.sql
│       ├── 📂 json/
│   │       └── sample_schema.json
│       └── 📂 nosql/
│           └── sample_mongo.json
│
├── 📂 benches/                          # ⚡ Performance benchmarks
│   ├── sqlgen_bench.rs
│   ├── converter_bench.rs
│   └── dataflow_bench.rs
│
├── 📂 scripts/                          # 🔨 Build automation
│   ├── setup.sh                         # Initial setup
│   ├── codegen.sh                       # flutter_rust_bridge codegen
│   ├── build_android.sh                 # cargo-ndk builds
│   ├── build_ios.sh                     # cargo-lipo builds
│   ├── build_desktop.sh                 # Win/Mac/Linux
│   ├── build_all.sh                     # All platforms
│   └── release.sh                       # Release builds
│
├── 📂 docs/                             # 📚 Documentation
│   ├── architecture.md
│   ├── adding-new-dialect.md            # Guide for new dialect
│   ├── adding-converter.md              # Guide for new converter
│   ├── dataflow-algorithm.md
│   └── api-reference.md
│
└── 📂 target/                           # Build output (gitignored)
```

---

## 📋 Crate Responsibilities (Quick Reference)

| Crate | Responsibility | On-Device? | Engineer Relevance |
|-------|---------------|------------|-------------------|
| core | Domain models (Table, Column, Schema, Relationship) | ✅ Yes | Shared schema model |
| dialects | 30+ dialect definitions + type maps | ✅ Yes | Multi-DB SQL generation |
| dbx-adapter | 100+ database drivers & introspection | ✅ Yes | Production database support |
| parser | Import: SQL/NoSQL/Mermaid → Schema | ✅ Yes | Schema import |
| sqlgen | Export: Schema → SQL DDL | ✅ Yes | Dialect-specific DDL |
| migration | Versioned migration files (Flyway/Liquibase/Alembic) | ✅ Yes | Production migrations |
| converter | Format + Dialect + NoSQL converters | ✅ Yes | Data migration |
| infra | Docker Compose, K8s, Terraform, Helm | ✅ Yes | Infrastructure as Code |
| inference | Schema inference from data | ✅ Yes | NoSQL → SQL |
| dataflow | Dependency graph + BFS + error prediction | ✅ Yes | Live simulation |
| diff | Schema diff + migrations + rollback | ✅ Yes | Safe deployments |
| lint | Schema linting, index advisor, breaking change | ✅ Yes | Code quality |
| mockdata | Mock data generation | ✅ Yes | Testing data |
| mermaid | Mermaid erDiagram generation | ✅ Yes | Docs-as-code |
| docsgen | Markdown/HTML/PDF documentation | ✅ Yes | Technical docs |
| ai-client | Cloud AI HTTP calls (OpenAI/Claude) | ⚠️ HTTP only | Schema suggestions |
| cloud | Supabase sync (OAuth, Management API) | ⚠️ HTTP only | Versioned storage |
| subscription | Plan gating & entitlements | ✅ Yes | Feature flags |
| ci-cd | CI/CD pipeline integration (GitHub Actions, GitLab CI) | ✅ Yes | Automated migrations |
| ffi | Flutter bridge (public API surface) | ✅ Yes | Type-safe bridge |

---

## 🔗 Crate Dependency Flow

```mermaid
flowchart TD
    FFI[ffi<br/>Public API] --> SQLGEN[sqlgen]
    FFI --> CONV[converter]
    FFI --> FLOW[dataflow]
    FFI --> DIFF[diff]
    FFI --> MOCK[mockdata]
    FFI --> MERMAID[mermaid]
    FFI --> DOCS[docsgen]
    FFI --> PARSER[parser]
    FFI --> INFER[inference]
    FFI --> LINT[lint]
    FFI --> INFRA[infra]
    FFI --> CI[ci-cd]
    FFI --> AI[ai-client]
    FFI --> CLOUD[cloud]
    FFI --> SUB[subscription]
    
    SQLGEN --> DIALECTS[dialects]
    CONV --> DIALECTS
    PARSER --> DIALECTS
    DBX[dbx-adapter] --> DIALECTS
    
    SQLGEN --> CORE[core]
    CONV --> CORE
    FLOW --> CORE
    DIFF --> CORE
    PARSER --> CORE
    DIALECTS --> CORE
    MOCK --> CORE
    MERMAID --> CORE
    DOCS --> CORE
    INFER --> CORE
    LINT --> CORE
    INFRA --> CORE
    CI --> CORE
    
    AI -->|HTTPS| CLOUDAI[☁️ Cloud AI API]
    CLOUD -->|HTTPS| SUPA[☁️ Supabase]
    
    style FFI fill:#4f46e5,color:#fff
    style CORE fill:#10b981,color:#fff
    style DIALECTS fill:#f59e0b,color:#fff
    style DBX fill:#8b5cf6,color:#fff
    style AI fill:#ef4444,color:#fff
    style INFRA fill:#f59e0b,color:#fff
```

**Key Principle:** Sab crates core par depend karte hain (shared models). ffi sabko Flutter se connect karta hai. dialects aur dbx-adapter ek central knowledge base hain.

---

## 🤖 AI Model Clarification (Important)

```mermaid
flowchart LR
    subgraph DEVICE["📱 On-Device Rust"]
        AIC[ai-client crate<br/>HTTP Client only]
    end
    
    subgraph CLOUD["☁️ Cloud"]
        API[AI API Endpoint]
        MODEL[Actual AI Model<br/>GPT/Claude/Custom]
    end
    
    AIC -->|Request: schema + prompt| API
    API --> MODEL
    MODEL --> API
    API -->|Response: suggestions| AIC
    
    style DEVICE fill:#4f46e5,color:#fff
    style CLOUD fill:#f59e0b,color:#fff
    style MODEL fill:#ef4444,color:#fff
```

### Kya NAHI hoga on-device:

| ❌ Not On-Device | Reason |
|------------------|--------|
| Koi ML model file (.onnx, .tflite, etc.) | App size badegi |
| Koi inference engine | Complexity badhegi |
| Koi heavy AI dependency | GPU requirement nahi chahiye |

### Kya hoga on-device:

| ✅ On-Device | Purpose |
|--------------|---------|
| HTTP client (reqwest) | Call cloud AI API |
| Prompt templates | Structured prompts |
| Request/response types | Type-safe API communication |
| API key management | Secure key storage |
| Response parsing | Parse AI responses |

**Fayda:** App size chhota (~5MB vs ~200MB+), koi GPU requirement nahi, easy updates.

---

## 🏭 Production-Ready Checklist

### Workspace Configuration

| Item | Purpose |
|------|---------|
| workspace.dependencies | Shared dependency versions (ek jagah) |
| workspace.package | Shared metadata (version, authors) |
| Feature flags | Optional dialects/converters (size control) |
| lto = true | Link-time optimization (release) |
| strip = true | Remove debug symbols (size) |

### Error Handling Strategy

```mermaid
flowchart LR
    A[Each crate] -->|thiserror| B[Typed errors]
    B --> C[ffi boundary]
    C -->|Convert to| D[User-friendly<br/>error codes]
    D --> E[Flutter shows<br/>localized message]
    
    style B fill:#ef4444,color:#fff
    style D fill:#10b981,color:#fff
```

- Library crates: `thiserror` (typed errors)
- FFI boundary: Errors ko codes mein convert
- Flutter: User-friendly messages

### Testing Strategy

| Level | Location | What |
|-------|----------|------|
| Unit tests | Each src/ | Individual functions |
| Integration tests | integration-tests/ | Cross-crate flows |
| Fixtures | fixtures/ | Sample SQL/JSON/NoSQL |
| Benchmarks | benches/ | Performance |
| Snapshot tests | Per crate | Output consistency |

### CI/CD Pipeline

```mermaid
flowchart LR
    PR[Pull Request] --> LINT[clippy + fmt]
    LINT --> TEST[cargo test]
    TEST --> BUILD[Build all targets]
    
    TAG[Git Tag] --> RELEASE[Release build]
    RELEASE --> ANDROID[Android .so]
    RELEASE --> IOS[iOS .a]
    RELEASE --> DESKTOP[Win/Mac/Linux]
    
    MIG[Schema Change] --> MIGRATE[Schema Migration CI]
    MIGRATE --> DRYRUN[Dry Run]
    DRYRUN --> APPLY[Apply to Staging]
    
    style TEST fill:#10b981,color:#fff
    style RELEASE fill:#f59e0b,color:#fff
    style MIGRATE fill:#8b5cf6,color:#fff
```

---

## 📦 Feature Flags (Size Control)

Har dialect/converter ko optional feature bana, taaki binary size control ho:

| Feature Flag | What it enables | Tier |
|--------------|-----------------|------|
| dialect-postgres | PostgreSQL support | Free |
| dialect-oracle | Oracle support (premium) | Team |
| dialect-snowflake | Snowflake support (premium) | Team |
| converter-parquet | Parquet conversion | Team |
| converter-nosql | NoSQL converters | Team/Enterprise |
| dataflow | Data flow engine | Pro |
| ai-client | AI integration | Team |
| cloud-sync | Cloud sync | Pro |
| schema-lint | Schema linting rules | Team |
| deploy-gates | Production deploy approval | Enterprise |
| audit-logs | Immutable audit trail | Enterprise |
| sso | SSO/SAML/OIDC | Enterprise |
| infra-docker | Docker Compose export | Team |
| infra-k8s | Kubernetes manifests | Enterprise |
| infra-terraform | Terraform export | Enterprise |

**Fayda:** Free tier ke liye chhota binary, Pro/Team ke liye full.

---

## 🎯 Key Design Principles

| Principle | Description |
|-----------|-------------|
| Workspace = Modularity | Har feature alag crate, independent testing |
| Core = Single Source of Truth | Sab domain models ek jagah |
| Dialects = Pluggable | Naya dialect add karna = ek file add karna |
| FFI = Thin Layer | Sirf bridge, business logic nahi |
| AI = Cloud Only | On-device sirf HTTP client |
| Feature Flags = Size Control | Tier-based binary sizes |
| Error Types = Typed | Har crate ke apne typed errors |
| Tests = First Class | Har crate mein tests |
| Schema-as-Code = Primary | Schema files in Git, not just visual |

---

## 💡 Adding a New Dialect (Example Workflow)

```mermaid
flowchart LR
    A[1. Create file<br/>dialects/impls/newdb.rs] --> B[2. Implement<br/>Dialect trait]
    B --> C[3. Add type<br/>mappings]
    C --> D[4. Register in<br/>registry.rs]
    D --> E[5. Add feature<br/>flag]
    E --> F[6. Add tests]
    F --> G[✅ Done]
    
    style G fill:#10b981,color:#fff
```

**Is structure ka fayda:** Naya dialect add karna = ek file + registration. Koi breaking change nahi.

---

## 📊 Final Structure Summary

```
🏠 chartdb-engine/ (Workspace)
├── 20+ library crates
│   ├── 1 core (models)
│   ├── 1 dialects (30+ dialects)
│   ├── 1 dbx-adapter (100+ DB drivers)
│   ├── 1 parser (import)
│   ├── 1 sqlgen (export)
│   ├── 1 migration (versioned files)
│   ├── 1 converter (4 types)
│   ├── 1 infra (Docker/K8s/Terraform)
│   ├── 1 inference
│   ├── 1 dataflow (animation logic)
│   ├── 1 diff
│   ├── 1 lint (schema quality)
│   ├── 1 mockdata
│   ├── 1 mermaid
│   ├── 1 docsgen
│   ├── 1 ai-client (cloud HTTP)
│   ├── 1 cloud (Supabase sync)
│   ├── 1 subscription
│   ├── 1 ci-cd (pipeline integration)
│   └── 1 ffi (Flutter bridge)
├── integration-tests/
├── benches/
├── scripts/
├── docs/
└── target/ (gitignored)
```

---

*Rust folder structure designed for professional engineers: Schema-as-Code, Multi-Database, Infrastructure as Code, CI/CD, Schema Linting, and Production-grade modularity.*