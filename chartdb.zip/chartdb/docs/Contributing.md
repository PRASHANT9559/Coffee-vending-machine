# 🤝 Contributing

> Contributing guide for the ChartDB Clone project.
> Bug reports, feature requests, and pull requests are welcome.
> Built for Professional Engineers: Schema-as-Code, CI/CD, Code Review.

---

## 📖 Table of Contents

- [Code of Conduct](#-code-of-conduct)
- [Getting Started](#-getting-started)
- [Project Structure](#-project-structure)
- [How to Contribute](#-how-to-contribute)
- [Coding Standards](#-coding-standards)
- [Testing](#-testing)
- [Pull Request Process](#-pull-request-process)
- [Adding a New Dialect](#-adding-a-new-dialect)
- [Adding a New Converter](#-adding-a-new-converter)
- [Adding Infrastructure Export](#-adding-infrastructure-export)
- [License](#-license)

---

## 📜 Code of Conduct

We are committed to providing a welcoming and inclusive environment. Please read and follow our Code of Conduct:

- Be respectful and inclusive
- No harassment or discrimination
- Accept constructive criticism gracefully
- Focus on what is best for the community
- Follow engineering best practices

---

## 🚀 Getting Started

### Prerequisites

| Tool | Version |
|------|---------|
| Flutter | 3.x |
| Rust | 1.75+ |
| Dart | 3.x |
| Git | Latest |
| Docker | Latest (optional) |

### Setup

```bash
# Fork and clone the repository
git clone https://github.com/your-username/chartdb-clone.git
cd chartdb-clone

# Install Flutter dependencies
flutter pub get

# Install flutter_rust_bridge codegen
cargo install flutter_rust_bridge_codegen

# Generate FFI bindings
flutter_rust_bridge_codegen generate

# Add Flutter dependency
flutter pub add flutter_rust_bridge

# Run the app (desktop)
flutter run -d macos     # or linux, windows

# Run tests
cargo test
flutter test
```

---

## 📁 Project Structure

```
chartdb-engine/              # Rust workspace
├── crates/                  # All library crates
│   ├── core/                # Domain models
│   ├── dialects/            # 30+ dialect definitions
│   ├── dbx-adapter/         # 100+ database drivers
│   ├── sqlgen/              # SQL DDL generator
│   ├── migration/           # Versioned migration files
│   ├── converter/           # Format/Dialect/NoSQL/Infra converters
│   ├── infra/               # Docker/K8s/Terraform export
│   ├── dataflow/            # Live data flow engine
│   ├── diff/                # Schema diff engine
│   ├── lint/                # Schema linting
│   ├── ci-cd/               # CI/CD integration
│   ├── ffi/                 # Flutter FFI bridge
│   └── ...                  # More crates
lib/                         # Flutter/Dart code
├── ui/                      # Screens & widgets
├── services/                # Business logic
├── models/                  # Data models
├── providers/               # State management
└── generated/               # Auto-generated FFI bindings
docs/                        # Documentation
scripts/                     # Build automation
```

---

## 🔧 How to Contribute

### 1. Report a Bug

1. Check if the issue already exists
2. Create a new issue with:
   - Clear title
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots (if UI)
   - Platform (Android/iOS/macOS/Windows/Linux)
   - Flutter and Rust versions
   - Database dialect (PostgreSQL/MySQL/etc.)

### 2. Suggest a Feature

1. Open a feature request issue
2. Describe the feature and use case
3. Mention which tier (Free/Pro/Team/Enterprise) it should be in
4. Discuss with maintainers before implementing
5. For engineer features: mention Schema-as-Code, Multi-Env, CI/CD, Performance, or Security impact

### 3. Submit a Pull Request

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Make your changes
4. Run tests: `cargo test` and `flutter test`
5. Run lint: `cargo clippy` and `flutter analyze`
6. Format code: `cargo fmt` and `flutter format`
7. Commit: `git commit -m "feat: your feature description"`
8. Push: `git push origin feature/your-feature`
9. Open a Pull Request

---

## 💻 Coding Standards

### Rust

| Standard | Description |
|----------|-------------|
| Edition | 2021 |
| Formatting | `rustfmt` (default) |
| Linting | `clippy` with `-D warnings` |
| Error handling | `thiserror` for typed errors |
| Documentation | All public items must have doc comments |
| Testing | Unit tests in each crate |
| Schema-as-Code | Schema files in Git, not just visual |

### Dart/Flutter

| Standard | Description |
|----------|-------------|
| Formatting | `dart format` |
| Linting | `flutter analyze` |
| State management | Riverpod or Bloc |
| Naming | snake_case for files, PascalCase for classes |
| Documentation | Public API must have doc comments |

### Commit Messages

Use conventional commits:

```
feat: add Oracle dialect support
fix: resolve cascade rule bug in dataflow
docs: update architecture documentation
style: format Rust code with rustfmt
test: add unit tests for sqlgen crate
refactor: simplify dialect registry
ci: add schema-migration workflow
```

---

## 🧪 Testing

### Rust Tests

```bash
# Run all tests
cargo test

# Run tests for specific crate
cargo test -p core
cargo test -p sqlgen
cargo test -p dataflow
cargo test -p diff
cargo test -p lint

# Run with output
cargo test -- --nocapture

# Run clippy
cargo clippy -- -D warnings

# Check formatting
cargo fmt --check
```

### Flutter Tests

```bash
# Run all tests
flutter test

# Run specific test
flutter test test/widget_test.dart

# Analyze code
flutter analyze

# Format code
flutter format .
```

### Integration Tests

Integration tests are in `integration-tests/` directory and test cross-crate flows:

- `sql_to_mysql_test.rs` — SQL to MySQL conversion
- `postgres_to_snowflake_test.rs` — PostgreSQL to Snowflake
- `sql_to_mongodb_test.rs` — SQL to MongoDB
- `dataflow_simulation_test.rs` — Data flow simulation
- `diff_test.rs` — Schema diff correctness
- `lint_test.rs` — Schema linting rules

### Schema Migration Tests

```bash
# Test migration generation
cargo test -p migration

# Test dry run deploy
cargo run --bin schema-deploy -- --env staging --dry-run
```

---

## 🔀 Pull Request Process

1. **Fork** the repository
2. **Create branch** from `main`
3. **Make changes** following coding standards
4. **Run tests** — all tests must pass
5. **Update documentation** if needed
6. **Open PR** with clear description
7. **Address review comments**
8. **Maintainer merges** after approval

### PR Checklist

- [ ] Tests pass (`cargo test` + `flutter test`)
- [ ] Lint passes (`cargo clippy` + `flutter analyze`)
- [ ] Code formatted (`cargo fmt` + `dart format`)
- [ ] Documentation updated (if API changed)
- [ ] No breaking changes (or noted in PR)
- [ ] Schema linting passes (`cargo test -p lint`)
- [ ] CI/CD workflow updated (if needed)

---

## 🗄️ Adding a New Dialect

New dialect = one file + registration. No breaking changes.

### Workflow

```mermaid
flowchart LR
    A[1. Create file<br/>dialects/impls/newdb.rs] --> B[2. Implement<br/>Dialect trait]
    B --> C[3. Add type<br/>mappings]
    C --> D[4. Register in<br/>registry.rs]
    D --> E[5. Add feature<br/>flag]
    E --> F[6. Add tests]
    F --> G[✅ Done]
    
    style G fill:#10b981,color:#fff
```

### Steps

1. Create `crates/dialects/src/impls/relational/newdb.rs`
2. Implement the `Dialect` trait
3. Add data type mappings
4. Register in `crates/dialects/src/registry.rs`
5. Add feature flag in `Cargo.toml`
6. Add tests in `crates/dialects/tests/`
7. Update documentation in `docs/adding-new-dialect.md`

---

## 🔄 Adding a New Converter

### Data Format Converter

1. Create file in `crates/converter/src/format/`
2. Implement parse and serialize functions
3. Register in `crates/converter/src/format/mod.rs`
4. Add feature flag if premium

### Dialect Converter

1. Add conversion logic in `crates/converter/src/dialect/`
2. Handle unsupported features with workarounds
3. Add feature resolver for unsupported features

### SQL ↔ NoSQL Converter

1. Add mapping strategy in `crates/converter/src/nosql/mapping_strategy.rs`
2. Add to_nosql or from_nosql implementation
3. Register in appropriate module

### Infrastructure Export (NEW)

1. Create file in `crates/infra/src/`
2. Implement infrastructure generation (Docker Compose, K8s, Terraform, etc.)
3. Register in `crates/infra/src/lib.rs`
4. Add feature flag if premium

---

## 🏷️ Issue Labels

| Label | Description |
|-------|-------------|
| `bug` | Something isn't working |
| `enhancement` | New feature or improvement |
| `documentation` | Docs improvements |
| `good-first-issue` | Good for new contributors |
| `help-wanted` | Need community help |
| `performance` | Performance-related |
| `security` | Security-related |
| `breaking` | Breaking change |
| `schema-as-code` | Schema-as-Code related |
| `ci-cd` | CI/CD related |
| `infra` | Infrastructure as Code related |

---

## 👥 Maintainers

- Project Owner: [Your Name]
- Contact: [Your Email]

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- ChartDB for inspiration
- flutter_rust_bridge for FFI
- Supabase for backend infrastructure
- Mermaid.js for diagram syntax
- dbx for multi-database support

---

*Contributing guide updated for professional engineering: Schema-as-Code, CI/CD, Code Review, and Infrastructure as Code.*