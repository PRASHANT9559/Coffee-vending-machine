# 🎬 Data Flow Algorithm

> Live Data Flow Animation algorithm for the ChartDB Clone.
> Code-free, concept-based design with Mermaid diagrams.
> STAR feature for demo and junior engineer learning.
> Note: Senior engineers care more about schema safety (Section: Breaking Change Detection) than animation.

---

## 🎯 Algorithm Ka Kaam Kya Hai?

Jab user koi operation karta hai (jaise profile table mein data add/update/delete), toh algorithm ko 3 sawaalon ka jawaab dena hai:

| Sawaal | Jawab |
|--------|-------|
| Data kahan-kahan jaayega? | Propagation path |
| Kaunsi cheezein change hongi? | Impact |
| Kahan error aayega? | Failure points |

Yeh sab animation engine ko bhejta hai jo phir visual dikhata hai.

---

## 🏗️ Algorithm Ke 5 Phases

```mermaid
flowchart LR
    A[Phase 1<br/>Graph Banao] --> B[Phase 2<br/>Operation Samjho]
    B --> C[Phase 3<br/>Traversal<br/>BFS/DFS]
    C --> D[Phase 4<br/>Error Check]
    D --> E[Phase 5<br/>Animation<br/>Sequence]
    
    style A fill:#3b82f6,color:#fff
    style C fill:#f59e0b,color:#fff
    style D fill:#ef4444,color:#fff
    style E fill:#10b981,color:#fff
```

---

## 🔷 PHASE 1: Dependency Graph Banao

Sabse pehle Rust engine poore schema ko ek graph mein convert karta hai. Har cheez ek node hai, aur connections edges hain.

### Node Types

```mermaid
flowchart TD
    subgraph NODES["Graph Ke Nodes"]
        T[📋 Tables]
        C[🔤 Columns]
        FK[🔗 Foreign Keys]
        TR[⚡ Triggers]
        V[👁️ Views]
        IX[📇 Indexes]
        CN[🛡️ Constraints]
    end
```

### Edge Types

| Edge Type | Matlab | Example |
|-----------|--------|---------|
| Foreign Key | Table A → Table B | profile.user_id → users.id |
| Cascade Rule | Delete/update par kya ho | ON DELETE CASCADE |
| Trigger Link | Trigger fire hoga | profile update → audit_log insert |
| View Dependency | View is table ko use karta hai | active_users_view uses profile |
| Index Dependency | Index is column par hai | idx_email on users.email |

### Graph Example

```mermaid
flowchart TD
    USERS[📋 users]
    PROFILE[📋 profile]
    ORDERS[📋 orders]
    NOTIF[📋 notifications<br/>⚠️ RESTRICT]
    AUDIT[📋 audit_log]
    TRIGGER[⚡ trigger_on_profile]
    VIEW[👁️ active_users_view]
    
    PROFILE -->|FK: user_id| USERS
    ORDERS -->|FK: user_id| USERS
    NOTIF -->|FK: user_id<br/>ON DELETE RESTRICT| USERS
    PROFILE -.->|fires| TRIGGER
    TRIGGER -.->|inserts into| AUDIT
    USERS -.->|used by| VIEW
    PROFILE -.->|used by| VIEW
    
    style USERS fill:#3b82f6,color:#fff
    style NOTIF fill:#ef4444,color:#fff
    style TRIGGER fill:#f59e0b,color:#fff
```

**Key Point:** Graph ek baar banta hai aur cache ho jaata hai. Jab bhi schema change ho, sirf tabhi dobara banta hai.

---

## 🔷 PHASE 2: Operation Samjho

Ab user koi operation select karta hai. Algorithm ko samajhna hai:

| Sawaal | Jawab Chahiye |
|--------|---------------|
| Kaunsa operation? | INSERT / UPDATE / DELETE |
| Kaunsi table? | e.g., users |
| Kaunse columns? | e.g., sirf email ya poora row |
| Kitne rows? | Ek row ya saari rows |
| Kya condition? | e.g., "sirf user_id = 101" |

### Operation Ka "Blast Radius"

```mermaid
flowchart LR
    subgraph INSERT["➕ INSERT"]
        I1[Naya row aata hai]
        I2[Constraints check hote hain]
        I3[Triggers fire hote hain]
        I4[Indexes update hote hain]
    end
    
    subgraph UPDATE["✏️ UPDATE"]
        U1[Row change hota hai]
        U2[Aagar FK column change → cascade]
        U3[Triggers fire hote hain]
        U4[Views refresh hote hain]
    end
    
    subgraph DELETE["🗑️ DELETE"]
        D1[Row hat-ta hai]
        D2[Children par cascade check]
        D3[RESTRICT ho toh error]
        D4[Indexes update hote hain]
    end
```

---

## 🔷 PHASE 3: Traversal (Data Ka Safar Track Karo)

Yeh sabse important phase hai. Algorithm graph mein BFS (Breadth-First Search) use karke ek node se doosre node tak jaata hai.

### BFS Kyun?

Kyunki data layer-by-layer fail-ta hai:

- **Level 0:** Source table (jahan operation hua)
- **Level 1:** Direct connections (FK, triggers)
- **Level 2:** Unke connections
- **Level 3:** Aage... aur gehra

```mermaid
flowchart TD
    L0[🎯 Level 0: users<br/>DELETE operation]
    L1A[Level 1: profile<br/>FK check]
    L1B[Level 1: orders<br/>FK check]
    L1C[Level 1: notifications<br/>FK check]
    L2A[Level 2: profile ka trigger]
    L2B[Level 2: views refresh]
    
    L0 --> L1A
    L0 --> L1B
    L0 --> L1C
    L1A --> L2A
    L1A --> L2B
    L1B --> L2B
    
    style L0 fill:#3b82f6,color:#fff
    style L1C fill:#ef4444,color:#fff
```

### Cascade Rules Ka Faisla

Har FK edge par ek rule hota hai:

```mermaid
flowchart TD
    Start[DELETE users row] --> CheckFK{Child table<br/>ka rule?}
    
    CheckFK -->|ON DELETE CASCADE| Cascade[✅ Child bhi delete<br/>Aage badho]
    CheckFK -->|ON DELETE SET NULL| SetNull[🟡 FK null karo<br/>Aage badho]
    CheckFK -->|ON DELETE RESTRICT| Restrict[🔴 ERROR!<br/>Ruk jao]
    CheckFK -->|ON DELETE NO ACTION| NoAction[🔴 ERROR!<br/>Ruk jao]
    
    Cascade --> NextLevel[Next level traverse]
    SetNull --> NextLevel
    Restrict --> MarkError[❌ Error mark karo]
    NoAction --> MarkError
    
    style Cascade fill:#10b981,color:#fff
    style SetNull fill:#f59e0b,color:#fff
    style Restrict fill:#ef4444,color:#fff
    style NoAction fill:#ef4444,color:#fff
```

---

## 🔷 PHASE 4: Error Detection (Sabse Valuable Part)

Yeh phase har step par constraints check karta hai aur predict karta hai ki kya fail hoga.

### Kaunse Errors Detect Hote Hain

```mermaid
flowchart TD
    ERR[🔍 Error Detection] --> E1[🔑 FK Violation<br/>Referenced row nahi mila]
    ERR --> E2[🚫 NOT NULL Violation<br/>Null value jahan allowed nahi]
    ERR --> E3[⚖️ UNIQUE Violation<br/>Duplicate value]
    ERR --> E4[📏 CHECK Violation<br/>Value range se bahar]
    ERR --> E5[🛡️ RESTRICT Block<br/>Child rows exist karte hain]
    ERR --> E6[🔤 Type Mismatch<br/>Galat data type]
    
    style ERR fill:#ef4444,color:#fff
```

### Error Kaise Predict Hota Hai

Algorithm har node par simulation karta hai (bina actual database touch kiye):

| Check | Algorithm Kya Karta Hai |
|-------|------------------------|
| FK check | Dekhta hai: kya referenced row exist karti hai? |
| NOT NULL | Dekhta hai: kya koi required column khali ja raha hai? |
| UNIQUE | Dekhta hai: kya yeh value pehle se hai? |
| CHECK | Dekhta hai: kya value rule tod rahi hai? (e.g., age > 0) |
| RESTRICT | Dekhta hai: kya child rows maujood hain jo block karengi? |

### Error Ka "Severity" Level

```mermaid
flowchart LR
    subgraph BLOCKING["🔴 BLOCKING"]
        B1[Operation ruk jayega]
        B2[Poora transaction fail]
    end
    
    subgraph WARNING["🟡 WARNING"]
        W1[Operation chalega]
        W2[Lekin side-effect hoga]
    end
    
    subgraph INFO["🔵 INFO"]
        I1[Normal propagation]
        I2[No issue]
    end
    
    style BLOCKING fill:#ef4444,color:#fff
    style WARNING fill:#f59e0b,color:#fff
    style INFO fill:#3b82f6,color:#fff
```

---

## 🔷 PHASE 5: Animation Sequence Banao

Ab tak algorithm ke paas hai:
- ✅ Poora traversal path
- ✅ Har step ka result (success/error)
- ✅ Ordered sequence

Ab isko animation steps mein convert karta hai:

```mermaid
flowchart LR
    Data[Graph + Errors] --> Seq[Sequence Generator]
    Seq --> S1[Step 1: Source highlight]
    Seq --> S2[Step 2: Packet move to FK]
    Seq --> S3[Step 3: Target update]
    Seq --> S4[Step 4: Trigger fire]
    Seq --> S5[Step 5: Error flash]
    
    S1 --> Anim[🎬 Animation Engine]
    S2 --> Anim
    S3 --> Anim
    S4 --> Anim
    S5 --> Anim
    
    style Seq fill:#f59e0b,color:#fff
    style Anim fill:#10b981,color:#fff
```

### Har Step Mein Kya Hota Hai

| Field | Matlab |
|-------|--------|
| From Node | Kahan se data aa raha hai |
| To Node | Kahan ja raha hai |
| Action | INSERT/UPDATE/DELETE/CHECK |
| Status | ✅ Success / 🔴 Error / 🟡 Warning |
| Duration | Kitni der animation chale |
| Message | User ko kya dikhana hai |

---

## 🎬 Poora Example Walkthrough

### Scenario:

User users table se ek row DELETE karta hai (user_id = 101)

### Schema:

- users (main table)
- profile (FK → users, CASCADE)
- orders (FK → users, CASCADE)
- notifications (FK → users, RESTRICT) ← Yahan problem hai!
- audit_log (trigger se banta hai)

### Algorithm Ka Thought Process:

```mermaid
sequenceDiagram
    participant User
    participant Algo as Algorithm
    participant Graph as Dependency Graph
    
    User->>Algo: DELETE users (id=101)
    
    Algo->>Graph: users se connected nodes dhundo
    Graph-->>Algo: profile, orders, notifications
    
    Algo->>Algo: Level 1 traverse karo
    
    Algo->>Graph: profile ka rule?
    Graph-->>Algo: CASCADE
    Algo->>Algo: ✅ profile rows delete honge<br/>(aage badho)
    
    Algo->>Graph: orders ka rule?
    Graph-->>Algo: CASCADE
    Algo->>Algo: ✅ orders rows delete honge<br/>(aage badho)
    
    Algo->>Graph: notifications ka rule?
    Graph-->>Algo: RESTRICT
    Algo->>Algo: ⚠️ Check karo: koi notification<br/>is user ka hai?
    
    Algo->>Algo: Haan, 3 notifications hain!
    Algo->>Algo: 🔴 ERROR MARK karo<br/>notifications par
    
    Algo->>Algo: Triggers check karo
    Algo->>Graph: profile deletion trigger?
    Graph-->>Algo: audit_log insert
    Algo->>Algo: 🟡 audit_log mein entry hogi
    
    Algo->>Algo: Views refresh list banao
    
    Algo->>User: Sequence return karo:<br/>1. users (source)<br/>2. profile (cascade ✅)<br/>3. orders (cascade ✅)<br/>4. notifications (ERROR 🔴)<br/>5. audit_log (trigger 🟡)
```

### Animation Kya Dikhayegi:

```mermaid
flowchart TD
    STEP1[1️⃣ users table<br/>🔵 Highlight<br/>DELETE id=101]
    STEP2[2️⃣ Data packet<br/>users → profile<br/>🟢 CASCADE]
    STEP3[3️⃣ Data packet<br/>users → orders<br/>🟢 CASCADE]
    STEP4[4️⃣ Data packet<br/>users → notifications<br/>🔴 BLOCKED + SHAKE]
    STEP5[5️⃣ Trigger fire<br/>profile → audit_log<br/>🟡 INFO]
    STEP6[6️⃣ Summary:<br/>✅ 2 success<br/>🔴 1 error<br/>🟡 1 trigger]
    
    STEP1 --> STEP2 --> STEP3 --> STEP4 --> STEP5 --> STEP6
    
    style STEP1 fill:#3b82f6,color:#fff
    style STEP2 fill:#10b981,color:#fff
    style STEP3 fill:#10b981,color:#fff
    style STEP4 fill:#ef4444,color:#fff
    style STEP5 fill:#f59e0b,color:#fff
    style STEP6 fill:#8b5cf6,color:#fff
```

User ko exactly pata chal gaya:
- ✅ profile aur orders delete ho jayenge
- 🔴 notifications ki wajah se operation FAIL hoga
- 💡 Fix: notifications ka rule CASCADE karo, ya pehle notifications delete karo

---

## 🧩 Edge Cases (Jo Algorithm Handle Karega)

| Edge Case | Algorithm Kya Karta Hai |
|-----------|------------------------|
| Circular Dependency | A → B → A. Infinite loop se bachne ke liye "visited" track karta hai |
| Self-Referencing FK | Table khud se connected (e.g., employee.manager). Depth limit lagata hai |
| Deep Chains | 10+ levels deep. Max depth limit rakhta hai (e.g., 20) |
| Multiple Paths | Ek table tak 2 raaste. Dono dikhata hai |
| Soft Deletes | deleted_at column. Logic alag handle karta hai |
| Triggers on Triggers | Chain of triggers. Recursive check karta hai |

---

## ⚡ Performance Kaise Fast Rahegi

| Technique | Fayda |
|-----------|-------|
| Graph Caching | Graph ek baar banta hai, baar-baar nahi |
| Incremental Update | Schema change par sirf affected hissa update |
| Lazy Traversal | Sirf utna traverse jitna user ko dikhana hai |
| Rust Speed | Graph operations Rust mein = blazing fast |
| Pre-computed Paths | Common paths pehle se calculate |

---

## 🎨 Algorithm → Animation Bridge

```mermaid
flowchart LR
    subgraph RUST["🦀 Rust Engine"]
        G[Dependency Graph]
        T[Traversal Logic]
        E[Error Detection]
        S[Sequence Builder]
    end
    
    subgraph BRIDGE["🔗 FFI Bridge"]
        FFI[flutter_rust_bridge]
    end
    
    subgraph FLUTTER["🐦 Flutter"]
        ANIM[Animation Controller]
        PACK[Data Packet Renderer]
        GLOW[Glow Effects]
        SHAKE[Error Shake]
        TIME[Timeline Scrubber]
    end
    
    G --> T --> E --> S
    S -->|JSON steps| FFI
    FFI --> ANIM
    ANIM --> PACK
    ANIM --> GLOW
    ANIM --> SHAKE
    ANIM --> TIME
    
    style RUST fill:#4f46e5,color:#fff
    style FLUTTER fill:#f59e0b,color:#fff
```

Rust logic karta hai, Flutter visuals karta hai. Beech mein ek simple JSON structure jaata hai jo batata hai: "Step 1: yahan se yahan tak, yeh action, yeh status."

---

## 📋 Algorithm Ka Output (Animation Ko Kya Milta Hai)

Algorithm end mein ek ordered list deta hai:

| Step | From | To | Action | Status | Message |
|------|------|----|--------|--------|---------|
| 1 | — | users | DELETE | ✅ | Source row deleted |
| 2 | users | profile | CASCADE DELETE | ✅ | 1 profile row deleted |
| 3 | users | orders | CASCADE DELETE | ✅ | 5 order rows deleted |
| 4 | users | notifications | RESTRICT CHECK | 🔴 | 3 rows block deletion |
| 5 | profile | audit_log | TRIGGER INSERT | 🟡 | Audit entry created |

Yahi table animation timeline ban jaati hai. 🎬

---

## 🎯 Summary: Algorithm Ka Flow

```mermaid
flowchart TD
    START([User Operation]) --> P1[Phase 1<br/>Graph banao/cache]
    P1 --> P2[Phase 2<br/>Operation samjho]
    P2 --> P3[Phase 3<br/>BFS Traversal]
    P3 --> CASCADE{Cascade<br/>Rules?}
    CASCADE -->|Aage badho| P3
    CASCADE -->|Error| P4[Phase 4<br/>Error Mark]
    P4 --> P3
    P3 --> DONE{Sab nodes<br/>cover ho gaye?}
    DONE -->|Nahi| P3
    DONE -->|Haan| P5[Phase 5<br/>Sequence banao]
    P5 --> ANIM[🎬 Animation Engine]
    ANIM --> USER([User ko dikhao])
    
    style P3 fill:#f59e0b,color:#fff
    style P4 fill:#ef4444,color:#fff
    style ANIM fill:#10b981,color:#fff
```

---

## 💡 Key Takeaways

- Graph Theory par based hai — nodes (tables) + edges (relationships)
- BFS Traversal se data ka path trace hota hai (layer by layer)
- Cascade Rules har edge par decide karte hain ki aage badhna hai ya rukna hai
- Error Detection har step par constraints simulate karke hota hai
- Sequence Builder sab kuch ordered animation steps mein convert karta hai
- Rust mein logic = fast, Flutter mein visuals = smooth
- Circular dependencies ko "visited set" se handle karte hain

**Pro Engineer Note:** Ye animation feature demo aur junior engineer sikhne ke liye accha hai. Senior production engineer ke liye zyada zaroori hai:
- Schema Diff Review (breaking change detection)
- Deploy Gates (production approval)
- Rollback (failure recovery)
- Index Advisor (performance)

Ye algorithm tera moat hai (competitive advantage) for marketing and onboarding.