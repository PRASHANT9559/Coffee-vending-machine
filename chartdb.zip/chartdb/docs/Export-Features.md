# 📦 Export Features

> Complete export system for the ChartDB Clone — Visual, Code, Documentation, Data, Cloud, and Infrastructure exports.
> Built for Professional Engineers who treat database schema as production code.

---

## 📦 Export Categories (Overview)

```mermaid
flowchart TD
    EXPORT[📦 Export Center] --> CAT1[🎨 Visual<br/>Images/Docs]
    EXPORT --> CAT2[💻 Code/Scripts<br/>SQL/ORM/Infra]
    EXPORT --> CAT3[📖 Documentation<br/>Wiki/PDF/API Docs]
    EXPORT --> CAT4[📊 Data<br/>Mock/CSV]
    EXPORT --> CAT5[☁️ Cloud<br/>Storage/Sync]
    EXPORT --> CAT6[🏗️ Infrastructure<br/>Docker/K8s/CI-CD]
    
    CAT1 --> V1[PNG, SVG, PDF]
    CAT2 --> C1[SQL, Mermaid, Prisma, Docker, K8s...]
    CAT3 --> D1[Markdown, HTML, Excel, OpenAPI]
    CAT4 --> M1[CSV, JSON, SQL Inserts]
    CAT5 --> S1[Save, Share, Sync]
    CAT6 --> I1[Docker Compose, K8s YAML, GitHub Actions]
    
    style EXPORT fill:#4f46e5,stroke:#3730a3,stroke-width:3px,color:#fff
    style CAT6 fill:#8b5cf6,color:#fff
```

---

## 1. Visual Exports (Diagram/Images)

| Format | Use Case | Free | Pro | Team |
|--------|----------|------|-----|------|
| PNG | Screenshot, sharing | ✅ (watermark + low-res) | ✅ HD | ✅ HD |
| SVG | Vector, scalable | ❌ | ✅ | ✅ |
| PDF | Print, client delivery | ❌ | ✅ | ✅ |
| High-Res Poster | Large diagrams | ❌ | ✅ | ✅ |
| Animated GIF/Video | Data flow demo | ❌ | ✅ (short) | ✅ (full) |

---

## 2. Code & Scripts (Engineer Critical)

### 2.1 SQL DDL (Dialect-specific)

| Dialect | Description | Tier |
|---------|-------------|------|
| PostgreSQL | .sql for Postgres/Supabase | Free |
| MySQL | MySQL syntax | Free |
| SQL Server | T-SQL | Pro |
| SQLite | SQLite syntax | Free |
| MariaDB | MariaDB syntax | Pro |
| Oracle | PL/SQL | Team |
| ...and 24 more | See SQL-DDL-Dialects.md | Pro/Team |

### 2.2 Migration Scripts (Critical for Production)

| Type | Use Case | Tier |
|------|----------|------|
| Forward Migration | CREATE TABLE scripts | Free |
| Diff Migration | Sirf ALTER TABLE (changes) | Pro |
| Rollback Script | Undo ke liye | Enterprise |
| Seeded Migration | Data ke saath | Pro |
| Versioned Migration | V1__init.sql, V2__add_users.sql | Team |
| Flyway Format | V1__init.sql | Pro |
| Liquibase Format | XML/YAML/SQL | Team |
| Alembic Format | .py files | Team |
| Knex Format | .js files | Pro |
| Prisma Migrate | .prisma + SQL | Pro |
| Django Migrations | .py files | Team |
| Rails Migrations | .rb files | Team |
| Entity Framework | C# migrations | Team |

> 💡 Engineer Note: Migration scripts are critical. Production deployments require versioned, rollback-safe migrations.

### 2.3 ORM & Framework Code

| Format | Framework/Language | Tier |
|--------|-------------------|------|
| Prisma Schema | .prisma file | Pro |
| TypeORM | TypeScript entities | Pro |
| Sequelize | Node.js models | Pro |
| Django Models | Python models.py | Pro |
| SQLAlchemy | Python ORM | Pro |
| TypeScript Interfaces | types.ts | Pro |
| Go Structs | Golang models | Team |
| Java Entities (JPA) | Spring Boot | Team |
| Kotlin Data Classes | Android | Team |
| C# Entities (EF Core) | .NET | Team |

### 2.4 Diagram-as-Code

| Format | Use Case | Tier |
|--------|----------|------|
| Mermaid | GitHub/Notion embed | Pro |
| PlantUML | UML tools | Pro |
| DBML | dbdiagram.io | Pro |
| Graphviz (DOT) | Graph tools | Pro |

### 2.5 Infrastructure as Code (NEW — Engineer Critical)

| Format | Description | Tier |
|--------|-------------|------|
| Docker Compose | `docker-compose.yml` with DB + app services | Team |
| Kubernetes Manifests | `Deployment`, `Service`, `StatefulSet` YAML | Enterprise |
| Terraform | AWS RDS, Azure SQL, GCP Cloud SQL resources | Enterprise |
| Helm Charts | K8s package for DB deployment | Enterprise |
| Ansible Playbooks | DB provisioning and configuration | Enterprise |
| CloudFormation | AWS infrastructure as code | Enterprise |

### 2.6 API Code Generation

| Format | Description | Tier |
|--------|-------------|------|
| OpenAPI / Swagger | API documentation from schema | Team |
| Full CRUD API | Node.js/Express, Python/FastAPI, Go/Gin | Team |
| GraphQL Schema | GraphQL type definitions | Team |
| gRPC Proto | Protocol Buffer definitions | Team |

### 2.7 Code Exports — Subscription Gating

| Format | Free | Pro | Team | Enterprise |
|--------|------|-----|------|------------|
| SQL DDL (any dialect) | ✅ (5 tables) | ✅ Unlimited | ✅ | ✅ |
| Migration Scripts | ❌ | ✅ | ✅ | ✅ |
| Mermaid | ❌ | ✅ | ✅ | ✅ |
| Prisma / TypeORM | ❌ | ✅ | ✅ | ✅ |
| Django / SQLAlchemy | ❌ | ✅ | ✅ | ✅ |
| TypeScript Interfaces | ❌ | ✅ | ✅ | ✅ |
| Go / Java / C# | ❌ | ❌ | ✅ | ✅ |
| PlantUML / DBML | ❌ | ✅ | ✅ | ✅ |
| Docker Compose | ❌ | ❌ | ✅ | ✅ |
| Kubernetes Manifests | ❌ | ❌ | ❌ | ✅ |
| Terraform | ❌ | ❌ | ❌ | ✅ |
| OpenAPI / Swagger | ❌ | ❌ | ✅ | ✅ |
| Full CRUD API | ❌ | ❌ | ✅ | ✅ |

---

## 3. Documentation Exports

| Format | Use Case | Free | Pro | Team | Enterprise |
|--------|----------|------|-----|------|------------|
| Markdown | GitHub README | ❌ | ✅ | ✅ | ✅ |
| HTML Docs | Standalone website | ❌ | ✅ | ✅ | ✅ |
| PDF Report | Client delivery | ❌ | ✅ | ✅ | ✅ |
| Data Dictionary (Excel) | Column details | ❌ | ❌ | ✅ | ✅ |
| Confluence/Notion | Team wikis | ❌ | ❌ | ✅ | ✅ |
| API Docs (OpenAPI/Swagger) | For APIs | ❌ | ❌ | ✅ | ✅ |
| Schema Documentation | Auto-generated tech docs | ❌ | ❌ | ✅ | ✅ |

---

## 4. Data Exports (Mock Data)

| Format | Use Case | Free | Pro | Team |
|--------|----------|------|-----|------|
| CSV | Spreadsheet import | ✅ (10 rows) | ✅ Unlimited | ✅ |
| JSON | App seeding | ✅ (10 rows) | ✅ | ✅ |
| SQL INSERTs | Direct DB seeding | ❌ | ✅ | ✅ |
| Excel (.xlsx) | Business users | ❌ | ❌ | ✅ |
| Faker Config | Auto-gen rules | ❌ | ✅ | ✅ |

---

## 5. Cloud Storage

| Feature | Free | Pro | Team |
|---------|------|-----|------|
| Cloud Projects | 1 project | Unlimited | Unlimited |
| Storage Size | 100 MB | 5 GB | 50 GB |
| Version History | ❌ | 30 days | Unlimited |
| Auto-Save | Manual | ✅ | ✅ |
| Cross-Device Sync | ❌ | ✅ | ✅ |
| Share Links | ❌ | View-only | View + Edit |
| Team Spaces | ❌ | ❌ | ✅ |
| Auto Backup | ❌ | Weekly | Daily |
| Custom Domain | ❌ | ❌ | ✅ |

**Cloud Providers:** Your Own Cloud (default), Supabase Storage, Google Drive, Dropbox, OneDrive, AWS S3

---

## 6. Infrastructure Export Workflow (Engineer Flow)

```mermaid
flowchart TD
    USER[Engineer designs schema] --> EXPORT{Export What?}
    
    EXPORT -->|SQL DDL| SQL[📜 SQL DDL<br/>30+ Dialects]
    EXPORT -->|Migration| MIG[📦 Migration Files<br/>Flyway/Liquibase/Alembic]
    EXPORT -->|Infra| INFRA[🏗️ Infrastructure<br/>Docker/K8s/Terraform]
    EXPORT -->|API| API[🔌 API Code<br/>OpenAPI/CRUD/GraphQL]
    EXPORT -->|Mermaid| MERMAID[📜 Mermaid erDiagram<br/>Docs-as-Code]
    EXPORT -->|Visual| VISUAL[🎨 PNG/SVG/PDF]
    
    SQL --> GATE1{Plan Check}
    MIG --> GATE1
    INFRA --> GATE1
    API --> GATE1
    MERMAID --> GATE1
    VISUAL --> GATE1
    
    GATE1 -->|Allowed| DOWNLOAD[✅ Download]
    GATE1 -->|Locked| PAYWALL[🔒 Upgrade Prompt]
    
    DOWNLOAD --> CI_CD[🔄 Add to CI/CD Pipeline]
    
    style GATE1 fill:#f59e0b,color:#fff
    style INFRA fill:#8b5cf6,color:#fff
    style API fill:#10b981,color:#fff
```

---

## 7. Export Center Screen Layout

```mermaid
flowchart TD
    subgraph SCREEN["📦 Export Center Screen"]
        direction TB
        
        subgraph TOPBAR["Top Bar"]
            TITLE[Export Your Schema]
            PLANBADGE[📋 Plan: Team]
        end
        
        subgraph TABS["Category Tabs"]
            TAB1[🎨 Visual]
            TAB2[💻 Code]
            TAB3[📖 Docs]
            TAB4[📊 Data]
            TAB5[☁️ Cloud]
            TAB6[🏗️ Infrastructure]
        end
        
        subgraph CONTENT["Format Grid"]
            SQL[SQL DDL Card]
            MIG[Migration Card]
            DOCKER[Docker Compose Card]
            K8S[Kubernetes Card]
            TERRAFORM[Terraform Card]
            OPENAPI[OpenAPI Card]
            MERMAID[Mermaid Card]
        end
        
        subgraph OPTIONS["Options Panel"]
            DIALECT[Select Dialect: PostgreSQL ▼]
            MIG_FORMAT[Migration: Flyway ▼]
            INFRA_TARGET[Target: AWS RDS ▼]
        end
        
        subgraph ACTIONS["Bottom Actions"]
            PREVIEW[👁️ Preview]
            DOWNLOAD[📥 Download]
            CI_CD[🔄 Add to CI/CD]
        end
    end
    
    style SCREEN fill:#1e293b,color:#fff
    style TAB6 fill:#8b5cf6,color:#fff
```

---

## 8. 📋 Final Export Summary

```
📦 EXPORT CENTER
├── 🎨 Visual (5 formats)
│   ├── PNG ✅ Free (watermark)
│   ├── SVG, PDF, Poster ⭐ Pro
│   └── GIF/Video ⭐ Pro
├── 💻 Code (20+ formats)
│   ├── SQL DDL ✅ Free (limited)
│   ├── Migrations ⭐ Pro
│   ├── ORM Code ⭐ Pro
│   ├── Docker Compose ✅ Team
│   ├── K8s Manifests 💎 Enterprise
│   ├── Terraform 💎 Enterprise
│   └── OpenAPI/CRUD ✅ Team
├── 📖 Docs (7 formats)
│   ├── Markdown/HTML/PDF ⭐ Pro
│   ├── Excel/OpenAPI ✅ Team
│   └── Schema Docs ✅ Team
├── 📊 Data (5 formats)
│   ├── CSV/JSON ✅ Free (10 rows)
│   ├── SQL Inserts ⭐ Pro
│   └── Excel 💎 Team
├── ☁️ Cloud (7 features)
│   ├── 1 project ✅ Free
│   ├── Unlimited + sync ⭐ Pro
│   └── Team spaces ✅ Team
└── 🏗️ Infrastructure (6 formats)
    ├── Docker Compose ✅ Team
    ├── K8s Manifests 💎 Enterprise
    ├── Terraform 💎 Enterprise
    └── Helm/Ansible/CloudFormation 💎 Enterprise
```

---

## 💡 Pro Tips for Engineers

1. **Migration First**: Always export migration scripts, not just DDL. Production needs rollback.
2. **Version Your Schema**: Use V1__init.sql, V2__add_users.sql format for Flyway/Liquibase.
3. **Infra as Code**: Export Docker Compose/K8s so your DB is provisioned reproducibly.
4. **CI/CD Integration**: Add schema migration to your GitHub Actions / GitLab CI pipeline.
5. **Dry Run First**: Use deploy gates to review changes before production.

---

*Export features updated for professional engineering: Migration scripts, IaC (Docker/K8s/Terraform), API code generation, and CI/CD integration.*