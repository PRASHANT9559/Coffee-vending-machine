# 📱 Screens

> 30+ screens + panels/modals for the ChartDB Clone.
> Designed for Professional Engineers, DBAs, and Platform Teams.
> Includes Schema-as-Code, Multi-Environment, and Security screens.

---

## 📊 Screen Summary

| Category | Count | Screens |
|----------|-------|---------|
| Entry & Onboarding | 3 | Splash, Onboarding Carousel, Home Dashboard |
| Project Management | 4 | New Project, Template Gallery, Environments, Settings |
| Core Editor | 5 | Canvas Editor, Table Properties, Column Editor, Relationship Editor, Minimap |
| SQL & Preview | 3 | SQL Preview, Mermaid Preview, Schema Lint |
| Deploy & Multi-Env | 6 | DB Connect, Project Selector, Environments, Schema Diff, Deploy Gates, Deploy Progress |
| Schema-as-Code | 3 | Git Sync, Version History, Migration Files, Breaking Change Detection |
| Utilities | 3 | Export Center, Mock Data Generator, Documentation Viewer |
| Performance & Ops | 4 | Index Advisor, Query Plan, Slow Query, Cost Estimation |
| Security & Compliance | 4 | SSO Config, RBAC, Audit Logs, Compliance Reports |
| Profile & Monetization | 3 | Profile, Subscription Plans, Payment History |
| Live Data Simulation | 2 | Simulation Setup, Live Flow Animation |
| AI Assistant | 1 | AI Assistant Panel |
| **Total** | **30+** | |

---

## A. Entry & Onboarding (3 Screens)

### 1. Splash Screen
- App logo, loading animation, version number

### 2. Onboarding Carousel
- 3 slides: "Design Visually", "Generate SQL", "Deploy to Multi-Env"
- Skip / Next buttons

### 3. Home Dashboard
- Recent projects list
- "New Project" button
- Search bar
- Empty state illustration

---

## B. Project Management (4 Screens)

### 4. New Project Setup
- Project name, database type selector, color picker
- Initial environment (Dev/Staging/Prod) selection

### 5. Template Gallery
- Pre-built templates (E-commerce, Blog, SaaS, Custom)
- Preview thumbnails

### 6. Environments Screen
- Dev, Staging, Production environment cards
- Connection strings per environment
- Environment-specific settings

### 7. Settings Screen
- Theme (light/dark), account info
- Database connections (multiple)
- Default dialect, schema linting rules
- Data & privacy, about

---

## C. Core Editor (5 Screens/Panels) ⭐

### 8. Main Canvas Editor (Hero Screen)
- Infinite canvas, draggable table cards
- Relationship lines, top toolbar (add table, undo/redo, zoom)
- Minimap bottom-right

### 9. Table Properties Panel (Right Drawer)
- Table name, color, description
- Columns list, add/remove column buttons
- Indexes, constraints, comments

### 10. Column Editor Modal
- Column name, data type, primary key, nullable, default, unique
- PII flag, comment, validation rules

### 11. Relationship Editor Modal
- From table → To table, type (1:1, 1:N, N:M)
- Cardinality selector, foreign key preview
- ON DELETE/UPDATE cascade rules

### 12. Minimap Navigator
- Small overview of entire diagram
- Click to jump to area

---

## D. SQL & Preview (3 Screens)

### 13. SQL Preview Panel (Bottom Sheet)
- Generated DDL syntax highlighted
- Copy button, dialect selector, regenerate button
- Migration file format (V1__init.sql, etc.)

### 14. Mermaid Preview Panel
- Mermaid erDiagram code live preview
- Copy / export button

### 15. Schema Lint Panel
- Best practice checks: missing indexes, unused columns
- Naming convention violations
- Performance warnings
- Fix suggestions

---

## E. Deploy & Multi-Environment (6 Screens) ⭐⭐

### 16. Database Connect Screen
- OAuth login for multiple DB providers
- Supabase, AWS RDS, Azure SQL, GCP Cloud SQL, etc.
- SSO / SAML / OIDC configuration

### 17. Project Selector Screen
- List of database projects (name, region, status, provider)
- Environment filter (Dev / Staging / Prod)
- Search, refresh button

### 18. Environments Configuration Screen
- Dev / Staging / Production connection strings
- Pool sizes, timeout settings per env
- SSL/TLS configuration

### 19. Schema Diff Review Screen ⭐
- Side-by-side: Current DB vs Your Design
- Color-coded: Green=Add, Yellow=Modify, Red=Delete
- Breaking change warnings
- Checkbox per change

### 20. Deploy Gates Screen
- Manual approval required for production
- Approver assignment (team lead)
- Deploy window configuration

### 21. Deploy Progress & Success Screen
- Progress bar per table
- Logs console, success animation
- Rollback option
- "Open in Database Console" link

---

## F. Schema-as-Code (3 Screens/Panels)

### 22. Git Sync Screen
- Connect GitHub / GitLab / Bitbucket
- Push/pull schema as `.sql` or `.prisma` files
- Branch selection, auto-sync toggle

### 23. Version History Panel
- Timeline of schema changes
- Restore points, commit messages
- Diff viewer between versions

### 24. Migration Files Screen
- Versioned migration files (V1, V2, V3...)
- Flyway, Liquibase, Alembic format options
- Download migration SQL

### 25. Breaking Change Detection Panel
- Alert if change breaks production
- Dependency analysis
- Safe alternatives suggested

---

## G. Utilities (3 Screens)

### 26. Export Center
- Grid: SQL, Mermaid, PNG, SVG, PDF, JSON, Markdown
- Docker Compose, Kubernetes manifests, OpenAPI

### 27. Mock Data Generator
- Table selector, row count, data type mapping
- Preview table, generate & download

### 28. Documentation Viewer
- Auto-generated docs: table list, columns, relationships
- Searchable, export button

---

## H. Performance & Operations (4 Screens)

### 29. Index Advisor Screen
- Missing index suggestions based on query patterns
- Index impact estimation
- Apply index directly

### 30. Query Plan Visualization Screen
- EXPLAIN ANALYZE output rendered visually
- Bottleneck highlighting
- Optimization suggestions

### 31. Slow Query Detection Screen
- Queries exceeding threshold
- Execution frequency, average time
- Optimization recommendations

### 32. Cost Estimation Screen
- Monthly DB cost estimate (AWS RDS, Azure SQL, etc.)
- Before-deploy cost preview
- Cost optimization suggestions

---

## I. Security & Compliance (4 Screens)

### 33. SSO Config Screen
- SAML / OIDC provider configuration
- Okta, Azure AD, Google Workspace
- Domain whitelisting

### 34. RBAC Screen
- Roles: Owner, Editor, Viewer, Billing Admin
- Permission matrix
- User-role assignment

### 35. Audit Logs Screen
- Immutable append-only log
- Who changed what, when, from which IP
- Export audit trail

### 36. Compliance Reports Screen
- GDPR, SOC 2, HIPAA readiness reports
- PII column identification
- Download compliance PDF

---

## J. Profile & Monetization (3 Screens) 🆕

### 37. Profile Screen
- User avatar, name, email
- Plan badge (Free/Pro/Team/Enterprise)
- Usage stats, edit profile

### 38. Subscription Plans Screen
- 4 pricing cards (Free / Pro / Team / Enterprise)
- Feature comparison, upgrade button

### 39. Payment History Screen
- Transaction table: date, amount, invoice, payment method, next billing

---

## K. Live Data Simulation (2 Screens) — THE STAR ⭐⭐⭐

### 40. Simulation Setup
- Table selector, operation (INSERT/UPDATE/DELETE)
- Sample data input, Run Simulation button

### 41. Live Flow Animation ⭐
- Animated canvas: data packets, FK paths, triggers
- Error nodes flash RED, step timeline
- Speed control: 1x/2x/4x, Play/Pause/Step/Restart

---

## L. AI Assistant (1 Screen/Panel) 🆕

### 42. AI Assistant Panel
- Chat interface, schema suggestions
- Error explanations, optimization tips
- "Explain this flow", quick actions

---

## 🔄 Main App Workflow (Mermaid)

```mermaid
flowchart TD
    Start([🚀 App Launch]) --> Splash[1. Splash Screen]
    Splash --> FirstTime{First Time User?}
    
    FirstTime -->|Yes| Onboarding[2. Onboarding Carousel]
    FirstTime -->|No| Home
    
    Onboarding --> Home[3. Home Dashboard]
    
    Home --> NewProject[4. New Project Setup]
    NewProject --> EnvConfig[6. Environments]
    EnvConfig --> Editor[8. Canvas Editor ⭐]
    
    Editor --> TablePanel[9. Table Properties]
    Editor --> ColumnModal[10. Column Editor]
    Editor --> RelationModal[11. Relationship Editor]
    
    Editor --> SqlPreview[13. SQL Preview]
    Editor --> MermaidPreview[14. Mermaid Preview]
    Editor --> LintPanel[15. Schema Lint]
    Editor --> GitSync[22. Git Sync]
    Editor --> DeployFlow[16-21. Deploy Flow]
    
    DeployFlow --> DBConnect[16. DB Connect]
    DBConnect --> ProjectSelect[17. Project Selector]
    ProjectSelect --> EnvConfig[18. Environments]
    EnvConfig --> SchemaDiff[19. Schema Diff Review ⭐]
    SchemaDiff --> DeployGates[20. Deploy Gates]
    DeployGates --> DeployProgress[21. Deploy Progress]
    
    SchemaDiff --> VersionHistory[23. Version History]
    SchemaDiff --> MigrationFiles[24. Migration Files]
    SchemaDiff --> BreakingChange[25. Breaking Change]
    
    Editor --> ExportCenter[26. Export Center]
    Editor --> MockData[27. Mock Data]
    Editor --> DocsViewer[28. Documentation]
    Editor --> IndexAdvisor[29. Index Advisor]
    Editor --> QueryPlan[30. Query Plan]
    Editor --> SlowQuery[31. Slow Query]
    Editor --> CostEst[32. Cost Estimation]
    
    Editor --> SSO[33. SSO Config]
    Editor --> RBAC[34. RBAC]
    Editor --> AuditLogs[35. Audit Logs]
    Editor --> Compliance[36. Compliance Reports]
    
    Editor --> Profile[37. Profile]
    Editor --> Plans[38. Subscription Plans]
    Editor --> Payments[39. Payment History]
    
    Editor --> SimSetup[40. Simulation Setup]
    SimSetup --> LiveAnim[41. Live Flow Animation ⭐]
    
    Editor --> AI[42. AI Assistant Panel]
    
    style Editor fill:#4f46e5,stroke:#3730a3,stroke-width:3px,color:#fff
    style SchemaDiff fill:#10b981,stroke:#059669,stroke-width:3px,color:#fff
    style DeployGates fill:#f59e0b,stroke:#d97706,stroke-width:3px
    style GitSync fill:#8b5cf6,stroke:#7c3aed,color:#fff
    style LiveAnim fill:#ef4444,color:#fff
```

---

## 🧭 Navigation Structure (Mermaid)

```mermaid
flowchart LR
    subgraph Root["🏠 Root"]
        Home[Home Dashboard]
        Settings[Settings]
    end
    
    subgraph ProjectScope["📁 Project Scope"]
        Editor[Canvas Editor]
        GitSync[Git Sync]
        VersionHistory[Version History]
        Export[Export Center]
    end
    
    subgraph DeployScope["🚀 Deploy Scope"]
        DBConnect[DB Connect]
        Environments[Environments]
        SchemaDiff[Schema Diff]
        DeployGates[Deploy Gates]
        DeployProgress[Deploy Progress]
    end
    
    subgraph OpsScope["⚙️ Operations Scope"]
        IndexAdvisor[Index Advisor]
        QueryPlan[Query Plan]
        SlowQuery[Slow Query]
        CostEst[Cost Estimation]
    end
    
    subgraph SecurityScope["🔒 Security Scope"]
        SSO[SSO Config]
        RBAC[RBAC]
        AuditLogs[Audit Logs]
        Compliance[Compliance Reports]
    end
    
    Home --> ProjectScope
    Home --> DeployScope
    Home --> OpsScope
    Home --> SecurityScope
    
    Editor --> DeployScope
    Editor --> OpsScope
    Editor --> SecurityScope
    
    style Editor fill:#4f46e5,color:#fff
    style DeployScope fill:#f59e0b
    style SecurityScope fill:#8b5cf6,color:#fff
```

---

## 📊 Screen Priority Matrix (Development Order)

| Phase | Screens | Why First? |
|-------|---------|------------|
| Phase 1 (MVP) | 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 | Core editing + Schema-as-Code |
| Phase 2 (Deploy) | 16, 17, 18, 19, 20, 21 | Multi-env + deploy safety |
| Phase 3 (Performance) | 29, 30, 31, 32 | Index advisor, query plans |
| Phase 4 (Security) | 33, 34, 35, 36 | SSO, RBAC, audit, compliance |
| Phase 5 (Team) | 22, 23, 24, 25, 37, 38, 39 | Git sync, subscription |
| Phase 6 (AI + Polish) | 2, 40, 41, 42 | Onboarding, animation, AI |

---

## 💡 Pro Tips for Engineers

- **Screen 8 (Canvas Editor)** is for quick design, but **Screen 22 (Git Sync)** is for production workflow
- **Screen 19 (Schema Diff)** prevents accidental production breaks
- **Screen 20 (Deploy Gates)** is mandatory for team production deploys
- **Screen 29 (Index Advisor)** helps DBAs optimize before deploy
- **Screen 35 (Audit Logs)** is required for SOC 2 compliance
- Empty states on every screen — guide engineers when no schema exists

---

## 🎯 At a Glance

```
30+ Screens Total
├── 3 Onboarding/Home
├── 4 Project Management (incl. Environments)
├── 5 Core Editor ⭐ (Visual)
├── 3 SQL & Preview (incl. Schema Lint)
├── 6 Deploy & Multi-Env ⭐⭐ (Safety)
├── 4 Schema-as-Code (Git, Versions, Migrations)
├── 3 Utilities (Export, Mock, Docs)
├── 4 Performance & Ops (Index, Query, Cost)
├── 4 Security & Compliance (SSO, RBAC, Audit)
├── 3 Profile & Monetization
├── 2 Live Data Simulation ⭐⭐⭐ (STAR)
└── 1 AI Assistant
```

---

*Screens documented for professional engineering workflow: Schema-as-Code, Multi-Environment, Deploy Gates, Performance, Security, and CI/CD.*