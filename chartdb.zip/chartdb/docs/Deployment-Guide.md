# 🚀 Deployment Guide

> Build, CI/CD, and distribution guide for the ChartDB Clone.
> Cross-platform: Windows, Linux, macOS, Android, iOS.
> Built for Professional Engineers: Schema-as-Code, CI/CD, Multi-Environment, Security.

---

## 📋 Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| Flutter | 3.x | Frontend framework |
| Rust | 1.75+ | Core engine |
| Dart | 3.x | Flutter language |
| Xcode | Latest | iOS/macOS builds |
| Android Studio | Latest | Android builds |
| MSVC Build Tools | Latest | Windows builds |
| Node.js | 18+ | Some build scripts |
| Docker | Latest | Container builds |
| Kubernetes CLI | Latest | K8s deployment |
| Terraform | Latest | IaC (optional) |
| Git | Latest | Version control |

---

## 🔧 Initial Setup

```bash
# Clone repository
git clone <repo-url>
cd chartdb-engine

# Install Flutter dependencies
flutter pub get

# Install flutter_rust_bridge codegen
cargo install flutter_rust_bridge_codegen

# Generate FFI bindings
flutter_rust_bridge_codegen generate

# Add Flutter dependency
flutter pub add flutter_rust_bridge
```

---

## 📱 Platform-Specific Build Setup

### Android

```bash
# Install cargo-ndk
cargo install cargo-ndk

# Install Android NDK (via Android Studio)

# Build Android .so
cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 build --release

# Build APK
flutter build apk --release
```

### iOS

```bash
# Install cargo-lipo
cargo install cargo-lipo

# Build iOS static library
cargo lipo --release

# Build iOS app (requires Xcode + Apple Developer account)
flutter build ipa --release
```

### macOS

```bash
# Add Rust targets
rustup target add aarch64-apple-darwin x86_64-apple-darwin

# Build universal binary
cargo build --release --target aarch64-apple-darwin
cargo build --release --target x86_64-apple-darwin
lipo -create libx86.dylib libarm.dylib -output libuniversal.dylib

# Build macOS app
flutter build macos --release
```

### Windows

```bash
# Install MSVC Build Tools (C++ workload)

# Add Rust target
rustup target add x86_64-pc-windows-msvc

# Build Windows .dll
cargo build --release --target x86_64-pc-windows-msvc

# Build Windows app
flutter build windows --release
```

### Linux

```bash
# Add Rust target
rustup target add x86_64-unknown-linux-gnu

# Install dependencies
sudo apt-get install clang cmake ninja-build gtk3-dev libwebkit2gtk-4.0-dev

# Build Linux .so
cargo build --release --target x86_64-unknown-linux-gnu

# Build Linux app
flutter build linux --release
```

---

## 🔨 Build Automation Scripts

### build_all.sh

```bash
#!/bin/bash
# build_all.sh

echo "🤖 Building Android..."
cargo ndk -t arm64-v8a -t armeabi-v7a build --release

echo "🍎 Building iOS..."
cargo lipo --release

echo "🍏 Building macOS..."
cargo build --release --target aarch64-apple-darwin
cargo build --release --target x86_64-apple-darwin

echo "🪟 Building Windows..."
cargo build --release --target x86_64-pc-windows-msvc

echo "🐧 Building Linux..."
cargo build --release --target x86_64-unknown-linux-gnu

echo "🔗 Generating FFI bindings..."
flutter_rust_bridge_codegen generate
```

### release.sh

```bash
#!/bin/bash
# release.sh

VERSION=$1

if [ -z "$VERSION" ]; then
  echo "Usage: ./release.sh <version>"
  exit 1
fi

# Tag release
git tag v$VERSION
git push origin v$VERSION

# CI/CD will handle the rest via GitHub Actions
```

---

## ⚙️ Release Profile Optimization

### Cargo.toml

```toml
[profile.release]
lto = true
strip = true
opt-level = "z"
codegen-units = 1
```

### Expected App Sizes

| Platform | Base Flutter | + Rust Lib | Total (approx) |
|----------|-------------|------------|----------------|
| Android APK | ~15 MB | +3-5 MB | ~20 MB |
| iOS IPA | ~20 MB | +3-5 MB | ~25 MB |
| macOS | ~30 MB | +4-6 MB | ~36 MB |
| Windows | ~25 MB | +4-6 MB | ~31 MB |
| Linux | ~25 MB | +4-6 MB | ~31 MB |

---

## 🔄 CI/CD Pipeline (GitHub Actions)

### .github/workflows/ci.yml

```yaml
name: CI
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.x'
      - uses: dtolnay/rust-toolchain@stable
      - run: flutter pub get
      - run: flutter_rust_bridge_codegen generate
      - run: cargo test
      - run: cargo clippy -- -D warnings
      - run: cargo fmt --check
      - run: flutter analyze
```

### .github/workflows/schema-migration.yml (NEW)

```yaml
name: Schema Migration
on:
  push:
    branches: [main]
    paths: ['schemas/**']

jobs:
  migrate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo test -p diff -p sqlgen -p lint
      - run: cargo run --bin schema-deploy -- --env staging --dry-run
      - run: cargo run --bin schema-deploy -- --env staging --apply
      - if: github.ref == 'refs/heads/main'
        run: cargo run --bin schema-deploy -- --env production --dry-run
```

### .github/workflows/build-android.yml

```yaml
name: Build Android
on:
  push:
    tags: ['v*']

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo install cargo-ndk
      - run: cargo ndk -t arm64-v8a -t armeabi-v7a build --release
      - run: flutter build apk --release
      - uses: actions/upload-artifact@v4
        with:
          name: android-apk
          path: build/app/outputs/flutter-apk/app-release.apk
```

### .github/workflows/build-ios.yml

```yaml
name: Build iOS
on:
  push:
    tags: ['v*']

jobs:
  build:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo install cargo-lipo
      - run: cargo lipo --release
      - run: flutter build ipa --release
      - uses: actions/upload-artifact@v4
        with:
          name: ios-ipa
          path: build/ios/ipa/*.ipa
```

### .github/workflows/build-desktop.yml

```yaml
name: Build Desktop
on:
  push:
    tags: ['v*']

jobs:
  build:
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
      - uses: dtolnay/rust-toolchain@stable
      - run: flutter_rust_bridge_codegen build
      - run: flutter build ${{ matrix.os }} --release
      - uses: actions/upload-artifact@v4
        with:
          name: desktop-${{ matrix.os }}
          path: build/
```

### .github/workflows/release.yml

```yaml
name: Release
on:
  push:
    tags: ['v*']

jobs:
  release:
    runs-on: ubuntu-latest
    needs: [build-android, build-ios, build-desktop]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/download-artifact@v4
      - uses: softprops/action-gh-release@v1
        with:
          files: |
            **/*.apk
            **/*.ipa
            **/*.dmg
            **/*.exe
            **/*.deb
          generate_release_notes: true
```

---

## ☁️ Supabase Setup

### 1. Create Supabase Project

1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Note down: Project URL, Anon Key, Service Role Key

### 2. Configure OAuth Redirect URLs

Add all platform redirect URLs in Supabase Dashboard:

| Platform | Redirect URL |
|----------|-------------|
| Android | `com.yourapp.schema://login-callback` |
| iOS | `com.yourapp.schema://login-callback` |
| macOS | `http://localhost:PORT/callback` |
| Windows | `http://localhost:PORT/callback` |
| Linux | `http://localhost:PORT/callback` |

**Path:** Supabase Dashboard → Authentication → URL Configuration → Redirect URLs

### 3. Enable Management API

For DDL execution (CREATE TABLE, ALTER TABLE), use Supabase Management API:

```
POST https://api.supabase.com/v1/projects/{ref}/database/query
```

Requires user's Access Token (OAuth).

---

## 🏗️ Infrastructure Deployment (NEW)

### Docker Compose (Team Tier)

```yaml
# docker-compose.yml (generated by app)
version: '3.8'
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: ${DB_NAME}
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    networks:
      - app-network
  app:
    build: .
    environment:
      DATABASE_URL: postgresql://${DB_USER}:${DB_PASSWORD}@db:5432/${DB_NAME}
    ports:
      - "3000:3000"
    depends_on:
      - db
    networks:
      - app-network

networks:
  app-network:
    driver: bridge

volumes:
  pgdata:
```

### Kubernetes Manifests (Enterprise Tier)

```yaml
# k8s-deployment.yaml (generated by app)
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
spec:
  serviceName: postgres
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15
        env:
        - name: POSTGRES_USER
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: username
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: password
        ports:
        - containerPort: 5432
        volumeMounts:
        - name: pg-storage
          mountPath: /var/lib/postgresql/data
  volumeClaimTemplates:
  - metadata:
      name: pg-storage
    spec:
      accessModes: ["ReadWriteOnce"]
      storageClassName: standard
      resources:
        requests:
          storage: 100Gi
---
apiVersion: v1
kind: Service
metadata:
  name: postgres
spec:
  selector:
    app: postgres
  ports:
    - protocol: TCP
      port: 5432
      targetPort: 5432
  type: ClusterIP
```

### Terraform (Enterprise Tier)

```hcl
# main.tf (generated by app)
resource "aws_db_instance" "default" {
  identifier       = "my-database"
  engine           = "postgres"
  instance_class   = "db.t3.medium"
  allocated_storage = 100
  username         = var.db_username
  password         = var.db_password
  skip_final_snapshot = true
}

resource "aws_db_parameter_group" "default" {
  name        = "my-db-params"
  family      = "postgres15"
  parameter {
    name  = "max_connections"
    value = "100"
  }
}
```

---

## 🔐 Security Checklist

| Item | Status |
|------|--------|
| Never hardcode Supabase Service Role Key in Flutter | ✅ |
| Use User Access Token / OAuth | ✅ |
| Store tokens in flutter_secure_storage | ✅ |
| Validate all input in Rust before generating SQL | ✅ |
| SECURITY DEFINER functions need RLS policies | ✅ |
| API keys for cloud AI stored securely | ✅ |
| Code signing for Windows/macOS distribution | ⚠️ Eventually |
| SSO / SAML / OIDC configuration | Enterprise |
| RBAC role assignment | Enterprise |
| Audit logs enabled | Enterprise |
| PII data masking | Enterprise |
| Secret management (Vault/AWS Secrets Manager) | Enterprise |

---

## 📦 Distribution Options

| Platform | Format | Store |
|----------|--------|-------|
| Android | APK / AAB | Google Play Store |
| iOS | IPA | Apple App Store |
| macOS | DMG / .app | Direct download / App Store |
| Windows | .exe / MSIX | Direct download / Microsoft Store |
| Linux | AppImage / Snap / Flatpak / .deb | Direct download |

### Recommended: AppImage for Linux

```bash
# AppImage is the most universal Linux format
# Bundle all dependencies including Rust .so
```

---

## 🧪 Testing Strategy

| Level | Tool | What to Test |
|-------|------|--------------|
| Unit tests | `cargo test` | Individual functions per crate |
| Widget tests | `flutter test` | UI components, drag-drop |
| Integration | `integration_test` | Full flow: design → SQL → Supabase |
| Platform-specific | Manual | OAuth flow, file permissions per OS |
| Schema migration | `cargo test -p diff -p sqlgen` | Migration correctness |
| Dry run deploy | `schema-deploy --dry-run` | Pre-deploy validation |

---

## ⚠️ Common Pitfalls

| Issue | Solution |
|-------|----------|
| iOS Simulator vs Device different Rust targets | Use `aarch64-apple-ios-sim` for simulator, `aarch64-apple-ios` for device |
| Windows antivirus blocks unsigned .dll | Get code signing certificate eventually |
| Linux dependencies missing | Install clang, cmake, ninja-build, gtk3-dev, libwebkit2gtk |
| Hot reload limitations for Rust | Rust changes require cargo rebuild; Dart hot reload works |
| iOS background restrictions | Supabase upload in foreground; warn user if app backgrounds |
| Production deploy without gate | Use deploy gates + dry run + rollback |
| Breaking change in schema | Use linting + breaking change detection before deploy |

---

## 🎯 Suggested Development Order

1. **Desktop first** (macOS/Linux) — fastest iteration, hot reload
2. **Schema-as-Code** — engineer's primary workflow
3. **Multi-Environment** — Dev/Staging/Prod safety
4. **Android** — mobile testing
5. **iOS** — Apple Developer account
6. **Windows + Linux** — final polish
7. **CI/CD + automated releases** — GitHub Actions

---

## 📊 Build Matrix

| Job | OS | Targets | Artifacts |
|-----|-----|---------|-----------|
| ci | ubuntu-latest | test, clippy, fmt | — |
| schema-migration | ubuntu-latest | dry run, apply to staging | — |
| build-android | ubuntu-latest | aarch64, armv7, x86_64 | .apk |
| build-ios | macos-latest | aarch64, aarch64-sim | .ipa |
| build-desktop-macos | macos-latest | aarch64, x86_64 | .dmg |
| build-desktop-windows | windows-latest | x86_64-msvc | .exe |
| build-desktop-linux | ubuntu-latest | x86_64-gnu | AppImage |

---

## 🔐 Production Deployment Checklist

- [ ] All 5 platform builds pass CI
- [ ] Schema migration tested on staging
- [ ] Deploy gates configured for production
- [ ] Rollback procedure documented
- [ ] SSO / RBAC configured (Enterprise)
- [ ] Audit logs enabled (Enterprise)
- [ ] Code signing certificates obtained
- [ ] App store listings created
- [ ] CI/CD pipeline with dry run + apply
- [ ] Monitoring and alerting configured

---

*Deployment guide designed for professional engineers: Schema-as-Code, CI/CD, Multi-Environment, Deploy Gates, Rollback, Infrastructure as Code (Docker/K8s/Terraform), and Security.*