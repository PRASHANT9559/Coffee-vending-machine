# 🛠️ Tech Stack

> Technology stack for the ChartDB Clone — Built for Professional Engineers.
> Flutter + Rust + Supabase + dbx (100+ databases) + Schema-as-Code.

---

## 1. Overview

| Layer | Technology | Purpose | Engineer Relevance |
|-------|-----------|---------|-------------------|
| Frontend | Flutter (Dart) | Cross-platform UI (5 platforms) | Desktop-first, hot reload |
| Core Engine | Rust | On-device business logic, SQL generation, dataflow | Memory safety, performance |
| Bridge | flutter_rust_bridge | FFI between Flutter and Rust | Type-safe FFI |
| Database Engine | dbx | 100+ database drivers & introspection | Multi-DB support |
| Target Databases | Supabase, PostgreSQL, MySQL, MongoDB, Cassandra, Snowflake, BigQuery, Oracle, SQL Server, etc. | Deployment targets | Production databases |
| Auth | Supabase Auth (OAuth) + SSO/SAML/OIDC | User authentication | Enterprise SSO |
| Cloud Storage | Supabase Storage / Own Cloud | Schema JSON, versions, thumbnails | Versioned storage |
| AI | OpenAI / Claude / Custom API | Cloud AI assistant (NOT on-device) | Schema suggestions |
| Payments | Stripe / Razorpay / Google Play / App Store | Subscription payments | Team billing |
| Local Storage | Hive / SQLite / flutter_secure_storage | Offline designs, token storage | Secure local cache |
| State Management | Riverpod or Bloc | App state | Predictable state |
| CI/CD | GitHub Actions | Build, test, release | Automated pipelines |
| Schema-as-Code | GitHub, GitLab, Bitbucket | Version-controlled schema files | Git workflow |

---

## 2. Flutter (Frontend)

### Packages

| Package | Use Case | Engineer Note |
|---------|----------|---------------|
| `flutter_rust_bridge` | FFI bridge to Rust | Battle-tested, type-safe |
| `supabase_flutter` | Supabase authentication and client | OAuth + SSO ready |
| `flutter_secure_storage` | Token storage (iOS Keychain / Android Keystore) | Secure secret storage |
| `riverpod` or `bloc` | State management | Immutable state, testable |
| `hive` or `sqflite` | Local offline storage | Encrypted local DB |
| `app_links` | Deep links for mobile OAuth callbacks | Secure OAuth flow |
| `shelf` or `shelf_io` | Local server for desktop OAuth callbacks | Desktop OAuth |
| `custom_painter` / `rive` | Data flow animation | Performant rendering |
| `graph_view` / `flutter_diagram_editor` | Canvas diagram editor | Node-based UI |
| `url_launcher` | Open database links | External DB console |
| `share_plus` | Share export files | Team collaboration |
| `git` integration | Push/pull schema to GitHub/GitLab | Schema-as-Code |

### Project Structure (Flutter)

```
lib/
├── main.dart
├── ui/
│   ├── splash/
│   ├── onboarding/
│   ├── home/
│   ├── editor/                  # Canvas editor, panels, modals
│   ├── preview/                 # SQL preview, Mermaid preview
│   ├── export/                  # Export center
│   ├── deploy/                  # Multi-env connect, diff, gates, rollback
│   ├── simulation/              # Simulation setup, live animation
│   ├── ai/                      # AI assistant panel
│   ├── profile/                 # Profile, subscription, payment history
│   ├── settings/                # SSO, RBAC, audit logs
│   └── git/                     # Schema-as-Code, version history
├── services/
│   ├── supabase_service.dart
│   ├── auth_service.dart        # OAuth + SSO
│   ├── payment_service.dart
│   ├── cloud_sync_service.dart
│   ├── subscription_service.dart
│   ├── git_service.dart         # Schema-as-Code git sync
│   └── audit_service.dart       # Audit logs
├── generated/                   # Auto-generated FFI bindings
├── models/                      # Dart data models
├── providers/                   # Riverpod / Bloc state management
└── utils/                       # Helpers, constants, extensions
```

---

## 3. Rust (Core Engine - On-Device)

### Workspace Crates

| Crate | Key Dependencies | Purpose | Engineer Relevance |
|-------|-----------------|---------|-------------------|
| `core` | `serde`, `serde_json`, `thiserror` | Domain models | Shared schema model |
| `dialects` | `serde` | 30+ dialect definitions + type maps | Multi-DB SQL generation |
| `dbx-adapter` | `tokio`, `sqlx`, `mongodb` | 100+ database drivers | Production database support |
| `sqlgen` | `sqlparser` | SQL DDL generation | Dialect-specific DDL |
| `converter` | `serde_json`, `csv`, `serde_yaml` | Format/Dialect/NoSQL converters | Data migration |
| `dataflow` | `petgraph` | Dependency graph + BFS + error prediction | Live simulation |
| `diff` | — | Schema diff + migration + rollback | Safe deployments |
| `mockdata` | — | Mock data generator | Testing data |
| `mermaid` | — | Mermaid erDiagram generation | Docs-as-code |
| `docsgen` | — | Markdown/HTML/PDF documentation | Technical docs |
| `ai-client` | `reqwest` | Cloud AI HTTP client | Schema suggestions |
| `cloud` | `reqwest` | Supabase sync client | Versioned storage |
| `subscription` | — | Plan gating & entitlements | Feature flags |
| `lint` | — | Schema linting rules | Best practices |
| `ci-cd` | — | CI/CD pipeline integration | Automated migrations |
| `ffi` | `flutter_rust_bridge` | Flutter bridge (public API) | Type-safe bridge |

### Cargo.toml (Root Workspace)

```toml
[workspace]
members = ["crates/*"]

[workspace.dependencies]
serde = { version = "1", features = ["derive"] }
serde_json = "1"
thiserror = "1"
sqlparser = "0.40"
reqwest = { version = "0.11", features = ["json"] }
flutter_rust_bridge = "2"
tokio = { version = "1", features = ["full"] }
sqlx = { version = "0.7", features = ["runtime-tokio-rustls", "postgres", "mysql", "sqlite"] }

[profile.release]
lto = true
strip = true
opt-level = "z"
codegen-units = 1
```

### Platform Targets

| Platform | Rust Target | Output | Tool |
|----------|-------------|--------|------|
| Android | aarch64-linux-android, armv7-linux-androideabi, x86_64-linux-android | .so | cargo-ndk |
| iOS | aarch64-apple-ios, aarch64-apple-ios-sim | .a (static) | cargo-lipo + Xcode |
| macOS | aarch64-apple-darwin, x86_64-apple-darwin | .dylib | Xcode CLI |
| Windows | x86_64-pc-windows-msvc | .dll | MSVC Build Tools |
| Linux | x86_64-unknown-linux-gnu | .so | gcc/clang |

---

## 4. dbx Integration (100+ Databases)

dbx provides the multi-database backbone:

| Database Category | Databases | Tier |
|-------------------|-----------|------|
| Relational | PostgreSQL, MySQL, MariaDB, SQL Server, Oracle, DB2, SAP HANA | Pro/Team |
| Cloud Data Warehouse | Snowflake, BigQuery, Redshift, Databricks, Firebolt | Team |
| NewSQL | CockroachDB, YugabyteDB, TiDB, Google Spanner | Team |
| Serverless | Supabase, Neon, PlanetScale, AWS Aurora, Cloudflare D1, DuckDB | Pro |
| NoSQL Document | MongoDB, Firestore, CouchDB | Team |
| NoSQL Key-Value | Redis, DynamoDB, Memcached | Team |
| NoSQL Wide-Column | Cassandra, HBase, ScyllaDB | Enterprise |
| NoSQL Graph | Neo4j, Neptune, ArangoDB | Enterprise |
| NoSQL Search | Elasticsearch, Solr, Meilisearch | Team |
| NoSQL Time-Series | InfluxDB, QuestDB, Prometheus | Enterprise |
| Embedded | SQLite, Apache Derby, H2, HSQLDB | Free |

---

## 5. Supabase (Backend)

### Services Used

| Service | Purpose |
|---------|---------|
| Supabase Auth | OAuth login (Google, GitHub, email) + SSO |
| Supabase Database | Target PostgreSQL for schema deployment |
| Supabase Management API | Execute DDL (CREATE TABLE, ALTER TABLE) |
| Supabase Storage | Store schema JSON, versions, thumbnails |
| Supabase Realtime | Cross-device sync (optional) |

### Key Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `POST https://api.supabase.com/v1/projects/{ref}/database/query` | POST | Execute DDL SQL |
| `GET https://api.supabase.com/v1/projects` | GET | List user's projects |

### Authentication Flow

1. User clicks "Connect Database"
2. Flutter opens OAuth URL (browser or web view)
3. Provider redirects with access token
4. Token stored in `flutter_secure_storage`
5. Rust/Flutter uses token for Management API calls

---

## 6. AI (Cloud-Only)

> ⚠️ **No AI model runs on-device.** Only an HTTP client in Rust.

| Component | Technology | Purpose |
|-----------|-----------|---------|
| AI Client | `reqwest` (Rust HTTP) | Call cloud AI API |
| Providers | OpenAI, Claude, Custom | Different AI models |
| Prompts | Template-based | Schema review, error explain, optimize |
| Request/Response | JSON types | Structured AI communication |

### AI Capabilities (Engineer Focused)
- Schema suggestions ("Add composite index on (user_id, created_at)")
- Error explanation ("FK violation on orders.user_id → users.id")
- Optimization tips ("Consider partitioning by month for >10M rows")
- "Explain this flow" — natural language data flow description
- Breaking change detection ("Dropping column 'email' will affect 3 services")

---

## 7. Security & Compliance

| Feature | Technology | Tier |
|---------|-----------|------|
| SSO / SAML / OIDC | Okta, Azure AD, Google Workspace | Enterprise |
| RBAC | Role-Based Access Control | Enterprise |
| Audit Logs | Immutable append-only log | Enterprise |
| PII Data Masking | Column-level masking | Enterprise |
| Secret Management | HashiCorp Vault, AWS Secrets Manager | Enterprise |
| Compliance Reports | GDPR, SOC 2, HIPAA | Enterprise |
| Code Signing | Windows/macOS distribution | All |
| Token Storage | flutter_secure_storage | All |

---

## 8. CI/CD Pipeline (GitHub Actions)

| Workflow | Trigger | Purpose |
|----------|---------|---------|
| `ci.yml` | Push/PR | clippy + fmt + cargo test + flutter analyze |
| `schema-migration.yml` | Push to main | Run schema migrations on deploy |
| `build-android.yml` | Push/Tag | Android .so builds |
| `build-ios.yml` | Push/Tag | iOS static lib builds |
| `build-desktop.yml` | Push/Tag | Windows/macOS/Linux builds |
| `release.yml` | Tag | Tagged releases, all platforms |

### Example: Schema Migration in CI

```yaml
name: Schema Migration
on:
  push:
    branches: [main]
    paths: ['schemas/**']
jobs:
  migrate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo test -p diff -p sqlgen
      - run: cargo run --bin schema-deploy -- --env production --dry-run
```

---

## 9. Feature Flags (Binary Size Control)

| Feature Flag | What it enables | Tier |
|--------------|-----------------|------|
| `dialect-postgres` | PostgreSQL support | Free |
| `dialect-oracle` | Oracle support (premium) | Team |
| `dialect-snowflake` | Snowflake support (premium) | Team |
| `converter-parquet` | Parquet conversion | Team |
| `converter-nosql` | NoSQL converters | Team/Enterprise |
| `dataflow` | Data flow engine | Pro |
| `ai-client` | AI integration | Team |
| `cloud-sync` | Cloud sync | Pro |
| `schema-lint` | Schema linting rules | Team |
| `deploy-gates` | Production deploy approval | Enterprise |
| `audit-logs` | Immutable audit trail | Enterprise |
| `sso` | SSO/SAML/OIDC | Enterprise |

---

## 10. Development Order

| Phase | Platform | Reason |
|-------|----------|--------|
| Phase 1-2 | Desktop (macOS/Linux) | Fast iteration, hot reload, Schema-as-Code |
| Phase 3 | Android | Mobile testing |
| Phase 4 | iOS | Apple account setup |
| Phase 5-6 | Windows + Linux | Final polish |

---

*Tech stack designed for professional engineers: Schema-as-Code, Multi-Database, CI/CD, Security, and Performance.*