# ☕ Manhattan Coffee — Rust Backend Engine

High-performance, memory-safe backend microservice written in **Rust** using **Axum**, **Tokio**, and **SQLx** for the Manhattan Coffee automated vending network.

---

## 🇮🇳 हिंदी में विवरण (Hindi Guide)

हाँ भाई! बैकएंड का पूरा कोड **Rust Programming Language** में लिख दिया गया है और यह `/backend` डायरेक्टरी में व्यवस्थित है:

### मुख्य विशेषताएँ (Key Highlights):
1. **Axum 0.7 Web Framework**: आधुनिक और बहुत तेज़ HTTP राउटर और माइक्रोसेवा।
2. **Tokio Async Runtime**: हज़ारों वेंडिंग मशीनों की टेलीमेट्री एक साथ बिना हैंग हुए प्रोसेस करने के लिए।
3. **SQLx PostgreSQL Connection Pool**: बिना किसी ORM स्लोडाउन के सीधा PostgreSQL 16 डेटाबेस से कनेक्शन।
4. **JWT Security & 6-Role RBAC**: HMAC-SHA256 क्रिप्टोग्राफ़िक टोकन और 6-रोल परमिशन चेक (`viewer`, `support`, `ops`, `marketing`, `finance`, `owner`)।
5. **Hardware Command Dispatch**: वेंडिंग मशीन रीबूट, टेस्ट डिस्पेंस, लॉक/अनलॉक के लिए आरबीएसी-सुरक्षित एंडपॉइंट्स।
6. **Live Telemetry & Dispute Desk**: 5-मिनट एसएलए टाइमर, फ्लो-रेट वेरियंस ट्रैकिंग, और रिफंड ऑटोमेशन।

---

## 📁 प्रोजेक्ट स्ट्रक्चर (Directory Tree)

```
backend/
├── Cargo.toml               # Rust dependencies (Axum, Tokio, SQLx, Serde, JWT)
├── Dockerfile               # Production multi-stage Docker build
├── README.md                # Documentation & API routes
└── src/
    ├── main.rs              # Application entry, Axum Router setup, CORS & Tracing
    ├── config.rs            # Environment variables (PORT, DATABASE_URL, JWT_SECRET)
    ├── error.rs             # Custom AppError with automatic JSON HTTP status mapping
    ├── db/
    │   ├── mod.rs
    │   └── pool.rs          # SQLx PostgreSQL pool connection manager
    ├── middleware/
    │   ├── mod.rs
    │   └── auth.rs          # JWT validation & role context extraction
    ├── models/
    │   ├── mod.rs
    │   ├── user.rs          # User roles, Claims, Login & OTP payloads
    │   ├── machine.rs       # Vending machine telemetry & hardware command models
    │   ├── order.rs         # Order items & refund request models
    │   ├── support.rs       # Dispute tickets, variance & SLA models
    │   └── inventory.rs     # FSSAI cold-chain milk tanks & stock items
    └── handlers/
        ├── mod.rs
        ├── health.rs        # Health check (/health)
        ├── auth.rs          # Login, OTP verification & token generation
        ├── machines.rs      # Telemetry updates & hardware commands
        ├── orders.rs        # Orders listing & refunds
        ├── support.rs       # Dispute queue & verdicts
        └── live.rs          # Fast telemetry polling for live operations
```

---

## 🚀 लोकल मशीन या VPS पर चलाने का तरीका (How to Run)

### 1. Prerequisites
- Rust 1.77+ installed (`curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`)
- PostgreSQL 16 running

### 2. Environment Variables (`.env`)
Create `backend/.env`:
```env
PORT=8080
DATABASE_URL=postgresql://manhattan_user:manhattan_secure_pass@localhost:5432/manhattan_coffee
JWT_SECRET=manhattan_coffee_vps_master_jwt_secret_2026_prod_rust_key
UPLOAD_DIR=/var/www/manhattan/uploads
RUST_LOG=info,manhattan_coffee_backend=debug
```

### 3. Build & Run
```bash
cd backend

# Debug Run
cargo run

# Optimized Production Release Build
cargo build --release
./target/release/manhattan-coffee-backend
```

### 4. Docker से चलाने के लिए
```bash
cd backend
docker build -t manhattan-rust-backend .
docker run -p 8080:8080 --env-file .env manhattan-rust-backend
```

---

## 📡 मुख्य API एंडपॉइंट्स (API Routes Reference)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/health` | Server & DB health check | No |
| `POST` | `/api/auth/login` | Request single-use 6-digit OTP | No |
| `POST` | `/api/auth/otp/verify` | Verify OTP & receive JWT token | No |
| `GET` | `/api/auth/me` | Fetch active operator identity | Yes (Bearer/Cookie) |
| `GET` | `/api/live/dashboard` | Live operations revenue & stats | No |
| `GET` | `/api/live/machines` | Fleet telemetry snapshot | No |
| `GET` | `/api/machines` | List all vending units | Yes |
| `GET` | `/api/machines/:id` | Specific machine status | Yes |
| `PATCH`| `/api/machines/:id/telemetry` | Ingest temperature & pressure | Yes |
| `POST` | `/api/machines/:id/command` | Dispatch reboot/flush/lock (Ops/Owner) | Yes (Ops/Owner) |
| `GET` | `/api/orders` | Paginated orders history | Yes |
| `POST` | `/api/orders/:id/refund` | Authorize customer refund | Yes (Finance/Owner) |
| `GET` | `/api/support/tickets` | Live dispute tickets queue | Yes |
| `POST` | `/api/support/tickets/:id/resolve` | Issue dispute verdict | Yes (Support/Owner) |
