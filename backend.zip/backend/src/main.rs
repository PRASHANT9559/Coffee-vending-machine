use std::net::SocketAddr;
use axum::{
    middleware::from_fn,
    routing::{get, patch, post},
    Router,
};
use tower_http::{
    cors::{Any, CorsLayer},
    trace::TraceLayer,
};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

mod config;
mod db;
mod error;
mod handlers;
mod middleware;
mod models;

use config::AppConfig;
use handlers::*;
use middleware::auth_middleware;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 1. Initialize Tracing & Logger
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info,manhattan_coffee_backend=debug".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    // 2. Load Configuration from Environment
    let config = AppConfig::from_env();
    tracing::info!("☕ Initializing Manhattan Coffee Rust Core Engine...");
    tracing::info!("📡 Database URL target: {}", &config.database_url);

    // 3. Connect to PostgreSQL via SQLx Connection Pool
    let pool = match db::create_pool(&config.database_url).await {
        Ok(pool) => {
            tracing::info!("✅ Connected to PostgreSQL database pool successfully.");
            pool
        }
        Err(err) => {
            tracing::warn!("⚠️ PostgreSQL connection warning: {}. Using fallback resilience mode.", err);
            // Attempt fallback or retry
            db::create_pool(&config.database_url).await.unwrap_or_else(|e| {
                tracing::error!("Fatal DB connection failure: {:?}", e);
                panic!("Cannot proceed without database pool: {}", e);
            })
        }
    };

    // 4. Setup CORS Layer
    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any);

    // 5. Build Public & Authenticated Routes
    let public_routes = Router::new()
        .route("/health", get(health_check))
        .route("/api/auth/login", post(login_handler))
        .route("/api/auth/otp/verify", post(otp_verify_handler))
        .route("/api/live/dashboard", get(live_dashboard))
        .route("/api/live/machines", get(live_machines));

    let protected_routes = Router::new()
        .route("/api/auth/me", get(me_handler))
        .route("/api/machines", get(list_machines))
        .route("/api/machines/:id", get(get_machine))
        .route("/api/machines/:id/telemetry", patch(update_telemetry))
        .route("/api/machines/:id/command", post(dispatch_hardware_command))
        .route("/api/orders", get(list_orders))
        .route("/api/orders/:id", get(get_order))
        .route("/api/orders/:id/refund", post(process_refund))
        .route("/api/support/tickets", get(list_tickets))
        .route("/api/support/tickets/:id", get(get_ticket))
        .route("/api/support/tickets/:id/resolve", post(resolve_dispute))
        .layer(from_fn(auth_middleware));

    // Combine all routes
    let app = Router::new()
        .merge(public_routes)
        .merge(protected_routes)
        .layer(cors)
        .layer(TraceLayer::new_for_http())
        .with_state(pool);

    // 6. Bind TCP Listener and Run Server
    let addr = SocketAddr::from(([0, 0, 0, 0], config.server_port));
    tracing::info!("🚀 Manhattan Coffee Rust Backend listening on http://{}", addr);

    let listener = tokio::net::TcpListener::bind(&addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}
