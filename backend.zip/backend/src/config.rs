use std::env;

#[derive(Clone, Debug)]
pub struct AppConfig {
    pub server_host: String,
    pub server_port: u16,
    pub database_url: String,
    pub jwt_secret: String,
    pub upload_dir: String,
}

impl AppConfig {
    pub fn from_env() -> Self {
        dotenvy::dotenv().ok();

        let server_host = env::var("SERVER_HOST").unwrap_or_else(|_| "0.0.0.0".to_string());
        let server_port = env::var("PORT")
            .unwrap_or_else(|_| env::var("SERVER_PORT").unwrap_or_else(|_| "8080".to_string()))
            .parse::<u16>()
            .unwrap_or(8080);

        let database_url = env::var("DATABASE_URL").unwrap_or_else(|_| {
            "postgresql://manhattan_user:manhattan_secure_pass@localhost:5432/manhattan_coffee".to_string()
        });

        let jwt_secret = env::var("JWT_SECRET").unwrap_or_else(|_| {
            "manhattan_coffee_vps_master_jwt_secret_2026_prod_rust_key".to_string()
        });

        let upload_dir = env::var("UPLOAD_DIR").unwrap_or_else(|_| {
            "/var/www/manhattan/uploads".to_string()
        });

        Self {
            server_host,
            server_port,
            database_url,
            jwt_secret,
            upload_dir,
        }
    }
}
