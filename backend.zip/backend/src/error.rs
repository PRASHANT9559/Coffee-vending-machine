use axum::{
    http::StatusCode,
    response::{IntoResponse, Response},
    Json,
};
use serde_json::json;

#[derive(Debug)]
pub enum AppError {
    Database(sqlx::Error),
    NotFound(String),
    Unauthorized(String),
    Forbidden(String),
    BadRequest(String),
    Internal(String),
}

impl std::fmt::Display for AppError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Database(err) => write!(f, "Database error: {err}"),
            Self::NotFound(msg) => write!(f, "Not found: {msg}"),
            Self::Unauthorized(msg) => write!(f, "Unauthorized: {msg}"),
            Self::Forbidden(msg) => write!(f, "Forbidden: {msg}"),
            Self::BadRequest(msg) => write!(f, "Bad request: {msg}"),
            Self::Internal(msg) => write!(f, "Internal error: {msg}"),
        }
    }
}

impl std::error::Error for AppError {}

impl From<sqlx::Error> for AppError {
    fn from(err: sqlx::Error) -> Self {
        Self::Database(err)
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, error_message, error_code) = match self {
            Self::Database(ref err) => {
                tracing::error!("Database query failure: {:?}", err);
                (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    "Database operation failed".to_string(),
                    "DATABASE_ERROR",
                )
            }
            Self::NotFound(msg) => (StatusCode::NOT_FOUND, msg, "NOT_FOUND"),
            Self::Unauthorized(msg) => (StatusCode::UNAUTHORIZED, msg, "UNAUTHORIZED"),
            Self::Forbidden(msg) => (StatusCode::FORBIDDEN, msg, "FORBIDDEN"),
            Self::BadRequest(msg) => (StatusCode::BAD_REQUEST, msg, "BAD_REQUEST"),
            Self::Internal(msg) => {
                tracing::error!("Internal server failure: {}", msg);
                (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    "Internal server error occurred".to_string(),
                    "INTERNAL_SERVER_ERROR",
                )
            }
        };

        let body = Json(json!({
            "success": false,
            "error": error_message,
            "code": error_code,
        }));

        (status, body).into_response()
    }
}
