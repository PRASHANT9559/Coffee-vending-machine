use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Tank {
    pub id: String,
    pub batch_no: String,
    pub supplier_name: String,
    pub fssai_cert_no: String,
    pub liters_capacity: f64,
    pub current_liters: f64,
    pub temperature_c: f64,
    pub status: String,
    pub assigned_machine_id: Option<String>,
    pub mounted_at: DateTime<Utc>,
    pub expiry_date: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct StockItem {
    pub id: String,
    pub item_name: String,
    pub category: String,
    pub quantity: f64,
    pub unit: String,
    pub reorder_level: f64,
    pub cost_basis_inr: f64,
}
