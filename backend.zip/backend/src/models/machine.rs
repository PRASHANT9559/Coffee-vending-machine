use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "UPPERCASE")]
pub enum MachineStatus {
    Online,
    Offline,
    Fault,
    Maintenance,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "UPPERCASE")]
pub enum MachineMode {
    Hot,
    Cold,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Machine {
    pub id: String,
    pub code: String,
    pub name: String,
    pub location: String,
    pub zone: String,
    pub status: String,
    pub mode: String,
    pub current_temp: f64,
    pub target_temp: f64,
    pub boiler_pressure: f64,
    pub water_flow_rate: f64,
    pub milk_level_liters: f64,
    pub milk_capacity_liters: f64,
    pub cups_dispensed_today: i32,
    pub cleaning_status: String,
    pub last_heartbeat: Option<DateTime<Utc>>,
}

#[derive(Debug, Deserialize)]
pub struct UpdateTelemetryRequest {
    pub current_temp: Option<f64>,
    pub target_temp: Option<f64>,
    pub boiler_pressure: Option<f64>,
    pub milk_level_liters: Option<f64>,
    pub status: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct HardwareCommandRequest {
    pub command: String, // REBOOT, TEST_DISPENSE, FLUSH_CYCLE, LOCK, UNLOCK
    pub reason: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct HardwareCommandResponse {
    pub success: bool,
    pub machine_id: String,
    pub command: String,
    pub ack_time_ms: u64,
    pub dispatched_at: DateTime<Utc>,
}
