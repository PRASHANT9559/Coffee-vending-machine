use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Order {
    pub id: String,
    pub machine_id: String,
    pub customer_id: Option<String>,
    pub customer_name: String,
    pub beverage_name: String,
    pub temperature_mode: String,
    pub sugar_level: String,
    pub amount_inr: f64,
    pub payment_method: String,
    pub status: String,
    pub qr_token: Option<String>,
    pub error_code: Option<String>,
    pub dispense_time_seconds: Option<i32>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Deserialize)]
pub struct RefundRequest {
    pub order_id: String,
    pub amount_inr: f64,
    pub reason: String,
}

#[derive(Debug, Serialize)]
pub struct RefundResponse {
    pub success: bool,
    pub refund_id: String,
    pub order_id: String,
    pub amount_inr: f64,
    pub timestamp: DateTime<Utc>,
}
