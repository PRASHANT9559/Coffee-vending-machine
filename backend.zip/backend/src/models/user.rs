use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum UserRole {
    Viewer,
    Support,
    Ops,
    Marketing,
    Finance,
    Owner,
}

impl UserRole {
    pub fn can_mutate_machines(&self) -> bool {
        matches!(self, Self::Ops | Self::Owner)
    }

    pub fn can_resolve_disputes(&self) -> bool {
        matches!(self, Self::Support | Self::Finance | Self::Owner)
    }

    pub fn can_refund_orders(&self) -> bool {
        matches!(self, Self::Finance | Self::Owner)
    }

    pub fn can_access_marketing(&self) -> bool {
        matches!(self, Self::Marketing | Self::Owner)
    }

    pub fn can_manage_settings(&self) -> bool {
        matches!(self, Self::Owner)
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Claims {
    pub sub: String,
    pub user_id: String,
    pub email: String,
    pub role: UserRole,
    pub mfa_verified: bool,
    pub exp: usize,
    pub iat: usize,
}

#[derive(Debug, Deserialize)]
pub struct LoginRequest {
    pub email: String,
    pub role: Option<UserRole>,
}

#[derive(Debug, Serialize)]
pub struct LoginResponse {
    pub success: bool,
    pub requires_otp: bool,
    pub email: String,
    pub demo_code: String,
    pub message: String,
}

#[derive(Debug, Deserialize)]
pub struct OtpVerifyRequest {
    pub email: String,
    pub code: String,
    pub role: Option<UserRole>,
}

#[derive(Debug, Serialize)]
pub struct AuthResponse {
    pub success: bool,
    pub token: String,
    pub user: UserInfo,
}

#[derive(Debug, Serialize)]
pub struct UserInfo {
    pub user_id: String,
    pub email: String,
    pub role: UserRole,
    pub mfa_verified: bool,
}
