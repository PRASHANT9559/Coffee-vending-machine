use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct SupportTicket {
    pub id: String,
    pub ticket_no: String,
    pub order_id: String,
    pub machine_id: String,
    pub customer_id: String,
    pub customer_name: String,
    pub issue_type: String,
    pub status: String,
    pub priority: String,
    pub flow_rate_variance: f64,
    pub expected_grams: f64,
    pub dispensed_grams: f64,
    pub video_clip_uri: Option<String>,
    pub sla_seconds_remaining: i32,
    pub operator_verdict: Option<String>,
    pub operator_note: Option<String>,
    pub resolved_by: Option<String>,
    pub resolved_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Deserialize)]
pub struct ResolveDisputeRequest {
    pub verdict: String, // APPROVED, REJECTED, REQUEST_INFO, BLACKLIST
    pub note: String,
}

#[derive(Debug, Serialize)]
pub struct ResolveDisputeResponse {
    pub success: bool,
    pub ticket_id: String,
    pub verdict: String,
    pub status: String,
    pub resolved_at: DateTime<Utc>,
}
