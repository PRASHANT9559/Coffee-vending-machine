use axum::{
    extract::{Path, State},
    Extension, Json,
};
use chrono::Utc;
use rand::Rng;
use serde_json::{json, Value};
use sqlx::PgPool;

use crate::{
    error::AppError,
    middleware::AuthContext,
    models::{HardwareCommandRequest, HardwareCommandResponse, Machine, UpdateTelemetryRequest},
};

pub async fn list_machines(
    State(pool): State<PgPool>,
) -> Result<Json<Value>, AppError> {
    let machines = sqlx::query_as::<_, Machine>(
        "SELECT * FROM machines ORDER BY id ASC"
    )
    .fetch_all(&pool)
    .await
    .unwrap_or_else(|_| vec![]);

    Ok(Json(json!({
        "success": true,
        "count": machines.len(),
        "data": machines,
    })))
}

pub async fn get_machine(
    State(pool): State<PgPool>,
    Path(id): Path<String>,
) -> Result<Json<Machine>, AppError> {
    let machine = sqlx::query_as::<_, Machine>(
        "SELECT * FROM machines WHERE id = $1 LIMIT 1"
    )
    .bind(&id)
    .fetch_optional(&pool)
    .await?
    .ok_or_else(|| AppError::NotFound(format!("Machine {id} not found")))?;

    Ok(Json(machine))
}

pub async fn update_telemetry(
    State(pool): State<PgPool>,
    Path(id): Path<String>,
    Json(payload): Json<UpdateTelemetryRequest>,
) -> Result<Json<Value>, AppError> {
    let mut query = String::from("UPDATE machines SET updated_at = NOW()");
    if let Some(temp) = payload.current_temp {
        query.push_str(&format!(", current_temp = {temp}"));
    }
    if let Some(target) = payload.target_temp {
        query.push_str(&format!(", target_temp = {target}"));
    }
    if let Some(milk) = payload.milk_level_liters {
        query.push_str(&format!(", milk_level_liters = {milk}"));
    }
    if let Some(ref st) = payload.status {
        query.push_str(&format!(", status = '{st}'"));
    }
    query.push_str(&format!(" WHERE id = '{id}'"));

    sqlx::query(&query).execute(&pool).await?;

    Ok(Json(json!({
        "success": true,
        "message": format!("Telemetry updated for {id}"),
    })))
}

pub async fn dispatch_hardware_command(
    State(pool): State<PgPool>,
    Extension(auth_ctx): Extension<AuthContext>,
    Path(id): Path<String>,
    Json(payload): Json<HardwareCommandRequest>,
) -> Result<Json<HardwareCommandResponse>, AppError> {
    // RBAC check: only Ops and Owner can execute hardware operations
    if !auth_ctx.role.can_mutate_machines() {
        return Err(AppError::Forbidden(format!(
            "Role '{:?}' cannot dispatch hardware commands",
            auth_ctx.role
        )));
    }

    let ack_time_ms = rand::thread_rng().gen_range(80..220);

    // Audit log in database
    let _ = sqlx::query!(
        "INSERT INTO audit_logs (user_id, user_role, action, permission, status, details) VALUES ($1, $2, $3, 'hardware.command.dispatch', 'SUCCESS', $4)",
        auth_ctx.user_id,
        format!("{:?}", auth_ctx.role).to_lowercase(),
        format!("COMMAND_{}", payload.command),
        json!({ "machine_id": id, "reason": payload.reason })
    )
    .execute(&pool)
    .await;

    tracing::info!(
        "Rust Ops: Command {} dispatched to machine {} by {}",
        payload.command,
        id,
        auth_ctx.user_id
    );

    Ok(Json(HardwareCommandResponse {
        success: true,
        machine_id: id,
        command: payload.command,
        ack_time_ms,
        dispatched_at: Utc::now(),
    }))
}
