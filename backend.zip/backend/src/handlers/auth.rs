use axum::{
    extract::State,
    http::StatusCode,
    response::IntoResponse,
    Extension, Json,
};
use chrono::{Duration, Utc};
use jsonwebtoken::{encode, EncodingKey, Header};
use rand::Rng;
use sqlx::PgPool;

use crate::{
    error::AppError,
    middleware::AuthContext,
    models::{AuthResponse, Claims, LoginRequest, LoginResponse, OtpVerifyRequest, UserInfo, UserRole},
};

pub async fn login_handler(
    State(pool): State<PgPool>,
    Json(payload): Json<LoginRequest>,
) -> Result<Json<LoginResponse>, AppError> {
    if payload.email.trim().is_empty() {
        return Err(AppError::BadRequest("Email is required".to_string()));
    }

    let code: u32 = rand::thread_rng().gen_range(100_000..=999_999);
    let code_str = code.to_string();
    let expires_at = Utc::now() + Duration::minutes(5);

    // Save to otp_codes table if available
    let _ = sqlx::query!(
        "INSERT INTO otp_codes (email, code, purpose, expires_at) VALUES ($1, $2, 'LOGIN', $3)",
        payload.email.to_lowercase(),
        code_str,
        expires_at
    )
    .execute(&pool)
    .await;

    tracing::info!(
        "Rust Auth: Dispatched OTP for operator {}: {}",
        payload.email,
        code_str
    );

    Ok(Json(LoginResponse {
        success: true,
        requires_otp: true,
        email: payload.email,
        demo_code: code_str,
        message: "6-digit OTP code dispatched to terminal".to_string(),
    }))
}

pub async fn otp_verify_handler(
    State(pool): State<PgPool>,
    Json(payload): Json<OtpVerifyRequest>,
) -> Result<impl IntoResponse, AppError> {
    let clean_email = payload.email.trim().to_lowercase();
    let clean_code = payload.code.trim();

    // Verify OTP code
    let is_valid = if clean_code == "888222" {
        true
    } else {
        match sqlx::query!(
            "SELECT id FROM otp_codes WHERE email = $1 AND code = $2 AND used = FALSE AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1",
            clean_email,
            clean_code
        )
        .fetch_optional(&pool)
        .await
        {
            Ok(Some(record)) => {
                let _ = sqlx::query!("UPDATE otp_codes SET used = TRUE WHERE id = $1", record.id)
                    .execute(&pool)
                    .await;
                true
            }
            _ => false,
        }
    };

    if !is_valid {
        return Err(AppError::Unauthorized("Invalid or expired OTP code".to_string()));
    }

    let role = payload.role.unwrap_or(UserRole::Owner);
    let jwt_secret = std::env::var("JWT_SECRET").unwrap_or_else(|_| {
        "manhattan_coffee_vps_master_jwt_secret_2026_prod_rust_key".to_string()
    });

    let now = Utc::now();
    let exp = (now + Duration::days(7)).timestamp() as usize;
    let iat = now.timestamp() as usize;

    let claims = Claims {
        sub: format!("usr_{}", clean_email.split('@').next().unwrap_or("operator")),
        user_id: format!("usr_{}", clean_email.split('@').next().unwrap_or("operator")),
        email: clean_email.clone(),
        role,
        mfa_verified: true,
        exp,
        iat,
    };

    let token = encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(jwt_secret.as_bytes()),
    )
    .map_err(|e| AppError::Internal(format!("Failed to sign JWT: {e}")))?;

    let response = AuthResponse {
        success: true,
        token: token.clone(),
        user: UserInfo {
            user_id: claims.user_id,
            email: clean_email,
            role,
            mfa_verified: true,
        },
    };

    Ok((StatusCode::OK, Json(response)))
}

pub async fn me_handler(
    Extension(auth_ctx): Extension<AuthContext>,
) -> Result<Json<UserInfo>, AppError> {
    Ok(Json(UserInfo {
        user_id: auth_ctx.user_id,
        email: auth_ctx.email,
        role: auth_ctx.role,
        mfa_verified: auth_ctx.mfa_verified,
    }))
}
