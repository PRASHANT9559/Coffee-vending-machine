use axum::{
    extract::{Path, State},
    Extension, Json,
};
use chrono::Utc;
use serde_json::{json, Value};
use sqlx::PgPool;

use crate::{
    error::AppError,
    middleware::AuthContext,
    models::{ResolveDisputeRequest, ResolveDisputeResponse, SupportTicket},
};

pub async fn list_tickets(
    State(pool): State<PgPool>,
) -> Result<Json<Value>, AppError> {
    let tickets = sqlx::query_as::<_, SupportTicket>(
        "SELECT * FROM support_tickets ORDER BY created_at DESC"
    )
    .fetch_all(&pool)
    .await
    .unwrap_or_else(|_| vec![]);

    let open_count = tickets.iter().filter(|t| t.status == "OPEN").count();
    let urgent_sla_count = tickets
        .iter()
        .filter(|t| t.status == "OPEN" && t.sla_seconds_remaining < 180)
        .count();

    Ok(Json(json!({
        "success": true,
        "total_tickets": tickets.len(),
        "open_tickets": open_count,
        "urgent_sla": urgent_sla_count,
        "data": tickets,
    })))
}

pub async fn get_ticket(
    State(pool): State<PgPool>,
    Path(id): Path<String>,
) -> Result<Json<SupportTicket>, AppError> {
    let ticket = sqlx::query_as::<_, SupportTicket>(
        "SELECT * FROM support_tickets WHERE id = $1 OR ticket_no = $1 LIMIT 1"
    )
    .bind(&id)
    .fetch_optional(&pool)
    .await?
    .ok_or_else(|| AppError::NotFound(format!("Ticket {id} not found")))?;

    Ok(Json(ticket))
}

pub async fn resolve_dispute(
    State(pool): State<PgPool>,
    Extension(auth_ctx): Extension<AuthContext>,
    Path(id): Path<String>,
    Json(payload): Json<ResolveDisputeRequest>,
) -> Result<Json<ResolveDisputeResponse>, AppError> {
    if !auth_ctx.role.can_resolve_disputes() {
        return Err(AppError::Forbidden(format!(
            "Role '{:?}' cannot resolve support disputes",
            auth_ctx.role
        )));
    }

    let status = if payload.verdict == "APPROVED" {
        "APPROVED"
    } else {
        "REJECTED"
    };

    let resolved_at = Utc::now();

    sqlx::query!(
        "UPDATE support_tickets SET status = $1, operator_verdict = $2, operator_note = $3, resolved_by = $4, resolved_at = $5 WHERE id = $6 OR ticket_no = $6",
        status,
        payload.verdict,
        payload.note,
        auth_ctx.email,
        resolved_at,
        id
    )
    .execute(&pool)
    .await?;

    let _ = sqlx::query!(
        "INSERT INTO audit_logs (user_id, user_role, action, permission, status, details) VALUES ($1, $2, 'DISPUTE_VERDICT_RESOLVED', 'support.dispute.resolve', 'SUCCESS', $3)",
        auth_ctx.user_id,
        format!("{:?}", auth_ctx.role).to_lowercase(),
        json!({ "ticket_id": id, "verdict": payload.verdict, "note": payload.note })
    )
    .execute(&pool)
    .await;

    Ok(Json(ResolveDisputeResponse {
        success: true,
        ticket_id: id,
        verdict: payload.verdict,
        status: status.to_string(),
        resolved_at,
    }))
}
