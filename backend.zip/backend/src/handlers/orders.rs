use axum::{
    extract::{Path, Query, State},
    Extension, Json,
};
use chrono::Utc;
use serde::Deserialize;
use serde_json::{json, Value};
use sqlx::PgPool;

use crate::{
    error::AppError,
    middleware::AuthContext,
    models::{Order, RefundRequest, RefundResponse},
};

#[derive(Debug, Deserialize)]
pub struct OrderQueryParams {
    pub limit: Option<i64>,
    pub offset: Option<i64>,
}

pub async fn list_orders(
    State(pool): State<PgPool>,
    Query(params): Query<OrderQueryParams>,
) -> Result<Json<Value>, AppError> {
    let limit = params.limit.unwrap_or(50).min(100);
    let offset = params.offset.unwrap_or(0);

    let orders = sqlx::query_as::<_, Order>(
        "SELECT * FROM orders ORDER BY created_at DESC LIMIT $1 OFFSET $2"
    )
    .bind(limit)
    .bind(offset)
    .fetch_all(&pool)
    .await
    .unwrap_or_else(|_| vec![]);

    Ok(Json(json!({
        "success": true,
        "count": orders.len(),
        "limit": limit,
        "offset": offset,
        "data": orders,
    })))
}

pub async fn get_order(
    State(pool): State<PgPool>,
    Path(id): Path<String>,
) -> Result<Json<Order>, AppError> {
    let order = sqlx::query_as::<_, Order>(
        "SELECT * FROM orders WHERE id = $1 LIMIT 1"
    )
    .bind(&id)
    .fetch_optional(&pool)
    .await?
    .ok_or_else(|| AppError::NotFound(format!("Order {id} not found")))?;

    Ok(Json(order))
}

pub async fn process_refund(
    State(pool): State<PgPool>,
    Extension(auth_ctx): Extension<AuthContext>,
    Path(id): Path<String>,
    Json(payload): Json<RefundRequest>,
) -> Result<Json<RefundResponse>, AppError> {
    if !auth_ctx.role.can_refund_orders() {
        return Err(AppError::Forbidden(format!(
            "Role '{:?}' lacks finance.refund.approve permission",
            auth_ctx.role
        )));
    }

    let refund_id = format!("RFND_{}", Utc::now().timestamp_millis());

    // Update order status to REFUNDED
    sqlx::query!(
        "UPDATE orders SET status = 'REFUNDED' WHERE id = $1",
        id
    )
    .execute(&pool)
    .await?;

    // Record audit trail
    let _ = sqlx::query!(
        "INSERT INTO audit_logs (user_id, user_role, action, permission, status, details) VALUES ($1, $2, 'ORDER_REFUND_APPROVED', 'finance.refund.approve', 'SUCCESS', $3)",
        auth_ctx.user_id,
        format!("{:?}", auth_ctx.role).to_lowercase(),
        json!({ "order_id": id, "amount_inr": payload.amount_inr, "reason": payload.reason })
    )
    .execute(&pool)
    .await;

    Ok(Json(RefundResponse {
        success: true,
        refund_id,
        order_id: id,
        amount_inr: payload.amount_inr,
        timestamp: Utc::now(),
    }))
}
