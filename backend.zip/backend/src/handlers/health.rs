use axum::{extract::State, Json};
use serde_json::{json, Value};
use sqlx::PgPool;

pub async fn health_check(State(pool): State<PgPool>) -> Json<Value> {
    let db_status = match sqlx::query("SELECT 1").execute(&pool).await {
        Ok(_) => "CONNECTED",
        Err(_) => "DISCONNECTED",
    };

    Json(json!({
        "status": "HEALTHY",
        "service": "manhattan-coffee-rust-core",
        "version": env!("CARGO_PKG_VERSION"),
        "database": db_status,
        "runtime": "Tokio Async Engine",
        "timestamp": chrono::Utc::now().to_rfc3339(),
    }))
}
