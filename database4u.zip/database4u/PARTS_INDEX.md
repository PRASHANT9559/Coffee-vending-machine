# Parts Index — Kaam ka Master Tracker

> Ye file batati hai kaunsa Part kis file me hai, kitna kaam bacha hai, aur kis order me karna hai.
> Detail ke liye respective `part*.md` file kholo.

---

## 1. Part files

| Part | File | Scope | Status | Estimate |
|---|---|---|---|---|
| 1 | [`part1-core-backend.md`](./part1-core-backend.md) | Core Backend & Database Management (12 modules + Connection Manager) | ~15% | 55–70 din |
| 2 | [`part2-file-storage.md`](./part2-file-storage.md) | File Storage & Upload System | ~2% | 26–30 din |
| 3 | [`part3-security.md`](./part3-security.md) | Security & Access Control (auth, RBAC, isolation, ACL) | ~3% | 30–33 din |
| 4 | [`part4-slint-client.md`](./part4-slint-client.md) | Slint Desktop Manager | ~8% | 38–41 din |
| 5 | [`part5-deployment.md`](./part5-deployment.md) | VPS Deployment & Storage Infrastructure | ~0% | 19–23 din |
| 6 | [`part6-realtime-performance.md`](./part6-realtime-performance.md) | Realtime, Performance & Scaling | 0% | 32–37 din |

**Total: ~200–234 working days** (1 developer, serial).
Parallel teams ke saath realistic calendar: **~10–12 months** (Part 1 + 3 pehle, phir 2 + 4, phir 5, phir 6).

---

## 2. Recommended execution order

```
Week 1–2    Part 1 · M0  Compile baseline          ← SABSE PEHLE
Week 3      Part 1 · M1  Schema complete
Week 3–4    Part 1 · M2  API Gateway
Week 4–5    Part 1 · M3  Auth mechanics  ──┐
Week 5–6    Part 1 · M4  Projects          │  Part 3 ke saath parallel
Week 5–7    Part 3 · M0–M3  Auth + RBAC + isolation
Week 7–12   Part 1 · M5  Connection Manager (biggest single chunk)
Week 12–13  Part 1 · M6  Database Engine
Week 13–15  Part 1 · M7  Schema Manager
Week 15–17  Part 1 · M8  CRUD / Query / Transactions
Week 17      Part 1 · M9  Permissions + Audit wiring
Week 18      Part 1 · M10 checkpoints
Week 18–21  Part 3 · M4–M8  Rate limit, audit, ACL, negative tests, hardening
Week 21–24  Part 2 · M0–M5  Storage + upload + download
Week 24–25  Part 2 · M6–M9  Quotas, cleanup, ACL hook, metrics
Week 22–27  Part 4 · M0–M4  Client build fix, API client, login, shell, explorer
Week 27–29  Part 4 · M5–M7  File manager, uploads, states
Week 29–30  Part 4 · M8–M10 Settings, packaging, tests
Week 28–30  Part 5 · M0–M5  VPS hardening, disk, proxy, systemd
Week 30–31  Part 5 · M6–M10 CI/CD, monitoring, backup, runbook, drills
Week 32–35  Part 6 · M0–M11 Realtime, caching, streaming, load tests
```

> Part 6 sabse last — pehle 1–5 stable hone chahiye. Part 5 (deploy) Part 2/4 ke saath overlap
> kar sakta hai kyunki wo mostly ops ka kaam hai.

---

## 3. Global blockers (aaj hi fix karne wale)

| # | Blocker | File | Fix |
|---|---|---|---|
| 1 | Backend server nahi chalta | `database-manager/src/main.rs` | Axum bootstrap (Part 1 · M0) |
| 2 | Router khaali | `database-manager/src/api/routes.rs` | `create_router(state)` (Part 1 · M0) |
| 3 | Desktop build fail | `desktop_manager/build.rs` missing | `slint_build::compile` (Part 4 · M0) |
| 4 | Slint compile error | `desktop_manager/ui/login.slint` | `LineEdit input-type` hatao (Part 4 · M0) |
| 5 | `Cargo.lock` nahi | repo root | `cargo generate-lockfile` |
| 6 | 14 tables missing | `database-manager/migrations/` | `008`–`014` (Part 1 · M1) |
| 7 | Docs khali | `database-manager/docs/*.md` | Part 1 ke saath update |
| 8 | 117 placeholder files | `src/**` | milestone-wise fill |

---

## 4. Definition of "done" (project level)

1. Backend `cargo test` + `clippy -D warnings` clean
2. End-to-end: login → project → connection → database → table → record → audit
3. File upload/download/resume 1 GB tak bounded memory ke saath
4. Cross-project access 100% blocked (negative test suite)
5. Desktop app se poora flow chalta hai
6. HTTPS VPS deploy + off-site backup + restore drill passed
7. Load test results documented (p95/p99)
8. Koi secret logs/response/config/git me nahi

---

## 5. Kaise use karein

- Har `part*.md` me checkboxes hain — kaam karte waqt `- [ ]` ko `- [x]` karo.
- Kisi Part me scope change ho to usi file ke "Current Status" section ko update karo.
- Milestone complete hone par `PARTS_INDEX.md` ki status % update karo.
