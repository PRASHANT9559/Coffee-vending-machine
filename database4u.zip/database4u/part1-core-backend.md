# Part 1 — Core Backend & Database Management

> **Scope:** Rust modular monolith ka core — API Gateway, Auth, Projects, Connection Manager,
> Database Engine, Schema Manager, CRUD, Query Engine, Permissions, Transactions, Audit, Realtime.
>
> **Depends on:** kuch nahi (ye foundation hai)
> **Blocks:** Part 2, Part 3, Part 4, Part 6
> **Owner:** Backend (Rust)
> **Estimate:** 6–8 weeks (1 developer)

---

## 0. Current Status (audit — 04 Nov 2026)

| Item | Value |
|---|---|
| Rust files in `database-manager/src/` | 123 |
| Total lines | 557 |
| Placeholder files (≤10 lines, only comments) | 117 |
| Actually working modules | 1 (crypto layer) |
| Migrations | 7 files, 14 tables |
| Server bootstraps? | ❌ `main.rs` sirf `println!` |
| Router? | ❌ `create_router()` empty |
| Compiles? | ❌ verify nahi hua (no cargo, no Cargo.lock) |

### Module-wise reality

| # | Module | Folder | Real code | Status |
|---|---|---|---|---|
| 01 | API Gateway | `api/` | 0 | 🔴 |
| 02 | Auth & Session | `auth/`, `security/auth/` | 0 | 🔴 |
| 03 | Project Manager | `projects/` | 0 | 🔴 |
| 04 | Connection Manager | `connections/` | 193 (crypto only) | 🟡 |
| 05 | Database Engine | `databases/` | 0 | 🔴 |
| 06 | Schema Manager | `schema/` | 0 | 🔴 |
| 07 | Record / CRUD | `records/` | 0 | 🔴 |
| 08 | Query Engine | `queries/` | 0 | 🔴 |
| 09 | Permission Engine | `permissions/`, `security/permissions/` | 0 | 🔴 |
| 10 | Transaction Manager | `transactions/` | 0 | 🔴 |
| 11 | Audit Logger | `audit/` | 0 (table exists) | 🔴 |
| 12 | Realtime Manager | `realtime/` | 0 | 🔴 |

### Already done (reuse karo, delete mat karo)

- `src/infrastructure/encryption/mod.rs` — XChaCha20-Poly1305 `CryptoEngine` (173 lines, 2 tests) ✅
- `src/connections/credentials/*` — vault / encrypt / decrypt / rotate (~90 lines) ✅
- `src/connections/state/machine.rs` — `ConnectionState` enum ✅
- `src/common/errors.rs` — `AppError` enum (5 variants, extend karna hai) ✅
- `src/config/settings.rs` — `Settings` struct (load nahi hota) 🟡
- Migrations 001–007 — users, sessions, refresh_tokens, projects, project_members, connections,
  connection_credentials, connection_projects, connection_databases, roles, permissions,
  role_permissions, audit_logs, files ✅

---

## Milestone M0 — Compile Baseline (P0, 2–3 din)

Ye sabse pehla kaam hai. Iske bina kuch test nahi ho sakta.

- [ ] `Cargo.toml` me missing deps add karo: `dotenvy`, `http`, `subtle`, `rand`, `mime_guess`,
      `sha2`, `hex`, `serde_with` (jo zaroorat pade)
- [ ] `database-manager/src/main.rs` — real Axum bootstrap:
  - `tracing_subscriber` init (env-filter, JSON optional)
  - `Settings::from_env()` load
  - `PgPool` create (manager_core)
  - `AppState { db, settings, crypto }` build
  - `create_router(state)` + `tokio::net::TcpListener` + `axum::serve`
  - graceful shutdown (SIGTERM → drain)
- [ ] `src/api/routes.rs` — `pub fn create_router(state: AppState) -> Router` with `/health`,
      `/ready`, and `/api/v1` nested router
- [ ] `src/api/mod.rs` — re-export `create_router`, `AppState`
- [ ] `src/api/response.rs` — `ApiResponse<T>` success envelope + `ApiError` error envelope
      (`code`, `message`, `request_id`, `details`), `impl IntoResponse for AppError`
- [ ] `src/common/errors.rs` — variants add karo: `Validation`, `Forbidden`, `Conflict`,
      `RateLimited`, `Timeout`, `Unavailable`; har ek ka HTTP status mapping
- [ ] `src/config/environment.rs` — `dotenvy::dotenv()` + env parsing helpers
- [ ] `src/config/settings.rs` — `Settings::from_env() -> Result<Self>`, missing env par fail-fast,
      `Debug` impl me secrets redact
- [ ] `src/common/types.rs` — `Pagination { page, limit }`, `Sort { field, order }`, `Page<T>`
- [ ] `src/common/validation.rs` — identifier validator (see M5), email/username/password rules
- [ ] `src/lib.rs` — verify all `pub mod` compile karte hain
- [ ] `Cargo.lock` generate karo aur commit karo
- [ ] `cargo fmt` + `cargo clippy -- -D warnings` clean
- [ ] `.gitignore` me `target/`, `.env`, `*.log`, `storage/` add

**Acceptance:** `cargo run` → server port 8080 par listen kare, `GET /health` → `{"status":"ok"}`.

---

## Milestone M1 — manager_core Schema Complete (P0, 2 din)

Abhi 14/28 tables hain. Baaki add karo (new migration files `008_*.sql` … `014_*.sql`).

- [ ] `008_project_member_roles.sql` — member ↔ role mapping
- [ ] `009_connection_configs.sql` — `connection_ssl_configs`, `connection_ssh_configs`
- [ ] `010_connection_ops.sql` — `connection_pool_policies`, `connection_health_logs`,
      `connection_events`, `connection_access`
- [ ] `011_files_extra.sql` — `upload_sessions`, `file_permissions`, `file_versions`,
      `file_events`, `file_storage_usage`
- [ ] `012_system.sql` — `system_settings`, `schema_snapshots`
- [ ] `013_seed_roles_permissions.sql` — roles (`owner`, `admin`, `editor`, `viewer`) +
      permissions seed (`project.read`, `project.members.manage`, `connection.manage`,
      `database.read`, `database.write`, `schema.alter`, `query.execute`,
      `file.read`, `file.upload`, `file.download`, `file.delete`, `file.share`, `audit.read`)
- [ ] Har table me: `created_at`, `updated_at`, proper `ON DELETE` behaviour, unique constraints
- [ ] `files` table me missing indexes: `(project_id, status)`, `(owner_user_id)`, `(checksum)`
- [ ] `audit_logs` me index: `(project_id, created_at DESC)`, `(user_id, created_at DESC)`
- [ ] `sessions`/`refresh_tokens` me `revoked_at`, `user_agent`, `ip_hash` columns
- [ ] Migration runner: `sqlx::migrate!("./migrations").run(&pool)` startup par
- [ ] Decide: **runtime queries** (`sqlx::query`) use karo, compile-time macros (`query!`) nahi —
      warna build ke waqt live DB chahiye hogi

**Acceptance:** khaali PostgreSQL par `cargo run` → saari migrations apply, 28 tables exist.

---

## Milestone M2 — API Gateway (Module 01) (P1, 3–4 din)

- [ ] `src/api/middleware.rs`:
  - `request_id` middleware (UUID, response header + tracing span)
  - `auth` extractor — `Authorization: Bearer <token>` → `AuthUser { user_id, session_id }`
  - `rate_limit` — `governor` per-IP + per-user (login par strict)
  - `body_limit` (tower-http `RequestBodyLimitLayer`) — default 1 MB, upload routes exempt
  - `cors` (desktop client ke liye restrictive)
  - `trace` layer with sanitized fields
  - `catch_panic` / `TimeoutLayer`
- [ ] Error responses me cross-project resource existence leak na ho (403 vs 404 policy)
- [ ] Har handler `Result<ApiResponse<T>, AppError>` return kare
- [ ] OpenAPI: `utoipa` optional — abhi skip kar sakte hain, doc `docs/api.md` update karo

**Acceptance:** unknown route → structured 404; no token → 401; rate limit → 429 with
`Retry-After`.

---

## Milestone M3 — Auth & Session Manager (Module 02) (P0, 4–5 din)

> Deep security rules Part 3 me hain. Yahan sirf working mechanics.

- [ ] `src/security/auth/login.rs`:
  - `hash_password` / `verify_password` — **Argon2id**, params: m=19456, t=2, p=1 (tune later)
  - `POST /api/v1/auth/login` — username+password → access + refresh token
  - Constant-time compare; user-not-found par bhi same timing
  - **Bootstrap** guarded by `pg_advisory_xact_lock` — concurrent requests can't create two "first" users.
- [ ] `src/security/auth/tokens.rs`:
  - Access token: short-lived (15 min), signed (HS256 ya opaque + DB session)
  - Refresh token: random 32 bytes, **hash** DB me store, rotation on every use
  - Reuse detection → poora session family revoke
- [ ] `src/security/auth/sessions.rs`:
  - `POST /auth/logout`, `GET /auth/sessions`, `DELETE /auth/sessions/{id}`
  - Multi-device support, `revoked_at` handling
- [ ] `src/security/auth/password_reset.rs`:
  - `POST /auth/password-reset/request` — random token, hash store, 30 min expiry
  - `POST /auth/password-reset/confirm` — single-use, sessions revoke
- [ ] `src/auth/mod.rs` — thin facade re-export
- [ ] `src/users/mod.rs` — user repository (get by id, by username, create, disable)

**Acceptance:** login → protected endpoint → refresh → logout flow Postman/curl se pass.

---

## Milestone M4 — Project Manager (Module 03) (P0, 3 din)

- [ ] `src/projects/mod.rs` (ya `service.rs` + `repository.rs` split):
  - `GET /projects`, `POST /projects`, `GET /projects/{id}`, `PATCH /projects/{id}`,
    `DELETE /projects/{id}` (soft delete/archive)
  - membership: `GET/POST /projects/{id}/members`, `PATCH/DELETE /projects/{id}/members/{user_id}`
  - `GET /projects/{id}/permissions`
- [x] Project ↔ connection mapping endpoints:
  - `GET /projects/{id}/connections` (`project.read`)
  - `POST /projects/{id}/connections` (`project.members.manage` + `connection.manage`)
  - `DELETE /projects/{id}/connections/{connection_id}` (`project.members.manage` + `connection.manage`)
- [ ] Har query me `project_id` scope mandatory — ID guess karke cross-project access na ho
- [ ] New project creator automatically `owner` role
- [ ] Project delete = archive by default; hard delete sirf owner + confirmation flag

**Acceptance:** Do users, do projects → user A project B ka data kabhi na dekh paaye (404).

---

## Milestone M5 — Connection Manager (Module 04) (P0, 2–3 weeks)

Architecture doc §9 + §16.2 ka sequence follow karo. Abhi sirf crypto hai.

### M5.1 Registry & Config
- [ ] `connections/models.rs` — `ServerProfile`, `DatabaseTarget`, `PoolPolicy` structs
- [ ] `connections/dto.rs` — Create/Update/Response DTOs (password sirf request me)
- [ ] `connections/config/postgres.rs` — `PostgresConfig` (host, port, user, db, timeouts)
- [ ] `connections/config/ssl.rs` — `TlsMode` enum: Disable / Require / VerifyCa / VerifyFull
- [ ] `connections/config/validation.rs` — host format, port range, timeout bounds
- [ ] `connections/repository.rs` — SQLx CRUD for `connections`, `connection_projects`,
      `connection_databases`, `connection_credentials`
- [ ] `connections/registry/{create,update,delete}.rs` — lifecycle + validation + audit
- [ ] `connections/service.rs` — orchestration
- [ ] `connections/controller.rs` — HTTP handlers
- [ ] Endpoints: `POST/GET/PATCH/DELETE /connections`, `GET /connections/{id}`,
      `GET /connections/{id}/databases`
- [ ] **List/detail response me password kabhi na jaye** — `credential_id` bhi leak na karo

### M5.2 Credential Manager (partially done)
- [ ] `vault.rs` ko DB se wire karo (`connection_credentials` read/write)
- [ ] Master key `MASTER_ENCRYPTION_KEY` env se load, `Settings` me `SecretString`
- [ ] `rotation.rs` ke liye `POST /connections/{id}/rotate-credential` (admin only)

### M5.3 Network & Connection Tester
- [ ] `network/resolver.rs` — DNS resolve + IP pinning (DNS rebinding guard)
- [ ] `network/security.rs` — metadata IP block (169.254.169.254), private-IP policy
- [ ] `network/connector.rs` — TCP connect with timeout
- [ ] `network/direct_tls.rs` — rustls handshake, cert verification per `TlsMode`
- [ ] `network/ssh_tunnel.rs` + `tunnel.rs` — local port forward, teardown on drop
      (crate: `russh` ya `ssh2`; ek chuno aur document karo)
- [ ] `testing/{dns,tcp,tls,authentication,permissions}.rs` — staged checks
- [ ] `testing/mod.rs` — `ConnectionTestReport { stage, ok, elapsed_ms, sanitized_error }`
- [ ] `POST /connections/{id}/test` — **temporary connection, koi pool nahi, end par close**

### M5.4 Pool Manager & Budget
- [ ] `pool/factory.rs` — `PgPoolOptions` from `PoolPolicy`
      (max 5, min 0, acquire 5s, connect 5s, idle 5m, max_lifetime 30m)
- [ ] `pool/manager.rs` — lazy per-database pool map, `RwLock<HashMap<DatabaseTargetId, Arc<PgPool>>>`
- [ ] `pool/lifecycle.rs` — create / drain / close / recreate
- [ ] `pool/eviction.rs` — idle-only eviction; active operation wale pool ko na chhedo
- [ ] `pool/limits.rs` + `pool_budget/mod.rs` — global budget (default 30), per-server budget,
      reservation before create, exhausted → controlled queue/reject
- [ ] `POST /connections/{id}/connect` / `/disconnect` / `/reconnect`
- [ ] Config change → old pool drain → new pool create

### M5.5 State, Health, Reconnect
- [ ] `state/machine.rs` — enum hai, ab **transitions + guards** implement karo
      (`Uninitialized → Creating → Ready → Draining → Closed`, `Unhealthy`, `Failed`)
- [ ] `health/checker.rs` — lightweight `SELECT 1` + pool acquire check
- [ ] `health/monitor.rs` — configurable interval (default 30s), jitter, no thundering herd
- [ ] `GET /connections/{id}/health`
- [ ] `reconnect/backoff.rs` — exponential + jitter (1,2,4,8,16s, max cap)
- [ ] `reconnect/retry.rs` — single-flight, max attempts, manual trigger
- [ ] **Failed transaction ko blind re-execute mat karo** — verify result first

### M5.6 Isolation, Metrics, Audit
- [ ] `isolation/access.rs` — `authorize(user, project, connection, action)` chain
- [ ] `metrics/collector.rs` — active/idle/waiting connections, latency, reconnect count
- [ ] `GET /connections/{id}/metrics` (plain text/table friendly JSON)
- [ ] `connections/audit/mod.rs` — profile create/update/delete, credential change,
      connect/disconnect events → `audit_logs` + `connection_events`
- [ ] `connection_health_logs` me periodic samples

### M5.7 Tests
- [ ] `tests/registry_tests.rs` — CRUD + validation + secret leakage test
- [ ] `tests/pool_tests.rs` — lazy create, eviction, budget exhaustion
- [ ] `tests/reconnect_tests.rs` — backoff schedule, single-flight
- [ ] `tests/security_tests.rs` — cross-project access denied
- [ ] `tests/integration_tests.rs` — real PostgreSQL against Docker container

**Acceptance:** Add connection → test → connect → query → disconnect; budget limit hit par clean
error; password kabhi response/log me nahi.

---

## Milestone M6 — Database Engine (Module 05) (P1, 1 week)

- [ ] `src/databases/mod.rs` → `models.rs`, `repository.rs`, `service.rs`, `api.rs`
- [ ] `GET /databases`, `POST /databases`, `GET /databases/{id}`
- [ ] `PATCH /databases/{id}` (rename), `DELETE /databases/{id}` (drop)
  - **Permissions:** rename needs `database.create`, drop needs `database.drop`
    (via connection access — not just `schema.alter`).
- [ ] Metadata: size, encoding, collation, owner, active connections, created_at
      (`pg_database`, `pg_stat_database`, `pg_catalog`)
- [ ] **Safety gate:** `DROP DATABASE` / rename → active-connection check + permission check +
      explicit `confirm: true` body field
- [ ] Identifier validation (`^[a-zA-Z_][a-zA-Z0-9_]{0,62}$`) — **bind parameter nahi**, allowlist
- [ ] Database discovery: `GET /connections/{id}/databases` refresh par
      `connection_databases` upsert

**Acceptance:** create → list → rename → drop; unsafe name (`users; DROP`) reject.

---

## Milestone M7 — Schema Manager (Module 06) (P1, 1–1.5 week)

- [ ] `src/schema/` split: `tables.rs`, `columns.rs`, `indexes.rs`, `constraints.rs`,
      `views.rs`, `sequences.rs`, `inspector.rs`, `service.rs`, `api.rs`
- [ ] Tables: `GET /databases/{id}/tables`, `POST /tables` (create), rename, drop
- [ ] Columns: `GET /tables/{id}/columns`, add / rename / alter type / drop
- [ ] Indexes: create / list / drop
- [ ] Constraints: PK, FK, UNIQUE, CHECK — create/list/drop
- [ ] Relations: FK graph endpoint
- [ ] Views: create / list / drop
- [ ] Sequences: list / inspect / manage
- [ ] `inspector.rs` — full table structure (columns + indexes + constraints + row estimate)
- [ ] Saara metadata `information_schema` + `pg_catalog` se — user input sirf identifiers me
- [ ] DDL changes audit + separate permission (`schema.alter`)

**Acceptance:** table create karo, column add karo, index banao, sab list endpoint par dikhe.

---

## Milestone M8 — CRUD, Query & Transactions (Modules 07, 08, 10) (P1, 1.5 week)

### CRUD
- [ ] `src/records/` — `models.rs`, `repository.rs`, `service.rs`, `api.rs`
- [ ] `GET /tables/{id}/records` — pagination (`page`, `limit` default 100, max 500),
      sort (`sort`, `order`), filter, search
- [ ] `POST /records`, `PATCH /records/{id}`, `DELETE /records/{id}`
- [ ] Bulk insert / bulk update
  - **Rule:** every row must use the same column set (avoids silent NULLs/default bypass).
- [ ] NULL handling + type validation per column type
- [ ] Primary key discovery for row identity
- [ ] **Kabhi bhi 100k rows ek response me nahi** — hard cap + `has_more`

### Query Engine
- [ ] `src/queries/` — `validator.rs`, `executor.rs`, `api.rs`
- [ ] `POST /queries/execute` — separate console permission (`query.execute`)
- [ ] Query timeout (configurable, default 5s), `statement_timeout` set
- [ ] Read-only mode (default on for non-admin)
  - **`WITH` (CTE) is classified as write** — a CTE can hide DML, so it requires write
    permission even when the outer statement looks like a `SELECT`.
- [ ] Row limit + result pagination
- [ ] Response: rows, affected, duration_ms, truncated flag
- [ ] Error details sanitized (no schema leak on permission error)
- [ ] Cancellation: `pg_cancel_backend` via request-scoped query id

### Transactions
- [ ] `src/transactions/` — begin / commit / rollback handle, multi-statement API
- [ ] `POST /transactions` (optional MVP) ya internal service API jo modules use karein
- [ ] Commit/rollback test: partial failure → zero side effects
- [ ] Active transaction ke dauran pool eviction block (M5.4 se link)

**Acceptance:** paginated read, safe insert/update/delete, SQL timeout, transaction rollback verified.

---

## Milestone M9 — Permissions & Audit (Modules 09, 11) (P0, 1 week)

- [ ] `src/security/permissions/policy.rs` — `authorize(user, project, resource, action) -> Allow|Deny`
- [ ] `src/security/permissions/enforcement.rs` — Axum extractor/middleware
- [ ] `src/permissions/mod.rs` — thin facade
- [ ] Default **deny**; policy error → fail closed
- [ ] Role → permission resolution (`project_member_roles` → `role_permissions`)
- [ ] Viewer role granted `connection.use` (migration `015`) so read endpoints that need
      a pool actually work; database discovery requires `connection.manage`.
- [ ] `src/audit/mod.rs` — `AuditEvent` struct + async writer
- [ ] `GET /audit` — project-scoped, paginated, filter by action/user/date
- [ ] Har sensitive action par audit: login, project member change, connection change,
      DB drop, schema alter, query execute, file ops
- [ ] Sanitizer: passwords/tokens/keys/signed URLs kabhi log na ho
- [ ] Request ID correlate karo

**Acceptance:** viewer role se write → 403 + audit entry; owner se write → 200 + audit entry.

---

## Milestone M10 — Realtime (Module 12) (P2, Part 6 me detail)

- [ ] `src/realtime/mod.rs` — event bus + WebSocket gateway skeleton
- [ ] Cross-ref: `part6-realtime-performance.md`

---

## Definition of Done (Part 1)

Ye end-to-end flow curl/Postman se chalta ho:

```
1. POST /auth/login                        → tokens
2. POST /projects                          → project
3. POST /connections                       → profile (encrypted password)
4. POST /connections/{id}/test             → staged report
5. POST /connections/{id}/connect          → pool ready
6. GET  /connections/{id}/databases        → discovered DBs
7. GET  /databases/{id}/tables             → tables
8. GET  /tables/{id}/columns               → columns
9. GET  /tables/{id}/records?page=1&limit=100 → rows
10. POST /records                          → insert
11. GET  /audit                            → saare steps dikhein
```

- [ ] `cargo test` green (unit + integration)
- [ ] `cargo clippy -- -D warnings` clean
- [ ] Koi secret response/log me nahi
- [ ] Cross-project access test pass (404)
- [ ] Pool budget exhaustion test pass
- [ ] `docs/api.md` + `docs/architecture.md` update

---

## Risks / Notes

| Risk | Mitigation |
|---|---|
| SSH tunnel crate choice | `russh` (pure Rust) choose karo, `ssh2` me native deps hain |
| `sqlx::query!` build-time DB requirement | runtime queries use karo |
| Connection Manager scope creep | M5.1 → M5.4 tak hi MVP; SSH tunnel last |
| Auth Part 1 vs Part 3 overlap | mechanics Part 1, policies/negative tests Part 3 |
| Identifier injection | allowlist + `quote_ident` style escaping, bind params sirf values ke liye |

## Effort summary

| Milestone | Days |
|---|---|
| M0 Compile baseline | 2–3 |
| M1 Schema complete | 2 |
| M2 API Gateway | 3–4 |
| M3 Auth | 4–5 |
| M4 Projects | 3 |
| M5 Connection Manager | 12–18 |
| M6 Database Engine | 5 |
| M7 Schema Manager | 7–10 |
| M8 CRUD/Query/Txn | 8–10 |
| M9 Permissions/Audit | 5 |
| **Total** | **~55–70 working days** |
