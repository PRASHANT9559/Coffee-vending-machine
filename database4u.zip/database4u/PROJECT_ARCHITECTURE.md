# Database Manager — Project Architecture

> Centralized Database & File Management Platform
> Rust + PostgreSQL + Axum backend on VPS, controlled by a lightweight Slint desktop client.

---

## 1. Overview

### 1.1 Purpose

A single control plane that manages the PostgreSQL databases **and** user-uploaded files
(images, videos, documents) of every project hosted on the VPS — from one place, with
one login, and with strict per-project isolation.

It is a **platform**, not a one-off app: the same backend serves the Omniconverter,
ImgForge, E-commerce, SaaS, Vending Machine (IoT) and any future project.

### 1.2 Product Principles

| Principle | Consequence |
|---|---|
| Thin client | The Slint app is UI + API client only. No direct DB access, no filesystem access, no raw storage keys. |
| Backend is the single control point | All credentials, authorization, and storage operations live in the Rust backend. |
| Modest UI | Forms, selects, buttons, lists, status text. No charts, no heavy visualizations. |
| Default-deny | Every authorization check fails closed. |
| Secrets never leak | Passwords, tokens, private keys and signed URLs are never stored in plaintext, logged, or returned by list/detail APIs. |
| Measure, don't guess | No hardcoded performance promises. Pool limits, chunk sizes and timeouts are benchmarked and configurable. |

### 1.3 Scope — Six-Part Roadmap

| Part | Title | Core responsibility |
|---|---|---|
| 1 | Core Backend & Database Management | Rust modules, PostgreSQL connections, CRUD, schema, query engine, transactions, audit |
| 2 | File Storage & Upload System | Uploads, downloads, storage adapters, metadata, quotas, lifecycle cleanup |
| 3 | Security & Access Control | Authentication, project isolation, RBAC, file ACLs, audit of privileged actions |
| 4 | Slint Desktop Manager | Lightweight control panel: database explorer + file manager |
| 5 | VPS Deployment & Storage Infrastructure | Disk layout, backups, HTTPS, reverse proxy, operations |
| 6 | Realtime, Performance & Scaling | WebSocket events, streaming, resumable uploads, scoped caching, scaling stages |

### 1.4 Architecture Style

**Modular Monolith** — a single Rust application with clearly separated, independently
testable modules. Not microservices. Rationale: lower RAM, deployment and maintenance
overhead, while preserving clean module boundaries. A module becomes a separate service
only if measurement proves a need for it.

### 1.5 Out of Scope (deliberately excluded)

- Chart / graph rendering in the UI
- Arbitrary shell command execution from the backend
- OS-level service control (PostgreSQL start/stop) — belongs to a separate privileged subsystem
- Micro-partitioning the backend into microservices at launch
- Storing file bytes (images/videos) as binary blobs in PostgreSQL

---

## 2. System Architecture

### 2.1 Component Topology

```
┌──────────────────────────────────────────────────────────┐
│  Slint Desktop Client  (user's PC)                       │
│  Login · Project Selector · Database Explorer · File Mgr  │
└───────────────────────────┬──────────────────────────────┘
                            │ HTTPS / REST (JSON)
                            ▼
┌──────────────────────────────────────────────────────────┐
│  Reverse Proxy  (Caddy / Nginx)  — TLS termination       │
└───────────────────────────┬──────────────────────────────┘
                            ▼
┌──────────────────────────────────────────────────────────┐
│  Rust Backend (Axum) — Modular Monolith                  │
│  ┌────────────────────────────────────────────────────┐  │
│  │ API Gateway │ Auth │ Permissions │ Audit           │  │
│  ├────────────────────────────────────────────────────┤  │
│  │ Connection Manager    │  File Storage Module      │  │
│  │ Database Engine       │  Schema / CRUD / Query    │  │
│  │ Transaction Manager   │  Realtime Event Manager   │  │
│  └────────────────────────────────────────────────────┘  │
└──────────┬──────────────────────────────┬───────────────┘
           ▼                              ▼
   ┌───────────────────┐        ┌──────────────────────────┐
   │ PostgreSQL        │        │ Private File Storage     │
   │ • manager_core    │        │ VPS disk  →  S3-compatible│
   │ • project DBs     │        │ (opaque storage keys)    │
   └───────────────────┘        └──────────────────────────┘
```

### 2.2 Backend Module Map (Part 1)

```
Rust Application
├── 01  API Gateway            request routing, validation, auth middleware,
│                              rate limiting, consistent JSON responses
├── 02  Authentication & Session Manager   login, tokens, sessions, revocation
├── 03  Project Manager        project registry, membership, DB mapping
├── 04  Connection Manager     PostgreSQL pools, credentials, health, reconnect
├── 05  Database Engine        list / create / rename / drop databases
├── 06  Schema Manager         tables, columns, indexes, constraints, views
├── 07  Record / CRUD Engine   read, insert, update, delete, bulk, pagination
├── 08  Query Engine           SQL execution, timeout, read-only mode
├── 09  Permission Engine      RBAC + project/connection-level access control
├── 10 Transaction Manager     multi-statement commit / rollback
├── 11 Audit & Activity Logger operation history, sanitized
└── 12 Realtime Event Manager  LISTEN/NOTIFY → WebSocket events
```

> Part 3 (Security & Access Control) is the **shared authorization layer** that
> Modules 02 and 09 implement and all other modules call into. It is not a 13th
> module — it is the enforcement contract behind 02 + 09.

### 2.3 Data Separation

`manager_core` holds the platform's own control data and is fully isolated from
application data:

| Database | Holds |
|---|---|
| `manager_core` | Users, sessions, projects, connection profiles, credentials, permissions, file metadata, audit logs |
| `ecommerce_db` | Customer data |
| `converter_db` | Application data (Omniconverter) |
| `imgforge_db` | Application data (ImgForge) |
| `vending_db` | IoT data |
| `saas_db` | SaaS data |

A project may have one **or many** databases. Project and Database are separate entities.

---

## 3. Technology Stack

### 3.1 Backend

| Technology / Crate | Purpose |
|---|---|
| Rust | Core language |
| Tokio | Async runtime |
| Axum | REST API server |
| SQLx | PostgreSQL driver + connection pool |
| Serde / Serde JSON | Request & response serialization |
| UUID | Project and resource identifiers |
| Chrono | Dates and timestamps |
| Argon2 | Password hashing |
| SHA-256 | Fingerprints and checksums |
| ChaCha20-Poly1305 (XChaCha20) | Credential encryption at rest (192-bit nonce, software fast) |
| `secrecy` | Safe handling of secret values |
| `zeroize` | Sensitive memory cleanup |
| `validator` | Input validation |
| `tracing` / `tracing-subscriber` | Structured logging and collection |
| `thiserror` | Typed application errors |
| `anyhow` | Internal error context |
| `tower-http` | HTTP middleware |
| `governor` | Rate limiting |
| `moka` | Optional in-memory caching |
| `rustls` | TLS support |
| `utoipa` | Optional OpenAPI documentation |

**ORM decision:** SQLx only. Diesel / SeaORM are not introduced at launch — SQLx gives
explicit control over pooling, transactions and query timeouts, which this workload needs.

### 3.2 Client

| Technology | Purpose |
|---|---|
| Slint | Native desktop UI, Rust ↔ UI binding |
| HTTPS/REST client | All backend interaction |

### 3.3 Infrastructure

| Technology | Purpose |
|---|---|
| PostgreSQL | Control plane DB + all registered project databases |
| Caddy / Nginx | Reverse proxy, TLS termination, certificate renewal |
| systemd | Backend service management |
| VPS disk | Private file storage (Phase 1) |
| S3-compatible storage | Object storage adapter (future) |

### 3.4 Explicitly Excluded

- Axum + WebSocket are **not** required for a desktop-only client, but both are
  mandatory here because the backend is hosted on a VPS and reached over the network.
- Diesel / SeaORM — see above.
- ORM-based query building for identifiers — identifiers are validated, not parameterized.

---

## 4. Management Database (`manager_core`)

### 4.1 Core Tables

| Table | Purpose |
|---|---|
| `users` | Platform users |
| `sessions` | Login sessions |
| `refresh_tokens` | Rotating refresh tokens |
| `projects` | Registered projects |
| `project_members` | User ↔ project membership |
| `roles` | Role definitions |
| `permissions` | Permission definitions |
| `role_permissions` | Role ↔ permission mapping |
| `project_member_roles` | Member ↔ role mapping |
| `connections` | PostgreSQL server connection profiles |
| `connection_credentials` | Encrypted credentials |
| `connection_ssl_configs` | TLS configurations |
| `connection_ssh_configs` | SSH tunnel configurations |
| `connection_projects` | Connection ↔ project mapping |
| `connection_databases` | Registered database targets |
| `connection_pool_policies` | Per-database pool policy |
| `connection_health_logs` | Health check history |
| `connection_events` | Connection state events |
| `connection_access` | Connection-level permissions |
| `files` | File metadata |
| `upload_sessions` | In-flight upload state |
| `file_permissions` | File-level ACL |
| `file_versions` | Optional file versioning |
| `file_events` | File audit trail |
| `file_storage_usage` | Project/user quota accounting |
| `audit_logs` | Operation history |
| `system_settings` | Global settings |
| `schema_snapshots` | Optional schema history |

### 4.2 Connection Manager tables (detail)

```
connections
connection_credentials
connection_ssl_configs
connection_ssh_configs
connection_projects
connection_databases
connection_pool_policies
connection_health_logs
connection_events
connection_access
```

> **Pool objects are runtime resources and are never serialized into the database.**
> The DB stores only the policy and operational metadata; pools are created and
> evicted in memory.

### 4.3 Credential Storage Rules

- Connection passwords, SSH private keys and the encryption key are stored as
  **separate secrets**. Never in the same field.
- The `connections` table holds only a `credential_id` reference — never a password.
- The XChaCha20-Poly1305 master encryption key lives **outside the database**, in a separate VPS
  secret source or protected secret store.
- PostgreSQL application users must **not** be superusers. Each project gets an
  account with minimum necessary privileges.

### 4.4 File Metadata Model

| Field | Purpose |
|---|---|
| `file_id` | Unique file identifier |
| `project_id` | Project ownership |
| `owner_user_id` | Uploading user |
| `original_name` | User-supplied filename |
| `storage_key` | Internal opaque storage reference |
| `media_type` | Validated MIME type |
| `extension` | Normalized extension |
| `size_bytes` | Stored file size |
| `checksum` | Integrity verification hash |
| `storage_provider` | `local` or configured provider |
| `status` | `uploading` / `scanning` / `ready` / `deleted` |
| `created_at` | Upload time |
| `deleted_at` | Soft-delete timestamp |

Separate tables: `upload_sessions`, `file_permissions`, `file_versions`,
`file_events`, `file_storage_usage`.

---

## 5. Source Layout

### 5.1 Backend

```
database-manager/
├── Cargo.toml
├── Cargo.lock
├── .env.example
│
├── migrations/
│   ├── 001_users.sql
│   ├── 002_sessions.sql
│   ├── 003_projects.sql
│   ├── 004_connections.sql
│   ├── 005_database_registry.sql
│   ├── 006_permissions.sql
│   └── 007_audit_logs.sql
│
├── src/
│   ├── main.rs
│   ├── lib.rs
│   │
│   ├── config/
│   │   ├── mod.rs
│   │   ├── environment.rs
│   │   └── settings.rs
│   │
│   ├── api/
│   │   ├── mod.rs
│   │   ├── routes.rs
│   │   ├── middleware.rs
│   │   └── response.rs
│   │
│   ├── auth/            users/  projects/  connections/  databases/
│   ├── schema/          records/  queries/  permissions/  transactions/
│   ├── audit/           realtime/
│   │
│   ├── infrastructure/
│   │   ├── postgres/
│   │   │   ├── pool.rs
│   │   │   ├── connection.rs
│   │   │   └── health.rs
│   │   ├── encryption/
│   │   └── logging/
│   │
│   ├── common/
│   │   ├── errors.rs
│   │   ├── types.rs
│   │   └── validation.rs
│   │
│   └── tests/
│       ├── auth_tests.rs
│       ├── connection_tests.rs
│       ├── database_tests.rs
│       └── crud_tests.rs
│
└── docs/
    ├── architecture.md
    ├── api.md
    └── security.md
```

> Feature-based layout so each module can be developed and tested independently.
> A feature folder may later hold `mod.rs`, `service.rs`, `repository.rs`, `dto.rs`,
> `models.rs` — create them as needed, not upfront. Guideline of 300–500 lines per file,
> but never split code artificially just to hit a line count.

### 5.2 Connection Manager (`src/connections/`)

```
src/connections/
├── mod.rs
├── controller.rs
├── service.rs
├── repository.rs
├── models.rs
├── dto.rs
├── registry/          create.rs  update.rs  delete.rs
├── config/            postgres.rs  ssl.rs  validation.rs
├── credentials/       encryption.rs  decryption.rs  vault.rs  rotation.rs
├── network/           resolver.rs  connector.rs  tunnel.rs  security.rs
│                      direct_tls.rs  ssh_tunnel.rs
├── testing/           dns.rs  tcp.rs  tls.rs  authentication.rs  permissions.rs
├── pool_budget/
├── pool/              manager.rs  factory.rs  lifecycle.rs  eviction.rs  limits.rs
├── lifecycle/
├── health/            monitor.rs  checker.rs
├── reconnect/         retry.rs  backoff.rs
├── state/             machine.rs
├── isolation/         access.rs
├── metrics/           collector.rs
├── audit/
└── tests/             registry_tests.rs  pool_tests.rs  security_tests.rs
                       reconnect_tests.rs  integration_tests.rs
```

### 5.3 File Storage (`src/files/`)

```
src/files/
├── mod.rs
├── api/
├── metadata/
├── upload/            sessions.rs  multipart.rs  resumable.rs
├── validation/
├── storage/           adapter.rs  local_disk.rs  object_store.rs
├── download/
├── permissions/
├── quotas/
├── lifecycle/
├── cleanup/
├── audit/
└── metrics/
```

### 5.4 Security (`src/security/`)

```
src/security/
├── mod.rs
├── auth/              login.rs  tokens.rs  sessions.rs  password_reset.rs
├── users/
├── projects/          membership.rs  isolation.rs
├── roles/
├── permissions/       policy.rs  enforcement.rs
├── files/             acl.rs  sharing.rs
├── rate_limit/
├── audit/
└── security_events/
```

### 5.5 Slint Client (`desktop_manager/`)

```
desktop_manager/
├── src/
│   ├── main.rs
│   ├── app_state.rs
│   ├── api_client/
│   ├── auth/
│   ├── navigation/
│   ├── database_explorer/
│   ├── file_manager/
│   ├── uploads/
│   ├── components/
│   └── error_handling/
├── ui/
│   ├── app.slint
│   ├── login.slint
│   ├── shell.slint
│   ├── database_explorer.slint
│   ├── file_manager.slint
│   └── components/
└── tests/
```

---

## 6. API Blueprint

Base prefix: `/api/v1`

### 6.1 Core Endpoints

| Endpoint | Method | Purpose |
|---|---|---|
| `/auth/login` | POST | Login |
| `/auth/refresh` | POST | Refresh access token |
| `/auth/logout` | POST | Logout |
| `/auth/password-reset/request` | POST | Request password reset |
| `/auth/password-reset/confirm` | POST | Confirm password reset |
| `/projects` | GET | Projects list |
| `/projects` | POST | Create project |
| `/projects/{id}` | GET | Project details |
| `/projects/{project_id}/members` | GET / POST | List / add members |
| `/projects/{project_id}/members/{user_id}` | PATCH / DELETE | Update / remove member |
| `/projects/{project_id}/permissions` | GET | Project permissions |
| `/connections` | GET / POST | List / create profiles |
| `/connections/{id}` | GET / PATCH / DELETE | Read / update / delete profile |
| `/connections/{id}/test` | POST | Test connection (temporary, no pool) |
| `/connections/{id}/connect` | POST | Initialize persistent pool |
| `/connections/{id}/disconnect` | POST | Drain / close pool |
| `/connections/{id}/reconnect` | POST | Manual reconnect |
| `/connections/{id}/health` | GET | Health status |
| `/connections/{id}/metrics` | GET | Performance data |
| `/connections/{id}/databases` | GET | Database targets |
| `/databases` | GET / POST | List / create database |
| `/databases/{id}` | GET | Database details |
| `/databases/{id}/tables` | GET | Tables list |
| `/tables` | POST | Create table |
| `/tables/{id}/columns` | GET | Columns list |
| `/tables/{id}/records` | GET | Fetch records |
| `/records` | POST | Insert record |
| `/records/{id}` | PATCH / DELETE | Update / delete record |
| `/queries/execute` | POST | Execute SQL |
| `/files/upload-sessions` | POST | Create upload session |
| `/files/upload-sessions/{id}` | GET | Session status |
| `/files/upload-sessions/{id}/complete` | POST | Finalize upload |
| `/files/upload-sessions/{id}` | DELETE | Abort session |
| `/files` | GET | List files |
| `/files/{file_id}` | GET / DELETE | File details / delete |
| `/files/{file_id}/download` | GET | Controlled download |
| `/files/{file_id}/permissions` | GET / PUT | File ACL |
| `/files/{file_id}/permissions/{subject_id}` | DELETE | Revoke ACL entry |
| `/audit` | GET | Activity history |

### 6.2 API Conventions

- Pagination, filtering, sorting and structured error responses on all relevant endpoints.
- Database and table IDs resolve to the correct connection and project context.
- **Credentials are accepted only in create/update requests.** List and detail
  responses never return secrets.
- Error responses must not reveal the existence of another project's resources.
- Chunk endpoints and upload-session token formats are defined separately for
  large/resumable uploads.
- The API never returns filesystem paths or raw storage keys to the client.

---

## 7. End-to-End Workflows

### 7.1 Operator Flow (login → operate)

```
Login
  └─ Slint app authenticates to the VPS backend
      └─ Dashboard: backend returns registered projects
          └─ Select Project
              └─ Select Connection  (PostgreSQL server)
                  └─ Select Database  (Database Engine)
                      └─ Select Table  (Schema Manager: tables + columns)
                          └─ Perform Operation  (read / insert / update / delete / schema change)
                              └─ Audit & Response  (result + activity history)
```

### 7.2 Connection Lifecycle

```
New Connection
  1. Slint sends Add Connection request
  2. API Gateway validates the request
  3. Connection Registry prepares the profile
  4. Credential Manager encrypts the password
  5. Connection Tester verifies the server
  6. Project ↔ database mapping is verified
  7. Profile is persisted to the registry
  8. On database selection, Pool Manager lazily creates the pool
  9. Health Monitor and State Manager track it from here
→ Connection Ready
```

**Runtime request path:**

```
Slint Request → Authentication → Project Permission → Connection Registry
              → Pool Manager → SQLx Connection Pool → PostgreSQL
              → Result / Error → Slint UI
```

### 7.3 Upload Workflow

```
1. Client sends an authenticated upload request
2. Backend checks user, project permission, quota and file-size policy
3. Upload session is created; temporary storage key is allocated
4. Client uploads the file in chunks or as a stream
5. Backend validates size limit, MIME/signature and checksum
6. Optional malware scan / quarantine step runs
7. File is committed from the temporary area to final storage
8. PostgreSQL metadata is updated to `ready`
9. Client receives `file_id` and sanitized metadata
```

- Incomplete uploads are removed by a session-expiry cleanup worker.
- Final metadata is published **only after** the storage write succeeds.

### 7.4 Download Workflow

```
1. Client requests a download for `file_id`
2. Backend checks user / project / file permissions
3. Backend verifies the file is in `ready` state
4. Backend returns a controlled stream or a short-lived signed URL
5. Download event and metrics are recorded
```

### 7.5 Upload / Download Modes

| Case | Mode |
|---|---|
| Small files | Direct authenticated multipart upload |
| Large files | Resumable / chunked upload — survives network interruption without restarting |
| Object storage (future) | Short-lived signed upload URLs |
| Large video downloads | HTTP range requests for client-side resume/seek |

### 7.6 Transaction Workflow

Used whenever one operation needs multiple SQL statements:

```
BEGIN TRANSACTION
  1. Update product stock
  2. Create order
  3. Insert payment record
COMMIT
```

On any step failure → `ROLLBACK`, preventing partially applied updates.

### 7.7 Audit Recording

Every significant operation records: User ID, Project ID, Connection ID, Operation Type,
Timestamp, Success/Failure, Execution Duration, Request ID.

Passwords, tokens and other secrets never appear in logs.

---

## 8. Part 1 — Core Backend & Database Management

### 8.1 Module Responsibilities

| Module | Responsibility |
|---|---|
| `project` | Project registry, membership, project ↔ database mapping |
| `connection` | Create, close and reconnect PostgreSQL connections |
| `database` | Database list and details |
| `table` | Create tables, inspect columns, alter schema |
| `records` | Read, insert, update and delete data |
| `query` | Safe SQL execution and result handling |
| `permissions` | User permissions and blocking of dangerous operations |
| `realtime` | Change notifications and UI updates |
| `error` | Uniform handling of all errors |

### 8.2 Module 03 — Project Manager

Every project has its own identity (a UUID) and its own name — e.g. Omniconverter,
ImgForge, E-commerce, Vending Machine.

**Operations:** create, rename, delete, archive project; project details; project status;
project ↔ database mapping; project-level permissions.

> A Project and a Database are separate entities — one project may own one database or
> many.

### 8.3 Module 05 — Database Engine

**Operations:** list, create, details, rename, refresh, drop, owner, permissions.

**Additional information:** database size, encoding, collation, owner, active connections,
creation time (where available).

**Safety:** `DROP DATABASE` and rename are never executed without an active-connection
check and a permission check.

### 8.4 Module 06 — Schema Manager

| Category | Operations |
|---|---|
| Tables | Create, rename, drop |
| Columns | Add, rename, alter, drop |
| Indexes | Create, list, drop |
| Constraints | Primary key, foreign key, unique, check |
| Relations | Foreign key relationships |
| Views | Create, list, drop |
| Sequences | List, inspect, manage |

Includes a Schema Inspector showing the full structure of a table, and a tree view:

```
Database: ecommerce_db
    ├── users
    ├── products
    ├── orders
    ├── payments
    └── inventory
```

Backed by `information_schema` and PostgreSQL's `pg_catalog`.

### 8.5 Module 07 — Record / CRUD Engine

Fetch, insert, update, delete, bulk insert, bulk update, pagination, sorting, filtering,
search, NULL handling, data type validation.

**Never send hundreds of thousands of rows to the UI at once.** Use:

```
Page: 1
Limit: 100
Sort: created_at
Order: DESC
```

This keeps both memory and network under control.

### 8.6 Module 08 — Query Engine

Features: SQL execution, query timeout, result pagination, query validation, execution
status, rows affected, query duration, error details, read-only mode, transaction support.

**Critical distinction:**

- **Normal CRUD** → safe parameterized queries.
- **Custom SQL** → a separate console, restricted to authorized users only.

> SQL identifiers (table names, column names, database names) **cannot** be bound as
> ordinary parameters. They require allowlisting and safe identifier construction.
> Never concatenate user input into a SQL string.

### 8.7 Module 10 — Transaction Manager

Commits or rolls back multi-statement operations as a single unit (see §7.6).

### 8.8 Module 12 — Realtime Event Manager

```
Database Updated
      ↓
Rust Event Manager
      ↓
WebSocket
      ↓
Slint Client
      ↓
Refresh Current View
```

> PostgreSQL `NOTIFY` is **not** a complete change-data-capture system. Per-table
> triggers and a deliberate event payload design are required.

---

## 9. Part 1 — Connection Manager (Deep Specification)

### 9.1 Purpose and Boundaries

The Connection Manager is the backend subsystem that creates, tests, pools, monitors and
closes connections to PostgreSQL servers and their databases.

**Main constraint:** the Slint desktop client never connects to PostgreSQL directly. It
sends requests to the Rust backend over authenticated HTTPS. The backend owns connection
credentials and database access.

The Connection Manager does **not** own database schema or record business logic — it
provides managed database connections to the other modules.

### 9.2 Architectural Decisions (final)

| Decision | Choice |
|---|---|
| PostgreSQL scope | **Both** — local and remote |
| Pool strategy | **Hybrid** — server-level budgets + database-specific lazy pools |
| Network connectivity | **Both** — direct TCP/TLS and SSH tunnel |

### 9.3 Core Concepts

| Concept | Meaning |
|---|---|
| **Server profile** | How to reach a PostgreSQL instance (host, port, TLS, auth) |
| **Database target** | A specific database on that instance |
| **Connection pool** | Reusable connections for one database target |

```
Rust Connection Manager  (central connection controller)
├── Server Profile: Main VPS   — host · port · SSL · credentials
│     ├── converter_db      → Pool
│     ├── imgforge_db       → Pool
│     ├── ecommerce_db      → Pool
│     └── manager_core      → Pool
└── PostgreSQL Server  — actual database operations
```

One server profile can expose many databases, but **each database gets its own pool, and
every pool is created lazily** — only when an operation actually needs that database.

### 9.4 Connection Architecture

```
Slint Desktop Client
        │ HTTPS / REST
        ▼
Rust API Gateway
        │ Authentication + Authorization
        ▼
Connection Manager
        ├── Connection Registry
        ├── Config & Credential Manager
        ├── Network Connector
        │     ├── Direct TCP + TLS
        │     └── SSH Tunnel
        ├── Connection Tester
        ├── Pool Budget Manager
        ├── Database Pool Manager
        ├── Health & State Manager
        └── Metrics + Audit Events
                    │
                    ▼
             PostgreSQL
          Local and Remote
```

### 9.5 Modules

| Module | Responsibility |
|---|---|
| `registry` | Lifecycle of server profiles and database targets |
| `config` | Validation of host, port, TLS mode, timeouts, route settings |
| `credentials` | Encrypted storage, retrieval and rotation of credentials |
| `network` | DNS, TCP, TLS and SSH tunnel setup/teardown |
| `testing` | Connection test without creating a persistent pool |
| `pool_budget` | Global and per-server connection limits |
| `pool` | Creating and acquiring/releasing database-specific SQLx pools |
| `lifecycle` | Pool create, drain, close, evict, recreate |
| `health` | Connectivity and pool usability checks |
| `reconnect` | Backoff, retry limits, manual reconnect |
| `state` | Authoritative tracking of connection and pool states |
| `isolation` | User, project and database target permission checks |
| `metrics` | Pool usage, latency, failures, reconnect metrics |
| `audit` | Audit trail for sensitive operations and configuration changes |

### 9.6 Connection Profile & Configuration

**Server profile fields:**

```
connection_id
display_name
scope                  // local | remote
host
port
username
credential_id
network_mode           // direct_tls | ssh_tunnel
tls_mode
connect_timeout
acquire_timeout
idle_timeout
max_lifetime
enabled
created_at
updated_at
```

**Database target fields:**

```
database_target_id
connection_id
database_name
pool_policy_id
enabled
last_discovered_at
```

> `database_name` and other SQL identifiers are **not** bind parameters. They go
> through validated identifier handling.

**Configuration types:**

| Type | Settings |
|---|---|
| Local PostgreSQL | `127.0.0.1:5432`, database `postgres` |
| Remote PostgreSQL | `db.example.com:5432`, SSL required |
| Private network | `10.0.0.10:5432` |
| SSH tunnel | local port `15432` → remote `127.0.0.1:5432` via `server.example.com` |

For SSH tunnels a dedicated tunnel component is used; SQLx connects to the tunnel's
local endpoint.

**TLS modes:**

| Mode | Use |
|---|---|
| `Disable` | Trusted local environments only |
| `Require` | TLS encryption, no verification |
| `Verify CA` | Certificate authority verified |
| `Verify Full` | CA **and** hostname verified |

**Recommendation:** remote production connections default to `Verify Full`. For
self-signed certificates, configure a trusted CA — disabling certificate verification
is not an acceptable general solution.

### 9.7 Credential Manager

Responsibilities: password encryption, credential storage, credential rotation, password
update, secret retrieval, secret deletion, access auditing, encryption key management.

```
Encrypted Credential Storage
      ▲
Credential Manager (authorization check)
      ▲
Encryption / Decryption (XChaCha20-Poly1305)
      ▲
Connection Manager (temporary access to secret)
```

Rules:
- Authenticated encryption (XChaCha20-Poly1305 with 192-bit nonce).
- The encryption key is kept on the VPS, separate from the database.
- Key rotation is supported.
- Passwords are never shown in logs or API responses.
- Secrets reach only the authorized backend component.
- Credentials are not retained in memory longer than necessary.
- The PostgreSQL application user must never be a superuser — use minimum-privilege
  accounts per project.

### 9.8 Connection Tester

```
Host format validation
  → DNS resolution
    → TCP connectivity test
      → TLS certificate verification
        → PostgreSQL authentication
          → Database access verification
            → Permission verification
              → Connection latency measurement
```

Result reports success/failure per stage, elapsed time and sanitized errors.
**The test uses a temporary connection and closes it afterwards — it never creates a
permanent pool.**

### 9.9 Pool Manager

```
Connection Pool
       |
       ├── Connection 01
       ├── Connection 02
       ├── Connection 03
       ├── Connection 04
       └── Connection 05
```

Request flow: acquire a connection from the pool → execute the query → return the
connection to the pool → the next request reuses it.

**Initial configuration (to be tuned after benchmarking):**

| Setting | Initial value |
|---|---|
| Max connections / pool | 5 |
| Min connections / pool | 0 |
| Acquire timeout | 5 seconds |
| Connect timeout | 5 seconds |
| Idle timeout | 5 minutes |
| Max lifetime | 30 minutes |

**The most important decision:** with 20 databases, creating 20 pools that each reserve
5 connections is wrong. Instead:

- Lazy pool creation
- Bounded total pool count
- Per-server **and** global connection budgets
- Idle pool eviction
- **No eviction while an operation is active**
- Recreate pools on demand

```
Global Connection Budget: 30

Main VPS
  ├── ecommerce_db: 5 max
  ├── converter_db: 5 max
  └── imgforge_db: 5 max
Remote VPS
  ├── saas_db: 5 max
  └── vending_db: 5 max
```

The global budget is a ceiling — actual concurrent connections may be lower. Each
PostgreSQL server's own `max_connections` limit must also be respected.

### 9.10 Pool Lifecycle

| Operation | Purpose |
|---|---|
| Create Pool | New database pool |
| Acquire | Take a connection from the pool |
| Release | Return the connection |
| Close Pool | Close the pool |
| Evict Pool | Remove an idle pool |
| Recreate Pool | New pool after a configuration change |
| Drain Pool | Block new requests, finish active work |

```
Pool Created → Active → Idle → Idle Timeout → Eviction
```

A connection inside an active transaction must never be terminated abruptly.
When a password or server configuration changes, the old pool is drained and a new pool
is created from the new configuration.

**Pool state machine:**

```
Uninitialized → Creating → Ready → Draining → Closed
```

On failure or network loss a pool may move to `Unhealthy` or `Failed`.

**Pool budget policy:**
- Global, server-level and database-level limits are separate configuration scopes.
- A budget reservation is required before a pool is created.
- When the budget is exhausted, requests are rejected or queued in a controlled way —
  unlimited pools are never created.
- Idle eviction only touches pools with no active operations.
- On close: block new acquisitions, give active operations a bounded grace period,
  then close.
- Limits must be tuned against measured workload and PostgreSQL capacity — no fixed
  limit is correct for every deployment.

### 9.11 Health Monitor

Checks: server reachability, PostgreSQL responsiveness, authentication validity, pool
acquire success, connections in use, idle connections, requests waiting, and the last
successful health check timestamp.

> Polling every database every few seconds creates unnecessary load. Use configurable
> intervals and lightweight checks.

### 9.12 Reconnection Manager

```
Connection Lost
      ↓
Failure Detected
      ↓
Check Configuration
      ↓
Retry Delay
      ↓
Reconnect Attempt
      ↓
Success / Failed
```

Strategy: exponential backoff, random jitter, maximum retry limit, configurable retry
interval, manual reconnect, automatic reconnect. Concurrent reconnect attempts during a
reconnect loop are blocked in a single-flight manner, so only one attempt runs at a time.

| Attempt | Retry delay |
|---|---|
| 1 | 1 second |
| 2 | 2 seconds |
| 3 | 4 seconds |
| 4 | 8 seconds |
| 5 | 16 seconds |

(This is a schedule illustration — jitter and a maximum delay are also applied.)

> **Never blindly re-execute a failed SQL transaction.** When a connection drops it may
> be unknown whether the transaction committed. Verify the operation result instead.

### 9.13 Connection State Model

```
Registered → Connecting → Connected → Disconnected
                     ↓          ↓
                  Degraded   Reconnecting → Failed
                     ↓
                  Disabled / Closing
```

| State | Meaning |
|---|---|
| `Registered` | Profile is saved |
| `Connecting` | Connection being established |
| `Connected` | Connection successful |
| `Disconnected` | Currently not connected |
| `Degraded` | Connected but with problems |
| `Reconnecting` | Reconnecting in progress |
| `Failed` | Connection failed |
| `Disabled` | Disabled by admin |
| `Closing` | Pool is closing |

> `Connected` means the pool is **available for use** — not that a physical TCP
> connection is active at that instant. A lazy pool can be ready with no live physical
> connection.

### 9.14 Network Manager

Handles: DNS resolver, TCP connector, TLS handshake, certificate verification,
SSH tunnel, connection timeout, network failure detection, proxy support (if needed).

**Security:** because the manager can reach external databases, connection creation must
be protected against SSRF and network abuse:

- Block access to arbitrary metadata endpoints
- Private IP access only under explicitly authorized configuration
- Validate the destination IP **after** DNS resolution
- Guard against DNS rebinding
- Audit all connection destinations

Private IP connections remain allowed for the platform's own VPS and private-network
databases — but unrestricted network access is not.

### 9.15 Connection Isolation

```
Project A
  └── ecommerce_connection
        └── ecommerce_db
Project B
  └── converter_connection
        └── converter_db
```

Knowing a UUID must never grant access to another project's connection.

**Every request is checked in this order:**

1. User authentication
2. Project permission
3. Connection permission
4. Database mapping verification
5. Operation authorization

### 9.16 Connection Metrics

| Metric | Meaning |
|---|---|
| Total Profiles | Registered connections |
| Active Pools | Current pools |
| Active Connections | Connections in use |
| Idle Connections | Free connections |
| Failed Connections | Failed connection attempts |
| Average Latency | Average connection latency |
| Pool Wait Time | Time spent waiting for a connection |
| Reconnect Count | Reconnection attempts |

These are displayed as plain text and tables — charts are not required.

### 9.17 Connection Manager API

```
POST   /connections
GET    /connections
GET    /connections/{id}
PATCH  /connections/{id}
DELETE /connections/{id}
POST   /connections/{id}/test
POST   /connections/{id}/connect
POST   /connections/{id}/disconnect
POST   /connections/{id}/reconnect
GET    /connections/{id}/health
GET    /connections/{id}/metrics
GET    /connections/{id}/databases
```

> `/connect` means **initialize the persistent pool** — not "keep one TCP connection open
> forever".

---

## 10. Part 2 — File Storage & Upload System

### 10.1 Architecture

```
Slint Desktop Client / Future Web or Mobile Apps
                    │ HTTPS
                    ▼
              Rust API Gateway
                    │ Auth + Project Permissions
                    ▼
             File Storage Module
       ├── Upload Session Manager
       ├── Validation & File Inspection
       ├── Storage Adapter
       ├── Metadata Manager
       ├── Download / Access Manager
       ├── Lifecycle & Cleanup
       └── Audit + Metrics
                    │
          ┌─────────┴──────────┐
          ▼                    ▼
   PostgreSQL Metadata    File Storage
                         VPS Disk / S3-compatible
```

**The core boundary:** file content is never stored as large binary blobs in PostgreSQL.
The database holds metadata, ownership, storage key, status and access rules; the bytes
live in the storage layer.

### 10.2 Storage Backend

**Phase 1 — VPS disk.** A private storage directory. Files are **not** placed at paths
derived from the user-supplied filename; a server-generated opaque storage key is used:

```
/storage/
  └── <opaque-storage-key>
```

(Conceptual layout — actual paths come from deployment configuration.)

**Future — object storage.** Keep the adapter interface stable so S3-compatible storage
can be added later without redesigning the upload/download API:

```
StorageAdapter
├── put()
├── get()
├── delete()
├── exists()
└── get_metadata()
```

VPS disk and object storage sit behind one abstraction. The storage key and
provider-specific path are hidden from the client.

### 10.3 File Validation & Security

- A filename is never used as a path or as a storage key.
- File extension, declared MIME type and file signature are validated **separately**.
- File size limits, per-project storage quotas and concurrent upload limits are enforced.
- Uploads are stored in a non-executable location.
- If archive extraction is added, path traversal and decompression-bomb risks need
  dedicated handling.
- Private file access is authorized on **every** request — an obscure `file_id` is not
  an access control mechanism.
- Temporary upload tokens are short-lived and narrowly scoped.
- Logs contain no file contents, secrets or signed URLs.
- Backup and deletion policies apply to both metadata and actual file bytes.

### 10.4 File Lifecycle

```
Created → Uploading → Validating → Ready → Deleted
```

A session may become `Failed`. Deleted files are removed from physical storage after a
configured retention period. The cleanup job also detects mismatches between metadata
and storage state.

### 10.5 File Storage API

```
POST   /files/upload-sessions
POST   /files/upload-sessions/{id}/complete
GET    /files/upload-sessions/{id}
DELETE /files/upload-sessions/{id}

GET    /files
GET    /files/{file_id}
GET    /files/{file_id}/download
DELETE /files/{file_id}
```

---

## 11. Part 3 — Security & Access Control

### 11.1 Architecture

```
Slint / Web / Mobile Client
           │ HTTPS
           ▼
      Rust API Gateway
           │
     Authentication
           │
     Authorization
      ├── User & Session Manager
      ├── Project Membership
      ├── Role / Permission Engine
      ├── Resource Access Checks
      ├── File Permission Manager
      └── Audit & Security Events
              │
     ┌────────┴─────────┐
     ▼                  ▼
Connection Manager   File Storage Module
```

**Rule:** authentication establishes *who* the user is; authorization decides *what*
they may do to the requested resource. A valid login never implies project or file access.

### 11.2 Session Policy

- Stable `user_id` per user; the backend issues a session or token after verifying credentials.
- Access tokens are short-lived.
- Refresh tokens are rotated, with reuse detection.
- Multiple concurrent device sessions are supported per user.
- Logout, password reset and account disable can revoke active sessions.
- Passwords are hashed with **Argon2id**; plaintext is never stored.
- Login failures are rate-limited and logged as suspicious activity.
- Password reset tokens are random, short-lived, single-use and hashed at rest.

**Request flow:**

1. Validate token / session
2. Confirm the user is active, not disabled
3. Authorize the requested project and resource
4. Execute only if permission is granted
5. Write an audit event for sensitive actions

### 11.3 Project Isolation

Every project is a security boundary. A user may belong to many projects, but membership
in one never grants access to another.

**Core entities:**

```
users
projects
project_members
roles
permissions
role_permissions
project_member_roles
sessions
refresh_tokens
```

**Isolation rules:**
- Every project-owned resource carries a `project_id` — connections, database targets,
  files, upload sessions and audit events alike.
- Never trust the `project_id` sent in a request; verify membership server-side.
- Resource lookups always include project scope, so guessing an ID never exposes data.
- Cross-project access only via an explicit, audited administrative permission.
- Background jobs and cleanup workers also run with project-scoped authorization context.

### 11.4 Roles

| Role | Typical rights |
|---|---|
| `Owner` | Full project administration: settings, members, resources |
| `Admin` | Manage members and project resources; **no** ownership transfer |
| `Editor` | Create/update permitted resources |
| `Viewer` | Read-only access |
| `Custom` | A chosen combination of permissions |

> Role names alone are not enforcement. The backend must decide on **permission checks**
> such as `file.read`, `file.delete`, `connection.manage`, `project.members.manage`.

### 11.5 File Permissions

```
file.read
file.upload
file.update_metadata
file.download
file.delete
file.share
```

**Access decision on a file request:**

1. Resolve `file_id`
2. Read the file's `project_id` and owner
3. Check the user's project membership and role
4. Apply the file-specific ACL, if one exists
5. Deny access if the requested action is not permitted

> A hard-to-guess file ID is not an authorization alternative. Never create permanent
> public URLs for private files. If a signed download URL is used, it must be
> short-lived, bound to a specific file, and scoped to a specific operation.

**File sharing (future, outside the project):** model the share token as a separate
capability — random and unguessable, with expiry and revocation, read-only/download
scope, an optional download limit, only the token's hash stored, and an audit event.

### 11.6 Authorization Enforcement

One central policy interface, called by both API handlers and background jobs:

```
authorize(user, project, resource, action) → allow | deny
```

Policy evaluation covers at minimum: user status, project membership, role permissions,
resource ownership/ACL, and resource state.

- Default policy is **deny**.
- A failed permission check or a policy-service error fails the operation closed.
- Client-supplied role, owner ID or permission claims are never authoritative.
- Sensitive mutations use an appropriate transaction/locking strategy to avoid a race
  between resource fetch and authorization.

### 11.7 Security Events & Audit

Audit these actions:
- Login success/failure, logout, token revocation
- Project member and role changes
- File upload, download, share and delete
- Connection profile or credential changes
- Permission denials and privileged actions

Each audit record holds: actor, project, action, resource ID, timestamp, result.
Passwords, access tokens, refresh tokens, private keys and signed URLs are never logged.

---

## 12. Part 4 — Slint Desktop Manager

### 12.1 Architecture

```
Slint Desktop App
   ├── Login / Project Selector
   ├── Database Explorer
   ├── File Manager
   └── Connection & Upload Status
             │ HTTPS / REST
             ▼
        Rust API Backend
   ├── Security & Access Control
   ├── Connection Manager
   └── File Storage Module
             │
       ┌─────┴─────┐
       ▼           ▼
   PostgreSQL   File Storage
```

The Slint client is **UI + API client only**. The client is given no direct access to
the PostgreSQL port or the VPS filesystem.

### 12.2 UI Design Principles

- Simple control panel: forms, selects, buttons, lists and status text.
- No charts or heavy visualizations.
- Main content area shows the selected page; the sidebar holds navigation.
- Every action has loading, success and error states.
- Destructive actions (delete database target, delete file) require confirmation.
- Credential/password fields are masked; secrets are never written to logs or local config.

### 12.3 Navigation

```
Home
├── Projects
├── Database Explorer
│   ├── Connections
│   ├── Databases
│   ├── Tables
│   └── Table Details
├── File Manager
│   ├── Files
│   ├── Uploads
│   └── File Details
├── Activity / Audit
└── Settings
```

### 12.4 Database Explorer

**Connections list** — each row shows: display name, local/remote scope, direct-TLS or
SSH-tunnel route, and health/status. Available actions: Test, Connect, Disconnect, Edit.

Status text must be unambiguous — `Connected`, `Disconnected`, `Degraded`, `Failed`.
"Connected" means the backend pool is available, not that a physical connection is
active right now.

**Add / Edit connection form fields:** connection name, host and port, username,
password/credential input, database selection, network mode (Direct TLS / SSH tunnel),
TLS configuration.

The UI sends credentials only in a secure API request; backend validation and secret
storage remain the backend's responsibility.

**Database and table browsing flow:**

```
Project → Connection → Database → Tables → Table Details
```

**Table Details — initial scope:**
- Columns and data types
- Primary key and index information
- Read-only record preview
- Permission-aware refresh

> Table data edit/update belongs to a later phase. Read-only browsing first reduces the
> risk of accidental data modification. The SQL console is **not** on the default screen;
> if added later it needs its own permission, query limits and audit trail.

### 12.5 File Manager

**File list** — each row shows: original filename, type/category, size, upload time,
status. Actions: Download, Rename metadata, Delete. The list only shows authorized
project files; internal storage keys and filesystem paths are never displayed.

**Upload flow:**

```
Select Project → Select Files → Upload → Progress / Status → Complete or Error
```

The UI shows upload progress, failed state and a retry action. Large/resumable uploads
update from the backend upload-session status or the API response.

**File preview** — images and documents preview only after the backend access
authorization passes. For videos, the initial version provides download and basic
metadata; inline streaming/preview is a later phase.

### 12.6 Shared UI States

Every API-backed page has: `Loading`, `Empty`, `Ready`, `Error`, `PermissionDenied`.

On network failure the user gets an explicit retry action. The UI must not present stale
data as new — keep a refresh timestamp or status text.

---

## 13. Part 5 — VPS Deployment & Storage Infrastructure

### 13.1 Deployment Architecture

```
Slint Desktop Client
        │ HTTPS
        ▼
Reverse Proxy (Caddy / Nginx)
        │
        ▼
Rust Backend (Axum)
   ├── Security & Access Control
   ├── Connection Manager
   └── File Storage Module
        │
   ├── PostgreSQL — metadata and control data
   └── Private File Storage — uploaded bytes
```

**Deployment principle:** all public traffic enters through the HTTPS reverse proxy.
PostgreSQL and the private file-storage directory are never directly reachable from the
public internet.

### 13.2 VPS Disk Layout

```
/opt/database-manager/
├── app/          Rust backend + deployment configuration
├── data/
│   ├── postgres/ PostgreSQL data directory
│   ├── storage/  Private file storage
│   └── tmp/      Temporary upload area
├── logs/
└── backup/       Backup staging area (copy off-site)
```

- Uploaded files use server-generated storage keys inside private directories.
- Temporary uploads and completed files are kept separate.
- Scheduled jobs handle temporary-upload cleanup, deleted-file retention and log rotation.
- Available disk space and project quota are checked before an upload starts.
- Under disk pressure, uploads are rejected or paused in a controlled way — never write
  until the disk is full.
- PostgreSQL data and file storage capacity are monitored separately.

> **Important:** keeping backups on the same VPS disk gives no protection against disk
> failure. Backups must live in a separate storage location.

### 13.3 Backup & Restore

Two data classes are backed up separately:
1. **PostgreSQL** — users, projects, connection profiles, file metadata, permissions, audit records
2. **File storage** — actual uploaded images, videos and documents

**Backup policy:**
- Consistent database backups for PostgreSQL, plus point-in-time recovery where needed.
- Incremental or snapshot-based backups for file storage, per provider capabilities.
- Backup encryption and restricted access.
- Configurable retention policy.
- Track success/failure status and the last successful backup.
- Verify checksums/manifests on completion.

**Restore requirements:** the restore procedure is tested regularly. Database metadata and
files must be restored from compatible recovery points — otherwise metadata can point to
files that were not restored, or vice versa.

### 13.4 HTTPS & Network Exposure

- The reverse proxy handles TLS termination and certificate renewal.
- HTTP requests redirect to HTTPS.
- The backend service is never exposed on the public interface; traffic arrives via the
  reverse proxy over a private/local interface.
- The PostgreSQL port is kept away from public exposure; remote DB access uses an
  allowlisted network, TLS and least-privilege credentials.
- SSH access uses keys and restricted accounts; password-based public SSH access can be
  disabled per deployment policy.
- The firewall opens only the necessary inbound ports.
- TLS certificates, SSH keys and application secrets are never committed to source
  control or ordinary config files.

### 13.5 Deployment & Operations

- Run the Rust backend via a service manager or container runtime.
- Production config, secrets and persistent data live outside the application release.
- Validate configuration and check database migrations before deploying.
- Graceful shutdown: stop accepting new requests → drain active operations → exit.
- Health/readiness endpoints expose no secrets or sensitive infrastructure details.
- Logs carry request IDs and sanitized errors; tokens, passwords and signed URLs are redacted.
- Keep a rollback procedure and deployment version tracking.

### 13.6 Operational Monitoring

Minimum metric set:

- Disk usage and free space
- PostgreSQL availability and storage growth
- File storage size and upload failures
- CPU, memory and process health
- Backup age, duration and failure count
- HTTPS certificate expiry
- API error rate and latency

---

## 14. Part 6 — Realtime, Performance & Scaling

### 14.1 Realtime Architecture

```
Rust Backend
   ├── Upload / Connection / File Events
   ├── Event Publisher
   └── WebSocket Gateway
             │
             ▼
       Slint Desktop Client
```

- REST remains the primary interface for commands and resource operations.
- WebSocket carries live status and events only.
- On reconnect the client re-fetches current status from REST — WebSocket events are
  never the permanent source of truth.
- Events are verified for project/resource scope; another project's events never reach
  a client.
- A sequence ID or state-refresh mechanism handles missed events after a reconnect.

```
upload.progress
upload.completed
upload.failed
connection.state_changed
file.validation_completed
```

### 14.2 Upload Speed

Upload throughput is bounded by four limits: client, network, backend and storage.

- Small files: straightforward streamed upload.
- Large files: resumable / chunked upload.
- Chunks are staged in temporary storage and committed to the final file on completion.
- Per-user and per-project limits apply to concurrent uploads.
- Progress is reported over WebSocket or a periodic status API.
- Hash/checksum verification checks uploaded-content integrity.

> Chunk size, parallelism and concurrency limits are benchmarked against real workloads.
> One fixed configuration cannot be correct for every VPS, network and client.

### 14.3 Large Video Handling

- Never load a whole file into memory.
- Upload and download are streaming-based.
- Temporary disk usage and incomplete-upload cleanup are managed.
- Downloads support HTTP range requests so clients can resume and seek — implemented in
  the storage adapter and the response layer.
- File size, upload duration and per-project storage quota are configurable.
- Thumbnails/transcoding, if added, run in background workers and never block the API
  request. Transcoding stays an optional future capability — it is not required for
  basic file upload/download.

### 14.4 Caching

Caching is subordinate to correctness and privacy.

- Short-lived in-memory cache is useful for project, connection and file metadata.
- Permission-sensitive data is cached under a project/user scope key.
- Membership or permission changes invalidate the relevant cache entries.
- File content caching for private files stays off by default until an
  authorization-aware cache policy exists.
- On cache miss or cache failure, data is read from the authoritative
  PostgreSQL/storage source.

> **Caching is never a substitute for authorization.** Every sensitive request must
> still enforce permissions, even when the metadata is cached.

### 14.5 Performance Controls

- File streaming uses bounded buffers; whole files are never buffered in memory.
- Backpressure applies to slow clients.
- Upload/download concurrency and per-project bandwidth limits are configurable.
- Database queries apply pagination and result-size limits.
- Pool budgets follow the global and per-server limits defined in the Connection Manager.
- CPU-heavy file inspection or video processing runs in bounded background workers.
- API request timeouts, upload-session expiry and cancellation handling are in place.

### 14.6 Scaling Strategy

Start with a modular monolith on one VPS. Identify the bottleneck from metrics before
scaling.

| Stage | Architecture |
|---|---|
| Initial | Single Rust backend, PostgreSQL, private VPS disk |
| Growth | Bounded background workers, stronger monitoring, external backup storage |
| Higher upload volume | Object-storage adapter + resumable uploads |
| Multi-instance backend | Shared event delivery, shared session/state strategy, external file storage |

> With more than one backend instance, a local in-memory WebSocket event bus is no
> longer sufficient — shared pub/sub or an event broker becomes necessary. Similarly,
> local-only file storage should give way to shared/object storage.

### 14.7 Failure Handling

- If WebSocket disconnects, the REST API keeps working.
- An interrupted upload can resume or cleanly restart.
- Disk-full or quota-exceeded stops the upload with an explicit error.
- If the storage write succeeds but the metadata update fails, a reconciliation/cleanup
  job finds orphaned files.
- If metadata commits but the file write fails, the file is **not** marked `ready`.
- After a background-worker restart, incomplete jobs resume or fail safely.

---

## 15. Security Principles (Consolidated)

1. **SQL safety** — SQL injection and unauthorized DDL/DML are blocked. Identifiers use
   allowlisting and safe construction; values use bind parameters.
2. **Never concatenate user input into a SQL string**, especially for table, column and
   database names.
3. **Connection isolation** — one project's credentials are never available to another project.
4. **Connection limits** — every pool has a maximum, so PostgreSQL connections on the VPS
   never run out.
5. **Timeouts** — long-running queries are controlled.
6. **Cancellation** — running queries can be cancelled.
7. **Auditability** — a complete record of significant operations.
8. **Concurrency** — proper transaction and conflict handling when multiple users change
   data at once.
9. **Backpressure** — the backend stays bounded under excessive requests.
10. **Graceful shutdown** — active connections close correctly on VPS restart.
11. **Health monitoring** — the backend and every registered connection are checked.
12. **Security boundary** — the manager has no permission to execute arbitrary shell
    commands. Database management and OS service management are separate boundaries.
13. **Least privilege** — no superuser PostgreSQL accounts for projects.
14. **Secret hygiene** — passwords, tokens, private keys and signed URLs never appear in
    logs, API responses, source control or ordinary config files.
15. **Destructive operations** — `DROP DATABASE`, `DROP TABLE` and similar require explicit
    confirmation plus a separate permission.

---

## 16. Development Roadmap

### 16.1 Overall Phases

| Phase | Development | Priority |
|---|---|---|
| 1 | Rust foundation, config, API, management DB | First |
| 2 | Authentication, users, projects, connections | First |
| 3 | Database explorer and Schema Manager | High |
| 4 | CRUD Engine and Query Engine | High |
| 5 | Permissions, transactions and audit logs | High |
| 6 | Realtime, optimization and production testing | Later |

### 16.2 Connection Manager Phases

| Phase | Scope | Priority |
|---|---|---|
| 1 — Basic Connection Engine | Registry, configuration, credentials, connection tester, PostgreSQL connectivity | First |
| 2 — Pool Engine | SQLx pool manager, pool lifecycle, global connection limits, pool eviction, connection isolation | First |
| 3 — Reliability | Health monitor, state manager, reconnection, network manager, SSH tunnel | High |
| 4 — Production Optimization | Metrics, credential rotation, failure recovery, load testing, security testing | Later |

**Connection Manager implementation sequence:**

1. Registry, config validation and project authorization
2. Direct TCP/TLS connection test
3. Database discovery and database-specific lazy SQLx pools
4. Global/server pool budget manager and lifecycle handling
5. SSH tunnel route and tunnel cleanup
6. Health checks, reconnect policy, metrics and audit
7. Failure testing: invalid credentials, DNS/TLS failure, network interruption, exhausted
   budgets, idle eviction, and active queries during shutdown

### 16.3 File Storage Phases

1. File metadata, project permissions and local-disk storage adapter
2. Small-file upload, validation and controlled download
3. Upload sessions, resumable/chunked uploads and cleanup
4. Quotas, audit, metrics and backup/restore tests
5. Malware scanning/quarantine and object-storage adapter, as needed

### 16.4 Security Phases

1. User identity, password hashing and session lifecycle
2. Project membership and default-deny authorization middleware
3. Resource-level project isolation — enforce first on connections and files
4. File ACL and secure download/share flows
5. Audit, rate limiting, revocation and security tests
6. Negative tests: cross-project access, expired sessions, guessed IDs, revoked share
   links, concurrent permission changes

### 16.5 Slint Client Phases

1. Login, project selector and shared API client
2. Connections list, add/edit form and connection test
3. Database/table explorer — read-only first
4. File list, upload progress, download and delete confirmation
5. Error states, permission-denied UI, audit/activity view and usability tests

### 16.6 Deployment Phases (Part 5)

1. VPS hardening, firewall and private service networking
2. Reverse proxy and HTTPS
3. Rust backend service deployment
4. PostgreSQL persistence and private file-storage directories
5. Backup/restore automation and restore drill
6. Disk, service, certificate and backup monitoring

### 16.7 Performance Phases (Part 6)

1. Streaming upload/download and bounded memory use
2. Upload status API and WebSocket events
3. Resumable upload sessions and cleanup
4. Large-file download range support
5. Scoped metadata caching and invalidation
6. Background processing, metrics and load testing
7. Shared event delivery and object storage, when needed

---

## 17. Testing Strategy

| Test type | Coverage |
|---|---|
| Unit Tests | Each module checked in isolation |
| Integration Tests | Against a real PostgreSQL instance |
| Security Tests | SQL injection and permission bypass attempts |
| Load Tests | Many concurrent connections and requests |
| Failure Tests | PostgreSQL disconnect, timeout and reconnect |
| Recovery Tests | Connection restoration after a backend restart |

---

## 18. Open Decisions

| # | Decision | Status |
|---|---|---|
| 1 | PostgreSQL connections: local only, remote only, or both | **Resolved** — both |
| 2 | Pool strategy: per-database, shared, or hybrid | **Resolved** — hybrid (server-level budgets + database-level lazy pools) |
| 3 | Remote connectivity: direct TLS, SSH tunnel, or both | **Resolved** — both |
| 4 | Object storage adoption vs. VPS disk only | Open — start with VPS disk |
| 5 | Multi-instance backend & event broker | Open — only when load/availability requires it |
| 6 | Table data editing in the UI | Deferred to a later phase (read-only first) |
| 7 | SQL console availability | Deferred — needs dedicated permission, limits and audit |
| 8 | Video transcoding / thumbnails | Optional future capability |

---

## 19. Final Architecture Summary

- **Part 1:** One Rust modular monolith with 12 clearly separated modules; SQLx for all
  PostgreSQL access; a dedicated management database (`manager_core`) holding the
  platform's own control data, fully isolated from application data.
- **Connection Manager:** Local and remote PostgreSQL profiles managed from one control
  plane; direct TLS and SSH tunnel both supported; lazy per-database SQLx pools running
  within global and per-server budgets.
- **Part 2:** The backend is the single control point for file access. PostgreSQL holds
  metadata and permissions; file bytes live in private storage behind a storage adapter.
- **Part 3:** One central Security & Access Control module enforces authentication,
  project membership, RBAC and file ACLs. All resources are project-scoped; access is
  default-deny; sharing requires explicit, revocable, limited-scope permissions.
- **Part 4:** The Slint app is a lightweight desktop control panel — simple navigation, a
  database explorer and a file manager. No charts, no direct database access, no raw
  filesystem access.
- **Part 5:** VPS hardening, HTTPS, private networking, disk layout, backups and
  operational monitoring.
- **Part 6:** WebSocket status updates, resumable streaming, large-video handling,
  scoped caching and measured scaling.
- **Deployment:** The initial deployment is a single VPS. Object storage, a multi-instance
  backend and an event broker are added only when real load or availability requirements
  demand them.
