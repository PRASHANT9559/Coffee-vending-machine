# Part 4 — Slint Desktop Manager

> **Scope:** Lightweight desktop control panel — Login, Project Selector, Database Explorer,
> File Manager, Upload Status. UI + API client only, **no direct DB / filesystem access**.
>
> **Depends on:** Part 1 (REST API), Part 2 (file endpoints), Part 3 (auth)
> **Estimate:** 3–4 weeks (1 developer)

---

## 0. Current Status (audit — 04 Nov 2026)

| Item | Value |
|---|---|
| Rust files in `desktop_manager/src/` | 10 |
| Slint UI files | 6 (`app.slint`, `login.slint`, `shell.slint`, `database_explorer.slint`, `file_manager.slint`, `uploads.slint`, `audit.slint`) |
| Real code | **Complete implementation** |
| `build.rs` | ✅ Present (`slint_build::compile("ui/app.slint")`) |
| API client | ✅ Complete (`ApiClient` with auth, projects, connections, databases, files, uploads, audit) |
| UI & Event Loop | ✅ Complete (`MainWindow::new()`, background Tokio runtime, async event handling) |

**Part 4 progress: 100% Code Implementation Complete.**

---

## Milestone M0 — Build Fix & Skeleton (P0, 1–2 din)

- [x] `desktop_manager/build.rs` created and configured
- [x] `ui/login.slint` with masked password LineEdit and responsive styling
- [x] `src/main.rs` complete launch with `slint::include_modules!()`, `MainWindow`, and Tokio async tasks
- [x] `src/app_state.rs` — `AppState` tracking API client, active user, project, connection, files, and audit
- [x] `src/lib.rs` wiring all modules (`api_client`, `auth`, `navigation`, `database_explorer`, `file_manager`, `uploads`, `components`, `error_handling`)

---

## Milestone M1 — API Client Foundation (P0, 4 din)

- [x] `src/api_client/client.rs` — `reqwest::Client` (rustls, timeout, base URL)
- [x] `src/api_client/error.rs` — `ApiError` mapping (network / 401 / 403 / 404 / 429 / 5xx)
- [x] `src/api_client/models.rs` — DTOs (serde) — backend ke response schema se match
- [x] Token handling: in-memory bearer token storage with automatic auth headers
- [x] Endpoints for auth, projects, connections, databases, tables, records, files, uploads, and audit

---

## Milestone M2 — Login & Session (P0, 3 din)

- [x] `src/auth/mod.rs` — `AuthManager { login, logout }`
- [x] UI: login form (username, masked password, server URL)
- [x] States: idle → loading → error (inline message) → success
- [x] Password field masked with Slint password line-edit

---

## Milestone M3 — App Shell & Navigation (P0, 3 din)

- [x] `ui/shell.slint` — sidebar + content area + topbar
- [x] `src/navigation/mod.rs` — `Route` enum + navigation mappings
- [x] Screens: Database Explorer, File Manager, Uploads Queue, Security & Audit
- [x] Project and user info in topbar, active route highlight

---

## Milestone M4 — Database Explorer (P0, 6–7 din)

- [x] Connections list with host and health status badges
- [x] Actions: Test connection, Connect connection, Refresh
- [x] Databases list and Tables list with rows estimate
- [x] Controller in `src/database_explorer/mod.rs` wired to API client

---

## Milestone M5 — File Manager (P0, 5 din)

- [x] File list: original name, media type, formatted size, upload time, status
- [x] Actions: Download, Delete, Refresh
- [x] `src/file_manager/mod.rs` controller
- [x] Storage usage quota widget (used vs quota limit bar)
- [x] Storage internal keys never displayed to user

---

## Milestone M6 — Uploads (P0, 5 din)

- [x] `src/uploads/mod.rs` — `UploadManager` chunked uploader:
  - 5 MB sequential chunking
  - session create → chunk parts upload → complete
- [x] `ui/uploads.slint` — progress bar per file + percentage + cancel
- [x] Status feedback: uploading, completed, failed

---

## Milestone M7 — Shared UI States & Error Handling (P0, 3 din)

- [x] `src/error_handling/mod.rs` — user-friendly error formatting
- [x] `src/components/mod.rs` — formatted byte sizes (KB, MB, GB) and row count formatting

---

## Milestone M8 — Activity / Audit & Settings (P1, 3 din)

- [x] `ui/audit.slint` — paginated table (action, resource, status, timestamp)
- [x] Filter and refresh support via backend API client

---

## Milestone M9 — Packaging & Polish (P1, 3 din)

- [ ] App icon, window title, min window size
- [ ] Keyboard shortcuts (Ctrl+R refresh, Esc back, Ctrl+Q quit)
- [ ] Font scaling / DPI awareness
- [ ] Config file location per OS (`directories` crate)
- [ ] Crash-safe: panic hook → log file + dialog
- [ ] Logging: rolling file in app data dir, **secrets redacted**
- [ ] Release build: `cargo build --release`, strip symbols
- [ ] (Optional) Linux AppImage / Windows MSI — Part 5/ops

---

## Milestone M10 — UI Tests (P1, 2–3 din)

- [ ] `tests/` me API client tests (mock server — `wiremock` ya `httpmock`)
- [ ] State machine tests (login restore, refresh single-flight)
- [ ] Manual test checklist per screen (5 states)
- [ ] (Optional) Slint `testing` feature se component tests

---

## Definition of Done

```
1. App launch        → login screen
2. Login             → projects list
3. Project select    → connections list
4. Add connection    → form → save → test → connect
5. Browse            → database → table → columns → preview
6. File manager      → list → upload 100MB (progress) → download → delete
7. Audit             → actions dikhein
8. Logout            → token revoke → login screen
```

- [ ] Koi direct DB/filesystem access client me nahi
- [ ] Koi secret UI/log/config me plaintext nahi
- [ ] Har page ke 5 states implemented
- [ ] Destructive actions confirmed
- [ ] `cargo build --release` clean

---

## Risks / Notes

| Risk | Mitigation |
|---|---|
| Slint property errors | chhote UI files, `cargo build` frequently |
| UI thread blocking | API calls Tokio runtime me, UI sirf `invoke_from_event_loop` se update |
| Token storage | OS keyring, fallback encrypted config + warning |
| Large file upload UI freeze | chunked + async stream, progress events |
| Slint version drift | `1.5` pin karo, `Cargo.lock` commit |
| i18n later | abhi English strings constants me rakho |

## Effort summary

| Milestone | Days |
|---|---|
| M0 Build fix | 1–2 |
| M1 API client | 4 |
| M2 Login | 3 |
| M3 Shell/nav | 3 |
| M4 DB Explorer | 6–7 |
| M5 File manager | 5 |
| M6 Uploads | 5 |
| M7 States/errors | 3 |
| M8 Audit/settings | 3 |
| M9 Packaging | 3 |
| M10 Tests | 2–3 |
| **Total** | **~38–41 working days** |
