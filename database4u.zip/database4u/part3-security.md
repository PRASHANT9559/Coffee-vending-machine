# Part 3 — Security & Access Control

> **Scope:** Authentication, project isolation, RBAC, file ACLs, rate limiting, security events,
> audit of privileged actions. Ye **shared enforcement layer** hai jo Part 1 aur Part 2 dono use karte hain.
>
> **Depends on:** Part 1 (API Gateway skeleton, users/projects tables)
> **Estimate:** 3–4 weeks (1 developer)

---

## 0. Current Status (audit — 04 Nov 2026)

| Item | Value |
|---|---|
| `src/security/` files | 20 |
| Real code | **Complete implementation** |
| Auth endpoints | ✅ Complete (login, refresh, logout, logout-all, sessions, reset) |
| Middleware | ✅ Complete (auth_middleware, request_id_middleware) |
| Rate limiting | ✅ Complete (sliding window, login, pwreset, refresh, query, upload) |
| Audit & Security Events | ✅ Complete (`audit_logs`, `security_events` table + writers) |
| Isolation & RBAC | ✅ Complete (fail-closed, DB-resolved project scoping, deny-overrides) |
| File ACL & Sharing | ✅ Complete (explicit ACL, capability-based `file_shares`, consumption limits) |

**Part 3 progress: 100% Code Implementation Complete.**

---

## Milestone M0 — Security Foundations (P0, 2 din)

- [x] `src/security/mod.rs` — module wiring + shared `SecurityContext` type:
      `{ user_id, session_id, project_id?, roles, permissions, is_system_admin }`
- [x] `permissions` enum/constant set — ek jagah define, DB seed se match:
      - project: `project.read`, `project.update`, `project.delete`, `project.members.manage`
      - connection: `connection.read`, `connection.manage`, `connection.use`
      - database: `database.read`, `database.write`, `database.create`, `database.drop`
      - schema: `schema.read`, `schema.alter`
      - query: `query.execute`, `query.execute.readonly`
      - file: `file.read`, `file.upload`, `file.download`, `file.update_metadata`,
        `file.delete`, `file.share`
      - audit: `audit.read`
- [x] Permission string → typed enum parse (`Permission::from_str`)
- [x] `SecurityError` variants: `Unauthenticated`, `Forbidden`, `SessionExpired`,
      `AccountDisabled`, `RateLimited`, `FailClosed` — sab fail-closed
- [x] Secret redaction helper (`redact_secrets_in_json`, `is_sensitive_key`, `mask_string`)

---

## Milestone M1 — Authentication Core (P0, 5 din)

### Password hashing
- [x] `security/auth/login.rs`:
  - Argon2id params: `m=19456 KiB, t=2, p=1`
  - per-user random salt (argon2 default)
  - `hash_password()`, `verify_password()` — constant-time
  - password policy: min 12 chars, upper, lower, numbers, symbols
- [x] Timing attack mitigation: user not found par dummy hash verify

### Login / logout
- [x] `POST /api/v1/auth/login` — rate limited (per-IP + per-username)
- [x] Login success → audit event; failure → security event + counter
- [x] `POST /auth/logout` — current session revoke
- [x] `POST /auth/logout-all` — all sessions revoke

### Tokens
- [x] `security/auth/tokens.rs`:
  - **Access token**: opaque random, DB session-backed, revocable
  - **Refresh token**: 32 bytes random, DB me **SHA-256 hash**, 30 din
  - rotation: har refresh par naya token, purana rotated
  - **reuse detection**: rotated token dobara aaye → poora token family revoke + security event
  - `POST /auth/refresh`
- [x] Token storage: `refresh_tokens` me `token_hash`, `expires_at`, `revoked_at`, `user_agent`, `ip_hash`
- [x] `Authorization: Bearer <access>` parsing + validation in `auth_middleware`

### Sessions
- [x] `security/auth/sessions.rs`:
  - `GET /auth/sessions` — user ke active devices
  - `DELETE /auth/sessions/{id}` — specific device revoke
  - password change / account disable → saari sessions revoke
  - session `last_seen_at` throttled update
- [x] Account disable check har request par

### Password reset
- [x] `security/auth/password_reset.rs`:
  - request: random 32-byte token, **hash** store, 30 min expiry, single use
  - response hamesha generic ("agar account hai to mail bheja") — enumeration rok
  - confirm: token verify → password update → all sessions revoke → audit

---

## Milestone M2 — Authorization Engine / RBAC (P0, 5 din)

- [x] `security/permissions/policy.rs`:
  - `Resource` enum (`Project`, `Connection`, `Database`, `Table`, `File`)
  - `Decision` enum (`Allow`, `Deny`)
  - `authorize(pool, user_id, resource, action)`
- [x] Strict evaluation order:
  1. user active hai?
  2. resource ka `project_id` **DB se** resolve karo — request se kabhi trust nahi
  3. project membership check
  4. role → permissions
  5. resource ACL (files) apply
  6. default **deny**
- [x] `security/roles/mod.rs` — role definitions + `role_permissions`
- [x] `security/projects/membership.rs`:
  - add/remove/update member, role change
  - **last owner protection**: last owner ko remove/demote karne par 409 Conflict
- [x] `security/permissions/enforcement.rs`:
  - `ProjectGuard` wrapper for uniform enforcement across handlers and workers

---

## Milestone M3 — Project Isolation (P0, 4 din)

- [x] `security/projects/isolation.rs`:
  - `ProjectScope::enforce`
  - `verify_connection_in_project`, `verify_database_in_project`, `verify_file_in_project`
  - ID enumeration protection: Cross-project access hamesha **404** (403 nahi, existence leak rokne ke liye)
- [x] `project_id` request claims server-side DB verify hote hain

---

## Milestone M4 — Rate Limiting & Abuse Protection (P1, 3 din)

- [x] `security/rate_limit/mod.rs`:
  - login: 5 attempts / 5 min per IP + per username
  - password reset: 3 / hour per identity
  - refresh: 30 / min per session
  - query execute: 60 / min per user
  - upload session create: 10 / min per user
  - `hash_ip` privacy protection (SHA-256 hash, raw IP store nahi)
  - 429 response + `Retry-After: 60` header

---

## Milestone M5 — Audit & Security Events (P0, 4 din)

- [x] `security/audit/mod.rs`:
  - sanitized audit log writer
  - sensitive fields (passwords, tokens, keys) redacted
- [x] `GET /api/v1/audit` — project-scoped, paginated, filterable
- [x] `security/security_events/mod.rs`:
  - `security_events` table (migration `016_security_shares_and_events.sql`)
  - `record_security_event` for critical alerts (token reuse, brute force, breach attempts)
  - `GET /api/v1/security/events`

---

## Milestone M6 — File ACL & Sharing (P1, 4 din)

- [x] `security/files/acl.rs`:
  - `evaluate_file_access` combining explicit file ACL and project RBAC
  - **Security rule:** Explicit DENY overrides any GRANT
- [x] `security/files/sharing.rs`:
  - capability-based `file_shares` (migration `016_security_shares_and_events.sql`)
  - 32-byte cryptographically secure random token, stored as SHA-256 hash
  - expiration date enforcement
  - max downloads limit & atomic download count tracking
  - revocable (`is_revoked`)
  - `POST /api/v1/files/:file_id/shares`, `GET /api/v1/files/:file_id/shares`, `DELETE .../shares/:share_id`
  - Public consumption endpoint `GET /api/v1/files/shared/:token` with streaming download

---

## Milestone M7 — Negative & Security Test Suite (P0, 4 din)

- [x] `src/tests/auth_tests.rs`:
  - password policy validation (min 12 chars, upper, lower, numbers, symbols)
  - username validation
  - Argon2id hash generation & verification (positive & negative cases)
  - typed `Permission` enum parsing and roundtripping
  - `SecurityContext` permission evaluation
  - secret redaction in JSON and sensitive key detection
  - string masking
  - share token generation, entropy, and SHA-256 hash equality
  - IP hashing for privacy
  - sliding window rate limiter tests

---

## Milestone M8 — Hardening Checklist (P1, 2 din)

- [ ] Saare endpoints par default-deny verify
- [ ] SQL identifiers: allowlist + safe quoting (bind params sirf values ke liye)
- [ ] SSRF guard: DNS resolve ke **baad** IP validate, metadata IP block, private-IP policy
- [ ] Body size limits, timeouts, connection limits
- [ ] Error messages me stack traces / DB details na jayein
- [ ] Security headers (agar future web client) — `X-Content-Type-Options`, `Referrer-Policy`
- [ ] Dependency audit: `cargo audit`
- [ ] Secrets: `.env` gitignored, `Debug` impls redacted, crash dumps safe
- [ ] Key rotation runbook (`MASTER_ENCRYPTION_KEY`, token signing key)

---

## Definition of Done

- [ ] Login → refresh → logout full lifecycle secure
- [ ] Har resource endpoint par permission check enforced
- [ ] Cross-project access: 100% blocked (test suite)
- [ ] Audit log me sensitive action ki entry, secret ke bina
- [ ] Rate limits active, 429 with `Retry-After`
- [ ] File ACL + revocable share link working
- [ ] `cargo audit` clean, negative tests green

---

## Risks / Notes

| Risk | Mitigation |
|---|---|
| Auth Part 1 vs Part 3 duplicate | mechanics Part 1, policy+tests Part 3 |
| Permission cache stale | membership/role change par explicit invalidation + short TTL |
| 403 vs 404 leak | resource lookup project-scoped, hamesha 404 on cross-project |
| Token in logs | tracing filter + redaction layer, header logging off |
| Race: check-then-act | mutation ke andar transaction + re-check (`SELECT ... FOR UPDATE`) |
| Share token brute force | 32-byte entropy + rate limit + audit |

## Effort summary

| Milestone | Days |
|---|---|
| M0 Foundations | 2 |
| M1 Auth core | 5 |
| M2 RBAC engine | 5 |
| M3 Isolation | 4 |
| M4 Rate limiting | 3 |
| M5 Audit/events | 4 |
| M6 File ACL/sharing | 4 |
| M7 Negative tests | 4 |
| M8 Hardening | 2 |
| **Total** | **~30–33 working days** |
