# Part 2 — File Storage & Upload System

> **Scope:** Uploads, downloads, storage adapters, metadata, validation, quotas, lifecycle cleanup.
>
> **Depends on:** Part 1 (API Gateway, Auth, Projects, Permissions), Part 3 (RBAC/ACL enforcement)
> **Estimate:** 3–4 weeks (1 developer)

---

## 0. Current Status (audit — 04 Nov 2026)

| Item | Value |
|---|---|
| `src/files/` files | 19 |
| Real code | **Complete implementation** |
| Tables ready | `files`, `upload_sessions`, `file_permissions`, `file_versions`, `file_events`, `file_storage_usage` |
| Storage adapter | ✅ `LocalStorageAdapter` (bounded streaming, atomic commits) + `ObjectStorageAdapter` stub |
| Upload endpoints | ✅ Complete (sessions, multipart chunking, resumable ranges, completion) |
| Download endpoints | ✅ Complete (streaming, RFC 7233 HTTP Range 206, RFC 5987 encoding) |
| Validation & Security | ✅ Complete (magic bytes sniff, traversal block, SHA-256 verify) |
| Quotas & Cleanup | ✅ Complete (atomic quotas, periodic cleanup worker) |
| ACL & Audit | ✅ Complete (file_permissions, file_events, metrics) |

**Part 2 progress: 100% Code Implementation Complete.**

---

## Milestone M0 — Schema Complete (P0, 1 din)

- [x] `upload_sessions` table:
      `session_id`, `file_id?`, `project_id`, `owner_user_id`, `temp_storage_key`,
      `expected_size`, `received_bytes`, `checksum_expected`, `status`
      (`initiated|uploading|completing|completed|aborted|expired`),
      `expires_at`, `created_at`, `updated_at`
- [x] `file_permissions` — `file_id`, `subject_type` (user/role), `subject_id`,
      `permissions` bitmask/jsonb, `granted_by`, `created_at`
- [x] `file_versions` — `file_id`, `version_no`, `storage_key`, `size_bytes`, `checksum`
- [x] `file_events` — audit trail per file
- [x] `file_storage_usage` — `project_id`, `user_id`, `used_bytes`, `quota_bytes`, `updated_at`
- [x] `files` me columns: `media_type`, `storage_provider`, `status`, `deleted_at`
- [x] Indexes: `files(project_id, status)`, `files(checksum)`, `upload_sessions(status, expires_at)`

---

## Milestone M1 — Storage Adapter Abstraction (P0, 2–3 din)

**Rule:** file bytes PostgreSQL me kabhi nahi.

- [x] `storage/adapter.rs` — async trait (`StorageAdapter`), `StorageKey`, `ObjectMeta`
- [x] `StorageKey` newtype — opaque, server-generated (`YYYY/MM/<uuid>`), path traversal reject
- [x] `storage/local_disk.rs` — `LocalStorageAdapter`:
  - root path `STORAGE_LOCAL_PATH`
  - temp area `TEMP_UPLOAD_PATH`
  - key format: `yyyy/mm/<uuid-v4>`
  - stream + bounded buffer (64 KB chunks), kabhi poora file memory me nahi
  - **atomic commit:** temp me likho → fsync → rename → metadata update
- [x] `storage/object_store.rs` — interface stub + `Unsupported` error (future S3)
- [x] Adapter factory / settings integration in `AppState`

---

## Milestone M2 — Upload Sessions & Multipart (P0, 4–5 din)

- [x] `upload/sessions.rs`:
  - `POST /files/upload-sessions` — body: `{project_id, original_name, media_type, size_bytes, checksum?}`
  - `GET /files/upload-sessions/{id}` — status + received bytes
  - `DELETE /files/upload-sessions/{id}` — abort + temp cleanup
  - `POST /files/upload-sessions/{id}/complete` — validate + commit + metadata `ready`
- [x] `upload/multipart.rs`:
  - `POST /files/upload-sessions/{id}/parts` — chunk upload (axum multipart & raw bytes)
  - bounded chunk size (up to 10 MB), received_bytes accounting
- [x] `upload/resumable.rs`:
  - `GET /files/upload-sessions/{id}/parts` — resumable progress & missing byte ranges
- [x] Pre-flight checks: auth, project permission (`file.upload`), quota available, size limit policy

---

## Milestone M3 — Validation & Security (P0, 3 din)

- [x] `validation/mod.rs`:
  - filename sanitization — filename kabhi filesystem path nahi banta
  - extension normalization (lowercase, stripped dots, capped at 32)
  - declared MIME vs detected signature (magic bytes) vs extension separate verify
  - magic bytes sniffing: PNG, JPEG, GIF, WebP, PDF, ZIP, MP4, WebM, MP3, WAV, OGG, JSON, SVG
  - checksum verify (SHA-256) on complete
  - rejection of dangerous filenames (`..`, `/`, `\`, NUL, control chars)

---

## Milestone M4 — Metadata & File APIs (P0, 3 din)

- [x] `metadata/mod.rs` — repository + service:
  - client-facing `FileView` sanitized (storage_key kabhi leak nahi hota)
  - `GET /files` — project-scoped list, pagination, filter by status
  - `GET /files/{file_id}` — detail
  - `DELETE /files/{file_id}` — soft delete (`status = 'deleted'`, `deleted_at = NOW()`)
  - `PATCH /files/{file_id}` — rename metadata
- [x] `file_events` me har action record

---

## Milestone M5 — Download & Range Requests (P0, 3 din)

- [x] `download/mod.rs`:
  - `GET /files/{file_id}/download` — auth + permission + `ready` state check
  - stream response (`Body::from_stream`), bounded buffers (flat memory)
  - `Content-Disposition` with sanitized filename + RFC 5987 UTF-8 encoding
  - `Content-Length`, `ETag`, `Cache-Control: private, no-store`
  - HTTP **Range** support (`206 Partial Content`) with RFC 7233 range parsing

---

## Milestone M6 — Quotas (P1, 2 din)

- [x] `quotas/mod.rs`:
  - `file_storage_usage` atomic increment and decrement
  - pre-flight check before upload (`check_quota`)
  - `GET /projects/{id}/storage-usage`

---

## Milestone M7 — Lifecycle & Cleanup (P1, 2–3 din)

- [x] `lifecycle/mod.rs` — state machine + retention config
- [x] `cleanup/mod.rs` — background worker (`spawn_cleanup_worker`):
  - expired upload sessions → temp delete
  - `deleted` files → retention (7 din) ke baad physical delete + quota reduction

---

## Milestone M8 — File Permissions / ACL (P1, 2 din)

- [x] `files/permissions/mod.rs` — ACL check hook
- [x] `GET /files/{file_id}/permissions`, `POST /files/{file_id}/permissions`
- [x] `DELETE /files/permissions/{permission_id}`
- [x] Integration with project RBAC + explicit file ACL fallback

---

## Milestone M9 — Audit & Metrics (P2, 1–2 din)

- [x] `files/audit/mod.rs` — upload/download/delete audit events in `file_events`
- [x] `files/metrics/mod.rs` — `GET /files/metrics` storage and session aggregation

---

## Milestone M10 — Tests (P0, 3 din)

- [x] Unit tests for filename sanitization, extension normalization, magic byte sniff, SHA-256 verification
- [x] Unit tests for `StorageKey` generation and path traversal rejection
- [x] Unit tests for HTTP RFC 7233 Range parser and RFC 5987 Content-Disposition encoding

---

## Definition of Done

```
1. POST /files/upload-sessions       → session_id
2. POST .../parts (multiple)         → 200 each
3. POST .../complete                 → file_id, status=ready
4. GET  /files                       → file list me dikhe
5. GET  /files/{id}/download         → correct bytes + checksum
6. GET  /files/{id}/download (Range) → 206
7. DELETE /files/{id}                → soft delete
8. (retention baad)                  → physical file gone
```

- [ ] Koi storage key / filesystem path client ko nahi
- [ ] Koi file byte PostgreSQL me nahi
- [ ] Streaming — 1 GB file par memory < 100 MB
- [ ] Cross-project access → 404
- [ ] `cargo test` green

---

## Risks / Notes

| Risk | Mitigation |
|---|---|
| Disk full during upload | pre-flight check + write fail par temp cleanup |
| Metadata vs storage inconsistency | reconciliation worker (M7) |
| axum multipart memory behaviour | `DefaultBodyLimit` + stream to temp file, buffer nahi |
| Range request correctness | RFC 7233 edge cases test karo (0-, -500, invalid) |
| Quota race | row-level `SELECT ... FOR UPDATE` |
| Virus scanning | Part 1 me skip, hook interface rakho |

## Effort summary

| Milestone | Days |
|---|---|
| M0 Schema | 1 |
| M1 Storage adapter | 2–3 |
| M2 Upload sessions | 4–5 |
| M3 Validation | 3 |
| M4 Metadata/API | 3 |
| M5 Download/range | 3 |
| M6 Quotas | 2 |
| M7 Lifecycle/cleanup | 2–3 |
| M8 ACL | 2 |
| M9 Audit/metrics | 1–2 |
| M10 Tests | 3 |
| **Total** | **~26–30 working days** |
