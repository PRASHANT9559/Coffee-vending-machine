# Part 6 — Realtime, Performance & Scaling

> **Scope:** WebSocket events, streaming, resumable uploads, scoped caching, scaling stages,
> failure handling. Ye **last phase** hai — pehle Part 1–5 stable hone chahiye.
>
> **Depends on:** Part 1 (modules), Part 2 (upload/download), Part 3 (auth/scope), Part 5 (deploy)
> **Estimate:** 3–4 weeks (1 developer)

---

## 0. Current Status (audit — 04 Nov 2026)

| Item | Value |
|---|---|
| `src/realtime/mod.rs` | 1 line — `// Realtime Event Hub & WebSocket Gateway` |
| WebSocket code | ❌ zero |
| Caching (`moka`) | ❌ dependency bhi nahi |
| Streaming | ❌ zero |
| Resumable upload | ❌ zero |
| Load tests | ❌ zero |
| Message broker | ❌ zero |

**Part 6 progress: 0%.**

> Note: Part 6 ke kuch elements Part 2 me already aa rahe hain (chunked upload, range download,
> streaming). Yahan **events, caching, scaling, aur load testing** par focus hai.

---

## Milestone M0 — Event Model Design (P0, 2 din)

- [ ] Event schema define karo (versioned):

```json
{
  "event_id": "uuid",
  "sequence": 1024,
  "type": "upload.progress",
  "project_id": "uuid",
  "resource": { "kind": "file", "id": "uuid" },
  "occurred_at": "2026-11-04T10:00:00Z",
  "payload": { }
}
```

- [ ] Event types (doc §14.1):
  - `upload.progress`, `upload.completed`, `upload.failed`
  - `connection.state_changed`
  - `file.validation_completed`
  - (future) `record.changed`, `schema.changed`
- [ ] Payload me **koi secret nahi** — no tokens, no storage keys, no paths
- [ ] Sequence ID per project (monotonic) — reconnect ke baad gap detect
- [ ] Event bus abstraction:
  ```rust
  trait EventBus: Send + Sync {
      async fn publish(&self, event: Event) -> Result<()>;
      async fn subscribe(&self, scope: Scope) -> BoxStream<Event>;
  }
  ```
- [ ] MVP implementation: in-memory `tokio::sync::broadcast` + ring buffer for replay

---

## Milestone M1 — WebSocket Gateway (P0, 4–5 din)

- [ ] `src/realtime/` split:
  - `mod.rs`, `hub.rs`, `event.rs`, `gateway.rs`, `auth.rs`, `sequence.rs`
- [ ] `GET /api/v1/ws` — upgrade handler (axum `ws` feature already enabled)
- [ ] **Auth:** token query param ya first message; token validate → `SecurityContext`
- [ ] **Scope enforcement:** client sirf apne project ke events subscribe kar sakta hai;
      server-side filter, client claim trust nahi
- [ ] Per-connection send queue + backpressure; slow client ko drop karo (memory na bade)
- [ ] Heartbeat: ping/pong, idle timeout
- [ ] Reconnect protocol:
  - client `last_sequence` bheje → server ring buffer se replay
  - buffer se purana → `resync_required` event → client REST se full refresh
- [ ] Connection limit per user (default 3)
- [ ] Graceful shutdown: close frames + drain
- [ ] Metrics: active connections, events/sec, dropped events

**Acceptance:** two clients, different projects → cross-project event kabhi na mile.
Reconnect with `last_sequence` → missed events replay.

---

## Milestone M2 — Event Publishers (P0, 2–3 din)

- [ ] Upload flow: `upload.progress` (throttled, e.g. 500ms), `upload.completed`, `upload.failed`
- [ ] Connection lifecycle: `connection.state_changed` (Part 1 state machine se)
- [ ] File: `file.validation_completed`
- [ ] Publishing request path ko block na kare (channel + worker)
- [ ] At-least-once delivery within instance; dedupe via `event_id`
- [ ] **REST remains source of truth** — event sirf hint hai

---

## Milestone M3 — PostgreSQL Change Notifications (P1, 3–4 din)

> Doc §8.8 warning: `NOTIFY` complete CDC nahi hai.

- [ ] `LISTEN/NOTIFY` bridge:
  - dedicated `PgListener` connection per monitored database
  - triggers per table (opt-in), payload minimal (`table`, `op`, `id`)
  - payload size limit (8 KB) — large payload avoid
- [ ] Trigger generation: schema manager se opt-in, migrations me add
- [ ] Reconnect logic with backoff (Part 1 reconnect se reuse)
- [ ] Event mapping → `record.changed` (future)
- [ ] **Out of scope MVP:** full CDC / logical replication; document limitation

---

## Milestone M4 — Streaming & Bounded Memory (P0, 3 din)

- [ ] Upload: `tokio_util::io` + `StreamReader`, 64–256 KB buffers, never full file
- [ ] Download: `Body::from_stream`, range support (Part 2 M5 se)
- [ ] Backpressure: `poll_ready` aware; slow client par buffer cap
- [ ] Concurrency limits:
  - max concurrent uploads per user (default 3), per project (default 10)
  - max concurrent downloads per user
  - global worker bounds
- [ ] `tower` `ConcurrencyLimitLayer` jahan applicable
- [ ] Memory profiling test: 1 GB file, RSS < 200 MB

**Acceptance:** 1 GB upload + 4 parallel downloads → memory bounded, no OOM.

---

## Milestone M5 — Scoped Caching (P1, 3 din)

- [ ] `moka` add karo (`Cargo.toml` me nahi hai)
- [ ] Cache targets:
  - project metadata (short TTL, e.g. 60s)
  - connection metadata (TTL + event invalidation)
  - file metadata (short TTL)
  - permissions resolution (TTL 30s + **explicit invalidation** on role/membership change)
- [ ] **Cache key me scope:** `(project_id, user_id, resource)` — cross-tenant leak impossible
- [ ] Invalidation:
  - membership/role change → user+project keys clear
  - connection update/delete → connection keys clear
  - file update/delete → file keys clear
- [ ] File **content** caching OFF by default (doc §14.4)
- [ ] Cache failure → DB fallback (cache kabhi correctness substitute nahi)
- [ ] Cache hit/miss metrics
- [ ] **Never cache authorization decisions without invalidation**

---

## Milestone M6 — Query & API Performance Controls (P1, 2–3 din)

- [ ] Pagination mandatory on all list endpoints (Part 1 M8 already)
- [ ] Result-size caps + `has_more`
- [ ] DB query timeouts per route class
- [ ] N+1 query audit (sqlx logging + `pg_stat_statements`)
- [ ] Slow query log threshold + review
- [ ] Compression (gzip/br) for JSON responses
- [ ] ETag / conditional GET for metadata endpoints (optional)
- [ ] Connection pool sizing benchmark (Part 1 budgets verify)
- [ ] Timeouts: request, upload session, idle WS, DB acquire

---

## Milestone M7 — Resumable Upload Hardening (P1, 2–3 din)

> Basic resumable Part 2 M2 me hai. Yahan reliability + scale.

- [ ] Chunk parallelism (client 2–4 parallel, server idempotent)
- [ ] Chunk checksum per part (optional, configurable)
- [ ] Session persistence across backend restart
- [ ] Expiry sweeper scale (batch deletes, no full scan)
- [ ] Resume token hardening (short-lived, single session scope)
- [ ] Metrics: resume rate, failure reasons, throughput
- [ ] Idempotent `complete` (double-complete safe)

---

## Milestone M8 — Scaling Stages (P2, 2 din design + partial impl)

Doc §14.6 ke stages — **measurement se decide**, guess se nahi.

| Stage | Trigger (measured) | Action |
|---|---|---|
| Initial | default | single backend, PG, local disk |
| Growth | CPU/mem sustained > 70%, p95 latency badh rahi | bounded background workers, monitoring, external backup |
| Upload volume | disk/IO saturated, upload failures | object storage adapter + resumable tuning |
| Multi-instance | single instance ceiling | shared event bus (Redis/NATS), shared session store, shared storage |

- [ ] Benchmark harness document karo (k6 / `oha` / custom)
- [ ] Metrics baseline capture (before changes)
- [ ] Document thresholds + decision log
- [ ] **Multi-instance prerequisites** (future):
  - WebSocket event bus → Redis pub/sub ya NATS
  - rate limiter → Redis
  - session revocation → shared store
  - file storage → S3-compatible
- [ ] Abhi implement mat karo jab tak load prove na kare

---

## Milestone M9 — Failure Handling & Recovery (P0, 3 din)

Doc §14.7 checklist:

- [ ] WS disconnect → REST keeps working (client fallback test)
- [ ] Interrupted upload → resume ya clean restart
- [ ] Disk full / quota → explicit error, no partial `ready`
- [ ] Storage write OK + metadata fail → orphan reconciler (Part 2 M7)
- [ ] Metadata OK + storage fail → file **kabhi** `ready` na ho
- [ ] Background worker restart → incomplete jobs resume ya safe fail
- [ ] Backend restart during active transaction → clean rollback, no blind retry
- [ ] PG restart → pool recreate, client sees `Degraded` → `Connected`
- [ ] Event bus restart → sequence reset handled, client resync
- [ ] Chaos tests: kill -9 backend mid-upload, mid-query

---

## Milestone M10 — Load & Performance Testing (P0, 4–5 din)

- [ ] Test environment: VPS-similar specs (document)
- [ ] Scenarios:
  - N concurrent logins (N = 50, 200, 500)
  - metadata list endpoints (p95 target)
  - 100 concurrent small uploads
  - 10 concurrent 1 GB uploads
  - 50 concurrent range downloads
  - 1000 WS connections + event throughput
  - pool budget exhaustion behaviour
- [ ] Metrics collect: p50/p95/p99 latency, error rate, CPU, RSS, DB connections, disk IO
- [ ] Targets **document me likho** (hardcoded promises nahi — measured values)
- [ ] Bottleneck identify → tune (pool size, chunk size, worker count)
- [ ] Regression baseline save karo (`benches/` ya `docs/perf-baseline.md`)

---

## Milestone M11 — Observability (P1, 2 din)

- [ ] `tracing` spans: request_id → handler → DB → storage
- [ ] Metrics endpoint (Prometheus format) — Part 5 M7 se integrate
- [ ] Key metrics:
  - api_request_duration (histogram)
  - upload_bytes_total, upload_failures_total
  - ws_connections_active, ws_events_dropped_total
  - db_pool_in_use, db_pool_wait_seconds
  - cache_hit_ratio
- [ ] Structured logs only, secret redaction test
- [ ] Optional: OpenTelemetry export

---

## Definition of Done

- [ ] WebSocket live events, project-scoped, replay on reconnect
- [ ] REST still full source of truth (WS band ho to sab kaam chale)
- [ ] 1 GB upload/download with bounded memory
- [ ] Resumable upload survives network cut + backend restart
- [ ] Cache scoped + invalidated, cross-tenant leak impossible
- [ ] Load test results documented with p95/p99
- [ ] Failure scenarios (M9) all pass
- [ ] Metrics + dashboards live

---

## Risks / Notes

| Risk | Mitigation |
|---|---|
| WS event bus single-instance | MVP me theek; multi-instance me shared bus |
| NOTIFY as CDC | per-table triggers + minimal payload, limitations document |
| Cache stale permissions | short TTL + explicit invalidation |
| Premature scaling | measurements ke bina object storage/broker na add karo |
| Memory blowup | bounded buffers + concurrency limits + profiling test |
| Sequence gaps | ring buffer + `resync_required` fallback |

## Effort summary

| Milestone | Days |
|---|---|
| M0 Event model | 2 |
| M1 WS gateway | 4–5 |
| M2 Publishers | 2–3 |
| M3 PG notifications | 3–4 |
| M4 Streaming | 3 |
| M5 Caching | 3 |
| M6 Perf controls | 2–3 |
| M7 Resumable hardening | 2–3 |
| M8 Scaling design | 2 |
| M9 Failure handling | 3 |
| M10 Load testing | 4–5 |
| M11 Observability | 2 |
| **Total** | **~32–37 working days** |
