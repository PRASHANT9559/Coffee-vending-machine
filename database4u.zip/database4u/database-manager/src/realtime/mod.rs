//! Realtime event hub (skeleton for Part 6).
//!
//! The hub keeps a bounded in-process broadcast channel. WebSocket clients subscribe with
//! their authenticated identity and receive only events for projects they are a member of
//! at connection time (membership changes require a reconnect; a shared bus arrives in
//! Part 6 when the backend scales horizontally).

use std::collections::HashSet;
use std::sync::Arc;
use std::time::Duration;

use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::State;
use axum::response::Response;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::sync::broadcast;
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::app_state::AppState;
use crate::common::errors::AppError;

/// Capacity per subscriber. Slow consumers are disconnected rather than allowed to grow
/// memory without bound.
pub const CHANNEL_CAPACITY: usize = 1024;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RealtimeEvent {
    /// Project boundary: only members of this project may receive the event.
    pub project_id: Uuid,
    pub kind: String,
    pub payload: serde_json::Value,
    pub created_at: DateTime<Utc>,
}

impl RealtimeEvent {
    pub fn new(project_id: Uuid, kind: impl Into<String>, payload: serde_json::Value) -> Self {
        Self {
            project_id,
            kind: kind.into(),
            payload,
            created_at: Utc::now(),
        }
    }
}

/// Bounded broadcast bus. Publishing with no subscribers is a no-op, not an error.
pub struct EventBus {
    sender: broadcast::Sender<RealtimeEvent>,
}

impl EventBus {
    pub fn new() -> Self {
        let (sender, _) = broadcast::channel(CHANNEL_CAPACITY);
        Self { sender }
    }

    pub fn subscribe(&self) -> broadcast::Receiver<RealtimeEvent> {
        self.sender.subscribe()
    }

    /// Publish an event. Returns the number of subscribers that received it (`0` when
    /// nobody is connected).
    pub fn publish(&self, event: RealtimeEvent) -> usize {
        self.sender.send(event).unwrap_or(0)
    }

    pub fn subscriber_count(&self) -> usize {
        self.sender.receiver_count()
    }
}

impl Default for EventBus {
    fn default() -> Self {
        Self::new()
    }
}

/// Projects the user may receive events for.
async fn subscribed_projects(state: &AppState, user_id: Uuid) -> Result<HashSet<Uuid>, AppError> {
    let rows = sqlx::query_scalar::<_, Uuid>(
        "SELECT project_id FROM project_members WHERE user_id = $1",
    )
    .bind(user_id)
    .fetch_all(&state.db)
    .await?;
    Ok(rows.into_iter().collect())
}

/// `GET /api/v1/ws` — authenticated WebSocket upgrade.
///
/// The HTTP `Authorization` header is required; browsers cannot set it, so the desktop
/// client (which can) is the intended consumer.
pub async fn ws_handler(
    State(state): State<AppState>,
    user: AuthUser,
    upgrade: WebSocketUpgrade,
) -> Result<Response, AppError> {
    let projects = subscribed_projects(&state, user.user_id).await?;
    let receiver = state.bus.subscribe();

    Ok(upgrade
        .max_message_size(64 * 1024)
        .on_upgrade(move |socket| stream_events(socket, receiver, projects)))
}

async fn stream_events(
    mut socket: WebSocket,
    mut receiver: broadcast::Receiver<RealtimeEvent>,
    projects: HashSet<Uuid>,
) {
    loop {
        tokio::select! {
            incoming = socket.recv() => {
                match incoming {
                    // Ignore client chatter but keep the connection alive.
                    Some(Ok(Message::Text(_))) | Some(Ok(Message::Binary(_))) => continue,
                    Some(Ok(Message::Ping(payload))) => {
                        if socket.send(Message::Pong(payload)).await.is_err() {
                            break;
                        }
                    }
                    Some(Ok(Message::Close(_))) | None | Some(Err(_)) => break,
                    Some(Ok(Message::Pong(_))) => continue,
                }
            }
            event = receiver.recv() => {
                match event {
                    Ok(event) if projects.contains(&event.project_id) => {
                        let Ok(text) = serde_json::to_string(&event) else { continue };
                        if socket.send(Message::Text(text)).await.is_err() {
                            break;
                        }
                    }
                    Ok(_) => continue,
                    Err(broadcast::error::RecvError::Lagged(skipped)) => {
                        tracing::warn!(skipped, "realtime subscriber lagged; closing connection");
                        break;
                    }
                    Err(broadcast::error::RecvError::Closed) => break,
                }
            }
        }
    }

    let _ = socket.close().await;
}

/// Heartbeat interval used by the desktop client's server-side counterpart (Part 6).
pub const HEARTBEAT_INTERVAL: Duration = Duration::from_secs(30);

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn publish_reaches_subscriber() {
        let bus = EventBus::new();
        let mut receiver = bus.subscribe();
        let project_id = Uuid::new_v4();
        let sent = bus.publish(RealtimeEvent::new(
            project_id,
            "record.created",
            serde_json::json!({ "table": "orders" }),
        ));
        assert_eq!(sent, 1);
        let event = receiver.recv().await.unwrap();
        assert_eq!(event.project_id, project_id);
        assert_eq!(event.kind, "record.created");
    }

    #[tokio::test]
    async fn publish_without_subscribers_is_ok() {
        let bus = EventBus::new();
        assert_eq!(
            bus.publish(RealtimeEvent::new(
                Uuid::new_v4(),
                "noop",
                serde_json::Value::Null
            )),
            0
        );
    }
}
