//! Transaction Manager.
//!
//! Multi-statement transactions are exposed through `POST /api/v1/transactions/execute`
//! (query engine). This module holds the concrete unit-of-work helper used by internal
//! modules and documents the safety rule for broken connections.

use sqlx::PgPool;

use crate::common::errors::AppError;

/// Execute every statement inside one transaction. Any failure rolls back everything.
pub async fn execute_all_or_nothing(
    pool: &PgPool,
    statements: &[String],
) -> Result<Vec<u64>, AppError> {
    let mut tx = pool.begin().await?;
    let mut affected = Vec::with_capacity(statements.len());

    for statement in statements {
        let sql = statement.trim().trim_end_matches(';').trim();
        if sql.is_empty() {
            return Err(AppError::BadRequest("empty statement".into()));
        }
        match sqlx::query(sql).execute(&mut *tx).await {
            Ok(result) => affected.push(result.rows_affected()),
            Err(error) => {
                tx.rollback().await.ok();
                return Err(AppError::Database(error));
            }
        }
    }

    tx.commit().await?;
    Ok(affected)
}

/// Guard rail used by destructive flows: a transaction that has not been committed must
/// never be assumed to have applied after a connection drop.
pub const VERIFY_AFTER_DISCONNECT: &str =
    "connection lost: verify whether the transaction committed before retrying";
