use axum::extract::{Path, Query, State};
use axum::Json;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::{Ack, ApiResponse};
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::common::validation::{quote_identifier, quote_qualified, validate_identifier};
use crate::connections::isolation::access::require_target_permission;
use crate::connections::service as connection_service;

#[derive(Debug, Clone, Deserialize)]
pub struct DatabaseRef {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
}

impl DatabaseRef {
    fn schema(&self) -> String {
        self.schema.clone().unwrap_or_else(|| "public".to_string())
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct TableRef {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
}

impl TableRef {
    fn schema(&self) -> String {
        self.schema.clone().unwrap_or_else(|| "public".to_string())
    }
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct TableInfo {
    pub table_schema: String,
    pub table_name: String,
    pub table_type: String,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct ColumnInfo {
    pub column_name: String,
    pub data_type: String,
    pub is_nullable: String,
    pub column_default: Option<String>,
    pub character_maximum_length: Option<i32>,
    pub numeric_precision: Option<i32>,
    pub numeric_scale: Option<i32>,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct IndexInfo {
    pub indexname: String,
    pub indexdef: String,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct ConstraintInfo {
    pub constraint_name: String,
    pub constraint_type: String,
    pub column_name: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct CreateTableRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub columns: Vec<ColumnDefinition>,
}

#[derive(Debug, Deserialize)]
pub struct ColumnDefinition {
    pub name: String,
    pub data_type: String,
    #[serde(default)]
    pub nullable: bool,
    #[serde(default)]
    pub primary_key: bool,
    pub default: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct RenameTableRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub new_name: String,
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct DropTableRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct AddColumnRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub column: ColumnDefinition,
}

#[derive(Debug, Deserialize)]
pub struct CreateIndexRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub index_name: String,
    pub columns: Vec<String>,
    #[serde(default)]
    pub unique: bool,
}

pub async fn list_tables(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<DatabaseRef>,
) -> Result<Json<ApiResponse<Vec<TableInfo>>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, reference.database_target_id).await?;

    let rows = sqlx::query_as::<_, TableInfo>(
        r#"SELECT table_schema, table_name, table_type
           FROM information_schema.tables
           WHERE table_schema = $1
           ORDER BY table_name"#,
    )
    .bind(reference.schema())
    .fetch_all(&entry.pool)
    .await?;

    Ok(Json(ApiResponse::ok(rows)))
}

#[derive(Debug, Deserialize)]
pub struct SchemaQuery {
    pub schema: Option<String>,
}

/// Path-parameter variant used by `/databases/{id}/tables`.
pub async fn list_tables_for_database(
    State(state): State<AppState>,
    user: AuthUser,
    Path(database_target_id): Path<Uuid>,
    Query(query): Query<SchemaQuery>,
) -> Result<Json<ApiResponse<Vec<TableInfo>>>, AppError> {
    let reference = DatabaseRef {
        database_target_id,
        schema: query.schema,
    };
    list_tables(State(state), user, Query(reference)).await
}

pub async fn list_columns(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<TableRef>,
) -> Result<Json<ApiResponse<Vec<ColumnInfo>>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    validate_identifier(&reference.table)?;
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, reference.database_target_id).await?;

    let rows = sqlx::query_as::<_, ColumnInfo>(
        r#"SELECT column_name, data_type, is_nullable, column_default,
                  character_maximum_length, numeric_precision, numeric_scale
           FROM information_schema.columns
           WHERE table_schema = $1 AND table_name = $2
           ORDER BY ordinal_position"#,
    )
    .bind(reference.schema())
    .bind(&reference.table)
    .fetch_all(&entry.pool)
    .await?;

    Ok(Json(ApiResponse::ok(rows)))
}

pub async fn list_indexes(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<TableRef>,
) -> Result<Json<ApiResponse<Vec<IndexInfo>>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    validate_identifier(&reference.table)?;
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, reference.database_target_id).await?;

    let rows = sqlx::query_as::<_, IndexInfo>(
        "SELECT indexname, indexdef FROM pg_indexes WHERE schemaname = $1 AND tablename = $2 ORDER BY indexname",
    )
    .bind(reference.schema())
    .bind(&reference.table)
    .fetch_all(&entry.pool)
    .await?;

    Ok(Json(ApiResponse::ok(rows)))
}

pub async fn list_constraints(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<TableRef>,
) -> Result<Json<ApiResponse<Vec<ConstraintInfo>>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    validate_identifier(&reference.table)?;
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, reference.database_target_id).await?;

    let rows = sqlx::query_as::<_, ConstraintInfo>(
        r#"SELECT tc.constraint_name, tc.constraint_type, kcu.column_name
           FROM information_schema.table_constraints tc
           LEFT JOIN information_schema.key_column_usage kcu
             ON kcu.constraint_name = tc.constraint_name
            AND kcu.table_schema = tc.table_schema
            AND kcu.table_name = tc.table_name
           WHERE tc.table_schema = $1 AND tc.table_name = $2
           ORDER BY tc.constraint_name, kcu.ordinal_position"#,
    )
    .bind(reference.schema())
    .bind(&reference.table)
    .fetch_all(&entry.pool)
    .await?;

    Ok(Json(ApiResponse::ok(rows)))
}

pub async fn create_table(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<CreateTableRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let table = quote_qualified(
        &request.schema.clone().unwrap_or_else(|| "public".into()),
        &request.table,
    )?;

    if request.columns.is_empty() {
        return Err(AppError::BadRequest("at least one column is required".into()));
    }

    let mut definitions = Vec::with_capacity(request.columns.len());
    let mut primary_keys = Vec::new();

    for column in &request.columns {
        let name = quote_identifier(&column.name)?;
        let data_type = validate_data_type(&column.data_type)?;
        let mut definition = format!("{name} {data_type}");
        if !column.nullable {
            definition.push_str(" NOT NULL");
        }
        if let Some(default) = column.default.as_deref() {
            definition.push_str(&format!(" DEFAULT {}", validate_default(default)?));
        }
        if column.primary_key {
            primary_keys.push(name);
        }
        definitions.push(definition);
    }

    if !primary_keys.is_empty() {
        definitions.push(format!("PRIMARY KEY ({})", primary_keys.join(", ")));
    }

    let sql = format!("CREATE TABLE {table} ({})", definitions.join(", "));
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.create_table",
        "table",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("table created"))))
}

pub async fn add_column(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<AddColumnRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let table = quote_qualified(
        &request.schema.clone().unwrap_or_else(|| "public".into()),
        &request.table,
    )?;
    let column = &request.column;
    let name = quote_identifier(&column.name)?;
    let data_type = validate_data_type(&column.data_type)?;

    let mut definition = format!("ADD COLUMN {name} {data_type}");
    if !column.nullable {
        definition.push_str(" NOT NULL");
    }
    if let Some(default) = column.default.as_deref() {
        definition.push_str(&format!(" DEFAULT {}", validate_default(default)?));
    }

    let sql = format!("ALTER TABLE {table} {definition}");
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.add_column",
        "table",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("column added"))))
}

pub async fn rename_table(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<RenameTableRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest("confirmation flag is required".into()));
    }
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let old = quote_qualified(&schema, &request.table)?;
    let new = validate_identifier(&request.new_name)?;

    let sql = format!("ALTER TABLE {old} RENAME TO {}", quote_identifier(new)?);
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.rename_table",
        "table",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("table renamed"))))
}

pub async fn drop_table(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<DropTableRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest("confirmation flag is required".into()));
    }
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let table = quote_qualified(
        &request.schema.clone().unwrap_or_else(|| "public".into()),
        &request.table,
    )?;

    let sql = format!("DROP TABLE {table}");
    let (entry, _) = connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.drop_table",
        "table",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("table dropped"))))
}

pub async fn create_index(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<CreateIndexRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    if request.columns.is_empty() {
        return Err(AppError::BadRequest("at least one index column is required".into()));
    }

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let index_name = quote_identifier(&request.index_name)?;
    let table = quote_qualified(&schema, &request.table)?;
    let columns = request
        .columns
        .iter()
        .map(|column| quote_identifier(column))
        .collect::<Result<Vec<_>, _>>()?
        .join(", ");

    let sql = format!(
        "CREATE {}INDEX {index_name} ON {table} ({columns})",
        if request.unique { "UNIQUE " } else { "" }
    );

    let (entry, _) = connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.create_index",
        "index",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("index created"))))
}

/// Data types are restricted to an allowlist grammar: letters, digits, spaces,
/// parentheses, commas and brackets. This blocks anything that could escape the DDL.
fn validate_data_type(raw: &str) -> Result<String, AppError> {
    let value = raw.trim();
    if value.is_empty() || value.len() > 64 {
        return Err(AppError::Validation("invalid column data type".into()));
    }
    if !value
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, ' ' | '(' | ')' | ',' | '[' | ']'))
    {
        return Err(AppError::Validation(
            "column data type contains unsupported characters".into(),
        ));
    }
    Ok(value.to_string())
}

/// Default expressions are limited to simple literals and well-known functions.
fn validate_default(raw: &str) -> Result<String, AppError> {
    let lowered = raw.trim().to_ascii_lowercase();
    if lowered.is_empty() || lowered.len() > 128 {
        return Err(AppError::Validation("invalid default expression".into()));
    }
    let allowed = lowered == "now()"
        || lowered == "current_timestamp"
        || lowered == "true"
        || lowered == "false"
        || lowered == "null"
        || lowered == "gen_random_uuid()"
        || lowered.parse::<f64>().is_ok()
        || (lowered.starts_with('\'') && lowered.ends_with('\''));

    if !allowed {
        return Err(AppError::Validation(
            "default expression is not permitted".into(),
        ));
    }

    if lowered.starts_with('\'') {
        // Only a plain SQL string literal is allowed. Every inner quote must be part of
        // a doubled quote; an odd quote (e.g. `'x'||pg_sleep(1)||'`) would escape the
        // literal and is rejected.
        if lowered.len() < 2 || !lowered.ends_with('\'') {
            return Err(AppError::Validation("invalid string default".into()));
        }
        let inner = &lowered[1..lowered.len() - 1];
        let mut chars = inner.chars().peekable();
        while let Some(ch) = chars.next() {
            if ch == '\'' {
                if chars.peek() == Some(&'\'') {
                    chars.next();
                } else {
                    return Err(AppError::Validation("invalid string default".into()));
                }
            }
        }
    }

    Ok(raw.trim().to_string())
}

fn map_pg_error(error: sqlx::Error) -> AppError {
    match &error {
        sqlx::Error::Database(db) if db.is_unique_violation() => {
            AppError::Conflict("object already exists".into())
        }
        sqlx::Error::Database(db) => {
            let message: String = db
                .message()
                .chars()
                .filter(|c| !c.is_control())
                .take(200)
                .collect();
            AppError::BadRequest(message)
        }
        other => AppError::Database(other.clone()),
    }
}

// ---------------------------------------------------------------------------
// Views, sequences, relations, inspector and column/index/constraint changes.
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct ViewInfo {
    pub viewname: String,
    pub definition: Option<String>,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct SequenceInfo {
    pub sequence_name: String,
    pub data_type: String,
    pub start_value: i64,
    pub increment: i64,
    pub last_value: Option<i64>,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct RelationInfo {
    pub constraint_name: String,
    pub table_name: String,
    pub column_name: String,
    pub foreign_table_schema: String,
    pub foreign_table_name: String,
    pub foreign_column_name: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct TableInspection {
    pub schema: String,
    pub table: String,
    pub estimated_rows: i64,
    pub total_size_bytes: i64,
    pub columns: Vec<ColumnInfo>,
    pub indexes: Vec<IndexInfo>,
    pub constraints: Vec<ConstraintInfo>,
}

#[derive(Debug, Deserialize)]
pub struct CreateViewRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub name: String,
    /// Body of the view. Must be a single `SELECT`/`WITH` statement.
    pub definition: String,
}

#[derive(Debug, Deserialize)]
pub struct ViewRef {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub name: String,
    #[serde(default)]
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct RenameColumnRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub column: String,
    pub new_name: String,
}

#[derive(Debug, Deserialize)]
pub struct AlterColumnTypeRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub column: String,
    pub data_type: String,
    /// Required when the conversion can rewrite the table.
    #[serde(default)]
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct DropColumnRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub column: String,
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct DropIndexRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub index_name: String,
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct DropConstraintRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub constraint_name: String,
    pub confirm: bool,
}

pub async fn list_views(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<DatabaseRef>,
) -> Result<Json<ApiResponse<Vec<ViewInfo>>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, reference.database_target_id)
            .await?;

    let rows = sqlx::query_as::<_, ViewInfo>(
        r#"SELECT viewname, definition
           FROM pg_views
           WHERE schemaname = $1
           ORDER BY viewname"#,
    )
    .bind(reference.schema())
    .fetch_all(&entry.pool)
    .await?;

    Ok(Json(ApiResponse::ok(rows)))
}

pub async fn create_view(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<CreateViewRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let name = quote_qualified(&schema, &request.name)?;
    let body = validate_view_definition(&request.definition)?;

    let sql = format!("CREATE VIEW {name} AS {body}");
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.create_view",
        "view",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("view created"))))
}

pub async fn drop_view(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<ViewRef>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest("confirmation flag is required".into()));
    }
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let name = quote_qualified(&schema, &request.name)?;

    let sql = format!("DROP VIEW {name}");
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.drop_view",
        "view",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("view dropped"))))
}

pub async fn list_sequences(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<DatabaseRef>,
) -> Result<Json<ApiResponse<Vec<SequenceInfo>>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, reference.database_target_id)
            .await?;

    let rows = sqlx::query_as::<_, SequenceInfo>(
        r#"SELECT c.relname AS sequence_name,
                  format_type(s.seqtypid, NULL) AS data_type,
                  s.seqstart AS start_value,
                  s.seqincrement AS increment,
                  pg_sequence_last_value(c.oid) AS last_value
           FROM pg_sequence s
           JOIN pg_class c ON c.oid = s.seqrelid
           JOIN pg_namespace n ON n.oid = c.relnamespace
           WHERE n.nspname = $1
           ORDER BY c.relname"#,
    )
    .bind(reference.schema())
    .fetch_all(&entry.pool)
    .await?;

    Ok(Json(ApiResponse::ok(rows)))
}

/// Foreign-key graph for a schema.
pub async fn list_relations(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<DatabaseRef>,
) -> Result<Json<ApiResponse<Vec<RelationInfo>>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, reference.database_target_id)
            .await?;

    let rows = sqlx::query_as::<_, RelationInfo>(
        r#"SELECT tc.constraint_name,
                  tc.table_name,
                  kcu.column_name,
                  ccu.table_schema AS foreign_table_schema,
                  ccu.table_name AS foreign_table_name,
                  ccu.column_name AS foreign_column_name
           FROM information_schema.table_constraints tc
           JOIN information_schema.key_column_usage kcu
             ON kcu.constraint_name = tc.constraint_name
            AND kcu.table_schema = tc.table_schema
           JOIN information_schema.constraint_column_usage ccu
             ON ccu.constraint_name = tc.constraint_name
            AND ccu.table_schema = tc.table_schema
           WHERE tc.constraint_type = 'FOREIGN KEY'
             AND tc.table_schema = $1
           ORDER BY tc.table_name, tc.constraint_name"#,
    )
    .bind(reference.schema())
    .fetch_all(&entry.pool)
    .await?;

    Ok(Json(ApiResponse::ok(rows)))
}

/// Full structure for one table: columns, indexes, constraints, row estimate and size.
pub async fn inspect_table(
    State(state): State<AppState>,
    user: AuthUser,
    Query(reference): Query<TableRef>,
) -> Result<Json<ApiResponse<TableInspection>>, AppError> {
    require_target_permission(&state.db, user.user_id, reference.database_target_id, "schema.read")
        .await?;
    validate_identifier(&reference.table)?;

    let schema = reference.schema();
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, reference.database_target_id)
            .await?;

    let columns = sqlx::query_as::<_, ColumnInfo>(
        r#"SELECT column_name, data_type, is_nullable, column_default,
                  character_maximum_length, numeric_precision, numeric_scale
           FROM information_schema.columns
           WHERE table_schema = $1 AND table_name = $2
           ORDER BY ordinal_position"#,
    )
    .bind(&schema)
    .bind(&reference.table)
    .fetch_all(&entry.pool)
    .await?;

    if columns.is_empty() {
        return Err(AppError::NotFound("table not found".into()));
    }

    let indexes = sqlx::query_as::<_, IndexInfo>(
        "SELECT indexname, indexdef FROM pg_indexes WHERE schemaname = $1 AND tablename = $2 ORDER BY indexname",
    )
    .bind(&schema)
    .bind(&reference.table)
    .fetch_all(&entry.pool)
    .await?;

    let constraints = sqlx::query_as::<_, ConstraintInfo>(
        r#"SELECT tc.constraint_name, tc.constraint_type, kcu.column_name
           FROM information_schema.table_constraints tc
           LEFT JOIN information_schema.key_column_usage kcu
             ON kcu.constraint_name = tc.constraint_name
            AND kcu.table_schema = tc.table_schema
            AND kcu.table_name = tc.table_name
           WHERE tc.table_schema = $1 AND tc.table_name = $2
           ORDER BY tc.constraint_name"#,
    )
    .bind(&schema)
    .bind(&reference.table)
    .fetch_all(&entry.pool)
    .await?;

    let stat = sqlx::query_as::<_, (i64, i64)>(
        r#"SELECT GREATEST(c.reltuples::bigint, 0),
                  pg_total_relation_size(c.oid)
           FROM pg_class c
           JOIN pg_namespace n ON n.oid = c.relnamespace
           WHERE n.nspname = $1 AND c.relname = $2"#,
    )
    .bind(&schema)
    .bind(&reference.table)
    .fetch_optional(&entry.pool)
    .await?
    .unwrap_or((0, 0));

    Ok(Json(ApiResponse::ok(TableInspection {
        schema,
        table: reference.table.clone(),
        estimated_rows: stat.0,
        total_size_bytes: stat.1,
        columns,
        indexes,
        constraints,
    })))
}

pub async fn rename_column(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<RenameColumnRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let table = quote_qualified(&schema, &request.table)?;
    let column = quote_identifier(&request.column)?;
    let new_name = quote_identifier(&request.new_name)?;

    let sql = format!("ALTER TABLE {table} RENAME COLUMN {column} TO {new_name}");
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.rename_column",
        "column",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("column renamed"))))
}

pub async fn alter_column_type(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<AlterColumnTypeRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest(
            "confirmation flag is required for a type change".into(),
        ));
    }
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let table = quote_qualified(&schema, &request.table)?;
    let column = quote_identifier(&request.column)?;
    let data_type = validate_data_type(&request.data_type)?;

    let sql = format!("ALTER TABLE {table} ALTER COLUMN {column} TYPE {data_type} USING {column}::{data_type}");
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.alter_column_type",
        "column",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("column type changed"))))
}

pub async fn drop_column(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<DropColumnRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest("confirmation flag is required".into()));
    }
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let table = quote_qualified(&schema, &request.table)?;
    let column = quote_identifier(&request.column)?;

    let sql = format!("ALTER TABLE {table} DROP COLUMN {column}");
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.drop_column",
        "column",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("column dropped"))))
}

pub async fn drop_index(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<DropIndexRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest("confirmation flag is required".into()));
    }
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let qualified = quote_qualified(&schema, &request.index_name)?;

    let sql = format!("DROP INDEX {qualified}");
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.drop_index",
        "index",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("index dropped"))))
}

pub async fn drop_constraint(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<DropConstraintRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest("confirmation flag is required".into()));
    }
    require_target_permission(&state.db, user.user_id, request.database_target_id, "schema.alter")
        .await?;

    let schema = request.schema.clone().unwrap_or_else(|| "public".into());
    let table = quote_qualified(&schema, &request.table)?;
    let constraint = quote_identifier(&request.constraint_name)?;

    let sql = format!("ALTER TABLE {table} DROP CONSTRAINT {constraint}");
    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;
    sqlx::query(&sql).execute(&entry.pool).await.map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "schema.drop_constraint",
        "constraint",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("constraint dropped"))))
}

/// View bodies cannot be bound as parameters, so they are read-only validated:
/// a single statement that starts with `SELECT` or `WITH`, without statement
/// separators or data-modifying keywords.
fn validate_view_definition(raw: &str) -> Result<String, AppError> {
    let body = raw.trim().trim_end_matches(';').trim();
    if body.is_empty() || body.len() > 20_000 {
        return Err(AppError::Validation("invalid view definition".into()));
    }
    if body.contains(';') {
        return Err(AppError::Validation(
            "view definition must be a single statement".into(),
        ));
    }

    let lowered = body.to_ascii_lowercase();
    if !(lowered.starts_with("select") || lowered.starts_with("with")) {
        return Err(AppError::Validation(
            "view definition must be a SELECT or WITH query".into(),
        ));
    }

    for forbidden in [
        "insert ", "update ", "delete ", "drop ", "alter ", "create ", "grant ", "truncate ",
        "copy ", "call ", "do ",
    ] {
        if lowered.contains(forbidden) {
            return Err(AppError::Validation(
                "view definition contains a forbidden statement".into(),
            ));
        }
    }

    Ok(body.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn allows_simple_types() {
        assert!(validate_data_type("varchar(255)").is_ok());
        assert!(validate_data_type("numeric(10,2)").is_ok());
        assert!(validate_data_type("timestamptz").is_ok());
    }

    #[test]
    fn rejects_type_injection() {
        assert!(validate_data_type("text); DROP TABLE users; --").is_err());
    }

    #[test]
    fn rejects_default_injection() {
        assert!(validate_default("'x'); DROP TABLE users; --").is_err());
        assert!(validate_default("now()").is_ok());
        assert!(validate_default("42").is_ok());
    }
}
