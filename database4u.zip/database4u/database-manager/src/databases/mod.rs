use axum::extract::{Path, Query, State};
use axum::Json;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::{Ack, ApiResponse};
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::common::validation::{quote_identifier, validate_identifier};
use crate::connections::isolation::access::require_connection_permission;
use crate::connections::repository as connection_repo;
use crate::connections::service as connection_service;
use crate::security::audit;

#[derive(Debug, Serialize)]
pub struct DatabaseInfo {
    pub database_target_id: Uuid,
    pub connection_id: Uuid,
    pub database_name: String,
    pub size_bytes: Option<i64>,
    pub encoding: Option<String>,
    pub collation: Option<String>,
    pub owner: Option<String>,
    pub active_connections: Option<i64>,
    pub allow_connections: Option<bool>,
}

#[derive(Debug, Deserialize)]
pub struct CreateDatabaseRequest {
    pub connection_id: Uuid,
    pub database_name: String,
    pub owner: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct RenameDatabaseRequest {
    pub new_name: String,
    /// Destructive/DDL operations require an explicit confirmation flag.
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct DropDatabaseRequest {
    pub confirm: bool,
}

#[derive(Debug, Deserialize)]
pub struct ListDatabasesQuery {
    pub connection_id: Uuid,
}

/// List registered databases for a connection.
pub async fn list_databases(
    State(state): State<AppState>,
    user: AuthUser,
    Query(query): Query<ListDatabasesQuery>,
) -> Result<Json<ApiResponse<Vec<DatabaseInfo>>>, AppError> {
    require_connection_permission(
        &state.db,
        user.user_id,
        query.connection_id,
        "database.read",
    )
    .await?;

    let targets = connection_repo::list_database_targets(&state.db, query.connection_id).await?;
    let mut result = Vec::with_capacity(targets.len());

    // Metadata is global to the server, but only resolvable while a pool exists. We use
    // the first target pool to query pg_database for all of them.
    let metadata = if let Some(first) = targets.first() {
        match connection_service::build_pool_for_target(&state, first.database_target_id).await {
            Ok(entry) => load_metadata(&entry.pool, None).await.unwrap_or_default(),
            Err(_) => Vec::new(),
        }
    } else {
        Vec::new()
    };

    for target in targets {
        let row = metadata
            .iter()
            .find(|row| row.database_name == target.database_name);
        result.push(DatabaseInfo {
            database_target_id: target.database_target_id,
            connection_id: target.connection_id,
            database_name: target.database_name,
            size_bytes: row.map(|r| r.size_bytes),
            encoding: row.map(|r| r.encoding.clone()),
            collation: row.map(|r| r.collation.clone()),
            owner: row.map(|r| r.owner.clone()),
            active_connections: row.map(|r| r.active_connections),
            allow_connections: row.map(|r| r.allow_connections),
        });
    }

    Ok(Json(ApiResponse::ok(result)))
}

#[derive(Debug, Clone, sqlx::FromRow)]
struct MetadataRow {
    database_name: String,
    size_bytes: i64,
    encoding: String,
    collation: String,
    owner: String,
    active_connections: i64,
    allow_connections: bool,
}

async fn load_metadata(
    pool: &sqlx::PgPool,
    database_name: Option<&str>,
) -> Result<Vec<MetadataRow>, AppError> {
    let rows = sqlx::query_as::<_, MetadataRow>(
        r#"SELECT d.datname AS database_name,
                  pg_database_size(d.datname) AS size_bytes,
                  pg_encoding_to_char(d.encoding) AS encoding,
                  d.datcollate AS collation,
                  pg_get_userbyid(d.datdba) AS owner,
                  (SELECT count(*) FROM pg_stat_activity a WHERE a.datname = d.datname)
                      AS active_connections,
                  d.datallowconn AS allow_connections
           FROM pg_database d
           WHERE ($1::text IS NULL OR d.datname = $1)
           ORDER BY d.datname"#,
    )
    .bind(database_name)
    .fetch_all(pool)
    .await?;

    Ok(rows)
}

/// Get details for one registered database target.
pub async fn get_database(
    State(state): State<AppState>,
    user: AuthUser,
    Path(target_id): Path<Uuid>,
) -> Result<Json<ApiResponse<DatabaseInfo>>, AppError> {
    let (entry, target) = connection_service::resolve_target(&state, user.user_id, target_id).await?;

    let rows = load_metadata(&entry.pool, Some(&target.database_name)).await?;
    let row = rows
        .into_iter()
        .next()
        .ok_or_else(|| AppError::NotFound("database not found".into()))?;

    Ok(Json(ApiResponse::ok(DatabaseInfo {
        database_target_id: target.database_target_id,
        connection_id: target.connection_id,
        database_name: row.database_name,
        size_bytes: Some(row.size_bytes),
        encoding: Some(row.encoding),
        collation: Some(row.collation),
        owner: Some(row.owner),
        active_connections: Some(row.active_connections),
        allow_connections: Some(row.allow_connections),
    })))
}

/// Create a database on the server and register it as a target.
///
/// Identifiers are validated and quoted — never interpolated raw.
pub async fn create_database(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<CreateDatabaseRequest>,
) -> Result<Json<ApiResponse<DatabaseInfo>>, AppError> {
    require_connection_permission(
        &state.db,
        user.user_id,
        request.connection_id,
        "database.create",
    )
    .await?;

    let name = validate_identifier(&request.database_name)?.to_string();
    let qualified = quote_identifier(&name)?;

    // Any existing database on the same server can execute CREATE DATABASE.
    let targets =
        connection_repo::list_database_targets(&state.db, request.connection_id).await?;
    let base_target = targets
        .first()
        .ok_or_else(|| AppError::BadRequest("connection has no database targets yet".into()))?;

    let entry =
        connection_service::build_pool_for_target(&state, base_target.database_target_id).await?;

    let mut sql = format!("CREATE DATABASE {qualified}");
    if let Some(owner) = request.owner.as_deref() {
        let owner = validate_identifier(owner)?;
        sql.push_str(&format!(" OWNER {}", quote_identifier(owner)?));
    }

    sqlx::query(&sql).execute(&entry.pool).await.map_err(|error| {
        map_pg_error(error, "database could not be created")
    })?;

    let target = connection_repo::upsert_database_target(
        &state.db,
        request.connection_id,
        &name,
    )
    .await?;

    audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "database.create",
        "database",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(DatabaseInfo {
        database_target_id: target.database_target_id,
        connection_id: target.connection_id,
        database_name: target.database_name,
        size_bytes: None,
        encoding: None,
        collation: None,
        owner: None,
        active_connections: Some(0),
        allow_connections: Some(true),
    })))
}

/// Rename a database. Fails if other sessions are connected.
pub async fn rename_database(
    State(state): State<AppState>,
    user: AuthUser,
    Path(target_id): Path<Uuid>,
    Json(request): Json<RenameDatabaseRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest(
            "confirmation flag is required for rename".into(),
        ));
    }

    let (_, target) = connection_service::resolve_target(&state, user.user_id, target_id).await?;
    require_connection_permission(
        &state.db,
        user.user_id,
        target.connection_id,
        "database.create",
    )
    .await?;
    let new_name = validate_identifier(&request.new_name)?.to_string();

    // DDL for a database must be issued from a different database on the same server.
    let peer = peer_pool(&state, target.connection_id, &target.database_name).await?;

    let active = active_connections(&peer.pool, &target.database_name).await?;
    if active > 0 {
        return Err(AppError::Conflict(
            "database has active connections; disconnect them first".into(),
        ));
    }

    let sql = format!(
        "ALTER DATABASE {} RENAME TO {}",
        quote_identifier(&target.database_name)?,
        quote_identifier(&new_name)?
    );
    sqlx::query(&sql)
        .execute(&peer.pool)
        .await
        .map_err(|error| map_pg_error(error, "database could not be renamed"))?;

    // Existing pool is bound to the old name; force lazy recreation.
    state.pools.close(target_id).await;

    sqlx::query("UPDATE connection_databases SET database_name = $1 WHERE database_target_id = $2")
        .bind(&new_name)
        .bind(target_id)
        .execute(&state.db)
        .await?;

    audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "database.rename",
        "database",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("database renamed"))))
}

/// Drop a database. Requires confirmation and no other active sessions.
pub async fn drop_database(
    State(state): State<AppState>,
    user: AuthUser,
    Path(target_id): Path<Uuid>,
    Json(request): Json<DropDatabaseRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    if !request.confirm {
        return Err(AppError::BadRequest(
            "confirmation flag is required to drop a database".into(),
        ));
    }

    let (_, target) = connection_service::resolve_target(&state, user.user_id, target_id).await?;
    require_connection_permission(
        &state.db,
        user.user_id,
        target.connection_id,
        "database.drop",
    )
    .await?;

    // Close our own pool first, otherwise it would count as an active session.
    state.pools.close(target_id).await;

    // DROP DATABASE cannot run from the database being dropped.
    let peer = peer_pool(&state, target.connection_id, &target.database_name).await?;
    let active = active_connections(&peer.pool, &target.database_name).await?;
    if active > 0 {
        return Err(AppError::Conflict(
            "database has active connections; disconnect them first".into(),
        ));
    }

    let sql = format!("DROP DATABASE {}", quote_identifier(&target.database_name)?);
    sqlx::query(&sql)
        .execute(&peer.pool)
        .await
        .map_err(|error| map_pg_error(error, "database could not be dropped"))?;

    state.pools.close(target_id).await;
    sqlx::query("DELETE FROM connection_databases WHERE database_target_id = $1")
        .bind(target_id)
        .execute(&state.db)
        .await?;

    audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "database.drop",
        "database",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(Ack::new("database dropped"))))
}

async fn active_connections(
    pool: &sqlx::PgPool,
    database_name: &str,
) -> Result<i64, AppError> {
    let count = sqlx::query_scalar::<_, i64>(
        "SELECT count(*) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()",
    )
    .bind(database_name)
    .fetch_one(pool)
    .await?;
    Ok(count)
}

/// Find a pool connected to a *different* database on the same server.
/// `CREATE/ALTER/DROP DATABASE` cannot run from the database being changed.
async fn peer_pool(
    state: &AppState,
    connection_id: Uuid,
    exclude: &str,
) -> Result<std::sync::Arc<crate::connections::pool::manager::PoolEntry>, AppError> {
    let targets = connection_repo::list_database_targets(&state.db, connection_id).await?;
    let peer = targets
        .into_iter()
        .find(|target| target.database_name != exclude)
        .ok_or_else(|| {
            AppError::BadRequest(
                "no other database on this server can execute the operation; register one first"
                    .into(),
            )
        })?;

    connection_service::build_pool_for_target(&state, peer.database_target_id).await
}

fn map_pg_error(error: sqlx::Error, context: &str) -> AppError {
    match &error {
        sqlx::Error::Database(db) if db.is_unique_violation() => {
            AppError::Conflict("database already exists".into())
        }
        _ => AppError::BadRequest(format!("{context}: {}", sanitize_db_error(&error))),
    }
}

fn sanitize_db_error(error: &sqlx::Error) -> String {
    match error {
        sqlx::Error::Database(db) => db
            .message()
            .chars()
            .filter(|c| !c.is_control())
            .take(200)
            .collect(),
        other => other.to_string().chars().take(200).collect(),
    }
}

/// Timestamp helper exposed for handlers that need a checked_at value.
pub fn now() -> DateTime<Utc> {
    Utc::now()
}
