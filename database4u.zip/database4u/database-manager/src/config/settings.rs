use std::fmt;

use secrecy::SecretString;

use super::environment::Environment;

/// Strongly typed application configuration, loaded from environment variables.
///
/// Secrets are never printed by the `Debug` implementation.
#[derive(Clone)]
pub struct Settings {
    pub host: String,
    pub port: u16,
    pub database_url: String,
    pub master_encryption_key: SecretString,
    pub environment: Environment,

    pub access_token_ttl_minutes: i64,
    pub refresh_token_ttl_days: i64,
    pub password_reset_ttl_minutes: i64,

    pub db_max_connections: u32,
    pub query_timeout_seconds: u64,
    pub global_pool_budget: u32,

    pub storage_local_path: String,
    pub temp_upload_path: String,
}

impl fmt::Debug for Settings {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Settings")
            .field("host", &self.host)
            .field("port", &self.port)
            .field("database_url", &"<redacted>")
            .field("master_encryption_key", &"<redacted>")
            .field("environment", &self.environment)
            .field("access_token_ttl_minutes", &self.access_token_ttl_minutes)
            .field("refresh_token_ttl_days", &self.refresh_token_ttl_days)
            .field("db_max_connections", &self.db_max_connections)
            .field("query_timeout_seconds", &self.query_timeout_seconds)
            .field("global_pool_budget", &self.global_pool_budget)
            .field("storage_local_path", &self.storage_local_path)
            .field("temp_upload_path", &self.temp_upload_path)
            .finish()
    }
}

#[derive(Debug, thiserror::Error)]
pub enum ConfigError {
    #[error("missing required environment variable: {0}")]
    Missing(&'static str),
    #[error("invalid value for {name}: {reason}")]
    Invalid { name: &'static str, reason: String },
    #[error("refusing to start: {0}")]
    Unsafe(String),
}

fn required(name: &'static str) -> Result<String, ConfigError> {
    std::env::var(name)
        .ok()
        .map(|v| v.trim().to_string())
        .filter(|v| !v.is_empty())
        .ok_or(ConfigError::Missing(name))
}

fn optional(name: &str, default: &str) -> String {
    std::env::var(name)
        .ok()
        .map(|v| v.trim().to_string())
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| default.to_string())
}

fn parse<T>(name: &'static str, raw: &str) -> Result<T, ConfigError>
where
    T: std::str::FromStr,
    T::Err: std::fmt::Display,
{
    raw.parse::<T>().map_err(|e| ConfigError::Invalid {
        name,
        reason: e.to_string(),
    })
}

impl Settings {
    /// Load configuration from the process environment (after loading `.env`).
    pub fn from_env() -> Result<Self, ConfigError> {
        let environment = Environment::parse(&optional("APP_ENV", "development"));

        let host = optional("SERVER_HOST", "127.0.0.1");
        let port = parse("SERVER_PORT", &optional("SERVER_PORT", "8080"))?;

        let database_url = required("DATABASE_URL")?;
        let master_encryption_key = SecretString::new(required("MASTER_ENCRYPTION_KEY")?);

        let access_token_ttl_minutes =
            parse("ACCESS_TOKEN_TTL_MINUTES", &optional("ACCESS_TOKEN_TTL_MINUTES", "15"))?;
        let refresh_token_ttl_days =
            parse("REFRESH_TOKEN_TTL_DAYS", &optional("REFRESH_TOKEN_TTL_DAYS", "30"))?;
        let password_reset_ttl_minutes =
            parse("PASSWORD_RESET_TTL_MINUTES", &optional("PASSWORD_RESET_TTL_MINUTES", "30"))?;

        let db_max_connections =
            parse("DB_MAX_CONNECTIONS", &optional("DB_MAX_CONNECTIONS", "10"))?;
        let query_timeout_seconds =
            parse("QUERY_TIMEOUT_SECONDS", &optional("QUERY_TIMEOUT_SECONDS", "5"))?;
        let global_pool_budget =
            parse("GLOBAL_POOL_BUDGET", &optional("GLOBAL_POOL_BUDGET", "30"))?;

        let storage_local_path =
            optional("STORAGE_LOCAL_PATH", "/var/storage/database4u/files");
        let temp_upload_path = optional("TEMP_UPLOAD_PATH", "/var/storage/database4u/tmp");

        let settings = Self {
            host,
            port,
            database_url,
            master_encryption_key,
            environment,
            access_token_ttl_minutes,
            refresh_token_ttl_days,
            password_reset_ttl_minutes,
            db_max_connections,
            query_timeout_seconds,
            global_pool_budget,
            storage_local_path,
            temp_upload_path,
        };

        settings.validate()?;
        Ok(settings)
    }

    /// Fail fast on unsafe production configuration. Never silently fall back to defaults.
    fn validate(&self) -> Result<(), ConfigError> {
        if self.master_encryption_key.expose_len() != 64 {
            return Err(ConfigError::Invalid {
                name: "MASTER_ENCRYPTION_KEY",
                reason: "expected 64 hexadecimal characters (32 bytes)".to_string(),
            });
        }
        if !self
            .master_encryption_key
            .expose_secret()
            .chars()
            .all(|c| c.is_ascii_hexdigit())
        {
            return Err(ConfigError::Invalid {
                name: "MASTER_ENCRYPTION_KEY",
                reason: "expected hexadecimal characters only".to_string(),
            });
        }
        if self.db_max_connections == 0 {
            return Err(ConfigError::Invalid {
                name: "DB_MAX_CONNECTIONS",
                reason: "must be greater than zero".to_string(),
            });
        }
        if self.access_token_ttl_minutes <= 0 || self.refresh_token_ttl_days <= 0 {
            return Err(ConfigError::Invalid {
                name: "ACCESS_TOKEN_TTL_MINUTES",
                reason: "token lifetimes must be positive".to_string(),
            });
        }
        if self.environment.is_production() && self.host == "0.0.0.0" {
            return Err(ConfigError::Unsafe(
                "backend must not bind to a public interface; use 127.0.0.1 behind the reverse proxy"
                    .to_string(),
            ));
        }
        Ok(())
    }

    /// Redacted database URL safe enough for logs (no credentials).
    pub fn redacted_database_url(&self) -> String {
        match self.database_url.split_once("://") {
            Some((scheme, rest)) => match rest.split_once('@') {
                Some((_, host_part)) => format!("{scheme}://<redacted>@{host_part}"),
                None => format!("{scheme}://<redacted>"),
            },
            None => "<redacted>".to_string(),
        }
    }
}

// `expose_len` helper keeps `secrecy` usage local to this module.
use secrecy::ExposeSecret;

trait SecretLen {
    fn expose_len(&self) -> usize;
}

impl SecretLen for SecretString {
    fn expose_len(&self) -> usize {
        self.expose_secret().len()
    }
}
