use std::sync::Arc;

use secrecy::ExposeSecret;
use tokio::net::TcpListener;

use database_manager::api::routes::create_router;
use database_manager::app_state::AppState;
use database_manager::config::Settings;
use database_manager::connections::lifecycle::spawn_eviction_worker;
use database_manager::connections::pool::manager::PoolManager;
use database_manager::files::cleanup::spawn_cleanup_worker;
use database_manager::files::storage::LocalStorageAdapter;
use database_manager::infrastructure::encryption::CryptoEngine;
use database_manager::infrastructure::logging;
use database_manager::infrastructure::postgres::pool::{create_pool, run_migrations};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let _ = dotenvy::dotenv();

    let settings = Settings::from_env()?;
    logging::init(&settings.environment.to_string());

    tracing::info!(
        environment = %settings.environment,
        address = %format!("{}:{}", settings.host, settings.port),
        database = %settings.redacted_database_url(),
        "starting database4u backend"
    );

    let db = create_pool(&settings.database_url, settings.db_max_connections).await?;
    run_migrations(&db).await?;

    let crypto = CryptoEngine::from_hex_key(settings.master_encryption_key.expose_secret())
        .map_err(|e| anyhow::anyhow!("invalid master encryption key: {e}"))?;

    let pools = Arc::new(PoolManager::new(settings.global_pool_budget));
    let _eviction = spawn_eviction_worker(
        pools.clone(),
        std::time::Duration::from_secs(60),
        std::time::Duration::from_secs(300),
    );

    let storage = Arc::new(
        LocalStorageAdapter::new(&settings.storage_local_path, &settings.temp_upload_path).await?,
    );

    let _cleanup = spawn_cleanup_worker(
        db.clone(),
        storage.clone(),
        std::time::Duration::from_secs(3600), // check every hour
        7,                                    // 7 days retention
    );

    let state = AppState::new(
        db.clone(),
        Arc::new(settings.clone()),
        Arc::new(crypto),
        pools.clone(),
        storage,
    );

    let app = create_router(state);
    let listener = TcpListener::bind((settings.host.as_str(), settings.port)).await?;

    tracing::info!("listening on {}", listener.local_addr()?);

    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await?;

    tracing::info!("shutting down: closing database pools");
    pools.close_all().await;
    db.close().await;

    Ok(())
}

/// Wait for Ctrl-C or SIGTERM. The server stops accepting new work, active requests are
/// given a bounded grace period by `axum::serve`, then pools are drained.
async fn shutdown_signal() {
    let ctrl_c = async {
        let _ = tokio::signal::ctrl_c().await;
    };

    #[cfg(unix)]
    let terminate = async {
        match tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate()) {
            Ok(mut signal) => {
                signal.recv().await;
            }
            Err(_) => std::future::pending::<()>().await,
        }
    };

    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => {},
        _ = terminate => {},
    }
}
