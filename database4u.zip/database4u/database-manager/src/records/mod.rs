use axum::extract::{Query, State};
use axum::Json;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::ApiResponse;
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::common::validation::{quote_identifier, quote_qualified, validate_identifier};
use crate::connections::isolation::access::require_target_permission;
use crate::connections::service as connection_service;

const DEFAULT_LIMIT: i64 = 100;
const MAX_LIMIT: i64 = 500;

#[derive(Debug, Deserialize)]
pub struct RecordsQuery {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub page: Option<i64>,
    pub limit: Option<i64>,
    pub sort: Option<String>,
    pub order: Option<String>,
    /// Exact-match filter on one column (`filter_column` is validated against the
    /// table's real columns, the value is always bound).
    pub filter_column: Option<String>,
    pub filter_value: Option<String>,
    /// Case-insensitive substring search across every column (cast to text).
    pub search: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct BulkInsertRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub rows: Vec<Value>,
}

#[derive(Debug, Deserialize)]
pub struct InsertRecordRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub values: Value,
}

#[derive(Debug, Deserialize)]
pub struct UpdateRecordRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub pk_column: String,
    pub pk_value: Value,
    pub values: Value,
}

#[derive(Debug, Deserialize)]
pub struct DeleteRecordRequest {
    pub database_target_id: Uuid,
    pub schema: Option<String>,
    pub table: String,
    pub pk_column: String,
    pub pk_value: Value,
}

#[derive(Debug, Serialize)]
pub struct RecordsPage {
    pub items: Vec<Value>,
    pub total: i64,
    pub page: i64,
    pub limit: i64,
    pub has_more: bool,
}

fn schema_of(schema: &Option<String>) -> String {
    schema.clone().unwrap_or_else(|| "public".to_string())
}

/// Primary-key columns in ordinal order (empty when the table has no PK).
async fn primary_key_columns(
    pool: &sqlx::PgPool,
    schema: &str,
    table: &str,
) -> Result<Vec<String>, AppError> {
    let rows = sqlx::query_scalar::<_, String>(
        r#"SELECT a.attname
           FROM pg_index i
           JOIN pg_class c ON c.oid = i.indrelid
           JOIN pg_namespace n ON n.oid = c.relnamespace
           JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum = ANY(i.indkey)
           WHERE i.indisprimary AND n.nspname = $1 AND c.relname = $2
           ORDER BY array_position(i.indkey, a.attnum)"#,
    )
    .bind(schema)
    .bind(table)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

async fn column_names(
    pool: &sqlx::PgPool,
    schema: &str,
    table: &str,
) -> Result<Vec<String>, AppError> {
    let rows = sqlx::query_scalar::<_, String>(
        "SELECT column_name FROM information_schema.columns WHERE table_schema = $1 AND table_name = $2",
    )
    .bind(schema)
    .bind(table)
    .fetch_all(pool)
    .await?;

    if rows.is_empty() {
        return Err(AppError::NotFound("table not found".into()));
    }
    Ok(rows)
}

pub async fn list_records(
    State(state): State<AppState>,
    user: AuthUser,
    Query(query): Query<RecordsQuery>,
) -> Result<Json<ApiResponse<RecordsPage>>, AppError> {
    require_target_permission(&state.db, user.user_id, query.database_target_id, "database.read")
        .await?;

    let schema = schema_of(&query.schema);
    validate_identifier(&schema)?;
    validate_identifier(&query.table)?;
    let table = quote_qualified(&schema, &query.table)?;

    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, query.database_target_id).await?;

    let columns = column_names(&entry.pool, &schema, &query.table).await?;

    // Default ordering prefers the primary key so pagination is stable.
    let default_sort = match primary_key_columns(&entry.pool, &schema, &query.table).await? {
        keys if !keys.is_empty() => keys[0].clone(),
        _ => columns[0].clone(),
    };

    let sort = match query.sort.as_deref() {
        Some(sort) => {
            let valid = columns.iter().any(|c| c == sort);
            if !valid {
                return Err(AppError::Validation("invalid sort column".into()));
            }
            quote_identifier(sort)?
        }
        None => quote_identifier(&default_sort)?,
    };

    let direction = match query.order.as_deref().unwrap_or("asc").to_ascii_lowercase().as_str() {
        "asc" => "ASC",
        "desc" => "DESC",
        _ => return Err(AppError::Validation("order must be asc or desc".into())),
    };

    // -- filters (values are always bound, never interpolated) ----------------
    let mut conditions: Vec<String> = Vec::new();
    let mut params: Vec<String> = Vec::new();

    if let Some(column) = query.filter_column.as_deref() {
        if !columns.iter().any(|c| c == column) {
            return Err(AppError::Validation("invalid filter column".into()));
        }
        if let Some(value) = query.filter_value.as_deref() {
            params.push(value.to_string());
            conditions.push(format!(
                "{}::text = ${}",
                quote_identifier(column)?,
                params.len()
            ));
        }
    }

    if let Some(search) = query.search.as_deref() {
        let term = format!("%{}%", escape_like(search));
        params.push(term);
        let placeholder = params.len();
        let ors = columns
            .iter()
            .map(|column| {
                quote_identifier(column)
                    .map(|quoted| format!("{quoted}::text ILIKE ${placeholder}"))
            })
            .collect::<Result<Vec<_>, _>>()?
            .join(" OR ");
        conditions.push(format!("({ors})"));
    }

    let where_clause = if conditions.is_empty() {
        String::new()
    } else {
        format!(" WHERE {}", conditions.join(" AND "))
    };

    let limit = query.limit.unwrap_or(DEFAULT_LIMIT).clamp(1, MAX_LIMIT);
    let page = query.page.unwrap_or(1).max(1);
    let offset = (page - 1) * limit;

    let count_sql = format!("SELECT count(*) FROM {table}{where_clause}");
    let mut count_query = sqlx::query_scalar::<_, i64>(&count_sql);
    for param in &params {
        count_query = count_query.bind(param);
    }
    let total = count_query.fetch_one(&entry.pool).await?;

    let limit_placeholder = params.len() + 1;
    let offset_placeholder = params.len() + 2;
    let sql = format!(
        "SELECT to_jsonb(t) FROM {table} t{where_clause} ORDER BY {sort} {direction} LIMIT ${limit_placeholder} OFFSET ${offset_placeholder}"
    );

    let mut items_query = sqlx::query_scalar::<_, Value>(&sql);
    for param in &params {
        items_query = items_query.bind(param);
    }
    let items = items_query
        .bind(limit)
        .bind(offset)
        .fetch_all(&entry.pool)
        .await?;

    Ok(Json(ApiResponse::ok(RecordsPage {
        has_more: page * limit < total,
        items,
        total,
        page,
        limit,
    })))
}

/// Escape LIKE wildcards so a user-supplied `%` or `_` is treated literally.
fn escape_like(raw: &str) -> String {
    let mut escaped = String::with_capacity(raw.len());
    for ch in raw.chars() {
        match ch {
            '%' | '_' | '\\' => {
                escaped.push('\\');
                escaped.push(ch);
            }
            other => escaped.push(other),
        }
    }
    escaped
}

pub async fn insert_record(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<InsertRecordRequest>,
) -> Result<Json<ApiResponse<Value>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "database.write")
        .await?;
    if !request.values.is_object() {
        return Err(AppError::BadRequest("values must be a JSON object".into()));
    }

    let schema = schema_of(&request.schema);
    validate_identifier(&schema)?;
    validate_identifier(&request.table)?;
    let table = quote_qualified(&schema, &request.table)?;

    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;

    let columns = column_names(&entry.pool, &schema, &request.table).await?;
    let keys = validate_object_keys(&request.values, &columns)?;
    if keys.is_empty() {
        return Err(AppError::BadRequest(
            "values must not be empty".into(),
        ));
    }
    let column_list = keys
        .iter()
        .map(|key| quote_identifier(key))
        .collect::<Result<Vec<_>, _>>()?
        .join(", ");

    // List only the supplied columns so PostgreSQL defaults and generated values apply
    // to everything the caller left out.
    let sql = format!(
        "INSERT INTO {table} AS t ({column_list}) \
         SELECT {column_list} FROM jsonb_populate_record(NULL::{table}, $1::jsonb) \
         RETURNING to_jsonb(t)"
    );

    let row = sqlx::query_scalar::<_, Value>(&sql)
        .bind(&request.values)
        .fetch_one(&entry.pool)
        .await
        .map_err(map_pg_error)?;

    Ok(Json(ApiResponse::ok(row)))
}

const MAX_BULK_ROWS: usize = 500;

/// Insert many rows in one round-trip.
///
/// `jsonb_populate_recordset` performs the type coercion, so a bad value aborts the whole
/// statement (no partial insert).
pub async fn bulk_insert_records(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<BulkInsertRequest>,
) -> Result<Json<ApiResponse<Vec<Value>>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "database.write")
        .await?;

    if request.rows.is_empty() {
        return Err(AppError::BadRequest("rows must not be empty".into()));
    }
    if request.rows.len() > MAX_BULK_ROWS {
        return Err(AppError::BadRequest(format!(
            "at most {MAX_BULK_ROWS} rows per bulk insert"
        )));
    }

    let schema = schema_of(&request.schema);
    validate_identifier(&schema)?;
    validate_identifier(&request.table)?;
    let table = quote_qualified(&schema, &request.table)?;

    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;

    let columns = column_names(&entry.pool, &schema, &request.table).await?;

    // Every row must use the same column set: a single `INSERT ... SELECT` applies one
    // column list to all rows, so silently mixing shapes would turn missing fields into
    // NULL instead of their defaults.
    let keys = validate_object_keys(&request.rows[0], &columns)?;
    if keys.is_empty() {
        return Err(AppError::BadRequest("rows must not be empty".into()));
    }
    for row in &request.rows {
        if validate_object_keys(row, &columns)? != keys {
            return Err(AppError::BadRequest(
                "every row in a bulk insert must use the same columns".into(),
            ));
        }
    }
    let column_list = keys
        .iter()
        .map(|key| quote_identifier(key))
        .collect::<Result<Vec<_>, _>>()?
        .join(", ");

    let payload = Value::Array(request.rows);

    let sql = format!(
        "INSERT INTO {table} AS t ({column_list}) \
         SELECT {column_list} FROM jsonb_populate_recordset(NULL::{table}, $1::jsonb) \
         RETURNING to_jsonb(t)"
    );

    let rows = sqlx::query_scalar::<_, Value>(&sql)
        .bind(&payload)
        .fetch_all(&entry.pool)
        .await
        .map_err(map_pg_error)?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "records.bulk_insert",
        "table",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(rows)))
}

pub async fn update_record(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<UpdateRecordRequest>,
) -> Result<Json<ApiResponse<Value>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "database.write")
        .await?;
    if !request.values.is_object() || request.values.as_object().map(|o| o.is_empty()).unwrap_or(true)
    {
        return Err(AppError::BadRequest(
            "values must be a non-empty JSON object".into(),
        ));
    }

    let schema = schema_of(&request.schema);
    validate_identifier(&schema)?;
    validate_identifier(&request.table)?;
    validate_identifier(&request.pk_column)?;
    let table = quote_qualified(&schema, &request.table)?;

    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;

    let columns = column_names(&entry.pool, &schema, &request.table).await?;
    validate_object_keys(&request.values, &columns)?;

    let object = request.values.as_object().unwrap();
    let assignments = object
        .keys()
        .map(|key| quote_identifier(key))
        .collect::<Result<Vec<_>, _>>()?
        .join(", ");

    let sql = format!(
        r#"UPDATE {table} AS t
           SET ({assignments}) = (
               SELECT {assignments} FROM jsonb_populate_record(NULL::{table}, $2::jsonb)
           )
           WHERE t.{}::text = $1
           RETURNING to_jsonb(t)"#,
        quote_identifier(&request.pk_column)?
    );

    let pk = value_to_text(&request.pk_value);

    let row = sqlx::query_scalar::<_, Value>(&sql)
        .bind(pk)
        .bind(&request.values)
        .fetch_optional(&entry.pool)
        .await
        .map_err(map_pg_error)?
        .ok_or_else(|| AppError::NotFound("record not found".into()))?;

    Ok(Json(ApiResponse::ok(row)))
}

pub async fn delete_record(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<DeleteRecordRequest>,
) -> Result<Json<ApiResponse<Value>>, AppError> {
    require_target_permission(&state.db, user.user_id, request.database_target_id, "database.write")
        .await?;

    let schema = schema_of(&request.schema);
    validate_identifier(&schema)?;
    validate_identifier(&request.table)?;
    validate_identifier(&request.pk_column)?;
    let table = quote_qualified(&schema, &request.table)?;

    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id).await?;

    let sql = format!(
        "DELETE FROM {table} AS t WHERE t.{}::text = $1 RETURNING to_jsonb(t)",
        quote_identifier(&request.pk_column)?
    );

    let pk = value_to_text(&request.pk_value);

    let row = sqlx::query_scalar::<_, Value>(&sql)
        .bind(pk)
        .fetch_optional(&entry.pool)
        .await
        .map_err(map_pg_error)?
        .ok_or_else(|| AppError::NotFound("record not found".into()))?;

    Ok(Json(ApiResponse::ok(row)))
}

/// Validate that every JSON key is a real column and return the key set in a stable
/// order (serde's default map ordering), so SQL can list the supplied columns.
fn validate_object_keys(values: &Value, columns: &[String]) -> Result<Vec<String>, AppError> {
    let object = values
        .as_object()
        .ok_or_else(|| AppError::BadRequest("values must be a JSON object".into()))?;

    let mut keys = Vec::with_capacity(object.len());
    for key in object.keys() {
        if !columns.iter().any(|column| column == key) {
            return Err(AppError::Validation(format!("unknown column: {key}")));
        }
        keys.push(key.clone());
    }
    Ok(keys)
}

fn value_to_text(value: &Value) -> String {
    match value {
        Value::String(text) => text.clone(),
        other => other.to_string(),
    }
}

fn map_pg_error(error: sqlx::Error) -> AppError {
    match &error {
        sqlx::Error::Database(db) if db.is_unique_violation() => {
            AppError::Conflict("unique constraint violated".into())
        }
        sqlx::Error::Database(db) if db.code().as_deref() == Some("23503") => {
            AppError::Conflict("foreign key constraint violated".into())
        }
        sqlx::Error::Database(db) if db.is_check_violation() => {
            AppError::BadRequest("check constraint violated".into())
        }
        sqlx::Error::Database(db) => {
            let message: String = db
                .message()
                .chars()
                .filter(|c| !c.is_control())
                .take(200)
                .collect();
            AppError::BadRequest(message)
        }
        other => AppError::Database(other.clone()),
    }
}
