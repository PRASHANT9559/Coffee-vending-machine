//! Destination policy: the backend must never be tricked into connecting to
//! loopback services, link-local metadata endpoints or other internal networks.
//!
//! The check runs on the *resolved* IP addresses, immediately before connecting,
//! which also mitigates DNS rebinding (the name is not resolved a second time).

use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

/// Why a destination was rejected. The message is safe to surface to the user.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DestinationError {
    Loopback,
    LinkLocal,
    Unspecified,
    Multicast,
    Broadcast,
    Reserved,
}

impl DestinationError {
    pub fn message(&self) -> &'static str {
        match self {
            Self::Loopback => "destination resolves to a loopback address",
            Self::LinkLocal => "destination resolves to a link-local/metadata address",
            Self::Unspecified => "destination resolves to an unspecified address",
            Self::Multicast => "destination resolves to a multicast address",
            Self::Broadcast => "destination resolves to a broadcast address",
            Self::Reserved => "destination resolves to a reserved address",
        }
    }
}

/// Classify one address.
///
/// Loopback is rejected by default. Local development can opt in explicitly via
/// [`DestinationPolicy::allow_loopback`].
pub fn classify(ip: &IpAddr, allow_loopback: bool) -> Result<(), DestinationError> {
    match ip {
        IpAddr::V4(v4) => classify_v4(v4, allow_loopback),
        IpAddr::V6(v6) => classify_v6(v6, allow_loopback),
    }
}

fn classify_v4(ip: &Ipv4Addr, allow_loopback: bool) -> Result<(), DestinationError> {
    if ip.is_loopback() {
        return if allow_loopback {
            Ok(())
        } else {
            Err(DestinationError::Loopback)
        };
    }
    if ip.is_link_local() {
        return Err(DestinationError::LinkLocal);
    }
    if ip.is_unspecified() {
        return Err(DestinationError::Unspecified);
    }
    if ip.is_multicast() {
        return Err(DestinationError::Multicast);
    }
    if ip.is_broadcast() {
        return Err(DestinationError::Broadcast);
    }
    // 0.0.0.0/8 "this network" and 240.0.0.0/4 reserved.
    let octets = ip.octets();
    if octets[0] == 0 || octets[0] >= 240 {
        return Err(DestinationError::Reserved);
    }
    Ok(())
}

fn classify_v6(ip: &Ipv6Addr, allow_loopback: bool) -> Result<(), DestinationError> {
    if ip.is_loopback() {
        return if allow_loopback {
            Ok(())
        } else {
            Err(DestinationError::Loopback)
        };
    }
    if ip.is_unspecified() {
        return Err(DestinationError::Unspecified);
    }
    if ip.is_multicast() {
        return Err(DestinationError::Multicast);
    }
    // Unique-local (fc00::/7) and link-local (fe80::/10) are internal networks.
    let segments = ip.segments();
    if (segments[0] & 0xfe00) == 0xfc00 {
        return Err(DestinationError::Reserved);
    }
    if (segments[0] & 0xffc0) == 0xfe80 {
        return Err(DestinationError::LinkLocal);
    }
    Ok(())
}

/// Policy applied to every outbound database connection.
///
/// A database manager legitimately connects to loopback and RFC1918 hosts (local and
/// LAN servers), so those are allowed by default. Cloud metadata endpoints and reserved
/// ranges are always blocked. Deployments that only allow public targets can use
/// [`DestinationPolicy::public_only`].
#[derive(Debug, Clone, Copy)]
pub struct DestinationPolicy {
    pub allow_loopback: bool,
    pub allow_private: bool,
}

impl Default for DestinationPolicy {
    fn default() -> Self {
        Self {
            allow_loopback: true,
            allow_private: true,
        }
    }
}

impl DestinationPolicy {
    /// Development profile — identical to the default; kept for explicitness.
    pub fn local_development() -> Self {
        Self::default()
    }

    /// Deny loopback and private ranges (public cloud deployments).
    pub fn public_only() -> Self {
        Self {
            allow_loopback: false,
            allow_private: false,
        }
    }

    pub fn validate(&self, ip: &IpAddr) -> Result<(), DestinationError> {
        classify(ip, self.allow_loopback)?;
        if !self.allow_private && is_private(ip) {
            return Err(DestinationError::Reserved);
        }
        Ok(())
    }

    pub fn validate_all<'a, I>(&self, addresses: I) -> Result<(), DestinationError>
    where
        I: IntoIterator<Item = &'a IpAddr>,
    {
        for ip in addresses {
            self.validate(ip)?;
        }
        Ok(())
    }
}

fn is_private(ip: &IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => v4.is_private() || v4.is_loopback() || v4.is_link_local(),
        IpAddr::V6(v6) => {
            let segments = v6.segments();
            v6.is_loopback() || (segments[0] & 0xfe00) == 0xfc00 || (segments[0] & 0xffc0) == 0xfe80
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ip(raw: &str) -> IpAddr {
        raw.parse().unwrap()
    }

    #[test]
    fn blocks_metadata_by_default() {
        let policy = DestinationPolicy::default();
        assert!(policy.validate(&ip("169.254.169.254")).is_err());
        assert!(policy.validate(&ip("0.0.0.0")).is_err());
        assert!(policy.validate(&ip("224.0.0.1")).is_err());
    }

    #[test]
    fn allows_loopback_and_private_by_default() {
        let policy = DestinationPolicy::default();
        assert!(policy.validate(&ip("127.0.0.1")).is_ok());
        assert!(policy.validate(&ip("::1")).is_ok());
        assert!(policy.validate(&ip("192.168.1.10")).is_ok());
        assert!(policy.validate(&ip("10.0.0.5")).is_ok());
    }

    #[test]
    fn public_only_denies_internal_targets() {
        let policy = DestinationPolicy::public_only();
        assert!(policy.validate(&ip("127.0.0.1")).is_err());
        assert!(policy.validate(&ip("192.168.1.10")).is_err());
        assert!(policy.validate(&ip("93.184.216.34")).is_ok());
    }

    #[test]
    fn public_addresses_pass() {
        let policy = DestinationPolicy::default();
        assert!(policy.validate(&ip("93.184.216.34")).is_ok());
        assert!(policy.validate(&ip("2606:2800:220:1:248:1893:25c8:1946")).is_ok());
    }
}
