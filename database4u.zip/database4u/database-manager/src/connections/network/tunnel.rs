//! Generic tunnel abstraction.
//!
//! A tunnel maps a local socket to a remote database endpoint. Implementations must
//! tear the forwarder down when dropped so a closed profile never leaves a listener
//! behind.

use std::net::SocketAddr;

use async_trait::async_trait;

/// A live local forwarder.
#[async_trait]
pub trait Tunnel: Send + Sync {
    /// Local address a client should connect to (usually `127.0.0.1:<ephemeral>`).
    fn local_address(&self) -> SocketAddr;

    /// Destination the tunnel ultimately reaches (for health/metrics only).
    fn remote_target(&self) -> String;

    /// Stop accepting new connections and close the listener.
    async fn shutdown(&self) -> Result<(), String>;
}

/// Tunnel kinds supported by the backend.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TunnelKind {
    None,
    Ssh,
}

impl TunnelKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::None => "none",
            Self::Ssh => "ssh",
        }
    }
}
