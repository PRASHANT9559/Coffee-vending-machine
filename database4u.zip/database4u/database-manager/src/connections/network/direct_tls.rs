//! Direct TLS route: PostgreSQL over the public internet with certificate verification.
//!
//! All TLS options are derived from [`TlsMode`]; the backend never silently downgrades
//! verification for a remote host.

use sqlx::postgres::PgConnectOptions;

use crate::connections::config::ssl::TlsMode;
use crate::infrastructure::postgres::connection::map_ssl_mode;

use super::resolver::ResolveError;
use super::security::{DestinationError, DestinationPolicy};

#[derive(Debug)]
pub enum RouteError {
    Resolve(ResolveError),
    Denied(DestinationError),
    InsecureMode(TlsMode),
}

impl RouteError {
    pub fn message(&self) -> String {
        match self {
            Self::Resolve(error) => error.message(),
            Self::Denied(error) => error.message().to_string(),
            Self::InsecureMode(mode) => format!(
                "tls mode '{}' is not permitted for remote connections",
                mode.as_str()
            ),
        }
    }
}

/// Enforce the production stance: a remote (non-loopback) target must use
/// `verify_ca` or `verify_full`.
pub fn enforce_remote_tls_mode(host_is_loopback: bool, tls: TlsMode) -> Result<(), RouteError> {
    if !host_is_loopback && !tls.is_secure() {
        return Err(RouteError::InsecureMode(tls));
    }
    Ok(())
}

/// Build validated SQLx options for a direct route.
///
/// `resolved` must have already been produced by
/// [`super::resolver::resolve`] so the destination cannot change underneath us.
pub fn direct_options(
    host: &str,
    port: u16,
    username: &str,
    database: &str,
    tls: TlsMode,
    policy: &DestinationPolicy,
    resolved: &[std::net::SocketAddr],
) -> Result<PgConnectOptions, RouteError> {
    for address in resolved {
        policy
            .validate(&address.ip())
            .map_err(RouteError::Denied)?;
    }

    Ok(PgConnectOptions::new()
        .host(host)
        .port(port)
        .username(username)
        .database(database)
        .application_name("database4u")
        .ssl_mode(map_ssl_mode(tls))
        // A lazily-created pool must not reuse a prepared statement tied to another
        // logical database.
        .statement_cache_capacity(0))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn remote_requires_verification() {
        assert!(enforce_remote_tls_mode(false, TlsMode::Disable).is_err());
        assert!(enforce_remote_tls_mode(false, TlsMode::Require).is_err());
        assert!(enforce_remote_tls_mode(false, TlsMode::VerifyFull).is_ok());
    }

    #[test]
    fn loopback_may_disable_tls() {
        assert!(enforce_remote_tls_mode(true, TlsMode::Disable).is_ok());
    }
}
