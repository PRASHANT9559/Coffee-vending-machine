//! SSH tunnel support.
//!
//! The profile schema (`connection_ssh_configs`) already stores everything needed for a
//! tunnel, but no SSH transport is compiled into this build. Rather than silently opening
//! a plain TCP route — which would be a security downgrade — the manager refuses to
//! connect and reports a clear, actionable error.

use std::net::SocketAddr;
use std::time::Duration;

use async_trait::async_trait;

use super::tunnel::{Tunnel, TunnelKind};

/// Error returned while trying to establish an SSH route.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SshError {
    Unsupported,
    InvalidConfig(&'static str),
}

impl SshError {
    pub fn message(&self) -> String {
        match self {
            Self::Unsupported => {
                "ssh tunnel support is not enabled in this build; use a direct TLS connection"
                    .to_string()
            }
            Self::InvalidConfig(field) => format!("invalid ssh configuration: {field}"),
        }
    }
}

/// Stored SSH profile (non-secret). The credential itself lives in the vault.
#[derive(Debug, Clone)]
pub struct SshProfile {
    pub ssh_host: String,
    pub ssh_port: u16,
    pub ssh_username: String,
    pub remote_host: String,
    pub remote_port: u16,
    pub connect_timeout: Duration,
}

impl SshProfile {
    pub fn validate(&self) -> Result<(), SshError> {
        if self.ssh_host.trim().is_empty() {
            return Err(SshError::InvalidConfig("ssh_host"));
        }
        if self.ssh_port == 0 {
            return Err(SshError::InvalidConfig("ssh_port"));
        }
        if self.ssh_username.trim().is_empty() {
            return Err(SshError::InvalidConfig("ssh_username"));
        }
        if self.remote_host.trim().is_empty() {
            return Err(SshError::InvalidConfig("remote_host"));
        }
        if self.remote_port == 0 {
            return Err(SshError::InvalidConfig("remote_port"));
        }
        if self.connect_timeout.is_zero() {
            return Err(SshError::InvalidConfig("connect_timeout"));
        }
        Ok(())
    }
}

/// Placeholder tunnel that can never be opened in this build.
pub struct UnsupportedTunnel {
    local: SocketAddr,
    remote: String,
}

impl UnsupportedTunnel {
    /// Always fails: callers must not fall back to a direct route.
    pub fn open(_profile: &SshProfile) -> Result<Self, SshError> {
        Err(SshError::Unsupported)
    }

    pub fn kind(&self) -> TunnelKind {
        TunnelKind::Ssh
    }
}

#[async_trait]
impl Tunnel for UnsupportedTunnel {
    fn local_address(&self) -> SocketAddr {
        self.local
    }

    fn remote_target(&self) -> String {
        self.remote.clone()
    }

    async fn shutdown(&self) -> Result<(), String> {
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn profile() -> SshProfile {
        SshProfile {
            ssh_host: "bastion.example.com".into(),
            ssh_port: 22,
            ssh_username: "deploy".into(),
            remote_host: "127.0.0.1".into(),
            remote_port: 5432,
            connect_timeout: Duration::from_secs(5),
        }
    }

    #[test]
    fn profile_validates() {
        assert!(profile().validate().is_ok());
    }

    #[test]
    fn rejects_blank_host() {
        let mut invalid = profile();
        invalid.ssh_host = "  ".into();
        assert_eq!(invalid.validate(), Err(SshError::InvalidConfig("ssh_host")));
    }

    #[test]
    fn open_fails_closed() {
        assert_eq!(
            UnsupportedTunnel::open(&profile()).err(),
            Some(SshError::Unsupported)
        );
    }
}
