//! DNS resolution with destination pinning.
//!
//! The resolver returns concrete [`SocketAddr`] values; the caller connects to those
//! addresses directly instead of re-resolving the hostname. That closes the classic
//! DNS-rebinding window between "check the IP" and "connect to the host".

use std::net::{IpAddr, SocketAddr};
use std::time::Duration;

use super::security::{DestinationError, DestinationPolicy};

#[derive(Debug)]
pub enum ResolveError {
    /// Name could not be resolved (no addresses, NXDOMAIN, DNS failure).
    Dns,
    /// Resolution exceeded the configured timeout.
    Timeout,
    /// Every resolved address failed the destination policy.
    Denied(DestinationError),
}

impl ResolveError {
    pub fn message(&self) -> String {
        match self {
            Self::Dns => "host name could not be resolved".to_string(),
            Self::Timeout => "name resolution timed out".to_string(),
            Self::Denied(error) => error.message().to_string(),
        }
    }
}

/// Resolve `host` and validate all addresses against `policy`.
pub async fn resolve(
    host: &str,
    port: u16,
    timeout: Duration,
    policy: &DestinationPolicy,
) -> Result<Vec<SocketAddr>, ResolveError> {
    let lookup = tokio::time::timeout(timeout, tokio::net::lookup_host((host, port)))
        .await
        .map_err(|_| ResolveError::Timeout)?
        .map_err(|_| ResolveError::Dns)?;

    let mut addresses: Vec<SocketAddr> = Vec::new();
    for address in lookup {
        policy
            .validate(&address.ip())
            .map_err(ResolveError::Denied)?;
        addresses.push(address);
    }

    if addresses.is_empty() {
        return Err(ResolveError::Dns);
    }
    Ok(addresses)
}

/// Convenience helper for code that only needs the distinct IP addresses.
pub async fn resolve_ips(
    host: &str,
    port: u16,
    timeout: Duration,
    policy: &DestinationPolicy,
) -> Result<Vec<IpAddr>, ResolveError> {
    Ok(resolve(host, port, timeout, policy)
        .await?
        .into_iter()
        .map(|address| address.ip())
        .collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn public_only_policy_rejects_loopback_host() {
        let policy = DestinationPolicy::public_only();
        // `localhost` resolves to loopback, which the public-only policy denies.
        let result = resolve("localhost", 5432, Duration::from_secs(2), &policy).await;
        assert!(matches!(result, Err(ResolveError::Denied(_))));
    }

    #[tokio::test]
    async fn default_policy_accepts_loopback() {
        let policy = DestinationPolicy::default();
        let result = resolve("localhost", 5432, Duration::from_secs(2), &policy).await;
        assert!(result.is_ok());
    }
}
