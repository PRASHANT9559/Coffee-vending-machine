//! TCP connector that only dials pre-validated socket addresses.

use std::net::SocketAddr;
use std::time::{Duration, Instant};

use tokio::net::TcpStream;

use super::resolver::ResolveError;

#[derive(Debug)]
pub enum ConnectError {
    Timeout,
    Refused,
    Io(String),
}

impl ConnectError {
    pub fn message(&self) -> String {
        match self {
            Self::Timeout => "tcp connection timed out".to_string(),
            Self::Refused => "tcp connection refused".to_string(),
            Self::Io(_) => "tcp connection failed".to_string(),
        }
    }
}

/// Try each validated address in order until one connects.
/// Returns the stream and the address that answered.
pub async fn connect_any(
    addresses: &[SocketAddr],
    timeout: Duration,
) -> Result<(TcpStream, SocketAddr, u64), ConnectError> {
    let started = Instant::now();
    let mut last_error = ConnectError::Refused;

    for address in addresses {
        match tokio::time::timeout(timeout, TcpStream::connect(*address)).await {
            Ok(Ok(stream)) => {
                let elapsed = started.elapsed().as_millis() as u64;
                let _ = stream.set_nodelay(true);
                return Ok((stream, *address, elapsed));
            }
            Ok(Err(error)) => {
                last_error = ConnectError::Io(error.to_string());
            }
            Err(_) => {
                last_error = ConnectError::Timeout;
            }
        }
    }

    Err(last_error)
}

/// Map a resolver failure into the connector's error surface.
impl From<ResolveError> for ConnectError {
    fn from(error: ResolveError) -> Self {
        match error {
            ResolveError::Timeout => Self::Timeout,
            _ => Self::Io(error.message()),
        }
    }
}
