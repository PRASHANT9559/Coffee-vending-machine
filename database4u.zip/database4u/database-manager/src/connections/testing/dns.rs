// DNS test step
