// Database authentication testing
