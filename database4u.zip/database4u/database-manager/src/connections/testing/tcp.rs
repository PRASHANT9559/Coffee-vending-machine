// TCP connectivity test step
