// TLS certificate verification test step
