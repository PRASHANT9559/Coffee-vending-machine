use std::time::{Duration, Instant};

use secrecy::SecretString;
use sqlx::postgres::PgConnectOptions;
use sqlx::Connection;

use crate::connections::config::ssl::TlsMode;
use crate::connections::config::validation::validate_host;
use crate::connections::dto::StageResult;
use crate::connections::network::connector;
use crate::connections::network::resolver;
use crate::connections::network::security::DestinationPolicy;

/// Parameters for a one-off connection test. Never persisted, never pooled.
pub struct TestTarget {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub database: String,
    pub tls: TlsMode,
    pub timeout: Duration,
}

impl TestTarget {
    fn connect_options(&self, password: &SecretString) -> PgConnectOptions {
        use secrecy::ExposeSecret;
        PgConnectOptions::new()
            .host(&self.host)
            .port(self.port)
            .username(&self.username)
            .password(password.expose_secret())
            .database(&self.database)
            .application_name("database4u-test")
            .ssl_mode(crate::infrastructure::postgres::connection::map_ssl_mode(self.tls))
            .statement_cache_capacity(0)
    }
}

/// Run the staged connection test:
/// DNS → TCP → TLS/authentication → database permissions.
///
/// The temporary connection is closed before returning; no pool is created.
pub async fn run_test(target: &TestTarget, password: &SecretString) -> (Vec<StageResult>, bool) {
    let mut stages = Vec::new();
    let mut success = true;

    // 1. Host format
    let started = Instant::now();
    match validate_host(&target.host) {
        Ok(host) => {
            stages.push(StageResult {
                stage: "host",
                ok: true,
                elapsed_ms: started.elapsed().as_millis() as u64,
                detail: Some(host),
            });
        }
        Err(exists) => {
            stages.push(StageResult {
                stage: "host",
                ok: false,
                elapsed_ms: started.elapsed().as_millis() as u64,
                detail: Some(exists.to_string()),
            });
            return (stages, false);
        }
    }

    // 2. DNS + destination policy (addresses are pinned for the TCP step).
    let started = Instant::now();
    let policy = DestinationPolicy::default();
    let addresses = match resolver::resolve(&target.host, target.port, target.timeout, &policy).await
    {
        Ok(addresses) => {
            stages.push(StageResult {
                stage: "dns",
                ok: true,
                elapsed_ms: started.elapsed().as_millis() as u64,
                detail: Some(format!("{} address(es) validated", addresses.len())),
            });
            addresses
        }
        Err(error) => {
            stages.push(failed("dns", started, &error.message()));
            return (stages, false);
        }
    };

    // 3. TCP
    let started = Instant::now();
    if connector::connect_any(&addresses, target.timeout)
        .await
        .is_err()
    {
        stages.push(failed("tcp", started, "connection refused or timed out"));
        return (stages, false);
    }
    stages.push(StageResult {
        stage: "tcp",
        ok: true,
        elapsed_ms: started.elapsed().as_millis() as u64,
        detail: None,
    });

    // 4. TLS + authentication (a successful SQLx connect proves both).
    let started = Instant::now();
    let options = target.connect_options(password);
    let connect = tokio::time::timeout(target.timeout, sqlx::PgConnection::connect_with(&options)).await;

    let mut connection = match connect {
        Ok(Ok(connection)) => {
            stages.push(StageResult {
                stage: "tls_authentication",
                ok: true,
                elapsed_ms: started.elapsed().as_millis() as u64,
                detail: Some(format!("tls={}", target.tls.as_str())),
            });
            connection
        }
        Ok(Err(error)) => {
            stages.push(failed(
                "tls_authentication",
                started,
                &sanitize_connect_error(&error),
            ));
            return (stages, false);
        }
        Err(_) => {
            stages.push(failed("tls_authentication", started, "connection timed out"));
            return (stages, false);
        }
    };

    // 5. Permissions
    let started = Instant::now();
    let permission = sqlx::query_as::<_, (String, String, bool)>(
        r#"SELECT current_database(), current_user,
                  has_database_privilege(current_user, current_database(), 'CONNECT')"#,
    )
    .fetch_one(&mut connection)
    .await;

    match permission {
        Ok((database, user, can_connect)) if can_connect => {
            stages.push(StageResult {
                stage: "permissions",
                ok: true,
                elapsed_ms: started.elapsed().as_millis() as u64,
                detail: Some(format!("database={database} user={user}")),
            });
        }
        Ok((_, _, _)) => {
            success = false;
            stages.push(failed("permissions", started, "CONNECT privilege denied"));
        }
        Err(_) => {
            success = false;
            stages.push(failed("permissions", started, "permission check failed"));
        }
    }

    let _ = connection.close().await;
    (stages, success)
}

fn failed(stage: &'static str, started: Instant, detail: &str) -> StageResult {
    StageResult {
        stage,
        ok: false,
        elapsed_ms: started.elapsed().as_millis() as u64,
        detail: Some(detail.to_string()),
    }
}

/// Never leak driver internals or credentials back to the client.
fn sanitize_connect_error(error: &sqlx::Error) -> String {
    let text = error.to_string().to_ascii_lowercase();
    if text.contains("password authentication failed") || text.contains("authentication failed") {
        "authentication failed".to_string()
    } else if text.contains("certificate") || text.contains("tls") {
        "tls verification failed".to_string()
    } else if text.contains("does not exist") {
        "database or role does not exist".to_string()
    } else if text.contains("connection refused") {
        "connection refused".to_string()
    } else if text.contains("timeout") || text.contains("timed out") {
        "connection timed out".to_string()
    } else {
        "connection failed".to_string()
    }
}
