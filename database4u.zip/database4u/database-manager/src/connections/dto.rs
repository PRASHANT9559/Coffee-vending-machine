use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::connections::config::{NetworkMode, TlsMode};

#[derive(Debug, Deserialize)]
pub struct CreateConnectionRequest {
    pub display_name: String,
    pub host: String,
    pub port: Option<u16>,
    pub username: String,
    pub password: String,
    /// Defaults to `postgres` for discovery.
    pub database: Option<String>,
    pub scope: Option<String>,
    pub network_mode: Option<NetworkMode>,
    pub tls_mode: Option<TlsMode>,
    pub connect_timeout_secs: Option<u64>,
    pub acquire_timeout_secs: Option<u64>,
    pub idle_timeout_secs: Option<u64>,
    pub max_lifetime_secs: Option<u64>,
    /// Project that owns this connection profile.
    pub project_id: Uuid,
}

#[derive(Debug, Deserialize)]
pub struct UpdateConnectionRequest {
    pub display_name: Option<String>,
    pub host: Option<String>,
    pub port: Option<u16>,
    pub username: Option<String>,
    /// Optional rotation: only sent when the password should change.
    pub password: Option<String>,
    pub scope: Option<String>,
    pub network_mode: Option<NetworkMode>,
    pub tls_mode: Option<TlsMode>,
    pub connect_timeout_secs: Option<u64>,
    pub acquire_timeout_secs: Option<u64>,
    pub idle_timeout_secs: Option<u64>,
    pub max_lifetime_secs: Option<u64>,
    pub is_enabled: Option<bool>,
}

#[derive(Debug, Deserialize)]
pub struct TestConnectionRequest {
    /// When omitted the stored credential is used.
    pub password: Option<String>,
    /// Optional override database; defaults to the profile's configured database.
    pub database: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct ConnectRequest {
    pub database_target_id: Option<Uuid>,
}

#[derive(Debug, Deserialize)]
pub struct RotateCredentialRequest {
    /// New plaintext password. It is encrypted before touching the database and is
    /// never logged or echoed back.
    pub password: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct StageResult {
    pub stage: &'static str,
    pub ok: bool,
    pub elapsed_ms: u64,
    /// Sanitized: never includes credentials or raw driver output.
    pub detail: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct ConnectionTestReport {
    pub connection_id: Uuid,
    pub success: bool,
    pub stages: Vec<StageResult>,
    pub total_elapsed_ms: u64,
}

#[derive(Debug, Clone, Serialize)]
pub struct ConnectionHealth {
    pub connection_id: Uuid,
    pub state: &'static str,
    pub database_target_id: Option<Uuid>,
    pub pool_available: bool,
    pub latency_ms: Option<u64>,
    pub checked_at: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize)]
pub struct ConnectionMetrics {
    pub connection_id: Uuid,
    pub active_pools: usize,
    pub idle_connections: u32,
    pub in_use_connections: u32,
    pub max_connections: u32,
    pub budget_used: u32,
    pub budget_limit: u32,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct DatabaseTargetView {
    pub database_target_id: Uuid,
    pub connection_id: Uuid,
    pub database_name: String,
    pub is_enabled: bool,
    pub last_discovered_at: Option<chrono::DateTime<chrono::Utc>>,
}
