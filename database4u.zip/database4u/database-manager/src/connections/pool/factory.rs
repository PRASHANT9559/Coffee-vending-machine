//! Pool factory: builds a lazily-connecting SQLx pool from validated options.

use sqlx::postgres::{PgConnectOptions, PgPoolOptions};
use sqlx::PgPool;

use super::limits::HARD_MAX_CONNECTIONS_PER_POOL;

pub struct PoolConfig {
    pub max_connections: u32,
    pub acquire_timeout_secs: u64,
    pub idle_timeout_secs: u64,
    pub max_lifetime_secs: u64,
}

impl Default for PoolConfig {
    fn default() -> Self {
        Self {
            max_connections: super::limits::DEFAULT_MAX_CONNECTIONS_PER_POOL,
            acquire_timeout_secs: super::limits::DEFAULT_ACQUIRE_TIMEOUT_SECS,
            idle_timeout_secs: super::limits::DEFAULT_IDLE_TIMEOUT_SECS,
            max_lifetime_secs: super::limits::DEFAULT_MAX_LIFETIME_SECS,
        }
    }
}

/// Build a pool that does not open a physical connection until first use.
///
/// `connect_lazy_with` is the key to the "no 20 databases => 20 open pools" rule.
pub fn build_lazy_pool(options: PgConnectOptions, config: &PoolConfig) -> PgPool {
    PgPoolOptions::new()
        .max_connections(config.max_connections.clamp(1, HARD_MAX_CONNECTIONS_PER_POOL))
        .min_connections(0)
        .acquire_timeout(std::time::Duration::from_secs(
            config.acquire_timeout_secs.max(1),
        ))
        .idle_timeout(Some(std::time::Duration::from_secs(
            config.idle_timeout_secs.max(1),
        )))
        .max_lifetime(Some(std::time::Duration::from_secs(
            config.max_lifetime_secs.max(1),
        )))
        .connect_lazy_with(options)
}
