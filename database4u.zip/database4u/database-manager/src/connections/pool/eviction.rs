use std::time::Duration;

use crate::connections::pool::manager::PoolManager;

/// Evict idle pools once. Thin wrapper kept separate so the policy is testable.
pub async fn run_once(pools: &PoolManager, max_idle: Duration) -> usize {
    pools.evict_idle(max_idle).await
}
