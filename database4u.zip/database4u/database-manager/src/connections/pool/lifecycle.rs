//! Pool lifecycle: create → ready → draining → closed, plus explicit recreation after a
//! configuration change.
//!
//! Eviction and health checks call into the same state machine so a pool can never be
//! closed while an operation is using it.

use std::sync::Arc;
use std::time::Duration;

use uuid::Uuid;

use crate::common::errors::AppError;
use crate::connections::pool::manager::{PoolEntry, PoolManager};

use super::factory::PoolConfig;

/// Request-safe recreation: close the old pool (if any) and lazily build a new one from
/// the supplied options. Callers must re-authorize before invoking this.
pub async fn recreate(
    pools: &PoolManager,
    target_id: Uuid,
    connection_id: Uuid,
    options: sqlx::postgres::PgConnectOptions,
    config: &PoolConfig,
) -> Result<Arc<PoolEntry>, AppError> {
    pools.close(target_id).await;
    pools
        .get_or_create(target_id, connection_id, options, config)
        .await
}

/// Drain every pool for a connection. Returns how many pools were closed.
pub async fn drain(pools: &PoolManager, connection_id: Uuid) -> usize {
    pools.close_connection(connection_id).await
}

/// Idle-only eviction. A pool with in-flight work is never touched.
pub async fn evict(pools: &PoolManager, max_idle: Duration) -> usize {
    pools.evict_idle(max_idle).await
}

#[cfg(test)]
mod tests {
    use super::super::factory::PoolConfig;

    #[test]
    fn default_pool_config_is_conservative() {
        let config = PoolConfig::default();
        assert_eq!(config.max_connections, 5);
        assert_eq!(config.acquire_timeout_secs, 5);
        assert_eq!(config.idle_timeout_secs, 300);
        assert_eq!(config.max_lifetime_secs, 1800);
    }
}
