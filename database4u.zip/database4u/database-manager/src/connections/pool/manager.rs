use std::collections::HashMap;
use std::sync::Arc;
use std::time::Instant;

use sqlx::postgres::PgConnectOptions;
use sqlx::PgPool;
use tokio::sync::RwLock;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::connections::pool::factory::{build_lazy_pool, PoolConfig};
use crate::connections::pool_budget::BudgetManager;

/// One lazily-created, database-specific pool.
pub struct PoolEntry {
    pub target_id: Uuid,
    pub connection_id: Uuid,
    pub pool: PgPool,
    pub max_connections: u32,
    pub reserved_budget: u32,
    last_used: std::sync::Mutex<Instant>,
}

impl PoolEntry {
    pub fn touch(&self) {
        if let Ok(mut last) = self.last_used.lock() {
            *last = Instant::now();
        }
    }

    pub fn idle_for(&self) -> std::time::Duration {
        self.last_used
            .lock()
            .map(|last| last.elapsed())
            .unwrap_or_default()
    }

    pub fn in_use(&self) -> u32 {
        self.pool.size().saturating_sub(self.pool.num_idle() as u32)
    }

    pub fn idle(&self) -> u32 {
        self.pool.num_idle() as u32
    }
}

#[derive(Debug, Clone, Default)]
pub struct PoolStats {
    pub active_pools: usize,
    pub total_connections: u32,
    pub in_use_connections: u32,
    pub idle_connections: u32,
    pub max_connections: u32,
    pub budget_used: u32,
    pub budget_limit: u32,
}

/// Owns every project-database pool in the process.
///
/// Pools are created lazily, bounded by a global budget, and evicted only when idle.
pub struct PoolManager {
    entries: RwLock<HashMap<Uuid, Arc<PoolEntry>>>,
    budget: BudgetManager,
}

impl PoolManager {
    pub fn new(global_budget: u32) -> Self {
        Self {
            entries: RwLock::new(HashMap::new()),
            budget: BudgetManager::new(global_budget),
        }
    }

    pub async fn get(&self, target_id: Uuid) -> Option<Arc<PoolEntry>> {
        let entries = self.entries.read().await;
        entries.get(&target_id).cloned()
    }

    pub async fn get_or_create(
        &self,
        target_id: Uuid,
        connection_id: Uuid,
        options: PgConnectOptions,
        config: &PoolConfig,
    ) -> Result<Arc<PoolEntry>, AppError> {
        // Fast path: reuse an existing pool.
        {
            let entries = self.entries.read().await;
            if let Some(entry) = entries.get(&target_id) {
                entry.touch();
                return Ok(entry.clone());
            }
        }

        let mut entries = self.entries.write().await;
        // Re-check after acquiring the write lock (another task may have won the race).
        if let Some(entry) = entries.get(&target_id) {
            entry.touch();
            return Ok(entry.clone());
        }

        let reserved = config
            .max_connections
            .clamp(1, super::limits::HARD_MAX_CONNECTIONS_PER_POOL);
        self.budget.try_reserve(reserved)?;

        let pool = build_lazy_pool(options, config);
        let entry = Arc::new(PoolEntry {
            target_id,
            connection_id,
            pool,
            max_connections: reserved,
            reserved_budget: reserved,
            last_used: std::sync::Mutex::new(Instant::now()),
        });

        entries.insert(target_id, entry.clone());
        Ok(entry)
    }

    /// Close a single pool and release its budget.
    pub async fn close(&self, target_id: Uuid) -> bool {
        let removed = {
            let mut entries = self.entries.write().await;
            entries.remove(&target_id)
        };

        if let Some(entry) = removed {
            self.budget.release(entry.reserved_budget);
            entry.pool.close().await;
            true
        } else {
            false
        }
    }

    /// Close every pool attached to a connection (used on disconnect/delete).
    pub async fn close_connection(&self, connection_id: Uuid) -> usize {
        let targets: Vec<Uuid> = {
            let entries = self.entries.read().await;
            entries
                .values()
                .filter(|entry| entry.connection_id == connection_id)
                .map(|entry| entry.target_id)
                .collect()
        };

        let mut closed = 0;
        for target_id in targets {
            if self.close(target_id).await {
                closed += 1;
            }
        }
        closed
    }

    pub async fn close_all(&self) {
        let entries: Vec<Arc<PoolEntry>> = {
            let mut map = self.entries.write().await;
            map.drain().map(|(_, entry)| entry).collect()
        };

        for entry in entries {
            self.budget.release(entry.reserved_budget);
            entry.pool.close().await;
        }
    }

    /// Evict pools that have been idle longer than the threshold.
    pub async fn evict_idle(&self, max_idle: std::time::Duration) -> usize {
        let candidates: Vec<Arc<PoolEntry>> = {
            let entries = self.entries.read().await;
            entries
                .values()
                .filter(|entry| entry.in_use() == 0 && entry.idle_for() >= max_idle)
                .cloned()
                .collect()
        };

        let mut evicted = 0;
        for entry in candidates {
            if self.close(entry.target_id).await {
                evicted += 1;
                tracing::info!(
                    target_id = %entry.target_id,
                    "evicted idle database pool"
                );
            }
        }
        evicted
    }

    pub async fn stats(&self) -> PoolStats {
        let entries = self.entries.read().await;
        let mut stats = PoolStats {
            active_pools: entries.len(),
            budget_used: self.budget.used(),
            budget_limit: self.budget.limit(),
            ..Default::default()
        };

        for entry in entries.values() {
            stats.total_connections += entry.pool.size();
            stats.in_use_connections += entry.in_use();
            stats.idle_connections += entry.idle();
            stats.max_connections += entry.max_connections;
        }
        stats
    }

    pub async fn active_pool_count(&self) -> usize {
        self.entries.read().await.len()
    }

    pub async fn target_ids(&self) -> Vec<Uuid> {
        self.entries.read().await.keys().copied().collect()
    }

    pub async fn pools_for_connection(&self, connection_id: Uuid) -> Vec<Arc<PoolEntry>> {
        self.entries
            .read()
            .await
            .values()
            .filter(|entry| entry.connection_id == connection_id)
            .cloned()
            .collect()
    }
}
