//! Global and per-database pool limits.
//!
//! These are defaults; production values must be benchmarked against the VPS and each
//! PostgreSQL server's `max_connections`.

pub const DEFAULT_MAX_CONNECTIONS_PER_POOL: u32 = 5;
pub const DEFAULT_MIN_CONNECTIONS_PER_POOL: u32 = 0;
pub const DEFAULT_ACQUIRE_TIMEOUT_SECS: u64 = 5;
pub const DEFAULT_CONNECT_TIMEOUT_SECS: u64 = 5;
pub const DEFAULT_IDLE_TIMEOUT_SECS: u64 = 300;
pub const DEFAULT_MAX_LIFETIME_SECS: u64 = 1800;

/// Upper bound used when a policy row is missing or malformed.
pub const HARD_MAX_CONNECTIONS_PER_POOL: u32 = 20;
