use serde::Serialize;

/// Authoritative connection state.
///
/// `Connected` means the pool is available for use — not that a physical TCP
/// connection is open right now (pools are lazy).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum ConnectionState {
    Registered,
    Connecting,
    Connected,
    Disconnected,
    Degraded,
    Reconnecting,
    Failed,
    Disabled,
    Closing,
}

impl ConnectionState {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Registered => "registered",
            Self::Connecting => "connecting",
            Self::Connected => "connected",
            Self::Disconnected => "disconnected",
            Self::Degraded => "degraded",
            Self::Reconnecting => "reconnecting",
            Self::Failed => "failed",
            Self::Disabled => "disabled",
            Self::Closing => "closing",
        }
    }

    pub fn parse(raw: &str) -> Option<Self> {
        match raw.trim().to_ascii_lowercase().as_str() {
            "registered" => Some(Self::Registered),
            "connecting" => Some(Self::Connecting),
            "connected" => Some(Self::Connected),
            "disconnected" => Some(Self::Disconnected),
            "degraded" => Some(Self::Degraded),
            "reconnecting" => Some(Self::Reconnecting),
            "failed" => Some(Self::Failed),
            "disabled" => Some(Self::Disabled),
            "closing" => Some(Self::Closing),
            _ => None,
        }
    }

    /// Fail-closed transition table.
    pub fn can_transition_to(self, next: Self) -> bool {
        use ConnectionState::*;
        matches!(
            (self, next),
            (Registered, Connecting)
                | (Registered, Disabled)
                | (Connecting, Connected)
                | (Connecting, Failed)
                | (Connected, Disconnected)
                | (Connected, Degraded)
                | (Connected, Closing)
                | (Degraded, Reconnecting)
                | (Degraded, Disconnected)
                | (Reconnecting, Connected)
                | (Reconnecting, Failed)
                | (Reconnecting, Disconnected)
                | (Failed, Connecting)
                | (Failed, Disabled)
                | (Disconnected, Connecting)
                | (Disconnected, Disabled)
                | (Closing, Disconnected)
                | (Disabled, Connecting)
        )
    }

    pub fn is_usable(&self) -> bool {
        matches!(self, Self::Connected | Self::Degraded)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn happy_path() {
        let mut state = ConnectionState::Registered;
        for next in [
            ConnectionState::Connecting,
            ConnectionState::Connected,
            ConnectionState::Closing,
            ConnectionState::Disconnected,
        ] {
            assert!(state.can_transition_to(next), "{state:?} -> {next:?}");
            state = next;
        }
    }

    #[test]
    fn cannot_connect_from_closed_without_registration() {
        assert!(!ConnectionState::Closing.can_transition_to(ConnectionState::Connected));
    }
}
