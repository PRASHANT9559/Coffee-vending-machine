use std::time::{Duration, Instant};

use sqlx::PgPool;

/// Lightweight liveness probe (`SELECT 1`) with a hard timeout.
/// Returns `(ok, latency_ms)`.
pub async fn check_pool(pool: &PgPool, timeout: Duration) -> (bool, u64) {
    let started = Instant::now();
    let result = tokio::time::timeout(timeout, async {
        sqlx::query_scalar::<_, i32>("SELECT 1").fetch_one(pool).await
    })
    .await;
    let elapsed = started.elapsed().as_millis() as u64;

    match result {
        Ok(Ok(1)) => (true, elapsed),
        _ => (false, elapsed),
    }
}

/// Probe a single database target if its pool exists. Missing pool = not connected.
pub async fn check_target(
    pools: &crate::connections::pool::manager::PoolManager,
    target_id: uuid::Uuid,
    timeout: Duration,
) -> (bool, u64) {
    match pools.get(target_id).await {
        Some(entry) => {
            entry.touch();
            check_pool(&entry.pool, timeout).await
        }
        None => (false, 0),
    }
}
