use std::sync::Arc;
use std::time::Duration;

use crate::connections::pool::manager::PoolManager;

/// Periodic health-probe schedule metadata.
///
/// The monitor intentionally does not poll every database every few seconds: interval and
/// jitter are configurable and each probe is a lightweight `SELECT 1`.
pub struct HealthMonitorConfig {
    pub interval: Duration,
    pub timeout: Duration,
    pub jitter: Duration,
}

impl Default for HealthMonitorConfig {
    fn default() -> Self {
        Self {
            interval: Duration::from_secs(30),
            timeout: Duration::from_secs(5),
            jitter: Duration::from_millis(500),
        }
    }
}

/// Spawn an eviction + health sweep loop.
///
/// A failing probe marks the pool unhealthy by closing it; the next request recreates it
/// lazily. Active operations are never terminated abruptly.
pub fn spawn_monitor(
    pools: Arc<PoolManager>,
    config: HealthMonitorConfig,
) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        let mut ticker = tokio::time::interval(config.interval);
        ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        loop {
            ticker.tick().await;
            let targets: Vec<uuid::Uuid> = pools.target_ids().await;
            for target_id in targets {
                if let Some(entry) = pools.get(target_id).await {
                    if entry.in_use() > 0 {
                        continue;
                    }
                    let (ok, latency) =
                        super::checker::check_pool(&entry.pool, config.timeout).await;
                    if !ok {
                        tracing::warn!(%target_id, latency, "health probe failed; closing pool");
                        pools.close(target_id).await;
                    }
                }
            }
        }
    })
}
