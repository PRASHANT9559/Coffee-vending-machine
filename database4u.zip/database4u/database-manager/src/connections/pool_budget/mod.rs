use std::sync::atomic::{AtomicU32, Ordering};

use crate::common::errors::AppError;

/// Global / per-server connection budget.
///
/// A reservation must succeed before a pool is created; exhausted budgets never
/// silently create more pools.
pub struct BudgetManager {
    limit: u32,
    used: AtomicU32,
}

impl BudgetManager {
    pub fn new(limit: u32) -> Self {
        Self {
            limit: limit.max(1),
            used: AtomicU32::new(0),
        }
    }

    pub fn try_reserve(&self, amount: u32) -> Result<(), AppError> {
        loop {
            let current = self.used.load(Ordering::SeqCst);
            if current + amount > self.limit {
                return Err(AppError::Unavailable(format!(
                    "connection pool budget exhausted ({}/{})",
                    current, self.limit
                )));
            }
            if self
                .used
                .compare_exchange(current, current + amount, Ordering::SeqCst, Ordering::SeqCst)
                .is_ok()
            {
                return Ok(());
            }
        }
    }

    pub fn release(&self, amount: u32) {
        let _ = self
            .used
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |current| {
                Some(current.saturating_sub(amount))
            });
    }

    pub fn used(&self) -> u32 {
        self.used.load(Ordering::SeqCst)
    }

    pub fn limit(&self) -> u32 {
        self.limit
    }

    pub fn available(&self) -> u32 {
        self.limit.saturating_sub(self.used())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reserves_until_limit_then_rejects() {
        let budget = BudgetManager::new(10);
        assert!(budget.try_reserve(6).is_ok());
        assert!(budget.try_reserve(4).is_ok());
        assert_eq!(budget.used(), 10);
        assert!(budget.try_reserve(1).is_err());
    }

    #[test]
    fn release_restores_capacity() {
        let budget = BudgetManager::new(5);
        assert!(budget.try_reserve(5).is_ok());
        budget.release(3);
        assert_eq!(budget.available(), 3);
        assert!(budget.try_reserve(3).is_ok());
        assert!(budget.try_reserve(1).is_err());
    }

    #[test]
    fn release_never_underflows() {
        let budget = BudgetManager::new(2);
        budget.release(10);
        assert_eq!(budget.used(), 0);
    }

    #[test]
    fn zero_limit_is_clamped_to_one() {
        let budget = BudgetManager::new(0);
        assert_eq!(budget.limit(), 1);
    }
}
