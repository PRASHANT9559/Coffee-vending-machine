use chrono::{DateTime, Utc};
use serde::Serialize;
use uuid::Uuid;

/// Persisted server profile. Never contains a password or credential id in responses.
#[derive(Debug, Clone, sqlx::FromRow)]
pub struct ConnectionProfile {
    pub connection_id: Uuid,
    pub display_name: String,
    pub scope: String,
    pub host: String,
    pub port: i32,
    pub username: String,
    pub credential_id: Uuid,
    pub network_mode: String,
    pub tls_mode: String,
    pub connect_timeout: i32,
    pub acquire_timeout: i32,
    pub idle_timeout: i32,
    pub max_lifetime: i32,
    pub is_enabled: bool,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, sqlx::FromRow)]
pub struct DatabaseTarget {
    pub database_target_id: Uuid,
    pub connection_id: Uuid,
    pub database_name: String,
    pub pool_policy_id: Option<Uuid>,
    pub is_enabled: bool,
    pub last_discovered_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, sqlx::FromRow)]
pub struct StoredCredential {
    pub credential_id: Uuid,
    pub encrypted_password: Vec<u8>,
    pub nonce: Vec<u8>,
}

#[derive(Debug, Clone, sqlx::FromRow)]
pub struct PoolPolicy {
    pub pool_policy_id: Uuid,
    pub connection_id: Uuid,
    pub max_connections: i32,
    pub min_connections: i32,
    pub acquire_timeout_secs: i32,
    pub connect_timeout_secs: i32,
    pub idle_timeout_secs: i32,
    pub max_lifetime_secs: i32,
}

impl PoolPolicy {
    pub fn default_for(connection_id: Uuid) -> Self {
        Self {
            pool_policy_id: Uuid::nil(),
            connection_id,
            max_connections: 5,
            min_connections: 0,
            acquire_timeout_secs: 5,
            connect_timeout_secs: 5,
            idle_timeout_secs: 300,
            max_lifetime_secs: 1800,
        }
    }
}

/// Sanitized public view of a profile.
#[derive(Debug, Clone, Serialize)]
pub struct ConnectionProfileView {
    pub connection_id: Uuid,
    pub display_name: String,
    pub scope: String,
    pub host: String,
    pub port: i32,
    pub username: String,
    pub network_mode: String,
    pub tls_mode: String,
    pub connect_timeout: i32,
    pub acquire_timeout: i32,
    pub idle_timeout: i32,
    pub max_lifetime: i32,
    pub is_enabled: bool,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl From<ConnectionProfile> for ConnectionProfileView {
    fn from(profile: ConnectionProfile) -> Self {
        Self {
            connection_id: profile.connection_id,
            display_name: profile.display_name,
            scope: profile.scope,
            host: profile.host,
            port: profile.port,
            username: profile.username,
            network_mode: profile.network_mode,
            tls_mode: profile.tls_mode,
            connect_timeout: profile.connect_timeout,
            acquire_timeout: profile.acquire_timeout,
            idle_timeout: profile.idle_timeout,
            max_lifetime: profile.max_lifetime,
            is_enabled: profile.is_enabled,
            created_at: profile.created_at,
            updated_at: profile.updated_at,
        }
    }
}

/// Authoritative runtime connection state (mirrors the state machine, never persisted
/// as a pool object).
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RuntimeState {
    Registered,
    Connecting,
    Connected,
    Disconnected,
    Degraded,
    Reconnecting,
    Failed,
    Disabled,
    Closing,
}
