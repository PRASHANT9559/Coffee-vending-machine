use std::time::Duration;

/// Reconnect policy. Attempts are single-flight at the call site; this type only holds
/// the schedule.
#[derive(Debug, Clone)]
pub struct RetryPolicy {
    pub max_attempts: u32,
    pub max_delay: Duration,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            max_attempts: 5,
            max_delay: Duration::from_secs(30),
        }
    }
}

impl RetryPolicy {
    pub fn delay(&self, attempt: u32) -> Duration {
        super::backoff::delay_for_attempt(attempt).min(self.max_delay)
    }
}

/// Never blindly re-execute a failed transaction: the caller must verify whether the
/// previous statement committed before retrying. This helper only encapsulates the
/// delay schedule, not the decision to retry.
pub async fn wait_before_attempt(policy: &RetryPolicy, attempt: u32) {
    if attempt == 0 {
        return;
    }
    tokio::time::sleep(policy.delay(attempt)).await;
}
