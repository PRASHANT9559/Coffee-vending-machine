use std::time::Duration;

/// Exponential backoff with jitter and a hard cap.
///
/// Delays: ~1s, 2s, 4s, 8s, 16s, 30s (cap).
pub fn delay_for_attempt(attempt: u32) -> Duration {
    let base_ms = 1_000u64.saturating_mul(1u64 << attempt.min(5));
    let capped = base_ms.min(30_000);
    // Deterministic-per-call jitter derived from the clock; avoids a thundering herd
    // without pulling in a random number dependency.
    let jitter = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.subsec_millis() as u64)
        .unwrap_or(0)
        % 500;
    Duration::from_millis(capped + jitter)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn grows_and_caps() {
        assert!(delay_for_attempt(0) >= Duration::from_secs(1));
        assert!(delay_for_attempt(3) >= Duration::from_secs(8));
        assert!(delay_for_attempt(10) <= Duration::from_secs(31));
    }
}
