use uuid::Uuid;

use crate::connections::pool::manager::PoolManager;

/// Snapshot metrics for one connection profile.
pub async fn collect(pools: &PoolManager, connection_id: Uuid) -> ConnectionMetricsSnapshot {
    let stats = pools.stats().await;
    let rows = pools.pools_for_connection(connection_id).await;

    let mut snapshot = ConnectionMetricsSnapshot {
        active_pools: rows.len(),
        budget_used: stats.budget_used,
        budget_limit: stats.budget_limit,
        ..Default::default()
    };

    for entry in rows {
        snapshot.in_use_connections += entry.in_use();
        snapshot.idle_connections += entry.idle();
        snapshot.max_connections += entry.max_connections;
    }

    snapshot
}

#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct ConnectionMetricsSnapshot {
    pub active_pools: usize,
    pub in_use_connections: u32,
    pub idle_connections: u32,
    pub max_connections: u32,
    pub budget_used: u32,
    pub budget_limit: u32,
}
