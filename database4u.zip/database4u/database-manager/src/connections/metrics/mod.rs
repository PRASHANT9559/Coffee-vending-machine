pub mod collector;

pub use collector::{collect, ConnectionMetricsSnapshot};
