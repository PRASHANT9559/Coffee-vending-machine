#[cfg(test)]
mod tests {
    #[test]
    fn test_registry() {
        assert!(true);
    }
}
