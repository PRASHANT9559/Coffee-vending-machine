#[cfg(test)]
mod tests {
    use crate::connections::credentials::vault::{CredentialVault, StoredCredentialRecord};
    use crate::infrastructure::encryption::CryptoEngine;
    use secrecy::{ExposeSecret, SecretString};
    use uuid::Uuid;

    #[test]
    fn test_vault_encryption_and_decryption_flow() {
        let key = CryptoEngine::generate_key();
        let engine = CryptoEngine::new(&key);
        let vault = CredentialVault::new(engine);

        let test_pass = SecretString::new("P@ssw0rd_Postgres_Prod_2026!".to_string());
        let (credential_id, payload) = vault
            .prepare_for_storage(&test_pass)
            .expect("Encryption failed");

        assert_eq!(payload.nonce.len(), 24);
        assert_ne!(payload.ciphertext, test_pass.expose_secret().as_bytes());

        let record = StoredCredentialRecord {
            credential_id,
            encrypted_password: payload.ciphertext,
            nonce: payload.nonce.to_vec(),
        };

        let decrypted = vault
            .decrypt_credential(&record)
            .expect("Decryption failed");

        assert_eq!(decrypted.expose_secret(), test_pass.expose_secret());
    }
}
