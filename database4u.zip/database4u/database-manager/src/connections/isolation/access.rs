use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;

/// Projects that link to this connection.
pub async fn project_ids_for_connection(
    pool: &PgPool,
    connection_id: Uuid,
) -> Result<Vec<Uuid>, AppError> {
    let rows = sqlx::query_scalar::<_, Uuid>(
        "SELECT project_id FROM connection_projects WHERE connection_id = $1",
    )
    .bind(connection_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

/// Authorize a connection-scoped action.
///
/// Returns the project that granted access. Non-members get `NotFound` so connection
/// existence never leaks across projects.
pub async fn require_connection_permission(
    pool: &PgPool,
    user_id: Uuid,
    connection_id: Uuid,
    permission: &str,
) -> Result<Uuid, AppError> {
    let projects = sqlx::query_scalar::<_, Uuid>(
        r#"SELECT cp.project_id
           FROM connection_projects cp
           JOIN project_members pm ON pm.project_id = cp.project_id
           WHERE cp.connection_id = $1 AND pm.user_id = $2"#,
    )
    .bind(connection_id)
    .bind(user_id)
    .fetch_all(pool)
    .await?;

    if projects.is_empty() {
        return Err(AppError::NotFound("connection not found".into()));
    }

    for project_id in &projects {
        if crate::security::permissions::policy::has_project_permission(
            pool,
            user_id,
            *project_id,
            permission,
        )
        .await?
        {
            return Ok(*project_id);
        }
    }

    Err(AppError::Forbidden(format!(
        "missing permission: {permission}"
    )))
}

/// Authorize access to a database target (resolves the owning connection first).
pub async fn require_target_permission(
    pool: &PgPool,
    user_id: Uuid,
    database_target_id: Uuid,
    permission: &str,
) -> Result<Uuid, AppError> {
    let connection_id = sqlx::query_scalar::<_, Uuid>(
        "SELECT connection_id FROM connection_databases WHERE database_target_id = $1",
    )
    .bind(database_target_id)
    .fetch_optional(pool)
    .await?
    .ok_or_else(|| AppError::NotFound("database target not found".into()))?;

    require_connection_permission(pool, user_id, connection_id, permission).await
}
