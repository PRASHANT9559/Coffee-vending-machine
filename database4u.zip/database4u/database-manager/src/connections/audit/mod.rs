use sqlx::PgPool;
use uuid::Uuid;

use crate::security::audit;

/// Connection-specific audit helper. Never accepts secrets.
pub async fn record(
    pool: &PgPool,
    user_id: Option<Uuid>,
    project_id: Option<Uuid>,
    connection_id: Uuid,
    action: &str,
    success: bool,
) {
    audit::record_connection(pool, user_id, project_id, Some(connection_id), action, success).await;
}

/// Append a state transition to `connection_events`.
///
/// Failures are logged but never propagated: lifecycle bookkeeping must not break a
/// user-facing operation.
pub async fn record_event(
    pool: &PgPool,
    connection_id: Uuid,
    from_state: Option<&str>,
    to_state: &str,
    reason: Option<&str>,
) {
    if let Err(error) = sqlx::query(
        r#"INSERT INTO connection_events (connection_id, from_state, to_state, reason)
           VALUES ($1, $2, $3, $4)"#,
    )
    .bind(connection_id)
    .bind(from_state)
    .bind(to_state)
    .bind(reason)
    .execute(pool)
    .await
    {
        tracing::warn!(%connection_id, error = %error, "failed to write connection event");
    }
}

/// Append a health sample to `connection_health_logs`.
pub async fn record_health(
    pool: &PgPool,
    connection_id: Uuid,
    database_target_id: Option<Uuid>,
    healthy: bool,
    latency_ms: Option<u64>,
    detail: Option<&str>,
) {
    if let Err(error) = sqlx::query(
        r#"INSERT INTO connection_health_logs
             (connection_id, database_target_id, healthy, latency_ms, detail)
           VALUES ($1, $2, $3, $4, $5)"#,
    )
    .bind(connection_id)
    .bind(database_target_id)
    .bind(healthy)
    .bind(latency_ms.map(|value| value.min(i32::MAX as u64) as i32))
    .bind(detail)
    .execute(pool)
    .await
    {
        tracing::warn!(%connection_id, error = %error, "failed to write connection health sample");
    }
}
