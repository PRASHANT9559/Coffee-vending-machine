use crate::infrastructure::encryption::{CryptoEngine, EncryptedPayload, EncryptionError};
use secrecy::SecretString;

/// Rotate a credential by decrypting with old engine and re-encrypting with new engine.
pub fn rotate_credential(
    old_engine: &CryptoEngine,
    new_engine: &CryptoEngine,
    ciphertext: &[u8],
    nonce: &[u8],
) -> Result<EncryptedPayload, EncryptionError> {
    let plaintext: SecretString =
        crate::connections::credentials::decryption::decrypt_connection_credential(
            old_engine, ciphertext, nonce,
        )?;

    crate::connections::credentials::encryption::encrypt_connection_credential(
        new_engine, &plaintext,
    )
}
