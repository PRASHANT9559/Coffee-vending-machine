use crate::infrastructure::encryption::{CryptoEngine, EncryptedPayload, EncryptionError};
use secrecy::SecretString;

/// Encrypt a connection password or sensitive secret using XChaCha20-Poly1305.
pub fn encrypt_connection_credential(
    engine: &CryptoEngine,
    raw_password: &SecretString,
) -> Result<EncryptedPayload, EncryptionError> {
    engine.encrypt_string(raw_password)
}
