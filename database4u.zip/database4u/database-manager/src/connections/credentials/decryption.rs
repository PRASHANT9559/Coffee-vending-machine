use crate::infrastructure::encryption::{CryptoEngine, EncryptionError, NONCE_SIZE};
use secrecy::SecretString;

/// Decrypt a stored credential using XChaCha20-Poly1305.
pub fn decrypt_connection_credential(
    engine: &CryptoEngine,
    encrypted_bytes: &[u8],
    nonce_bytes: &[u8],
) -> Result<SecretString, EncryptionError> {
    if nonce_bytes.len() != NONCE_SIZE {
        return Err(EncryptionError::InvalidNonceLength(nonce_bytes.len()));
    }

    let mut nonce_arr = [0u8; NONCE_SIZE];
    nonce_arr.copy_from_slice(nonce_bytes);

    engine.decrypt_to_string(encrypted_bytes, &nonce_arr)
}
