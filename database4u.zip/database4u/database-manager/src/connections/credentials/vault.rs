use crate::infrastructure::encryption::{CryptoEngine, EncryptedPayload, EncryptionError};
use secrecy::SecretString;
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct StoredCredentialRecord {
    pub credential_id: Uuid,
    pub encrypted_password: Vec<u8>,
    pub nonce: Vec<u8>,
}

/// Credential Vault managing encryption and decryption operations for database targets.
pub struct CredentialVault {
    crypto_engine: CryptoEngine,
}

impl CredentialVault {
    pub fn new(crypto_engine: CryptoEngine) -> Self {
        Self { crypto_engine }
    }

    /// Prepare a raw password for storage by encrypting it with XChaCha20-Poly1305.
    pub fn prepare_for_storage(
        &self,
        raw_password: &SecretString,
    ) -> Result<(Uuid, EncryptedPayload), EncryptionError> {
        let credential_id = Uuid::new_v4();
        let payload = self.crypto_engine.encrypt_string(raw_password)?;
        Ok((credential_id, payload))
    }

    /// Decrypt a database credential retrieved from PostgreSQL.
    pub fn decrypt_credential(
        &self,
        record: &StoredCredentialRecord,
    ) -> Result<SecretString, EncryptionError> {
        crate::connections::credentials::decryption::decrypt_connection_credential(
            &self.crypto_engine,
            &record.encrypted_password,
            &record.nonce,
        )
    }
}
