use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::common::validation::validate_display_name;
use crate::connections::config::validation::ConnectionConfig;
use crate::connections::models::{
    ConnectionProfile, DatabaseTarget, PoolPolicy, StoredCredential,
};

pub struct NewConnection {
    pub display_name: String,
    pub scope: String,
    pub host: String,
    pub port: u16,
    pub username: String,
    pub network_mode: String,
    pub tls_mode: String,
    pub connect_timeout: u64,
    pub acquire_timeout: u64,
    pub idle_timeout: u64,
    pub max_lifetime: u64,
    pub project_id: Uuid,
}

impl NewConnection {
    pub fn from_parts(
        display_name: &str,
        config: &ConnectionConfig,
        network_mode: &str,
        project_id: Uuid,
        acquire_timeout: u64,
        idle_timeout: u64,
        max_lifetime: u64,
    ) -> Result<Self, AppError> {
        Ok(Self {
            display_name: validate_display_name(display_name, 128)?,
            scope: if matches!(config.host.as_str(), "127.0.0.1" | "localhost" | "::1") {
                "local".to_string()
            } else {
                "remote".to_string()
            },
            host: config.host.clone(),
            port: config.port,
            username: config.username.clone(),
            network_mode: network_mode.to_string(),
            tls_mode: config.tls.as_str().to_string(),
            connect_timeout: config.connect_timeout_secs,
            acquire_timeout,
            idle_timeout,
            max_lifetime,
            project_id,
        })
    }
}

pub async fn create(
    pool: &PgPool,
    new: &NewConnection,
    encrypted_password: &[u8],
    nonce: &[u8],
) -> Result<ConnectionProfile, AppError> {
    let mut tx = pool.begin().await?;

    let credential_id = sqlx::query_scalar::<_, Uuid>(
        r#"INSERT INTO connection_credentials (encrypted_password, nonce)
           VALUES ($1, $2) RETURNING credential_id"#,
    )
    .bind(encrypted_password)
    .bind(nonce)
    .fetch_one(&mut *tx)
    .await?;

    let profile = sqlx::query_as::<_, ConnectionProfile>(
        r#"INSERT INTO connections
             (display_name, scope, host, port, username, credential_id, network_mode,
              tls_mode, connect_timeout, acquire_timeout, idle_timeout, max_lifetime)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
           RETURNING connection_id, display_name, scope, host, port, username, credential_id,
                     network_mode, tls_mode, connect_timeout, acquire_timeout, idle_timeout,
                     max_lifetime, is_enabled, created_at, updated_at"#,
    )
    .bind(&new.display_name)
    .bind(&new.scope)
    .bind(&new.host)
    .bind(new.port as i32)
    .bind(&new.username)
    .bind(credential_id)
    .bind(&new.network_mode)
    .bind(&new.tls_mode)
    .bind(new.connect_timeout as i32)
    .bind(new.acquire_timeout as i32)
    .bind(new.idle_timeout as i32)
    .bind(new.max_lifetime as i32)
    .fetch_one(&mut *tx)
    .await?;

    sqlx::query(
        "INSERT INTO connection_projects (connection_id, project_id) VALUES ($1, $2)
         ON CONFLICT DO NOTHING",
    )
    .bind(profile.connection_id)
    .bind(new.project_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;
    Ok(profile)
}

pub async fn list_for_user(
    pool: &PgPool,
    user_id: Uuid,
) -> Result<Vec<ConnectionProfile>, AppError> {
    let rows = sqlx::query_as::<_, ConnectionProfile>(
        r#"SELECT DISTINCT c.connection_id, c.display_name, c.scope, c.host, c.port,
                  c.username, c.credential_id, c.network_mode, c.tls_mode,
                  c.connect_timeout, c.acquire_timeout, c.idle_timeout, c.max_lifetime,
                  c.is_enabled, c.created_at, c.updated_at
           FROM connections c
           JOIN connection_projects cp ON cp.connection_id = c.connection_id
           JOIN project_members pm ON pm.project_id = cp.project_id
           WHERE pm.user_id = $1
           ORDER BY c.created_at DESC"#,
    )
    .bind(user_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn get_for_user(
    pool: &PgPool,
    user_id: Uuid,
    connection_id: Uuid,
) -> Result<Option<ConnectionProfile>, AppError> {
    let row = sqlx::query_as::<_, ConnectionProfile>(
        r#"SELECT DISTINCT c.connection_id, c.display_name, c.scope, c.host, c.port,
                  c.username, c.credential_id, c.network_mode, c.tls_mode,
                  c.connect_timeout, c.acquire_timeout, c.idle_timeout, c.max_lifetime,
                  c.is_enabled, c.created_at, c.updated_at
           FROM connections c
           JOIN connection_projects cp ON cp.connection_id = c.connection_id
           JOIN project_members pm ON pm.project_id = cp.project_id
           WHERE c.connection_id = $1 AND pm.user_id = $2"#,
    )
    .bind(connection_id)
    .bind(user_id)
    .fetch_optional(pool)
    .await?;
    Ok(row)
}

pub struct ConnectionUpdate {
    pub display_name: Option<String>,
    pub host: Option<String>,
    pub port: Option<u16>,
    pub username: Option<String>,
    pub scope: Option<String>,
    pub network_mode: Option<String>,
    pub tls_mode: Option<String>,
    pub connect_timeout: Option<u64>,
    pub acquire_timeout: Option<u64>,
    pub idle_timeout: Option<u64>,
    pub max_lifetime: Option<u64>,
    pub is_enabled: Option<bool>,
}

pub async fn update(
    pool: &PgPool,
    connection_id: Uuid,
    update: &ConnectionUpdate,
) -> Result<ConnectionProfile, AppError> {
    let row = sqlx::query_as::<_, ConnectionProfile>(
        r#"UPDATE connections SET
             display_name = COALESCE($2, display_name),
             host = COALESCE($3, host),
             port = COALESCE($4, port),
             username = COALESCE($5, username),
             scope = COALESCE($6, scope),
             network_mode = COALESCE($7, network_mode),
             tls_mode = COALESCE($8, tls_mode),
             connect_timeout = COALESCE($9, connect_timeout),
             acquire_timeout = COALESCE($10, acquire_timeout),
             idle_timeout = COALESCE($11, idle_timeout),
             max_lifetime = COALESCE($12, max_lifetime),
             is_enabled = COALESCE($13, is_enabled),
             updated_at = now()
           WHERE connection_id = $1
           RETURNING connection_id, display_name, scope, host, port, username, credential_id,
                     network_mode, tls_mode, connect_timeout, acquire_timeout, idle_timeout,
                     max_lifetime, is_enabled, created_at, updated_at"#,
    )
    .bind(connection_id)
    .bind(update.display_name.as_deref())
    .bind(update.host.as_deref())
    .bind(update.port.map(|p| p as i32))
    .bind(update.username.as_deref())
    .bind(update.scope.as_deref())
    .bind(update.network_mode.as_deref())
    .bind(update.tls_mode.as_deref())
    .bind(update.connect_timeout.map(|v| v as i32))
    .bind(update.acquire_timeout.map(|v| v as i32))
    .bind(update.idle_timeout.map(|v| v as i32))
    .bind(update.max_lifetime.map(|v| v as i32))
    .bind(update.is_enabled)
    .fetch_optional(pool)
    .await?
    .ok_or_else(|| AppError::NotFound("connection not found".into()))?;

    Ok(row)
}

/// List connections linked to a project (profiles only, no credentials).
pub async fn list_connections_for_project(
    pool: &PgPool,
    project_id: Uuid,
) -> Result<Vec<ConnectionProfile>, AppError> {
    let rows = sqlx::query_as::<_, ConnectionProfile>(
        r#"SELECT DISTINCT c.connection_id, c.display_name, c.scope, c.host, c.port,
                  c.username, c.credential_id, c.network_mode, c.tls_mode,
                  c.connect_timeout, c.acquire_timeout, c.idle_timeout, c.max_lifetime,
                  c.is_enabled, c.created_at, c.updated_at
           FROM connections c
           JOIN connection_projects cp ON cp.connection_id = c.connection_id
           WHERE cp.project_id = $1
           ORDER BY c.created_at DESC"#,
    )
    .bind(project_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

/// Link an existing connection to a project. Idempotent (uses ON CONFLICT DO NOTHING).
pub async fn link_connection_to_project(
    pool: &PgPool,
    connection_id: Uuid,
    project_id: Uuid,
) -> Result<(), AppError> {
    sqlx::query(
        "INSERT INTO connection_projects (connection_id, project_id) VALUES ($1, $2)
         ON CONFLICT DO NOTHING",
    )
    .bind(connection_id)
    .bind(project_id)
    .execute(pool)
    .await?;
    Ok(())
}

/// Unlink a connection from a project. Returns `true` if a row was removed.
pub async fn unlink_connection_from_project(
    pool: &PgPool,
    connection_id: Uuid,
    project_id: Uuid,
) -> Result<bool, AppError> {
    let affected = sqlx::query(
        "DELETE FROM connection_projects WHERE connection_id = $1 AND project_id = $2",
    )
    .bind(connection_id)
    .bind(project_id)
    .execute(pool)
    .await?
    .rows_affected();
    Ok(affected > 0)
}

pub async fn delete(pool: &PgPool, connection_id: Uuid) -> Result<(), AppError> {
    let mut tx = pool.begin().await?;

    let credential_id = sqlx::query_scalar::<_, Uuid>(
        "SELECT credential_id FROM connections WHERE connection_id = $1",
    )
    .bind(connection_id)
    .fetch_optional(&mut *tx)
    .await?
    .ok_or_else(|| AppError::NotFound("connection not found".into()))?;

    sqlx::query("DELETE FROM connections WHERE connection_id = $1")
        .bind(connection_id)
        .execute(&mut *tx)
        .await?;

    sqlx::query("DELETE FROM connection_credentials WHERE credential_id = $1")
        .bind(credential_id)
        .execute(&mut *tx)
        .await?;

    tx.commit().await?;
    Ok(())
}

pub async fn load_credential(
    pool: &PgPool,
    connection_id: Uuid,
) -> Result<StoredCredential, AppError> {
    let credential = sqlx::query_as::<_, StoredCredential>(
        r#"SELECT cc.credential_id, cc.encrypted_password, cc.nonce
           FROM connection_credentials cc
           JOIN connections c ON c.credential_id = cc.credential_id
           WHERE c.connection_id = $1"#,
    )
    .bind(connection_id)
    .fetch_optional(pool)
    .await?
    .ok_or_else(|| AppError::NotFound("connection credential not found".into()))?;
    Ok(credential)
}

pub async fn replace_credential(
    pool: &PgPool,
    connection_id: Uuid,
    encrypted_password: &[u8],
    nonce: &[u8],
) -> Result<(), AppError> {
    let affected = sqlx::query(
        r#"UPDATE connection_credentials SET encrypted_password = $1, nonce = $2
           WHERE credential_id = (SELECT credential_id FROM connections WHERE connection_id = $3)"#,
    )
    .bind(encrypted_password)
    .bind(nonce)
    .bind(connection_id)
    .execute(pool)
    .await?
    .rows_affected();

    if affected == 0 {
        return Err(AppError::NotFound("connection credential not found".into()));
    }
    Ok(())
}

pub async fn list_database_targets(
    pool: &PgPool,
    connection_id: Uuid,
) -> Result<Vec<DatabaseTarget>, AppError> {
    let rows = sqlx::query_as::<_, DatabaseTarget>(
        r#"SELECT database_target_id, connection_id, database_name, pool_policy_id,
                  is_enabled, last_discovered_at
           FROM connection_databases
           WHERE connection_id = $1
           ORDER BY database_name"#,
    )
    .bind(connection_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn find_database_target(
    pool: &PgPool,
    database_target_id: Uuid,
) -> Result<Option<DatabaseTarget>, AppError> {
    let row = sqlx::query_as::<_, DatabaseTarget>(
        r#"SELECT database_target_id, connection_id, database_name, pool_policy_id,
                  is_enabled, last_discovered_at
           FROM connection_databases WHERE database_target_id = $1"#,
    )
    .bind(database_target_id)
    .fetch_optional(pool)
    .await?;
    Ok(row)
}

pub async fn upsert_database_target(
    pool: &PgPool,
    connection_id: Uuid,
    database_name: &str,
) -> Result<DatabaseTarget, AppError> {
    let row = sqlx::query_as::<_, DatabaseTarget>(
        r#"INSERT INTO connection_databases (connection_id, database_name, last_discovered_at)
           VALUES ($1, $2, now())
           ON CONFLICT (connection_id, database_name)
           DO UPDATE SET last_discovered_at = now()
           RETURNING database_target_id, connection_id, database_name, pool_policy_id,
                     is_enabled, last_discovered_at"#,
    )
    .bind(connection_id)
    .bind(database_name)
    .fetch_one(pool)
    .await?;
    Ok(row)
}

pub async fn load_pool_policy(
    pool: &PgPool,
    database_target_id: Uuid,
) -> Result<PoolPolicy, AppError> {
    let row = sqlx::query_as::<_, PoolPolicy>(
        r#"SELECT p.pool_policy_id, p.connection_id, p.max_connections, p.min_connections,
                  p.acquire_timeout_secs, p.connect_timeout_secs, p.idle_timeout_secs,
                  p.max_lifetime_secs
           FROM connection_pool_policies p
           JOIN connection_databases d ON d.pool_policy_id = p.pool_policy_id
           WHERE d.database_target_id = $1"#,
    )
    .bind(database_target_id)
    .fetch_optional(pool)
    .await?;

    Ok(row.unwrap_or_else(|| {
        PoolPolicy::default_for(Uuid::nil())
    }))
}
