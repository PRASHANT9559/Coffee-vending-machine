//! Connection registry — delete path.

pub use crate::connections::service::delete_connection as delete;
