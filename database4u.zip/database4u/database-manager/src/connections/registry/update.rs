//! Connection registry — update path.

pub use crate::connections::service::update_connection as update;
