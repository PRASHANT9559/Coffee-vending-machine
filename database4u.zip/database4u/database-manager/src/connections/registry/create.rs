//! Connection registry — create path.
//!
//! The implementation lives in `service` so the same logic is used by both HTTP
//! handlers and internal callers.

pub use crate::connections::service::create_connection as create;
