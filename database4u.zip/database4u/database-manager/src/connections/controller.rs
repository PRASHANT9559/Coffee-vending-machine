use axum::extract::{Path, State};
use axum::Json;
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::{Ack, ApiResponse};
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::connections::dto::{
    ConnectionHealth, ConnectionMetrics, ConnectionTestReport, ConnectRequest,
    CreateConnectionRequest, DatabaseTargetView, RotateCredentialRequest, TestConnectionRequest,
    UpdateConnectionRequest,
};
use crate::connections::models::ConnectionProfileView;
use crate::connections::service;

pub async fn list(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<Json<ApiResponse<Vec<ConnectionProfileView>>>, AppError> {
    let profiles = service::list_connections(&state, user.user_id).await?;
    Ok(Json(ApiResponse::ok(profiles)))
}

pub async fn create(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<CreateConnectionRequest>,
) -> Result<Json<ApiResponse<ConnectionProfileView>>, AppError> {
    let profile = service::create_connection(&state, user.user_id, request).await?;
    Ok(Json(ApiResponse::ok(profile)))
}

pub async fn get(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<ConnectionProfileView>>, AppError> {
    let profile = service::get_connection(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(profile)))
}

pub async fn update(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
    Json(request): Json<UpdateConnectionRequest>,
) -> Result<Json<ApiResponse<ConnectionProfileView>>, AppError> {
    let profile =
        service::update_connection(&state, user.user_id, connection_id, request).await?;
    Ok(Json(ApiResponse::ok(profile)))
}

pub async fn delete(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    service::delete_connection(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("connection deleted"))))
}

pub async fn rotate_credential(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
    Json(request): Json<RotateCredentialRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    service::rotate_credential(&state, user.user_id, connection_id, request).await?;
    Ok(Json(ApiResponse::ok(Ack::new("credential rotated"))))
}

pub async fn test(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
    Json(request): Json<TestConnectionRequest>,
) -> Result<Json<ApiResponse<ConnectionTestReport>>, AppError> {
    let report = service::test_connection(&state, user.user_id, connection_id, request).await?;
    Ok(Json(ApiResponse::ok(report)))
}

pub async fn connect(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
    Json(request): Json<ConnectRequest>,
) -> Result<Json<ApiResponse<ConnectionHealth>>, AppError> {
    let health = service::connect(&state, user.user_id, connection_id, request).await?;
    Ok(Json(ApiResponse::ok(health)))
}

pub async fn disconnect(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    let closed = service::disconnect(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new(format!(
        "{closed} pool(s) closed"
    )))))
}

pub async fn reconnect(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<ConnectionHealth>>, AppError> {
    let health = service::reconnect(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(health)))
}

pub async fn health(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<ConnectionHealth>>, AppError> {
    let health = service::health(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(health)))
}

pub async fn metrics(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<ConnectionMetrics>>, AppError> {
    let metrics = service::metrics(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(metrics)))
}

pub async fn databases(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Vec<DatabaseTargetView>>>, AppError> {
    let targets = service::list_targets(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(targets)))
}

pub async fn discover_databases(
    State(state): State<AppState>,
    user: AuthUser,
    Path(connection_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Vec<DatabaseTargetView>>>, AppError> {
    let targets = service::discover_databases(&state, user.user_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(targets)))
}
