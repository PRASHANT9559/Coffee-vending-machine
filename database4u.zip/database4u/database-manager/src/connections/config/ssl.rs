use serde::{Deserialize, Serialize};

/// PostgreSQL TLS verification modes, ordered from weakest to strongest.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TlsMode {
    Disable,
    Prefer,
    Require,
    VerifyCa,
    VerifyFull,
}

impl Default for TlsMode {
    fn default() -> Self {
        Self::VerifyFull
    }
}

impl TlsMode {
    pub fn parse(raw: &str) -> Option<Self> {
        match raw.trim().to_ascii_lowercase().as_str() {
            "disable" | "disabled" => Some(Self::Disable),
            "prefer" => Some(Self::Prefer),
            "require" | "required" => Some(Self::Require),
            "verify_ca" | "verify-ca" => Some(Self::VerifyCa),
            "verify_full" | "verify-full" => Some(Self::VerifyFull),
            _ => None,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Disable => "disable",
            Self::Prefer => "prefer",
            Self::Require => "require",
            Self::VerifyCa => "verify_ca",
            Self::VerifyFull => "verify_full",
        }
    }

    /// Remote production connections should never silently downgrade verification.
    pub fn is_secure(&self) -> bool {
        matches!(self, Self::VerifyCa | Self::VerifyFull)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NetworkMode {
    DirectTls,
    SshTunnel,
}

impl Default for NetworkMode {
    fn default() -> Self {
        Self::DirectTls
    }
}

impl NetworkMode {
    pub fn parse(raw: &str) -> Option<Self> {
        match raw.trim().to_ascii_lowercase().as_str() {
            "direct_tls" | "direct" | "tls" => Some(Self::DirectTls),
            "ssh_tunnel" | "ssh" => Some(Self::SshTunnel),
            _ => None,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            Self::DirectTls => "direct_tls",
            Self::SshTunnel => "ssh_tunnel",
        }
    }
}
