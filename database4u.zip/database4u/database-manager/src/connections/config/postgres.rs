//! PostgreSQL connection parameters used to build SQLx options.

pub use super::ssl::{NetworkMode, TlsMode};
pub use super::validation::ConnectionConfig;
