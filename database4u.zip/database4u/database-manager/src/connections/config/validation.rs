use crate::common::errors::AppError;

use super::ssl::TlsMode;

/// Validated, non-secret connection parameters.
#[derive(Debug, Clone)]
pub struct ConnectionConfig {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub database: String,
    pub tls: TlsMode,
    pub connect_timeout_secs: u64,
}

impl ConnectionConfig {
    pub fn validate(
        host: &str,
        port: u16,
        username: &str,
        database: &str,
        tls: TlsMode,
        connect_timeout_secs: u64,
    ) -> Result<Self, AppError> {
        let host = validate_host(host)?;
        if port == 0 {
            return Err(AppError::Validation("port must be between 1 and 65535".into()));
        }
        let username = validate_username(username)?;
        let database = validate_database_name(database)?;
        let connect_timeout_secs = connect_timeout_secs.clamp(1, 60);

        Ok(Self {
            host,
            port,
            username,
            database,
            tls,
            connect_timeout_secs,
        })
    }
}

/// Host validation rejects schemes, paths and whitespace so the value can never be
/// smuggled into a connection string.
pub fn validate_host(raw: &str) -> Result<String, AppError> {
    let host = raw.trim();
    if host.is_empty() || host.len() > 255 {
        return Err(AppError::Validation(
            "host must be between 1 and 255 characters".into(),
        ));
    }
    if host.contains(char::is_whitespace)
        || host.contains('/')
        || host.contains('\\')
        || host.contains('@')
        || host.contains(':')
    {
        return Err(AppError::Validation(
            "host must not contain whitespace, schemes, credentials or ports".into(),
        ));
    }
    if !host
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_' | ':'))
    {
        return Err(AppError::Validation("host contains unsupported characters".into()));
    }
    Ok(host.to_ascii_lowercase())
}

pub fn validate_username(raw: &str) -> Result<String, AppError> {
    let username = raw.trim();
    if username.is_empty() || username.len() > 128 {
        return Err(AppError::Validation(
            "database username must be between 1 and 128 characters".into(),
        ));
    }
    if !username
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | '.' | '-' | '$'))
    {
        return Err(AppError::Validation(
            "database username contains unsupported characters".into(),
        ));
    }
    Ok(username.to_string())
}

pub fn validate_database_name(raw: &str) -> Result<String, AppError> {
    let name = raw.trim();
    if name.is_empty() || name.len() > 63 {
        return Err(AppError::Validation(
            "database name must be between 1 and 63 characters".into(),
        ));
    }
    if !name
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | '-' | '.'))
    {
        return Err(AppError::Validation(
            "database name contains unsupported characters".into(),
        ));
    }
    Ok(name.to_string())
}

/// Reject destinations that must never be reachable from the backend (SSRF guard).
///
/// Delegates to the richer [`crate::connections::network::security::DestinationPolicy`];
/// loopback and RFC1918 hosts are legitimate database targets, metadata/link-local
/// addresses are not.
pub fn is_forbidden_ip(ip: &std::net::IpAddr) -> bool {
    crate::connections::network::security::classify(ip, true).is_err()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_host_injection() {
        assert!(validate_host("db.example.com; DROP").is_err());
        assert!(validate_host("http://db.example.com").is_err());
        assert!(validate_host("user@db").is_err());
        assert!(validate_host("db:5432").is_err());
        assert!(validate_host("db.example.com").is_ok());
    }

    #[test]
    fn rejects_metadata_ip() {
        let ip: std::net::IpAddr = "169.254.169.254".parse().unwrap();
        assert!(is_forbidden_ip(&ip));
    }
}
