use std::time::Duration;

use crate::connections::pool::manager::PoolManager;

/// Pool lifecycle states (interpreted by the state machine).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PoolState {
    Uninitialized,
    Creating,
    Ready,
    Draining,
    Closed,
    Unhealthy,
    Failed,
}

impl PoolState {
    pub fn can_transition_to(self, next: PoolState) -> bool {
        use PoolState::*;
        matches!(
            (self, next),
            (Uninitialized, Creating)
                | (Creating, Ready)
                | (Creating, Failed)
                | (Ready, Draining)
                | (Ready, Unhealthy)
                | (Unhealthy, Draining)
                | (Draining, Closed)
                | (Failed, Creating)
        )
    }
}

/// Drain a single connection's pools on configuration change or shutdown.
pub async fn drain_connection(pools: &PoolManager, connection_id: uuid::Uuid) -> usize {
    pools.close_connection(connection_id).await
}

/// Background worker that evicts idle pools. Bounded and cheap: it never touches a pool
/// with an active operation.
pub fn spawn_eviction_worker(
    pools: std::sync::Arc<PoolManager>,
    interval: Duration,
    max_idle: Duration,
) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        let mut ticker = tokio::time::interval(interval);
        ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        loop {
            ticker.tick().await;
            let evicted = pools.evict_idle(max_idle).await;
            if evicted > 0 {
                tracing::debug!(evicted, "idle pool eviction pass");
            }
        }
    })
}
