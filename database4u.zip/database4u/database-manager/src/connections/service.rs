use std::sync::Arc;

use secrecy::SecretString;
use sqlx::{Connection, PgConnection};
use uuid::Uuid;

use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::connections::config::validation::ConnectionConfig;
use crate::connections::config::{NetworkMode, TlsMode};
use crate::connections::credentials::vault::{CredentialVault, StoredCredentialRecord};
use crate::connections::dto::{
    ConnectionHealth, ConnectionMetrics, ConnectionTestReport, ConnectRequest,
    CreateConnectionRequest, DatabaseTargetView, TestConnectionRequest, UpdateConnectionRequest,
};
use crate::connections::isolation::access::{
    require_connection_permission, require_target_permission,
};
use crate::connections::metrics::collector;
use crate::connections::models::{
    ConnectionProfile, ConnectionProfileView, DatabaseTarget, StoredCredential,
};
use crate::connections::pool::manager::PoolEntry;
use crate::connections::pool::PoolConfig;
use crate::connections::repository::{self, ConnectionUpdate, NewConnection};
use crate::connections::testing::{run_test, TestTarget};
use crate::security::audit;
use crate::security::permissions::policy;

pub async fn list_connections(
    state: &AppState,
    actor: Uuid,
) -> Result<Vec<ConnectionProfileView>, AppError> {
    let rows = repository::list_for_user(&state.db, actor).await?;
    Ok(rows.into_iter().map(ConnectionProfileView::from).collect())
}

pub async fn get_connection(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<ConnectionProfileView, AppError> {
    repository::get_for_user(&state.db, actor, connection_id)
        .await?
        .map(ConnectionProfileView::from)
        .ok_or_else(|| AppError::NotFound("connection not found".into()))
}

pub async fn create_connection(
    state: &AppState,
    actor: Uuid,
    request: CreateConnectionRequest,
) -> Result<ConnectionProfileView, AppError> {
    policy::require_project_permission(
        &state.db,
        actor,
        request.project_id,
        "connection.manage",
    )
    .await?;

    let tls = request.tls_mode.unwrap_or_default();
    let network_mode = request.network_mode.unwrap_or_default();
    let config = ConnectionConfig::validate(
        &request.host,
        request.port.unwrap_or(5432),
        &request.username,
        request.database.as_deref().unwrap_or("postgres"),
        tls,
        request.connect_timeout_secs.unwrap_or(5),
    )?;

    let new = NewConnection::from_parts(
        &request.display_name,
        &config,
        network_mode.as_str(),
        request.project_id,
        request.acquire_timeout_secs.unwrap_or(5),
        request.idle_timeout_secs.unwrap_or(300),
        request.max_lifetime_secs.unwrap_or(1800),
    )?;

    let vault = CredentialVault::new((*state.crypto).clone());
    let password = SecretString::new(request.password);
    let (_credential_id, payload) = vault.prepare_for_storage(&password)?;

    let profile = repository::create(
        &state.db,
        &new,
        &payload.ciphertext,
        &payload.nonce,
    )
    .await?;

    // Register the initial database target (defaults to `postgres` for discovery).
    let _ = repository::upsert_database_target(
        &state.db,
        profile.connection_id,
        request.database.as_deref().unwrap_or("postgres"),
    )
    .await;

    audit::record_connection(
        &state.db,
        Some(actor),
        Some(request.project_id),
        Some(profile.connection_id),
        "connection.create",
        true,
    )
    .await;

    crate::connections::audit::record_event(
        &state.db,
        profile.connection_id,
        None,
        "registered",
        Some("profile created"),
    )
    .await;

    Ok(ConnectionProfileView::from(profile))
}

pub async fn update_connection(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
    request: UpdateConnectionRequest,
) -> Result<ConnectionProfileView, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.manage").await?;

    let existing = repository::get_for_user(&state.db, actor, connection_id)
        .await?
        .ok_or_else(|| AppError::NotFound("connection not found".into()))?;

    // Validate any changed network fields before touching the database.
    if let Some(host) = request.host.as_deref() {
        crate::connections::config::validation::validate_host(host)?;
    }
    if let Some(username) = request.username.as_deref() {
        crate::connections::config::validation::validate_username(username)?;
    }
    let tls_mode = match request.tls_mode {
        Some(tls) => Some(tls.as_str().to_string()),
        None => None,
    };
    let network_mode = match request.network_mode {
        Some(mode) => Some(mode.as_str().to_string()),
        None => None,
    };

    if let Some(password) = request.password.as_ref() {
        let vault = CredentialVault::new((*state.crypto).clone());
        let secret = SecretString::new(password.clone());
        let (_id, payload) = vault.prepare_for_storage(&secret)?;
        repository::replace_credential(
            &state.db,
            connection_id,
            &payload.ciphertext,
            &payload.nonce,
        )
        .await?;
    }

    let update = ConnectionUpdate {
        display_name: request.display_name,
        host: request.host,
        port: request.port,
        username: request.username,
        scope: request.scope,
        network_mode,
        tls_mode,
        connect_timeout: request.connect_timeout_secs,
        acquire_timeout: request.acquire_timeout_secs,
        idle_timeout: request.idle_timeout_secs,
        max_lifetime: request.max_lifetime_secs,
        is_enabled: request.is_enabled,
    };

    let profile = repository::update(&state.db, connection_id, &update).await?;

    // Configuration changed: drain existing pools so they are recreated from the new
    // configuration on demand.
    let drained = state.pools.close_connection(connection_id).await;

    crate::connections::audit::record_event(
        &state.db,
        connection_id,
        Some("connected"),
        "registered",
        Some(if drained > 0 {
            "configuration changed; pools drained"
        } else {
            "configuration changed"
        }),
    )
    .await;

    audit::record_connection(
        &state.db,
        Some(actor),
        None,
        Some(connection_id),
        "connection.update",
        true,
    )
    .await;

    let _ = existing;
    Ok(ConnectionProfileView::from(profile))
}

/// Rotate the stored password without touching the rest of the profile.
///
/// Existing pools are drained so the next request reconnects with the new secret.
pub async fn rotate_credential(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
    request: super::dto::RotateCredentialRequest,
) -> Result<(), AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.manage").await?;

    if request.password.trim().is_empty() {
        return Err(AppError::Validation(
            "new password must not be empty".into(),
        ));
    }

    let vault = CredentialVault::new((*state.crypto).clone());
    let secret = SecretString::new(request.password);
    let (_id, payload) = vault.prepare_for_storage(&secret)?;

    repository::replace_credential(
        &state.db,
        connection_id,
        &payload.ciphertext,
        &payload.nonce,
    )
    .await?;

    state.pools.close_connection(connection_id).await;

    audit::record_connection(
        &state.db,
        Some(actor),
        None,
        Some(connection_id),
        "connection.credential_rotated",
        true,
    )
    .await;

    Ok(())
}

pub async fn delete_connection(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<(), AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.manage").await?;

    state.pools.close_connection(connection_id).await;
    repository::delete(&state.db, connection_id).await?;

    audit::record_connection(
        &state.db,
        Some(actor),
        None,
        Some(connection_id),
        "connection.delete",
        true,
    )
    .await;

    Ok(())
}

pub async fn test_connection(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
    request: TestConnectionRequest,
) -> Result<ConnectionTestReport, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.use").await?;

    let profile = repository::get_for_user(&state.db, actor, connection_id)
        .await?
        .ok_or_else(|| AppError::NotFound("connection not found".into()))?;

    if profile.network_mode == NetworkMode::SshTunnel.as_str() {
        return Err(AppError::BadRequest(
            "ssh tunnel support is not enabled in this build".into(),
        ));
    }

    let password = match request.password {
        Some(password) => SecretString::new(password),
        None => decrypt_stored_password(state, connection_id).await?,
    };

    let tls = TlsMode::parse(&profile.tls_mode).unwrap_or_default();
    let target = TestTarget {
        host: profile.host.clone(),
        port: profile.port as u16,
        username: profile.username.clone(),
        database: request.database.unwrap_or_else(|| "postgres".to_string()),
        tls,
        timeout: std::time::Duration::from_secs(profile.connect_timeout.max(1) as u64),
    };

    let started = std::time::Instant::now();
    let (stages, success) = run_test(&target, &password).await;

    audit::record_connection(
        &state.db,
        Some(actor),
        None,
        Some(connection_id),
        "connection.test",
        success,
    )
    .await;

    Ok(ConnectionTestReport {
        connection_id,
        success,
        stages,
        total_elapsed_ms: started.elapsed().as_millis() as u64,
    })
}

/// Lazily create (or reuse) the pool for a database target after authorization.
pub async fn pool_for_target(
    state: &AppState,
    actor: Uuid,
    target_id: Uuid,
) -> Result<Arc<PoolEntry>, AppError> {
    require_target_permission(&state.db, actor, target_id, "connection.use").await?;
    build_pool_for_target(state, target_id).await
}

/// Internal variant without a user check — only for trusted background paths.
pub async fn build_pool_for_target(
    state: &AppState,
    target_id: Uuid,
) -> Result<Arc<PoolEntry>, AppError> {
    let target = repository::find_database_target(&state.db, target_id)
        .await?
        .ok_or_else(|| AppError::NotFound("database target not found".into()))?;

    if let Some(entry) = state.pools.get(target_id).await {
        entry.touch();
        return Ok(entry);
    }

    let profile = sqlx::query_as::<_, ConnectionProfile>(
        r#"SELECT connection_id, display_name, scope, host, port, username, credential_id,
                  network_mode, tls_mode, connect_timeout, acquire_timeout, idle_timeout,
                  max_lifetime, is_enabled, created_at, updated_at
           FROM connections WHERE connection_id = $1"#,
    )
    .bind(target.connection_id)
    .fetch_optional(&state.db)
    .await?
    .ok_or_else(|| AppError::NotFound("connection not found".into()))?;

    if !profile.is_enabled {
        return Err(AppError::BadRequest("connection is disabled".into()));
    }
    if profile.network_mode == NetworkMode::SshTunnel.as_str() {
        return Err(AppError::BadRequest(
            "ssh tunnel support is not enabled in this build".into(),
        ));
    }

    let password = decrypt_stored_password(state, profile.connection_id).await?;
    let tls = TlsMode::parse(&profile.tls_mode).unwrap_or_default();

    let config = ConnectionConfig::validate(
        &profile.host,
        profile.port as u16,
        &profile.username,
        &target.database_name,
        tls,
        profile.connect_timeout.max(1) as u64,
    )?;

    // Validate every address the name resolves to before handing it to SQLx. Metadata,
    // link-local and reserved destinations are rejected even when the host is a DNS name.
    crate::connections::network::resolver::resolve(
        &config.host,
        config.port,
        std::time::Duration::from_secs(config.connect_timeout_secs.max(1)),
        &crate::connections::network::security::DestinationPolicy::default(),
    )
    .await
    .map_err(|error| AppError::BadRequest(format!("target address rejected: {}", error.message())))?;

    let options = crate::infrastructure::postgres::connection::PgTarget {
        host: config.host.clone(),
        port: config.port,
        username: config.username.clone(),
        database: config.database.clone(),
    }
    .connect_options(&password, config.tls, config.connect_timeout_secs)?;

    let pool_config = PoolConfig {
        max_connections: 5,
        acquire_timeout_secs: profile.acquire_timeout.max(1) as u64,
        idle_timeout_secs: profile.idle_timeout.max(1) as u64,
        max_lifetime_secs: profile.max_lifetime.max(1) as u64,
    };

    state
        .pools
        .get_or_create(target_id, profile.connection_id, options, &pool_config)
        .await
}

async fn decrypt_stored_password(
    state: &AppState,
    connection_id: Uuid,
) -> Result<SecretString, AppError> {
    let stored: StoredCredential = repository::load_credential(&state.db, connection_id).await?;
    let vault = CredentialVault::new((*state.crypto).clone());
    let record = StoredCredentialRecord {
        credential_id: stored.credential_id,
        encrypted_password: stored.encrypted_password,
        nonce: stored.nonce,
    };
    vault.decrypt_credential(&record)
}

pub async fn connect(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
    request: ConnectRequest,
) -> Result<ConnectionHealth, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.use").await?;

    let target = match request.database_target_id {
        Some(target_id) => repository::find_database_target(&state.db, target_id)
            .await?
            .ok_or_else(|| AppError::NotFound("database target not found".into()))?,
        None => {
            let mut targets = repository::list_database_targets(&state.db, connection_id).await?;
            if targets.is_empty() {
                let created =
                    repository::upsert_database_target(&state.db, connection_id, "postgres")
                        .await?;
                targets.push(created);
            }
            targets.remove(0)
        }
    };

    if target.connection_id != connection_id {
        return Err(AppError::NotFound("database target not found".into()));
    }

    let entry = build_pool_for_target(state, target.database_target_id).await?;
    let (ok, latency) = crate::connections::health::check_pool(
        &entry.pool,
        std::time::Duration::from_secs(5),
    )
    .await;

    audit::record_connection(
        &state.db,
        Some(actor),
        None,
        Some(connection_id),
        "connection.connect",
        ok,
    )
    .await;

    crate::connections::audit::record_event(
        &state.db,
        connection_id,
        None,
        if ok { "connected" } else { "failed" },
        Some("manual connect"),
    )
    .await;

    crate::connections::audit::record_health(
        &state.db,
        connection_id,
        Some(target.database_target_id),
        ok,
        Some(latency),
        None,
    )
    .await;

    Ok(ConnectionHealth {
        connection_id,
        state: if ok { "connected" } else { "failed" },
        database_target_id: Some(target.database_target_id),
        pool_available: true,
        latency_ms: Some(latency),
        checked_at: chrono::Utc::now(),
    })
}

pub async fn disconnect(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<usize, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.use").await?;
    let closed = state.pools.close_connection(connection_id).await;

    audit::record_connection(
        &state.db,
        Some(actor),
        None,
        Some(connection_id),
        "connection.disconnect",
        true,
    )
    .await;

    crate::connections::audit::record_event(
        &state.db,
        connection_id,
        None,
        "disconnected",
        Some("manual disconnect"),
    )
    .await;

    Ok(closed)
}

pub async fn reconnect(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<ConnectionHealth, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.use").await?;
    state.pools.close_connection(connection_id).await;

    connect(
        state,
        actor,
        connection_id,
        ConnectRequest {
            database_target_id: None,
        },
    )
    .await
}

pub async fn health(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<ConnectionHealth, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.use").await?;

    let pools = state.pools.pools_for_connection(connection_id).await;
    if pools.is_empty() {
        return Ok(ConnectionHealth {
            connection_id,
            state: "disconnected",
            database_target_id: None,
            pool_available: false,
            latency_ms: None,
            checked_at: chrono::Utc::now(),
        });
    }

    let entry = &pools[0];
    entry.touch();
    let (ok, latency) =
        crate::connections::health::check_pool(&entry.pool, std::time::Duration::from_secs(5)).await;

    crate::connections::audit::record_health(
        &state.db,
        connection_id,
        Some(entry.target_id),
        ok,
        Some(latency),
        None,
    )
    .await;

    Ok(ConnectionHealth {
        connection_id,
        state: if ok { "connected" } else { "degraded" },
        database_target_id: Some(entry.target_id),
        pool_available: true,
        latency_ms: Some(latency),
        checked_at: chrono::Utc::now(),
    })
}

pub async fn metrics(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<ConnectionMetrics, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.read").await?;
    let snapshot = collector::collect(&state.pools, connection_id).await;

    Ok(ConnectionMetrics {
        connection_id,
        active_pools: snapshot.active_pools,
        idle_connections: snapshot.idle_connections,
        in_use_connections: snapshot.in_use_connections,
        max_connections: snapshot.max_connections,
        budget_used: snapshot.budget_used,
        budget_limit: snapshot.budget_limit,
    })
}

pub async fn list_targets(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<Vec<DatabaseTargetView>, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.read").await?;

    let rows: Vec<DatabaseTarget> =
        repository::list_database_targets(&state.db, connection_id).await?;

    Ok(rows
        .into_iter()
        .map(|target| DatabaseTargetView {
            database_target_id: target.database_target_id,
            connection_id: target.connection_id,
            database_name: target.database_name,
            is_enabled: target.is_enabled,
            last_discovered_at: target.last_discovered_at,
        })
        .collect())
}

/// Discover databases on the server and register new targets.
pub async fn discover_databases(
    state: &AppState,
    actor: Uuid,
    connection_id: Uuid,
) -> Result<Vec<DatabaseTargetView>, AppError> {
    require_connection_permission(&state.db, actor, connection_id, "connection.manage").await?;

    let mut targets = repository::list_database_targets(&state.db, connection_id).await?;
    if targets.is_empty() {
        targets.push(
            repository::upsert_database_target(&state.db, connection_id, "postgres").await?,
        );
    }

    let entry = build_pool_for_target(state, targets[0].database_target_id).await?;

    let names = sqlx::query_scalar::<_, String>(
        "SELECT datname FROM pg_database WHERE datallowconn AND NOT datistemplate ORDER BY datname",
    )
    .fetch_all(&entry.pool)
    .await?;

    for name in &names {
        if let Err(error) =
            repository::upsert_database_target(&state.db, connection_id, name).await
        {
            tracing::warn!(database = %name, error = %error, "failed to register database target");
        }
    }

    list_targets(state, actor, connection_id).await
}

/// Verify that a connection's pool budget/policy allows the requested database.
pub async fn resolve_target(
    state: &AppState,
    actor: Uuid,
    database_target_id: Uuid,
) -> Result<(Arc<PoolEntry>, DatabaseTarget), AppError> {
    require_target_permission(&state.db, actor, database_target_id, "connection.use").await?;
    let target = repository::find_database_target(&state.db, database_target_id)
        .await?
        .ok_or_else(|| AppError::NotFound("database target not found".into()))?;
    let entry = build_pool_for_target(state, database_target_id).await?;
    Ok((entry, target))
}

/// Kept for symmetry with the registry submodules.
pub async fn ping_database(pool: &sqlx::PgPool) -> Result<(), AppError> {
    sqlx::query("SELECT 1")
        .execute(pool)
        .await
        .map_err(AppError::Database)?;
    Ok(())
}

/// Close a temporary connection helper (used by discovery paths).
pub async fn close_temp(connection: &mut PgConnection) {
    let _ = connection.close().await;
}

/// List connections linked to a project. Requires `project.read` on the project.
pub async fn list_connections_for_project(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
) -> Result<Vec<ConnectionProfileView>, AppError> {
    policy::require_project_permission(&state.db, actor, project_id, "project.read")
        .await?;
    let rows = repository::list_connections_for_project(&state.db, project_id).await?;
    Ok(rows.into_iter().map(ConnectionProfileView::from).collect())
}

/// Link an existing connection to a project.
///
/// Requires `project.members.manage` on the project and `connection.manage` on the
/// connection. Idempotent: linking an already-linked connection is a no-op.
pub async fn link_connection_to_project(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
    connection_id: Uuid,
) -> Result<(), AppError> {
    policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.members.manage",
    )
    .await?;
    require_connection_permission(&state.db, actor, connection_id, "connection.manage")
        .await?;

    repository::link_connection_to_project(&state.db, connection_id, project_id).await?;

    audit::record_connection(
        &state.db,
        Some(actor),
        Some(project_id),
        Some(connection_id),
        "connection.link_to_project",
        true,
    )
    .await;

    Ok(())
}

/// Unlink a connection from a project.
///
/// Requires `project.members.manage` on the project and `connection.manage` on the
/// connection. Drains any pools for the connection so in-flight queries are not
/// stranded by the unlink.
pub async fn unlink_connection_from_project(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
    connection_id: Uuid,
) -> Result<(), AppError> {
    policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.members.manage",
    )
    .await?;
    require_connection_permission(&state.db, actor, connection_id, "connection.manage")
        .await?;

    let removed = repository::unlink_connection_from_project(&state.db, connection_id, project_id).await?;
    if !removed {
        return Err(AppError::NotFound(
            "connection is not linked to this project".into(),
        ));
    }

    // Drain pools so any active sessions through this connection are closed.
    state.pools.close_connection(connection_id).await;

    audit::record_connection(
        &state.db,
        Some(actor),
        Some(project_id),
        Some(connection_id),
        "connection.unlink_from_project",
        true,
    )
    .await;

    Ok(())
}
