use uuid::Uuid;

use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::projects::models::{
    AddMemberRequest, CreateProjectRequest, Project, ProjectMember, UpdateMemberRequest,
    UpdateProjectRequest,
};
use crate::projects::repository;
use crate::security::audit;

pub async fn create(
    state: &AppState,
    actor: Uuid,
    request: CreateProjectRequest,
) -> Result<Project, AppError> {
    let project = repository::create(
        &state.db,
        &request.name,
        request.description.as_deref(),
        actor,
    )
    .await?;

    audit::record(
        &state.db,
        Some(actor),
        Some(project.project_id),
        "project.create",
        "project",
        true,
        None,
        None,
    )
    .await;

    Ok(project)
}

pub async fn list(state: &AppState, actor: Uuid) -> Result<Vec<Project>, AppError> {
    repository::list_for_user(&state.db, actor).await
}

pub async fn get(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
) -> Result<Project, AppError> {
    repository::get_for_user(&state.db, actor, project_id)
        .await?
        .ok_or_else(|| AppError::NotFound("project not found".into()))
}

pub async fn update(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
    request: UpdateProjectRequest,
) -> Result<Project, AppError> {
    crate::security::permissions::policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.update",
    )
    .await?;

    let project = repository::update(
        &state.db,
        project_id,
        request.name.as_deref(),
        request.description.as_deref(),
        request.is_archived,
    )
    .await?;

    audit::record(
        &state.db,
        Some(actor),
        Some(project_id),
        "project.update",
        "project",
        true,
        None,
        None,
    )
    .await;

    Ok(project)
}

pub async fn archive(state: &AppState, actor: Uuid, project_id: Uuid) -> Result<(), AppError> {
    crate::security::permissions::policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.delete",
    )
    .await?;

    repository::archive(&state.db, project_id).await?;

    audit::record(
        &state.db,
        Some(actor),
        Some(project_id),
        "project.archive",
        "project",
        true,
        None,
        None,
    )
    .await;

    Ok(())
}

pub async fn list_members(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
) -> Result<Vec<ProjectMember>, AppError> {
    crate::security::permissions::policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.read",
    )
    .await?;

    repository::list_members(&state.db, project_id).await
}

pub async fn add_member(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
    request: AddMemberRequest,
) -> Result<(), AppError> {
    crate::security::permissions::policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.members.manage",
    )
    .await?;

    let role = request.role.as_deref().unwrap_or("viewer");
    repository::add_member(&state.db, project_id, request.user_id, role).await?;

    audit::record(
        &state.db,
        Some(actor),
        Some(project_id),
        "project.member_added",
        "project_member",
        true,
        None,
        None,
    )
    .await;

    Ok(())
}

pub async fn update_member(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
    user_id: Uuid,
    request: UpdateMemberRequest,
) -> Result<(), AppError> {
    crate::security::permissions::policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.members.manage",
    )
    .await?;

    repository::update_member_role(&state.db, project_id, user_id, &request.role).await?;

    audit::record(
        &state.db,
        Some(actor),
        Some(project_id),
        "project.member_role_updated",
        "project_member",
        true,
        None,
        None,
    )
    .await;

    Ok(())
}

pub async fn remove_member(
    state: &AppState,
    actor: Uuid,
    project_id: Uuid,
    user_id: Uuid,
) -> Result<(), AppError> {
    crate::security::permissions::policy::require_project_permission(
        &state.db,
        actor,
        project_id,
        "project.members.manage",
    )
    .await?;

    repository::remove_member(&state.db, project_id, user_id).await?;

    audit::record(
        &state.db,
        Some(actor),
        Some(project_id),
        "project.member_removed",
        "project_member",
        true,
        None,
        None,
    )
    .await;

    Ok(())
}
