use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::common::validation::validate_display_name;
use crate::projects::models::{Project, ProjectMember};

pub async fn create(
    pool: &PgPool,
    name: &str,
    description: Option<&str>,
    owner_user_id: Uuid,
) -> Result<Project, AppError> {
    let name = validate_display_name(name, 128)?;

    let mut tx = pool.begin().await?;

    let project = sqlx::query_as::<_, Project>(
        r#"INSERT INTO projects (name, description, owner_user_id)
           VALUES ($1, $2, $3)
           RETURNING project_id, name, description, owner_user_id, is_archived, created_at, updated_at"#,
    )
    .bind(&name)
    .bind(description)
    .bind(owner_user_id)
    .fetch_one(&mut *tx)
    .await?;

    sqlx::query(
        "INSERT INTO project_members (project_id, user_id, role) VALUES ($1, $2, 'owner')",
    )
    .bind(project.project_id)
    .bind(owner_user_id)
    .execute(&mut *tx)
    .await?;

    sqlx::query(
        r#"INSERT INTO project_member_roles (project_id, user_id, role_id)
           SELECT $1, $2, role_id FROM roles WHERE role_name = 'owner'"#,
    )
    .bind(project.project_id)
    .bind(owner_user_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;
    Ok(project)
}

pub async fn list_for_user(pool: &PgPool, user_id: Uuid) -> Result<Vec<Project>, AppError> {
    let rows = sqlx::query_as::<_, Project>(
        r#"SELECT p.project_id, p.name, p.description, p.owner_user_id, p.is_archived,
                  p.created_at, p.updated_at
           FROM projects p
           JOIN project_members pm ON pm.project_id = p.project_id
           WHERE pm.user_id = $1
           ORDER BY p.created_at DESC"#,
    )
    .bind(user_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

/// Project lookups are always scoped by membership: a guessed UUID returns `None`.
pub async fn get_for_user(
    pool: &PgPool,
    user_id: Uuid,
    project_id: Uuid,
) -> Result<Option<Project>, AppError> {
    let row = sqlx::query_as::<_, Project>(
        r#"SELECT p.project_id, p.name, p.description, p.owner_user_id, p.is_archived,
                  p.created_at, p.updated_at
           FROM projects p
           JOIN project_members pm ON pm.project_id = p.project_id
           WHERE p.project_id = $1 AND pm.user_id = $2"#,
    )
    .bind(project_id)
    .bind(user_id)
    .fetch_optional(pool)
    .await?;
    Ok(row)
}

pub async fn update(
    pool: &PgPool,
    project_id: Uuid,
    name: Option<&str>,
    description: Option<&str>,
    is_archived: Option<bool>,
) -> Result<Project, AppError> {
    if let Some(name) = name {
        validate_display_name(name, 128)?;
    }

    let row = sqlx::query_as::<_, Project>(
        r#"UPDATE projects
           SET name = COALESCE($2, name),
               description = COALESCE($3, description),
               is_archived = COALESCE($4, is_archived),
               updated_at = now()
           WHERE project_id = $1
           RETURNING project_id, name, description, owner_user_id, is_archived, created_at, updated_at"#,
    )
    .bind(project_id)
    .bind(name)
    .bind(description)
    .bind(is_archived)
    .fetch_optional(pool)
    .await?
    .ok_or_else(|| AppError::NotFound("project not found".into()))?;

    Ok(row)
}

pub async fn archive(pool: &PgPool, project_id: Uuid) -> Result<(), AppError> {
    let affected = sqlx::query(
        "UPDATE projects SET is_archived = true, updated_at = now() WHERE project_id = $1",
    )
    .bind(project_id)
    .execute(pool)
    .await?
    .rows_affected();

    if affected == 0 {
        return Err(AppError::NotFound("project not found".into()));
    }
    Ok(())
}

pub async fn list_members(
    pool: &PgPool,
    project_id: Uuid,
) -> Result<Vec<ProjectMember>, AppError> {
    let rows = sqlx::query_as::<_, ProjectMember>(
        r#"SELECT pm.user_id, u.username, pm.role, pm.created_at AS joined_at
           FROM project_members pm
           JOIN users u ON u.user_id = pm.user_id
           WHERE pm.project_id = $1
           ORDER BY pm.created_at ASC"#,
    )
    .bind(project_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn add_member(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Uuid,
    role_name: &str,
) -> Result<(), AppError> {
    let role_id = sqlx::query_scalar::<_, Uuid>("SELECT role_id FROM roles WHERE role_name = $1")
        .bind(role_name)
        .fetch_optional(pool)
        .await?
        .ok_or_else(|| AppError::BadRequest(format!("unknown role: {role_name}")))?;

    let mut tx = pool.begin().await?;

    sqlx::query(
        r#"INSERT INTO project_members (project_id, user_id, role)
           VALUES ($1, $2, $3)
           ON CONFLICT (project_id, user_id) DO UPDATE SET role = EXCLUDED.role"#,
    )
    .bind(project_id)
    .bind(user_id)
    .bind(role_name)
    .execute(&mut *tx)
    .await?;

    sqlx::query(
        r#"INSERT INTO project_member_roles (project_id, user_id, role_id)
           VALUES ($1, $2, $3)
           ON CONFLICT (project_id, user_id) DO UPDATE SET role_id = EXCLUDED.role_id"#,
    )
    .bind(project_id)
    .bind(user_id)
    .bind(role_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;
    Ok(())
}

pub async fn update_member_role(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Uuid,
    role_name: &str,
) -> Result<(), AppError> {
    // The last owner can never be demoted: that would orphan the project.
    if role_name != "owner" {
        let owners = sqlx::query_scalar::<_, i64>(
            "SELECT COUNT(*) FROM project_members WHERE project_id = $1 AND role = 'owner'",
        )
        .bind(project_id)
        .fetch_one(pool)
        .await?;
        let is_current_owner = sqlx::query_scalar::<_, bool>(
            "SELECT EXISTS(SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2 AND role = 'owner')",
        )
        .bind(project_id)
        .bind(user_id)
        .fetch_one(pool)
        .await?;

        if owners <= 1 && is_current_owner {
            return Err(AppError::Conflict(
                "cannot demote the last project owner".into(),
            ));
        }
    }

    add_member(pool, project_id, user_id, role_name).await
}

pub async fn remove_member(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Uuid,
) -> Result<(), AppError> {
    let is_owner = sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS(SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2 AND role = 'owner')",
    )
    .bind(project_id)
    .bind(user_id)
    .fetch_one(pool)
    .await?;

    if is_owner {
        let owners = sqlx::query_scalar::<_, i64>(
            "SELECT COUNT(*) FROM project_members WHERE project_id = $1 AND role = 'owner'",
        )
        .bind(project_id)
        .fetch_one(pool)
        .await?;
        if owners <= 1 {
            return Err(AppError::Conflict(
                "cannot remove the last project owner".into(),
            ));
        }
    }

    let mut tx = pool.begin().await?;
    sqlx::query("DELETE FROM project_member_roles WHERE project_id = $1 AND user_id = $2")
        .bind(project_id)
        .bind(user_id)
        .execute(&mut *tx)
        .await?;
    let affected = sqlx::query("DELETE FROM project_members WHERE project_id = $1 AND user_id = $2")
        .bind(project_id)
        .bind(user_id)
        .execute(&mut *tx)
        .await?
        .rows_affected();
    tx.commit().await?;

    if affected == 0 {
        return Err(AppError::NotFound("project member not found".into()));
    }
    Ok(())
}
