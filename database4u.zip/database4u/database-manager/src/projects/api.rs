use axum::extract::{Path, State};
use axum::Json;
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::{Ack, ApiResponse};
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::connections::models::ConnectionProfileView;
use crate::connections::service as connection_service;
use crate::projects::models::{
    AddMemberRequest, AddProjectConnectionRequest, CreateProjectRequest, Project,
    ProjectMember, ProjectPermissionsResponse, UpdateMemberRequest, UpdateProjectRequest,
};
use crate::projects::service;

pub async fn list_projects(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<Json<ApiResponse<Vec<Project>>>, AppError> {
    let projects = service::list(&state, user.user_id).await?;
    Ok(Json(ApiResponse::ok(projects)))
}

pub async fn create_project(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<CreateProjectRequest>,
) -> Result<Json<ApiResponse<Project>>, AppError> {
    let project = service::create(&state, user.user_id, request).await?;
    Ok(Json(ApiResponse::ok(project)))
}

pub async fn get_project(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Project>>, AppError> {
    let project = service::get(&state, user.user_id, project_id).await?;
    Ok(Json(ApiResponse::ok(project)))
}

pub async fn update_project(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
    Json(request): Json<UpdateProjectRequest>,
) -> Result<Json<ApiResponse<Project>>, AppError> {
    let project = service::update(&state, user.user_id, project_id, request).await?;
    Ok(Json(ApiResponse::ok(project)))
}

pub async fn archive_project(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    service::archive(&state, user.user_id, project_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("project archived"))))
}

pub async fn list_members(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Vec<ProjectMember>>>, AppError> {
    let members = service::list_members(&state, user.user_id, project_id).await?;
    Ok(Json(ApiResponse::ok(members)))
}

pub async fn add_member(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
    Json(request): Json<AddMemberRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    service::add_member(&state, user.user_id, project_id, request).await?;
    Ok(Json(ApiResponse::ok(Ack::new("member added"))))
}

pub async fn update_member(
    State(state): State<AppState>,
    user: AuthUser,
    Path((project_id, member_id)): Path<(Uuid, Uuid)>,
    Json(request): Json<UpdateMemberRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    service::update_member(&state, user.user_id, project_id, member_id, request).await?;
    Ok(Json(ApiResponse::ok(Ack::new("member updated"))))
}

pub async fn remove_member(
    State(state): State<AppState>,
    user: AuthUser,
    Path((project_id, member_id)): Path<(Uuid, Uuid)>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    service::remove_member(&state, user.user_id, project_id, member_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("member removed"))))
}

pub async fn project_permissions(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
) -> Result<Json<ApiResponse<ProjectPermissionsResponse>>, AppError> {
    service::get(&state, user.user_id, project_id).await?;
    let permissions = crate::security::permissions::policy::effective_permissions(
        &state.db,
        user.user_id,
        project_id,
    )
    .await?;
    Ok(Json(ApiResponse::ok(ProjectPermissionsResponse {
        project_id,
        permissions,
    })))
}

// --- Project <-> connection mapping ---

/// List connections linked to a project.
pub async fn list_project_connections(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Vec<ConnectionProfileView>>>, AppError> {
    let connections = connection_service::list_connections_for_project(&state, user.user_id, project_id).await?;
    Ok(Json(ApiResponse::ok(connections)))
}

/// Link an existing connection to a project.
pub async fn add_project_connection(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
    Json(request): Json<AddProjectConnectionRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    connection_service::link_connection_to_project(&state, user.user_id, project_id, request.connection_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("connection linked to project"))))
}

/// Unlink a connection from a project.
pub async fn remove_project_connection(
    State(state): State<AppState>,
    user: AuthUser,
    Path((project_id, connection_id)): Path<(Uuid, Uuid)>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    connection_service::unlink_connection_from_project(&state, user.user_id, project_id, connection_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("connection unlinked from project"))))
}
