use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::files::validation::sanitize_filename;

/// Internal database row for a file record.
#[derive(Debug, Clone, sqlx::FromRow)]
pub struct FileRecord {
    pub file_id: Uuid,
    pub project_id: Uuid,
    pub owner_user_id: Option<Uuid>,
    pub original_name: String,
    pub storage_key: String,
    pub media_type: String,
    pub extension: String,
    pub size_bytes: i64,
    pub checksum: String,
    pub storage_provider: String,
    pub status: String,
    pub created_at: DateTime<Utc>,
    pub deleted_at: Option<DateTime<Utc>>,
}

/// Public sanitized view of a file metadata record.
/// Never leaks the internal storage key or filesystem paths.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileView {
    pub file_id: Uuid,
    pub project_id: Uuid,
    pub owner_user_id: Option<Uuid>,
    pub original_name: String,
    pub media_type: String,
    pub extension: String,
    pub size_bytes: i64,
    pub checksum: String,
    pub status: String,
    pub created_at: DateTime<Utc>,
}

impl From<FileRecord> for FileView {
    fn from(r: FileRecord) -> Self {
        Self {
            file_id: r.file_id,
            project_id: r.project_id,
            owner_user_id: r.owner_user_id,
            original_name: r.original_name,
            media_type: r.media_type,
            extension: r.extension,
            size_bytes: r.size_bytes,
            checksum: r.checksum,
            status: r.status,
            created_at: r.created_at,
        }
    }
}

#[derive(Debug, Deserialize)]
pub struct UpdateFileRequest {
    pub original_name: String,
}

pub struct CreateFileParams<'a> {
    pub project_id: Uuid,
    pub owner_user_id: Option<Uuid>,
    pub original_name: &'a str,
    pub storage_key: &'a str,
    pub media_type: &'a str,
    pub extension: &'a str,
    pub size_bytes: i64,
    pub checksum: &'a str,
    pub storage_provider: &'a str,
    pub status: &'a str,
}

pub async fn create_file_record(
    pool: &PgPool,
    params: CreateFileParams<'_>,
) -> Result<FileRecord, AppError> {
    let sanitized_name = sanitize_filename(params.original_name);

    let record = sqlx::query_as!(
        FileRecord,
        r#"
        INSERT INTO files (
            project_id, owner_user_id, original_name, storage_key,
            media_type, extension, size_bytes, checksum, storage_provider, status,
            created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
        RETURNING
            file_id, project_id, owner_user_id, original_name, storage_key,
            media_type, extension, size_bytes, checksum, storage_provider, status,
            created_at, deleted_at
        "#,
        params.project_id,
        params.owner_user_id,
        sanitized_name,
        params.storage_key,
        params.media_type,
        params.extension,
        params.size_bytes,
        params.checksum,
        params.storage_provider,
        params.status
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(record)
}

pub async fn get_file_record(pool: &PgPool, file_id: Uuid) -> Result<Option<FileRecord>, AppError> {
    let record = sqlx::query_as!(
        FileRecord,
        r#"
        SELECT
            file_id, project_id, owner_user_id, original_name, storage_key,
            media_type, extension, size_bytes, checksum, storage_provider, status,
            created_at, deleted_at
        FROM files
        WHERE file_id = $1
        "#,
        file_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(record)
}

pub async fn get_active_file_record(
    pool: &PgPool,
    file_id: Uuid,
) -> Result<Option<FileRecord>, AppError> {
    let record = sqlx::query_as!(
        FileRecord,
        r#"
        SELECT
            file_id, project_id, owner_user_id, original_name, storage_key,
            media_type, extension, size_bytes, checksum, storage_provider, status,
            created_at, deleted_at
        FROM files
        WHERE file_id = $1 AND deleted_at IS NULL AND status = 'ready'
        "#,
        file_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(record)
}

pub async fn list_files_for_project(
    pool: &PgPool,
    project_id: Uuid,
    status_filter: Option<&str>,
    limit: i64,
    offset: i64,
) -> Result<Vec<FileRecord>, AppError> {
    let limit = limit.clamp(1, 100);
    let offset = offset.max(0);

    let rows = if let Some(st) = status_filter {
        sqlx::query_as!(
            FileRecord,
            r#"
            SELECT
                file_id, project_id, owner_user_id, original_name, storage_key,
                media_type, extension, size_bytes, checksum, storage_provider, status,
                created_at, deleted_at
            FROM files
            WHERE project_id = $1 AND status = $2 AND deleted_at IS NULL
            ORDER BY created_at DESC
            LIMIT $3 OFFSET $4
            "#,
            project_id,
            st,
            limit,
            offset
        )
        .fetch_all(pool)
        .await
        .map_err(AppError::Database)?
    } else {
        sqlx::query_as!(
            FileRecord,
            r#"
            SELECT
                file_id, project_id, owner_user_id, original_name, storage_key,
                media_type, extension, size_bytes, checksum, storage_provider, status,
                created_at, deleted_at
            FROM files
            WHERE project_id = $1 AND deleted_at IS NULL
            ORDER BY created_at DESC
            LIMIT $2 OFFSET $3
            "#,
            project_id,
            limit,
            offset
        )
        .fetch_all(pool)
        .await
        .map_err(AppError::Database)?
    };

    Ok(rows)
}

pub async fn rename_file_metadata(
    pool: &PgPool,
    file_id: Uuid,
    new_name: &str,
) -> Result<FileRecord, AppError> {
    let sanitized = sanitize_filename(new_name);

    let record = sqlx::query_as!(
        FileRecord,
        r#"
        UPDATE files
        SET original_name = $2
        WHERE file_id = $1 AND deleted_at IS NULL
        RETURNING
            file_id, project_id, owner_user_id, original_name, storage_key,
            media_type, extension, size_bytes, checksum, storage_provider, status,
            created_at, deleted_at
        "#,
        file_id,
        sanitized
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound("file not found or has been deleted".into()))?;

    Ok(record)
}

pub async fn soft_delete_file(pool: &PgPool, file_id: Uuid) -> Result<FileRecord, AppError> {
    let record = sqlx::query_as!(
        FileRecord,
        r#"
        UPDATE files
        SET status = 'deleted', deleted_at = NOW()
        WHERE file_id = $1 AND deleted_at IS NULL
        RETURNING
            file_id, project_id, owner_user_id, original_name, storage_key,
            media_type, extension, size_bytes, checksum, storage_provider, status,
            created_at, deleted_at
        "#,
        file_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound("file not found or already deleted".into()))?;

    Ok(record)
}

pub async fn update_file_status(
    pool: &PgPool,
    file_id: Uuid,
    new_status: &str,
) -> Result<(), AppError> {
    sqlx::query!(
        "UPDATE files SET status = $2 WHERE file_id = $1",
        file_id,
        new_status
    )
    .execute(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(())
}
