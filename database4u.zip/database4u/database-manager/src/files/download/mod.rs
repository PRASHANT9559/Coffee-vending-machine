use axum::body::Body;
use axum::http::header::{
    ACCEPT_RANGES, CACHE_CONTROL, CONTENT_DISPOSITION, CONTENT_LENGTH, CONTENT_RANGE, CONTENT_TYPE,
    ETAG, RANGE,
};
use axum::http::{HeaderMap, HeaderValue, StatusCode};
use axum::response::Response;
use sqlx::PgPool;
use std::fmt::Write;
use std::sync::Arc;
use tokio_util::io::ReaderStream;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::files::audit::record_file_event;
use crate::files::metadata::get_active_file_record;
use crate::files::permissions::check_file_permission;
use crate::files::storage::{StorageAdapter, StorageKey};

/// Parsed byte range for HTTP 206 Partial Content.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ByteRange {
    pub start: u64,
    pub end: u64,
}

/// Parse standard HTTP `Range: bytes=...` header according to RFC 7233.
pub fn parse_range_header(header: &str, file_size: u64) -> Result<Option<ByteRange>, AppError> {
    let header = header.trim();
    if !header.starts_with("bytes=") {
        return Ok(None);
    }

    let spec = header.strip_prefix("bytes=").unwrap().trim();
    // Multi-range is not supported, take first range specifier
    let first_spec = spec.split(',').next().unwrap_or("").trim();
    if first_spec.is_empty() {
        return Ok(None);
    }

    if let Some((start_str, end_str)) = first_spec.split_once('-') {
        let start_str = start_str.trim();
        let end_str = end_str.trim();

        if start_str.is_empty() {
            // Suffix range: bytes=-500 (last 500 bytes)
            if let Ok(suffix_len) = end_str.parse::<u64>() {
                if suffix_len == 0 {
                    return Err(AppError::BadRequest("invalid range suffix length".into()));
                }
                let clamped_suffix = suffix_len.min(file_size);
                let start = file_size.saturating_sub(clamped_suffix);
                let end = file_size.saturating_sub(1);
                return Ok(Some(ByteRange { start, end }));
            }
        } else if let Ok(start) = start_str.parse::<u64>() {
            if start >= file_size {
                return Err(AppError::BadRequest(format!(
                    "range start {start} is beyond file length {file_size}"
                )));
            }

            let end = if end_str.is_empty() {
                // Open-ended range: bytes=1000-
                file_size - 1
            } else if let Ok(end) = end_str.parse::<u64>() {
                end.min(file_size - 1)
            } else {
                return Err(AppError::BadRequest("invalid range end value".into()));
            };

            if start <= end {
                return Ok(Some(ByteRange { start, end }));
            }
        }
    }

    Err(AppError::BadRequest("malformed HTTP Range header".into()))
}

/// URL encode string bytes (RFC 3986 / RFC 5987 compatible) without external crates.
fn percent_encode_rfc5987(input: &str) -> String {
    let mut encoded = String::with_capacity(input.len() * 2);
    for b in input.bytes() {
        if b.is_ascii_alphanumeric() || b == b'-' || b == b'_' || b == b'.' || b == b'~' {
            encoded.push(b as char);
        } else {
            let _ = write!(encoded, "%{:02X}", b);
        }
    }
    encoded
}

/// Format standard RFC 5987 Content-Disposition header.
pub fn format_content_disposition(filename: &str) -> String {
    let ascii_safe: String = filename
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '.' || c == '_' || c == '-' { c } else { '_' })
        .collect();

    let encoded_utf8 = percent_encode_rfc5987(filename);

    format!(
        "attachment; filename=\"{}\"; filename*=UTF-8''{}",
        ascii_safe, encoded_utf8
    )
}

/// Download handler streaming file contents with HTTP Range support and bounded RAM usage.
pub async fn handle_file_download(
    pool: &PgPool,
    storage: Arc<dyn StorageAdapter>,
    file_id: Uuid,
    actor_user_id: Uuid,
    headers: &HeaderMap,
) -> Result<Response, AppError> {
    let record = get_active_file_record(pool, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found or not ready".into()))?;

    // Check read/download permission
    let allowed = check_file_permission(
        pool,
        actor_user_id,
        file_id,
        record.project_id,
        "file.download",
    )
    .await?;

    if !allowed {
        return Err(AppError::Forbidden("insufficient permissions to download file".into()));
    }

    let storage_key = StorageKey::new(&record.storage_key)?;
    let total_size = record.size_bytes as u64;

    // Check for HTTP Range header
    let range_header = headers.get(RANGE).and_then(|h| h.to_str().ok());
    let byte_range = if let Some(rh) = range_header {
        parse_range_header(rh, total_size)?
    } else {
        None
    };

    let content_disposition = format_content_disposition(&record.original_name);
    let etag = format!("\"{}\"", record.checksum);

    // Audit the download action
    record_file_event(
        pool,
        Some(file_id),
        record.project_id,
        Some(actor_user_id),
        "file_downloaded",
        "success",
        None,
    )
    .await;

    if let Some(range) = byte_range {
        let stream = storage.get_range(&storage_key, range.start, range.end).await?;
        let body_stream = ReaderStream::new(stream);
        let body = Body::from_stream(body_stream);

        let content_range = format!("bytes {}-{}/{}", range.start, range.end, total_size);
        let content_len = (range.end - range.start + 1).to_string();

        let mut res = Response::builder()
            .status(StatusCode::PARTIAL_CONTENT)
            .body(body)
            .map_err(|e| AppError::Internal(format!("failed to build response: {e}")))?;

        let h = res.headers_mut();
        h.insert(
            CONTENT_TYPE,
            HeaderValue::from_str(&record.media_type)
                .unwrap_or(HeaderValue::from_static("application/octet-stream")),
        );
        h.insert(CONTENT_LENGTH, HeaderValue::from_str(&content_len).unwrap());
        h.insert(CONTENT_RANGE, HeaderValue::from_str(&content_range).unwrap());
        h.insert(ACCEPT_RANGES, HeaderValue::from_static("bytes"));
        h.insert(CACHE_CONTROL, HeaderValue::from_static("private, no-store"));
        h.insert(ETAG, HeaderValue::from_str(&etag).unwrap());
        if let Ok(cd) = HeaderValue::from_str(&content_disposition) {
            h.insert(CONTENT_DISPOSITION, cd);
        }

        Ok(res)
    } else {
        let stream = storage.get(&storage_key).await?;
        let body_stream = ReaderStream::new(stream);
        let body = Body::from_stream(body_stream);

        let mut res = Response::builder()
            .status(StatusCode::OK)
            .body(body)
            .map_err(|e| AppError::Internal(format!("failed to build response: {e}")))?;

        let h = res.headers_mut();
        h.insert(
            CONTENT_TYPE,
            HeaderValue::from_str(&record.media_type)
                .unwrap_or(HeaderValue::from_static("application/octet-stream")),
        );
        h.insert(CONTENT_LENGTH, HeaderValue::from_str(&total_size.to_string()).unwrap());
        h.insert(ACCEPT_RANGES, HeaderValue::from_static("bytes"));
        h.insert(CACHE_CONTROL, HeaderValue::from_static("private, no-store"));
        h.insert(ETAG, HeaderValue::from_str(&etag).unwrap());
        if let Ok(cd) = HeaderValue::from_str(&content_disposition) {
            h.insert(CONTENT_DISPOSITION, cd);
        }

        Ok(res)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_range_header() {
        let size = 1000;

        // Valid ranges
        let r1 = parse_range_header("bytes=0-499", size).unwrap().unwrap();
        assert_eq!(r1, ByteRange { start: 0, end: 499 });

        let r2 = parse_range_header("bytes=500-999", size).unwrap().unwrap();
        assert_eq!(r2, ByteRange { start: 500, end: 999 });

        // Open-ended range
        let r3 = parse_range_header("bytes=500-", size).unwrap().unwrap();
        assert_eq!(r3, ByteRange { start: 500, end: 999 });

        // Suffix range (last 200 bytes)
        let r4 = parse_range_header("bytes=-200", size).unwrap().unwrap();
        assert_eq!(r4, ByteRange { start: 800, end: 999 });

        // Out of range
        assert!(parse_range_header("bytes=1500-2000", size).is_err());
    }

    #[test]
    fn test_format_content_disposition() {
        let cd = format_content_disposition("report 2026.pdf");
        assert!(cd.contains("filename=\"report_2026.pdf\"") || cd.contains("filename=\"report 2026.pdf\""));
        assert!(cd.contains("filename*=UTF-8''"));
    }
}
