use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;

pub const DEFAULT_PROJECT_QUOTA_BYTES: i64 = 10 * 1024 * 1024 * 1024; // 10 GB default per project

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageUsage {
    pub project_id: Uuid,
    pub user_id: Option<Uuid>,
    pub used_bytes: i64,
    pub quota_bytes: Option<i64>,
    pub updated_at: DateTime<Utc>,
}

/// Check if adding `incoming_bytes` will violate the quota limit for the given project and user.
pub async fn check_quota(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Option<Uuid>,
    incoming_bytes: i64,
) -> Result<(), AppError> {
    if incoming_bytes <= 0 {
        return Ok(());
    }

    if let Some(uid) = user_id {
        let row = sqlx::query!(
            r#"
            SELECT used_bytes, quota_bytes
            FROM file_storage_usage
            WHERE project_id = $1 AND user_id = $2
            "#,
            project_id,
            uid
        )
        .fetch_optional(pool)
        .await
        .map_err(AppError::Database)?;

        if let Some(usage) = row {
            if let Some(quota) = usage.quota_bytes {
                if usage.used_bytes + incoming_bytes > quota {
                    return Err(AppError::Conflict(format!(
                        "storage quota exceeded: used {} bytes of limit {} bytes",
                        usage.used_bytes + incoming_bytes,
                        quota
                    )));
                }
            }
        }
    }

    // Check project-wide sum
    let total_used = sqlx::query_scalar!(
        r#"
        SELECT COALESCE(SUM(used_bytes), 0)::BIGINT
        FROM file_storage_usage
        WHERE project_id = $1
        "#,
        project_id
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?
    .unwrap_or(0);

    if total_used + incoming_bytes > DEFAULT_PROJECT_QUOTA_BYTES {
        return Err(AppError::Conflict(format!(
            "project storage quota exceeded: total usage would reach {} bytes (limit {} bytes)",
            total_used + incoming_bytes,
            DEFAULT_PROJECT_QUOTA_BYTES
        )));
    }

    Ok(())
}

/// Atomically increase the used bytes.
pub async fn record_usage_addition(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Option<Uuid>,
    bytes: i64,
) -> Result<(), AppError> {
    if bytes <= 0 {
        return Ok(());
    }

    if let Some(uid) = user_id {
        sqlx::query!(
            r#"
            INSERT INTO file_storage_usage (project_id, user_id, used_bytes, quota_bytes, updated_at)
            VALUES ($1, $2, $3, $4, NOW())
            ON CONFLICT (project_id, user_id)
            DO UPDATE SET
                used_bytes = file_storage_usage.used_bytes + EXCLUDED.used_bytes,
                updated_at = NOW()
            "#,
            project_id,
            uid,
            bytes,
            DEFAULT_PROJECT_QUOTA_BYTES
        )
        .execute(pool)
        .await
        .map_err(AppError::Database)?;
    }

    Ok(())
}

/// Atomically decrease the used bytes (e.g. after permanent deletion).
pub async fn record_usage_reduction(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Option<Uuid>,
    bytes: i64,
) -> Result<(), AppError> {
    if bytes <= 0 {
        return Ok(());
    }

    if let Some(uid) = user_id {
        sqlx::query!(
            r#"
            UPDATE file_storage_usage
            SET used_bytes = GREATEST(0, used_bytes - $3),
                updated_at = NOW()
            WHERE project_id = $1 AND user_id = $2
            "#,
            project_id,
            uid,
            bytes
        )
        .execute(pool)
        .await
        .map_err(AppError::Database)?;
    }

    Ok(())
}

/// Retrieve project-wide and user-specific storage usage.
pub async fn get_project_storage_usage(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Option<Uuid>,
) -> Result<StorageUsage, AppError> {
    if let Some(uid) = user_id {
        let row = sqlx::query!(
            r#"
            SELECT used_bytes, quota_bytes, updated_at
            FROM file_storage_usage
            WHERE project_id = $1 AND user_id = $2
            "#,
            project_id,
            uid
        )
        .fetch_optional(pool)
        .await
        .map_err(AppError::Database)?;

        if let Some(r) = row {
            return Ok(StorageUsage {
                project_id,
                user_id: Some(uid),
                used_bytes: r.used_bytes,
                quota_bytes: r.quota_bytes,
                updated_at: r.updated_at,
            });
        }
    }

    // Default project total
    let total_used = sqlx::query_scalar!(
        r#"
        SELECT COALESCE(SUM(used_bytes), 0)::BIGINT
        FROM file_storage_usage
        WHERE project_id = $1
        "#,
        project_id
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?
    .unwrap_or(0);

    Ok(StorageUsage {
        project_id,
        user_id,
        used_bytes: total_used,
        quota_bytes: Some(DEFAULT_PROJECT_QUOTA_BYTES),
        updated_at: Utc::now(),
    })
}
