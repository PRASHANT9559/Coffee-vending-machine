use chrono::Duration;
use sqlx::PgPool;
use std::sync::Arc;
use tokio::time::{interval, Duration as TokioDuration};
use tracing::{error, info, warn};

use crate::common::errors::AppError;
use crate::files::audit::record_file_event;
use crate::files::quotas::record_usage_reduction;
use crate::files::storage::{StorageAdapter, StorageKey};

/// Sweeper that marks expired upload sessions and deletes their temporary storage files.
pub async fn cleanup_expired_upload_sessions(
    pool: &PgPool,
    storage: Arc<dyn StorageAdapter>,
) -> Result<u64, AppError> {
    let expired_rows = sqlx::query!(
        r#"
        SELECT session_id, temp_storage_key, project_id, owner_user_id
        FROM upload_sessions
        WHERE expires_at < NOW() AND status IN ('initiated', 'uploading', 'completing')
        LIMIT 100
        "#
    )
    .fetch_all(pool)
    .await
    .map_err(AppError::Database)?;

    let mut cleaned_count = 0;

    for row in expired_rows {
        // Mark session expired in database
        let _ = sqlx::query!(
            "UPDATE upload_sessions SET status = 'expired', updated_at = NOW() WHERE session_id = $1",
            row.session_id
        )
        .execute(pool)
        .await;

        // Clean up temp file on storage
        if let Ok(temp_key) = StorageKey::new(&row.temp_storage_key) {
            let _ = storage.delete(&temp_key).await;
        }

        record_file_event(
            pool,
            None,
            row.project_id,
            row.owner_user_id,
            "session_expired_cleaned",
            "expired",
            Some(&format!("session_id: {}", row.session_id)),
        )
        .await;

        cleaned_count += 1;
    }

    if cleaned_count > 0 {
        info!(count = cleaned_count, "cleaned up expired upload sessions");
    }

    Ok(cleaned_count)
}

/// Permanently purge soft-deleted files whose retention period has passed.
pub async fn purge_soft_deleted_files(
    pool: &PgPool,
    storage: Arc<dyn StorageAdapter>,
    retention_days: i64,
) -> Result<u64, AppError> {
    let cutoff = chrono::Utc::now() - Duration::days(retention_days);

    let rows = sqlx::query!(
        r#"
        SELECT file_id, project_id, owner_user_id, storage_key, size_bytes
        FROM files
        WHERE status = 'deleted' AND deleted_at < $1
        LIMIT 50
        "#,
        cutoff
    )
    .fetch_all(pool)
    .await
    .map_err(AppError::Database)?;

    let mut purged_count = 0;

    for row in rows {
        // 1. Delete physical object from storage adapter
        if let Ok(key) = StorageKey::new(&row.storage_key) {
            if let Err(e) = storage.delete(&key).await {
                error!(file_id = %row.file_id, error = %e, "failed to delete physical file during purge");
                continue;
            }
        }

        // 2. Reduce used quota
        let _ = record_usage_reduction(pool, row.project_id, row.owner_user_id, row.size_bytes).await;

        // 3. Remove row from files table
        let _ = sqlx::query!("DELETE FROM files WHERE file_id = $1", row.file_id)
            .execute(pool)
            .await;

        // 4. Record audit event
        record_file_event(
            pool,
            Some(row.file_id),
            row.project_id,
            row.owner_user_id,
            "file_permanently_purged",
            "purged",
            Some(&format!("purged file {} ({} bytes)", row.file_id, row.size_bytes)),
        )
        .await;

        purged_count += 1;
    }

    if purged_count > 0 {
        info!(count = purged_count, "purged soft-deleted files past retention");
    }

    Ok(purged_count)
}

/// Spawn a background task to periodically run cleanup sweeps.
pub fn spawn_cleanup_worker(
    pool: PgPool,
    storage: Arc<dyn StorageAdapter>,
    sweep_interval: TokioDuration,
    retention_days: i64,
) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        let mut ticker = interval(sweep_interval);
        loop {
            ticker.tick().await;

            if let Err(e) = cleanup_expired_upload_sessions(&pool, storage.clone()).await {
                warn!(error = %e, "error in cleanup_expired_upload_sessions sweep");
            }

            if let Err(e) = purge_soft_deleted_files(&pool, storage.clone(), retention_days).await {
                warn!(error = %e, "error in purge_soft_deleted_files sweep");
            }
        }
    })
}
