use std::fmt;
use std::path::{Component, Path, PathBuf};
use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::io::AsyncRead;
use uuid::Uuid;

use crate::common::errors::AppError;

/// Strongly typed storage key preventing path traversal and information leaks.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct StorageKey(String);

impl StorageKey {
    /// Generate a new time-partitioned key: `YYYY/MM/<uuid-v4>`.
    pub fn generate() -> Self {
        let now = Utc::now();
        let key = format!("{:04}/{:02}/{}", now.format("%Y"), now.format("%m"), Uuid::new_v4());
        Self(key)
    }

    /// Generate a temporary upload key: `tmp/<uuid-v4>`.
    pub fn generate_temp() -> Self {
        Self(format!("tmp/{}", Uuid::new_v4()))
    }

    /// Construct a StorageKey from an existing validated string.
    pub fn new(key: impl Into<String>) -> Result<Self, AppError> {
        let key_str = key.into();
        Self::validate(&key_str)?;
        Ok(Self(key_str))
    }

    /// Returns the raw relative path key.
    pub fn as_str(&self) -> &str {
        &self.0
    }

    /// Validate the key prevents path traversal and dangerous characters.
    fn validate(raw: &str) -> Result<(), AppError> {
        let trimmed = raw.trim();
        if trimmed.is_empty() {
            return Err(AppError::Validation("storage key cannot be empty".into()));
        }
        if trimmed.starts_with('/') || trimmed.starts_with('\\') {
            return Err(AppError::Validation("storage key cannot start with root slash".into()));
        }
        if trimmed.contains('\0') {
            return Err(AppError::Validation("storage key contains null byte".into()));
        }

        let path = Path::new(trimmed);
        for component in path.components() {
            match component {
                Component::ParentDir => {
                    return Err(AppError::Validation("path traversal attempt in storage key".into()));
                }
                Component::Prefix(_) | Component::RootDir => {
                    return Err(AppError::Validation("absolute prefix not allowed in storage key".into()));
                }
                Component::Normal(part) => {
                    let s = part.to_string_lossy();
                    if s.contains('\\') || s.contains(':') {
                        return Err(AppError::Validation("invalid characters in storage key segment".into()));
                    }
                }
                Component::CurDir => {}
            }
        }

        Ok(())
    }

    /// Safely join to a root directory.
    pub fn to_safe_path(&self, root: &Path) -> Result<PathBuf, AppError> {
        Self::validate(&self.0)?;
        let resolved = root.join(&self.0);
        Ok(resolved)
    }
}

impl fmt::Display for StorageKey {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

/// Metadata describing an object in storage.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectMeta {
    pub size_bytes: u64,
    pub checksum: Option<String>,
    pub last_modified: DateTime<Utc>,
    pub content_type: Option<String>,
}

/// Async storage backend abstraction.
#[async_trait]
pub trait StorageAdapter: Send + Sync {
    /// Stream data into storage at key.
    async fn put(
        &self,
        key: &StorageKey,
        data: &mut (dyn AsyncRead + Unpin + Send),
        size: Option<u64>,
    ) -> Result<ObjectMeta, AppError>;

    /// Retrieve full object stream.
    async fn get(
        &self,
        key: &StorageKey,
    ) -> Result<Box<dyn AsyncRead + Unpin + Send>, AppError>;

    /// Retrieve byte range stream (inclusive start and end bytes).
    async fn get_range(
        &self,
        key: &StorageKey,
        start: u64,
        end: u64,
    ) -> Result<Box<dyn AsyncRead + Unpin + Send>, AppError>;

    /// Check if key exists.
    async fn exists(&self, key: &StorageKey) -> Result<bool, AppError>;

    /// Get object metadata.
    async fn metadata(&self, key: &StorageKey) -> Result<ObjectMeta, AppError>;

    /// Atomically rename/move object from one key to another.
    async fn move_object(&self, from: &StorageKey, to: &StorageKey) -> Result<(), AppError>;

    /// Delete object.
    async fn delete(&self, key: &StorageKey) -> Result<(), AppError>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_storage_key_generation() {
        let key = StorageKey::generate();
        assert!(!key.as_str().is_empty());
        assert!(!key.as_str().starts_with('/'));

        let temp_key = StorageKey::generate_temp();
        assert!(temp_key.as_str().starts_with("tmp/"));
    }

    #[test]
    fn test_storage_key_rejection() {
        assert!(StorageKey::new("../etc/passwd").is_err());
        assert!(StorageKey::new("/root/secret").is_err());
        assert!(StorageKey::new("hello\0world").is_err());
        assert!(StorageKey::new("").is_err());
        assert!(StorageKey::new("2026/11/abc-123").is_ok());
    }
}
