pub mod adapter;
pub mod local_disk;
pub mod object_store;

pub use adapter::{ObjectMeta, StorageAdapter, StorageKey};
pub use local_disk::LocalStorageAdapter;
pub use object_store::ObjectStorageAdapter;
