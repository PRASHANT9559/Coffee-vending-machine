use async_trait::async_trait;
use tokio::io::AsyncRead;

use crate::common::errors::AppError;
use super::adapter::{ObjectMeta, StorageAdapter, StorageKey};

/// Future S3 / GCS object storage adapter stub.
#[derive(Clone, Debug, Default)]
pub struct ObjectStorageAdapter;

impl ObjectStorageAdapter {
    pub fn new() -> Self {
        Self
    }
}

#[async_trait]
impl StorageAdapter for ObjectStorageAdapter {
    async fn put(
        &self,
        _key: &StorageKey,
        _data: &mut (dyn AsyncRead + Unpin + Send),
        _size: Option<u64>,
    ) -> Result<ObjectMeta, AppError> {
        Err(AppError::BadRequest("object storage provider is not currently configured".into()))
    }

    async fn get(
        &self,
        _key: &StorageKey,
    ) -> Result<Box<dyn AsyncRead + Unpin + Send>, AppError> {
        Err(AppError::BadRequest("object storage provider is not currently configured".into()))
    }

    async fn get_range(
        &self,
        _key: &StorageKey,
        _start: u64,
        _end: u64,
    ) -> Result<Box<dyn AsyncRead + Unpin + Send>, AppError> {
        Err(AppError::BadRequest("object storage provider is not currently configured".into()))
    }

    async fn exists(&self, _key: &StorageKey) -> Result<bool, AppError> {
        Err(AppError::BadRequest("object storage provider is not currently configured".into()))
    }

    async fn metadata(&self, _key: &StorageKey) -> Result<ObjectMeta, AppError> {
        Err(AppError::BadRequest("object storage provider is not currently configured".into()))
    }

    async fn move_object(&self, _from: &StorageKey, _to: &StorageKey) -> Result<(), AppError> {
        Err(AppError::BadRequest("object storage provider is not currently configured".into()))
    }

    async fn delete(&self, _key: &StorageKey) -> Result<(), AppError> {
        Err(AppError::BadRequest("object storage provider is not currently configured".into()))
    }
}
