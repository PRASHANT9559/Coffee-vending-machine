use std::path::{Path, PathBuf};
use async_trait::async_trait;
use chrono::Utc;
use sha2::{Digest, Sha256};
use tokio::fs::{self, File, OpenOptions};
use tokio::io::{AsyncRead, AsyncReadExt, AsyncSeekExt, AsyncWriteExt, SeekFrom};
use tracing::{debug, error, info};

use crate::common::errors::AppError;
use super::adapter::{ObjectMeta, StorageAdapter, StorageKey};

const BUFFER_SIZE: usize = 64 * 1024; // 64 KB streaming buffer

/// Local disk storage adapter with bounded streaming, path traversal prevention,
/// and atomic commit operations.
#[derive(Clone, Debug)]
pub struct LocalStorageAdapter {
    root_path: PathBuf,
    temp_path: PathBuf,
}

impl LocalStorageAdapter {
    pub async fn new(root_path: impl AsRef<Path>, temp_path: impl AsRef<Path>) -> Result<Self, AppError> {
        let root = root_path.as_ref().to_path_buf();
        let temp = temp_path.as_ref().to_path_buf();

        fs::create_dir_all(&root).await.map_err(|e| {
            AppError::Internal(format!("failed to initialize storage root directory: {e}"))
        })?;

        fs::create_dir_all(&temp).await.map_err(|e| {
            AppError::Internal(format!("failed to initialize storage temp directory: {e}"))
        })?;

        info!(
            root = %root.display(),
            temp = %temp.display(),
            "local disk storage adapter initialized"
        );

        Ok(Self {
            root_path: root,
            temp_path: temp,
        })
    }

    /// Resolve a key to its physical path. Keys prefixed with `tmp/` are mapped to temp_path,
    /// others are mapped to root_path.
    fn resolve_path(&self, key: &StorageKey) -> Result<PathBuf, AppError> {
        let key_str = key.as_str();
        if let Some(sub) = key_str.strip_prefix("tmp/") {
            let safe_key = StorageKey::new(sub)?;
            safe_key.to_safe_path(&self.temp_path)
        } else {
            key.to_safe_path(&self.root_path)
        }
    }
}

#[async_trait]
impl StorageAdapter for LocalStorageAdapter {
    async fn put(
        &self,
        key: &StorageKey,
        data: &mut (dyn AsyncRead + Unpin + Send),
        _size: Option<u64>,
    ) -> Result<ObjectMeta, AppError> {
        let dest_path = self.resolve_path(key)?;

        if let Some(parent) = dest_path.parent() {
            fs::create_dir_all(parent).await.map_err(|e| {
                AppError::Internal(format!("failed to create storage directories: {e}"))
            })?;
        }

        let mut file = OpenOptions::new()
            .create(true)
            .write(true)
            .truncate(true)
            .open(&dest_path)
            .await
            .map_err(|e| AppError::Internal(format!("failed to open destination file: {e}")))?;

        let mut hasher = Sha256::new();
        let mut buffer = vec![0u8; BUFFER_SIZE];
        let mut total_bytes: u64 = 0;

        loop {
            let n = data.read(&mut buffer).await.map_err(|e| {
                AppError::Internal(format!("error reading input stream during upload: {e}"))
            })?;
            if n == 0 {
                break;
            }
            hasher.update(&buffer[..n]);
            file.write_all(&buffer[..n]).await.map_err(|e| {
                AppError::Internal(format!("error writing chunk to storage: {e}"))
            })?;
            total_bytes += n as u64;
        }

        file.flush().await.map_err(|e| {
            AppError::Internal(format!("failed to flush written file to storage: {e}"))
        })?;

        file.sync_all().await.map_err(|e| {
            AppError::Internal(format!("failed to sync file contents to disk: {e}"))
        })?;

        let checksum = hex::encode(hasher.finalize());
        debug!(key = %key, bytes = total_bytes, checksum = %checksum, "file written to local storage");

        Ok(ObjectMeta {
            size_bytes: total_bytes,
            checksum: Some(checksum),
            last_modified: Utc::now(),
            content_type: None,
        })
    }

    async fn get(
        &self,
        key: &StorageKey,
    ) -> Result<Box<dyn AsyncRead + Unpin + Send>, AppError> {
        let path = self.resolve_path(key)?;
        let file = File::open(&path).await.map_err(|e| {
            if e.kind() == std::io::ErrorKind::NotFound {
                AppError::NotFound("requested file does not exist in storage".into())
            } else {
                AppError::Internal(format!("failed to open file for read: {e}"))
            }
        })?;

        Ok(Box::new(file))
    }

    async fn get_range(
        &self,
        key: &StorageKey,
        start: u64,
        end: u64,
    ) -> Result<Box<dyn AsyncRead + Unpin + Send>, AppError> {
        if start > end {
            return Err(AppError::BadRequest("range start cannot exceed range end".into()));
        }

        let path = self.resolve_path(key)?;
        let mut file = File::open(&path).await.map_err(|e| {
            if e.kind() == std::io::ErrorKind::NotFound {
                AppError::NotFound("requested file does not exist in storage".into())
            } else {
                AppError::Internal(format!("failed to open file for range read: {e}"))
            }
        })?;

        let metadata = file.metadata().await.map_err(|e| {
            AppError::Internal(format!("failed to get file metadata for range request: {e}"))
        })?;

        let file_len = metadata.len();
        if start >= file_len {
            return Err(AppError::BadRequest(format!(
                "range start {start} is beyond file length {file_len}"
            )));
        }

        let clamped_end = end.min(file_len - 1);
        let byte_count = clamped_end - start + 1;

        file.seek(SeekFrom::Start(start)).await.map_err(|e| {
            AppError::Internal(format!("failed to seek to byte {start}: {e}"))
        })?;

        let limited = file.take(byte_count);
        Ok(Box::new(limited))
    }

    async fn exists(&self, key: &StorageKey) -> Result<bool, AppError> {
        let path = self.resolve_path(key)?;
        Ok(fs::try_exists(&path).await.unwrap_or(false))
    }

    async fn metadata(&self, key: &StorageKey) -> Result<ObjectMeta, AppError> {
        let path = self.resolve_path(key)?;
        let meta = fs::metadata(&path).await.map_err(|e| {
            if e.kind() == std::io::ErrorKind::NotFound {
                AppError::NotFound("file not found in storage".into())
            } else {
                AppError::Internal(format!("failed to read file metadata: {e}"))
            }
        })?;

        let last_modified = meta
            .modified()
            .ok()
            .map(|st| chrono::DateTime::<Utc>::from(st))
            .unwrap_or_else(Utc::now);

        Ok(ObjectMeta {
            size_bytes: meta.len(),
            checksum: None,
            last_modified,
            content_type: None,
        })
    }

    async fn move_object(&self, from: &StorageKey, to: &StorageKey) -> Result<(), AppError> {
        let from_path = self.resolve_path(from)?;
        let to_path = self.resolve_path(to)?;

        if let Some(parent) = to_path.parent() {
            fs::create_dir_all(parent).await.map_err(|e| {
                AppError::Internal(format!("failed to create parent directory for target: {e}"))
            })?;
        }

        // Attempt fast atomic filesystem rename
        match fs::rename(&from_path, &to_path).await {
            Ok(_) => Ok(()),
            Err(e) => {
                debug!(
                    error = %e,
                    "atomic rename failed (possibly across mounts), falling back to stream copy and remove"
                );
                // Fallback copy + remove if temp and storage are across mountpoints
                fs::copy(&from_path, &to_path).await.map_err(|e| {
                    AppError::Internal(format!("failed to copy file during move: {e}"))
                })?;
                let _ = fs::remove_file(&from_path).await;
                Ok(())
            }
        }
    }

    async fn delete(&self, key: &StorageKey) -> Result<(), AppError> {
        let path = self.resolve_path(key)?;
        if fs::try_exists(&path).await.unwrap_or(false) {
            fs::remove_file(&path).await.map_err(|e| {
                error!(key = %key, error = %e, "failed to delete file from storage");
                AppError::Internal(format!("failed to delete file from storage: {e}"))
            })?;
        }
        Ok(())
    }
}
