use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::security::permissions::policy::has_project_permission;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FilePermission {
    pub file_permission_id: Uuid,
    pub file_id: Uuid,
    pub subject_type: String, // 'user' or 'role'
    pub subject_id: Uuid,
    pub permission_key: String,
    pub granted_by: Option<Uuid>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Deserialize)]
pub struct GrantPermissionRequest {
    pub subject_type: String,
    pub subject_id: Uuid,
    pub permission_key: String,
}

/// Check if a user has the required permission on a specific file, either through project RBAC
/// or explicit file ACL.
pub async fn check_file_permission(
    pool: &PgPool,
    user_id: Uuid,
    file_id: Uuid,
    project_id: Uuid,
    permission_key: &str,
) -> Result<bool, AppError> {
    // 1. Check project-level permission first
    if has_project_permission(pool, user_id, project_id, permission_key).await? {
        return Ok(true);
    }

    // 2. Check explicit file ACL grant
    let has_acl = sqlx::query_scalar!(
        r#"
        SELECT EXISTS(
            SELECT 1 FROM file_permissions
            WHERE file_id = $1
              AND subject_type = 'user'
              AND subject_id = $2
              AND permission_key = $3
        )
        "#,
        file_id,
        user_id,
        permission_key
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?
    .unwrap_or(false);

    Ok(has_acl)
}

/// List all explicit permissions granted on a file.
pub async fn list_file_permissions(
    pool: &PgPool,
    file_id: Uuid,
) -> Result<Vec<FilePermission>, AppError> {
    let list = sqlx::query_as!(
        FilePermission,
        r#"
        SELECT file_permission_id, file_id, subject_type, subject_id, permission_key, granted_by, created_at
        FROM file_permissions
        WHERE file_id = $1
        ORDER BY created_at ASC
        "#,
        file_id
    )
    .fetch_all(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(list)
}

/// Grant an explicit permission on a file.
pub async fn grant_file_permission(
    pool: &PgPool,
    file_id: Uuid,
    subject_type: &str,
    subject_id: Uuid,
    permission_key: &str,
    granted_by: Uuid,
) -> Result<FilePermission, AppError> {
    let perm = sqlx::query_as!(
        FilePermission,
        r#"
        INSERT INTO file_permissions (file_id, subject_type, subject_id, permission_key, granted_by, created_at)
        VALUES ($1, $2, $3, $4, $5, NOW())
        ON CONFLICT (file_id, subject_type, subject_id, permission_key)
        DO UPDATE SET granted_by = EXCLUDED.granted_by
        RETURNING file_permission_id, file_id, subject_type, subject_id, permission_key, granted_by, created_at
        "#,
        file_id,
        subject_type,
        subject_id,
        permission_key,
        granted_by
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(perm)
}

/// Revoke an explicit file permission by permission ID.
pub async fn revoke_file_permission(
    pool: &PgPool,
    file_permission_id: Uuid,
) -> Result<(), AppError> {
    let rows_affected = sqlx::query!(
        "DELETE FROM file_permissions WHERE file_permission_id = $1",
        file_permission_id
    )
    .execute(pool)
    .await
    .map_err(AppError::Database)?
    .rows_affected();

    if rows_affected == 0 {
        return Err(AppError::NotFound("file permission not found".into()));
    }

    Ok(())
}
