use serde::Serialize;
use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::files::upload::sessions::UploadSessionRow;

#[derive(Debug, Serialize)]
pub struct ResumableProgressResponse {
    pub session_id: Uuid,
    pub received_bytes: i64,
    pub expected_size: i64,
    pub chunk_size: i32,
    pub missing_range_start: i64,
    pub missing_range_end: i64,
    pub status: String,
}

/// Retrieve the current upload offset and missing range for resuming an interrupted upload.
pub async fn get_resumable_status(
    pool: &PgPool,
    session_id: Uuid,
) -> Result<ResumableProgressResponse, AppError> {
    let row = sqlx::query_as!(
        UploadSessionRow,
        r#"
        SELECT
            session_id, project_id, owner_user_id, original_name, media_type,
            expected_size, received_bytes, temp_storage_key, checksum_expected,
            chunk_size, status, file_id, expires_at, created_at, updated_at
        FROM upload_sessions
        WHERE session_id = $1
        "#,
        session_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound("upload session not found".into()))?;

    let missing_range_start = row.received_bytes;
    let missing_range_end = (row.expected_size - 1).max(row.received_bytes);

    Ok(ResumableProgressResponse {
        session_id: row.session_id,
        received_bytes: row.received_bytes,
        expected_size: row.expected_size,
        chunk_size: row.chunk_size,
        missing_range_start,
        missing_range_end,
        status: row.status,
    })
}
