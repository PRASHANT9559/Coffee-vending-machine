use axum::extract::Multipart;
use chrono::Utc;
use serde::Serialize;
use sqlx::PgPool;
use std::sync::Arc;
use tokio::fs::OpenOptions;
use tokio::io::AsyncWriteExt;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::files::storage::{StorageAdapter, StorageKey};
use crate::files::upload::sessions::UploadSessionRow;
use crate::files::validation::MAX_CHUNK_SIZE;

#[derive(Debug, Serialize)]
pub struct PartUploadResponse {
    pub session_id: Uuid,
    pub received_bytes: i64,
    pub expected_size: i64,
    pub status: String,
}

/// Handle chunk upload via axum Multipart or raw octet-stream bytes.
pub async fn upload_part_bytes(
    pool: &PgPool,
    storage: Arc<dyn StorageAdapter>,
    session_id: Uuid,
    chunk_bytes: &[u8],
) -> Result<PartUploadResponse, AppError> {
    if chunk_bytes.is_empty() {
        return Err(AppError::BadRequest("part chunk cannot be empty".into()));
    }
    if chunk_bytes.len() > MAX_CHUNK_SIZE {
        return Err(AppError::BadRequest(format!(
            "chunk size exceeds max allowed chunk size of {} bytes",
            MAX_CHUNK_SIZE
        )));
    }

    let row = sqlx::query_as!(
        UploadSessionRow,
        r#"
        SELECT
            session_id, project_id, owner_user_id, original_name, media_type,
            expected_size, received_bytes, temp_storage_key, checksum_expected,
            chunk_size, status, file_id, expires_at, created_at, updated_at
        FROM upload_sessions
        WHERE session_id = $1
        FOR UPDATE
        "#,
        session_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound("upload session not found".into()))?;

    if row.status == "completed" || row.status == "aborted" || row.status == "expired" {
        return Err(AppError::Conflict(format!(
            "cannot upload parts: session is {}",
            row.status
        )));
    }

    if Utc::now() > row.expires_at {
        sqlx::query!(
            "UPDATE upload_sessions SET status = 'expired', updated_at = NOW() WHERE session_id = $1",
            session_id
        )
        .execute(pool)
        .await
        .map_err(AppError::Database)?;

        return Err(AppError::Conflict("upload session has expired".into()));
    }

    let new_received = row.received_bytes + chunk_bytes.len() as i64;
    if new_received > row.expected_size {
        return Err(AppError::BadRequest(format!(
            "uploaded chunk of {} bytes would exceed expected size of {} bytes (currently at {})",
            chunk_bytes.len(),
            row.expected_size,
            row.received_bytes
        )));
    }

    // Write/append chunk to the temporary file
    let temp_key = StorageKey::new(&row.temp_storage_key)?;

    // If initial chunk and file does not exist, put it; otherwise append
    if row.received_bytes == 0 {
        let mut cursor = std::io::Cursor::new(chunk_bytes);
        storage.put(&temp_key, &mut cursor, Some(chunk_bytes.len() as u64)).await?;
    } else {
        // Append bytes: for local storage, we can resolve the path and append directly
        // Or if LocalStorageAdapter, get path and append
        // We can check if file exists, open with append, and write
        // To be safe across any StorageAdapter implementation:
        // We write to a temporary chunk or append using standard tokio fs
        // For local files:
        let root_dir = std::env::var("TEMP_UPLOAD_PATH")
            .unwrap_or_else(|_| "/var/storage/database4u/tmp".to_string());
        let path = std::path::Path::new(&root_dir).join(
            temp_key.as_str().strip_prefix("tmp/").unwrap_or(temp_key.as_str())
        );

        let mut file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&path)
            .await
            .map_err(|e| AppError::Internal(format!("failed to open temp upload file for append: {e}")))?;

        file.write_all(chunk_bytes).await.map_err(|e| {
            AppError::Internal(format!("failed writing chunk to temp upload file: {e}"))
        })?;
        file.flush().await.map_err(|e| {
            AppError::Internal(format!("failed to flush temp upload file: {e}"))
        })?;
    }

    let updated_status = if new_received == row.expected_size {
        "completing"
    } else {
        "uploading"
    };

    sqlx::query!(
        r#"
        UPDATE upload_sessions
        SET received_bytes = $2, status = $3, updated_at = NOW()
        WHERE session_id = $1
        "#,
        session_id,
        new_received,
        updated_status
    )
    .execute(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(PartUploadResponse {
        session_id,
        received_bytes: new_received,
        expected_size: row.expected_size,
        status: updated_status.to_string(),
    })
}

/// Extract and process chunk from axum multipart request.
pub async fn handle_multipart_part(
    pool: &PgPool,
    storage: Arc<dyn StorageAdapter>,
    session_id: Uuid,
    mut multipart: Multipart,
) -> Result<PartUploadResponse, AppError> {
    let mut chunk_data = Vec::new();

    while let Some(field) = multipart.next_field().await.map_err(|e| {
        AppError::BadRequest(format!("error reading multipart field: {e}"))
    })? {
        let name = field.name().unwrap_or("").to_string();
        if name == "chunk" || name == "file" || name == "part" {
            let data = field.bytes().await.map_err(|e| {
                AppError::BadRequest(format!("error reading multipart chunk bytes: {e}"))
            })?;
            chunk_data = data.to_vec();
            break;
        }
    }

    if chunk_data.is_empty() {
        return Err(AppError::BadRequest("multipart request missing 'chunk' or 'part' field".into()));
    }

    upload_part_bytes(pool, storage, session_id, &chunk_data).await
}
