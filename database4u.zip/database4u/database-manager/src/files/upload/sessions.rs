use chrono::{DateTime, Duration, Utc};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sqlx::PgPool;
use std::sync::Arc;
use tokio::io::AsyncReadExt;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::files::audit::record_file_event;
use crate::files::metadata::{create_file_record, CreateFileParams, FileView};
use crate::files::quotas::{check_quota, record_usage_addition};
use crate::files::storage::{ObjectMeta, StorageAdapter, StorageKey};
use crate::files::validation::{
    normalize_extension, sanitize_filename, sniff_mime_type, validate_mime_compatibility,
    verify_checksum, DEFAULT_MAX_FILE_SIZE,
};

pub const DEFAULT_CHUNK_SIZE: i32 = 5 * 1024 * 1024; // 5 MB chunk size

#[derive(Debug, Clone, sqlx::FromRow)]
pub struct UploadSessionRow {
    pub session_id: Uuid,
    pub project_id: Uuid,
    pub owner_user_id: Option<Uuid>,
    pub original_name: String,
    pub media_type: String,
    pub expected_size: i64,
    pub received_bytes: i64,
    pub temp_storage_key: String,
    pub checksum_expected: Option<String>,
    pub chunk_size: i32,
    pub status: String,
    pub file_id: Option<Uuid>,
    pub expires_at: DateTime<Utc>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UploadSessionResponse {
    pub session_id: Uuid,
    pub project_id: Uuid,
    pub original_name: String,
    pub media_type: String,
    pub expected_size: i64,
    pub received_bytes: i64,
    pub chunk_size: i32,
    pub status: String,
    pub expires_at: DateTime<Utc>,
    pub file_id: Option<Uuid>,
}

impl From<UploadSessionRow> for UploadSessionResponse {
    fn from(r: UploadSessionRow) -> Self {
        Self {
            session_id: r.session_id,
            project_id: r.project_id,
            original_name: r.original_name,
            media_type: r.media_type,
            expected_size: r.expected_size,
            received_bytes: r.received_bytes,
            chunk_size: r.chunk_size,
            status: r.status,
            expires_at: r.expires_at,
            file_id: r.file_id,
        }
    }
}

#[derive(Debug, Deserialize)]
pub struct CreateSessionRequest {
    pub project_id: Uuid,
    pub original_name: String,
    pub media_type: String,
    pub size_bytes: i64,
    pub checksum: Option<String>,
}

/// Create a new resumable upload session after validating limits, quotas, and naming.
pub async fn create_upload_session(
    pool: &PgPool,
    actor_user_id: Option<Uuid>,
    request: CreateSessionRequest,
) -> Result<UploadSessionResponse, AppError> {
    if request.size_bytes <= 0 {
        return Err(AppError::BadRequest("size_bytes must be strictly positive".into()));
    }
    if request.size_bytes > DEFAULT_MAX_FILE_SIZE as i64 {
        return Err(AppError::BadRequest(format!(
            "file size exceeds maximum allowed limit of {} bytes",
            DEFAULT_MAX_FILE_SIZE
        )));
    }

    let sanitized_name = sanitize_filename(&request.original_name);
    if sanitized_name.is_empty() {
        return Err(AppError::BadRequest("invalid filename".into()));
    }

    // Pre-flight quota check
    check_quota(pool, request.project_id, actor_user_id, request.size_bytes).await?;

    let session_id = Uuid::new_v4();
    let temp_key = format!("tmp/{}", session_id);
    let expires_at = Utc::now() + Duration::hours(1);

    let row = sqlx::query_as!(
        UploadSessionRow,
        r#"
        INSERT INTO upload_sessions (
            session_id, project_id, owner_user_id, original_name, media_type,
            expected_size, received_bytes, temp_storage_key, checksum_expected,
            chunk_size, status, expires_at, created_at, updated_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, 0, $7, $8, $9, 'initiated', $10, NOW(), NOW())
        RETURNING
            session_id, project_id, owner_user_id, original_name, media_type,
            expected_size, received_bytes, temp_storage_key, checksum_expected,
            chunk_size, status, file_id, expires_at, created_at, updated_at
        "#,
        session_id,
        request.project_id,
        actor_user_id,
        sanitized_name,
        request.media_type,
        request.size_bytes,
        temp_key,
        request.checksum,
        DEFAULT_CHUNK_SIZE,
        expires_at
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?;

    record_file_event(
        pool,
        None,
        row.project_id,
        actor_user_id,
        "upload_initiated",
        "initiated",
        Some(&format!("session_id: {}", row.session_id)),
    )
    .await;

    Ok(row.into())
}

/// Retrieve an upload session by ID.
pub async fn get_upload_session(
    pool: &PgPool,
    session_id: Uuid,
) -> Result<UploadSessionResponse, AppError> {
    let row = sqlx::query_as!(
        UploadSessionRow,
        r#"
        SELECT
            session_id, project_id, owner_user_id, original_name, media_type,
            expected_size, received_bytes, temp_storage_key, checksum_expected,
            chunk_size, status, file_id, expires_at, created_at, updated_at
        FROM upload_sessions
        WHERE session_id = $1
        "#,
        session_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound("upload session not found".into()))?;

    Ok(row.into())
}

/// Abort an upload session and clean up the temporary storage artifact.
pub async fn abort_upload_session(
    pool: &PgPool,
    storage: Arc<dyn StorageAdapter>,
    session_id: Uuid,
    actor_user_id: Option<Uuid>,
) -> Result<(), AppError> {
    let row = sqlx::query_as!(
        UploadSessionRow,
        r#"
        SELECT
            session_id, project_id, owner_user_id, original_name, media_type,
            expected_size, received_bytes, temp_storage_key, checksum_expected,
            chunk_size, status, file_id, expires_at, created_at, updated_at
        FROM upload_sessions
        WHERE session_id = $1
        "#,
        session_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound("upload session not found".into()))?;

    if row.status == "completed" {
        return Err(AppError::Conflict("cannot abort a completed session".into()));
    }

    sqlx::query!(
        "UPDATE upload_sessions SET status = 'aborted', updated_at = NOW() WHERE session_id = $1",
        session_id
    )
    .execute(pool)
    .await
    .map_err(AppError::Database)?;

    if let Ok(temp_key) = StorageKey::new(&row.temp_storage_key) {
        let _ = storage.delete(&temp_key).await;
    }

    record_file_event(
        pool,
        None,
        row.project_id,
        actor_user_id,
        "upload_aborted",
        "aborted",
        Some(&format!("session_id: {session_id}")),
    )
    .await;

    Ok(())
}

/// Complete an upload session: validate file integrity, verify checksum, sniff magic bytes,
/// atomically move into permanent storage, and insert ready file record.
pub async fn complete_upload_session(
    pool: &PgPool,
    storage: Arc<dyn StorageAdapter>,
    session_id: Uuid,
    actor_user_id: Option<Uuid>,
) -> Result<FileView, AppError> {
    let row = sqlx::query_as!(
        UploadSessionRow,
        r#"
        SELECT
            session_id, project_id, owner_user_id, original_name, media_type,
            expected_size, received_bytes, temp_storage_key, checksum_expected,
            chunk_size, status, file_id, expires_at, created_at, updated_at
        FROM upload_sessions
        WHERE session_id = $1
        FOR UPDATE
        "#,
        session_id
    )
    .fetch_optional(pool)
    .await
    .map_err(AppError::Database)?
    .ok_or_else(|| AppError::NotFound("upload session not found".into()))?;

    if row.status == "completed" {
        if let Some(fid) = row.file_id {
            if let Some(f) = crate::files::metadata::get_file_record(pool, fid).await? {
                return Ok(f.into());
            }
        }
        return Err(AppError::Conflict("upload session already completed".into()));
    }

    if row.status == "aborted" || row.status == "expired" {
        return Err(AppError::Conflict(format!("session is {}", row.status)));
    }

    if Utc::now() > row.expires_at {
        sqlx::query!(
            "UPDATE upload_sessions SET status = 'expired', updated_at = NOW() WHERE session_id = $1",
            session_id
        )
        .execute(pool)
        .await
        .map_err(AppError::Database)?;

        return Err(AppError::Conflict("upload session has expired".into()));
    }

    if row.received_bytes != row.expected_size {
        return Err(AppError::BadRequest(format!(
            "incomplete upload: received {} bytes, expected {} bytes",
            row.received_bytes, row.expected_size
        )));
    }

    let temp_key = StorageKey::new(&row.temp_storage_key)?;

    // Read initial bytes to sniff magic numbers and compute SHA-256
    let mut stream = storage.get(&temp_key).await?;
    let mut header_sample = vec![0u8; 512];
    let mut sample_len = 0;
    while sample_len < 512 {
        let n = stream.read(&mut header_sample[sample_len..]).await.map_err(|e| {
            AppError::Internal(format!("failed reading file stream for verification: {e}"))
        })?;
        if n == 0 {
            break;
        }
        sample_len += n;
    }
    header_sample.truncate(sample_len);

    let sniffed = sniff_mime_type(&header_sample);
    validate_mime_compatibility(&row.media_type, sniffed)?;

    // Compute full SHA-256 checksum over the file
    let mut stream = storage.get(&temp_key).await?;
    let mut hasher = Sha256::new();
    let mut buf = vec![0u8; 64 * 1024];
    loop {
        let n = stream.read(&mut buf).await.map_err(|e| {
            AppError::Internal(format!("failed reading file for checksum computation: {e}"))
        })?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    let computed_checksum = hex::encode(hasher.finalize());

    if let Some(expected) = &row.checksum_expected {
        verify_checksum(expected, &computed_checksum)?;
    }

    // Generate permanent destination key and move atomically
    let final_key = StorageKey::generate();
    storage.move_object(&temp_key, &final_key).await?;

    let ext = std::path::Path::new(&row.original_name)
        .extension()
        .and_then(|s| s.to_str())
        .map(normalize_extension)
        .unwrap_or_else(|| "bin".to_string());

    let file_record = create_file_record(
        pool,
        CreateFileParams {
            project_id: row.project_id,
            owner_user_id: row.owner_user_id,
            original_name: &row.original_name,
            storage_key: final_key.as_str(),
            media_type: &row.media_type,
            extension: &ext,
            size_bytes: row.expected_size,
            checksum: &computed_checksum,
            storage_provider: "local",
            status: "ready",
        },
    )
    .await?;

    // Mark session completed and link file_id
    sqlx::query!(
        r#"
        UPDATE upload_sessions
        SET status = 'completed', file_id = $2, updated_at = NOW()
        WHERE session_id = $1
        "#,
        session_id,
        file_record.file_id
    )
    .execute(pool)
    .await
    .map_err(AppError::Database)?;

    // Account for used quota
    record_usage_addition(pool, row.project_id, row.owner_user_id, row.expected_size).await?;

    // Record audit event
    record_file_event(
        pool,
        Some(file_record.file_id),
        row.project_id,
        actor_user_id,
        "upload_completed",
        "ready",
        Some(&format!("file_id: {}, size: {}", file_record.file_id, row.expected_size)),
    )
    .await;

    Ok(file_record.into())
}
