use serde::{Deserialize, Serialize};
use sqlx::PgPool;

use crate::common::errors::AppError;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageMetrics {
    pub total_files: i64,
    pub total_bytes_used: i64,
    pub completed_uploads: i64,
    pub active_sessions: i64,
    pub expired_sessions: i64,
}

/// Retrieve overall system file and storage metrics.
pub async fn get_system_file_metrics(pool: &PgPool) -> Result<StorageMetrics, AppError> {
    let file_stats = sqlx::query!(
        r#"
        SELECT
            COALESCE(COUNT(*), 0)::BIGINT as total_files,
            COALESCE(SUM(size_bytes), 0)::BIGINT as total_bytes
        FROM files
        WHERE deleted_at IS NULL AND status = 'ready'
        "#
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?;

    let session_stats = sqlx::query!(
        r#"
        SELECT
            COALESCE(COUNT(*) FILTER (WHERE status = 'completed'), 0)::BIGINT as completed_count,
            COALESCE(COUNT(*) FILTER (WHERE status IN ('initiated', 'uploading', 'completing')), 0)::BIGINT as active_count,
            COALESCE(COUNT(*) FILTER (WHERE status = 'expired'), 0)::BIGINT as expired_count
        FROM upload_sessions
        "#
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?;

    Ok(StorageMetrics {
        total_files: file_stats.total_files.unwrap_or(0),
        total_bytes_used: file_stats.total_bytes.unwrap_or(0),
        completed_uploads: session_stats.completed_count.unwrap_or(0),
        active_sessions: session_stats.active_count.unwrap_or(0),
        expired_sessions: session_stats.expired_count.unwrap_or(0),
    })
}
