use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use tracing::warn;
use uuid::Uuid;

use crate::common::errors::AppError;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileEvent {
    pub event_id: Uuid,
    pub file_id: Option<Uuid>,
    pub project_id: Uuid,
    pub actor_user_id: Option<Uuid>,
    pub action: String,
    pub status: String,
    pub detail: Option<String>,
    pub created_at: DateTime<Utc>,
}

/// Record an audit event for file actions. Does not fail the parent transaction if logging fails.
pub async fn record_file_event(
    pool: &PgPool,
    file_id: Option<Uuid>,
    project_id: Uuid,
    actor_user_id: Option<Uuid>,
    action: &str,
    status: &str,
    detail: Option<&str>,
) {
    let res = sqlx::query!(
        r#"
        INSERT INTO file_events (file_id, project_id, actor_user_id, action, status, detail, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW())
        "#,
        file_id,
        project_id,
        actor_user_id,
        action,
        status,
        detail
    )
    .execute(pool)
    .await;

    if let Err(e) = res {
        warn!(error = %e, action = %action, "failed to record file audit event");
    }
}

/// List recent file audit events for a project.
pub async fn list_file_events(
    pool: &PgPool,
    project_id: Uuid,
    file_id: Option<Uuid>,
    limit: i64,
) -> Result<Vec<FileEvent>, AppError> {
    let limit = limit.clamp(1, 100);

    let events = if let Some(fid) = file_id {
        sqlx::query_as!(
            FileEvent,
            r#"
            SELECT event_id, file_id, project_id, actor_user_id, action, status, detail, created_at
            FROM file_events
            WHERE project_id = $1 AND file_id = $2
            ORDER BY created_at DESC
            LIMIT $3
            "#,
            project_id,
            fid,
            limit
        )
        .fetch_all(pool)
        .await
        .map_err(AppError::Database)?
    } else {
        sqlx::query_as!(
            FileEvent,
            r#"
            SELECT event_id, file_id, project_id, actor_user_id, action, status, detail, created_at
            FROM file_events
            WHERE project_id = $1
            ORDER BY created_at DESC
            LIMIT $2
            "#,
            project_id,
            limit
        )
        .fetch_all(pool)
        .await
        .map_err(AppError::Database)?
    };

    Ok(events)
}
