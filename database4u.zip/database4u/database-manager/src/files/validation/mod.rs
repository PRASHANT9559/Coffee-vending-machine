use sha2::{Digest, Sha256};
use std::path::Path;

use crate::common::errors::AppError;

pub const DEFAULT_MAX_FILE_SIZE: u64 = 500 * 1024 * 1024; // 500 MB
pub const MAX_CHUNK_SIZE: usize = 10 * 1024 * 1024; // 10 MB max per upload chunk
pub const MIN_CHUNK_SIZE: usize = 256 * 1024; // 256 KB minimum (except last chunk)

/// Sanitizes untrusted user filenames.
///
/// Rules:
/// 1. Strips directory paths (`..`, `/`, `\`).
/// 2. Removes ASCII control characters and null bytes.
/// 3. Normalizes Unicode and trims leading/trailing spaces and dots.
/// 4. Caps filename length at 255 characters while preserving the extension.
/// 5. Ensures the output is non-empty, falling back to a safe generic name.
pub fn sanitize_filename(raw: &str) -> String {
    let raw_name = Path::new(raw)
        .file_name()
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_else(|| "unnamed_file".to_string());

    let cleaned: String = raw_name
        .chars()
        .map(|c| {
            if c == '/' || c == '\\' || c == '\0' || c.is_ascii_control() {
                '_'
            } else {
                c
            }
        })
        .collect();

    let trimmed = cleaned.trim().trim_matches('.').trim();
    let safe_name = if trimmed.is_empty() || trimmed == ".." || trimmed == "." {
        "unnamed_file".to_string()
    } else {
        trimmed.to_string()
    };

    if safe_name.len() > 255 {
        // Truncate while keeping extension if present
        if let Some(dot_idx) = safe_name.rfind('.') {
            let ext = &safe_name[dot_idx..];
            let max_base_len = 255_usize.saturating_sub(ext.len());
            format!("{}{}", &safe_name[..max_base_len], ext)
        } else {
            safe_name[..255].to_string()
        }
    } else {
        safe_name
    }
}

/// Normalizes a file extension (lowercase, no leading dot, capped at 32 chars).
pub fn normalize_extension(raw: &str) -> String {
    let stripped = raw.trim().trim_start_matches('.');
    let mut cleaned: String = stripped
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '_' || *c == '-')
        .collect();

    cleaned.make_ascii_lowercase();
    if cleaned.len() > 32 {
        cleaned.truncate(32);
    }
    cleaned
}

/// Sniffs magic bytes to infer the MIME type.
pub fn sniff_mime_type(sample: &[u8]) -> Option<&'static str> {
    if sample.is_empty() {
        return None;
    }

    // PNG: 89 50 4E 47 0D 0A 1A 0A
    if sample.len() >= 8 && sample.starts_with(b"\x89PNG\r\n\x1a\n") {
        return Some("image/png");
    }

    // JPEG: FF D8 FF
    if sample.len() >= 3 && sample.starts_with(b"\xFF\xD8\xFF") {
        return Some("image/jpeg");
    }

    // GIF: GIF87a or GIF89a
    if sample.len() >= 6 && (sample.starts_with(b"GIF87a") || sample.starts_with(b"GIF89a")) {
        return Some("image/gif");
    }

    // WebP: RIFF....WEBP
    if sample.len() >= 12 && sample.starts_with(b"RIFF") && &sample[8..12] == b"WEBP" {
        return Some("image/webp");
    }

    // PDF: %PDF-
    if sample.len() >= 5 && sample.starts_with(b"%PDF-") {
        return Some("application/pdf");
    }

    // ZIP / Office OpenXML (docx, xlsx, pptx): PK\x03\x04
    if sample.len() >= 4 && sample.starts_with(b"PK\x03\x04") {
        return Some("application/zip");
    }

    // MP4: [4 bytes length] 'ftyp'
    if sample.len() >= 8 && &sample[4..8] == b"ftyp" {
        return Some("video/mp4");
    }

    // WebM / Matroska: 1A 45 DF A3
    if sample.len() >= 4 && sample.starts_with(b"\x1A\x45\xDF\xA3") {
        return Some("video/webm");
    }

    // MP3: ID3 or MPEG sync frames
    if sample.len() >= 3 && sample.starts_with(b"ID3") {
        return Some("audio/mpeg");
    }
    if sample.len() >= 2 && sample[0] == 0xFF && (sample[1] & 0xE0) == 0xE0 {
        return Some("audio/mpeg");
    }

    // WAV: RIFF....WAVE
    if sample.len() >= 12 && sample.starts_with(b"RIFF") && &sample[8..12] == b"WAVE" {
        return Some("audio/wav");
    }

    // OGG: OggS
    if sample.len() >= 4 && sample.starts_with(b"OggS") {
        return Some("audio/ogg");
    }

    // SVG / XML
    let sample_str = std::str::from_utf8(sample).unwrap_or("");
    let trimmed = sample_str.trim_start();
    if trimmed.starts_with("<?xml") || trimmed.starts_with("<svg") {
        if trimmed.contains("<svg") {
            return Some("image/svg+xml");
        }
        return Some("application/xml");
    }

    // JSON
    if (trimmed.starts_with('{') && trimmed.ends_with('}'))
        || (trimmed.starts_with('[') && trimmed.ends_with(']'))
    {
        return Some("application/json");
    }

    // Plain text UTF-8
    if std::str::from_utf8(sample).is_ok() && !sample.iter().any(|&b| b < 0x09 || (b > 0x0D && b < 0x20)) {
        return Some("text/plain");
    }

    None
}

/// Validates whether the declared MIME type is compatible with detected signature.
pub fn validate_mime_compatibility(declared: &str, detected: Option<&str>) -> Result<(), AppError> {
    let declared_clean = declared.split(';').next().unwrap_or("").trim().to_lowercase();
    if declared_clean.is_empty() {
        return Err(AppError::Validation("media type cannot be empty".into()));
    }

    if let Some(sniffed) = detected {
        // If detected matches declared
        if declared_clean == sniffed {
            return Ok(());
        }

        // Generic octet-stream is allowed if sniffed is binary
        if declared_clean == "application/octet-stream" {
            return Ok(());
        }

        // Zip-based archives (docx, jar, etc.) declared as application/zip
        if declared_clean.starts_with("application/vnd.openxmlformats") && sniffed == "application/zip" {
            return Ok(());
        }

        // Text variations
        if declared_clean.starts_with("text/") && sniffed == "text/plain" {
            return Ok(());
        }

        return Err(AppError::Validation(format!(
            "declared media type '{declared}' contradicts detected file format '{sniffed}'"
        )));
    }

    // If undetectable, allow standard generic types
    Ok(())
}

/// Verifies SHA-256 checksum equality (case-insensitive hex).
pub fn verify_checksum(expected_hex: &str, actual_hex: &str) -> Result<(), AppError> {
    if expected_hex.trim().eq_ignore_ascii_case(actual_hex.trim()) {
        Ok(())
    } else {
        Err(AppError::Validation(format!(
            "checksum mismatch: expected {expected_hex}, computed {actual_hex}"
        )))
    }
}

/// Compute SHA-256 hex string for a byte buffer.
pub fn compute_sha256(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hex::encode(hasher.finalize())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sanitize_filename_traversal() {
        assert_eq!(sanitize_filename("../../etc/passwd"), "passwd");
        assert_eq!(sanitize_filename("..\\..\\windows\\system32\\cmd.exe"), "cmd.exe");
        assert_eq!(sanitize_filename("/var/log/syslog"), "syslog");
        assert_eq!(sanitize_filename("hello\0world.txt"), "hello_world.txt");
        assert_eq!(sanitize_filename(""), "unnamed_file");
        assert_eq!(sanitize_filename("..."), "unnamed_file");
    }

    #[test]
    fn test_normalize_extension() {
        assert_eq!(normalize_extension(".PNG"), "png");
        assert_eq!(normalize_extension("JPEG"), "jpeg");
        assert_eq!(normalize_extension("..tar.gz"), "targz");
    }

    #[test]
    fn test_sniff_mime_type() {
        let png = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR";
        assert_eq!(sniff_mime_type(png), Some("image/png"));

        let jpeg = b"\xFF\xD8\xFF\xE0\x00\x10JFIF";
        assert_eq!(sniff_mime_type(jpeg), Some("image/jpeg"));

        let pdf = b"%PDF-1.7\r\n";
        assert_eq!(sniff_mime_type(pdf), Some("application/pdf"));
    }

    #[test]
    fn test_checksum_verification() {
        let data = b"test payload for sha256";
        let hash = compute_sha256(data);
        assert!(verify_checksum(&hash, &hash).is_ok());
        assert!(verify_checksum(&hash.to_uppercase(), &hash).is_ok());
        assert!(verify_checksum("badhash", &hash).is_err());
    }
}
