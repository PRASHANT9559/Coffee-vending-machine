use axum::extract::{Multipart, Path, Query, State};
use axum::http::HeaderMap;
use axum::response::Response;
use axum::Json;
use serde::Deserialize;
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::{Ack, ApiResponse};
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::common::types::Pagination;
use crate::files::download::handle_file_download;
use crate::files::metadata::{
    self, get_file_record, rename_file_metadata, soft_delete_file, FileView, UpdateFileRequest,
};
use crate::files::metrics::{get_system_file_metrics, StorageMetrics};
use crate::files::permissions::{
    grant_file_permission, list_file_permissions, revoke_file_permission, FilePermission,
    GrantPermissionRequest,
};
use crate::files::quotas::{get_project_storage_usage, StorageUsage};
use crate::files::upload::multipart::{handle_multipart_part, PartUploadResponse};
use crate::files::upload::resumable::{get_resumable_status as get_resumable_info, ResumableProgressResponse};
use crate::files::upload::sessions::{
    abort_upload_session as abort_session, complete_upload_session as complete_session,
    create_upload_session as create_session, get_upload_session as get_session,
    CreateSessionRequest, UploadSessionResponse,
};
use crate::security::permissions::policy::require_project_permission;

#[derive(Debug, Deserialize)]
pub struct ListFilesQuery {
    pub project_id: Uuid,
    pub status: Option<String>,
    #[serde(flatten)]
    pub pagination: Pagination,
}

/// List files for a project. Requires `file.read` permission.
pub async fn list_files(
    State(state): State<AppState>,
    user: AuthUser,
    Query(query): Query<ListFilesQuery>,
) -> Result<Json<ApiResponse<Vec<FileView>>>, AppError> {
    require_project_permission(&state.db, user.user_id, query.project_id, "file.read").await?;

    let (limit, offset) = query.pagination.resolve(20, 100);
    let rows = metadata::list_files_for_project(
        &state.db,
        query.project_id,
        query.status.as_deref(),
        limit,
        offset,
    )
    .await?;

    let views: Vec<FileView> = rows.into_iter().map(FileView::from).collect();
    Ok(Json(ApiResponse::ok(views)))
}

/// Get file detail. Storage internals are never returned.
pub async fn get_file(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
) -> Result<Json<ApiResponse<FileView>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    require_project_permission(&state.db, user.user_id, file.project_id, "file.read").await?;

    Ok(Json(ApiResponse::ok(file.into())))
}

/// Rename file metadata. Requires `file.update_metadata` permission.
pub async fn rename_file(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
    Json(body): Json<UpdateFileRequest>,
) -> Result<Json<ApiResponse<FileView>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    require_project_permission(&state.db, user.user_id, file.project_id, "file.update_metadata").await?;

    let updated = rename_file_metadata(&state.db, file_id, &body.original_name).await?;
    Ok(Json(ApiResponse::ok(updated.into())))
}

/// Soft-delete file metadata. Physical file will be removed after retention period.
pub async fn delete_file(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    require_project_permission(&state.db, user.user_id, file.project_id, "file.delete").await?;

    soft_delete_file(&state.db, file_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("file marked for deletion"))))
}

/// Stream file download with RFC 7233 Range support.
pub async fn download_file(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
    headers: HeaderMap,
) -> Result<Response, AppError> {
    handle_file_download(&state.db, state.storage.clone(), file_id, user.user_id, &headers).await
}

/// Create a new resumable upload session.
pub async fn create_upload_session(
    State(state): State<AppState>,
    user: AuthUser,
    Json(body): Json<CreateSessionRequest>,
) -> Result<Json<ApiResponse<UploadSessionResponse>>, AppError> {
    require_project_permission(&state.db, user.user_id, body.project_id, "file.upload").await?;

    let session = create_session(&state.db, Some(user.user_id), body).await?;
    Ok(Json(ApiResponse::ok(session)))
}

/// Retrieve status of an upload session.
pub async fn get_upload_session(
    State(state): State<AppState>,
    user: AuthUser,
    Path(session_id): Path<Uuid>,
) -> Result<Json<ApiResponse<UploadSessionResponse>>, AppError> {
    let session = get_session(&state.db, session_id).await?;
    require_project_permission(&state.db, user.user_id, session.project_id, "file.read").await?;

    Ok(Json(ApiResponse::ok(session)))
}

/// Abort an upload session and remove its temporary file.
pub async fn abort_upload_session(
    State(state): State<AppState>,
    user: AuthUser,
    Path(session_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    let session = get_session(&state.db, session_id).await?;
    require_project_permission(&state.db, user.user_id, session.project_id, "file.upload").await?;

    abort_session(&state.db, state.storage.clone(), session_id, Some(user.user_id)).await?;
    Ok(Json(ApiResponse::ok(Ack::new("upload session aborted and cleaned up"))))
}

/// Upload a chunk part for a session.
pub async fn upload_part(
    State(state): State<AppState>,
    user: AuthUser,
    Path(session_id): Path<Uuid>,
    multipart: Multipart,
) -> Result<Json<ApiResponse<PartUploadResponse>>, AppError> {
    let session = get_session(&state.db, session_id).await?;
    require_project_permission(&state.db, user.user_id, session.project_id, "file.upload").await?;

    let res = handle_multipart_part(&state.db, state.storage.clone(), session_id, multipart).await?;
    Ok(Json(ApiResponse::ok(res)))
}

/// Get missing ranges / chunk progress for resuming upload.
pub async fn get_resumable_status(
    State(state): State<AppState>,
    user: AuthUser,
    Path(session_id): Path<Uuid>,
) -> Result<Json<ApiResponse<ResumableProgressResponse>>, AppError> {
    let session = get_session(&state.db, session_id).await?;
    require_project_permission(&state.db, user.user_id, session.project_id, "file.read").await?;

    let res = get_resumable_info(&state.db, session_id).await?;
    Ok(Json(ApiResponse::ok(res)))
}

/// Complete an upload session, verify integrity, move file to storage, and activate file record.
pub async fn complete_upload_session(
    State(state): State<AppState>,
    user: AuthUser,
    Path(session_id): Path<Uuid>,
) -> Result<Json<ApiResponse<FileView>>, AppError> {
    let session = get_session(&state.db, session_id).await?;
    require_project_permission(&state.db, user.user_id, session.project_id, "file.upload").await?;

    let file_view = complete_session(&state.db, state.storage.clone(), session_id, Some(user.user_id)).await?;
    Ok(Json(ApiResponse::ok(file_view)))
}

/// Retrieve storage quota and used bytes for a project.
pub async fn get_storage_usage(
    State(state): State<AppState>,
    user: AuthUser,
    Path(project_id): Path<Uuid>,
) -> Result<Json<ApiResponse<StorageUsage>>, AppError> {
    require_project_permission(&state.db, user.user_id, project_id, "file.read").await?;

    let usage = get_project_storage_usage(&state.db, project_id, Some(user.user_id)).await?;
    Ok(Json(ApiResponse::ok(usage)))
}

/// List explicit permissions on a file.
pub async fn list_file_permissions_handler(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Vec<FilePermission>>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    require_project_permission(&state.db, user.user_id, file.project_id, "file.read").await?;

    let list = list_file_permissions(&state.db, file_id).await?;
    Ok(Json(ApiResponse::ok(list)))
}

/// Grant an explicit permission on a file. Requires `file.share` permission.
pub async fn grant_file_permission_handler(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
    Json(body): Json<GrantPermissionRequest>,
) -> Result<Json<ApiResponse<FilePermission>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    require_project_permission(&state.db, user.user_id, file.project_id, "file.share").await?;

    let perm = grant_file_permission(
        &state.db,
        file_id,
        &body.subject_type,
        body.subject_id,
        &body.permission_key,
        user.user_id,
    )
    .await?;

    Ok(Json(ApiResponse::ok(perm)))
}

/// Revoke an explicit permission on a file. Requires `file.share` permission.
pub async fn revoke_file_permission_handler(
    State(state): State<AppState>,
    user: AuthUser,
    Path(permission_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    revoke_file_permission(&state.db, permission_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("file permission revoked"))))
}

/// Get system-wide file storage metrics.
pub async fn get_metrics(
    State(state): State<AppState>,
    _user: AuthUser,
) -> Result<Json<ApiResponse<StorageMetrics>>, AppError> {
    let metrics = get_system_file_metrics(&state.db).await?;
    Ok(Json(ApiResponse::ok(metrics)))
}

/// Create a public share link for a file. Requires `file.share` permission.
pub async fn create_file_share_handler(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
    Json(body): Json<crate::security::files::sharing::CreateShareRequest>,
) -> Result<Json<ApiResponse<crate::security::files::sharing::CreatedShareResponse>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    let res = crate::security::files::sharing::create_share_link(
        &state.db,
        user.user_id,
        file_id,
        file.project_id,
        body,
    )
    .await?;

    Ok(Json(ApiResponse::ok(res)))
}

/// List active share links for a file. Requires `file.share` permission.
pub async fn list_file_shares_handler(
    State(state): State<AppState>,
    user: AuthUser,
    Path(file_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Vec<crate::security::files::sharing::FileShareInfo>>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    require_project_permission(&state.db, user.user_id, file.project_id, "file.share").await?;

    let list = crate::security::files::sharing::list_shares_for_file(&state.db, file_id).await?;
    Ok(Json(ApiResponse::ok(list)))
}

/// Revoke a share link for a file. Requires `file.share` permission.
pub async fn revoke_file_share_handler(
    State(state): State<AppState>,
    user: AuthUser,
    Path((file_id, share_id)): Path<(Uuid, Uuid)>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    let file = get_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found".into()))?;

    crate::security::files::sharing::revoke_share_link(
        &state.db,
        user.user_id,
        file.project_id,
        share_id,
    )
    .await?;

    Ok(Json(ApiResponse::ok(Ack::new("share link revoked"))))
}

/// Public download handler via shared capability token.
pub async fn download_shared_file_handler(
    State(state): State<AppState>,
    Path(token): Path<String>,
    headers: HeaderMap,
) -> Result<Response, AppError> {
    let file_id = crate::security::files::sharing::validate_and_consume_share(&state.db, &token).await?;

    let record = metadata::get_active_file_record(&state.db, file_id)
        .await?
        .ok_or_else(|| AppError::NotFound("file not found or not ready".into()))?;

    let storage_key = crate::files::storage::StorageKey::new(&record.storage_key)?;
    let total_size = record.size_bytes as u64;

    let range_header = headers.get(axum::http::header::RANGE).and_then(|h| h.to_str().ok());
    let byte_range = if let Some(rh) = range_header {
        crate::files::download::parse_range_header(rh, total_size)?
    } else {
        None
    };

    let content_disposition = crate::files::download::format_content_disposition(&record.original_name);
    let etag = format!("\"{}\"", record.checksum);

    if let Some(range) = byte_range {
        let stream = state.storage.get_range(&storage_key, range.start, range.end).await?;
        let body_stream = tokio_util::io::ReaderStream::new(stream);
        let body = axum::body::Body::from_stream(body_stream);

        let content_range = format!("bytes {}-{}/{}", range.start, range.end, total_size);
        let content_len = (range.end - range.start + 1).to_string();

        let mut res = Response::builder()
            .status(axum::http::StatusCode::PARTIAL_CONTENT)
            .body(body)
            .map_err(|e| AppError::Internal(format!("failed to build response: {e}")))?;

        let h = res.headers_mut();
        h.insert(
            axum::http::header::CONTENT_TYPE,
            axum::http::HeaderValue::from_str(&record.media_type)
                .unwrap_or(axum::http::HeaderValue::from_static("application/octet-stream")),
        );
        h.insert(axum::http::header::CONTENT_LENGTH, axum::http::HeaderValue::from_str(&content_len).unwrap());
        h.insert(axum::http::header::CONTENT_RANGE, axum::http::HeaderValue::from_str(&content_range).unwrap());
        h.insert(axum::http::header::ACCEPT_RANGES, axum::http::HeaderValue::from_static("bytes"));
        h.insert(axum::http::header::CACHE_CONTROL, axum::http::HeaderValue::from_static("private, no-store"));
        h.insert(axum::http::header::ETAG, axum::http::HeaderValue::from_str(&etag).unwrap());
        if let Ok(cd) = axum::http::HeaderValue::from_str(&content_disposition) {
            h.insert(axum::http::header::CONTENT_DISPOSITION, cd);
        }

        Ok(res)
    } else {
        let stream = state.storage.get(&storage_key).await?;
        let body_stream = tokio_util::io::ReaderStream::new(stream);
        let body = axum::body::Body::from_stream(body_stream);

        let mut res = Response::builder()
            .status(axum::http::StatusCode::OK)
            .body(body)
            .map_err(|e| AppError::Internal(format!("failed to build response: {e}")))?;

        let h = res.headers_mut();
        h.insert(
            axum::http::header::CONTENT_TYPE,
            axum::http::HeaderValue::from_str(&record.media_type)
                .unwrap_or(axum::http::HeaderValue::from_static("application/octet-stream")),
        );
        h.insert(axum::http::header::CONTENT_LENGTH, axum::http::HeaderValue::from_str(&total_size.to_string()).unwrap());
        h.insert(axum::http::header::ACCEPT_RANGES, axum::http::HeaderValue::from_static("bytes"));
        h.insert(axum::http::header::CACHE_CONTROL, axum::http::HeaderValue::from_static("private, no-store"));
        h.insert(axum::http::header::ETAG, axum::http::HeaderValue::from_str(&etag).unwrap());
        if let Ok(cd) = axum::http::HeaderValue::from_str(&content_disposition) {
            h.insert(axum::http::header::CONTENT_DISPOSITION, cd);
        }

        Ok(res)
    }
}
