use chrono::Duration;
use serde::{Deserialize, Serialize};

/// Standard file state machine.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FileLifecycleStatus {
    Uploading,
    Scanning,
    Ready,
    Failed,
    Deleted,
}

impl FileLifecycleStatus {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Uploading => "uploading",
            Self::Scanning => "scanning",
            Self::Ready => "ready",
            Self::Failed => "failed",
            Self::Deleted => "deleted",
        }
    }
}

/// Retention configuration.
#[derive(Debug, Clone)]
pub struct RetentionPolicy {
    /// Time before soft-deleted files are physically purged from storage.
    pub soft_delete_retention: Duration,
    /// Upload session TTL before expiration.
    pub upload_session_ttl: Duration,
}

impl Default for RetentionPolicy {
    fn default() -> Self {
        Self {
            soft_delete_retention: Duration::days(7),
            upload_session_ttl: Duration::hours(1),
        }
    }
}
