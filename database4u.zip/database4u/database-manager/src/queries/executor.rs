//! Query execution.
//!
//! Every statement runs inside a transaction that first applies
//! `SET LOCAL statement_timeout`, so an expensive query can never pin a pool connection
//! indefinitely. Read queries are wrapped in `json_agg(row_to_json(...))` to return one
//! JSON payload with a hard row cap.

use serde_json::Value;
use sqlx::PgPool;

use crate::common::errors::AppError;

use super::validator::QueryKind;

#[derive(Debug)]
pub struct QueryOutcome {
    pub rows: Value,
    pub rows_affected: Option<u64>,
    pub duration_ms: u64,
    pub truncated: bool,
    pub read_only: bool,
}

pub async fn run(
    pool: &PgPool,
    sql: &str,
    kind: QueryKind,
    max_rows: i64,
    timeout_ms: u64,
) -> Result<QueryOutcome, AppError> {
    let started = std::time::Instant::now();
    let max_rows = max_rows.max(1);
    // `statement_timeout = 0` disables the timeout, so never allow it.
    let timeout_ms = timeout_ms.max(1_000);
    let mut tx = pool.begin().await?;

    sqlx::query(&format!("SET LOCAL statement_timeout = {timeout_ms}"))
        .execute(&mut *tx)
        .await?;

    if kind.is_read() {
        // Fetch one extra row so `truncated` reflects whether more data exists instead
        // of guessing from the row count.
        let wrapped = format!(
            "SELECT COALESCE(json_agg(row_to_json(q)), '[]'::json) \
             FROM (SELECT * FROM ({sql}) AS _inner LIMIT $1) q"
        );

        let rows: Value = sqlx::query_scalar(&wrapped)
            .bind(max_rows + 1)
            .fetch_one(&mut *tx)
            .await
            .map_err(map_query_error)?;

        tx.commit().await?;

        let (rows, truncated) = match rows {
            Value::Array(mut array) => {
                let truncated = array.len() as i64 > max_rows;
                if truncated {
                    array.truncate(max_rows as usize);
                }
                (Value::Array(array), truncated)
            }
            other => (other, false),
        };

        Ok(QueryOutcome {
            rows,
            rows_affected: None,
            duration_ms: started.elapsed().as_millis() as u64,
            truncated,
            read_only: true,
        })
    } else {
        let result = sqlx::query(sql)
            .execute(&mut *tx)
            .await
            .map_err(map_query_error)?;

        tx.commit().await?;

        Ok(QueryOutcome {
            rows: Value::Array(Vec::new()),
            rows_affected: Some(result.rows_affected()),
            duration_ms: started.elapsed().as_millis() as u64,
            truncated: false,
            read_only: false,
        })
    }
}

/// Execute several statements atomically: any failure rolls back everything.
pub async fn run_multi(
    pool: &PgPool,
    statements: &[String],
    timeout_ms: u64,
) -> Result<(Vec<u64>, u64), AppError> {
    let started = std::time::Instant::now();
    let timeout_ms = timeout_ms.max(1_000);
    let mut tx = pool.begin().await?;

    sqlx::query(&format!("SET LOCAL statement_timeout = {timeout_ms}"))
        .execute(&mut *tx)
        .await?;

    let mut affected = Vec::with_capacity(statements.len());

    for statement in statements {
        let sql = super::validator::normalize(statement);
        if sql.is_empty() {
            tx.rollback().await.ok();
            return Err(AppError::BadRequest("empty statement".into()));
        }
        match sqlx::query(sql).execute(&mut *tx).await {
            Ok(result) => affected.push(result.rows_affected()),
            Err(error) => {
                // Rollback is implicit when the transaction is dropped, but do it explicitly.
                tx.rollback().await.ok();
                return Err(map_query_error(error));
            }
        }
    }

    tx.commit().await?;
    Ok((affected, started.elapsed().as_millis() as u64))
}

pub fn map_query_error(error: sqlx::Error) -> AppError {
    match &error {
        sqlx::Error::Database(db) => {
            if db.code().as_deref() == Some("57014") {
                return AppError::Timeout("query exceeded the statement timeout".into());
            }
            let message: String = db
                .message()
                .chars()
                .filter(|c| !c.is_control())
                .take(300)
                .collect();
            AppError::BadRequest(message)
        }
        other => AppError::Database(other.clone()),
    }
}
