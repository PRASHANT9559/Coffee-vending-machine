//! Query classification and validation.
//!
//! The console accepts free-form SQL by design, so the guard rails are:
//! * a hard size limit,
//! * exactly one statement per request,
//! * a read/write classification used for default read-only enforcement,
//! * `statement_timeout` applied inside the transaction (see [`super::executor`]).
//!
//! Writes are authorised separately by the RBAC layer; this module never decides *who*
//! may run a statement.

use crate::common::errors::AppError;

const MAX_SQL_LEN: usize = 100_000;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueryKind {
    Read,
    Write,
}

impl QueryKind {
    pub fn is_read(self) -> bool {
        matches!(self, Self::Read)
    }
}

/// Trim trailing separators and surrounding whitespace.
pub fn normalize(sql: &str) -> &str {
    sql.trim().trim_end_matches(';').trim()
}

pub fn first_keyword(sql: &str) -> String {
    sql.trim_start()
        .split(|c: char| c.is_whitespace() || c == '(')
        .next()
        .unwrap_or("")
        .to_ascii_uppercase()
}

pub fn is_read_query(sql: &str) -> bool {
    matches!(
        first_keyword(sql).as_str(),
        "SELECT" | "SHOW" | "EXPLAIN" | "VALUES" | "TABLE"
    )
}

/// Reject empty input, oversized input and multi-statement payloads.
///
/// A trailing semicolon is allowed; any other semicolon is treated as a second statement
/// and rejected (multi-statement is only available through the transaction endpoint).
pub fn validate(sql: &str) -> Result<(&str, QueryKind), AppError> {
    let normalized = normalize(sql);
    if normalized.is_empty() {
        return Err(AppError::BadRequest("sql must not be empty".into()));
    }
    if normalized.len() > MAX_SQL_LEN {
        return Err(AppError::Validation(format!(
            "sql exceeds the {MAX_SQL_LEN} character limit"
        )));
    }
    if normalized.contains(';') {
        return Err(AppError::Validation(
            "only one statement is allowed per request; use the transaction endpoint for multiple statements"
                .into(),
        ));
    }

    let kind = if is_read_query(normalized) {
        QueryKind::Read
    } else {
        QueryKind::Write
    };

    Ok((normalized, kind))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classifies_statements() {
        assert!(is_read_query("SELECT 1"));
        assert!(is_read_query("EXPLAIN SELECT 1"));
        assert!(!is_read_query("UPDATE users SET x = 1"));
        assert!(!is_read_query("DELETE FROM users"));
    }

    #[test]
    fn cte_is_treated_as_write() {
        // A CTE can contain a data-modifying statement, so it must not be classified as
        // read-only.
        assert!(!is_read_query(
            "WITH gone AS (DELETE FROM users RETURNING *) SELECT * FROM gone"
        ));
        let (_, kind) = validate("WITH x AS (SELECT 1) SELECT * FROM x").unwrap();
        assert_eq!(kind, QueryKind::Write);
    }

    #[test]
    fn normalizes_semicolons() {
        assert_eq!(normalize(" SELECT 1; "), "SELECT 1");
    }

    #[test]
    fn rejects_multi_statement() {
        assert!(validate("SELECT 1; SELECT 2").is_err());
        assert!(validate("SELECT 1;").is_ok());
    }

    #[test]
    fn rejects_empty() {
        assert!(validate("   ;  ").is_err());
    }

    #[test]
    fn classifies_write() {
        let (_, kind) = validate("UPDATE t SET a = 1").unwrap();
        assert_eq!(kind, QueryKind::Write);
    }
}
