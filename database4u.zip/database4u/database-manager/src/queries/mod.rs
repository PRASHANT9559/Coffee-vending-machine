//! Query console.
//!
//! Two endpoints:
//! * `POST /queries/execute` — one statement, default read-only for non-admins.
//! * `POST /transactions/execute` — up to 100 statements in a single transaction.

pub mod executor;
pub mod validator;

use axum::extract::State;
use axum::Json;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::ApiResponse;
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::connections::isolation::access::require_target_permission;
use crate::connections::service as connection_service;
use crate::security::permissions::policy;

const DEFAULT_MAX_ROWS: i64 = 100;
const HARD_MAX_ROWS: i64 = 1000;
const MAX_TRANSACTION_STATEMENTS: usize = 100;

#[derive(Debug, Deserialize)]
pub struct ExecuteQueryRequest {
    pub database_target_id: Uuid,
    pub sql: String,
    /// `None` applies the role-aware default: read-only unless the caller can alter
    /// schema in the owning project.
    pub read_only: Option<bool>,
    pub max_rows: Option<i64>,
}

#[derive(Debug, Deserialize)]
pub struct MultiStatementRequest {
    pub database_target_id: Uuid,
    pub statements: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct QueryResult {
    pub rows: Value,
    pub rows_affected: Option<u64>,
    pub duration_ms: u64,
    pub truncated: bool,
    pub read_only: bool,
}

#[derive(Debug, Serialize)]
pub struct MultiStatementResult {
    pub statements: usize,
    pub rows_affected: Vec<u64>,
    pub duration_ms: u64,
}

pub async fn execute(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<ExecuteQueryRequest>,
) -> Result<Json<ApiResponse<QueryResult>>, AppError> {
    let project_id = require_target_permission(
        &state.db,
        user.user_id,
        request.database_target_id,
        "query.execute",
    )
    .await?;

    let (sql, kind) = validator::validate(&request.sql)?;

    // Default stance: read-only. Only project members who can alter schema may run
    // write statements unless they explicitly opt in to read-only mode.
    let can_write = policy::has_project_permission(
        &state.db,
        user.user_id,
        project_id,
        "schema.alter",
    )
    .await?;
    let read_only = request.read_only.unwrap_or(!can_write);

    if !kind.is_read() && read_only {
        return Err(AppError::Forbidden(
            "read-only mode rejects non-SELECT statements".into(),
        ));
    }

    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;

    let max_rows = request
        .max_rows
        .unwrap_or(DEFAULT_MAX_ROWS)
        .clamp(1, HARD_MAX_ROWS);

    let timeout_ms = state.settings.query_timeout_seconds.saturating_mul(1000);
    let outcome = executor::run(&entry.pool, sql, kind, max_rows, timeout_ms).await?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        Some(project_id),
        "query.execute",
        "query",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(QueryResult {
        rows: outcome.rows,
        rows_affected: outcome.rows_affected,
        duration_ms: outcome.duration_ms,
        truncated: outcome.truncated,
        read_only: outcome.read_only,
    })))
}

/// Execute several statements atomically: any failure rolls back everything.
pub async fn execute_multi(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<MultiStatementRequest>,
) -> Result<Json<ApiResponse<MultiStatementResult>>, AppError> {
    let project_id = require_target_permission(
        &state.db,
        user.user_id,
        request.database_target_id,
        "query.execute",
    )
    .await?;

    if request.statements.is_empty() {
        return Err(AppError::BadRequest("no statements supplied".into()));
    }
    if request.statements.len() > MAX_TRANSACTION_STATEMENTS {
        return Err(AppError::BadRequest(format!(
            "at most {MAX_TRANSACTION_STATEMENTS} statements per transaction"
        )));
    }

    let (entry, _) =
        connection_service::resolve_target(&state, user.user_id, request.database_target_id)
            .await?;

    let timeout_ms = state.settings.query_timeout_seconds.saturating_mul(1000);
    let (affected, duration_ms) =
        executor::run_multi(&entry.pool, &request.statements, timeout_ms).await?;

    crate::security::audit::record(
        &state.db,
        Some(user.user_id),
        Some(project_id),
        "query.execute_transaction",
        "transaction",
        true,
        None,
        None,
    )
    .await;

    Ok(Json(ApiResponse::ok(MultiStatementResult {
        statements: affected.len(),
        rows_affected: affected,
        duration_ms,
    })))
}
