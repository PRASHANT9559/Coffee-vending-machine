//! Thin facade over the security submodules.
//!
//! Business modules should depend on this module rather than reaching into
//! `security::auth::login` directly.

pub use crate::security::auth::login::{
    hash_password, verify_password, LoginRequest, LoginResponse,
};
pub use crate::security::auth::sessions::revoke_all_for_user;
pub use crate::security::permissions::policy::{
    effective_permissions, has_project_permission, is_project_member, require_project_permission,
};
