use axum::extract::State;
use axum::Json;

use crate::api::response::ApiResponse;
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::security::roles::{self, PermissionInfo, RoleInfo};

pub async fn list_permissions(
    State(state): State<AppState>,
) -> Result<Json<ApiResponse<Vec<PermissionInfo>>>, AppError> {
    let permissions = roles::list_permissions(&state.db).await?;
    Ok(Json(ApiResponse::ok(permissions)))
}

pub async fn list_roles(
    State(state): State<AppState>,
) -> Result<Json<ApiResponse<Vec<RoleInfo>>>, AppError> {
    let roles = roles::list_roles(&state.db).await?;
    Ok(Json(ApiResponse::ok(roles)))
}
