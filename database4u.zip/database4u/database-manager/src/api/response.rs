use serde::{Deserialize, Serialize};

use crate::common::errors::AppError;

/// Positive version of the standard API envelope.
#[derive(Debug, Clone, Serialize)]
pub struct ApiResponse<T> {
    pub success: bool,
    pub data: T,
}

impl<T> ApiResponse<T> {
    pub fn ok(data: T) -> Self {
        Self {
            success: true,
            data,
        }
    }
}

impl<T> From<T> for ApiResponse<T> {
    fn from(data: T) -> Self {
        Self::ok(data)
    }
}

/// Generic acknowledgement body for mutations that have no payload.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Ack {
    pub message: String,
}

impl Ack {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}

/// Health payload returned by `/health`.
#[derive(Debug, Clone, Serialize)]
pub struct HealthStatus {
    pub status: &'static str,
    pub version: &'static str,
    pub environment: String,
    pub database: &'static str,
}

/// JSON rejection wrapper so malformed bodies produce a structured error.
pub fn json_error(message: impl Into<String>) -> AppError {
    AppError::BadRequest(message.into())
}
