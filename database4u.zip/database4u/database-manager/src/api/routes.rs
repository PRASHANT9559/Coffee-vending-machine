use axum::extract::{Path, State};
use axum::http::HeaderMap;
use axum::middleware;
use axum::routing::{delete, get, patch, post};
use axum::{Json, Router};
use tower_http::limit::RequestBodyLimitLayer;
use uuid::Uuid;

use crate::api::middleware::{auth_middleware, request_id_middleware, AuthUser};
use crate::api::response::{Ack, ApiResponse, HealthStatus};
use crate::app_state::AppState;
use crate::audit::list_audit;
use crate::common::errors::AppError;
use crate::common::types::RequestMeta;
use crate::connections::controller as connections;
use crate::databases as databases;
use crate::files;
use crate::permissions;
use crate::projects::api as projects;
use crate::queries;
use crate::records;
use crate::schema;
use crate::security::auth::login::{self, BootstrapRequest, LoginRequest, RefreshRequest};
use crate::security::auth::password_reset::{self, PasswordResetConfirm, PasswordResetRequest};
use crate::security::auth::sessions;
use crate::users;

const V1: &str = "/api/v1";
const MAX_REQUEST_BODY: usize = 16 * 1024 * 1024; // 16 MB limit to support file chunks

pub fn create_router(state: AppState) -> Router {
    let public = Router::new()
        .route("/health", get(health))
        .route("/ready", get(ready))
        .route(&format!("{V1}/auth/login"), post(auth_login))
        .route(&format!("{V1}/auth/refresh"), post(auth_refresh))
        .route(&format!("{V1}/auth/bootstrap"), post(auth_bootstrap))
        .route(
            &format!("{V1}/auth/password-reset/request"),
            post(auth_password_reset_request),
        )
        .route(
            &format!("{V1}/auth/password-reset/confirm"),
            post(auth_password_reset_confirm),
        )
        .route(
            &format!("{V1}/files/shared/:token"),
            get(files::api::download_shared_file_handler),
        );

    let protected = Router::new()
        // Session lifecycle
        .route(&format!("{V1}/auth/logout"), post(auth_logout))
        .route(&format!("{V1}/auth/logout-all"), post(auth_logout_all))
        .route(&format!("{V1}/auth/sessions"), get(auth_sessions))
        .route(
            &format!("{V1}/auth/sessions/:session_id"),
            delete(auth_revoke_session),
        )
        // Users
        .route(&format!("{V1}/users/me"), get(users::me))
        .route(
            &format!("{V1}/users/me/password"),
            post(users::change_password),
        )
        // Permissions catalogue
        .route(&format!("{V1}/permissions"), get(permissions::list_permissions))
        .route(&format!("{V1}/roles"), get(permissions::list_roles))
        // Projects
        .route(
            &format!("{V1}/projects"),
            get(projects::list_projects).post(projects::create_project),
        )
        .route(
            &format!("{V1}/projects/:project_id"),
            get(projects::get_project)
                .patch(projects::update_project)
                .delete(projects::archive_project),
        )
        .route(
            &format!("{V1}/projects/:project_id/members"),
            get(projects::list_members).post(projects::add_member),
        )
        .route(
            &format!("{V1}/projects/:project_id/members/:member_id"),
            patch(projects::update_member).delete(projects::remove_member),
        )
        .route(
            &format!("{V1}/projects/:project_id/permissions"),
            get(projects::project_permissions),
        )
        // Project <-> connection mapping
        .route(
            &format!("{V1}/projects/:project_id/connections"),
            get(projects::list_project_connections).post(projects::add_project_connection),
        )
        .route(
            &format!("{V1}/projects/:project_id/connections/:connection_id"),
            delete(projects::remove_project_connection),
        )
        // Connections
        .route(
            &format!("{V1}/connections"),
            get(connections::list).post(connections::create),
        )
        .route(
            &format!("{V1}/connections/:connection_id"),
            get(connections::get)
                .patch(connections::update)
                .delete(connections::delete),
        )
        .route(
            &format!("{V1}/connections/:connection_id/test"),
            post(connections::test),
        )
        .route(
            &format!("{V1}/connections/:connection_id/rotate-credential"),
            post(connections::rotate_credential),
        )
        .route(
            &format!("{V1}/connections/:connection_id/connect"),
            post(connections::connect),
        )
        .route(
            &format!("{V1}/connections/:connection_id/disconnect"),
            post(connections::disconnect),
        )
        .route(
            &format!("{V1}/connections/:connection_id/reconnect"),
            post(connections::reconnect),
        )
        .route(
            &format!("{V1}/connections/:connection_id/health"),
            get(connections::health),
        )
        .route(
            &format!("{V1}/connections/:connection_id/metrics"),
            get(connections::metrics),
        )
        .route(
            &format!("{V1}/connections/:connection_id/databases"),
            get(connections::databases),
        )
        .route(
            &format!("{V1}/connections/:connection_id/discover"),
            post(connections::discover_databases),
        )
        // Databases
        .route(
            &format!("{V1}/databases"),
            get(databases::list_databases).post(databases::create_database),
        )
        .route(
            &format!("{V1}/databases/:database_target_id"),
            get(databases::get_database).delete(databases::drop_database),
        )
        .route(
            &format!("{V1}/databases/:database_target_id/rename"),
            post(databases::rename_database),
        )
        .route(
            &format!("{V1}/databases/:database_target_id/tables"),
            get(schema::list_tables_for_database),
        )
        // Schema
        .route(&format!("{V1}/tables"), post(schema::create_table).delete(schema::drop_table))
        .route(&format!("{V1}/tables/columns"), get(schema::list_columns).post(schema::add_column))
        .route(&format!("{V1}/tables/indexes"), get(schema::list_indexes))
        .route(&format!("{V1}/tables/constraints"), get(schema::list_constraints))
        .route(&format!("{V1}/tables/rename"), post(schema::rename_table))
        .route(&format!("{V1}/indexes"), post(schema::create_index))
        .route(&format!("{V1}/indexes/drop"), post(schema::drop_index))
        .route(&format!("{V1}/tables/inspect"), get(schema::inspect_table))
        .route(&format!("{V1}/tables/relations"), get(schema::list_relations))
        .route(
            &format!("{V1}/tables/columns/rename"),
            post(schema::rename_column),
        )
        .route(
            &format!("{V1}/tables/columns/type"),
            post(schema::alter_column_type),
        )
        .route(
            &format!("{V1}/tables/columns/drop"),
            post(schema::drop_column),
        )
        .route(
            &format!("{V1}/tables/constraints/drop"),
            post(schema::drop_constraint),
        )
        // Views & sequences
        .route(
            &format!("{V1}/views"),
            get(schema::list_views)
                .post(schema::create_view)
                .delete(schema::drop_view),
        )
        .route(&format!("{V1}/sequences"), get(schema::list_sequences))
        // Records
        .route(
            &format!("{V1}/records"),
            get(records::list_records)
                .post(records::insert_record)
                .patch(records::update_record)
                .delete(records::delete_record),
        )
        .route(
            &format!("{V1}/records/bulk"),
            post(records::bulk_insert_records),
        )
        // Query engine
        .route(&format!("{V1}/queries/execute"), post(queries::execute))
        .route(
            &format!("{V1}/transactions/execute"),
            post(queries::execute_multi),
        )
        // Audit
        .route(&format!("{V1}/audit"), get(list_audit))
        // Realtime
        .route(&format!("{V1}/ws"), get(crate::realtime::ws_handler))
        // Files & Uploads
        .route(&format!("{V1}/files"), get(files::api::list_files))
        .route(
            &format!("{V1}/files/:file_id"),
            get(files::api::get_file)
                .patch(files::api::rename_file)
                .delete(files::api::delete_file),
        )
        .route(
            &format!("{V1}/files/:file_id/download"),
            get(files::api::download_file),
        )
        .route(
            &format!("{V1}/files/:file_id/permissions"),
            get(files::api::list_file_permissions_handler)
                .post(files::api::grant_file_permission_handler),
        )
        .route(
            &format!("{V1}/files/permissions/:permission_id"),
            delete(files::api::revoke_file_permission_handler),
        )
        // Upload sessions
        .route(
            &format!("{V1}/files/upload-sessions"),
            post(files::api::create_upload_session),
        )
        .route(
            &format!("{V1}/files/upload-sessions/:session_id"),
            get(files::api::get_upload_session)
                .delete(files::api::abort_upload_session),
        )
        .route(
            &format!("{V1}/files/upload-sessions/:session_id/parts"),
            get(files::api::get_resumable_status)
                .post(files::api::upload_part),
        )
        .route(
            &format!("{V1}/files/upload-sessions/:session_id/complete"),
            post(files::api::complete_upload_session),
        )
        // Quotas & Metrics
        .route(
            &format!("{V1}/projects/:project_id/storage-usage"),
            get(files::api::get_storage_usage),
        )
        .route(
            &format!("{V1}/files/metrics"),
            get(files::api::get_metrics),
        )
        // File Shares
        .route(
            &format!("{V1}/files/:file_id/shares"),
            get(files::api::list_file_shares_handler)
                .post(files::api::create_file_share_handler),
        )
        .route(
            &format!("{V1}/files/:file_id/shares/:share_id"),
            delete(files::api::revoke_file_share_handler),
        )
        // Security Events
        .route(
            &format!("{V1}/security/events"),
            get(security_events_handler),
        )
        .layer(middleware::from_fn_with_state(
            state.clone(),
            auth_middleware,
        ));

    public
        .merge(protected)
        .layer(RequestBodyLimitLayer::new(MAX_REQUEST_BODY))
        .layer(middleware::from_fn(request_id_middleware))
        .with_state(state)
}

async fn health(State(state): State<AppState>) -> Json<ApiResponse<HealthStatus>> {
    Json(ApiResponse::ok(HealthStatus {
        status: "ok",
        version: env!("CARGO_PKG_VERSION"),
        environment: state.settings.environment.to_string(),
        database: "unchecked",
    }))
}

async fn ready(State(state): State<AppState>) -> Result<Json<ApiResponse<HealthStatus>>, AppError> {
    let ok = crate::infrastructure::postgres::health::check_database(&state.db).await;
    if !ok {
        return Err(AppError::Unavailable("database is not ready".into()));
    }
    Ok(Json(ApiResponse::ok(HealthStatus {
        status: "ready",
        version: env!("CARGO_PKG_VERSION"),
        environment: state.settings.environment.to_string(),
        database: "ok",
    })))
}

async fn auth_login(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(request): Json<LoginRequest>,
) -> Result<Json<ApiResponse<login::LoginResponse>>, AppError> {
    let meta = RequestMeta::from_headers(&headers);
    let response = login::login(&state, request, meta).await?;
    Ok(Json(ApiResponse::ok(response)))
}

async fn auth_refresh(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(request): Json<RefreshRequest>,
) -> Result<Json<ApiResponse<login::RefreshResponse>>, AppError> {
    let meta = RequestMeta::from_headers(&headers);
    let response = login::refresh(&state, request, meta).await?;
    Ok(Json(ApiResponse::ok(response)))
}

async fn auth_bootstrap(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(request): Json<BootstrapRequest>,
) -> Result<Json<ApiResponse<crate::security::users::UserPublic>>, AppError> {
    let meta = RequestMeta::from_headers(&headers);
    let user = login::bootstrap(&state, request, meta).await?;
    Ok(Json(ApiResponse::ok(user)))
}

async fn auth_password_reset_request(
    State(state): State<AppState>,
    Json(request): Json<PasswordResetRequest>,
) -> Result<Json<ApiResponse<password_reset::PasswordResetResponse>>, AppError> {
    let response = password_reset::request_reset(&state, request).await?;
    Ok(Json(ApiResponse::ok(response)))
}

async fn auth_password_reset_confirm(
    State(state): State<AppState>,
    Json(request): Json<PasswordResetConfirm>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    password_reset::confirm_reset(&state, request).await?;
    Ok(Json(ApiResponse::ok(Ack::new("password has been reset"))))
}

async fn auth_logout(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    sessions::revoke_current(&state.db, user.session_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("logged out"))))
}

async fn auth_logout_all(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    sessions::revoke_all_for_user(&state.db, user.user_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("all sessions revoked"))))
}

async fn auth_sessions(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<Json<ApiResponse<Vec<sessions::SessionInfo>>>, AppError> {
    let rows = sessions::list_for_user(&state.db, user.user_id).await?;
    Ok(Json(ApiResponse::ok(rows)))
}

async fn auth_revoke_session(
    State(state): State<AppState>,
    user: AuthUser,
    Path(session_id): Path<Uuid>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    sessions::revoke(&state.db, user.user_id, session_id).await?;
    Ok(Json(ApiResponse::ok(Ack::new("session revoked"))))
}

async fn security_events_handler(
    State(state): State<AppState>,
    _user: AuthUser,
) -> Result<Json<ApiResponse<Vec<crate::security::security_events::SecurityEvent>>>, AppError> {
    let events = crate::security::security_events::list_security_events(&state.db, None, 50).await?;
    Ok(Json(ApiResponse::ok(events)))
}
