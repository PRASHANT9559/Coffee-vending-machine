use async_trait::async_trait;
use axum::extract::{FromRequestParts, Request, State};
use axum::http::request::Parts;
use axum::http::HeaderMap;
use axum::middleware::Next;
use axum::response::Response;
use uuid::Uuid;

use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::security::auth::tokens;

/// Authenticated principal attached to the request by `auth_middleware`.
#[derive(Debug, Clone)]
pub struct AuthUser {
    pub user_id: Uuid,
    pub session_id: Uuid,
    pub username: String,
}

#[async_trait]
impl<S> FromRequestParts<S> for AuthUser
where
    S: Send + Sync,
{
    type Rejection = AppError;

    async fn from_request_parts(parts: &mut Parts, _state: &S) -> Result<Self, Self::Rejection> {
        parts
            .extensions
            .get::<AuthUser>()
            .cloned()
            .ok_or_else(|| AppError::Unauthorized("authentication required".into()))
    }
}

/// Extract a bearer token from the `Authorization` header.
pub fn bearer_token(headers: &HeaderMap) -> Option<String> {
    let value = headers.get(axum::http::header::AUTHORIZATION)?;
    let raw = value.to_str().ok()?.trim();
    let token = raw
        .strip_prefix("Bearer ")
        .or_else(|| raw.strip_prefix("bearer "))?;
    let token = token.trim();
    if token.is_empty() {
        None
    } else {
        Some(token.to_string())
    }
}

/// Validate the access token against the session store and attach the principal.
pub async fn auth_middleware(
    State(state): State<AppState>,
    mut request: Request,
    next: Next,
) -> Result<Response, AppError> {
    let token = bearer_token(request.headers())
        .ok_or_else(|| AppError::Unauthorized("missing bearer token".into()))?;

    let principal = tokens::authenticate_access_token(&state.db, &token)
        .await?
        .ok_or_else(|| AppError::Unauthorized("invalid or expired session".into()))?;

    request.extensions_mut().insert(principal);
    Ok(next.run(request).await)
}

/// Attach a request id to every response and log the outcome.
pub async fn request_id_middleware(mut request: Request, next: Next) -> Response {
    let request_id = Uuid::new_v4();
    request
        .extensions_mut()
        .insert(RequestId(request_id.to_string()));

    let method = request.method().clone();
    let path = request.uri().path().to_string();
    let started = std::time::Instant::now();

    let mut response = next.run(request).await;

    let elapsed_ms = started.elapsed().as_millis() as u64;
    response.headers_mut().insert(
        "x-request-id",
        axum::http::HeaderValue::from_str(&request_id.to_string())
            .unwrap_or_else(|_| axum::http::HeaderValue::from_static("invalid")),
    );

    tracing::info!(
        request_id = %request_id,
        method = %method,
        path = %path,
        status = %response.status().as_u16(),
        elapsed_ms,
        "request completed"
    );

    response
}

#[derive(Debug, Clone)]
pub struct RequestId(pub String);

/// Small helper so handlers can rate-limit by client identity.
pub fn client_rate_key(headers: &HeaderMap, scope: &str) -> String {
    let ip = headers
        .get("x-real-ip")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("unknown");
    format!("{scope}:{ip}")
}
