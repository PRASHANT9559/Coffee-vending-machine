//! Audit trail reader.
//!
//! Writes happen through [`crate::security::audit`]; this module only exposes a
//! project-scoped, paginated read surface with server-side filters.

use axum::extract::{Query, State};
use axum::Json;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::api::response::ApiResponse;
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::common::types::Page;

#[derive(Debug, Deserialize)]
pub struct AuditQuery {
    pub project_id: Option<Uuid>,
    pub action: Option<String>,
    pub user_id: Option<Uuid>,
    pub from: Option<DateTime<Utc>>,
    pub to: Option<DateTime<Utc>>,
    pub page: Option<i64>,
    pub limit: Option<i64>,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct AuditEntry {
    pub log_id: Uuid,
    pub user_id: Option<Uuid>,
    pub project_id: Option<Uuid>,
    pub connection_id: Option<Uuid>,
    pub action: String,
    pub target_resource: String,
    pub status: String,
    pub duration_ms: Option<i32>,
    pub created_at: DateTime<Utc>,
}

pub async fn list_audit(
    State(state): State<AppState>,
    user: AuthUser,
    Query(query): Query<AuditQuery>,
) -> Result<Json<ApiResponse<Page<AuditEntry>>>, AppError> {
    let limit = query.limit.unwrap_or(50).clamp(1, 200);
    let page = query.page.unwrap_or(1).max(1);
    let offset = (page - 1) * limit;

    // Without an explicit project scope only the caller's own activity is visible.
    let scoped_project = match query.project_id {
        Some(project_id) => {
            crate::security::permissions::policy::require_project_permission(
                &state.db,
                user.user_id,
                project_id,
                "audit.read",
            )
            .await?;
            Some(project_id)
        }
        None => None,
    };

    // A caller-scoped query may filter by their own user id only; a project-scoped
    // query may filter by any member.
    let user_filter = if scoped_project.is_some() {
        query.user_id
    } else {
        Some(user.user_id)
    };

    let total = sqlx::query_scalar::<_, i64>(
        r#"SELECT count(*)
           FROM audit_logs
           WHERE ($1::uuid IS NULL OR project_id = $1)
             AND ($2::uuid IS NULL OR user_id = $2)
             AND ($3::text IS NULL OR action = $3)
             AND ($4::timestamptz IS NULL OR created_at >= $4)
             AND ($5::timestamptz IS NULL OR created_at <= $5)"#,
    )
    .bind(scoped_project)
    .bind(user_filter)
    .bind(query.action.as_deref())
    .bind(query.from)
    .bind(query.to)
    .fetch_one(&state.db)
    .await?;

    let rows = sqlx::query_as::<_, AuditEntry>(
        r#"SELECT log_id, user_id, project_id, connection_id, action, target_resource,
                  status, duration_ms, created_at
           FROM audit_logs
           WHERE ($1::uuid IS NULL OR project_id = $1)
             AND ($2::uuid IS NULL OR user_id = $2)
             AND ($3::text IS NULL OR action = $3)
             AND ($4::timestamptz IS NULL OR created_at >= $4)
             AND ($5::timestamptz IS NULL OR created_at <= $5)
           ORDER BY created_at DESC
           LIMIT $6 OFFSET $7"#,
    )
    .bind(scoped_project)
    .bind(user_filter)
    .bind(query.action.as_deref())
    .bind(query.from)
    .bind(query.to)
    .bind(limit)
    .bind(offset)
    .fetch_all(&state.db)
    .await?;

    Ok(Json(ApiResponse::ok(Page::new(rows, total, page, limit))))
}
