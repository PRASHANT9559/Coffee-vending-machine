use serde::Serialize;
use sqlx::PgPool;

use crate::common::errors::AppError;

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct RoleInfo {
    pub role_id: uuid::Uuid,
    pub role_name: String,
    pub description: Option<String>,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct PermissionInfo {
    pub permission_id: uuid::Uuid,
    pub permission_key: String,
    pub description: Option<String>,
}

pub async fn list_roles(pool: &PgPool) -> Result<Vec<RoleInfo>, AppError> {
    let rows = sqlx::query_as::<_, RoleInfo>(
        "SELECT role_id, role_name, description FROM roles ORDER BY role_name",
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn list_permissions(pool: &PgPool) -> Result<Vec<PermissionInfo>, AppError> {
    let rows = sqlx::query_as::<_, PermissionInfo>(
        "SELECT permission_id, permission_key, description FROM permissions ORDER BY permission_key",
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn find_role_by_name(pool: &PgPool, name: &str) -> Result<Option<RoleInfo>, AppError> {
    let row = sqlx::query_as::<_, RoleInfo>(
        "SELECT role_id, role_name, description FROM roles WHERE role_name = $1",
    )
    .bind(name)
    .fetch_optional(pool)
    .await?;
    Ok(row)
}
