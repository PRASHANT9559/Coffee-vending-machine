use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use tracing::{error, warn};
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::security::rate_limit::hash_ip;

#[derive(Debug, Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct SecurityEvent {
    pub event_id: Uuid,
    pub event_type: String,
    pub severity: String,
    pub user_id: Option<Uuid>,
    pub project_id: Option<Uuid>,
    pub ip_hash: Option<String>,
    pub details: Option<serde_json::Value>,
    pub created_at: DateTime<Utc>,
}

/// Record a high-severity security event (e.g. brute force, token reuse, cross-project breach attempt).
pub async fn record_security_event(
    pool: &PgPool,
    event_type: &str,
    severity: &str,
    user_id: Option<Uuid>,
    project_id: Option<Uuid>,
    raw_ip: Option<&str>,
    mut details: Option<serde_json::Value>,
) {
    let hashed_ip = raw_ip.map(hash_ip);

    // Ensure secrets in details are never stored
    if let Some(ref mut d) = details {
        crate::security::redact_secrets_in_json(d);
    }

    if severity == "critical" {
        error!(
            event_type = %event_type,
            severity = %severity,
            user_id = ?user_id,
            project_id = ?project_id,
            "CRITICAL SECURITY EVENT DETECTED"
        );
    } else {
        warn!(
            event_type = %event_type,
            severity = %severity,
            user_id = ?user_id,
            "security event logged"
        );
    }

    let _ = sqlx::query!(
        r#"
        INSERT INTO security_events (event_type, severity, user_id, project_id, ip_hash, details, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW())
        "#,
        event_type,
        severity,
        user_id,
        project_id,
        hashed_ip,
        details
    )
    .execute(pool)
    .await;
}

/// List recent security events.
pub async fn list_security_events(
    pool: &PgPool,
    severity_filter: Option<&str>,
    limit: i64,
) -> Result<Vec<SecurityEvent>, AppError> {
    let limit = limit.clamp(1, 100);

    let rows = if let Some(sev) = severity_filter {
        sqlx::query_as!(
            SecurityEvent,
            r#"
            SELECT event_id, event_type, severity, user_id, project_id, ip_hash, details, created_at
            FROM security_events
            WHERE severity = $1
            ORDER BY created_at DESC
            LIMIT $2
            "#,
            sev,
            limit
        )
        .fetch_all(pool)
        .await
        .map_err(AppError::Database)?
    } else {
        sqlx::query_as!(
            SecurityEvent,
            r#"
            SELECT event_id, event_type, severity, user_id, project_id, ip_hash, details, created_at
            FROM security_events
            ORDER BY created_at DESC
            LIMIT $1
            "#,
            limit
        )
        .fetch_all(pool)
        .await
        .map_err(AppError::Database)?
    };

    Ok(rows)
}
