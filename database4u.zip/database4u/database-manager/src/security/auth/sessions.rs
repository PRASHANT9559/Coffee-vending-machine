use chrono::{DateTime, Utc};
use serde::Serialize;
use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct SessionInfo {
    pub session_id: Uuid,
    pub created_at: DateTime<Utc>,
    pub expires_at: DateTime<Utc>,
    pub last_seen_at: Option<DateTime<Utc>>,
    pub revoked_at: Option<DateTime<Utc>>,
    pub user_agent: Option<String>,
}

pub async fn list_for_user(pool: &PgPool, user_id: Uuid) -> Result<Vec<SessionInfo>, AppError> {
    let rows = sqlx::query_as::<_, SessionInfo>(
        r#"SELECT session_id, created_at, expires_at, last_seen_at, revoked_at, user_agent
           FROM sessions
           WHERE user_id = $1
           ORDER BY created_at DESC
           LIMIT 100"#,
    )
    .bind(user_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn revoke(pool: &PgPool, user_id: Uuid, session_id: Uuid) -> Result<(), AppError> {
    let affected = sqlx::query(
        "UPDATE sessions SET revoked_at = now() WHERE session_id = $1 AND user_id = $2 AND revoked_at IS NULL",
    )
    .bind(session_id)
    .bind(user_id)
    .execute(pool)
    .await?
    .rows_affected();

    if affected == 0 {
        return Err(AppError::NotFound("session not found".into()));
    }

    sqlx::query(
        "UPDATE refresh_tokens SET revoked_at = now() WHERE session_id = $1 AND revoked_at IS NULL",
    )
    .bind(session_id)
    .execute(pool)
    .await?;

    Ok(())
}

pub async fn revoke_all_for_user(pool: &PgPool, user_id: Uuid) -> Result<u64, AppError> {
    sqlx::query("UPDATE sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL")
        .bind(user_id)
        .execute(pool)
        .await?;

    let affected = sqlx::query(
        r#"UPDATE refresh_tokens SET revoked_at = now()
           WHERE revoked_at IS NULL
             AND session_id IN (SELECT session_id FROM sessions WHERE user_id = $1)"#,
    )
    .bind(user_id)
    .execute(pool)
    .await?
    .rows_affected();

    Ok(affected)
}

pub async fn revoke_current(pool: &PgPool, session_id: Uuid) -> Result<(), AppError> {
    sqlx::query("UPDATE sessions SET revoked_at = now() WHERE session_id = $1")
        .bind(session_id)
        .execute(pool)
        .await?;
    sqlx::query(
        "UPDATE refresh_tokens SET revoked_at = now() WHERE session_id = $1 AND revoked_at IS NULL",
    )
    .bind(session_id)
    .execute(pool)
    .await?;
    Ok(())
}
