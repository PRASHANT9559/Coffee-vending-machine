use chrono::{DateTime, Duration, Utc};
use sha2::{Digest, Sha256};
use sqlx::PgPool;
use uuid::Uuid;

use crate::api::middleware::AuthUser;
use crate::common::errors::AppError;
use crate::common::types::RequestMeta;

/// 256 bits of entropy, hex encoded.
pub fn generate_token() -> String {
    format!("{}{}", Uuid::new_v4().simple(), Uuid::new_v4().simple())
}

/// Tokens are stored hashed at rest — a database leak must not reveal live sessions.
pub fn hash_token(token: &str) -> String {
    hex::encode(Sha256::digest(token.as_bytes()))
}

pub struct IssuedSession {
    pub session_id: Uuid,
    pub access_token: String,
    pub expires_at: DateTime<Utc>,
}

/// Create a new session (login family) and its access token.
pub async fn create_session(
    pool: &PgPool,
    user_id: Uuid,
    ttl_minutes: i64,
    meta: &RequestMeta,
) -> Result<IssuedSession, AppError> {
    let access_token = generate_token();
    let token_hash = hash_token(&access_token);
    let expires_at = Utc::now() + Duration::minutes(ttl_minutes.max(1));

    let session_id = sqlx::query_scalar::<_, Uuid>(
        r#"INSERT INTO sessions (user_id, token_hash, expires_at, user_agent, ip_hash)
           VALUES ($1, $2, $3, $4, $5)
           RETURNING session_id"#,
    )
    .bind(user_id)
    .bind(token_hash)
    .bind(expires_at)
    .bind(meta.user_agent.as_deref())
    .bind(meta.ip_hash.as_deref())
    .fetch_one(pool)
    .await?;

    Ok(IssuedSession {
        session_id,
        access_token,
        expires_at,
    })
}

/// Replace the access token for an existing session (used on refresh).
async fn rotate_access_token(
    pool: &PgPool,
    session_id: Uuid,
    ttl_minutes: i64,
) -> Result<(String, DateTime<Utc>), AppError> {
    let access_token = generate_token();
    let token_hash = hash_token(&access_token);
    let expires_at = Utc::now() + Duration::minutes(ttl_minutes.max(1));

    let affected = sqlx::query(
        "UPDATE sessions SET token_hash = $1, expires_at = $2 WHERE session_id = $3 AND revoked_at IS NULL",
    )
    .bind(token_hash)
    .bind(expires_at)
    .bind(session_id)
    .execute(pool)
    .await?
    .rows_affected();

    if affected == 0 {
        return Err(AppError::Unauthorized("session was revoked".into()));
    }

    Ok((access_token, expires_at))
}

pub async fn issue_refresh_token(
    pool: &PgPool,
    session_id: Uuid,
    ttl_days: i64,
    meta: &RequestMeta,
) -> Result<String, AppError> {
    let token = generate_token();
    let expires_at = Utc::now() + Duration::days(ttl_days.max(1));

    sqlx::query(
        r#"INSERT INTO refresh_tokens (session_id, token_hash, expires_at, user_agent, ip_hash)
           VALUES ($1, $2, $3, $4, $5)"#,
    )
    .bind(session_id)
    .bind(hash_token(&token))
    .bind(expires_at)
    .bind(meta.user_agent.as_deref())
    .bind(meta.ip_hash.as_deref())
    .execute(pool)
    .await?;

    Ok(token)
}

/// Validate an access token. Returns `None` for invalid/expired/revoked sessions.
pub async fn authenticate_access_token(
    pool: &PgPool,
    token: &str,
) -> Result<Option<AuthUser>, AppError> {
    let token_hash = hash_token(token);

    let row = sqlx::query_as::<_, (Uuid, Uuid, String)>(
        r#"SELECT s.session_id, u.user_id, u.username
           FROM sessions s
           JOIN users u ON u.user_id = s.user_id
           WHERE s.token_hash = $1
             AND s.revoked_at IS NULL
             AND s.expires_at > now()
             AND u.is_active = true"#,
    )
    .bind(token_hash)
    .fetch_optional(pool)
    .await?;

    let Some((session_id, user_id, username)) = row else {
        return Ok(None);
    };

    // Throttled presence update: at most once per minute per session.
    sqlx::query(
        r#"UPDATE sessions SET last_seen_at = now()
           WHERE session_id = $1
             AND (last_seen_at IS NULL OR last_seen_at < now() - interval '60 seconds')"#,
    )
    .bind(session_id)
    .execute(pool)
    .await?;

    Ok(Some(AuthUser {
        user_id,
        session_id,
        username,
    }))
}

pub struct RefreshedTokens {
    pub access_token: String,
    pub refresh_token: String,
    pub expires_at: DateTime<Utc>,
    pub user_id: Uuid,
    pub session_id: Uuid,
}

#[derive(sqlx::FromRow)]
struct RefreshRow {
    refresh_token_id: Uuid,
    session_id: Uuid,
    revoked_at: Option<DateTime<Utc>>,
    expires_at: DateTime<Utc>,
    session_revoked_at: Option<DateTime<Utc>>,
    user_id: Uuid,
    is_active: bool,
}

/// Rotate a refresh token.
///
/// Reuse of an already-rotated token is treated as theft: the whole session family is
/// revoked and the caller is rejected.
pub async fn rotate_refresh_token(
    pool: &PgPool,
    raw_refresh_token: &str,
    access_ttl_minutes: i64,
    refresh_ttl_days: i64,
    meta: &RequestMeta,
) -> Result<RefreshedTokens, AppError> {
    let token_hash = hash_token(raw_refresh_token);
    let mut tx = pool.begin().await?;

    let row = sqlx::query_as::<_, RefreshRow>(
        r#"SELECT rt.refresh_token_id, rt.session_id, rt.revoked_at, rt.expires_at,
                  s.revoked_at AS session_revoked_at, s.user_id, u.is_active
           FROM refresh_tokens rt
           JOIN sessions s ON s.session_id = rt.session_id
           JOIN users u ON u.user_id = s.user_id
           WHERE rt.token_hash = $1
           FOR UPDATE OF rt"#,
    )
    .bind(&token_hash)
    .fetch_optional(&mut *tx)
    .await?;

    let Some(RefreshRow {
        refresh_token_id: refresh_id,
        session_id,
        revoked_at,
        expires_at,
        session_revoked_at,
        user_id,
        is_active: active,
    }) = row
    else {
        return Err(AppError::Unauthorized("invalid refresh token".into()));
    };

    if revoked_at.is_some() || session_revoked_at.is_some() || !active || expires_at <= Utc::now() {
        // Reuse detection / dead session: revoke everything in this family.
        sqlx::query("UPDATE refresh_tokens SET revoked_at = now() WHERE session_id = $1 AND revoked_at IS NULL")
            .bind(session_id)
            .execute(&mut *tx)
            .await?;
        sqlx::query("UPDATE sessions SET revoked_at = now() WHERE session_id = $1 AND revoked_at IS NULL")
            .bind(session_id)
            .execute(&mut *tx)
            .await?;
        tx.commit().await?;
        return Err(AppError::Unauthorized(
            "refresh token is no longer valid".into(),
        ));
    }

    // Rotate.
    sqlx::query("UPDATE refresh_tokens SET revoked_at = now(), rotated_at = now() WHERE refresh_token_id = $1")
        .bind(refresh_id)
        .execute(&mut *tx)
        .await?;

    let new_refresh = generate_token();
    let new_refresh_expires = Utc::now() + Duration::days(refresh_ttl_days.max(1));
    let new_refresh_id = sqlx::query_scalar::<_, Uuid>(
        r#"INSERT INTO refresh_tokens (session_id, token_hash, expires_at, user_agent, ip_hash)
           VALUES ($1, $2, $3, $4, $5)
           RETURNING refresh_token_id"#,
    )
    .bind(session_id)
    .bind(hash_token(&new_refresh))
    .bind(new_refresh_expires)
    .bind(meta.user_agent.as_deref())
    .bind(meta.ip_hash.as_deref())
    .fetch_one(&mut *tx)
    .await?;

    sqlx::query("UPDATE refresh_tokens SET replaced_by = $1 WHERE refresh_token_id = $2")
        .bind(new_refresh_id)
        .bind(refresh_id)
        .execute(&mut *tx)
        .await?;

    // New access token for the same session.
    let access_token = generate_token();
    let access_expires = Utc::now() + Duration::minutes(access_ttl_minutes.max(1));
    sqlx::query("UPDATE sessions SET token_hash = $1, expires_at = $2 WHERE session_id = $3")
        .bind(hash_token(&access_token))
        .bind(access_expires)
        .bind(session_id)
        .execute(&mut *tx)
        .await?;

    tx.commit().await?;

    Ok(RefreshedTokens {
        access_token,
        refresh_token: new_refresh,
        expires_at: access_expires,
        user_id,
        session_id,
    })
}

pub async fn rotate_access_for_session(
    pool: &PgPool,
    session_id: Uuid,
    ttl_minutes: i64,
) -> Result<(String, DateTime<Utc>), AppError> {
    rotate_access_token(pool, session_id, ttl_minutes).await
}
