use argon2::password_hash::rand_core::OsRng;
use argon2::password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString};
use argon2::Argon2;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use uuid::Uuid;

use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::common::types::RequestMeta;
use crate::common::validation::{validate_password, validate_username};
use crate::security::audit;
use crate::security::users::{self, UserPublic};

pub const MAX_LOGIN_ATTEMPTS: usize = 5;
pub const LOGIN_WINDOW_SECONDS: u64 = 300;

#[derive(Debug, Deserialize)]
pub struct LoginRequest {
    pub username: String,
    pub password: String,
}

#[derive(Debug, Deserialize)]
pub struct BootstrapRequest {
    pub username: String,
    pub password: String,
}

#[derive(Debug, Deserialize)]
pub struct RefreshRequest {
    pub refresh_token: String,
}

#[derive(Debug, Deserialize)]
pub struct ChangePasswordRequest {
    pub current_password: String,
    pub new_password: String,
}

#[derive(Debug, Serialize)]
pub struct LoginResponse {
    pub access_token: String,
    pub refresh_token: String,
    pub token_type: &'static str,
    pub expires_in: i64,
    pub user: UserPublic,
}

#[derive(Debug, Serialize)]
pub struct RefreshResponse {
    pub access_token: String,
    pub refresh_token: String,
    pub token_type: &'static str,
    pub expires_in: i64,
}

/// Hash a password with Argon2id (defaults: m=19456 KiB, t=2, p=1).
pub fn hash_password(password: &str) -> Result<String, AppError> {
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map(|hash| hash.to_string())
        .map_err(|e| AppError::Internal(format!("password hashing failed: {e}")))
}

pub fn verify_password(password: &str, stored_hash: &str) -> bool {
    let Ok(parsed) = PasswordHash::new(stored_hash) else {
        return false;
    };
    Argon2::default()
        .verify_password(password.as_bytes(), &parsed)
        .is_ok()
}

/// Burn roughly the same amount of time when a user does not exist.
///
/// The dummy hash is generated once with the same Argon2 parameters as real passwords so
/// a missing account and a wrong password take comparable time.
fn dummy_verify(password: &str) {
    static DUMMY_HASH: std::sync::OnceLock<String> = std::sync::OnceLock::new();
    let hash = DUMMY_HASH
        .get_or_init(|| hash_password("database4u-timing-equalizer").unwrap_or_default());
    if !hash.is_empty() {
        let _ = verify_password(password, hash);
    }
}

pub async fn login(
    state: &AppState,
    request: LoginRequest,
    meta: RequestMeta,
) -> Result<LoginResponse, AppError> {
    let username = validate_username(&request.username)?.to_string();

    // Per-IP and per-username throttling.
    let ip_key = format!("login_ip:{}", meta.ip_hash.clone().unwrap_or_else(|| "unknown".into()));
    let user_key = format!("login_user:{username}");
    let window = std::time::Duration::from_secs(LOGIN_WINDOW_SECONDS);

    let ip_ok = state
        .rate_limiter
        .check(&ip_key, MAX_LOGIN_ATTEMPTS * 4, window);
    let user_ok = state
        .rate_limiter
        .check(&user_key, MAX_LOGIN_ATTEMPTS, window);

    if !ip_ok || !user_ok {
        audit::record(
            &state.db,
            None,
            None,
            "auth.login",
            "user",
            false,
            None,
            None,
        )
        .await;
        return Err(AppError::RateLimited(
            "too many login attempts, try again later".into(),
        ));
    }

    let user = users::find_by_username(&state.db, &username).await?;

    let Some(user) = user else {
        dummy_verify(&request.password);
        audit::record(&state.db, None, None, "auth.login", "user", false, None, None).await;
        return Err(AppError::Unauthorized("invalid credentials".into()));
    };

    if !user.is_active {
        dummy_verify(&request.password);
        audit::record(
            &state.db,
            Some(user.user_id),
            None,
            "auth.login",
            "user",
            false,
            None,
            None,
        )
        .await;
        return Err(AppError::Unauthorized("invalid credentials".into()));
    }

    if !verify_password(&request.password, &user.password_hash) {
        audit::record(
            &state.db,
            Some(user.user_id),
            None,
            "auth.login",
            "user",
            false,
            None,
            None,
        )
        .await;
        return Err(AppError::Unauthorized("invalid credentials".into()));
    }

    let session = crate::security::auth::tokens::create_session(
        &state.db,
        user.user_id,
        state.settings.access_token_ttl_minutes,
        &meta,
    )
    .await?;

    let refresh_token = crate::security::auth::tokens::issue_refresh_token(
        &state.db,
        session.session_id,
        state.settings.refresh_token_ttl_days,
        &meta,
    )
    .await?;

    let _ = users::set_last_login(&state.db, user.user_id).await;

    audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "auth.login",
        "user",
        true,
        None,
        None,
    )
    .await;

    Ok(LoginResponse {
        access_token: session.access_token,
        refresh_token,
        token_type: "Bearer",
        expires_in: state.settings.access_token_ttl_minutes * 60,
        user: UserPublic::from(user),
    })
}

pub async fn refresh(
    state: &AppState,
    request: RefreshRequest,
    meta: RequestMeta,
) -> Result<RefreshResponse, AppError> {
    let refreshed = crate::security::auth::tokens::rotate_refresh_token(
        &state.db,
        &request.refresh_token,
        state.settings.access_token_ttl_minutes,
        state.settings.refresh_token_ttl_days,
        &meta,
    )
    .await?;

    audit::record(
        &state.db,
        Some(refreshed.user_id),
        None,
        "auth.refresh",
        "session",
        true,
        None,
        None,
    )
    .await;

    Ok(RefreshResponse {
        access_token: refreshed.access_token,
        refresh_token: refreshed.refresh_token,
        token_type: "Bearer",
        expires_in: state.settings.access_token_ttl_minutes * 60,
    })
}

/// Create the very first platform user. Only allowed while the users table is empty.
///
/// A transaction-scoped advisory lock closes the race where two concurrent requests both
/// observe an empty table and create two "first" users.
pub async fn bootstrap(
    state: &AppState,
    request: BootstrapRequest,
    meta: RequestMeta,
) -> Result<UserPublic, AppError> {
    let username = validate_username(&request.username)?.to_string();
    validate_password(&request.password)?;

    let hash = hash_password(&request.password)?;
    let mut tx = state.db.begin().await?;

    sqlx::query("SELECT pg_advisory_xact_lock(hashtext('database4u.bootstrap'))")
        .execute(&mut *tx)
        .await?;

    let count = sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM users")
        .fetch_one(&mut *tx)
        .await?;
    if count > 0 {
        return Err(AppError::Forbidden(
            "bootstrap is only available on an empty installation".into(),
        ));
    }

    let user = sqlx::query_as::<_, crate::security::users::User>(
        r#"INSERT INTO users (username, password_hash)
           VALUES ($1, $2)
           RETURNING user_id, username, password_hash, is_active, created_at, updated_at"#,
    )
    .bind(&username)
    .bind(&hash)
    .fetch_one(&mut *tx)
    .await
    .map_err(|error| match error {
        sqlx::Error::Database(db) if db.is_unique_violation() => {
            AppError::Conflict("username already exists".into())
        }
        other => AppError::Database(other),
    })?;

    tx.commit().await?;

    audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "auth.bootstrap",
        "user",
        true,
        None,
        None,
    )
    .await;

    let _ = meta;

    Ok(UserPublic::from(user))
}

pub async fn change_password(
    state: &AppState,
    user_id: Uuid,
    request: ChangePasswordRequest,
) -> Result<(), AppError> {
    validate_password(&request.new_password)?;

    let user = users::find_by_id(&state.db, user_id)
        .await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;

    if !verify_password(&request.current_password, &user.password_hash) {
        return Err(AppError::Unauthorized("current password is incorrect".into()));
    }

    let hash = hash_password(&request.new_password)?;
    users::update_password(&state.db, user_id, &hash).await?;

    // Password change invalidates every existing session.
    crate::security::auth::sessions::revoke_all_for_user(&state.db, user_id).await?;

    audit::record(
        &state.db,
        Some(user_id),
        None,
        "auth.password_changed",
        "user",
        true,
        None,
        None,
    )
    .await;

    Ok(())
}

pub async fn revoke_session(
    pool: &PgPool,
    user_id: Uuid,
    session_id: Uuid,
) -> Result<(), AppError> {
    let affected = sqlx::query(
        "UPDATE sessions SET revoked_at = now() WHERE session_id = $1 AND user_id = $2 AND revoked_at IS NULL",
    )
    .bind(session_id)
    .bind(user_id)
    .execute(pool)
    .await?
    .rows_affected();

    if affected == 0 {
        return Err(AppError::NotFound("session not found".into()));
    }
    Ok(())
}

pub async fn session_expiry(pool: &PgPool, session_id: Uuid) -> Result<Option<DateTime<Utc>>, AppError> {
    let expires = sqlx::query_scalar::<_, DateTime<Utc>>(
        "SELECT expires_at FROM sessions WHERE session_id = $1",
    )
    .bind(session_id)
    .fetch_optional(pool)
    .await?;
    Ok(expires)
}
