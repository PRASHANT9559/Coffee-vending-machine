use chrono::{Duration, Utc};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;

use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::common::validation::{validate_password, validate_username};
use crate::security::audit;
use crate::security::auth::login::hash_password;
use crate::security::auth::tokens::{generate_token, hash_token};
use crate::security::users;

#[derive(Debug, Deserialize)]
pub struct PasswordResetRequest {
    pub username: String,
}

#[derive(Debug, Deserialize)]
pub struct PasswordResetConfirm {
    pub token: String,
    pub new_password: String,
}

#[derive(Debug, Serialize)]
pub struct PasswordResetResponse {
    pub message: String,
    /// Only populated in non-production environments to make local testing possible.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub development_token: Option<String>,
}

pub async fn request_reset(
    state: &AppState,
    request: PasswordResetRequest,
) -> Result<PasswordResetResponse, AppError> {
    let generic = PasswordResetResponse {
        message: "if the account exists, a reset link has been issued".into(),
        development_token: None,
    };

    let username = match validate_username(&request.username) {
        Ok(value) => value.to_string(),
        Err(_) => return Ok(generic),
    };

    let Some(user) = users::find_by_username(&state.db, &username).await? else {
        return Ok(generic);
    };

    let token = generate_token();
    let expires_at = Utc::now() + Duration::minutes(state.settings.password_reset_ttl_minutes.max(1));

    sqlx::query(
        r#"INSERT INTO password_reset_tokens (user_id, token_hash, expires_at)
           VALUES ($1, $2, $3)"#,
    )
    .bind(user.user_id)
    .bind(hash_token(&token))
    .bind(expires_at)
    .execute(&state.db)
    .await?;

    audit::record(
        &state.db,
        Some(user.user_id),
        None,
        "auth.password_reset_requested",
        "user",
        true,
        None,
        None,
    )
    .await;

    Ok(PasswordResetResponse {
        message: "if the account exists, a reset link has been issued".into(),
        // Never expose this in production; delivery is an operational concern (email).
        development_token: if state.settings.environment.is_production() {
            None
        } else {
            Some(token)
        },
    })
}

pub async fn confirm_reset(
    state: &AppState,
    request: PasswordResetConfirm,
) -> Result<(), AppError> {
    validate_password(&request.new_password)?;
    let token_hash = hash_token(&request.token);

    let mut tx = state.db.begin().await?;

    let row = sqlx::query_as::<_, (uuid::Uuid, uuid::Uuid)>(
        r#"SELECT token_id, user_id FROM password_reset_tokens
           WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now()
           FOR UPDATE"#,
    )
    .bind(&token_hash)
    .fetch_optional(&mut *tx)
    .await?;

    let Some((token_id, user_id)) = row else {
        return Err(AppError::BadRequest(
            "reset token is invalid or expired".into(),
        ));
    };

    let hash = hash_password(&request.new_password)?;

    sqlx::query("UPDATE users SET password_hash = $1, updated_at = now() WHERE user_id = $2")
        .bind(hash)
        .bind(user_id)
        .execute(&mut *tx)
        .await?;

    sqlx::query("UPDATE password_reset_tokens SET used_at = now() WHERE token_id = $1")
        .bind(token_id)
        .execute(&mut *tx)
        .await?;

    sqlx::query("UPDATE sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL")
        .bind(user_id)
        .execute(&mut *tx)
        .await?;

    sqlx::query(
        r#"UPDATE refresh_tokens SET revoked_at = now()
           WHERE revoked_at IS NULL
             AND session_id IN (SELECT session_id FROM sessions WHERE user_id = $1)"#,
    )
    .bind(user_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;

    audit::record(
        &state.db,
        Some(user_id),
        None,
        "auth.password_reset_completed",
        "user",
        true,
        None,
        None,
    )
    .await;

    Ok(())
}
