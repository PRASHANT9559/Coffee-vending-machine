use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::security::permissions::policy::has_project_permission;

/// Evaluates file access combining explicit ACL rules and project RBAC.
///
/// Security rule: Explicit DENY always overrides any GRANT!
pub async fn evaluate_file_access(
    pool: &PgPool,
    user_id: Uuid,
    file_id: Uuid,
    project_id: Uuid,
    action: &str,
) -> Result<bool, AppError> {
    // 1. Check if there is an explicit DENY on this file for this user
    let deny_key = format!("deny:{action}");
    let has_deny = sqlx::query_scalar!(
        r#"
        SELECT EXISTS(
            SELECT 1 FROM file_permissions
            WHERE file_id = $1
              AND subject_type = 'user'
              AND subject_id = $2
              AND permission_key = $3
        )
        "#,
        file_id,
        user_id,
        deny_key
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?
    .unwrap_or(false);

    if has_deny {
        return Ok(false);
    }

    // 2. Check if there is an explicit GRANT on this file for this user
    let has_explicit_grant = sqlx::query_scalar!(
        r#"
        SELECT EXISTS(
            SELECT 1 FROM file_permissions
            WHERE file_id = $1
              AND subject_type = 'user'
              AND subject_id = $2
              AND permission_key = $3
        )
        "#,
        file_id,
        user_id,
        action
    )
    .fetch_one(pool)
    .await
    .map_err(AppError::Database)?
    .unwrap_or(false);

    if has_explicit_grant {
        return Ok(true);
    }

    // 3. Fallback to project-level role permissions
    has_project_permission(pool, user_id, project_id, action).await
}
