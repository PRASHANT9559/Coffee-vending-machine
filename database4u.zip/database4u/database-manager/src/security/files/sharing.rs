use chrono::{DateTime, Duration, Utc};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::security::permissions::policy::require_project_permission;

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct FileShareInfo {
    pub share_id: Uuid,
    pub file_id: Uuid,
    pub project_id: Uuid,
    pub created_by: Option<Uuid>,
    pub max_downloads: Option<i32>,
    pub download_count: i32,
    pub expires_at: Option<DateTime<Utc>>,
    pub is_revoked: bool,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Serialize)]
pub struct CreatedShareResponse {
    pub share_id: Uuid,
    pub file_id: Uuid,
    pub raw_share_token: String,
    pub expires_at: Option<DateTime<Utc>>,
    pub max_downloads: Option<i32>,
}

#[derive(Debug, Deserialize)]
pub struct CreateShareRequest {
    pub max_downloads: Option<i32>,
    pub ttl_hours: Option<i64>,
}

/// Compute SHA-256 hash of a share token.
pub fn hash_share_token(token: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(token.trim().as_bytes());
    hex::encode(hasher.finalize())
}

/// Generate a 256-bit cryptographically secure random share token string.
pub fn generate_share_token() -> String {
    format!("shr_{}{}", Uuid::new_v4().simple(), Uuid::new_v4().simple())
}

/// Create a new public share link for a file. Returns the raw secret token once.
pub async fn create_share_link(
    pool: &PgPool,
    actor_id: Uuid,
    file_id: Uuid,
    project_id: Uuid,
    request: CreateShareRequest,
) -> Result<CreatedShareResponse, AppError> {
    require_project_permission(pool, actor_id, project_id, "file.share").await?;

    let raw_token = generate_share_token();
    let token_hash = hash_share_token(&raw_token);

    let expires_at = request.ttl_hours.map(|h| Utc::now() + Duration::hours(h.max(1)));
    let max_downloads = request.max_downloads.filter(|&m| m > 0);

    let share_id = sqlx::query_scalar::<_, Uuid>(
        r#"
        INSERT INTO file_shares (file_id, project_id, created_by, token_hash, max_downloads, expires_at, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW())
        RETURNING share_id
        "#,
    )
    .bind(file_id)
    .bind(project_id)
    .bind(actor_id)
    .bind(token_hash)
    .bind(max_downloads)
    .bind(expires_at)
    .fetch_one(pool)
    .await?;

    Ok(CreatedShareResponse {
        share_id,
        file_id,
        raw_share_token: raw_token,
        expires_at,
        max_downloads,
    })
}

/// Validate a public share token, enforce expiration and download count limit, and consume 1 download.
pub async fn validate_and_consume_share(
    pool: &PgPool,
    raw_token: &str,
) -> Result<Uuid, AppError> {
    let token_hash = hash_share_token(raw_token);

    let mut tx = pool.begin().await?;

    let row = sqlx::query_as::<_, FileShareInfo>(
        r#"
        SELECT share_id, file_id, project_id, created_by, max_downloads, download_count, expires_at, is_revoked, created_at
        FROM file_shares
        WHERE token_hash = $1
        FOR UPDATE
        "#,
    )
    .bind(token_hash)
    .fetch_optional(&mut *tx)
    .await?
    .ok_or_else(|| AppError::NotFound("invalid or nonexistent share token".into()))?;

    if row.is_revoked {
        return Err(AppError::NotFound("share link has been revoked".into()));
    }

    if let Some(exp) = row.expires_at {
        if Utc::now() > exp {
            return Err(AppError::BadRequest("share link has expired".into()));
        }
    }

    if let Some(max) = row.max_downloads {
        if row.download_count >= max {
            return Err(AppError::Conflict("download limit for this share link has been exceeded".into()));
        }
    }

    // Atomically increment download count
    sqlx::query(
        "UPDATE file_shares SET download_count = download_count + 1 WHERE share_id = $1",
    )
    .bind(row.share_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;

    Ok(row.file_id)
}

/// Revoke an active file share.
pub async fn revoke_share_link(
    pool: &PgPool,
    actor_id: Uuid,
    project_id: Uuid,
    share_id: Uuid,
) -> Result<(), AppError> {
    require_project_permission(pool, actor_id, project_id, "file.share").await?;

    let affected = sqlx::query(
        "UPDATE file_shares SET is_revoked = TRUE WHERE share_id = $1 AND project_id = $2",
    )
    .bind(share_id)
    .bind(project_id)
    .execute(pool)
    .await?
    .rows_affected();

    if affected == 0 {
        return Err(AppError::NotFound("share link not found".into()));
    }

    Ok(())
}

/// List active share links for a file.
pub async fn list_shares_for_file(
    pool: &PgPool,
    file_id: Uuid,
) -> Result<Vec<FileShareInfo>, AppError> {
    let rows = sqlx::query_as::<_, FileShareInfo>(
        r#"
        SELECT share_id, file_id, project_id, created_by, max_downloads, download_count, expires_at, is_revoked, created_at
        FROM file_shares
        WHERE file_id = $1
        ORDER BY created_at DESC
        "#,
    )
    .bind(file_id)
    .fetch_all(pool)
    .await?;

    Ok(rows)
}
