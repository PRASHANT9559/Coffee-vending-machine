use std::collections::HashSet;
use std::fmt;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::common::errors::AppError;

pub mod audit;
pub mod auth;
pub mod files;
pub mod permissions;
pub mod projects;
pub mod rate_limit;
pub mod roles;
pub mod security_events;
pub mod users;

/// Centralized security context for an authenticated actor within a request.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityContext {
    pub user_id: Uuid,
    pub session_id: Option<Uuid>,
    pub project_id: Option<Uuid>,
    pub roles: Vec<String>,
    pub permissions: HashSet<String>,
    pub is_system_admin: bool,
}

impl SecurityContext {
    pub fn new(user_id: Uuid) -> Self {
        Self {
            user_id,
            session_id: None,
            project_id: None,
            roles: Vec::new(),
            permissions: HashSet::new(),
            is_system_admin: false,
        }
    }

    pub fn with_project(mut self, project_id: Uuid) -> Self {
        self.project_id = Some(project_id);
        self
    }

    pub fn with_roles(mut self, roles: Vec<String>) -> Self {
        self.roles = roles;
        self
    }

    pub fn with_permissions(mut self, perms: HashSet<String>) -> Self {
        self.permissions = perms;
        self
    }

    pub fn has_permission(&self, perm: &str) -> bool {
        self.is_system_admin || self.permissions.contains(perm)
    }

    pub fn has_role(&self, role_name: &str) -> bool {
        self.is_system_admin || self.roles.iter().any(|r| r.eq_ignore_ascii_case(role_name))
    }
}

/// Strongly typed permission catalogue matching DB seed `014_seed_rbac.sql`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Permission {
    // Project
    ProjectRead,
    ProjectUpdate,
    ProjectDelete,
    ProjectMembersManage,

    // Connection
    ConnectionRead,
    ConnectionManage,
    ConnectionUse,

    // Database
    DatabaseRead,
    DatabaseWrite,
    DatabaseCreate,
    DatabaseDrop,

    // Schema
    SchemaRead,
    SchemaAlter,

    // Query
    QueryExecute,
    QueryExecuteReadonly,

    // File
    FileRead,
    FileUpload,
    FileDownload,
    FileUpdateMetadata,
    FileDelete,
    FileShare,

    // Audit
    AuditRead,
}

impl Permission {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::ProjectRead => "project.read",
            Self::ProjectUpdate => "project.update",
            Self::ProjectDelete => "project.delete",
            Self::ProjectMembersManage => "project.members.manage",

            Self::ConnectionRead => "connection.read",
            Self::ConnectionManage => "connection.manage",
            Self::ConnectionUse => "connection.use",

            Self::DatabaseRead => "database.read",
            Self::DatabaseWrite => "database.write",
            Self::DatabaseCreate => "database.create",
            Self::DatabaseDrop => "database.drop",

            Self::SchemaRead => "schema.read",
            Self::SchemaAlter => "schema.alter",

            Self::QueryExecute => "query.execute",
            Self::QueryExecuteReadonly => "query.execute.readonly",

            Self::FileRead => "file.read",
            Self::FileUpload => "file.upload",
            Self::FileDownload => "file.download",
            Self::FileUpdateMetadata => "file.update_metadata",
            Self::FileDelete => "file.delete",
            Self::FileShare => "file.share",

            Self::AuditRead => "audit.read",
        }
    }

    pub fn from_str(s: &str) -> Option<Self> {
        match s.trim() {
            "project.read" => Some(Self::ProjectRead),
            "project.update" => Some(Self::ProjectUpdate),
            "project.delete" => Some(Self::ProjectDelete),
            "project.members.manage" => Some(Self::ProjectMembersManage),

            "connection.read" => Some(Self::ConnectionRead),
            "connection.manage" => Some(Self::ConnectionManage),
            "connection.use" => Some(Self::ConnectionUse),

            "database.read" => Some(Self::DatabaseRead),
            "database.write" => Some(Self::DatabaseWrite),
            "database.create" => Some(Self::DatabaseCreate),
            "database.drop" => Some(Self::DatabaseDrop),

            "schema.read" => Some(Self::SchemaRead),
            "schema.alter" => Some(Self::SchemaAlter),

            "query.execute" => Some(Self::QueryExecute),
            "query.execute.readonly" => Some(Self::QueryExecuteReadonly),

            "file.read" => Some(Self::FileRead),
            "file.upload" => Some(Self::FileUpload),
            "file.download" => Some(Self::FileDownload),
            "file.update_metadata" => Some(Self::FileUpdateMetadata),
            "file.delete" => Some(Self::FileDelete),
            "file.share" => Some(Self::FileShare),

            "audit.read" => Some(Self::AuditRead),
            _ => None,
        }
    }
}

impl fmt::Display for Permission {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.as_str())
    }
}

/// Specific security errors designed to fail closed.
#[derive(Debug, thiserror::Error)]
pub enum SecurityError {
    #[error("unauthenticated: {0}")]
    Unauthenticated(String),

    #[error("forbidden: {0}")]
    Forbidden(String),

    #[error("session expired or revoked: {0}")]
    SessionExpired(String),

    #[error("user account is disabled: {0}")]
    AccountDisabled(String),

    #[error("rate limit exceeded: {0}")]
    RateLimited(String),

    #[error("resource not found: {0}")]
    NotFound(String),

    #[error("security policy failure: {0}")]
    FailClosed(String),
}

impl From<SecurityError> for AppError {
    fn from(err: SecurityError) -> Self {
        match err {
            SecurityError::Unauthenticated(msg) => AppError::Unauthorized(msg),
            SecurityError::Forbidden(msg) => AppError::Forbidden(msg),
            SecurityError::SessionExpired(msg) => AppError::Unauthorized(msg),
            SecurityError::AccountDisabled(msg) => AppError::Unauthorized(msg),
            SecurityError::RateLimited(msg) => AppError::RateLimited(msg),
            SecurityError::NotFound(msg) => AppError::NotFound(msg),
            SecurityError::FailClosed(msg) => AppError::Forbidden(msg),
        }
    }
}

/// Check if a field or key name indicates sensitive credential data.
pub fn is_sensitive_key(key: &str) -> bool {
    let lower = key.to_lowercase();
    lower.contains("password")
        || lower.contains("secret")
        || lower.contains("token")
        || lower.contains("private_key")
        || lower.contains("credential")
        || lower.contains("auth")
        || lower.contains("bearer")
        || lower.contains("encryption_key")
}

/// Recursively redact sensitive fields from a JSON structure before logging or auditing.
pub fn redact_secrets_in_json(val: &mut serde_json::Value) {
    match val {
        serde_json::Value::Object(map) => {
            for (k, v) in map.iter_mut() {
                if is_sensitive_key(k) {
                    *v = serde_json::Value::String("[REDACTED]".into());
                } else {
                    redact_secrets_in_json(v);
                }
            }
        }
        serde_json::Value::Array(arr) => {
            for item in arr.iter_mut() {
                redact_secrets_in_json(item);
            }
        }
        _ => {}
    }
}

/// Safely mask a string (e.g. key, token), showing only first 4 and last 4 characters.
pub fn mask_string(val: &str) -> String {
    if val.len() <= 8 {
        "[REDACTED]".to_string()
    } else {
        format!("{}...{}", &val[..4], &val[val.len() - 4..])
    }
}
