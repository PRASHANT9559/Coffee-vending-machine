use chrono::{DateTime, Utc};
use serde::Serialize;
use sqlx::{FromRow, PgPool};
use uuid::Uuid;

use crate::common::errors::AppError;

#[derive(Debug, Clone, FromRow)]
pub struct User {
    pub user_id: Uuid,
    pub username: String,
    pub password_hash: String,
    pub is_active: bool,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

/// Sanitized user shape safe to return over the API.
#[derive(Debug, Clone, Serialize)]
pub struct UserPublic {
    pub user_id: Uuid,
    pub username: String,
    pub is_active: bool,
    pub created_at: DateTime<Utc>,
}

impl From<User> for UserPublic {
    fn from(user: User) -> Self {
        Self {
            user_id: user.user_id,
            username: user.username,
            is_active: user.is_active,
            created_at: user.created_at,
        }
    }
}

pub async fn find_by_username(pool: &PgPool, username: &str) -> Result<Option<User>, AppError> {
    let user = sqlx::query_as::<_, User>(
        r#"SELECT user_id, username, password_hash, is_active, created_at, updated_at
           FROM users WHERE username = $1"#,
    )
    .bind(username)
    .fetch_optional(pool)
    .await?;
    Ok(user)
}

pub async fn find_by_id(pool: &PgPool, user_id: Uuid) -> Result<Option<User>, AppError> {
    let user = sqlx::query_as::<_, User>(
        r#"SELECT user_id, username, password_hash, is_active, created_at, updated_at
           FROM users WHERE user_id = $1"#,
    )
    .bind(user_id)
    .fetch_optional(pool)
    .await?;
    Ok(user)
}

pub async fn create(
    pool: &PgPool,
    username: &str,
    password_hash: &str,
) -> Result<User, AppError> {
    let user = sqlx::query_as::<_, User>(
        r#"INSERT INTO users (username, password_hash)
           VALUES ($1, $2)
           RETURNING user_id, username, password_hash, is_active, created_at, updated_at"#,
    )
    .bind(username)
    .bind(password_hash)
    .fetch_one(pool)
    .await
    .map_err(|e| match e {
        sqlx::Error::Database(db) if db.is_unique_violation() => {
            AppError::Conflict("username already exists".into())
        }
        other => AppError::Database(other),
    })?;
    Ok(user)
}

pub async fn update_password(
    pool: &PgPool,
    user_id: Uuid,
    password_hash: &str,
) -> Result<(), AppError> {
    let affected = sqlx::query(
        "UPDATE users SET password_hash = $1, updated_at = now() WHERE user_id = $2",
    )
    .bind(password_hash)
    .bind(user_id)
    .execute(pool)
    .await?
    .rows_affected();
    if affected == 0 {
        return Err(AppError::NotFound("user not found".into()));
    }
    Ok(())
}

pub async fn set_active(pool: &PgPool, user_id: Uuid, active: bool) -> Result<(), AppError> {
    let affected = sqlx::query(
        "UPDATE users SET is_active = $1, updated_at = now() WHERE user_id = $2",
    )
    .bind(active)
    .bind(user_id)
    .execute(pool)
    .await?
    .rows_affected();
    if affected == 0 {
        return Err(AppError::NotFound("user not found".into()));
    }
    Ok(())
}

pub async fn count_users(pool: &PgPool) -> Result<i64, AppError> {
    let count = sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM users")
        .fetch_one(pool)
        .await?;
    Ok(count)
}

pub async fn set_last_login(pool: &PgPool, user_id: Uuid) -> Result<(), AppError> {
    sqlx::query("UPDATE users SET last_login_at = now() WHERE user_id = $1")
        .bind(user_id)
        .execute(pool)
        .await?;
    Ok(())
}
