use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::security::permissions::policy::require_project_permission;

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ProjectMemberRecord {
    pub member_id: Uuid,
    pub project_id: Uuid,
    pub user_id: Uuid,
    pub role: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

/// Count active owners for a project.
pub async fn count_project_owners(pool: &PgPool, project_id: Uuid) -> Result<i64, AppError> {
    let count = sqlx::query_scalar::<_, i64>(
        r#"
        SELECT COUNT(DISTINCT pm.user_id)::BIGINT
        FROM project_members pm
        LEFT JOIN project_member_roles pmr ON pmr.project_id = pm.project_id AND pmr.user_id = pm.user_id
        LEFT JOIN roles r ON r.role_id = pmr.role_id
        WHERE pm.project_id = $1
          AND (pm.role = 'owner' OR r.role_name = 'owner')
        "#,
    )
    .bind(project_id)
    .fetch_one(pool)
    .await?;

    Ok(count)
}

/// Check if a user is currently an owner of the project.
pub async fn is_project_owner(
    pool: &PgPool,
    project_id: Uuid,
    user_id: Uuid,
) -> Result<bool, AppError> {
    let is_owner = sqlx::query_scalar::<_, bool>(
        r#"
        SELECT EXISTS(
            SELECT 1
            FROM project_members pm
            LEFT JOIN project_member_roles pmr ON pmr.project_id = pm.project_id AND pmr.user_id = pm.user_id
            LEFT JOIN roles r ON r.role_id = pmr.role_id
            WHERE pm.project_id = $1
              AND pm.user_id = $2
              AND (pm.role = 'owner' OR r.role_name = 'owner')
        )
        "#,
    )
    .bind(project_id)
    .bind(user_id)
    .fetch_one(pool)
    .await?;

    Ok(is_owner)
}

/// Add a new member to a project with role validation.
pub async fn add_member(
    pool: &PgPool,
    actor_id: Uuid,
    project_id: Uuid,
    target_user_id: Uuid,
    role_name: &str,
) -> Result<Uuid, AppError> {
    require_project_permission(pool, actor_id, project_id, "project.members.manage").await?;

    let role_id = sqlx::query_scalar::<_, Uuid>(
        "SELECT role_id FROM roles WHERE role_name = $1",
    )
    .bind(role_name)
    .fetch_optional(pool)
    .await?
    .ok_or_else(|| AppError::BadRequest(format!("invalid role: {role_name}")))?;

    let mut tx = pool.begin().await?;

    let member_id = sqlx::query_scalar::<_, Uuid>(
        r#"
        INSERT INTO project_members (project_id, user_id, role, created_at)
        VALUES ($1, $2, $3, NOW())
        ON CONFLICT (project_id, user_id)
        DO UPDATE SET role = EXCLUDED.role
        RETURNING member_id
        "#,
    )
    .bind(project_id)
    .bind(target_user_id)
    .bind(role_name)
    .fetch_one(&mut *tx)
    .await?;

    sqlx::query(
        r#"
        INSERT INTO project_member_roles (project_id, user_id, role_id)
        VALUES ($1, $2, $3)
        ON CONFLICT (project_id, user_id, role_id) DO NOTHING
        "#,
    )
    .bind(project_id)
    .bind(target_user_id)
    .bind(role_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;
    Ok(member_id)
}

/// Remove a member from a project while preventing orphan projects without an owner.
pub async fn remove_member(
    pool: &PgPool,
    actor_id: Uuid,
    project_id: Uuid,
    target_user_id: Uuid,
) -> Result<(), AppError> {
    require_project_permission(pool, actor_id, project_id, "project.members.manage").await?;

    // Check if the user being removed is an owner
    if is_project_owner(pool, project_id, target_user_id).await? {
        let owners_count = count_project_owners(pool, project_id).await?;
        if owners_count <= 1 {
            return Err(AppError::Conflict(
                "cannot remove the last owner of the project; transfer ownership first".into(),
            ));
        }
    }

    let mut tx = pool.begin().await?;

    sqlx::query(
        "DELETE FROM project_member_roles WHERE project_id = $1 AND user_id = $2",
    )
    .bind(project_id)
    .bind(target_user_id)
    .execute(&mut *tx)
    .await?;

    let affected = sqlx::query(
        "DELETE FROM project_members WHERE project_id = $1 AND user_id = $2",
    )
    .bind(project_id)
    .bind(target_user_id)
    .execute(&mut *tx)
    .await?
    .rows_affected();

    if affected == 0 {
        return Err(AppError::NotFound("member not found in project".into()));
    }

    tx.commit().await?;
    Ok(())
}

/// Update a member's role with last-owner safety checks.
pub async fn update_member_role(
    pool: &PgPool,
    actor_id: Uuid,
    project_id: Uuid,
    target_user_id: Uuid,
    new_role: &str,
) -> Result<(), AppError> {
    require_project_permission(pool, actor_id, project_id, "project.members.manage").await?;

    let role_id = sqlx::query_scalar::<_, Uuid>(
        "SELECT role_id FROM roles WHERE role_name = $1",
    )
    .bind(new_role)
    .fetch_optional(pool)
    .await?
    .ok_or_else(|| AppError::BadRequest(format!("invalid role: {new_role}")))?;

    // If demoting from owner to non-owner, ensure another owner exists
    if new_role != "owner" && is_project_owner(pool, project_id, target_user_id).await? {
        let owners_count = count_project_owners(pool, project_id).await?;
        if owners_count <= 1 {
            return Err(AppError::Conflict(
                "cannot demote the sole owner of the project".into(),
            ));
        }
    }

    let mut tx = pool.begin().await?;

    sqlx::query(
        "UPDATE project_members SET role = $3 WHERE project_id = $1 AND user_id = $2",
    )
    .bind(project_id)
    .bind(target_user_id)
    .bind(new_role)
    .execute(&mut *tx)
    .await?;

    sqlx::query(
        "DELETE FROM project_member_roles WHERE project_id = $1 AND user_id = $2",
    )
    .bind(project_id)
    .bind(target_user_id)
    .execute(&mut *tx)
    .await?;

    sqlx::query(
        "INSERT INTO project_member_roles (project_id, user_id, role_id) VALUES ($1, $2, $3)",
    )
    .bind(project_id)
    .bind(target_user_id)
    .bind(role_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;
    Ok(())
}
