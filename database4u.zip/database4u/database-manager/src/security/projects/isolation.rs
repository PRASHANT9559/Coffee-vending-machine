use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;
use crate::security::permissions::policy::{is_project_member, require_project_permission};

/// Strict multi-tenant project boundary enforcement.
///
/// Rule: Cross-project access attempts ALWAYS return 404 (Not Found), NEVER 403 (Forbidden),
/// to prevent resource enumeration and existence leaks.
pub struct ProjectScope;

impl ProjectScope {
    /// Verify that an actor is a member of the project and has the required permission.
    /// Non-members receive `AppError::NotFound` ("project not found").
    pub async fn enforce(
        pool: &PgPool,
        user_id: Uuid,
        project_id: Uuid,
        permission: &str,
    ) -> Result<(), AppError> {
        if !is_project_member(pool, user_id, project_id).await? {
            return Err(AppError::NotFound("project not found".into()));
        }

        require_project_permission(pool, user_id, project_id, permission).await
    }

    /// Verify that a connection belongs to the given project.
    pub async fn verify_connection_in_project(
        pool: &PgPool,
        project_id: Uuid,
        connection_id: Uuid,
    ) -> Result<(), AppError> {
        let is_linked = sqlx::query_scalar::<_, bool>(
            r#"
            SELECT EXISTS(
                SELECT 1 FROM project_connections
                WHERE project_id = $1 AND connection_id = $2
            )
            "#,
        )
        .bind(project_id)
        .bind(connection_id)
        .fetch_one(pool)
        .await?;

        if !is_linked {
            return Err(AppError::NotFound("connection not found in project".into()));
        }

        Ok(())
    }

    /// Verify that a database belongs to the given project.
    pub async fn verify_database_in_project(
        pool: &PgPool,
        project_id: Uuid,
        database_id: Uuid,
    ) -> Result<(), AppError> {
        let exists = sqlx::query_scalar::<_, bool>(
            r#"
            SELECT EXISTS(
                SELECT 1 FROM database_registry
                WHERE project_id = $1 AND database_id = $2
            )
            "#,
        )
        .bind(project_id)
        .bind(database_id)
        .fetch_one(pool)
        .await?;

        if !exists {
            return Err(AppError::NotFound("database not found in project".into()));
        }

        Ok(())
    }

    /// Verify that a file belongs to the given project.
    pub async fn verify_file_in_project(
        pool: &PgPool,
        project_id: Uuid,
        file_id: Uuid,
    ) -> Result<(), AppError> {
        let exists = sqlx::query_scalar::<_, bool>(
            r#"
            SELECT EXISTS(
                SELECT 1 FROM files
                WHERE project_id = $1 AND file_id = $2 AND deleted_at IS NULL
            )
            "#,
        )
        .bind(project_id)
        .bind(file_id)
        .fetch_one(pool)
        .await?;

        if !exists {
            return Err(AppError::NotFound("file not found in project".into()));
        }

        Ok(())
    }
}
