use sha2::{Digest, Sha256};
use std::collections::{HashMap, VecDeque};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use crate::common::errors::AppError;

/// Hash an IP address with SHA-256 to protect user privacy.
pub fn hash_ip(ip: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(ip.trim().as_bytes());
    hex::encode(hasher.finalize())
}

/// Small in-process sliding-window rate limiter with burst protection.
pub struct RateLimiter {
    windows: Mutex<HashMap<String, VecDeque<Instant>>>,
}

impl Default for RateLimiter {
    fn default() -> Self {
        Self::new()
    }
}

impl RateLimiter {
    pub fn new() -> Self {
        Self {
            windows: Mutex::new(HashMap::new()),
        }
    }

    /// Record an attempt. Returns `true` when the caller is still within budget.
    pub fn check(&self, key: &str, limit: usize, window: Duration) -> bool {
        let now = Instant::now();
        let mut guard = match self.windows.lock() {
            Ok(guard) => guard,
            // A poisoned lock fails closed.
            Err(_) => return false,
        };

        // Opportunistic pruning keeps memory bounded for long-running processes.
        if guard.len() > 10_000 {
            guard.retain(|_, entries| entries.back().map(|t| now.duration_since(*t) < window).unwrap_or(false));
        }

        let entries = guard.entry(key.to_string()).or_default();
        while let Some(front) = entries.front() {
            if now.duration_since(*front) >= window {
                entries.pop_front();
            } else {
                break;
            }
        }

        if entries.len() >= limit {
            return false;
        }
        entries.push_back(now);
        true
    }

    pub fn reset(&self, key: &str) {
        if let Ok(mut guard) = self.windows.lock() {
            guard.remove(key);
        }
    }

    /// Check login rate limits: 5 attempts per 5 minutes per IP and per username.
    pub fn check_login(&self, ip: &str, username: &str) -> Result<(), AppError> {
        let ip_key = format!("login:ip:{}", hash_ip(ip));
        let user_key = format!("login:user:{}", username.trim().to_lowercase());
        let window = Duration::from_secs(300); // 5 min

        if !self.check(&ip_key, 5, window) {
            return Err(AppError::RateLimited("too many login attempts from this IP; retry after 5 minutes".into()));
        }

        if !self.check(&user_key, 5, window) {
            return Err(AppError::RateLimited("too many login attempts for this user; retry after 5 minutes".into()));
        }

        Ok(())
    }

    /// Check password reset limit: 3 attempts per hour.
    pub fn check_password_reset(&self, identity: &str) -> Result<(), AppError> {
        let key = format!("pwreset:{}", identity.trim().to_lowercase());
        let window = Duration::from_secs(3600); // 1 hour

        if !self.check(&key, 3, window) {
            return Err(AppError::RateLimited("too many password reset requests; retry after 1 hour".into()));
        }

        Ok(())
    }

    /// Check token refresh limit: 30 attempts per minute per session.
    pub fn check_refresh(&self, session_id: &str) -> Result<(), AppError> {
        let key = format!("refresh:{}", session_id);
        let window = Duration::from_secs(60);

        if !self.check(&key, 30, window) {
            return Err(AppError::RateLimited("token refresh rate limit exceeded".into()));
        }

        Ok(())
    }

    /// Check query execution rate limit: 60 queries per minute per user.
    pub fn check_query_execution(&self, user_id: &str) -> Result<(), AppError> {
        let key = format!("query:{}", user_id);
        let window = Duration::from_secs(60);

        if !self.check(&key, 60, window) {
            return Err(AppError::RateLimited("query execution rate limit exceeded".into()));
        }

        Ok(())
    }

    /// Check upload session creation rate limit: 10 per minute per user.
    pub fn check_upload_creation(&self, user_id: &str) -> Result<(), AppError> {
        let key = format!("upload:{}", user_id);
        let window = Duration::from_secs(60);

        if !self.check(&key, 10, window) {
            return Err(AppError::RateLimited("upload session creation rate limit exceeded".into()));
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn blocks_after_limit() {
        let limiter = RateLimiter::new();
        let window = Duration::from_secs(60);
        for _ in 0..3 {
            assert!(limiter.check("login:1.2.3.4", 3, window));
        }
        assert!(!limiter.check("login:1.2.3.4", 3, window));
    }

    #[test]
    fn separate_keys_are_independent() {
        let limiter = RateLimiter::new();
        let window = Duration::from_secs(60);
        assert!(limiter.check("a", 1, window));
        assert!(limiter.check("b", 1, window));
        assert!(!limiter.check("a", 1, window));
    }

    #[test]
    fn test_login_policy_enforcement() {
        let limiter = RateLimiter::new();
        for _ in 0..5 {
            assert!(limiter.check_login("192.168.1.1", "alice").is_ok());
        }
        assert!(limiter.check_login("192.168.1.1", "alice").is_err());
    }
}
