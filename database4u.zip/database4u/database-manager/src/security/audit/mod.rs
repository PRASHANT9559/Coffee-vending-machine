use sqlx::PgPool;
use uuid::Uuid;

/// Append a sanitized audit record.
///
/// Failures are logged and swallowed: auditing must never break a business operation,
/// but sensitive fields are never passed in here in the first place.
pub async fn record(
    pool: &PgPool,
    user_id: Option<Uuid>,
    project_id: Option<Uuid>,
    action: &str,
    resource: &str,
    success: bool,
    request_id: Option<Uuid>,
    duration_ms: Option<i32>,
) {
    let status = if success { "success" } else { "failure" };

    if let Err(error) = sqlx::query(
        r#"INSERT INTO audit_logs
             (user_id, project_id, action, target_resource, status, request_id, duration_ms)
           VALUES ($1, $2, $3, $4, $5, $6, $7)"#,
    )
    .bind(user_id)
    .bind(project_id)
    .bind(action)
    .bind(resource)
    .bind(status)
    .bind(request_id)
    .bind(duration_ms)
    .execute(pool)
    .await
    {
        tracing::warn!(action, error = %error, "failed to write audit log");
    }
}

/// Audit with a connection id attached.
pub async fn record_connection(
    pool: &PgPool,
    user_id: Option<Uuid>,
    project_id: Option<Uuid>,
    connection_id: Option<Uuid>,
    action: &str,
    success: bool,
) {
    let status = if success { "success" } else { "failure" };
    if let Err(error) = sqlx::query(
        r#"INSERT INTO audit_logs
             (user_id, project_id, connection_id, action, target_resource, status)
           VALUES ($1, $2, $3, $4, 'connection', $5)"#,
    )
    .bind(user_id)
    .bind(project_id)
    .bind(connection_id)
    .bind(action)
    .bind(status)
    .execute(pool)
    .await
    {
        tracing::warn!(action, error = %error, "failed to write connection audit log");
    }
}
