use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;

/// Resource identifier for fine-grained authorization.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Resource {
    Project(Uuid),
    Connection(Uuid),
    Database(Uuid),
    Table { database_id: Uuid, name: String },
    File(Uuid),
}

/// Authorization decision.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Decision {
    Allow,
    Deny(String),
}

impl Decision {
    pub fn is_allowed(&self) -> bool {
        matches!(self, Self::Allow)
    }

    pub fn to_result(&self) -> Result<(), AppError> {
        match self {
            Self::Allow => Ok(()),
            Self::Deny(reason) => Err(AppError::Forbidden(reason.clone())),
        }
    }
}

/// Is the user an active, non-disabled user?
pub async fn is_user_active(pool: &PgPool, user_id: Uuid) -> Result<bool, AppError> {
    let active = sqlx::query_scalar::<_, bool>(
        "SELECT is_active FROM users WHERE user_id = $1",
    )
    .bind(user_id)
    .fetch_optional(pool)
    .await?
    .unwrap_or(false);

    Ok(active)
}

/// Is the user a member of the project at all?
pub async fn is_project_member(
    pool: &PgPool,
    user_id: Uuid,
    project_id: Uuid,
) -> Result<bool, AppError> {
    let exists = sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS(SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2)",
    )
    .bind(project_id)
    .bind(user_id)
    .fetch_one(pool)
    .await?;
    Ok(exists)
}

/// Resolve a permission through the user's project roles.
///
/// Supports both the normalized `project_member_roles` mapping and the legacy
/// `project_members.role` text column so migrations cannot silently lock users out.
pub async fn has_project_permission(
    pool: &PgPool,
    user_id: Uuid,
    project_id: Uuid,
    permission_key: &str,
) -> Result<bool, AppError> {
    let granted = sqlx::query_scalar::<_, bool>(
        r#"
        SELECT EXISTS(
            SELECT 1
            FROM project_members pm
            JOIN role_permissions rp ON rp.role_id = ANY(
                SELECT pmr.role_id FROM project_member_roles pmr
                WHERE pmr.project_id = pm.project_id AND pmr.user_id = pm.user_id
                UNION
                SELECT r.role_id FROM roles r WHERE r.role_name = pm.role
            )
            JOIN permissions p ON p.permission_id = rp.permission_id
            WHERE pm.project_id = $1
              AND pm.user_id = $2
              AND p.permission_key = $3
        )
        "#,
    )
    .bind(project_id)
    .bind(user_id)
    .bind(permission_key)
    .fetch_one(pool)
    .await?;

    Ok(granted)
}

/// Authorize an action inside a project.
///
/// Non-members receive `NotFound` so resource existence never leaks across projects.
/// Members missing the permission receive `Forbidden`.
pub async fn require_project_permission(
    pool: &PgPool,
    user_id: Uuid,
    project_id: Uuid,
    permission_key: &str,
) -> Result<(), AppError> {
    if !is_user_active(pool, user_id).await? {
        return Err(AppError::Unauthorized("user account is inactive or disabled".into()));
    }

    if !is_project_member(pool, user_id, project_id).await? {
        return Err(AppError::NotFound("project not found".into()));
    }
    if !has_project_permission(pool, user_id, project_id, permission_key).await? {
        return Err(AppError::Forbidden(format!(
            "missing permission: {permission_key}"
        )));
    }
    Ok(())
}

/// List effective permission keys for a user inside a project.
pub async fn effective_permissions(
    pool: &PgPool,
    user_id: Uuid,
    project_id: Uuid,
) -> Result<Vec<String>, AppError> {
    let rows = sqlx::query_scalar::<_, String>(
        r#"
        SELECT DISTINCT p.permission_key
        FROM project_members pm
        JOIN role_permissions rp ON rp.role_id = ANY(
            SELECT pmr.role_id FROM project_member_roles pmr
            WHERE pmr.project_id = pm.project_id AND pmr.user_id = pm.user_id
            UNION
            SELECT r.role_id FROM roles r WHERE r.role_name = pm.role
        )
        JOIN permissions p ON p.permission_id = rp.permission_id
        WHERE pm.project_id = $1 AND pm.user_id = $2
        ORDER BY p.permission_key
        "#,
    )
    .bind(project_id)
    .bind(user_id)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

/// Resolve the project_id owning a given resource directly from database records.
/// Server never trusts client-supplied project claims.
pub async fn resolve_resource_project(
    pool: &PgPool,
    resource: &Resource,
) -> Result<Option<Uuid>, AppError> {
    match resource {
        Resource::Project(id) => {
            let exists = sqlx::query_scalar::<_, bool>(
                "SELECT EXISTS(SELECT 1 FROM projects WHERE project_id = $1 AND archived_at IS NULL)",
            )
            .bind(id)
            .fetch_one(pool)
            .await?;
            if exists {
                Ok(Some(*id))
            } else {
                Ok(None)
            }
        }
        Resource::Connection(conn_id) => {
            // First check project_connections mapping
            let proj_id = sqlx::query_scalar::<_, Uuid>(
                "SELECT project_id FROM project_connections WHERE connection_id = $1 LIMIT 1",
            )
            .bind(conn_id)
            .fetch_optional(pool)
            .await?;

            if proj_id.is_some() {
                return Ok(proj_id);
            }

            // Fallback to connection owner's project if any
            let owner_proj = sqlx::query_scalar::<_, Option<Uuid>>(
                "SELECT project_id FROM connection_configs WHERE connection_id = $1",
            )
            .bind(conn_id)
            .fetch_optional(pool)
            .await?
            .flatten();

            Ok(owner_proj)
        }
        Resource::Database(db_id) => {
            let proj_id = sqlx::query_scalar::<_, Option<Uuid>>(
                "SELECT project_id FROM database_registry WHERE database_id = $1",
            )
            .bind(db_id)
            .fetch_optional(pool)
            .await?
            .flatten();
            Ok(proj_id)
        }
        Resource::Table { database_id, .. } => {
            let proj_id = sqlx::query_scalar::<_, Option<Uuid>>(
                "SELECT project_id FROM database_registry WHERE database_id = $1",
            )
            .bind(database_id)
            .fetch_optional(pool)
            .await?
            .flatten();
            Ok(proj_id)
        }
        Resource::File(file_id) => {
            let proj_id = sqlx::query_scalar::<_, Uuid>(
                "SELECT project_id FROM files WHERE file_id = $1 AND deleted_at IS NULL",
            )
            .bind(file_id)
            .fetch_optional(pool)
            .await?;
            Ok(proj_id)
        }
    }
}

/// Central evaluation engine for RBAC & ABAC policy decisions.
///
/// Order of evaluation:
/// 1. User is active?
/// 2. Resolve target resource's true project_id from DB
/// 3. User is member of the project?
/// 4. Role -> permission evaluation
/// 5. Resource-level ACL (files)
/// 6. Default DENY (fail closed)
pub async fn authorize(
    pool: &PgPool,
    user_id: Uuid,
    resource: &Resource,
    action: &str,
) -> Result<Decision, AppError> {
    // 1. User active check
    if !is_user_active(pool, user_id).await? {
        return Ok(Decision::Deny("user account is inactive or disabled".into()));
    }

    // 2. Resolve project_id strictly from database
    let project_id = match resolve_resource_project(pool, resource).await? {
        Some(pid) => pid,
        None => return Ok(Decision::Deny("resource not found".into())),
    };

    // 3. Project membership check
    if !is_project_member(pool, user_id, project_id).await? {
        return Ok(Decision::Deny("project not found or not a member".into()));
    }

    // 4. Role -> permission check
    if has_project_permission(pool, user_id, project_id, action).await? {
        return Ok(Decision::Allow);
    }

    // 5. File ACL check
    if let Resource::File(file_id) = resource {
        let has_acl = sqlx::query_scalar!(
            r#"
            SELECT EXISTS(
                SELECT 1 FROM file_permissions
                WHERE file_id = $1 AND subject_type = 'user' AND subject_id = $2 AND permission_key = $3
            )
            "#,
            file_id,
            user_id,
            action
        )
        .fetch_one(pool)
        .await
        .map_err(AppError::Database)?
        .unwrap_or(false);

        if has_acl {
            return Ok(Decision::Allow);
        }
    }

    // 6. Default deny
    Ok(Decision::Deny(format!("insufficient permissions for action '{action}'")))
}
