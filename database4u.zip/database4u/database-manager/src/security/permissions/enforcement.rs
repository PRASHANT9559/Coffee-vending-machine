//! Enforcement helpers.
//!
//! The canonical decision lives in [`super::policy`]. This module only exposes a thin
//! ergonomic wrapper so handlers and background jobs call the exact same code path.

use sqlx::PgPool;
use uuid::Uuid;

use crate::common::errors::AppError;

pub struct ProjectGuard<'a> {
    pub pool: &'a PgPool,
    pub user_id: Uuid,
    pub project_id: Uuid,
}

impl<'a> ProjectGuard<'a> {
    pub fn new(pool: &'a PgPool, user_id: Uuid, project_id: Uuid) -> Self {
        Self {
            pool,
            user_id,
            project_id,
        }
    }

    pub async fn require(&self, permission: &str) -> Result<(), AppError> {
        super::policy::require_project_permission(
            self.pool,
            self.user_id,
            self.project_id,
            permission,
        )
        .await
    }

    pub async fn is_member(&self) -> Result<bool, AppError> {
        super::policy::is_project_member(self.pool, self.user_id, self.project_id).await
    }
}
