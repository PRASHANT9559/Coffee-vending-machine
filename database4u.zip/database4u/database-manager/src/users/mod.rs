use axum::extract::State;
use axum::Json;

use crate::api::middleware::AuthUser;
use crate::api::response::{Ack, ApiResponse};
use crate::app_state::AppState;
use crate::common::errors::AppError;
use crate::security::auth::login::{self, ChangePasswordRequest};
use crate::security::users::UserPublic;

pub async fn me(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<Json<ApiResponse<UserPublic>>, AppError> {
    let user = crate::security::users::find_by_id(&state.db, user.user_id)
        .await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;
    Ok(Json(ApiResponse::ok(UserPublic::from(user))))
}

pub async fn change_password(
    State(state): State<AppState>,
    user: AuthUser,
    Json(request): Json<ChangePasswordRequest>,
) -> Result<Json<ApiResponse<Ack>>, AppError> {
    login::change_password(&state, user.user_id, request).await?;
    Ok(Json(ApiResponse::ok(Ack::new(
        "password changed; all sessions revoked",
    ))))
}
