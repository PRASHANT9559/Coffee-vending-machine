#[cfg(test)]
mod tests {
    use crate::common::validation::{validate_password, validate_username};
    use crate::security::auth::login::{hash_password, verify_password};
    use crate::security::files::sharing::{generate_share_token, hash_share_token};
    use crate::security::rate_limit::{hash_ip, RateLimiter};
    use crate::security::{is_sensitive_key, mask_string, redact_secrets_in_json, Permission, SecurityContext, SecurityError};
    use std::collections::HashSet;
    use std::time::Duration;
    use uuid::Uuid;

    #[test]
    fn test_password_policy_validation() {
        assert!(validate_password("Short1!").is_err());
        assert!(validate_password("alllowercase123!").is_err());
        assert!(validate_password("ALLUPPERCASE123!").is_err());
        assert!(validate_password("NoSpecialChars123").is_err());
        assert!(validate_password("ValidPassword123!").is_ok());
    }

    #[test]
    fn test_username_validation() {
        assert!(validate_username("ab").is_err());
        assert!(validate_username("user with spaces").is_err());
        assert!(validate_username("valid_user-123").is_ok());
    }

    #[test]
    fn test_argon2id_hash_and_verify() {
        let password = "SuperSecretPassword123#";
        let hash = hash_password(password).expect("hashing should succeed");

        assert!(hash.starts_with("$argon2id$"));
        assert!(verify_password(password, &hash).expect("verify should succeed"));
        assert!(!verify_password("WrongPassword123#", &hash).expect("verify should return false"));
    }

    #[test]
    fn test_permission_enum_roundtrip() {
        let perms = [
            Permission::ProjectRead,
            Permission::ProjectUpdate,
            Permission::ProjectDelete,
            Permission::ProjectMembersManage,
            Permission::ConnectionRead,
            Permission::ConnectionManage,
            Permission::ConnectionUse,
            Permission::DatabaseRead,
            Permission::DatabaseWrite,
            Permission::DatabaseCreate,
            Permission::DatabaseDrop,
            Permission::SchemaRead,
            Permission::SchemaAlter,
            Permission::QueryExecute,
            Permission::QueryExecuteReadonly,
            Permission::FileRead,
            Permission::FileUpload,
            Permission::FileDownload,
            Permission::FileUpdateMetadata,
            Permission::FileDelete,
            Permission::FileShare,
            Permission::AuditRead,
        ];

        for perm in perms {
            let s = perm.as_str();
            let parsed = Permission::from_str(s).expect("should parse successfully");
            assert_eq!(parsed, perm);
        }

        assert!(Permission::from_str("invalid.permission").is_none());
    }

    #[test]
    fn test_security_context_permissions() {
        let user_id = Uuid::new_v4();
        let mut perms = HashSet::new();
        perms.insert("file.read".to_string());
        perms.insert("file.download".to_string());

        let ctx = SecurityContext::new(user_id)
            .with_roles(vec!["viewer".to_string()])
            .with_permissions(perms);

        assert!(ctx.has_permission("file.read"));
        assert!(ctx.has_permission("file.download"));
        assert!(!ctx.has_permission("file.delete"));
        assert!(ctx.has_role("viewer"));
        assert!(!ctx.has_role("owner"));
    }

    #[test]
    fn test_secret_redaction_and_masking() {
        assert!(is_sensitive_key("password"));
        assert!(is_sensitive_key("user_secret"));
        assert!(is_sensitive_key("bearer_token"));
        assert!(is_sensitive_key("master_encryption_key"));
        assert!(!is_sensitive_key("username"));
        assert!(!is_sensitive_key("created_at"));

        let mut payload = serde_json::json!({
            "username": "alice",
            "password": "secret_password",
            "nested": {
                "token": "sensitive_jwt_token",
                "normal_field": "visible"
            }
        });

        redact_secrets_in_json(&mut payload);
        assert_eq!(payload["username"], "alice");
        assert_eq!(payload["password"], "[REDACTED]");
        assert_eq!(payload["nested"]["token"], "[REDACTED]");
        assert_eq!(payload["nested"]["normal_field"], "visible");

        assert_eq!(mask_string("1234567890abcdef"), "1234...cdef");
        assert_eq!(mask_string("short"), "[REDACTED]");
    }

    #[test]
    fn test_share_token_generation_and_hashing() {
        let token1 = generate_share_token();
        let token2 = generate_share_token();
        assert_ne!(token1, token2);
        assert!(token1.starts_with("shr_"));

        let hash1 = hash_share_token(&token1);
        let hash2 = hash_share_token(&token1);
        assert_eq!(hash1, hash2);
        assert_eq!(hash1.len(), 64);
    }

    #[test]
    fn test_ip_hashing_privacy() {
        let ip = "192.168.1.100";
        let h1 = hash_ip(ip);
        let h2 = hash_ip(ip);
        assert_eq!(h1, h2);
        assert_ne!(h1, ip);
        assert_eq!(h1.len(), 64);
    }

    #[test]
    fn test_rate_limiter_sliding_window() {
        let limiter = RateLimiter::new();
        let window = Duration::from_millis(50);

        assert!(limiter.check("key", 2, window));
        assert!(limiter.check("key", 2, window));
        assert!(!limiter.check("key", 2, window));

        std::thread::sleep(Duration::from_millis(60));
        assert!(limiter.check("key", 2, window));
    }
}
