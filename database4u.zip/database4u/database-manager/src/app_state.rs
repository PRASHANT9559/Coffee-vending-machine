use std::sync::Arc;

use sqlx::PgPool;

use crate::config::Settings;
use crate::connections::pool::manager::PoolManager;
use crate::files::storage::StorageAdapter;
use crate::infrastructure::encryption::CryptoEngine;
use crate::realtime::EventBus;
use crate::security::rate_limit::RateLimiter;

/// Shared state injected into every handler.
#[derive(Clone)]
pub struct AppState {
    pub db: PgPool,
    pub settings: Arc<Settings>,
    pub crypto: Arc<CryptoEngine>,
    pub rate_limiter: Arc<RateLimiter>,
    pub pools: Arc<PoolManager>,
    pub bus: Arc<EventBus>,
    pub storage: Arc<dyn StorageAdapter>,
}

impl AppState {
    pub fn new(
        db: PgPool,
        settings: Arc<Settings>,
        crypto: Arc<CryptoEngine>,
        pools: Arc<PoolManager>,
        storage: Arc<dyn StorageAdapter>,
    ) -> Self {
        Self {
            db,
            settings,
            crypto,
            rate_limiter: Arc::new(RateLimiter::new()),
            pools,
            bus: Arc::new(EventBus::new()),
            storage,
        }
    }
}
