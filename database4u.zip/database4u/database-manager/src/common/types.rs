use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::common::errors::AppError;

/// Simple page/limit query parameters.
#[derive(Debug, Clone, Copy, Deserialize)]
pub struct Pagination {
    pub page: Option<i64>,
    pub limit: Option<i64>,
}

impl Default for Pagination {
    fn default() -> Self {
        Self {
            page: None,
            limit: None,
        }
    }
}

impl Pagination {
    /// Resolve into `(limit, offset)` clamped to sane bounds.
    pub fn resolve(&self, default_limit: i64, max_limit: i64) -> (i64, i64) {
        let limit = self.limit.unwrap_or(default_limit).clamp(1, max_limit);
        let page = self.page.unwrap_or(1).max(1);
        (limit, (page - 1) * limit)
    }

    pub fn page(&self) -> i64 {
        self.page.unwrap_or(1).max(1)
    }
}

#[derive(Debug, Clone, Copy, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum SortOrder {
    Asc,
    Desc,
}

impl Default for SortOrder {
    fn default() -> Self {
        Self::Asc
    }
}

impl SortOrder {
    pub fn as_sql(&self) -> &'static str {
        match self {
            Self::Asc => "ASC",
            Self::Desc => "DESC",
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct Page<T> {
    pub items: Vec<T>,
    pub total: i64,
    pub page: i64,
    pub limit: i64,
    pub has_more: bool,
}

impl<T> Page<T> {
    pub fn new(items: Vec<T>, total: i64, page: i64, limit: i64) -> Self {
        let has_more = page * limit < total;
        Self {
            items,
            total,
            page,
            limit,
            has_more,
        }
    }
}

/// Pagination/sort/filter parameters shared by list endpoints.
#[derive(Debug, Clone, Copy, Deserialize)]
pub struct ListQuery {
    #[serde(flatten)]
    pub pagination: Pagination,
    pub sort: Option<String>,
    pub order: Option<SortOrder>,
}

impl ListQuery {
    pub fn ascending(&self) -> bool {
        self.order.unwrap_or_default() == SortOrder::Asc
    }
}

/// Convert a domain row into a coarse audit status string.
pub fn audit_status(ok: bool) -> &'static str {
    if ok {
        "success"
    } else {
        "failure"
    }
}

/// Request metadata captured for auditing and sessions.
#[derive(Debug, Clone, Default)]
pub struct RequestMeta {
    pub user_agent: Option<String>,
    pub ip_hash: Option<String>,
}

impl RequestMeta {
    pub fn from_headers(headers: &axum::http::HeaderMap) -> Self {
        let user_agent = headers
            .get(axum::http::header::USER_AGENT)
            .and_then(|v| v.to_str().ok())
            .map(|v| v.chars().take(255).collect::<String>());

        // The proxy sets X-Real-IP. We never persist raw IPs: only a truncated hash.
        let ip_hash = headers
            .get("x-real-ip")
            .and_then(|v| v.to_str().ok())
            .map(hash_ip);

        Self { user_agent, ip_hash }
    }
}

fn hash_ip(ip: &str) -> String {
    use sha2::{Digest, Sha256};
    let digest = Sha256::digest(ip.trim().as_bytes());
    hex::encode(&digest[..8])
}

/// Basic request timestamp helper.
pub fn now() -> DateTime<Utc> {
    Utc::now()
}

/// Map `sqlx::RowNotFound` style errors to a 404 without leaking internals.
pub fn not_found(resource: &str) -> AppError {
    AppError::NotFound(format!("{resource} not found"))
}
