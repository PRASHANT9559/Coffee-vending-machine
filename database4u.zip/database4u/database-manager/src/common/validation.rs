use crate::common::errors::AppError;

/// SQL identifiers (table/column/database names) can never be bound as parameters.
/// They must be validated against a strict allowlist and then safely quoted.
const MAX_IDENTIFIER_LEN: usize = 63;

pub fn validate_identifier(raw: &str) -> Result<&str, AppError> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Err(AppError::Validation("identifier must not be empty".into()));
    }
    if trimmed.len() > MAX_IDENTIFIER_LEN {
        return Err(AppError::Validation(format!(
            "identifier exceeds {MAX_IDENTIFIER_LEN} characters"
        )));
    }
    let mut chars = trimmed.chars();
    let first = chars.next().unwrap();
    if !(first.is_ascii_alphabetic() || first == '_') {
        return Err(AppError::Validation(
            "identifier must start with a letter or underscore".into(),
        ));
    }
    if !chars.all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Err(AppError::Validation(
            "identifier may only contain letters, digits and underscores".into(),
        ));
    }
    Ok(trimmed)
}

/// Validate then double-quote an identifier for safe interpolation.
/// Quoting makes reserved words safe, so no reserved-word blocklist is needed.
pub fn quote_identifier(raw: &str) -> Result<String, AppError> {
    let valid = validate_identifier(raw)?;
    Ok(format!("\"{}\"", valid.replace('"', "\"\"")))
}

/// `schema.table` helper used by the record/schema engines.
pub fn quote_qualified(schema: &str, table: &str) -> Result<String, AppError> {
    Ok(format!(
        "{}.{}",
        quote_identifier(schema)?,
        quote_identifier(table)?
    ))
}

pub fn validate_username(raw: &str) -> Result<&str, AppError> {
    let trimmed = raw.trim();
    if trimmed.len() < 3 || trimmed.len() > 64 {
        return Err(AppError::Validation(
            "username must be between 3 and 64 characters".into(),
        ));
    }
    if !trimmed
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | '.' | '-' | '@'))
    {
        return Err(AppError::Validation(
            "username contains unsupported characters".into(),
        ));
    }
    Ok(trimmed)
}

pub fn validate_password(raw: &str) -> Result<(), AppError> {
    if raw.len() < 12 {
        return Err(AppError::Validation(
            "password must be at least 12 characters".into(),
        ));
    }
    if raw.len() > 128 {
        return Err(AppError::Validation(
            "password must be at most 128 characters".into(),
        ));
    }
    if raw.trim().is_empty() {
        return Err(AppError::Validation("password must not be blank".into()));
    }
    Ok(())
}

pub fn validate_display_name(raw: &str, max: usize) -> Result<String, AppError> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Err(AppError::Validation("name must not be empty".into()));
    }
    if trimmed.chars().count() > max {
        return Err(AppError::Validation(format!(
            "name exceeds {max} characters"
        )));
    }
    Ok(trimmed.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn accepts_simple_identifiers() {
        assert!(validate_identifier("orders").is_ok());
        assert!(validate_identifier("_internal_1").is_ok());
    }

    #[test]
    fn rejects_injection_attempts() {
        assert!(validate_identifier("users; DROP TABLE users").is_err());
        assert!(validate_identifier("a\"b").is_err());
        assert!(validate_identifier("1abc").is_err());
        assert!(validate_identifier("").is_err());
    }

    #[test]
    fn quotes_safely() {
        assert_eq!(quote_identifier("orders").unwrap(), "\"orders\"");
        assert_eq!(quote_qualified("public", "orders").unwrap(), "\"public\".\"orders\"");
    }

    #[test]
    fn password_policy() {
        assert!(validate_password("short").is_err());
        assert!(validate_password("correct-horse-battery").is_ok());
    }
}
