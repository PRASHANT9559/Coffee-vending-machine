use chacha20poly1305::{
    aead::{Aead, KeyInit, OsRng},
    XChaCha20Poly1305, XNonce,
};
use secrecy::{ExposeSecret, SecretString};
use thiserror::Error;
use zeroize::{Zeroize, Zeroizing};

pub const KEY_SIZE: usize = 32;
pub const NONCE_SIZE: usize = 24;

#[derive(Error, Debug)]
pub enum EncryptionError {
    #[error("Invalid key length: expected {KEY_SIZE} bytes, got {0}")]
    InvalidKeyLength(usize),
    #[error("Invalid nonce length: expected {NONCE_SIZE} bytes, got {0}")]
    InvalidNonceLength(usize),
    #[error("Failed to decode hex key: {0}")]
    HexDecodeError(String),
    #[error("Encryption failed: {0}")]
    EncryptionFailed(String),
    #[error("Decryption failed (integrity check or invalid key/nonce): {0}")]
    DecryptionFailed(String),
    #[error("UTF-8 decoding error: {0}")]
    Utf8Error(#[from] std::string::FromUtf8Error),
}

/// Represents encrypted ciphertext together with its unique 192-bit nonce.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EncryptedPayload {
    pub ciphertext: Vec<u8>,
    pub nonce: [u8; NONCE_SIZE],
}

/// Core cryptographic engine using XChaCha20-Poly1305 AEAD.
#[derive(Clone)]
pub struct CryptoEngine {
    cipher: XChaCha20Poly1305,
}

impl CryptoEngine {
    /// Create a new engine from a 32-byte secret key.
    pub fn new(key: &[u8; KEY_SIZE]) -> Self {
        let cipher = XChaCha20Poly1305::new(key.into());
        Self { cipher }
    }

    /// Create an engine from a 64-character hexadecimal string.
    pub fn from_hex_key(hex_key: &str) -> Result<Self, EncryptionError> {
        let bytes = hex_to_bytes(hex_key)?;
        if bytes.len() != KEY_SIZE {
            return Err(EncryptionError::InvalidKeyLength(bytes.len()));
        }
        let mut key_arr = [0u8; KEY_SIZE];
        key_arr.copy_from_slice(&bytes);
        let engine = Self::new(&key_arr);
        key_arr.zeroize();
        Ok(engine)
    }

    /// Generate a cryptographically secure random 32-byte master key.
    pub fn generate_key() -> Zeroizing<[u8; KEY_SIZE]> {
        let key = XChaCha20Poly1305::generate_key(&mut OsRng);
        let mut arr = [0u8; KEY_SIZE];
        arr.copy_from_slice(key.as_slice());
        Zeroizing::new(arr)
    }

    /// Encrypt arbitrary bytes with a freshly generated random 24-byte nonce.
    pub fn encrypt(&self, plaintext: &[u8]) -> Result<EncryptedPayload, EncryptionError> {
        let nonce = XChaCha20Poly1305::generate_nonce(&mut OsRng);
        let ciphertext = self
            .cipher
            .encrypt(&nonce, plaintext)
            .map_err(|e| EncryptionError::EncryptionFailed(e.to_string()))?;

        let mut nonce_bytes = [0u8; NONCE_SIZE];
        nonce_bytes.copy_from_slice(nonce.as_slice());

        Ok(EncryptedPayload {
            ciphertext,
            nonce: nonce_bytes,
        })
    }

    /// Encrypt a sensitive string (password / connection string).
    pub fn encrypt_string(&self, plaintext: &SecretString) -> Result<EncryptedPayload, EncryptionError> {
        self.encrypt(plaintext.expose_secret().as_bytes())
    }

    /// Decrypt ciphertext using the provided 24-byte nonce.
    /// Returns a zeroizing byte buffer for maximum memory safety.
    pub fn decrypt(
        &self,
        ciphertext: &[u8],
        nonce: &[u8; NONCE_SIZE],
    ) -> Result<Zeroizing<Vec<u8>>, EncryptionError> {
        let x_nonce = XNonce::from_slice(nonce);
        let decrypted = self
            .cipher
            .decrypt(x_nonce, ciphertext)
            .map_err(|e| EncryptionError::DecryptionFailed(e.to_string()))?;

        Ok(Zeroizing::new(decrypted))
    }

    /// Decrypt ciphertext and convert to a `SecretString`.
    pub fn decrypt_to_string(
        &self,
        ciphertext: &[u8],
        nonce: &[u8; NONCE_SIZE],
    ) -> Result<SecretString, EncryptionError> {
        let plaintext_bytes = self.decrypt(ciphertext, nonce)?;
        let s = String::from_utf8(plaintext_bytes.to_vec())?;
        Ok(SecretString::new(s))
    }
}

/// Helper function to convert a hex string to byte vector safely.
fn hex_to_bytes(s: &str) -> Result<Vec<u8>, EncryptionError> {
    let s = s.trim();
    if s.len() % 2 != 0 {
        return Err(EncryptionError::HexDecodeError("Odd length hex string".to_string()));
    }

    (0..s.len())
        .step_by(2)
        .map(|i| {
            u8::from_str_radix(&s[i..i + 2], 16)
                .map_err(|e| EncryptionError::HexDecodeError(e.to_string()))
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_xchacha20poly1305_encryption_cycle() {
        let key = CryptoEngine::generate_key();
        let engine = CryptoEngine::new(&key);

        let secret_data = SecretString::new("SuperSecretPostgresPassword123!".to_string());
        let encrypted = engine.encrypt_string(&secret_data).expect("encryption failed");

        assert_ne!(encrypted.ciphertext, secret_data.expose_secret().as_bytes());
        assert_eq!(encrypted.nonce.len(), NONCE_SIZE);

        let decrypted = engine
            .decrypt_to_string(&encrypted.ciphertext, &encrypted.nonce)
            .expect("decryption failed");

        assert_eq!(decrypted.expose_secret(), secret_data.expose_secret());
    }

    #[test]
    fn test_tampered_ciphertext_fails_poly1305_verification() {
        let key = CryptoEngine::generate_key();
        let engine = CryptoEngine::new(&key);

        let secret_data = SecretString::new("postgres_credentials".to_string());
        let mut encrypted = engine.encrypt_string(&secret_data).unwrap();

        // Tamper with one byte of ciphertext
        if let Some(byte) = encrypted.ciphertext.first_mut() {
            *byte ^= 0xFF;
        }

        let result = engine.decrypt_to_string(&encrypted.ciphertext, &encrypted.nonce);
        assert!(result.is_err(), "Tampered ciphertext must fail authentication!");
    }
}
