use sqlx::postgres::PgPoolOptions;
use sqlx::PgPool;

/// Create the control-plane connection pool for `manager_core`.
///
/// Pool sizes are measured/tuned through configuration, never hardcoded promises.
pub async fn create_pool(database_url: &str, max_connections: u32) -> Result<PgPool, sqlx::Error> {
    PgPoolOptions::new()
        .max_connections(max_connections.max(1))
        .min_connections(0)
        .acquire_timeout(std::time::Duration::from_secs(5))
        .connect(database_url)
        .await
}

/// Apply all embedded migrations. Safe to call on every boot.
pub async fn run_migrations(pool: &PgPool) -> Result<(), sqlx::migrate::MigrateError> {
    sqlx::migrate!("./migrations").run(pool).await
}
