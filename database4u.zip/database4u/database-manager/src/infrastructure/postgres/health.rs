use sqlx::PgPool;

/// Single round-trip liveness probe used by `/ready`.
pub async fn check_database(pool: &PgPool) -> bool {
    sqlx::query_scalar::<_, i32>("SELECT 1")
        .fetch_one(pool)
        .await
        .is_ok()
}
