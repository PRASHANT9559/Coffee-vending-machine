//! Helpers for building ad-hoc PostgreSQL targets.
//!
//! The control plane always uses `manager_core`. Project databases use lazily created,
//! per-database pools (see `connections::pool`). This module only builds validated
//! connection options for one-off connections (tests) and pool factories.

use secrecy::SecretString;
use sqlx::postgres::PgSslMode;
use sqlx::PgConnectOptions;

use crate::connections::config::ssl::TlsMode;
use crate::common::errors::AppError;

/// Parameters required to reach a PostgreSQL database.
#[derive(Debug, Clone)]
pub struct PgTarget {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub database: String,
}

impl PgTarget {
    /// Build SQLx options. The password is only borrowed for the duration of the call.
    pub fn connect_options(
        &self,
        password: &SecretString,
        tls: TlsMode,
        connect_timeout_secs: u64,
    ) -> Result<PgConnectOptions, AppError> {
        use secrecy::ExposeSecret;

        let options = PgConnectOptions::new()
            .host(&self.host)
            .port(self.port)
            .username(&self.username)
            .password(password.expose_secret())
            .database(&self.database)
            .application_name("database4u")
            .ssl_mode(map_ssl_mode(tls))
            .statement_cache_capacity(0);

        // `PgConnectOptions` does not expose a connect timeout setter in sqlx 0.7;
        // the timeout is enforced by the caller around `PgConnection::connect`.
        let _ = connect_timeout_secs;
        Ok(options)
    }
}

pub fn map_ssl_mode(tls: TlsMode) -> PgSslMode {
    match tls {
        TlsMode::Disable => PgSslMode::Disable,
        TlsMode::Prefer => PgSslMode::Prefer,
        TlsMode::Require => PgSslMode::Require,
        TlsMode::VerifyCa => PgSslMode::VerifyCa,
        TlsMode::VerifyFull => PgSslMode::VerifyFull,
    }
}
