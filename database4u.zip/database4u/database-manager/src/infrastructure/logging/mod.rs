use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};

/// Initialise structured logging.
///
/// Secrets are never logged: handlers use `tracing` with explicit, sanitized fields only.
pub fn init(environment: &str) {
    let filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| {
        let default = if environment == "production" {
            "database_manager=info,tower_http=info,sqlx=warn"
        } else {
            "database_manager=debug,tower_http=debug,sqlx=info"
        };
        EnvFilter::new(default)
    });

    let _ = tracing_subscriber::registry()
        .with(filter)
        .with(tracing_subscriber::fmt::layer().with_target(true))
        .try_init();
}
