# Backend Architecture (Part 1)

The backend is a **modular monolith**: one Axum process, one control database
(`manager_core`), and lazily-created pools for the user databases it manages.

```
HTTP ──► api/middleware (request-id → body limit → auth)
           │
           ├── projects / users / permissions   (control-plane CRUD)
           ├── connections                      (registry, pools, health)
           ├── databases / schema / records     (target-plane DDL + DML)
           ├── queries / transactions           (SQL console)
           ├── audit / realtime
           ▼
      AppState { db, settings, crypto, rate_limiter, pools, bus }
```

## Layers

| Layer | Location | Responsibility |
|---|---|---|
| HTTP | `api/` | Routing, envelopes, request-id/auth middleware, body limit. |
| Domain services | `projects/`, `connections/`, `databases/`, `schema/`, `records/`, `queries/` | Authorization + validation + orchestration. |
| Security | `security/` | Argon2id, opaque sessions, refresh rotation, RBAC policy, rate limiting, audit writer. |
| Infrastructure | `infrastructure/` | Postgres pool/migrations/health, logging, XChaCha20-Poly1305 crypto. |
| Shared | `common/` | `AppError`, identifier validation/quoting, pagination types. |
| State | `app_state.rs` | Single injectable state handle. |

## Key invariants

1. **Default deny.** Only `/health`, `/ready` and the auth endpoints are public; every
   other route passes through `auth_middleware`.
2. **Project isolation.** Reads join `project_members`; a guessed UUID yields `404`
   (not `403`) so existence never leaks. Every mutation first resolves an RBAC permission.
   Viewer role is granted `connection.use` (migration `015`) so read endpoints that need
   a pool actually work; discovery requires `connection.manage`.
3. **Secrets never leave.** Passwords are encrypted at rest with XChaCha20-Poly1305
   (`MASTER_ENCRYPTION_KEY`, 32 bytes hex). Responses and logs never include passwords,
   tokens, hashes or signed URLs. Only SHA-256 token hashes are stored.
4. **Identifiers are code, values are data.** Table/column/database names are validated
   against `^[A-Za-z_][A-Za-z0-9_]{0,62}$` and double-quoted. Everything user-supplied goes
   through bind parameters.
5. **Files never live in PostgreSQL.** Only metadata is stored; bytes go to disk/object
   storage (Part 2).
6. **Pools are lazy and budgeted.** A pool is created on first use per database target,
   bounded by `GLOBAL_POOL_BUDGET`; idle pools are evicted only when unused.
7. **DDL never runs from the target database.** `CREATE/ALTER/DROP DATABASE` use a peer
   pool connected to another database on the same server, after an active-connection check.
8. **Bootstrap is race-free.** The first-user bootstrap is protected by a
   transaction-scoped advisory lock (`pg_advisory_xact_lock`), so concurrent requests
   cannot create two "first" users.

## Request lifecycle

```
1. request_id_middleware  → UUID, tracing span, x-request-id response header
2. RequestBodyLimitLayer  → reject > 1 MB JSON bodies
3. auth_middleware        → hash bearer token, load session+user, attach AuthUser
4. handler                → RBAC check → validate → DB/pool work → audit
5. AppError::into_response→ stable status + code + sanitized message
```

## Connection/pool model

```
connections (profile, encrypted credential)
   └── connection_projects (ACL link)
   └── connection_databases (database targets)
         └── PoolManager: HashMap<target_id, Arc<PoolEntry>>
```

* `PoolEntry` = `PgPool` built with `connect_lazy_with`, so creating the entry does not open
  a socket.
* `BudgetManager` reserves `max_connections` before creation; exhausted budget returns
  `503 unavailable`.
* Eviction runs every 60 s and only closes pools idle ≥5 min with zero in-flight work.
* Health checks are `SELECT 1` with a 5 s timeout; failures close the pool so the next
  request recreates it.
* Reconnect uses exponential backoff (1,2,4,8,16 s, cap 30 s) with jitter.
  Failed transactions are **never** blindly retried.

## Query safety

* SQL console: one statement, size limit, `statement_timeout` inside a transaction,
  row cap, read-only by default for non-admins. `WITH` (CTE) is classified as **write**
  because a CTE can hide `INSERT`/`UPDATE`/`DELETE ... RETURNING`; it requires
  `schema.alter` even when the outer statement looks like a `SELECT`.
* CRUD: `jsonb_populate_record(set)` for typed input; unknown columns rejected.
* Schema DDL: allowlisted data types and default expressions; destructive operations
  require `confirm: true`; all DDL is audited.
* Database rename/drop require explicit `database.create` / `database.drop` (not just
  `schema.alter`).

## Migrations

Embedded via `sqlx::migrate!("./migrations")` and applied on boot. Runtime queries
(`sqlx::query` / `query_as`) are used everywhere — the project never requires a live
database at compile time.

| Migration | Content |
|---|---|
| 001–007 | users, sessions, refresh tokens, projects, members, connections, credentials, database registry, RBAC, audit, files |
| 008 | auth extensions: revocation, device metadata, password reset tokens |
| 009 | project owner/archive + normalized `project_member_roles` |
| 010 | SSL/SSH config tables, credential key version |
| 011 | pool policies, health logs, connection events, access grants |
| 012 | upload sessions, file ACLs, versions, events, storage usage |
| 013 | system settings, schema snapshots, audit indexes |
| 014 | RBAC seed (roles, permissions, role_permissions) |
| 015 | Viewer role granted `connection.use` |

## Configuration

All settings come from the environment (`.env` in development). Boot fails fast on a
missing/short `MASTER_ENCRYPTION_KEY`, zero pool limits, non-positive token TTLs, and —
in production — on `SERVER_HOST=0.0.0.0` (the proxy must terminate TLS).

See [`.env.example`](../.env.example).

## Deferred to later parts

* File bytes, resumable uploads, share links (Part 2).
* Password policy depth, security events, negative tests (Part 3).
* Slint desktop UI (Part 4).
* Multi-instance rate limiting/bus, backpressure tuning (Part 6).
* SSH transport (schema is ready; transport is intentionally disabled).
