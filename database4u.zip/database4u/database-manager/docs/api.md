# database4u — Backend API

Base URL: `/api/v1` · Content type: `application/json`

Every response uses one of two envelopes:

```jsonc
// success
{ "success": true, "data": { ... } }

// error
{ "success": false, "error": { "code": "forbidden", "message": "missing permission: database.write" } }
```

Error codes: `bad_request`, `validation_failed`, `unauthorized`, `forbidden`, `not_found`,
`conflict`, `rate_limited`, `timeout`, `unavailable`, `database_error`, `internal_error`.
`429` responses include `Retry-After`.

Authentication is **default-deny**: every `/api/v1` route except the six public auth
routes requires `Authorization: Bearer <access_token>`. Requests are also tagged with
`x-request-id` in the response.

---

## Health

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/health` | no | Liveness only, never touches the DB. |
| GET | `/ready` | no | Runs `SELECT 1` on `manager_core`; `503` if not ready. |

---

## Auth

| Method | Path | Auth | Body / notes |
|---|---|---|---|
| POST | `/auth/bootstrap` | no | `{ username, password }` — only while `users` is empty. |
| POST | `/auth/login` | no | `{ username, password }` → access + refresh token. Per-IP/per-user rate limited. |
| POST | `/auth/refresh` | no | `{ refresh_token }` — rotated; reuse revokes the whole session family. |
| POST | `/auth/password-reset/request` | no | `{ username }` — generic response; token returned only outside production. |
| POST | `/auth/password-reset/confirm` | no | `{ token, new_password }` — single use, revokes sessions. |
| POST | `/auth/logout` | yes | Revokes the current session. |
| POST | `/auth/logout-all` | yes | Revokes every session for the user. |
| GET | `/auth/sessions` | yes | Last 100 sessions with `last_seen_at` / `revoked_at`. |
| DELETE | `/auth/sessions/{session_id}` | yes | Revokes one session and its refresh tokens. |

Login response:

```json
{
  "access_token": "…",
  "refresh_token": "…",
  "token_type": "Bearer",
  "expires_in": 900,
  "user": { "user_id": "…", "username": "admin", "is_active": true, "created_at": "…" }
}
```

Tokens are opaque, 256-bit values; only their SHA-256 hash is stored. Access tokens live
`ACCESS_TOKEN_TTL_MINUTES` (default 15), refresh tokens `REFRESH_TOKEN_TTL_DAYS`
(default 30).

---

## Users

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/users/me` | yes | Sanitized profile (no password hash). |
| POST | `/users/me/password` | yes | `{ current_password, new_password }` — revokes all sessions. |

---

## Roles & permissions

| Method | Path | Notes |
|---|---|---|
| GET | `/permissions` | Permission catalogue (`permission_key`, description). |
| GET | `/roles` | Role catalogue (`owner`, `admin`, `editor`, `viewer`). |

Effective permissions for the current user in a project: `GET /projects/{id}/permissions`.

---

## Projects

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/projects` | — | Only projects the caller is a member of. |
| POST | `/projects` | — | `{ name, description? }`; creator becomes `owner`. |
| GET | `/projects/{id}` | membership | Guessed UUIDs return `404`. |
| PATCH | `/projects/{id}` | `project.update` | `{ name?, description?, is_archived? }`. |
| DELETE | `/projects/{id}` | `project.delete` | Soft delete (archive). |
| GET | `/projects/{id}/members` | `project.read` | Includes username + role. |
| POST | `/projects/{id}/members` | `project.members.manage` | `{ user_id, role? }`. |
| PATCH | `/projects/{id}/members/{user_id}` | `project.members.manage` | `{ role }`; last owner cannot be demoted. |
| DELETE | `/projects/{id}/members/{user_id}` | `project.members.manage` | Last owner cannot be removed. |
| GET | `/projects/{id}/permissions` | membership | Flattened permission keys. |

### Project ↔ connection mapping

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/projects/{id}/connections` | `project.read` | Connections linked to this project (sanitized profiles, no credentials). |
| POST | `/projects/{id}/connections` | `project.members.manage` + `connection.manage` | `{ connection_id }` — links an existing connection to this project. Idempotent. |
| DELETE | `/projects/{id}/connections/{connection_id}` | `project.members.manage` + `connection.manage` | Unlinks the connection from this project; pools are drained. |

---

## Connections

Passwords are encrypted with XChaCha20-Poly1305 before insert and are never returned.
`credential_id` is not exposed.

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/connections` | — | Connections linked to projects the caller belongs to. |
| POST | `/connections` | `connection.manage` | See body below. |
| GET | `/connections/{id}` | membership | Sanitized profile. |
| PATCH | `/connections/{id}` | `connection.manage` | Any field optional; `password` rotates the secret. Pools are drained. |
| DELETE | `/connections/{id}` | `connection.manage` | Closes pools, removes profile + credential. |
| POST | `/connections/{id}/rotate-credential` | `connection.manage` | `{ password }` — re-encrypts; pools drained. |
| POST | `/connections/{id}/test` | `connection.use` | `{ password?, database? }` — staged report, no pool created. |
| POST | `/connections/{id}/connect` | `connection.use` | `{ database_target_id? }` → health snapshot. |
| POST | `/connections/{id}/disconnect` | `connection.use` | Closes every pool for the connection. |
| POST | `/connections/{id}/reconnect` | `connection.use` | Drain + connect. |
| GET | `/connections/{id}/health` | `connection.use` | `SELECT 1` probe with latency. |
| GET | `/connections/{id}/metrics` | `connection.read` | Pool/budget counters. |
| GET | `/connections/{id}/databases` | `connection.read` | Registered database targets. |
| POST | `/connections/{id}/discover` | `connection.use` | Reads `pg_database` and upserts targets. |

Create body:

```json
{
  "display_name": "Production",
  "project_id": "…",
  "host": "db.example.com",
  "port": 5432,
  "username": "app",
  "password": "…",
  "database": "postgres",
  "tls_mode": "verify_full",
  "network_mode": "direct_tls",
  "connect_timeout_secs": 5,
  "acquire_timeout_secs": 5,
  "idle_timeout_secs": 300,
  "max_lifetime_secs": 1800
}
```

Test report stages: `host → dns → tcp → tls_authentication → permissions`. Driver internals
and credentials are never included (`authentication failed`, `tls verification failed`, …).

`network_mode: "ssh_tunnel"` is accepted for storage but connect/test return `400` —
SSH transport is not compiled into this build (fail closed, no silent downgrade).

---

## Databases

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/databases?connection_id=…` | `database.read` | Registered targets with size/encoding/collation/owner/active connections. |
| POST | `/databases` | `database.create` | `{ connection_id, database_name, owner? }`. |
| GET | `/databases/{database_target_id}` | connection access | Single database metadata. |
| POST | `/databases/{database_target_id}/rename` | `database.create` (via connection access) | `{ new_name, confirm: true }`. |
| DELETE | `/databases/{database_target_id}` | `database.drop` (via connection access) | `{ confirm: true }`. |
| GET | `/databases/{database_target_id}/tables` | `schema.read` | `?schema=public` (default). |

`CREATE/ALTER/DROP DATABASE` always runs through a **peer pool** connected to a different
database on the same server, after an active-connection check. Identifiers are validated
(`^[A-Za-z_][A-Za-z0-9_]{0,62}$`) and double-quoted — never bound as values.

---

## Schema

| Method | Path | Permission | Body / query |
|---|---|---|---|
| GET | `/tables?database_target_id=…&schema=public` | `schema.read` | List tables/views. |
| POST | `/tables` | `schema.alter` | `{ database_target_id, schema?, table, columns[] }` |
| DELETE | `/tables` | `schema.alter` | `{ database_target_id, schema?, table, confirm: true }` |
| POST | `/tables/rename` | `schema.alter` | `{ …, table, new_name, confirm: true }` |
| GET | `/tables/inspect?database_target_id=…&table=…` | `schema.read` | Columns + indexes + constraints + row estimate + size. |
| GET | `/tables/relations?database_target_id=…&schema=public` | `schema.read` | Foreign-key graph. |
| GET | `/tables/columns?database_target_id=…&table=…` | `schema.read` | Column metadata. |
| POST | `/tables/columns` | `schema.alter` | `{ …, table, column }` — add column. |
| POST | `/tables/columns/rename` | `schema.alter` | `{ …, column, new_name }`. |
| POST | `/tables/columns/type` | `schema.alter` | `{ …, column, data_type, confirm: true }`. |
| POST | `/tables/columns/drop` | `schema.alter` | `{ …, column, confirm: true }`. |
| GET | `/tables/indexes?database_target_id=…&table=…` | `schema.read` | `pg_indexes`. |
| POST | `/indexes` | `schema.alter` | `{ …, table, index_name, columns[], unique? }`. |
| POST | `/indexes/drop` | `schema.alter` | `{ …, index_name, confirm: true }`. |
| GET | `/tables/constraints?database_target_id=…&table=…` | `schema.read` | PK/FK/UNIQUE/CHECK. |
| POST | `/tables/constraints/drop` | `schema.alter` | `{ …, table, constraint_name, confirm: true }`. |
| GET | `/views?database_target_id=…&schema=public` | `schema.read` | Definition included. |
| POST | `/views` | `schema.alter` | `{ …, name, definition }` — single SELECT/WITH only. |
| DELETE | `/views` | `schema.alter` | `{ …, name, confirm: true }`. |
| GET | `/sequences?database_target_id=…&schema=public` | `schema.read` | Type, start, increment, last value. |

Data types are limited to `[A-Za-z0-9 (),\[\]]` and ≤64 chars; defaults are an allowlist
(`now()`, `current_timestamp`, `gen_random_uuid()`, booleans, numbers, single-quoted
strings). Column/table identifiers are always validated and quoted.

---

## Records

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/records?database_target_id=…&table=…` | `database.read` | `page` (1), `limit` (100, max 500), `sort`, `order`, `filter_column`, `filter_value`, `search`. |
| POST | `/records` | `database.write` | `{ …, table, values: { … } }` → inserted row. |
| POST | `/records/bulk` | `database.write` | `{ …, table, rows: [ … ] }` — max 500, all-or-nothing. **Every row must use the same column set**; mixed shapes are rejected (a single `INSERT … SELECT` applies one column list to all rows, so missing fields would otherwise become NULL instead of their defaults). |
| PATCH | `/records` | `database.write` | `{ …, table, pk_column, pk_value, values }` → updated row. |
| DELETE | `/records` | `database.write` | `{ …, table, pk_column, pk_value }` → deleted row. |

Responses use `to_jsonb(row)`; values are typed by PostgreSQL via
`jsonb_populate_record` / `jsonb_populate_recordset`. Unknown column names are rejected
before SQL is built. Insert lists only the supplied columns so PostgreSQL defaults and
generated values apply to everything the caller left out. `has_more` is always present
so clients never request 100k rows.

---

## Queries & transactions

| Method | Path | Permission | Body |
|---|---|---|---|
| POST | `/queries/execute` | `query.execute` | `{ database_target_id, sql, read_only?, max_rows? }` |
| POST | `/transactions/execute` | `query.execute` | `{ database_target_id, statements: [ … ] }` (max 100) |

* One statement per `/queries/execute`; trailing `;` allowed, embedded `;` rejected.
* `read_only` defaults to **true** unless the caller has `schema.alter` in the owning
  project. Read results are capped at `max_rows` (default 100, max 1000) with `truncated`.
* `WITH` (CTE) is classified as **write**: a CTE can hide `INSERT`/`UPDATE`/`DELETE ... RETURNING`,
  so it requires write permission even when the outer statement is a `SELECT`. Plain
  `SELECT`/`SHOW`/`EXPLAIN`/`VALUES`/`TABLE` are read-only.
* Each request runs in a transaction with `SET LOCAL statement_timeout = QUERY_TIMEOUT_SECONDS`.
* `/transactions/execute` is all-or-nothing; any failure rolls back every statement.
* Error messages are sanitized to the driver message (no stack traces, no credentials).

---

## Audit

| Method | Path | Permission | Query |
|---|---|---|---|
| GET | `/audit` | `audit.read` when `project_id` is supplied | `project_id?`, `action?`, `user_id?`, `from?`, `to?`, `page`, `limit` |

Without `project_id`, only the caller's own entries are returned. Entries include
`action`, `target_resource`, `status`, `duration_ms`, `created_at` and the request id
correlation available in server logs.

---

## Realtime

| Method | Path | Notes |
|---|---|---|
| GET | `/ws` | Authenticated WebSocket (`Authorization` header). Events are filtered to projects the caller belongs to. |

Event shape: `{ project_id, kind, payload, created_at }`. The channel is bounded; a lagging
subscriber is disconnected instead of buffering without limit. A shared bus (Redis/NATS)
arrives with Part 6.
