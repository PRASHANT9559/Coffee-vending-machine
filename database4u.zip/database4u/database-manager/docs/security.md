# Security Documentation

See [PROJECT_ARCHITECTURE.md Section 11 & 15](../../PROJECT_ARCHITECTURE.md#11-part-3--security--access-control) for security principles and implementation details.
