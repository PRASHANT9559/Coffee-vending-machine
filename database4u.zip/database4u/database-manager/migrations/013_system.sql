-- 013_system.sql
-- Global settings and optional schema history.

CREATE TABLE IF NOT EXISTS system_settings (
    key VARCHAR(128) PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS schema_snapshots (
    snapshot_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    database_target_id UUID NOT NULL REFERENCES connection_databases(database_target_id) ON DELETE CASCADE,
    schema_name VARCHAR(128) NOT NULL,
    snapshot JSONB NOT NULL,
    created_by UUID REFERENCES users(user_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_schema_snapshots_target_time
    ON schema_snapshots (database_target_id, created_at DESC);

ALTER TABLE audit_logs
    ADD COLUMN IF NOT EXISTS ip_hash TEXT;

CREATE INDEX IF NOT EXISTS idx_audit_project_time
    ON audit_logs (project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_user_time
    ON audit_logs (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs (action);
