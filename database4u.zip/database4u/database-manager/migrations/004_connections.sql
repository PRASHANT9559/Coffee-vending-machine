-- 004_connections.sql
CREATE TABLE IF NOT EXISTS connections (
    connection_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    display_name VARCHAR(128) NOT NULL,
    scope VARCHAR(32) NOT NULL DEFAULT 'local', -- 'local' | 'remote'
    host VARCHAR(255) NOT NULL,
    port INT NOT NULL DEFAULT 5432,
    username VARCHAR(128) NOT NULL,
    credential_id UUID NOT NULL,
    network_mode VARCHAR(32) NOT NULL DEFAULT 'direct_tls', -- 'direct_tls' | 'ssh_tunnel'
    tls_mode VARCHAR(32) NOT NULL DEFAULT 'verify_full',
    connect_timeout INT NOT NULL DEFAULT 5,
    acquire_timeout INT NOT NULL DEFAULT 5,
    idle_timeout INT NOT NULL DEFAULT 300,
    max_lifetime INT NOT NULL DEFAULT 1800,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS connection_credentials (
    credential_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    encrypted_password BYTEA NOT NULL,
    nonce BYTEA NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS connection_projects (
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
    PRIMARY KEY (connection_id, project_id)
);
