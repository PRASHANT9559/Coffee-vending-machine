-- 005_database_registry.sql
CREATE TABLE IF NOT EXISTS connection_databases (
    database_target_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    database_name VARCHAR(128) NOT NULL,
    pool_policy_id UUID,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    last_discovered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(connection_id, database_name)
);
