-- 012_files_extra.sql
-- Upload sessions, ACLs, versions, events and quota accounting.
-- File bytes are never stored in PostgreSQL.

CREATE TABLE IF NOT EXISTS upload_sessions (
    session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
    owner_user_id UUID REFERENCES users(user_id) ON DELETE SET NULL,
    original_name VARCHAR(255) NOT NULL,
    media_type VARCHAR(128) NOT NULL,
    expected_size BIGINT NOT NULL CHECK (expected_size >= 0),
    received_bytes BIGINT NOT NULL DEFAULT 0,
    temp_storage_key VARCHAR(512) NOT NULL,
    checksum_expected VARCHAR(64),
    chunk_size INT NOT NULL DEFAULT 5242880,
    status VARCHAR(32) NOT NULL DEFAULT 'initiated',
    file_id UUID REFERENCES files(file_id) ON DELETE SET NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_upload_sessions_status_expiry
    ON upload_sessions (status, expires_at);

CREATE TABLE IF NOT EXISTS file_permissions (
    file_permission_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_id UUID NOT NULL REFERENCES files(file_id) ON DELETE CASCADE,
    subject_type VARCHAR(16) NOT NULL,
    subject_id UUID NOT NULL,
    permission_key VARCHAR(128) NOT NULL,
    granted_by UUID REFERENCES users(user_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (file_id, subject_type, subject_id, permission_key)
);

CREATE TABLE IF NOT EXISTS file_versions (
    version_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_id UUID NOT NULL REFERENCES files(file_id) ON DELETE CASCADE,
    version_no INT NOT NULL DEFAULT 1,
    storage_key VARCHAR(512) NOT NULL,
    size_bytes BIGINT NOT NULL,
    checksum VARCHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (file_id, version_no)
);

CREATE TABLE IF NOT EXISTS file_events (
    event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_id UUID REFERENCES files(file_id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
    actor_user_id UUID REFERENCES users(user_id) ON DELETE SET NULL,
    action VARCHAR(64) NOT NULL,
    status VARCHAR(32) NOT NULL,
    detail TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_file_events_project_time
    ON file_events (project_id, created_at DESC);

CREATE TABLE IF NOT EXISTS file_storage_usage (
    project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    used_bytes BIGINT NOT NULL DEFAULT 0 CHECK (used_bytes >= 0),
    quota_bytes BIGINT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (project_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_files_project_status ON files (project_id, status);
CREATE INDEX IF NOT EXISTS idx_files_checksum ON files (checksum);
CREATE INDEX IF NOT EXISTS idx_files_owner ON files (owner_user_id);
