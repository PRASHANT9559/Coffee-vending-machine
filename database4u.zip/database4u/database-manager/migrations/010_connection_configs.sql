-- 010_connection_configs.sql
-- TLS and SSH configuration are stored separately from credentials.

CREATE TABLE IF NOT EXISTS connection_ssl_configs (
    ssl_config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    mode VARCHAR(32) NOT NULL DEFAULT 'verify_full',
    root_cert_path TEXT,
    client_cert_path TEXT,
    client_key_path TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (connection_id)
);

CREATE TABLE IF NOT EXISTS connection_ssh_configs (
    ssh_config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    ssh_host VARCHAR(255) NOT NULL,
    ssh_port INT NOT NULL DEFAULT 22,
    ssh_username VARCHAR(128) NOT NULL,
    ssh_credential_id UUID,
    local_port INT,
    remote_host VARCHAR(255) NOT NULL DEFAULT '127.0.0.1',
    remote_port INT NOT NULL DEFAULT 5432,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (connection_id)
);

ALTER TABLE connection_credentials
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ADD COLUMN IF NOT EXISTS key_version INT NOT NULL DEFAULT 1;
