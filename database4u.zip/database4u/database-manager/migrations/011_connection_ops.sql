-- 011_connection_ops.sql
-- Pool policy, health history, lifecycle events and connection-level access grants.

CREATE TABLE IF NOT EXISTS connection_pool_policies (
    pool_policy_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    max_connections INT NOT NULL DEFAULT 5,
    min_connections INT NOT NULL DEFAULT 0,
    acquire_timeout_secs INT NOT NULL DEFAULT 5,
    connect_timeout_secs INT NOT NULL DEFAULT 5,
    idle_timeout_secs INT NOT NULL DEFAULT 300,
    max_lifetime_secs INT NOT NULL DEFAULT 1800,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (max_connections > 0 AND max_connections <= 20),
    CHECK (min_connections >= 0 AND min_connections <= max_connections)
);

CREATE TABLE IF NOT EXISTS connection_health_logs (
    health_log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    database_target_id UUID,
    healthy BOOLEAN NOT NULL,
    latency_ms INT,
    detail TEXT,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_health_logs_connection_time
    ON connection_health_logs (connection_id, checked_at DESC);

CREATE TABLE IF NOT EXISTS connection_events (
    event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    from_state VARCHAR(32),
    to_state VARCHAR(32) NOT NULL,
    reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_connection_events_connection_time
    ON connection_events (connection_id, created_at DESC);

CREATE TABLE IF NOT EXISTS connection_access (
    connection_id UUID NOT NULL REFERENCES connections(connection_id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    permission_key VARCHAR(128) NOT NULL,
    granted_by UUID REFERENCES users(user_id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (connection_id, user_id, permission_key)
);
