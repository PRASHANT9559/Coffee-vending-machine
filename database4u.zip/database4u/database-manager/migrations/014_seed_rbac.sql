-- 014_seed_rbac.sql
-- Roles and permissions are data, not code: enforcement always resolves through the
-- database so role changes take effect without a deploy.

INSERT INTO roles (role_name, description) VALUES
    ('owner',  'Full project administration including destructive operations'),
    ('admin',  'Manage members and resources; cannot remove the last owner'),
    ('editor', 'Create and update permitted resources'),
    ('viewer', 'Read-only access')
ON CONFLICT (role_name) DO NOTHING;

INSERT INTO permissions (permission_key, description) VALUES
    ('project.read',            'View project details'),
    ('project.update',          'Update project settings'),
    ('project.delete',          'Archive or delete a project'),
    ('project.members.manage',  'Add, update and remove project members'),
    ('connection.read',         'View connection profiles and health'),
    ('connection.manage',       'Create, update and delete connection profiles'),
    ('connection.use',          'Open pools and query through a connection'),
    ('database.read',           'List databases and read metadata'),
    ('database.write',          'Insert, update and delete records'),
    ('database.create',         'Create databases'),
    ('database.drop',           'Drop databases'),
    ('schema.read',             'Inspect tables, columns, indexes and constraints'),
    ('schema.alter',            'Create and alter schema objects'),
    ('query.execute',           'Execute raw SQL through the query console'),
    ('file.read',               'List files'),
    ('file.upload',             'Create upload sessions'),
    ('file.download',           'Download file content'),
    ('file.update_metadata',    'Rename file metadata'),
    ('file.delete',             'Delete files'),
    ('file.share',              'Create and revoke file share links'),
    ('audit.read',              'Read the project audit trail')
ON CONFLICT (permission_key) DO NOTHING;

-- owner: every permission
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r CROSS JOIN permissions p
WHERE r.role_name = 'owner'
ON CONFLICT DO NOTHING;

-- admin: everything except project.delete
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r CROSS JOIN permissions p
WHERE r.role_name = 'admin' AND p.permission_key <> 'project.delete'
ON CONFLICT DO NOTHING;

-- editor
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r CROSS JOIN permissions p
WHERE r.role_name = 'editor'
  AND p.permission_key IN (
      'project.read', 'connection.read', 'connection.use',
      'database.read', 'database.write',
      'schema.read', 'schema.alter', 'query.execute',
      'file.read', 'file.upload', 'file.download', 'file.update_metadata'
  )
ON CONFLICT DO NOTHING;

-- viewer
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r CROSS JOIN permissions p
WHERE r.role_name = 'viewer'
  AND p.permission_key IN (
      'project.read', 'connection.read', 'database.read',
      'schema.read', 'file.read', 'file.download'
  )
ON CONFLICT DO NOTHING;
