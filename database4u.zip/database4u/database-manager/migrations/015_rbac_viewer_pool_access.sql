-- 015_rbac_viewer_pool_access.sql
-- Read paths authorize twice: first the fine-grained permission (e.g. `database.read`)
-- and then `connection.use` to obtain a pool. Without this grant a viewer could list a
-- database but never actually read it, so every read would fail with 403.

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r
JOIN permissions p ON p.permission_key = 'connection.use'
WHERE r.role_name = 'viewer'
ON CONFLICT DO NOTHING;
