use uuid::Uuid;

use crate::api_client::models::{FileDto, StorageUsageDto};
use crate::api_client::{ApiClient, ApiError};

pub struct FileManagerController;

impl FileManagerController {
    pub async fn load_files(api: &ApiClient, project_id: Uuid) -> Result<Vec<FileDto>, ApiError> {
        api.list_files(project_id).await
    }

    pub async fn load_quota_usage(api: &ApiClient, project_id: Uuid) -> Result<StorageUsageDto, ApiError> {
        api.get_storage_usage(project_id).await
    }

    pub async fn delete_file(api: &ApiClient, file_id: &str) -> Result<(), ApiError> {
        api.delete_file(file_id).await
    }

    pub async fn download_file(api: &ApiClient, file_id: &str) -> Result<Vec<u8>, ApiError> {
        api.download_file_bytes(file_id).await
    }
}
