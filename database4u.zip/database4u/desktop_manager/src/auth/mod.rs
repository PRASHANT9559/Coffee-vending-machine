use crate::api_client::models::LoginResponseData;
use crate::api_client::{ApiClient, ApiError};

pub struct AuthManager;

impl AuthManager {
    pub async fn login(
        api: &ApiClient,
        server_url: &str,
        username: &str,
        password: &str,
    ) -> Result<LoginResponseData, ApiError> {
        api.set_base_url(server_url).await;
        api.login(username, password).await
    }

    pub async fn logout(api: &ApiClient) {
        api.set_token(None).await;
    }
}
