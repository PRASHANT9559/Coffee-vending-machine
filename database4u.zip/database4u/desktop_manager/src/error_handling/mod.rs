use crate::api_client::ApiError;

/// Format API error into user-friendly message.
pub fn format_ui_error(err: &ApiError) -> String {
    match err {
        ApiError::Network(_) => "Cannot connect to server. Please verify the URL and ensure the backend is running.".to_string(),
        ApiError::Unauthorized(_) => "Invalid username or password, or session has expired.".to_string(),
        ApiError::Forbidden(_) => "Access denied: your user does not have permission for this action.".to_string(),
        ApiError::NotFound(_) => "Requested resource not found.".to_string(),
        ApiError::RateLimited(_) => "Too many requests. Please wait a moment and try again.".to_string(),
        ApiError::Server { status, message } => format!("Server error ({status}): {message}"),
        ApiError::Serialization(msg) => format!("Data parsing error: {msg}"),
    }
}
