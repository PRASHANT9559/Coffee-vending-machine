use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Deserialize)]
pub struct ApiResponse<T> {
    pub success: bool,
    pub data: Option<T>,
    pub error: Option<ApiErrorResponse>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ApiErrorResponse {
    pub code: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoginPayload {
    pub username: String,
    pub password: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct UserPublic {
    pub user_id: Uuid,
    pub username: String,
    pub email: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct LoginResponseData {
    pub access_token: String,
    pub refresh_token: String,
    pub token_type: String,
    pub expires_in: i64,
    pub user: UserPublic,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ProjectDto {
    pub project_id: Uuid,
    pub name: String,
    pub description: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ConnectionProfileDto {
    pub connection_id: Uuid,
    pub display_name: String,
    pub host: String,
    pub port: u16,
    pub state: String,
    pub is_healthy: bool,
}

#[derive(Debug, Clone, Deserialize)]
pub struct DatabaseDto {
    pub database_id: Option<Uuid>,
    pub name: String,
    pub size_bytes: Option<i64>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct TableDto {
    pub table_name: String,
    pub row_count_estimate: Option<i64>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct FileDto {
    pub file_id: Uuid,
    pub project_id: Uuid,
    pub original_name: String,
    pub media_type: String,
    pub extension: String,
    pub size_bytes: i64,
    pub checksum: String,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct StorageUsageDto {
    pub project_id: Uuid,
    pub used_bytes: i64,
    pub quota_bytes: Option<i64>,
}

#[derive(Debug, Clone, Serialize)]
pub struct CreateSessionDto {
    pub project_id: Uuid,
    pub original_name: String,
    pub media_type: String,
    pub size_bytes: i64,
}

#[derive(Debug, Clone, Deserialize)]
pub struct UploadSessionDto {
    pub session_id: Uuid,
    pub chunk_size: i32,
    pub expires_at: String,
    pub status: String,
    pub expected_size: i64,
    pub received_bytes: i64,
}

#[derive(Debug, Clone, Deserialize)]
pub struct AuditEntryDto {
    pub log_id: Uuid,
    pub action: String,
    pub target_resource: String,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct AuditPageDto {
    pub items: Vec<AuditEntryDto>,
    pub total: i64,
}
