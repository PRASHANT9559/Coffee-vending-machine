use reqwest::header::{HeaderMap, HeaderValue, AUTHORIZATION};
use reqwest::{Client, StatusCode};
use std::sync::Arc;
use tokio::sync::RwLock;
use uuid::Uuid;

use super::error::ApiError;
use super::models::*;

#[derive(Clone, Debug)]
pub struct ApiClient {
    base_url: Arc<RwLock<String>>,
    client: Client,
    token: Arc<RwLock<Option<String>>>,
}

impl ApiClient {
    pub fn new(base_url: &str) -> Self {
        Self {
            base_url: Arc::new(RwLock::new(base_url.trim_end_matches('/').to_string())),
            client: Client::builder().build().unwrap_or_default(),
            token: Arc::new(RwLock::new(None)),
        }
    }

    pub async fn set_base_url(&self, url: &str) {
        let mut guard = self.base_url.write().await;
        *guard = url.trim_end_matches('/').to_string();
    }

    pub async fn set_token(&self, token: Option<String>) {
        let mut guard = self.token.write().await;
        *guard = token;
    }

    async fn auth_headers(&self) -> HeaderMap {
        let mut headers = HeaderMap::new();
        if let Some(ref t) = *self.token.read().await {
            if let Ok(val) = HeaderValue::from_str(&format!("Bearer {t}")) {
                headers.insert(AUTHORIZATION, val);
            }
        }
        headers
    }

    async fn handle_response<T: serde::de::DeserializeOwned>(&self, res: reqwest::Response) -> Result<T, ApiError> {
        let status = res.status();
        if status == StatusCode::UNAUTHORIZED {
            return Err(ApiError::Unauthorized("invalid or expired session token".into()));
        }
        if status == StatusCode::FORBIDDEN {
            return Err(ApiError::Forbidden("access denied to this resource".into()));
        }
        if status == StatusCode::NOT_FOUND {
            return Err(ApiError::NotFound("resource not found".into()));
        }
        if status == StatusCode::TOO_MANY_REQUESTS {
            return Err(ApiError::RateLimited("too many requests, rate limit exceeded".into()));
        }

        let body_text = res.text().await?;
        let parsed: ApiResponse<T> = serde_json::from_str(&body_text)
            .map_err(|e| ApiError::Serialization(format!("{e}: {body_text}")))?;

        if parsed.success {
            parsed.data.ok_or_else(|| ApiError::Serialization("missing data payload in success response".into()))
        } else {
            let msg = parsed.error.map(|e| e.message).unwrap_or_else(|| "unknown API error".into());
            Err(ApiError::Server {
                status: status.as_u16(),
                message: msg,
            })
        }
    }

    pub async fn login(&self, username: &str, password: &str) -> Result<LoginResponseData, ApiError> {
        let url = format!("{}/api/v1/auth/login", *self.base_url.read().await);
        let payload = LoginPayload {
            username: username.to_string(),
            password: password.to_string(),
        };

        let res = self.client.post(&url).json(&payload).send().await?;
        let data: LoginResponseData = self.handle_response(res).await?;

        self.set_token(Some(data.access_token.clone())).await;
        Ok(data)
    }

    pub async fn list_projects(&self) -> Result<Vec<ProjectDto>, ApiError> {
        let url = format!("{}/api/v1/projects", *self.base_url.read().await);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }

    pub async fn list_connections(&self) -> Result<Vec<ConnectionProfileDto>, ApiError> {
        let url = format!("{}/api/v1/connections", *self.base_url.read().await);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }

    pub async fn test_connection(&self, connection_id: &str) -> Result<(), ApiError> {
        let url = format!("{}/api/v1/connections/{}/test", *self.base_url.read().await, connection_id);
        let res = self.client.post(&url).headers(self.auth_headers().await).send().await?;
        let _: serde_json::Value = self.handle_response(res).await?;
        Ok(())
    }

    pub async fn connect_connection(&self, connection_id: &str) -> Result<(), ApiError> {
        let url = format!("{}/api/v1/connections/{}/connect", *self.base_url.read().await, connection_id);
        let res = self.client.post(&url).headers(self.auth_headers().await).send().await?;
        let _: serde_json::Value = self.handle_response(res).await?;
        Ok(())
    }

    pub async fn list_databases(&self) -> Result<Vec<DatabaseDto>, ApiError> {
        let url = format!("{}/api/v1/databases", *self.base_url.read().await);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }

    pub async fn list_tables_for_database(&self, database_id: &str) -> Result<Vec<TableDto>, ApiError> {
        let url = format!("{}/api/v1/databases/{}/tables", *self.base_url.read().await, database_id);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }

    pub async fn list_files(&self, project_id: Uuid) -> Result<Vec<FileDto>, ApiError> {
        let url = format!("{}/api/v1/files?project_id={}&limit=100", *self.base_url.read().await, project_id);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }

    pub async fn get_storage_usage(&self, project_id: Uuid) -> Result<StorageUsageDto, ApiError> {
        let url = format!("{}/api/v1/projects/{}/storage-usage", *self.base_url.read().await, project_id);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }

    pub async fn delete_file(&self, file_id: &str) -> Result<(), ApiError> {
        let url = format!("{}/api/v1/files/{}", *self.base_url.read().await, file_id);
        let res = self.client.delete(&url).headers(self.auth_headers().await).send().await?;
        let _: serde_json::Value = self.handle_response(res).await?;
        Ok(())
    }

    pub async fn download_file_bytes(&self, file_id: &str) -> Result<Vec<u8>, ApiError> {
        let url = format!("{}/api/v1/files/{}/download", *self.base_url.read().await, file_id);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        if !res.status().is_success() {
            return Err(ApiError::Server {
                status: res.status().as_u16(),
                message: "file download failed".into(),
            });
        }
        let bytes = res.bytes().await?;
        Ok(bytes.to_vec())
    }

    pub async fn create_upload_session(
        &self,
        project_id: Uuid,
        filename: &str,
        media_type: &str,
        size_bytes: i64,
    ) -> Result<UploadSessionDto, ApiError> {
        let url = format!("{}/api/v1/files/upload-sessions", *self.base_url.read().await);
        let payload = CreateSessionDto {
            project_id,
            original_name: filename.to_string(),
            media_type: media_type.to_string(),
            size_bytes,
        };
        let res = self.client.post(&url).headers(self.auth_headers().await).json(&payload).send().await?;
        self.handle_response(res).await
    }

    pub async fn upload_part_chunk(&self, session_id: Uuid, chunk_bytes: Vec<u8>) -> Result<(), ApiError> {
        let url = format!("{}/api/v1/files/upload-sessions/{}/parts", *self.base_url.read().await, session_id);
        let part = reqwest::multipart::Part::bytes(chunk_bytes).file_name("chunk.bin");
        let form = reqwest::multipart::Form::new().part("chunk", part);

        let res = self.client.post(&url).headers(self.auth_headers().await).multipart(form).send().await?;
        let _: serde_json::Value = self.handle_response(res).await?;
        Ok(())
    }

    pub async fn complete_upload_session(&self, session_id: Uuid) -> Result<FileDto, ApiError> {
        let url = format!("{}/api/v1/files/upload-sessions/{}/complete", *self.base_url.read().await, session_id);
        let res = self.client.post(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }

    pub async fn abort_upload_session(&self, session_id: Uuid) -> Result<(), ApiError> {
        let url = format!("{}/api/v1/files/upload-sessions/{}", *self.base_url.read().await, session_id);
        let res = self.client.delete(&url).headers(self.auth_headers().await).send().await?;
        let _: serde_json::Value = self.handle_response(res).await?;
        Ok(())
    }

    pub async fn list_audit_entries(&self, project_id: Uuid) -> Result<AuditPageDto, ApiError> {
        let url = format!("{}/api/v1/audit?project_id={}&limit=50", *self.base_url.read().await, project_id);
        let res = self.client.get(&url).headers(self.auth_headers().await).send().await?;
        self.handle_response(res).await
    }
}
