use thiserror::Error;

#[derive(Error, Debug)]
pub enum ApiError {
    #[error("network connection error: {0}")]
    Network(#[from] reqwest::Error),

    #[error("unauthorized: {0}")]
    Unauthorized(String),

    #[error("forbidden: {0}")]
    Forbidden(String),

    #[error("not found: {0}")]
    NotFound(String),

    #[error("rate limit exceeded: {0}")]
    RateLimited(String),

    #[error("server error ({status}): {message}")]
    Server { status: u16, message: String },

    #[error("serialization error: {0}")]
    Serialization(String),
}
