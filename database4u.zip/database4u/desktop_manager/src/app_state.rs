use std::sync::Arc;
use tokio::sync::RwLock;
use uuid::Uuid;

use crate::api_client::models::{AuditEntryDto, ConnectionProfileDto, DatabaseDto, FileDto, ProjectDto, TableDto};
use crate::api_client::ApiClient;

/// Shared application runtime state.
#[derive(Clone, Debug)]
pub struct AppState {
    pub api: ApiClient,
    pub username: Arc<RwLock<String>>,
    pub current_project_id: Arc<RwLock<Option<Uuid>>>,
    pub current_project_name: Arc<RwLock<String>>,
    pub projects: Arc<RwLock<Vec<ProjectDto>>>,
    pub connections: Arc<RwLock<Vec<ConnectionProfileDto>>>,
    pub selected_connection_id: Arc<RwLock<Option<String>>>,
    pub databases: Arc<RwLock<Vec<DatabaseDto>>>,
    pub selected_database: Arc<RwLock<Option<String>>>,
    pub tables: Arc<RwLock<Vec<TableDto>>>,
    pub files: Arc<RwLock<Vec<FileDto>>>,
    pub audit_entries: Arc<RwLock<Vec<AuditEntryDto>>>,
}

impl AppState {
    pub fn new(default_url: &str) -> Self {
        Self {
            api: ApiClient::new(default_url),
            username: Arc::new(RwLock::new(String::new())),
            current_project_id: Arc::new(RwLock::new(None)),
            current_project_name: Arc::new(RwLock::new("Default Project".to_string())),
            projects: Arc::new(RwLock::new(Vec::new())),
            connections: Arc::new(RwLock::new(Vec::new())),
            selected_connection_id: Arc::new(RwLock::new(None)),
            databases: Arc::new(RwLock::new(Vec::new())),
            selected_database: Arc::new(RwLock::new(None)),
            tables: Arc::new(RwLock::new(Vec::new())),
            files: Arc::new(RwLock::new(Vec::new())),
            audit_entries: Arc::new(RwLock::new(Vec::new())),
        }
    }
}
