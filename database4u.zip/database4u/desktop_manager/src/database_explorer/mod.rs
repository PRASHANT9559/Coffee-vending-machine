use crate::api_client::models::{ConnectionProfileDto, DatabaseDto, TableDto};
use crate::api_client::{ApiClient, ApiError};

pub struct DatabaseExplorerController;

impl DatabaseExplorerController {
    pub async fn load_connections(api: &ApiClient) -> Result<Vec<ConnectionProfileDto>, ApiError> {
        api.list_connections().await
    }

    pub async fn test_connection(api: &ApiClient, connection_id: &str) -> Result<(), ApiError> {
        api.test_connection(connection_id).await
    }

    pub async fn connect_connection(api: &ApiClient, connection_id: &str) -> Result<(), ApiError> {
        api.connect_connection(connection_id).await
    }

    pub async fn load_databases(api: &ApiClient) -> Result<Vec<DatabaseDto>, ApiError> {
        api.list_databases().await
    }

    pub async fn load_tables(api: &ApiClient, database_id: &str) -> Result<Vec<TableDto>, ApiError> {
        api.list_tables_for_database(database_id).await
    }
}
