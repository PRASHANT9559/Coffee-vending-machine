slint::include_modules!();

use slint::{ComponentHandle, ModelRc, SharedString, VecModel};
use std::rc::Rc;
use std::sync::Arc;

use desktop_manager::api_client::ApiClient;
use desktop_manager::app_state::AppState;
use desktop_manager::auth::AuthManager;
use desktop_manager::components::format_bytes;
use desktop_manager::database_explorer::DatabaseExplorerController;
use desktop_manager::error_handling::format_ui_error;
use desktop_manager::file_manager::FileManagerController;
use desktop_manager::uploads::UploadManager;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let main_window = MainWindow::new()?;
    let state = Arc::new(AppState::new("http://127.0.0.1:8080"));

    // 1. Login callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_login_requested(move |server_url, username, password| {
            let window_weak = window_weak.clone();
            let state = state.clone();
            let server_url = server_url.to_string();
            let username = username.to_string();
            let password = password.to_string();

            if let Some(win) = window_weak.upgrade() {
                win.set_login_loading(true);
                win.set_login_error("".into());
            }

            tokio::spawn(async move {
                let res = AuthManager::login(&state.api, &server_url, &username, &password).await;

                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(win) = window_weak.upgrade() {
                        win.set_login_loading(false);
                        match res {
                            Ok(login_data) => {
                                win.set_is_logged_in(true);
                                win.set_username(login_data.user.username.into());
                                win.set_login_error("".into());
                            }
                            Err(e) => {
                                win.set_login_error(format_ui_error(&e).into());
                            }
                        }
                    }
                });
            });
        });
    }

    // 2. Logout callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_logout_requested(move || {
            let state = state.clone();
            let window_weak = window_weak.clone();

            tokio::spawn(async move {
                AuthManager::logout(&state.api).await;

                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(win) = window_weak.upgrade() {
                        win.set_is_logged_in(false);
                    }
                });
            });
        });
    }

    // 3. Refresh database explorer callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_refresh_database_explorer(move || {
            let window_weak = window_weak.clone();
            let state = state.clone();

            tokio::spawn(async move {
                let res = DatabaseExplorerController::load_connections(&state.api).await;

                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(win) = window_weak.upgrade() {
                        if let Ok(conns) = res {
                            let items: Vec<ConnectionItem> = conns
                                .into_iter()
                                .map(|c| ConnectionItem {
                                    id: c.connection_id.to_string().into(),
                                    name: c.display_name.into(),
                                    host: format!("{}:{}", c.host, c.port).into(),
                                    status: c.state.into(),
                                })
                                .collect();
                            win.set_connections(ModelRc::new(VecModel::from(items)));
                        }
                    }
                });
            });
        });
    }

    // 4. Test connection callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_test_connection(move |conn_id| {
            let window_weak = window_weak.clone();
            let state = state.clone();
            let conn_id = conn_id.to_string();

            tokio::spawn(async move {
                let res = DatabaseExplorerController::test_connection(&state.api, &conn_id).await;

                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(win) = window_weak.upgrade() {
                        match res {
                            Ok(_) => win.set_db_status("Connection test succeeded!".into()),
                            Err(e) => win.set_db_status(format!("Test failed: {}", format_ui_error(&e)).into()),
                        }
                    }
                });
            });
        });
    }

    // 5. Connect connection callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_connect_connection(move |conn_id| {
            let window_weak = window_weak.clone();
            let state = state.clone();
            let conn_id = conn_id.to_string();

            tokio::spawn(async move {
                let res = DatabaseExplorerController::connect_connection(&state.api, &conn_id).await;
                let dbs = DatabaseExplorerController::load_databases(&state.api).await;

                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(win) = window_weak.upgrade() {
                        match res {
                            Ok(_) => {
                                win.set_db_status("Connected successfully.".into());
                                if let Ok(dbs_list) = dbs {
                                    let db_names: Vec<SharedString> =
                                        dbs_list.into_iter().map(|d| d.name.into()).collect();
                                    win.set_databases(ModelRc::new(VecModel::from(db_names)));
                                }
                            }
                            Err(e) => win.set_db_status(format!("Connect failed: {}", format_ui_error(&e)).into()),
                        }
                    }
                });
            });
        });
    }

    // 6. Refresh files callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_refresh_files(move || {
            let window_weak = window_weak.clone();
            let state = state.clone();

            tokio::spawn(async move {
                let proj_id = *state.current_project_id.read().await;
                if let Some(pid) = proj_id {
                    let files_res = FileManagerController::load_files(&state.api, pid).await;
                    let quota_res = FileManagerController::load_quota_usage(&state.api, pid).await;

                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(win) = window_weak.upgrade() {
                            if let Ok(files) = files_res {
                                let items: Vec<FileItem> = files
                                    .into_iter()
                                    .map(|f| FileItem {
                                        id: f.file_id.to_string().into(),
                                        name: f.original_name.into(),
                                        media_type: f.media_type.into(),
                                        size_formatted: format_bytes(f.size_bytes).into(),
                                        created_at: f.created_at.into(),
                                        status: f.status.into(),
                                    })
                                    .collect();
                                win.set_files(ModelRc::new(VecModel::from(items)));
                            }

                            if let Ok(q) = quota_res {
                                win.set_quota_used(format_bytes(q.used_bytes).into());
                                if let Some(limit) = q.quota_bytes {
                                    win.set_quota_limit(format_bytes(limit).into());
                                    let progress = (q.used_bytes as f32 / limit as f32).clamp(0.0, 1.0);
                                    win.set_quota_progress(progress);
                                }
                            }
                        }
                    });
                }
            });
        });
    }

    // 7. Delete file callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_delete_file(move |file_id| {
            let state = state.clone();
            let file_id = file_id.to_string();

            tokio::spawn(async move {
                let _ = FileManagerController::delete_file(&state.api, &file_id).await;
            });
        });
    }

    // 8. Start upload callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_start_upload(move |path| {
            let window_weak = window_weak.clone();
            let state = state.clone();
            let path_str = path.to_string();

            tokio::spawn(async move {
                let proj_id = *state.current_project_id.read().await;
                if let Some(pid) = proj_id {
                    let w_weak = window_weak.clone();
                    let _ = UploadManager::upload_file(&state.api, pid, &path_str, move |sent, total| {
                        let w_weak = w_weak.clone();
                        let _ = slint::invoke_from_event_loop(move || {
                            if let Some(win) = w_weak.upgrade() {
                                let progress = (sent as f32 / total as f32).clamp(0.0, 1.0);
                                let task = UploadTaskItem {
                                    id: "upload-1".into(),
                                    filename: "uploading...".into(),
                                    progress,
                                    progress_text: format!("{}%", (progress * 100.0) as i32).into(),
                                    status: if progress >= 1.0 { "completed".into() } else { "uploading".into() },
                                };
                                win.set_upload_tasks(ModelRc::new(VecModel::from(vec![task])));
                            }
                        });
                    })
                    .await;
                }
            });
        });
    }

    // 9. Refresh audit callback
    {
        let window_weak = main_window.as_weak();
        let state = state.clone();

        main_window.on_refresh_audit(move || {
            let window_weak = window_weak.clone();
            let state = state.clone();

            tokio::spawn(async move {
                let proj_id = *state.current_project_id.read().await;
                if let Some(pid) = proj_id {
                    let res = state.api.list_audit_entries(pid).await;

                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(win) = window_weak.upgrade() {
                            if let Ok(page) = res {
                                let entries: Vec<AuditRowItem> = page
                                    .items
                                    .into_iter()
                                    .map(|e| AuditRowItem {
                                        id: e.log_id.to_string().into(),
                                        action: e.action.into(),
                                        target_resource: e.target_resource.into(),
                                        status: e.status.into(),
                                        created_at: e.created_at.into(),
                                    })
                                    .collect();
                                win.set_audit_entries(ModelRc::new(VecModel::from(entries)));
                            }
                        }
                    });
                }
            });
        });
    }

    main_window.run()?;
    Ok(())
}
