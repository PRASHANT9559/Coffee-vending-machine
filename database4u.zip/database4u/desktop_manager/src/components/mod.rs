/// Format bytes into human-readable representation.
pub fn format_bytes(bytes: i64) -> String {
    let b = bytes.max(0) as f64;
    const KB: f64 = 1024.0;
    const MB: f64 = KB * 1024.0;
    const GB: f64 = MB * 1024.0;

    if b >= GB {
        format!("{:.2} GB", b / GB)
    } else if b >= MB {
        format!("{:.1} MB", b / MB)
    } else if b >= KB {
        format!("{:.0} KB", b / KB)
    } else {
        format!("{} B", bytes)
    }
}

/// Format row count for table preview.
pub fn format_row_count(count: Option<i64>) -> String {
    match count {
        Some(c) => c.to_string(),
        None => "—".to_string(),
    }
}
