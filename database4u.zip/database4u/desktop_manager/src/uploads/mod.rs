use std::path::Path;
use tokio::fs::File;
use tokio::io::AsyncReadExt;
use uuid::Uuid;

use crate::api_client::models::FileDto;
use crate::api_client::{ApiClient, ApiError};

const CHUNK_SIZE: usize = 5 * 1024 * 1024; // 5 MB chunks

pub struct UploadManager;

impl UploadManager {
    /// Perform an end-to-end chunked upload of a local file to the backend file storage system.
    pub async fn upload_file<F>(
        api: &ApiClient,
        project_id: Uuid,
        file_path_str: &str,
        mut progress_cb: F,
    ) -> Result<FileDto, ApiError>
    where
        F: FnMut(i64, i64) + Send + 'static,
    {
        let path = Path::new(file_path_str);
        let mut file = File::open(path).await.map_err(|e| {
            ApiError::Serialization(format!("cannot open file '{}': {e}", file_path_str))
        })?;

        let metadata = file.metadata().await.map_err(|e| {
            ApiError::Serialization(format!("cannot read file metadata: {e}"))
        })?;
        let total_size = metadata.len() as i64;

        let filename = path
            .file_name()
            .map(|s| s.to_string_lossy().to_string())
            .unwrap_or_else(|| "uploaded_file.bin".to_string());

        let media_type = mime_guess_simple(&filename);

        // 1. Create upload session
        let session = api
            .create_upload_session(project_id, &filename, media_type, total_size)
            .await?;

        // 2. Stream chunk parts
        let mut buffer = vec![0u8; CHUNK_SIZE];
        let mut sent_bytes: i64 = 0;

        loop {
            let n = file.read(&mut buffer).await.map_err(|e| {
                ApiError::Serialization(format!("read error during chunk upload: {e}"))
            })?;
            if n == 0 {
                break;
            }

            let chunk_data = buffer[..n].to_vec();
            if let Err(e) = api.upload_part_chunk(session.session_id, chunk_data).await {
                // Abort session on failure
                let _ = api.abort_upload_session(session.session_id).await;
                return Err(e);
            }

            sent_bytes += n as i64;
            progress_cb(sent_bytes, total_size);
        }

        // 3. Complete session
        let ready_file = api.complete_upload_session(session.session_id).await?;
        Ok(ready_file)
    }
}

fn mime_guess_simple(filename: &str) -> &'static str {
    let lower = filename.to_lowercase();
    if lower.ends_with(".png") {
        "image/png"
    } else if lower.ends_with(".jpg") || lower.ends_with(".jpeg") {
        "image/jpeg"
    } else if lower.ends_with(".gif") {
        "image/gif"
    } else if lower.ends_with(".pdf") {
        "application/pdf"
    } else if lower.ends_with(".zip") {
        "application/zip"
    } else if lower.ends_with(".mp4") {
        "video/mp4"
    } else if lower.ends_with(".json") {
        "application/json"
    } else if lower.ends_with(".txt") {
        "text/plain"
    } else {
        "application/octet-stream"
    }
}
