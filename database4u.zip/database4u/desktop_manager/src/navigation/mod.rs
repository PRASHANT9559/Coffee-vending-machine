#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Route {
    Login,
    DatabaseExplorer,
    FileManager,
    Uploads,
    Audit,
}

impl Route {
    pub fn from_tab_index(index: i32) -> Self {
        match index {
            0 => Self::DatabaseExplorer,
            1 => Self::FileManager,
            2 => Self::Uploads,
            3 => Self::Audit,
            _ => Self::DatabaseExplorer,
        }
    }

    pub fn to_tab_index(&self) -> i32 {
        match self {
            Self::Login => -1,
            Self::DatabaseExplorer => 0,
            Self::FileManager => 1,
            Self::Uploads => 2,
            Self::Audit => 3,
        }
    }
}
