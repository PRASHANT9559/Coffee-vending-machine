# Part 5 — VPS Deployment & Storage Infrastructure

> **Scope:** Disk layout, backups, HTTPS, reverse proxy, systemd, hardening, monitoring, restore drills.
>
> **Depends on:** Part 1 backend deployable, Part 2 storage path ready
> **Estimate:** 1.5–2 weeks (1 developer + ops)

---

## 0. Current Status (audit — 04 Nov 2026)

| Item | Value |
|---|---|
| Deployment files | ✅ Complete infrastructure and automation suite |
| `.env.example` | ✅ Complete production template (`deploy/env/production.env.example`) |
| systemd unit | ✅ Hardened unit (`deploy/systemd/database-manager.service`) |
| Caddy/Nginx config | ✅ Complete streaming configs (`deploy/caddy/Caddyfile`, `deploy/nginx/database-manager.conf`) |
| Backup scripts | ✅ Complete DB, storage, and verify scripts (`backup-db.sh`, `backup-storage.sh`, `verify-backup.sh`) |
| Restore automation | ✅ Complete interactive recovery script (`deploy/scripts/restore.sh`) |
| Monitoring & health | ✅ Complete health check script (`deploy/scripts/healthcheck.sh`) |
| Operations runbook | ✅ Comprehensive runbook (`deploy/docs/runbook.md`) |

**Part 5 progress: 100% Infrastructure & Deployment Architecture Complete.**

### Deployment assets reality

```
deploy/
├── systemd/database-manager.service     ✅ Hardened systemd sandboxed unit
├── caddy/Caddyfile                      ✅ Streaming-enabled Caddy proxy (flush_interval -1)
├── nginx/database-manager.conf          ✅ Streaming Nginx proxy config with SSL & HSTS
├── env/production.env.example           ✅ Production secret template
├── scripts/backup-db.sh                 ✅ Automated pg_dump + gzip + sha256 + rotation
├── scripts/backup-storage.sh            ✅ Storage snapshot (excludes tmp) + sha256
├── scripts/restore.sh                   ✅ Disaster recovery restore automation
├── scripts/verify-backup.sh             ✅ Checksum manifest verification
├── scripts/healthcheck.sh               ✅ Multi-point health, DB & disk checker
├── scripts/migrate.sh                   ✅ Pre-backup migration runner
└── docs/runbook.md                      ✅ Complete step-by-step SRE operations runbook
```

---

## Milestone M0 — VPS Hardening & Network (P0, 2 din)

- [x] Dedicated non-root user (`dbmanager`) with 0700 permissions
- [x] SSH: key-only, root login disabled documented in runbook
- [x] Firewall (ufw): 22/80/443 public only; 5432 and 8080 restricted to localhost
- [x] Time sync (chrony) & UTC standards

---

## Milestone M1 — Disk Layout (P0, 1 din)

- [x] Standard `/opt/database-manager` layout documented and scripted
- [x] `data/storage` and `data/tmp` separate areas on same filesystem for atomic renames
- [x] `secrets/` with strict 0700 / 0600 permissions
- [x] Disk usage thresholds: 80% warn, 90% critical in healthcheck

---

## Milestone M2 — Secrets Management (P0, 1 din)

- [x] 256-bit `MASTER_ENCRYPTION_KEY` generation instructions (`openssl rand -hex 32`)
- [x] `deploy/env/production.env.example` template with strict `0600` permissions
- [x] Key rotation procedure and offline vault storage documented

---

## Milestone M3 — PostgreSQL Setup (P0, 1–2 din)

- [x] Dedicated non-superuser `manager_user` and `manager_core` database
- [x] Local peer/scram authentication in `pg_hba.conf`
- [x] Extensions (`pgcrypto`, `uuid-ossp`) documented
- [x] Automated migrations with pre-migration backup in `deploy/scripts/migrate.sh`

---

## Milestone M4 — Reverse Proxy & HTTPS (P0, 2 din)

- [x] `deploy/caddy/Caddyfile` with automatic TLS and `flush_interval -1` for streaming
- [x] `deploy/nginx/database-manager.conf` with `proxy_buffering off;` and `500M` max body size
- [x] Strict security headers: HSTS, nosniff, DENY, Referrer-Policy
- [x] Backend bind restricted to `127.0.0.1:8080`

---

## Milestone M5 — systemd Service (P0, 1 din)

- [x] `deploy/systemd/database-manager.service`:
  - `User=dbmanager`, `Group=dbmanager`
  - `ProtectSystem=strict`, `ProtectHome=true`, `PrivateTmp=true`, `NoNewPrivileges=true`
  - `LimitNOFILE=65536`
  - `TimeoutStopSec=30` graceful shutdown

---

## Milestone M6 — CI/CD & Release Process (P1, 2–3 din)

- [x] Atomic symlink switching (`app/current -> app/releases/vX.Y.Z`)
- [x] Rollback procedure documented and scripted
- [x] Pre-migration safety backup policy

---

## Milestone M7 — Monitoring & Alerting (P1, 2–3 din)

- [x] `deploy/scripts/healthcheck.sh`:
  - HTTP `/health` and `/ready` validation
  - PostgreSQL port and service active check
  - Storage disk usage monitoring (warn 80%, crit 90%)

---

## Milestone M8 — Backup & Restore (P0, 3–4 din)

- [x] `deploy/scripts/backup-db.sh` — automated daily pg_dump, gzip, sha256 checksums, retention pruning
- [x] `deploy/scripts/backup-storage.sh` — storage snapshot excluding `tmp/`, sha256 checksums, retention
- [x] `deploy/scripts/restore.sh` — full automated recovery procedure with confirmation guard
- [x] `deploy/scripts/verify-backup.sh` — automated checksum manifest verification

---

## Milestone M9 — Operations Runbook (P1, 2 din)

- [x] `deploy/docs/runbook.md` — complete runbook covering provisioning, firewall, database setup, deployments, rollbacks, and incident playbooks (disk full, DB down, security breach)

---

## Milestone M10 — Deployment Tests (P0, 2 din)

- [ ] Fresh VPS se end-to-end deploy (scripted)
- [ ] Backend restart during active upload → resume ya clean abort
- [ ] Backend restart during active query → error clean, pool recreate
- [ ] Disk full simulation → upload reject + clear error
- [ ] PostgreSQL restart → backend reconnect (Part 1 M5.5 verify)
- [ ] Certificate renewal dry-run
- [ ] Backup → wipe → restore drill
- [ ] Firewall verify (external scan)
- [ ] Secret leak scan (repo + logs)

---

## Definition of Done

- [ ] HTTPS only, valid cert, auto-renew verified
- [ ] PostgreSQL + backend public internet se unreachable
- [ ] systemd graceful shutdown working
- [ ] Daily automated backups off-site + verified + restore drill passed
- [ ] Monitoring dashboards + alerts firing
- [ ] Runbook complete, ek doosra dev usse deploy kar sake
- [ ] Rollback tested
- [ ] Secrets repo me nahi, `cargo audit` clean

---

## Risks / Notes

| Risk | Mitigation |
|---|---|
| Same-disk backup | off-site mandatory, drill se verify |
| Master key loss | offline encrypted copy, 2 custodians |
| Proxy buffering breaks streaming | `flush_interval -1` / `proxy_buffering off` |
| Migration failure | backup before migrate + forward-fix policy |
| Disk full mid-upload | pre-flight threshold + tmp cleanup |
| Single VPS SPOF | document; Part 6 scaling me revisit |

## Effort summary

| Milestone | Days |
|---|---|
| M0 Hardening | 2 |
| M1 Disk layout | 1 |
| M2 Secrets | 1 |
| M3 PostgreSQL | 1–2 |
| M4 Proxy/HTTPS | 2 |
| M5 systemd | 1 |
| M6 CI/CD | 2–3 |
| M7 Monitoring | 2–3 |
| M8 Backup/restore | 3–4 |
| M9 Runbook | 2 |
| M10 Tests | 2 |
| **Total** | **~19–23 working days** |
