#!/usr/bin/env bash
# =====================================================================
# Database4U — Disaster Recovery & Database/Storage Restore Script
# Usage: sudo ./restore.sh <path-to-db-backup.sql.gz> <path-to-storage-backup.tar.gz>
# =====================================================================

set -euo pipefail

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <db_backup.sql.gz> <storage_backup.tar.gz>" >&2
    exit 1
fi

DB_BACKUP="$1"
STORAGE_BACKUP="$2"
ENV_FILE="/opt/database-manager/secrets/production.env"
DATA_DIR="/opt/database-manager/data"

if [ ! -f "$DB_BACKUP" ]; then
    echo "ERROR: DB backup file '$DB_BACKUP' not found!" >&2
    exit 1
fi

if [ ! -f "$STORAGE_BACKUP" ]; then
    echo "ERROR: Storage backup file '$STORAGE_BACKUP' not found!" >&2
    exit 1
fi

# Load environment
if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
else
    echo "ERROR: Environment file $ENV_FILE not found!" >&2
    exit 1
fi

# Verify checksums if present
if [ -f "${DB_BACKUP}.sha256" ]; then
    echo "Verifying DB backup checksum..."
    sha256sum -c "${DB_BACKUP}.sha256"
fi

if [ -f "${STORAGE_BACKUP}.sha256" ]; then
    echo "Verifying storage backup checksum..."
    sha256sum -c "${STORAGE_BACKUP}.sha256"
fi

echo "=========================================================="
echo "WARNING: This will STOP the service and RESTORE data!"
echo "Database backup: $DB_BACKUP"
echo "Storage backup:  $STORAGE_BACKUP"
echo "Target DB:       $DATABASE_URL"
echo "=========================================================="
read -p "Type 'RESTORE-CONFIRM' to proceed: " CONFIRMATION

if [ "$CONFIRMATION" != "RESTORE-CONFIRM" ]; then
    echo "Aborted by user."
    exit 0
fi

echo "[1/4] Stopping database-manager service..."
systemctl stop database-manager || true

echo "[2/4] Restoring PostgreSQL database..."
gunzip -c "$DB_BACKUP" | psql "$DATABASE_URL"

echo "[3/4] Restoring storage files..."
mkdir -p "${DATA_DIR}/storage" "${DATA_DIR}/tmp"
tar -xzf "$STORAGE_BACKUP" -C "$DATA_DIR"
chown -R dbmanager:dbmanager "$DATA_DIR"
chmod 700 "${DATA_DIR}/storage" "${DATA_DIR}/tmp"

echo "[4/4] Starting database-manager service..."
systemctl start database-manager

echo "Checking health status..."
sleep 2
curl -sf http://127.0.0.1:8080/health || {
    echo "ERROR: Service failed to report healthy status after restore!" >&2
    exit 1
}

echo "RESTORE COMPLETED SUCCESSFULLY."
