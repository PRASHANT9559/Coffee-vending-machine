#!/usr/bin/env bash
# =====================================================================
# Database4U — Automated PostgreSQL Database Backup Script
# Usage: ./backup-db.sh
# Cron:  0 2 * * * /opt/database-manager/scripts/backup-db.sh >> /opt/database-manager/logs/backup.log 2>&1
# =====================================================================

set -euo pipefail

BACKUP_ROOT="/opt/database-manager/backup/postgres"
ENV_FILE="/opt/database-manager/secrets/production.env"
TIMESTAMP=$(date -u +"%Y%m%d_%H%M%SZ")
BACKUP_FILE="${BACKUP_ROOT}/db_manager_core_${TIMESTAMP}.sql.gz"
RETENTION_DAYS=7

# Load environment
if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
else
    echo "ERROR: Environment file $ENV_FILE not found!" >&2
    exit 1
fi

mkdir -p "$BACKUP_ROOT"
chmod 700 "$BACKUP_ROOT"

echo "[$(date -u)] Starting PostgreSQL logical dump..."

# Dump and compress database
pg_dump "$DATABASE_URL" \
    --format=plain \
    --no-owner \
    --no-privileges \
    --clean \
    --if-exists \
    | gzip -9 > "$BACKUP_FILE"

chmod 600 "$BACKUP_FILE"

# Generate SHA-256 checksum manifest
sha256sum "$BACKUP_FILE" > "${BACKUP_FILE}.sha256"
chmod 600 "${BACKUP_FILE}.sha256"

BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
echo "[$(date -u)] Database backup completed successfully: $BACKUP_FILE ($BACKUP_SIZE)"

# Prune old backups older than retention days
echo "[$(date -u)] Pruning backups older than $RETENTION_DAYS days..."
find "$BACKUP_ROOT" -type f \( -name "*.sql.gz" -o -name "*.sha256" \) -mtime "+$RETENTION_DAYS" -exec rm -f {} +

echo "[$(date -u)] Database backup and cleanup finished."
