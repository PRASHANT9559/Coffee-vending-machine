#!/usr/bin/env bash
# =====================================================================
# Database4U — Backup Integrity & Checksum Verification Script
# Usage: ./verify-backup.sh
# =====================================================================

set -euo pipefail

BACKUP_ROOT="/opt/database-manager/backup"
FAILED=0

echo "=== Verifying Database4U Backups at $(date -u) ==="

# Check PostgreSQL backup checksums
echo "Checking PostgreSQL backup checksums..."
for sha_file in $(find "${BACKUP_ROOT}/postgres" -maxdepth 1 -type f -name "*.sha256" 2>/dev/null); do
    archive="$(dirname "$sha_file")/$(basename "$sha_file" .sha256)"
    if [ -f "$archive" ]; then
        if sha256sum -c "$sha_file" --status; then
            echo "  [OK] $(basename "$archive")"
        else
            echo "  [FAIL] Checksum mismatch: $(basename "$archive")" >&2
            FAILED=1
        fi
    else
        echo "  [WARN] Missing archive for: $sha_file" >&2
        FAILED=1
    fi
done

# Check Storage backup checksums
echo "Checking File Storage backup checksums..."
for sha_file in $(find "${BACKUP_ROOT}/storage" -maxdepth 1 -type f -name "*.sha256" 2>/dev/null); do
    archive="$(dirname "$sha_file")/$(basename "$sha_file" .sha256)"
    if [ -f "$archive" ]; then
        if sha256sum -c "$sha_file" --status; then
            echo "  [OK] $(basename "$archive")"
        else
            echo "  [FAIL] Checksum mismatch: $(basename "$archive")" >&2
            FAILED=1
        fi
    else
        echo "  [WARN] Missing archive for: $sha_file" >&2
        FAILED=1
    fi
done

if [ "$FAILED" -eq 0 ]; then
    echo "=== ALL BACKUP CHECKSUMS VERIFIED SUCCESSFULLY ==="
    exit 0
else
    echo "=== BACKUP INTEGRITY VERIFICATION FAILED ===" >&2
    exit 1
fi
