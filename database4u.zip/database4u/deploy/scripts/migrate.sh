#!/usr/bin/env bash
# =====================================================================
# Database4U — Database Migration Runner Script
# Takes an automatic pre-migration backup before applying migrations
# Usage: ./migrate.sh
# =====================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="/opt/database-manager/secrets/production.env"

# Load environment
if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
elif [ -f ".env" ]; then
    set -a
    source ".env"
    set +a
else
    echo "ERROR: Environment file not found!" >&2
    exit 1
fi

echo "[1/2] Taking safety pre-migration database backup..."
if [ -x "${SCRIPT_DIR}/backup-db.sh" ]; then
    "${SCRIPT_DIR}/backup-db.sh"
fi

echo "[2/2] Applying database migrations..."
# Check for sqlx binary or apply sql scripts sequentially
MIGRATIONS_DIR="${SCRIPT_DIR}/../../database-manager/migrations"
if [ ! -d "$MIGRATIONS_DIR" ]; then
    MIGRATIONS_DIR="/opt/database-manager/app/current/migrations"
fi

if command -v sqlx >/dev/null 2>&1; then
    sqlx migrate run --source "$MIGRATIONS_DIR" --database-url "$DATABASE_URL"
else
    echo "sqlx CLI not found in PATH; applying SQL files via psql..."
    for sql_file in $(ls -1 "$MIGRATIONS_DIR"/*.sql | sort); do
        echo "Applying: $(basename "$sql_file")"
        psql "$DATABASE_URL" -f "$sql_file"
    done
fi

echo "Migrations successfully applied."
