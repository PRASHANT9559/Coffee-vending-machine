#!/usr/bin/env bash
# =====================================================================
# Database4U — Automated Storage Snapshot Backup Script
# Backs up the permanent file storage directory (excludes temporary uploads)
# Usage: ./backup-storage.sh
# Cron:  30 2 * * * /opt/database-manager/scripts/backup-storage.sh >> /opt/database-manager/logs/backup.log 2>&1
# =====================================================================

set -euo pipefail

STORAGE_DIR="/opt/database-manager/data/storage"
BACKUP_ROOT="/opt/database-manager/backup/storage"
TIMESTAMP=$(date -u +"%Y%m%d_%H%M%SZ")
ARCHIVE_FILE="${BACKUP_ROOT}/storage_${TIMESTAMP}.tar.gz"
RETENTION_DAYS=7

mkdir -p "$BACKUP_ROOT"
chmod 700 "$BACKUP_ROOT"

if [ ! -d "$STORAGE_DIR" ]; then
    echo "ERROR: Storage directory $STORAGE_DIR does not exist!" >&2
    exit 1
fi

echo "[$(date -u)] Starting file storage snapshot backup..."

# Create tar.gz archive excluding any temporary files
tar -czf "$ARCHIVE_FILE" \
    --exclude="*/tmp/*" \
    --exclude="*.tmp" \
    -C "$(dirname "$STORAGE_DIR")" \
    "$(basename "$STORAGE_DIR")"

chmod 600 "$ARCHIVE_FILE"

# Calculate checksum
sha256sum "$ARCHIVE_FILE" > "${ARCHIVE_FILE}.sha256"
chmod 600 "${ARCHIVE_FILE}.sha256"

ARCHIVE_SIZE=$(du -h "$ARCHIVE_FILE" | cut -f1)
echo "[$(date -u)] Storage backup completed: $ARCHIVE_FILE ($ARCHIVE_SIZE)"

# Prune old archives
find "$BACKUP_ROOT" -type f \( -name "*.tar.gz" -o -name "*.sha256" \) -mtime "+$RETENTION_DAYS" -exec rm -f {} +

echo "[$(date -u)] Storage backup cycle finished."
