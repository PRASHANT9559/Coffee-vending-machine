#!/usr/bin/env bash
# =====================================================================
# Database4U — Node & Service Healthcheck Script
# Usage: ./healthcheck.sh
# Suitable for cron or external monitoring agents (Consul, Nagios, Uptime)
# =====================================================================

set -euo pipefail

STATUS=0

echo "=== Database4U Health Check: $(date -u) ==="

# 1. Check HTTP health endpoint
echo -n "Checking backend HTTP /health... "
HEALTH_RESPONSE=$(curl -sf -m 5 http://127.0.0.1:8080/health 2>/dev/null || echo "FAILED")
if [ "$HEALTH_RESPONSE" = "FAILED" ]; then
    echo "ERROR (HTTP /health unreachable)"
    STATUS=1
else
    echo "OK"
fi

# 2. Check HTTP readiness endpoint
echo -n "Checking backend HTTP /ready... "
READY_RESPONSE=$(curl -sf -m 5 http://127.0.0.1:8080/ready 2>/dev/null || echo "FAILED")
if [ "$READY_RESPONSE" = "FAILED" ]; then
    echo "ERROR (Database not ready or disconnected)"
    STATUS=1
else
    echo "OK"
fi

# 3. Check systemd unit status
echo -n "Checking systemd service... "
if systemctl is-active --quiet database-manager 2>/dev/null; then
    echo "OK (active)"
else
    echo "WARN (service not active or not running under systemd)"
fi

# 4. Check disk usage on storage volume
echo -n "Checking storage disk capacity... "
DISK_USAGE=$(df -h /opt/database-manager/data 2>/dev/null | awk 'NR==2 {print $5}' | tr -d '%')
if [ -n "$DISK_USAGE" ]; then
    if [ "$DISK_USAGE" -ge 90 ]; then
        echo "CRITICAL (${DISK_USAGE}% full >= 90%)"
        STATUS=1
    elif [ "$DISK_USAGE" -ge 80 ]; then
        echo "WARNING (${DISK_USAGE}% full >= 80%)"
    else
        echo "OK (${DISK_USAGE}% full)"
    fi
else
    echo "UNKNOWN"
fi

echo "=========================================="
if [ "$STATUS" -eq 0 ]; then
    echo "Healthcheck: ALL SYSTEMS HEALTHY"
    exit 0
else
    echo "Healthcheck: CRITICAL FAILURES DETECTED"
    exit 1
fi
