# Database4U — Production Operations & Deployment Runbook

> **Target Audience:** Site Reliability Engineers, DevOps, and Platform Engineers maintaining Database4U infrastructure.

---

## 1. Architecture & Directory Layout

The application runs on Linux (Ubuntu 22.04+ or Debian 12+) using a dedicated, non-root user `dbmanager`.

```
/opt/database-manager/
├── app/
│   ├── current -> releases/v1.0.0      # Active release symlink
│   └── releases/
│       ├── v1.0.0/                     # Immutable release binaries
│       └── v1.0.1/
├── data/
│   ├── storage/                        # Permanent opaque file storage (0700, dbmanager:dbmanager)
│   └── tmp/                            # Temporary upload chunks (same filesystem for atomic rename)
├── logs/                               # Application and reverse proxy logs (logrotate managed)
├── backup/
│   ├── postgres/                       # Daily logical database dumps
│   └── storage/                        # Storage snapshots
├── secrets/
│   └── production.env                  # Secrets configuration (0600, dbmanager:dbmanager)
└── scripts/                            # Operational automation scripts
```

---

## 2. Initial VPS Provisioning & Hardening

### Step 2.1: System User
```bash
sudo useradd -r -s /usr/sbin/nologin -d /opt/database-manager dbmanager
sudo mkdir -p /opt/database-manager/{app/releases,data/storage,data/tmp,logs,backup/postgres,backup/storage,secrets,scripts}
sudo chown -R dbmanager:dbmanager /opt/database-manager
sudo chmod 700 /opt/database-manager/{data/storage,data/tmp,secrets,backup}
```

### Step 2.2: Firewall & Network Isolation
Only ports `22` (SSH), `80` (HTTP), and `443` (HTTPS) must be accessible from the public internet. PostgreSQL (port 5432) and backend internal port (8080) **must remain strictly on localhost**.

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### Step 2.3: SSH Hardening
Edit `/etc/ssh/sshd_config`:
```ini
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
```
Restart SSH: `sudo systemctl restart ssh`

---

## 3. Database Setup (PostgreSQL)

Create non-superuser service account and database:

```bash
sudo -u postgres psql
```
```sql
CREATE DATABASE manager_core;
CREATE USER manager_user WITH ENCRYPTED PASSWORD 'YOUR_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE manager_core TO manager_user;
ALTER DATABASE manager_core OWNER TO manager_user;
\c manager_core
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
\q
```

Ensure `/etc/postgresql/<version>/main/pg_hba.conf` binds to `127.0.0.1` only:
```
host    manager_core    manager_user    127.0.0.1/32    scram-sha-256
```

---

## 4. Secrets Generation & Configuration

Generate the 256-bit Master Encryption Key:
```bash
openssl rand -hex 32
```

Create `/opt/database-manager/secrets/production.env` from [`deploy/env/production.env.example`](file:///sdcard/download/project/database4u/deploy/env/production.env.example):
```bash
sudo cp deploy/env/production.env.example /opt/database-manager/secrets/production.env
sudo chown dbmanager:dbmanager /opt/database-manager/secrets/production.env
sudo chmod 600 /opt/database-manager/secrets/production.env
# Edit production.env with your real DB password and generated MASTER_ENCRYPTION_KEY
```

> ⚠️ **CRITICAL:** Store an offline, encrypted copy of `MASTER_ENCRYPTION_KEY` in a secure vault (e.g. 1Password / HashiCorp Vault). If this key is lost, encrypted database connection credentials cannot be decrypted.

---

## 5. Reverse Proxy Setup (Caddy or Nginx)

### Option A: Caddy (Recommended)
```bash
sudo apt install -y caddy
sudo cp deploy/caddy/Caddyfile /etc/caddy/Caddyfile
# Edit your domain in /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

### Option B: Nginx
```bash
sudo cp deploy/nginx/database-manager.conf /etc/nginx/sites-available/database-manager.conf
sudo ln -s /etc/nginx/sites-available/database-manager.conf /etc/nginx/sites-enabled/
sudo certbot --nginx -d api.database4u.example.com
sudo systemctl reload nginx
```

---

## 6. Service Installation & Deployment

```bash
sudo cp deploy/systemd/database-manager.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now database-manager
```

Check logs:
```bash
journalctl -u database-manager -f
```

---

## 7. Zero-Downtime Deployment & Rollback

### Deploying a New Release:
1. Copy compiled binary to release directory:
   ```bash
   mkdir -p /opt/database-manager/app/releases/v1.0.1
   cp database-manager /opt/database-manager/app/releases/v1.0.1/
   ```
2. Run database migrations:
   ```bash
   /opt/database-manager/scripts/migrate.sh
   ```
3. Update symlink atomically:
   ```bash
   ln -sfn /opt/database-manager/app/releases/v1.0.1 /opt/database-manager/app/current
   ```
4. Restart service:
   ```bash
   sudo systemctl restart database-manager
   ```
5. Verify health:
   ```bash
   curl -sf http://127.0.0.1:8080/health
   ```

### Rollback Procedure:
If a release fails verification, instantly roll back symlink to previous release:
```bash
ln -sfn /opt/database-manager/app/releases/v1.0.0 /opt/database-manager/app/current
sudo systemctl restart database-manager
```

---

## 8. Backup & Disaster Recovery Runbook

### Automated Backups
Cron schedule in `/etc/cron.d/database-manager-backup`:
```cron
0 2 * * * dbmanager /opt/database-manager/scripts/backup-db.sh >> /opt/database-manager/logs/backup.log 2>&1
30 2 * * * dbmanager /opt/database-manager/scripts/backup-storage.sh >> /opt/database-manager/logs/backup.log 2>&1
```

### Complete Disaster Recovery Restore:
1. Verify checksums of latest offsite backup files.
2. Run the interactive restore script:
   ```bash
   sudo /opt/database-manager/scripts/restore.sh \
       /opt/database-manager/backup/postgres/db_manager_core_YYYYMMDD_HHMMSSZ.sql.gz \
       /opt/database-manager/backup/storage/storage_YYYYMMDD_HHMMSSZ.tar.gz
   ```

---

## 9. Troubleshooting & Incident Playbooks

### Playbook 1: Disk Full (>= 90%)
1. Clean expired upload chunks:
   ```bash
   find /opt/database-manager/data/tmp -type f -mtime +1 -delete
   ```
2. Clean rotated logs:
   ```bash
   find /opt/database-manager/logs -type f -name "*.gz" -delete
   ```
3. Verify disk space recovered: `df -h /opt/database-manager/data`

### Playbook 2: PostgreSQL Down or Connection Pool Exhausted
1. Check Postgres service: `sudo systemctl status postgresql`
2. Check database connection limits:
   ```sql
   SELECT count(*), state FROM pg_stat_activity GROUP BY state;
   ```
3. Restart backend service to recycle leaked connection handles: `sudo systemctl restart database-manager`

### Playbook 3: Suspected Security Compromise
1. Revoke all active user sessions:
   ```sql
   UPDATE sessions SET revoked_at = NOW() WHERE revoked_at IS NULL;
   UPDATE refresh_tokens SET revoked_at = NOW() WHERE revoked_at IS NULL;
   ```
2. Rotate `MASTER_ENCRYPTION_KEY`:
   - Re-encrypt target database credentials with new key.
   - Update `/opt/database-manager/secrets/production.env`.
   - Restart service: `sudo systemctl restart database-manager`.
