fn main() {
    // Tauri's build script generates the ACL/permission context only for the
    // desktop shell. CLI-only builds (Termux/CI) skip it so they don't need
    // WebKit/GTK or a frontend bundle.
    if std::env::var_os("CARGO_FEATURE_TAURI").is_some() {
        tauri_build::build();
    }
}
