//! Tauri IPC command handlers.
//! All commands are typed request/response pairs. No arbitrary execution.

use rusqlite::{params, OptionalExtension};
use serde::{Deserialize, Serialize};
use std::sync::{Arc, Mutex};
use tauri::State;

use crate::discovery::Discovery;
use crate::query::{compile_query, executor, QueryIntent, QueryIntentKind};
use crate::query::validator::ObjectAllowlist;
use crate::uiir::{default_dashboard_ir, UiIrDocument, Validator, UI_IR_VERSION};

// Re-export types for command signatures
pub use crate::engine::Engine;
pub use crate::storage::Store;

/// App state held by Tauri.
///
/// `rusqlite::Connection` is `Send` but not `Sync`, so the engine is wrapped
/// in a mutex rather than shared directly. All handlers are synchronous
/// inside the lock, so no guard is held across an `.await`.
pub struct AppState {
    pub engine: Arc<Mutex<Engine>>,
}

// ---------------------------------------------------------------------------
// Request / Response types
// ---------------------------------------------------------------------------

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateDashboardRequest {
    pub name: String,
    pub description: Option<String>,
    pub icon: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateDashboardResponse {
    pub dashboard_id: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ListDashboardsRequest {
    pub query: Option<String>,
    pub cursor: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ListDashboardsResponse {
    pub items: Vec<crate::storage::Dashboard>,
    pub next: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetDashboardRequest {
    pub dashboard_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GetDashboardResponse {
    pub dashboard: crate::storage::Dashboard,
    pub uiir: Option<serde_json::Value>,
    pub revision: i64,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveDashboardRequest {
    pub dashboard_id: String,
    pub name: Option<String>,
    pub description: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveDashboardResponse {
    pub dashboard_id: String,
    pub revision: i64,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DeleteDashboardRequest {
    pub dashboard_id: String,
    pub confirm_name: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DeleteDashboardResponse {
    pub ok: bool,
}

#[derive(Debug, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct ListDataSourcesRequest {}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ListDataSourcesResponse {
    pub items: Vec<crate::storage::DataSource>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateDataSourceRequest {
    pub name: String,
    pub kind: String, // postgres | timescale
    pub host: String,
    pub port: i32,
    pub database_name: String,
    pub username: String,
    pub secret_ref: String,
    pub ssl_mode: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateDataSourceResponse {
    pub data_source_id: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetDataSourceRequest {
    pub data_source_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GetDataSourceResponse {
    pub data_source: crate::storage::DataSource,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TestDataSourceRequest {
    pub data_source_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TestDataSourceResponse {
    pub ok: bool,
    pub latency_ms: Option<u64>,
    pub error_code: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DeleteDataSourceRequest {
    pub data_source_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DeleteDataSourceResponse {
    pub ok: bool,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DiagnosticsResponse {
    pub versions: serde_json::Value,
    pub health: Vec<serde_json::Value>,
    pub cache_stats: serde_json::Value,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverSchemaRequest {
    pub dashboard_id: String,
    pub data_source_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverSchemaResponse {
    pub snapshot_id: String,
    pub summary: serde_json::Value,
    pub warnings: Vec<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RunQueryRequest {
    pub dashboard_id: String,
    pub query_id: String,
    pub params: Option<serde_json::Value>,
    pub page: Option<i64>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RunQueryResponse {
    pub columns: Vec<String>,
    pub rows: Vec<serde_json::Value>,
    pub truncated: bool,
    pub ms: u64,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GenerateUiIrRequest {
    pub dashboard_id: String,
    pub mode: String, // automatic | configured | hybrid
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GenerateUiIrResponse {
    pub draft_id: String,
    pub uiir: serde_json::Value,
    pub report: serde_json::Value,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveUiIrRequest {
    pub dashboard_id: String,
    pub ir: serde_json::Value,
    pub base_revision: Option<i64>,
    pub source: Option<String>,
    pub note: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveUiIrResponse {
    pub dashboard_id: String,
    pub revision: i64,
    pub validation: crate::uiir::ValidationReport,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ValidateUiIrRequest {
    pub ir: serde_json::Value,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveWorkspaceLayoutRequest {
    pub layout: serde_json::Value,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveWorkspaceLayoutResponse {
    pub ok: bool,
}

#[derive(Debug, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct GetWorkspaceLayoutRequest {}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GetWorkspaceLayoutResponse {
    pub layout: serde_json::Value,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PingResponse {
    pub version: String,
    pub capabilities: Vec<String>,
}

// ---------------------------------------------------------------------------
// Command handlers
// ---------------------------------------------------------------------------

#[tauri::command]
pub fn ping() -> Result<PingResponse, String> {
    Ok(PingResponse {
        version: crate::ENGINE_VERSION.to_string(),
        capabilities: vec![
            "dashboard:crud".to_string(),
            "discovery:inspect".to_string(),
            "query:execute".to_string(),
            "uiir:generate".to_string(),
            "workspace:layout".to_string(),
        ],
    })
}

#[tauri::command]
pub fn dashboard_create(
    state: State<'_, AppState>,
    req: CreateDashboardRequest,
) -> Result<CreateDashboardResponse, String> {
    let desc = req.description.unwrap_or_default();
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let dash = engine
        .create_dashboard(req.name, desc)
        .map_err(|e| e.message)?;

    if let Some(icon) = req.icon.filter(|value| !value.trim().is_empty()) {
        let icon_json = serde_json::json!({ "kind": "emoji", "value": icon }).to_string();
        engine
            .store
            .update_dashboard_icon(&dash.id, &icon_json)
            .map_err(|e| e.message)?;
    }

    // Seed revision 1 with a valid starter UI-IR so opening the dashboard
    // immediately renders something meaningful.
    let doc = default_dashboard_ir(&dash.id, &dash.name, &dash.description);
    let ir_json = serde_json::to_string(&doc).map_err(|e| e.to_string())?;
    engine
        .store
        .save_revision(
            &dash.id,
            ir_json,
            None,
            UI_IR_VERSION.to_string(),
            "generator".to_string(),
            Some("initial default dashboard".to_string()),
            Some(0),
        )
        .map_err(|e| e.message)?;

    Ok(CreateDashboardResponse {
        dashboard_id: dash.id,
    })
}

#[tauri::command]
pub fn dashboard_list(
    state: State<'_, AppState>,
    req: ListDashboardsRequest,
) -> Result<ListDashboardsResponse, String> {
    let _ = &req;
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let items = engine
        .store
        .list_dashboards()
        .map_err(|e| e.message)?;
    Ok(ListDashboardsResponse { items, next: None })
}

#[tauri::command]
pub fn dashboard_get(
    state: State<'_, AppState>,
    req: GetDashboardRequest,
) -> Result<GetDashboardResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let dash = engine
        .store
        .get_dashboard(&req.dashboard_id)
        .map_err(|e| e.message)?
        .ok_or_else(|| "dashboard not found".to_string())?;

    let uiir = match engine
        .store
        .get_current_revision(&dash.id)
        .map_err(|e| e.message)?
    {
        Some(rev) => Some(
            serde_json::from_str::<serde_json::Value>(&rev.ir_json)
                .map_err(|e| e.to_string())?,
        ),
        None => Some(
            serde_json::to_value(default_dashboard_ir(
                &dash.id,
                &dash.name,
                &dash.description,
            ))
            .map_err(|e| e.to_string())?,
        ),
    };

    let revision = dash.current_rev;
    Ok(GetDashboardResponse {
        dashboard: dash,
        uiir,
        revision,
    })
}

#[tauri::command]
pub fn dashboard_save(
    state: State<'_, AppState>,
    req: SaveDashboardRequest,
) -> Result<SaveDashboardResponse, String> {
    let dashboard_id = req.dashboard_id.clone();
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    engine
        .store
        .update_dashboard(&dashboard_id, req.name, req.description)
        .map_err(|e| e.message)?;
    let dash = engine
        .store
        .get_dashboard(&dashboard_id)
        .map_err(|e| e.message)?
        .ok_or_else(|| "dashboard not found".to_string())?;
    Ok(SaveDashboardResponse {
        dashboard_id,
        revision: dash.current_rev,
    })
}

#[tauri::command]
pub fn dashboard_save_uiir(
    state: State<'_, AppState>,
    req: SaveUiIrRequest,
) -> Result<SaveUiIrResponse, String> {
    let doc: UiIrDocument =
        serde_json::from_value(req.ir).map_err(|e| format!("invalid ui-ir: {e}"))?;
    let report = Validator::validate(&doc);
    if !report.valid {
        return Err(format!(
            "ui-ir validation failed: {}",
            report.errors.join("; ")
        ));
    }

    let ir_json = serde_json::to_string(&doc).map_err(|e| e.to_string())?;
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let revision = engine
        .store
        .save_revision(
            &req.dashboard_id,
            ir_json,
            None,
            doc.version.clone(),
            req.source.unwrap_or_else(|| "user".to_string()),
            req.note,
            req.base_revision,
        )
        .map_err(|e| e.message)?;

    Ok(SaveUiIrResponse {
        dashboard_id: req.dashboard_id,
        revision: revision.revision,
        validation: report,
    })
}

#[tauri::command]
pub fn dashboard_validate_uiir(
    _state: State<'_, AppState>,
    req: ValidateUiIrRequest,
) -> Result<crate::uiir::ValidationReport, String> {
    let doc: UiIrDocument =
        serde_json::from_value(req.ir).map_err(|e| format!("invalid ui-ir: {e}"))?;
    Ok(Validator::validate(&doc))
}

#[tauri::command]
pub fn dashboard_delete(
    state: State<'_, AppState>,
    req: DeleteDashboardRequest,
) -> Result<DeleteDashboardResponse, String> {
    if req.confirm_name.is_empty() {
        return Err("confirm_name required".to_string());
    }
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    engine
        .store
        .delete_dashboard(&req.dashboard_id)
        .map_err(|e| e.message)?;
    Ok(DeleteDashboardResponse { ok: true })
}

#[tauri::command]
pub fn datasource_list(
    state: State<'_, AppState>,
    req: ListDataSourcesRequest,
) -> Result<ListDataSourcesResponse, String> {
    let _ = &req;
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let items = engine
        .store
        .list_data_sources()
        .map_err(|e| e.message)?;
    Ok(ListDataSourcesResponse { items })
}

#[tauri::command]
pub fn datasource_create(
    state: State<'_, AppState>,
    req: CreateDataSourceRequest,
) -> Result<CreateDataSourceResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let source = engine
        .store
        .create_data_source(
            req.name,
            req.kind,
            req.host,
            req.port,
            req.database_name,
            req.username,
            req.secret_ref,
            req.ssl_mode.unwrap_or_else(|| "require".to_string()),
        )
        .map_err(|e| e.message)?;
    Ok(CreateDataSourceResponse {
        data_source_id: source.id,
    })
}

#[tauri::command]
pub fn datasource_get(
    state: State<'_, AppState>,
    req: GetDataSourceRequest,
) -> Result<GetDataSourceResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let data_source = engine
        .store
        .get_data_source(&req.data_source_id)
        .map_err(|e| e.message)?
        .ok_or_else(|| "data source not found".to_string())?;
    Ok(GetDataSourceResponse { data_source })
}

#[tauri::command]
pub async fn datasource_test(
    state: State<'_, AppState>,
    req: TestDataSourceRequest,
) -> Result<TestDataSourceResponse, String> {
    let data_source = {
        let engine = state
            .engine
            .lock()
            .map_err(|_| "engine lock poisoned".to_string())?;
        engine
            .store
            .get_data_source(&req.data_source_id)
            .map_err(|e| e.message)?
            .ok_or_else(|| "data source not found".to_string())?
    };

    let connection_string = format!(
        "host={} port={} dbname={} user={}",
        data_source.host, data_source.port, data_source.database_name, data_source.username
    );

    let started = std::time::Instant::now();
    let result = crate::discovery::Discovery::test_connection(&connection_string).await;
    let latency = started.elapsed().as_millis() as u64;

    match result {
        Ok(()) => Ok(TestDataSourceResponse {
            ok: true,
            latency_ms: Some(latency),
            error_code: None,
        }),
        Err(err) => Ok(TestDataSourceResponse {
            ok: false,
            latency_ms: Some(latency),
            error_code: Some(format!("{:?}", err.code)),
        }),
    }
}

#[tauri::command]
pub fn datasource_delete(
    state: State<'_, AppState>,
    req: DeleteDataSourceRequest,
) -> Result<DeleteDataSourceResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    engine
        .store
        .delete_data_source(&req.data_source_id)
        .map_err(|e| e.message)?;
    Ok(DeleteDataSourceResponse { ok: true })
}

#[tauri::command]
pub fn diagnostics_get(state: State<'_, AppState>) -> Result<DiagnosticsResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let counts = engine.store.diagnostics_counts().unwrap_or_default();
    Ok(DiagnosticsResponse {
        versions: serde_json::json!({
            "engine": crate::ENGINE_VERSION,
            "uiIr": UI_IR_VERSION,
        }),
        health: vec![serde_json::json!({
            "component": "store",
            "status": "ok",
        })],
        cache_stats: counts,
    })
}

#[tauri::command]
pub fn workspace_save_layout(
    state: State<'_, AppState>,
    req: SaveWorkspaceLayoutRequest,
) -> Result<SaveWorkspaceLayoutResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    engine
        .store
        .save_workspace_layout(&req.layout)
        .map_err(|e| e.message)?;
    Ok(SaveWorkspaceLayoutResponse { ok: true })
}

#[tauri::command]
pub fn workspace_get_layout(
    state: State<'_, AppState>,
    req: GetWorkspaceLayoutRequest,
) -> Result<GetWorkspaceLayoutResponse, String> {
    let _ = &req;
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let layout = engine
        .store
        .get_workspace_layout()
        .map_err(|e| e.message)?
        .unwrap_or(serde_json::Value::Null);
    Ok(GetWorkspaceLayoutResponse { layout })
}

// ===========================================================================
// P2 — Schema discovery commands
// ===========================================================================

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverInspectRequest {
    pub dashboard_id: String,
    pub data_source_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverInspectResponse {
    pub snapshot_id: String,
    pub fingerprint: String,
    pub status: String,
    pub table_count: usize,
    pub relationship_count: usize,
    pub warnings: Vec<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverSnapshotRequest {
    pub snapshot_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverSnapshotResponse {
    pub snapshot_id: String,
    pub summary: serde_json::Value,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverProfileJsonbRequest {
    pub snapshot_id: String,
    pub table: String,
    pub column: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DiscoverProfileJsonbResponse {
    pub paths: Vec<serde_json::Value>,
}

// ===========================================================================
// P3 — Query execution commands
// ===========================================================================

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct QueryExecuteRequest {
    pub dashboard_id: String,
    pub query_id: String,
    pub params: Option<serde_json::Value>,
    pub page: Option<i64>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct QueryExecuteResponse {
    pub columns: Vec<String>,
    pub rows: Vec<serde_json::Value>,
    pub truncated: bool,
    pub ms: u64,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct QueryCancelRequest {
    pub request_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct QueryCancelResponse {
    pub ok: bool,
}

// ===========================================================================
// P4 — UI-IR apply/migrate commands
// ===========================================================================

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiirApplyDraftRequest {
    pub dashboard_id: String,
    pub draft_id: String,
    /// The draft UI-IR document produced by `uiir_generate`.
    pub uiir: serde_json::Value,
    pub strategy: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UiirApplyDraftResponse {
    pub revision: i64,
    pub uiir: serde_json::Value,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiirMigrateRequest {
    pub uiir: serde_json::Value,
    pub to_version: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UiirMigrateResponse {
    pub uiir: serde_json::Value,
    pub report: crate::uiir::ValidationReport,
}

// ===========================================================================
// Handlers
// ===========================================================================

#[tauri::command]
pub async fn discovery_inspect(
    state: State<'_, AppState>,
    req: DiscoverInspectRequest,
) -> Result<DiscoverInspectResponse, String> {
    // Copy what we need out of the locked engine, then release the guard before
    // awaiting — a `MutexGuard` is not `Send` and would poison the future.
    let (connection_string, max_objects, timeout_sec) = {
        let engine = state
            .engine
            .lock()
            .map_err(|_| "engine lock poisoned".to_string())?;

        let data_source = engine
            .store
            .get_data_source(&req.data_source_id)
            .map_err(|e| e.message)?
            .ok_or_else(|| "data source not found".to_string())?;

        (
            format!(
                "host={} port={} dbname={} user={}",
                data_source.host,
                data_source.port,
                data_source.database_name,
                data_source.username
            ),
            engine.config.max_discovery_objects,
            engine.config.discovery_timeout_sec,
        )
    };

    let snapshot = Discovery::inspect(&connection_string, max_objects, timeout_sec)
        .await
        .map_err(|e| e.message)?;

    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;

    // Persist snapshot + objects + relationships
    let summary = serde_json::to_value(&snapshot).map_err(|e| e.to_string())?;
    let snapshot_id = engine
        .store
        .save_schema_snapshot(
            &req.data_source_id,
            &snapshot.fingerprint,
            &snapshot.engine_version,
            &snapshot.status,
            &summary.to_string(),
        )
        .map_err(|e| e.message)?;

    engine
        .store
        .save_schema_objects(&snapshot_id, &snapshot.tables)
        .map_err(|e| e.message)?;

    engine
        .store
        .save_relationships(&snapshot_id, &snapshot.relationships)
        .map_err(|e| e.message)?;

    Ok(DiscoverInspectResponse {
        snapshot_id,
        fingerprint: snapshot.fingerprint,
        status: snapshot.status,
        table_count: snapshot.tables.len(),
        relationship_count: snapshot.relationships.len(),
        warnings: vec![],
    })
}

#[tauri::command]
pub fn discovery_snapshot(
    state: State<'_, AppState>,
    req: DiscoverSnapshotRequest,
) -> Result<DiscoverSnapshotResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let summary = engine
        .store
        .get_schema_snapshot(&req.snapshot_id)
        .map_err(|e| e.message)?
        .ok_or_else(|| "snapshot not found".to_string())?;
    Ok(DiscoverSnapshotResponse {
        snapshot_id: req.snapshot_id,
        summary: serde_json::from_str(&summary).unwrap_or(serde_json::Value::Null),
    })
}

#[tauri::command]
pub async fn discovery_profile_jsonb(
    _state: State<'_, AppState>,
    _req: DiscoverProfileJsonbRequest,
) -> Result<DiscoverProfileJsonbResponse, String> {
    Err("jsonb profiling not yet implemented".to_string())
}

#[tauri::command]
pub async fn query_execute(
    state: State<'_, AppState>,
    req: QueryExecuteRequest,
) -> Result<QueryExecuteResponse, String> {
    // `query_id` is the target table/object name for this simple execution
    // path. Real UI-IR queries carry a full intent, resolved by the caller.
    let table = req.query_id.trim().to_string();
    if table.is_empty()
        || !table
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '.')
    {
        return Err("query_id must be a valid table identifier".to_string());
    }

    let page = req.page.unwrap_or(1).max(1);
    let page_size: i64 = 100;

    // Resolve everything under the lock, then drop the guard before awaiting.
    let (connection_string, plan) = {
        let engine = state
            .engine
            .lock()
            .map_err(|_| "engine lock poisoned".to_string())?;

        // Look up the data source linked to the dashboard, falling back to the
        // first configured source so a fresh dashboard can query immediately.
        let linked: Option<String> = engine
            .store
            .conn()
            .query_row(
                "SELECT data_source_id FROM dashboard_data_sources WHERE dashboard_id = ?1 LIMIT 1",
                params![req.dashboard_id],
                |r| r.get(0),
            )
            .optional()
            .map_err(|e| e.to_string())?;

        let data_source_id = match linked {
            Some(id) if !id.is_empty() => id,
            _ => engine
                .store
                .list_data_sources()
                .map_err(|e| e.message)?
                .into_iter()
                .next()
                .map(|ds| ds.id)
                .ok_or_else(|| "no data source configured".to_string())?,
        };

        let data_source = engine
            .store
            .get_data_source(&data_source_id)
            .map_err(|e| e.message)?
            .ok_or_else(|| "data source not found".to_string())?;

        let connection_string = format!(
            "host={} port={} dbname={} user={}",
            data_source.host, data_source.port, data_source.database_name, data_source.username
        );

        let intent = QueryIntent {
            kind: QueryIntentKind::Select,
            source_id: table.clone(),
            fields: vec!["*".to_string()],
            order_by: Vec::new(),
            limit: Some(page_size),
            offset: Some((page - 1) * page_size).filter(|o| *o > 0),
            group_by: None,
            aggregates: None,
            time_column: None,
            bucket: None,
        };

        let mut allowlist = ObjectAllowlist::new();
        allowlist.objects.push(table.clone());
        let plan = compile_query(&intent, &table, &allowlist, 15_000, page_size)
            .map_err(|e| e.message)?;

        (connection_string, plan)
    };

    let result = executor::execute(&connection_string, &plan)
        .await
        .map_err(|e| e.message)?;

    Ok(QueryExecuteResponse {
        columns: result.columns,
        rows: result.rows,
        truncated: result.truncated,
        ms: result.execution_ms,
    })
}

#[tauri::command]
pub fn query_cancel(
    _state: State<'_, AppState>,
    req: QueryCancelRequest,
) -> Result<QueryCancelResponse, String> {
    let _ = req;
    executor::cancel("").map_err(|e| e.message)?;
    Ok(QueryCancelResponse { ok: true })
}

#[tauri::command]
pub fn uiir_generate(
    state: State<'_, AppState>,
    req: GenerateUiIrRequest,
) -> Result<GenerateUiIrResponse, String> {
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let dash = engine
        .store
        .get_dashboard(&req.dashboard_id)
        .map_err(|e| e.message)?
        .ok_or_else(|| "dashboard not found".to_string())?;

    // Prefer the latest snapshot of the dashboard's (or first) data source for
    // schema-driven generation; otherwise fall back to the starter document.
    let latest = {
        let source_id: Option<String> = engine
            .store
            .conn()
            .query_row(
                "SELECT data_source_id FROM dashboard_data_sources WHERE dashboard_id = ?1 LIMIT 1",
                params![dash.id],
                |r| r.get(0),
            )
            .optional()
            .map_err(|e| e.to_string())?;

        let source_id = match source_id {
            Some(id) if !id.is_empty() => Some(id),
            _ => engine
                .store
                .list_data_sources()
                .map_err(|e| e.message)?
                .into_iter()
                .next()
                .map(|ds| ds.id),
        };

        match source_id {
            Some(id) => engine
                .store
                .get_latest_snapshot_for_source(&id)
                .map_err(|e| e.message)?,
            None => None,
        }
    };

    let doc = if let Some(summary) = latest {
        if let Ok(value) = serde_json::from_str::<serde_json::Value>(&summary) {
            if let Some(tables) = value.get("tables").and_then(|t| t.as_array()) {
                schema_driven_uiir(&dash, tables)
            } else {
                default_dashboard_ir(&dash.id, &dash.name, &dash.description)
            }
        } else {
            default_dashboard_ir(&dash.id, &dash.name, &dash.description)
        }
    } else {
        default_dashboard_ir(&dash.id, &dash.name, &dash.description)
    };

    let uiir = serde_json::to_value(&doc).map_err(|e| e.to_string())?;
    Ok(GenerateUiIrResponse {
        draft_id: format!("draft_{}", dash.id),
        uiir,
        report: serde_json::json!({
            "mode": req.mode,
            "warnings": ["schema-driven generation is a first draft"],
        }),
    })
}

#[tauri::command]
pub fn uiir_apply_draft(
    state: State<'_, AppState>,
    req: UiirApplyDraftRequest,
) -> Result<UiirApplyDraftResponse, String> {
    let doc: UiIrDocument =
        serde_json::from_value(req.uiir).map_err(|e| format!("invalid draft ui-ir: {e}"))?;
    let report = Validator::validate(&doc);
    if !report.valid {
        return Err(format!(
            "ui-ir validation failed: {}",
            report.errors.join("; ")
        ));
    }

    let ir_json = serde_json::to_string(&doc).map_err(|e| e.to_string())?;
    let engine = state
        .engine
        .lock()
        .map_err(|_| "engine lock poisoned".to_string())?;
    let revision = engine
        .store
        .save_revision(
            &req.dashboard_id,
            ir_json,
            None,
            UI_IR_VERSION.to_string(),
            "user".to_string(),
            Some(format!("apply draft {}", req.strategy)),
            None,
        )
        .map_err(|e| e.message)?;

    Ok(UiirApplyDraftResponse {
        revision: revision.revision,
        uiir: serde_json::to_value(doc).map_err(|e| e.to_string())?,
    })
}

#[tauri::command]
pub fn uiir_migrate(
    _state: State<'_, AppState>,
    req: UiirMigrateRequest,
) -> Result<UiirMigrateResponse, String> {
    let doc: UiIrDocument =
        serde_json::from_value(req.uiir).map_err(|e| e.to_string())?;
    let migrated = Validator::migrate_doc(doc, &req.to_version).map_err(|e| e.message)?;
    let report = Validator::validate(&migrated);
    Ok(UiirMigrateResponse {
        uiir: serde_json::to_value(migrated).map_err(|e| e.to_string())?,
        report,
    })
}

/// Build a starter UI-IR from discovered tables (first component per table).
fn schema_driven_uiir(dash: &crate::storage::Dashboard, tables: &[serde_json::Value]) -> UiIrDocument {
    let pairs: Vec<(String, String)> = tables
        .iter()
        .filter_map(|table| {
            let object = table.get("object_name").and_then(|v| v.as_str())?;
            let object_id = table
                .get("object_id")
                .and_then(|v| v.as_str())
                .unwrap_or(object);
            Some((object_id.to_string(), object.to_string()))
        })
        .collect();

    crate::uiir::starter_from_tables(&dash.id, &dash.name, &dash.description, &pairs)
}

// Commands are registered directly in `main.rs` via `tauri::generate_handler!`.
// Keeping the command list in one place there avoids a second, hand-written
// function signature that can drift from Tauri's generated handler type.
