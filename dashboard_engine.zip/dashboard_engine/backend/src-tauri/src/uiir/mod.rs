//! UI-IR (UI Intermediate Representation) — generation, validation, migration.
//! Versioned, validated contract between backend and frontend.

use crate::{EngineError, EngineResult};
use serde::{Deserialize, Serialize};
use serde_json::Value;

/// UI-IR document version.
pub const UI_IR_VERSION: &str = "1.0.0";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrDocument {
    pub version: String,
    pub dashboard: UiIrApp,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrApp {
    pub id: String,
    pub name: String,
    /// Schema-optional: defaults to an empty description.
    #[serde(default)]
    pub description: String,
    /// Schema-optional: defaults to the standard emoji icon.
    #[serde(default)]
    pub icon: UiIrIcon,
    /// Schema-optional: defaults to system theme with no token overrides.
    #[serde(default)]
    pub theme: UiIrTheme,
    pub navigation: UiIrNavigation,
    pub routes: Vec<UiIrRoute>,
    pub pages: Vec<UiIrPage>,
    pub components: Vec<UiIrComponent>,
    pub bindings: Vec<UiIrBinding>,
    pub queries: Vec<UiIrQuery>,
    pub permissions: UiIrPermissions,
    pub fallbacks: UiIrFallbacks,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrIcon {
    pub kind: String, // emoji | image
    pub value: String,
}

impl Default for UiIrIcon {
    fn default() -> Self {
        Self {
            kind: "emoji".to_string(),
            value: "📊".to_string(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrTheme {
    pub mode: String, // light | dark | system
    pub tokens: Option<Value>,
}

impl Default for UiIrTheme {
    fn default() -> Self {
        Self {
            mode: "system".to_string(),
            tokens: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrNavigation {
    pub style: String,
    pub groups: Vec<UiIrNavGroup>,
    pub footer: Vec<UiIrNavItem>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrNavGroup {
    pub id: String,
    pub label: String,
    pub items: Vec<UiIrNavItem>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrNavItem {
    pub id: String,
    pub label: String,
    pub route_id: String,
    pub icon: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrRoute {
    pub id: String,
    pub path: String,
    pub page_id: String,
    pub title: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrPage {
    pub id: String,
    pub title: String,
    pub layout: UiIrLayout,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrLayout {
    pub kind: String, // grid
    pub columns: i32,
    pub rows: Vec<UiIrLayoutRow>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrLayoutRow {
    pub id: String,
    pub height: String, // auto | fill | Npx
    pub items: Vec<UiIrLayoutItem>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrLayoutItem {
    pub component_id: String,
    pub span: i32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrComponent {
    pub id: String,
    pub r#type: String,
    pub title: Option<String>,
    pub binding_id: Option<String>,
    pub format: Option<String>,
    pub props: Value,
    pub grid_area: Option<UiIrGridArea>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrGridArea {
    pub col: String,
    pub row: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrBinding {
    pub id: String,
    pub query_id: String,
    pub result_shape: String, // scalar | rows | series | distribution | none
    pub refresh: UiIrRefresh,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrRefresh {
    pub mode: String, // manual | on_mount | interval
    pub stale_after_sec: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrQuery {
    pub id: String,
    pub intent: Value,
    pub params: Value,
    pub cacheable: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrPermissions {
    pub hide: Vec<String>,
    pub read_only: bool,
    pub scopes: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UiIrFallbacks {
    pub unknown_component: String,
    pub missing_binding: String,
}

/// Build a valid starter UI-IR document for a freshly created dashboard.
///
/// Offset 0 has no data source yet, so all components are intentionally
/// unbound. They render their empty state until the user connects a source and
/// either configures or generates a real layout.
pub fn default_dashboard_ir(id: &str, name: &str, description: &str) -> UiIrDocument {
    let component = |id: &str, kind: &str, title: &str| UiIrComponent {
        id: id.to_string(),
        r#type: kind.to_string(),
        title: Some(title.to_string()),
        binding_id: None,
        format: None,
        props: serde_json::json!({}),
        grid_area: None,
    };

    let item = |component_id: &str, span: i32| UiIrLayoutItem {
        component_id: component_id.to_string(),
        span,
    };

    UiIrDocument {
        version: UI_IR_VERSION.to_string(),
        dashboard: UiIrApp {
            id: id.to_string(),
            name: name.to_string(),
            description: description.to_string(),
            icon: UiIrIcon {
                kind: "emoji".to_string(),
                value: "📊".to_string(),
            },
            theme: UiIrTheme {
                mode: "system".to_string(),
                tokens: None,
            },
            navigation: UiIrNavigation {
                style: "sidebar".to_string(),
                groups: vec![UiIrNavGroup {
                    id: "grp_main".to_string(),
                    label: "Overview".to_string(),
                    items: vec![UiIrNavItem {
                        id: "nav_overview".to_string(),
                        label: "Overview".to_string(),
                        route_id: "rt_overview".to_string(),
                        icon: Some("home".to_string()),
                    }],
                }],
                footer: Vec::new(),
            },
            routes: vec![UiIrRoute {
                id: "rt_overview".to_string(),
                path: "/".to_string(),
                page_id: "pg_overview".to_string(),
                title: "Overview".to_string(),
            }],
            pages: vec![UiIrPage {
                id: "pg_overview".to_string(),
                title: "Overview".to_string(),
                layout: UiIrLayout {
                    kind: "grid".to_string(),
                    columns: 12,
                    rows: vec![
                        UiIrLayoutRow {
                            id: "row_heading".to_string(),
                            height: "auto".to_string(),
                            items: vec![item("cmp_heading", 12)],
                        },
                        UiIrLayoutRow {
                            id: "row_metrics".to_string(),
                            height: "auto".to_string(),
                            items: vec![
                                item("cmp_metric_total", 4),
                                item("cmp_metric_active", 4),
                                item("cmp_metric_updated", 4),
                            ],
                        },
                        UiIrLayoutRow {
                            id: "row_detail".to_string(),
                            height: "fill".to_string(),
                            items: vec![item("cmp_detail", 12)],
                        },
                    ],
                },
            }],
            components: vec![
                UiIrComponent {
                    props: serde_json::json!({ "description": description }),
                    ..component("cmp_heading", "section", name)
                },
                component("cmp_metric_total", "metric-card", "Total records"),
                component("cmp_metric_active", "metric-card", "Active items"),
                component("cmp_metric_updated", "metric-card", "Last updated"),
                component("cmp_detail", "detail", "Dashboard details"),
            ],
            bindings: Vec::new(),
            queries: Vec::new(),
            permissions: UiIrPermissions {
                hide: Vec::new(),
                read_only: true,
                scopes: vec!["analytics:read".to_string()],
            },
            fallbacks: UiIrFallbacks {
                unknown_component: "placeholder-card".to_string(),
                missing_binding: "placeholder-card".to_string(),
            },
        },
    }
}

/// Build a schema-driven starter UI-IR from discovered tables.
///
/// Each table becomes one `data-table` component plus a navigation entry on a
/// single generated page. Used by `uiir_generate` and the standalone generator.
pub fn starter_from_tables(
    id: &str,
    name: &str,
    description: &str,
    tables: &[(String, String)],
) -> UiIrDocument {
    if tables.is_empty() {
        return default_dashboard_ir(id, name, description);
    }

    let mut components = Vec::with_capacity(tables.len());
    let mut row_items = Vec::with_capacity(tables.len());
    let mut nav_items = Vec::with_capacity(tables.len());

    for (index, (object_id, object_name)) in tables.iter().enumerate() {
        let component_id = format!("cmp_table_{index}");
        components.push(UiIrComponent {
            id: component_id.clone(),
            r#type: "data-table".to_string(),
            title: Some(object_name.clone()),
            binding_id: None,
            format: None,
            props: serde_json::json!({
                "table": object_name,
                "objectId": object_id,
            }),
            grid_area: None,
        });
        row_items.push(UiIrLayoutItem {
            component_id,
            span: if tables.len() <= 2 { 6 } else { 4 },
        });
        nav_items.push(UiIrNavItem {
            id: format!("nav_table_{index}"),
            label: object_name.clone(),
            route_id: "rt_generated".to_string(),
            icon: Some("table".to_string()),
        });
    }

    UiIrDocument {
        version: UI_IR_VERSION.to_string(),
        dashboard: UiIrApp {
            id: id.to_string(),
            name: name.to_string(),
            description: description.to_string(),
            icon: UiIrIcon::default(),
            theme: UiIrTheme::default(),
            navigation: UiIrNavigation {
                style: "sidebar".to_string(),
                groups: vec![UiIrNavGroup {
                    id: "grp_generated".to_string(),
                    label: "Discovered".to_string(),
                    items: nav_items,
                }],
                footer: Vec::new(),
            },
            routes: vec![UiIrRoute {
                id: "rt_generated".to_string(),
                path: "/".to_string(),
                page_id: "pg_generated".to_string(),
                title: "Generated".to_string(),
            }],
            pages: vec![UiIrPage {
                id: "pg_generated".to_string(),
                title: "Generated Dashboard".to_string(),
                layout: UiIrLayout {
                    kind: "grid".to_string(),
                    columns: 12,
                    rows: vec![UiIrLayoutRow {
                        id: "row_generated".to_string(),
                        height: "fill".to_string(),
                        items: row_items,
                    }],
                },
            }],
            components,
            bindings: Vec::new(),
            queries: Vec::new(),
            permissions: UiIrPermissions {
                hide: Vec::new(),
                read_only: true,
                scopes: vec!["analytics:read".to_string()],
            },
            fallbacks: UiIrFallbacks {
                unknown_component: "placeholder-card".to_string(),
                missing_binding: "placeholder-card".to_string(),
            },
        },
    }
}

/// Validator — checks UI-IR shape before saving/rendering.
pub struct Validator;

impl Validator {
    pub fn validate(doc: &UiIrDocument) -> ValidationReport {
        let mut errors = Vec::new();
        let mut warnings = Vec::new();

        if doc.version != UI_IR_VERSION {
            warnings.push(format!("ui-ir version {} != supported {}", doc.version, UI_IR_VERSION));
        }

        // Unique ids
        let mut ids = std::collections::HashSet::new();
        for c in &doc.dashboard.components {
            if !ids.insert(c.id.clone()) {
                errors.push(format!("duplicate component id: {}", c.id));
            }
        }
        for b in &doc.dashboard.bindings {
            if !ids.insert(b.id.clone()) {
                errors.push(format!("duplicate binding id: {}", b.id));
            }
        }
        for q in &doc.dashboard.queries {
            if !ids.insert(q.id.clone()) {
                errors.push(format!("duplicate query id: {}", q.id));
            }
        }

        // Reference resolution
        let binding_ids: std::collections::HashSet<&str> =
            doc.dashboard.bindings.iter().map(|b| b.id.as_str()).collect();
        for c in &doc.dashboard.components {
            if let Some(bid) = &c.binding_id {
                if !binding_ids.contains(bid.as_str()) {
                    errors.push(format!("component {} references unknown binding {}", c.id, bid));
                }
            }
        }

        ValidationReport {
            valid: errors.is_empty(),
            version: doc.version.clone(),
            errors,
            warnings,
        }
    }

    /// Apply a version migration to a document. Returns the migrated document.
    pub fn migrate_doc(doc: UiIrDocument, to_version: &str) -> EngineResult<UiIrDocument> {
        Generator::migrate(doc, to_version)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ValidationReport {
    pub valid: bool,
    pub version: String,
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
}

/// Generator — produces a first-draft UI-IR from schema metadata.
pub struct Generator;

impl Generator {
    /// Generate a starter document from a completed discovery snapshot.
    pub fn generate_draft(
        snapshot: &crate::discovery::SchemaSnapshot,
    ) -> EngineResult<UiIrDocument> {
        let tables: Vec<(String, String)> = snapshot
            .tables
            .iter()
            .filter(|t| t.object_type == "table" || t.object_type == "view")
            .map(|t| (t.object_id.clone(), t.object_name.clone()))
            .collect();

        let name = if tables.is_empty() {
            "Generated Dashboard".to_string()
        } else {
            format!("{} — {} objects", snapshot.data_source_id, tables.len())
        };

        Ok(starter_from_tables(
            &snapshot.data_source_id,
            &name,
            "Generated from discovered schema",
            &tables,
        ))
    }

    /// Migrate a UI-IR document forward to `to_version`.
    ///
    /// Only 1.x is implemented. Downgrades and unknown future versions are
    /// rejected explicitly instead of silently passing through.
    pub fn migrate(mut doc: UiIrDocument, to_version: &str) -> EngineResult<UiIrDocument> {
        if doc.version == to_version {
            return Ok(doc);
        }

        let target = semver::Version::parse(to_version).map_err(|_| {
            EngineError::invalid_ir(format!("invalid target version: {to_version}"))
        })?;
        let current = semver::Version::parse(&doc.version).map_err(|_| {
            EngineError::invalid_ir(format!("invalid document version: {}", doc.version))
        })?;
        let supported = semver::Version::parse(UI_IR_VERSION).map_err(|_| {
            EngineError::invalid_ir("engine UI-IR version is not valid semver".to_string())
        })?;

        if target.major != current.major {
            return Err(EngineError::invalid_ir(format!(
                "cannot migrate across major versions: {} -> {}",
                doc.version, to_version
            )));
        }
        if target > supported {
            return Err(EngineError::invalid_ir(format!(
                "target version {to_version} is newer than supported {UI_IR_VERSION}"
            )));
        }
        if target < current {
            return Err(EngineError::invalid_ir(format!(
                "downgrades are not supported: {} -> {}",
                doc.version, to_version
            )));
        }

        // Minor/patch upgrades within 1.x only change the version stamp today.
        doc.version = to_version.to_string();
        Ok(doc)
    }
}

pub mod migrator {
    pub use super::Generator;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_ir_is_valid() {
        let doc = default_dashboard_ir("dash_1", "Sales", "Sales overview");
        let report = Validator::validate(&doc);
        assert!(report.valid, "validation errors: {:?}", report.errors);
        assert_eq!(doc.version, UI_IR_VERSION);
        assert_eq!(doc.dashboard.pages.len(), 1);
        assert!(doc.dashboard.routes.iter().any(|r| r.id == "rt_overview"));
    }

    #[test]
    fn default_ir_serializes_camel_case() {
        let doc = default_dashboard_ir("dash_1", "Sales", "");
        let json = serde_json::to_value(&doc).unwrap();
        let dashboard = &json["dashboard"];

        let item = &dashboard["pages"][0]["layout"]["rows"][0]["items"][0];
        assert!(item.get("componentId").is_some());
        assert!(item.get("component_id").is_none());
        assert!(dashboard["routes"][0].get("pageId").is_some());

        let component = &dashboard["components"][0];
        assert!(component.get("bindingId").is_some());
        assert!(component.get("binding_id").is_none());
    }

    #[test]
    fn starter_from_tables_is_valid_and_bound_to_tables() {
        let tables = vec![
            ("public.users".to_string(), "users".to_string()),
            ("public.orders".to_string(), "orders".to_string()),
        ];
        let doc = starter_from_tables("dash_1", "Sales", "desc", &tables);
        let report = Validator::validate(&doc);
        assert!(report.valid, "validation errors: {:?}", report.errors);
        assert_eq!(doc.dashboard.components.len(), 2);
        assert_eq!(doc.dashboard.components[0].r#type, "data-table");
        assert_eq!(
            doc.dashboard.components[0].props["table"],
            serde_json::json!("users")
        );
        assert_eq!(doc.dashboard.navigation.groups[0].items.len(), 2);
    }

    #[test]
    fn starter_from_tables_falls_back_when_empty() {
        let doc = starter_from_tables("dash_1", "Sales", "desc", &[]);
        assert_eq!(doc.dashboard.routes[0].id, "rt_overview");
    }

    #[test]
    fn migrate_same_version_is_noop() {
        let doc = default_dashboard_ir("dash_1", "Sales", "");
        let migrated = Generator::migrate(doc.clone(), UI_IR_VERSION).expect("migrate");
        assert_eq!(migrated.version, doc.version);
    }

    #[test]
    fn migrate_rejects_unsupported_versions() {
        let doc = default_dashboard_ir("dash_1", "Sales", "");
        assert!(Generator::migrate(doc.clone(), "2.0.0").is_err());
        assert!(Generator::migrate(doc, "0.9.0").is_err());
    }
}
