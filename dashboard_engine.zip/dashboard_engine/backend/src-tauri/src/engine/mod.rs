//! Engine configuration and orchestration.

use crate::{EngineError, EngineResult};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

/// Top-level engine configuration loaded from env / config file.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EngineConfig {
    pub data_dir: PathBuf,
    pub max_query_rows: i64,
    pub default_query_timeout_sec: u64,
    pub max_discovery_objects: i32,
    pub discovery_timeout_sec: u64,
    pub cache_total_bytes: usize,
    pub cache_entry_bytes: usize,
    pub read_only_role: bool,
}

impl Default for EngineConfig {
    fn default() -> Self {
        Self {
            data_dir: std::env::var("DDE_DATA_DIR")
                .map(PathBuf::from)
                .unwrap_or_else(|_| std::env::temp_dir().join("dde")),
            max_query_rows: 1000,
            default_query_timeout_sec: 15,
            max_discovery_objects: 500,
            discovery_timeout_sec: 30,
            cache_total_bytes: 64 * 1024 * 1024,
            cache_entry_bytes: 2 * 1024 * 1024,
            read_only_role: true,
        }
    }
}

/// Engine orchestrator — coordinates discovery, planning, execution, UI-IR.
pub struct Engine {
    pub config: EngineConfig,
    pub store: crate::storage::Store,
    pub cache: crate::cache::CacheManager,
}

impl Engine {
    pub fn new(config: EngineConfig) -> EngineResult<Self> {
        std::fs::create_dir_all(&config.data_dir)?;
        let store = crate::storage::Store::open(&config.data_dir.join("config.sqlite"))?;
        let cache = crate::cache::CacheManager::new(config.cache_total_bytes, config.cache_entry_bytes)?;
        Ok(Self { config, store, cache })
    }

    /// Create a new dashboard draft.
    pub fn create_dashboard(&self, name: String, description: String) -> EngineResult<crate::storage::Dashboard> {
        self.store.create_dashboard(name, description)
    }

    /// List all dashboards.
    pub fn list_dashboards(&self) -> EngineResult<Vec<crate::storage::Dashboard>> {
        self.store.list_dashboards()
    }

    /// Get a dashboard by id.
    pub fn get_dashboard(&self, id: &str) -> EngineResult<Option<crate::storage::Dashboard>> {
        self.store.get_dashboard(id)
    }
}
