//! Plugin system — manifests, compatibility, lifecycle, registry.
//!
//! Plugins are declared by manifest only; this module never loads native code
//! itself. A future sandboxed loader (WASM / sidecar) consumes these types.

use crate::{EngineError, EngineResult};
use semver::{Version, VersionReq};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Plugin manifest — declared identity, version, capabilities.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PluginManifest {
    pub id: String,
    pub name: String,
    pub version: String,
    pub compatibility: PluginCompatibility,
    #[serde(default)]
    pub capabilities: Vec<String>,
    #[serde(default)]
    pub dependencies: Vec<String>,
    #[serde(default)]
    pub config_requirements: Vec<String>,
    /// `in_process` | `sidecar` | `wasm`
    pub sandbox_level: String,
    /// Relative entry point inside the plugin package (optional).
    #[serde(default)]
    pub entry: Option<String>,
    /// Fine-grained permissions the plugin may request.
    #[serde(default)]
    pub permissions: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PluginCompatibility {
    /// Semver requirement against the engine version, e.g. `^0.1`.
    pub engine: String,
    /// Semver requirement against the bridge/contracts version.
    pub bridge: String,
}

/// Lifecycle state of a registered plugin.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PluginState {
    Discovered,
    Validated,
    Loaded,
    Enabled,
    Disabled,
    Failed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RegisteredPlugin {
    pub manifest: PluginManifest,
    pub state: PluginState,
    pub error: Option<String>,
}

const SANDBOX_LEVELS: [&str; 3] = ["in_process", "sidecar", "wasm"];

impl PluginManifest {
    /// Structural validation: id format, semver version, sandbox level, deps.
    pub fn validate(&self) -> EngineResult<()> {
        if self.id.is_empty()
            || !self
                .id
                .chars()
                .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || matches!(c, '-' | '_' | '.'))
        {
            return Err(EngineError::invalid_ir(format!(
                "invalid plugin id: {}",
                self.id
            )));
        }
        if self.name.trim().is_empty() {
            return Err(EngineError::invalid_ir("plugin name is required".to_string()));
        }
        Version::parse(&self.version).map_err(|_| {
            EngineError::invalid_ir(format!("invalid plugin version: {}", self.version))
        })?;
        if !SANDBOX_LEVELS.contains(&self.sandbox_level.as_str()) {
            return Err(EngineError::invalid_ir(format!(
                "unknown sandbox level: {}",
                self.sandbox_level
            )));
        }
        if self.capabilities.is_empty() {
            return Err(EngineError::invalid_ir(
                "plugin must declare at least one capability".to_string(),
            ));
        }
        Ok(())
    }

    /// Check engine compatibility with a concrete engine version.
    pub fn check_compatibility(&self, engine_version: &str) -> EngineResult<()> {
        let engine = Version::parse(engine_version)
            .map_err(|_| EngineError::internal("engine version is not semver".to_string()))?;
        let requirement = VersionReq::parse(&self.compatibility.engine).map_err(|_| {
            EngineError::invalid_ir(format!(
                "invalid engine requirement: {}",
                self.compatibility.engine
            ))
        })?;
        if !requirement.matches(&engine) {
            return Err(EngineError::plugin_incompatible(format!(
                "plugin {} requires engine {}, running {}",
                self.id, self.compatibility.engine, engine_version
            )));
        }
        Ok(())
    }
}

/// Plugin registry — in-memory catalog of declared plugins.
#[derive(Debug, Default)]
pub struct PluginRegistry {
    plugins: HashMap<String, RegisteredPlugin>,
}

impl PluginRegistry {
    pub fn new() -> Self {
        Self {
            plugins: HashMap::new(),
        }
    }

    /// Validate and register a manifest in the `Discovered` state.
    pub fn register(&mut self, manifest: PluginManifest) -> EngineResult<()> {
        manifest.validate()?;
        manifest.check_compatibility(crate::ENGINE_VERSION)?;

        if self.plugins.contains_key(&manifest.id) {
            return Err(EngineError::config_conflict(format!(
                "plugin already registered: {}",
                manifest.id
            )));
        }

        let id = manifest.id.clone();
        self.plugins.insert(
            id,
            RegisteredPlugin {
                manifest,
                state: PluginState::Discovered,
                error: None,
            },
        );
        Ok(())
    }

    pub fn unregister(&mut self, id: &str) -> EngineResult<()> {
        self.plugins
            .remove(id)
            .map(|_| ())
            .ok_or_else(|| EngineError::invalid_ir(format!("plugin not found: {id}")))
    }

    pub fn get(&self, id: &str) -> Option<&RegisteredPlugin> {
        self.plugins.get(id)
    }

    pub fn get_mut(&mut self, id: &str) -> Option<&mut RegisteredPlugin> {
        self.plugins.get_mut(id)
    }

    /// All registered plugins, sorted by id for stable output.
    pub fn list(&self) -> Vec<&RegisteredPlugin> {
        let mut items: Vec<_> = self.plugins.values().collect();
        items.sort_by(|a, b| a.manifest.id.cmp(&b.manifest.id));
        items
    }

    pub fn set_state(
        &mut self,
        id: &str,
        state: PluginState,
        error: Option<String>,
    ) -> EngineResult<()> {
        let plugin = self
            .plugins
            .get_mut(id)
            .ok_or_else(|| EngineError::invalid_ir(format!("plugin not found: {id}")))?;
        plugin.state = state;
        plugin.error = error;
        Ok(())
    }

    /// Enable a plugin once all of its dependencies are enabled.
    pub fn enable(&mut self, id: &str) -> EngineResult<()> {
        let manifest = self
            .plugins
            .get(id)
            .map(|p| p.manifest.clone())
            .ok_or_else(|| EngineError::invalid_ir(format!("plugin not found: {id}")))?;

        for dep in &manifest.dependencies {
            match self.plugins.get(dep) {
                Some(p) if p.state == PluginState::Enabled => {}
                Some(_) => {
                    return Err(EngineError::config_conflict(format!(
                        "dependency {dep} of plugin {id} is not enabled"
                    )))
                }
                None => {
                    return Err(EngineError::config_conflict(format!(
                        "missing dependency {dep} for plugin {id}"
                    )))
                }
            }
        }

        self.set_state(id, PluginState::Enabled, None)
    }

    pub fn disable(&mut self, id: &str) -> EngineResult<()> {
        // Refuse to disable a plugin something else still depends on.
        let dependents: Vec<String> = self
            .plugins
            .values()
            .filter(|p| {
                p.state == PluginState::Enabled && p.manifest.dependencies.iter().any(|d| d == id)
            })
            .map(|p| p.manifest.id.clone())
            .collect();
        if !dependents.is_empty() {
            return Err(EngineError::config_conflict(format!(
                "plugin {id} is required by: {}",
                dependents.join(", ")
            )));
        }
        self.set_state(id, PluginState::Disabled, None)
    }
}

/// Minimal lifecycle trait a concrete sandboxed plugin implements.
pub trait Plugin {
    fn manifest(&self) -> &PluginManifest;
    fn on_load(&mut self) -> EngineResult<()>;
    fn on_enable(&mut self) -> EngineResult<()> {
        Ok(())
    }
    fn on_disable(&mut self) -> EngineResult<()> {
        Ok(())
    }
    fn on_unload(&mut self) -> EngineResult<()> {
        Ok(())
    }
}

pub mod traits {
    //! Reserved capability marker traits. Implementations arrive with the
    //! sandboxed loader; declaring them here keeps the plugin contract stable.
    pub trait DatabaseAdapter: super::Plugin {}
    pub trait SchemaProfiler: super::Plugin {}
    pub trait RelationshipProvider: super::Plugin {}
    pub trait AnalyticsProvider: super::Plugin {}
    pub trait AuthProvider: super::Plugin {}
    pub trait RealtimeAdapter: super::Plugin {}
}

pub mod loader {
    //! Manifest loading + compatibility validation.

    use crate::{EngineError, EngineResult};
    use super::{PluginManifest, PluginRegistry, PluginState};

    /// Parse a manifest from JSON and validate it.
    pub fn parse(json: &str) -> EngineResult<PluginManifest> {
        let manifest: PluginManifest = serde_json::from_str(json)
            .map_err(|e| EngineError::invalid_ir(format!("manifest parse: {e}")))?;
        manifest.validate()?;
        Ok(manifest)
    }

    /// Register a parsed manifest and mark it validated.
    pub fn load(registry: &mut PluginRegistry, manifest: PluginManifest) -> EngineResult<()> {
        manifest.check_compatibility(crate::ENGINE_VERSION)?;
        let id = manifest.id.clone();
        registry.register(manifest)?;
        registry.set_state(&id, PluginState::Validated, None)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn manifest(id: &str) -> PluginManifest {
        PluginManifest {
            id: id.to_string(),
            name: format!("Plugin {id}"),
            version: "1.0.0".to_string(),
            compatibility: PluginCompatibility {
                engine: "^0.1".to_string(),
                bridge: "^1.0".to_string(),
            },
            capabilities: vec!["database-adapter".to_string()],
            dependencies: Vec::new(),
            config_requirements: Vec::new(),
            sandbox_level: "wasm".to_string(),
            entry: None,
            permissions: Vec::new(),
        }
    }

    #[test]
    fn register_and_list() {
        let mut registry = PluginRegistry::new();
        registry.register(manifest("alpha")).expect("register");
        registry.register(manifest("beta")).expect("register");

        let ids: Vec<_> = registry.list().iter().map(|p| p.manifest.id.clone()).collect();
        assert_eq!(ids, vec!["alpha", "beta"]);
        assert_eq!(registry.get("alpha").unwrap().state, PluginState::Discovered);
    }

    #[test]
    fn rejects_duplicate_and_invalid_ids() {
        let mut registry = PluginRegistry::new();
        registry.register(manifest("alpha")).expect("register");
        assert!(registry.register(manifest("alpha")).is_err());

        let mut bad = manifest("Has Spaces");
        bad.id = "Bad Id".to_string();
        assert!(bad.validate().is_err());
    }

    #[test]
    fn rejects_incompatible_engine() {
        let mut plugin = manifest("future");
        plugin.compatibility.engine = "^99.0".to_string();
        assert!(plugin.check_compatibility(crate::ENGINE_VERSION).is_err());
    }

    #[test]
    fn dependency_ordering_is_enforced() {
        let mut registry = PluginRegistry::new();
        registry.register(manifest("base")).expect("register");
        let mut dependent = manifest("dependent");
        dependent.dependencies = vec!["base".to_string()];
        registry.register(dependent).expect("register");

        assert!(registry.enable("dependent").is_err());
        registry.enable("base").expect("enable base");
        registry.enable("dependent").expect("enable dependent");
        assert!(registry.disable("base").is_err());
    }
}
