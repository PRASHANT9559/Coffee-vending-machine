//! Universal UI & Auto-Dashboard Engine — Rust Core
//!
//! This crate provides the trusted backend engine:
//! - Dashboard config persistence (SQLite)
//! - Schema discovery & profiling (PostgreSQL / TimescaleDB)
//! - Relationship inference with confidence/provenance
//! - Query validation & bounded execution
//! - UI-IR generation, validation, migration
//! - Tauri IPC command layer

#[cfg(feature = "tauri")]
pub mod commands;
#[cfg(feature = "sqlite")]
pub mod engine;
pub mod discovery;
pub mod query;
pub mod uiir;
#[cfg(feature = "sqlite")]
pub mod storage;
pub mod cache;
pub mod plugins;
pub mod security;

/// Engine version (semver-compatible, matched against UI-IR version)
pub const ENGINE_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Result type used throughout the engine
pub type EngineResult<T> = Result<T, EngineError>;

/// Engine-level error with stable error codes
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct EngineError {
    pub code: ErrorCode,
    pub message: String,
    pub stage: Stage,
    pub request_id: Option<String>,
    pub retryable: bool,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq)]
pub enum ErrorCode {
    DsUnreachable,
    DsAuthFailed,
    DsReadOnlyDenied,
    DiscoveryTimeout,
    DiscoveryPartial,
    QueryForbidden,
    QueryInvalid,
    QueryTimeout,
    QueryCancelled,
    QueryLimitExceeded,
    IrInvalid,
    IrVersionUnsupported,
    ConfigConflict,
    ConfigCorrupt,
    PluginIncompatible,
    CacheCorrupt,
    Internal,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq)]
pub enum Stage {
    Resolve,
    Authorize,
    Discover,
    Plan,
    Validate,
    Compile,
    Execute,
    Shape,
    Save,
    Migrate,
    Internal,
}

impl std::fmt::Display for EngineError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{:?}: {} (stage: {:?})", self.code, self.message, self.stage)
    }
}

impl std::error::Error for EngineError {}

impl EngineError {
    pub fn forbidden(msg: impl Into<String>) -> Self {
        Self {
            code: ErrorCode::QueryForbidden,
            message: msg.into(),
            stage: Stage::Authorize,
            request_id: None,
            retryable: false,
        }
    }
    pub fn timeout(msg: impl Into<String>) -> Self {
        Self {
            code: ErrorCode::QueryTimeout,
            message: msg.into(),
            stage: Stage::Execute,
            request_id: None,
            retryable: true,
        }
    }
    pub fn invalid_ir(msg: impl Into<String>) -> Self {
        Self {
            code: ErrorCode::IrInvalid,
            message: msg.into(),
            stage: Stage::Validate,
            request_id: None,
            retryable: false,
        }
    }
    pub fn config_conflict(msg: impl Into<String>) -> Self {
        Self {
            code: ErrorCode::ConfigConflict,
            message: msg.into(),
            stage: Stage::Save,
            request_id: None,
            retryable: false,
        }
    }
    pub fn internal(msg: impl Into<String>) -> Self {
        Self {
            code: ErrorCode::Internal,
            message: msg.into(),
            stage: Stage::Internal,
            request_id: None,
            retryable: false,
        }
    }
    pub fn plugin_incompatible(msg: impl Into<String>) -> Self {
        Self {
            code: ErrorCode::PluginIncompatible,
            message: msg.into(),
            stage: Stage::Internal,
            request_id: None,
            retryable: false,
        }
    }
}

// Conversion impls so `?` works across the storage, filesystem, and JSON
// layers without leaking dependency-specific error types to callers.

impl From<std::io::Error> for EngineError {
    fn from(err: std::io::Error) -> Self {
        Self::internal(format!("io error: {err}"))
    }
}

impl From<serde_json::Error> for EngineError {
    fn from(err: serde_json::Error) -> Self {
        Self::internal(format!("json error: {err}"))
    }
}

#[cfg(feature = "sqlite")]
impl From<rusqlite::Error> for EngineError {
    fn from(err: rusqlite::Error) -> Self {
        Self::internal(format!("sqlite error: {err}"))
    }
}
