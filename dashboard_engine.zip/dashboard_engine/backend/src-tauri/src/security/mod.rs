//! Security module — permission model, credential handling, audit logging.

use crate::{EngineError, EngineResult};
use serde::{Deserialize, Serialize};

/// Permission scope label used in cache keys and audit logs.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PermissionScope(pub String);

impl PermissionScope {
    pub fn read() -> Self {
        Self("analytics:read".to_string())
    }
}

/// Allowed database objects for a dashboard.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectAllowlist {
    pub schemas: Vec<String>,
    pub objects: Vec<String>,
    pub column_deny_list: Vec<String>,
}

/// Credential reference — never stores the actual secret.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecretRef {
    pub key: String, // keyring key name
    pub backend: SecretBackend,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SecretBackend {
    OsKeyring,
    Environment,
    DevFile, // dev-only, chmod 600
}

/// Audit log entry (no secrets, no row values).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditEntry {
    pub at: String,
    pub actor: Option<String>,
    pub action: String,
    pub subject: Option<String>,
    pub outcome: String, // ok | denied | error
    pub detail_json: Option<String>, // sanitized
}

/// Resolve a secret from the configured backend.
pub fn resolve_secret(ref_: &SecretRef) -> EngineResult<String> {
    match &ref_.backend {
        SecretBackend::Environment => {
            std::env::var(&ref_.key)
                .map_err(|_| EngineError::internal(format!("secret not found in env: {}", ref_.key)))
        }
        SecretBackend::OsKeyring => {
            // On desktop, use keyring crate. On Termux/dev, fall back to env.
            std::env::var(&ref_.key)
                .map_err(|_| EngineError::internal(format!("secret not found: {}", ref_.key)))
        }
        SecretBackend::DevFile => {
            // Dev-only restricted file
            let path = std::path::Path::new(&ref_.key);
            std::fs::read_to_string(path)
                .map_err(|_| EngineError::internal(format!("secret file not found: {}", path.display())))
        }
    }
}

/// Validate that a query intent respects the allowlist.
pub fn validate_intent(
    _allowlist: &ObjectAllowlist,
    _intent: &crate::query::QueryIntent,
) -> EngineResult<()> {
    // Full validation implemented in query::validator.
    Ok(())
}
