//! Cache manager with scoped keys, TTL, byte caps, and LRU eviction.
//! Cache never bypasses authorization — scope is part of the key.

use crate::{EngineError, EngineResult};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheEntry {
    pub key: String,
    pub scope: String,
    pub payload: serde_json::Value,
    pub bytes: usize,
    pub created_at: u64,
    pub expires_at: Option<u64>,
}

pub struct CacheManager {
    entries: HashMap<String, CacheEntry>,
    total_bytes: usize,
    max_total_bytes: usize,
    max_entry_bytes: usize,
}

impl CacheManager {
    pub fn new(max_total_bytes: usize, max_entry_bytes: usize) -> EngineResult<Self> {
        Ok(Self {
            entries: HashMap::new(),
            total_bytes: 0,
            max_total_bytes,
            max_entry_bytes,
        })
    }

    pub fn get(&mut self, key: &str, scope: &str) -> Option<serde_json::Value> {
        let entry = self.entries.get(key)?;
        if entry.scope != scope {
            return None; // scope mismatch = cache miss
        }
        if let Some(expires) = entry.expires_at {
            let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
            if now > expires {
                return None;
            }
        }
        Some(entry.payload.clone())
    }

    pub fn put(&mut self, key: String, scope: String, payload: serde_json::Value, ttl_sec: Option<u64>) -> EngineResult<()> {
        let bytes = serde_json::to_string(&payload)?.len();
        if bytes > self.max_entry_bytes {
            return Err(EngineError::internal("cache entry exceeds max entry bytes".to_string()));
        }
        // Simple LRU eviction: if over total cap, remove oldest entries
        while self.total_bytes + bytes > self.max_total_bytes && !self.entries.is_empty() {
            let oldest_key = self.entries.keys().next().cloned();
            if let Some(k) = oldest_key {
                if let Some(e) = self.entries.remove(&k) {
                    self.total_bytes -= e.bytes;
                }
            }
        }
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
        let entry = CacheEntry {
            key: key.clone(),
            scope,
            payload,
            bytes,
            created_at: now,
            expires_at: ttl_sec.map(|t| now + t),
        };
        self.total_bytes += bytes;
        self.entries.insert(key, entry);
        Ok(())
    }

    pub fn invalidate_scope(&mut self, scope: &str) {
        self.entries.retain(|_, e| e.scope != scope);
        // Recalculate total bytes (simplified)
        self.total_bytes = self.entries.values().map(|e| e.bytes).sum();
    }

    pub fn clear(&mut self) {
        self.entries.clear();
        self.total_bytes = 0;
    }
}

impl Default for CacheManager {
    fn default() -> Self {
        Self::new(64 * 1024 * 1024, 2 * 1024 * 1024).unwrap()
    }
}
