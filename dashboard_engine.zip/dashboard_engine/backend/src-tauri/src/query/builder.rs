//! Safe query construction helpers.
use super::{Aggregate, QueryIntent, QueryIntentKind, SortDirection};

pub fn select(source_id: &str, fields: &[String]) -> QueryIntent {
    QueryIntent {
        kind: QueryIntentKind::Select,
        source_id: source_id.to_string(),
        fields: fields.to_vec(),
        order_by: vec![],
        limit: Some(100),
        offset: None,
        group_by: None,
        aggregates: None,
        time_column: None,
        bucket: None,
    }
}

pub fn aggregate(
    source_id: &str,
    fields: &[String],
    aggregates: Vec<Aggregate>,
) -> QueryIntent {
    QueryIntent {
        kind: QueryIntentKind::Aggregate,
        source_id: source_id.to_string(),
        fields: fields.to_vec(),
        order_by: vec![],
        limit: Some(1),
        offset: None,
        group_by: None,
        aggregates: Some(aggregates),
        time_column: None,
        bucket: None,
    }
}

pub fn grouped(
    source_id: &str,
    fields: &[String],
    group_by: Vec<String>,
    aggregates: Vec<Aggregate>,
) -> QueryIntent {
    QueryIntent {
        kind: QueryIntentKind::Grouped,
        source_id: source_id.to_string(),
        fields: fields.to_vec(),
        order_by: vec![],
        limit: Some(100),
        offset: None,
        group_by: Some(group_by),
        aggregates: Some(aggregates),
        time_column: None,
        bucket: None,
    }
}

pub fn timeseries(
    source_id: &str,
    time_column: String,
    value_field: String,
    bucket: String,
    limit: i64,
) -> QueryIntent {
    QueryIntent {
        kind: QueryIntentKind::Timeseries,
        source_id: source_id.to_string(),
        fields: vec![time_column.clone(), value_field],
        order_by: vec![super::SortSpec {
            field: time_column,
            direction: SortDirection::Asc,
        }],
        limit: Some(limit),
        offset: None,
        group_by: None,
        aggregates: Some(vec![Aggregate::Sum]),
        time_column: Some(time_column),
        bucket: Some(bucket),
    }
}
