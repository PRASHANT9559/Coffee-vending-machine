//! Query system — intent model, validation, execution, aggregation.
//! All queries are read-only, parameterized, bounded, and cancellable.

use crate::{EngineError, EngineResult};
use serde::{Deserialize, Serialize};

/// Declarative description of desired data — NOT raw SQL.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueryIntent {
    pub kind: QueryIntentKind,
    pub source_id: String,
    pub fields: Vec<String>,
    pub order_by: Vec<SortSpec>,
    pub limit: Option<i64>,
    pub offset: Option<i64>,
    pub group_by: Option<Vec<String>>,
    pub aggregates: Option<Vec<Aggregate>>,
    pub time_column: Option<String>,
    pub bucket: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum QueryIntentKind {
    Select,
    Aggregate,
    Grouped,
    Timeseries,
    Distribution,
    TopN,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SortSpec {
    pub field: String,
    pub direction: SortDirection,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum SortDirection {
    Asc,
    Desc,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum Aggregate {
    Count,
    Sum,
    Avg,
    Min,
    Max,
    Distinct,
}

/// Validated, compiled form of an intent — ready for the adapter.
#[derive(Debug, Clone)]
pub struct QueryPlan {
    pub intent: QueryIntent,
    pub sql: String,
    pub params: Vec<serde_json::Value>,
    pub timeout_ms: u64,
    pub max_rows: i64,
}

/// Shaped query result returned to the frontend.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueryResult {
    pub columns: Vec<String>,
    pub rows: Vec<serde_json::Value>,
    pub row_count: i64,
    pub truncated: bool,
    pub execution_ms: u64,
}

pub mod validator;

pub mod executor;

pub mod builder;

/// Compile a QueryIntent into a read-only, parameterized QueryPlan.
/// All SQL is generated internally — raw SQL never reaches this path.
pub fn compile_query(
    intent: &QueryIntent,
    source_id: &str,
    allowlist: &crate::query::validator::ObjectAllowlist,
    timeout_ms: u64,
    max_rows: i64,
) -> EngineResult<QueryPlan> {
    // --- 1. Allowlist check: object must be allowed ---
    let object_allowed = allowlist.objects.contains(&source_id.to_string())
        || allowlist
            .objects
            .iter()
            .any(|o| o == source_id || o.ends_with(&format!(".{}", source_id)));
    if !object_allowed && allowlist.objects.is_empty() {
        // When allowlist is empty, fall back to schema allowlist check below.
    }
    if !allowlist.objects.is_empty() && !object_allowed {
        return Err(EngineError::forbidden(format!(
            "object {source_id} not allowlisted"
        )));
    }

    // --- 2. Columns must be subset of allowed / not denied ---
    let denied: std::collections::HashSet<&str> =
        allowlist.column_deny_list.iter().map(|s| s.as_str()).collect();
    for field in &intent.fields {
        if denied.contains(field.as_str()) {
            return Err(EngineError::forbidden(format!(
                "column {field} is denied"
            )));
        }
    }
    for agg in intent.aggregates.iter().flatten() {
        match agg {
            crate::query::Aggregate::Count => {}
            crate::query::Aggregate::Sum
            | crate::query::Aggregate::Avg
            | crate::query::Aggregate::Min
            | crate::query::Aggregate::Max
            | crate::query::Aggregate::Distinct => {
                // Field-level denial checked above for the single aggregate field
            }
        }
    }

    // --- 3. Build SELECT columns ---
    let select_sql: String = if intent.fields.is_empty() {
        "*".to_string()
    } else {
        intent
            .fields
            .iter()
            .map(|f| {
                if f == "*" {
                    "*".to_string()
                } else {
                    format!("\"{}\"", f)
                }
            })
            .collect::<Vec<_>>()
            .join(", ")
    };

    // --- 4. Build SELECT kind ---
    // `first_field` is owned so aggregate arms never hold a reference to a
    // temporary `String`. `*` is passed through unquoted.
    let first_field = intent
        .fields
        .first()
        .cloned()
        .unwrap_or_else(|| "*".to_string());
    let agg_field = if first_field == "*" {
        "*".to_string()
    } else {
        format!("\"{first_field}\"")
    };
    let default_aggs = vec![Aggregate::Count];

    // Kinds contribute at most one implicit ORDER BY / LIMIT. They are applied
    // once below so a caller-supplied `order_by` can never produce duplicate
    // (invalid) ORDER BY/LIMIT clauses.
    let mut kind_order: Option<String> = None;
    let mut kind_limit: Option<i64> = None;

    let aggregate_sql = |aggs: &[Aggregate]| -> String {
        aggs.iter()
            .map(|a| match a {
                Aggregate::Count => format!("COUNT({agg_field}) as count_value"),
                Aggregate::Sum => format!("SUM({agg_field}) as sum_value"),
                Aggregate::Avg => format!("AVG({agg_field}) as avg_value"),
                Aggregate::Min => format!("MIN({agg_field}) as min_value"),
                Aggregate::Max => format!("MAX({agg_field}) as max_value"),
                Aggregate::Distinct => {
                    format!("COUNT(DISTINCT {agg_field}) as distinct_value")
                }
            })
            .collect::<Vec<_>>()
            .join(", ")
    };

    let (select_prefix, group_sql) = match &intent.kind {
        QueryIntentKind::Select => (select_sql.clone(), String::new()),
        QueryIntentKind::Aggregate => {
            let aggs = intent.aggregates.as_deref().ok_or_else(|| {
                EngineError::invalid_ir("aggregate requires aggregates".to_string())
            })?;
            (aggregate_sql(aggs), String::new())
        }
        QueryIntentKind::Grouped => {
            let group_by = intent.group_by.as_ref().ok_or_else(|| {
                EngineError::invalid_ir("grouped requires group_by".to_string())
            })?;
            let aggs = intent.aggregates.as_deref().unwrap_or(&default_aggs);
            let agg_sql = aggregate_sql(aggs);
            let group_cols = group_by
                .iter()
                .map(|f| format!("\"{}\"", f))
                .collect::<Vec<_>>()
                .join(", ");
            let select = if group_cols.is_empty() {
                agg_sql
            } else {
                format!("{group_cols}, {agg_sql}")
            };
            (select, format!(" GROUP BY {group_cols}"))
        }
        QueryIntentKind::Timeseries => {
            let time_col = intent.time_column.as_ref().ok_or_else(|| {
                EngineError::invalid_ir("timeseries requires time_column".to_string())
            })?;
            let bucket = intent.bucket.as_deref().unwrap_or("1 hour");
            let aggs = intent.aggregates.as_deref().unwrap_or(&default_aggs);
            let agg_sql = aggregate_sql(aggs);
            kind_order = Some(" ORDER BY bucket".to_string());
            (
                format!("date_trunc('{bucket}', \"{time_col}\") as bucket, {agg_sql}"),
                " GROUP BY bucket".to_string(),
            )
        }
        QueryIntentKind::Distribution => {
            let field = intent.fields.first().cloned().unwrap_or_default();
            kind_order = Some(" ORDER BY count_value DESC".to_string());
            (
                format!("\"{field}\" as value, COUNT(*) as count_value"),
                format!(" GROUP BY \"{field}\""),
            )
        }
        QueryIntentKind::TopN => {
            let field = intent.fields.first().cloned().unwrap_or_default();
            kind_order = Some(" ORDER BY count_value DESC".to_string());
            kind_limit = Some(intent.limit.unwrap_or(10));
            (
                format!("\"{field}\" as value, COUNT(*) as count_value"),
                format!(" GROUP BY \"{field}\""),
            )
        }
    };

    // --- 5. Assemble final SQL (SELECT only — never write) ---
    let order_sql = if intent.order_by.is_empty() {
        kind_order.unwrap_or_default()
    } else {
        let specs: Vec<String> = intent
            .order_by
            .iter()
            .map(|s| {
                let direction = match s.direction {
                    SortDirection::Asc => "ASC",
                    SortDirection::Desc => "DESC",
                };
                format!("\"{}\" {direction}", s.field)
            })
            .collect();
        format!(" ORDER BY {}", specs.join(", "))
    };

    // Hard bound: never emit more rows than the plan allows.
    let limit = intent
        .limit
        .or(kind_limit)
        .unwrap_or(100)
        .clamp(0, max_rows.max(1));
    let limit_sql = format!(" LIMIT {limit}");

    let offset_sql = match intent.offset {
        Some(o) if o > 0 => format!(" OFFSET {o}"),
        _ => String::new(),
    };

    // Quote each identifier part: `public.users` -> "public"."users".
    let source_ref = match source_id.split_once('.') {
        Some((schema, table)) => format!("\"{schema}\".\"{table}\""),
        None => format!("\"{source_id}\""),
    };
    let sql = format!(
        "SELECT {select_prefix} FROM {source_ref}{group_sql}{order_sql}{limit_sql}{offset_sql}"
    );

    Ok(QueryPlan {
        intent: intent.clone(),
        sql,
        params: Vec::new(),
        timeout_ms,
        max_rows,
    }
}
