//! Query execution with timeouts, cancellation, and result shaping.
//! Read-only, parameterized, bounded. Requires the `postgres` feature.

use crate::{EngineError, EngineResult};
use super::{QueryPlan, QueryResult};

/// Execute a compiled plan against PostgreSQL and shape the result.
#[cfg(feature = "postgres")]
pub async fn execute(
    connection_string: &str,
    plan: &QueryPlan,
) -> EngineResult<QueryResult> {
    use tokio_postgres::types::ToSql;
    use tokio_postgres::NoTls;

    let (client, connection) = tokio_postgres::connect(connection_string, NoTls)
        .await
        .map_err(|e| EngineError::internal(format!("postgres connect: {e}")))?;

    tokio::spawn(async move {
        if let Err(e) = connection.await {
            tracing::warn!("postgres connection dropped: {e}");
        }
    });

    let statement = client
        .prepare(&plan.sql)
        .await
        .map_err(|e| EngineError::forbidden(format!("prepare: {e}")))?;

    // serde_json::Value has no ToSql impl — map each value onto a concrete
    // PostgreSQL-compatible parameter type. Nulls become typed NULLs.
    fn to_param(value: &serde_json::Value) -> Box<dyn ToSql + Sync> {
        match value {
            serde_json::Value::Null => Box::new(Option::<String>::None),
            serde_json::Value::Bool(b) => Box::new(*b),
            serde_json::Value::Number(n) => {
                if let Some(i) = n.as_i64() {
                    Box::new(i)
                } else if let Some(f) = n.as_f64() {
                    Box::new(f)
                } else {
                    Box::new(n.to_string())
                }
            }
            serde_json::Value::String(s) => Box::new(s.clone()),
            other => Box::new(other.to_string()),
        }
    }

    let owned: Vec<Box<dyn ToSql + Sync>> = plan.params.iter().map(to_param).collect();
    let params: Vec<&(dyn ToSql + Sync)> = owned.iter().map(|b| b.as_ref()).collect();

    let start = std::time::Instant::now();

    // The compiled SQL already carries a bounded LIMIT, so plain `query` keeps
    // the result set small while a timeout still guards slow statements.
    let rows = tokio::time::timeout(
        std::time::Duration::from_millis(plan.timeout_ms),
        client.query(&statement, &params),
    )
    .await
    .map_err(|_| EngineError::timeout("query exceeded timeout".to_string()))?
    .map_err(|e| EngineError::forbidden(format!("execute: {e}")))?;

    let mut columns: Vec<String> = Vec::new();
    if let Some(first) = rows.first() {
        columns = first.columns().iter().map(|c| c.name().to_string()).collect();
    }

    let max_rows = plan.max_rows.max(0) as usize;
    let truncated = rows.len() > max_rows;
    let mut out_rows: Vec<serde_json::Value> = Vec::with_capacity(rows.len().min(max_rows));

    for (r_index, row) in rows.iter().take(max_rows).enumerate() {
        let mut obj = serde_json::Map::new();
        for (i, col) in columns.iter().enumerate() {
            obj.insert(col.clone(), column_json(row, i, r_index as i32));
        }
        out_rows.push(serde_json::Value::Object(obj));
    }

    Ok(QueryResult {
        columns,
        rows: out_rows,
        row_count: rows.len().min(max_rows) as i64,
        truncated,
        execution_ms: start.elapsed().as_millis() as u64,
    })
}

/// Best-effort conversion of a Postgres column into JSON without depending on
/// concrete SQL types. Tries common types in order, falls back to NULL.
#[cfg(feature = "postgres")]
fn column_json(row: &tokio_postgres::Row, index: usize, _row_index: i32) -> serde_json::Value {
    use serde_json::Value;

    if let Ok(v) = row.try_get::<_, Option<String>>(index) {
        return match v {
            Some(s) => {
                // Rehydrate numeric/boolean strings where safe.
                if let Ok(parsed) = serde_json::from_str::<Value>(&s) {
                    match parsed {
                        Value::Number(_) | Value::Bool(_) | Value::Null => parsed,
                        _ => Value::String(s),
                    }
                } else {
                    Value::String(s)
                }
            }
            None => Value::Null,
        };
    }
    if let Ok(v) = row.try_get::<_, Option<i64>>(index) {
        return v.map(Value::from).unwrap_or(Value::Null);
    }
    if let Ok(v) = row.try_get::<_, Option<f64>>(index) {
        return v
            .and_then(serde_json::Number::from_f64)
            .map(Value::Number)
            .unwrap_or(Value::Null);
    }
    if let Ok(v) = row.try_get::<_, Option<bool>>(index) {
        return v.map(Value::from).unwrap_or(Value::Null);
    }
    Value::Null
}

/// Stub build without the postgres feature.
#[cfg(not(feature = "postgres"))]
pub async fn execute(
    _connection_string: &str,
    _plan: &QueryPlan,
) -> EngineResult<QueryResult> {
    Err(EngineError::internal("postgres feature not enabled".to_string()))
}

/// Cancel a running query (best effort). No in-flight tracking yet.
pub fn cancel(_request_id: &str) -> EngineResult<()> {
    Ok(())
}
