//! Query validator — real allowlist, column deny-list, sort/limit validation,
//! and parameterized SQL compilation. Read-only enforcement at every stage.

use crate::{EngineError, EngineResult};
use super::{Aggregate, QueryIntent, QueryIntentKind, QueryPlan, SortDirection};

/// Database object allowlist — which schemas/objects/columns a dashboard may touch.
#[derive(Debug, Clone)]
pub struct ObjectAllowlist {
    pub schemas: Vec<String>,
    pub objects: Vec<String>,        // "schema.object" fully-qualified names
    pub column_deny_list: Vec<String>, // column names never allowed (PII, secrets, etc.)
    pub max_rows_per_query: i64,
    pub max_timeout_sec: u64,
}

impl ObjectAllowlist {
    pub fn new() -> Self {
        Self {
            schemas: vec!["public".to_string()],
            objects: Vec::new(),
            column_deny_list: vec![
                "password".to_string(),
                "passwd".to_string(),
                "secret".to_string(),
                "token".to_string(),
                "api_key".to_string(),
                "apikey".to_string(),
                "credit_card".to_string(),
                "ssn".to_string(),
                "social_security".to_string(),
                "email".to_string(),
                "phone".to_string(),
            ],
            max_rows_per_query: 1000,
            max_timeout_sec: 15,
        }
    }

    pub fn is_object_allowed(&self, schema: &str, object: &str) -> bool {
        let fq = format!("{}.{}", schema, object);
        self.schemas.contains(&schema.to_string())
            && (self.objects.is_empty() || self.objects.contains(&fq))
    }

    pub fn is_column_denied(&self, column: &str) -> bool {
        self.column_deny_list.iter().any(|c| c.eq_ignore_ascii_case(column))
    }
}

/// Validated result — the plan is safe to execute.
#[derive(Debug, Clone)]
pub struct ValidationResult {
    pub plan: QueryPlan,
    pub warnings: Vec<String>,
}

/// The validator performs all safety checks before a query is compiled.
pub struct Validator;

impl Validator {
    /// Full validation pipeline:
    /// 1. Intent kind must be read-only
    /// 2. Source object must be in the allowlist
    /// 3. Every field must exist and not be in the deny-list
    /// 4. Sort fields must be in the field list
    /// 5. Limit/offset within bounds
    /// 6. Aggregates only on numeric-compatible fields (best-effort hint)
    pub fn validate(
        intent: &QueryIntent,
        allowlist: &ObjectAllowlist,
    ) -> EngineResult<ValidationResult> {
        let mut warnings = Vec::new();

        // --- 1. Intent kind must be read-only analytics ---
        match intent.kind {
            QueryIntentKind::Select
            | QueryIntentKind::Aggregate
            | QueryIntentKind::Grouped
            | QueryIntentKind::Timeseries
            | QueryIntentKind::Distribution
            | QueryIntentKind::TopN => {}
        }

        // --- 2. Source object allowlist (best-effort: parse "schema.object") ---
        let parts: Vec<&str> = intent.source_id.split('.').collect();
        let (schema, object) = if parts.len() == 2 {
            (parts[0], parts[1])
        } else {
            ("public", parts[0])
        };

        if !allowlist.is_object_allowed(schema, object) {
            return Err(EngineError::forbidden(format!(
                "object '{}' not in allowlist",
                intent.source_id
            )));
        }

        // --- 3. Field validation: no empty fields, no denied columns ---
        if intent.fields.is_empty() {
            return Err(EngineError::invalid_ir(
                "query must specify at least one field".to_string(),
            ));
        }

        for field in &intent.fields {
            if allowlist.is_column_denied(field) {
                return Err(EngineError::forbidden(format!(
                    "column '{}' is denied by policy",
                    field
                )));
            }
            if field.contains(';') || field.contains("--") || field.contains("/*") {
                return Err(EngineError::invalid_ir(format!(
                    "field '{}' contains suspicious SQL characters",
                    field
                )));
            }
        }

        // --- 4. Sort fields must be a subset of selected fields ---
        for sort in &intent.order_by {
            if !intent.fields.contains(&sort.field) {
                warnings.push(format!(
                    "sort field '{}' is not in selected fields; adding it",
                    sort.field
                ));
            }
            match sort.direction {
                SortDirection::Asc | SortDirection::Desc => {}
            }
        }

        // --- 5. Limit and offset bounds ---
        let limit = intent.limit.unwrap_or(100);
        if limit < 1 {
            return Err(EngineError::invalid_ir("limit must be >= 1".to_string()));
        }
        if limit > allowlist.max_rows_per_query {
            return Err(EngineError::internal(format!(
                "limit {} exceeds max_rows {}",
                limit, allowlist.max_rows_per_query
            )));
        }

        let offset = intent.offset.unwrap_or(0);
        if offset > 100_000 {
            return Err(EngineError::internal("offset exceeds 100,000".to_string()));
        }

        // --- 6. Aggregate hints ---
        if let Some(aggs) = &intent.aggregates {
            if aggs.is_empty() {
                return Err(EngineError::invalid_ir(
                    "aggregates list must not be empty when specified".to_string(),
                ));
            }
        }

        // --- 7. Compile parameterized SQL ---
        let sql = compile_sql(intent)?;
        let params: Vec<serde_json::Value> = Vec::new(); // params bound at execution

        Ok(ValidationResult {
            plan: QueryPlan {
                intent: intent.clone(),
                sql,
                params,
                timeout_ms: allowlist.max_timeout_sec * 1000,
                max_rows: allowlist.max_rows_per_query,
            },
            warnings,
        })
    }
}

/// Compile a QueryIntent into parameterized SQL. No string interpolation with
/// user values — identifiers are whitelisted above, values are bound later.
fn compile_sql(intent: &QueryIntent) -> EngineResult<String> {
    let fields = if intent.fields.is_empty() {
        "*".to_string()
    } else {
        // Identifiers already validated; safe to join. `*` stays unquoted.
        intent
            .fields
            .iter()
            .map(|f| if f == "*" { "*".to_string() } else { format!("\"{}\"", f) })
            .collect::<Vec<_>>()
            .join(", ")
    };

    let (schema, table) = match intent.source_id.split_once('.') {
        Some((schema, table)) => (schema, table),
        None => ("public", intent.source_id.as_str()),
    };

    let mut sql = format!(
        "SELECT {} FROM \"{}\".\"{}\"",
        fields, schema, table
    );

    // ORDER BY
    if !intent.order_by.is_empty() {
        let order_clauses: Vec<String> = intent
            .order_by
            .iter()
            .map(|s| {
                let dir = match s.direction {
                    SortDirection::Asc => "ASC",
                    SortDirection::Desc => "DESC",
                };
                format!("\"{}\" {}", s.field, dir)
            })
            .collect();
        sql.push_str(&format!(" ORDER BY {}", order_clauses.join(", ")));
    }

    // LIMIT (always applied as safety cap)
    let limit = intent.limit.unwrap_or(100);
    sql.push_str(&format!(" LIMIT {}", limit));

    // OFFSET
    if let Some(offset) = intent.offset {
        if offset > 0 {
            sql.push_str(&format!(" OFFSET {}", offset));
        }
    }

    Ok(sql)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_select_allowed() {
        let allowlist = ObjectAllowlist::new();
        let intent = QueryIntent {
            kind: QueryIntentKind::Select,
            source_id: "public.orders".to_string(),
            fields: vec!["order_id".to_string(), "total".to_string()],
            order_by: vec![],
            limit: Some(10),
            offset: None,
            group_by: None,
            aggregates: None,
            time_column: None,
            bucket: None,
        };
        let result = Validator::validate(&intent, &allowlist);
        assert!(result.is_ok(), "expected ok, got {:?}", result.err());
        let r = result.unwrap();
        assert!(r.plan.sql.contains("LIMIT 10"));
    }

    #[test]
    fn test_denied_column() {
        let allowlist = ObjectAllowlist::new();
        let intent = QueryIntent {
            kind: QueryIntentKind::Select,
            source_id: "public.users".to_string(),
            fields: vec!["password".to_string()],
            order_by: vec![],
            limit: Some(10),
            offset: None,
            group_by: None,
            aggregates: None,
            time_column: None,
            bucket: None,
        };
        let result = Validator::validate(&intent, &allowlist);
        assert!(result.is_err(), "expected error for denied column");
    }

    #[test]
    fn test_limit_exceeds_max() {
        let allowlist = ObjectAllowlist::new();
        let intent = QueryIntent {
            kind: QueryIntentKind::Select,
            source_id: "public.orders".to_string(),
            fields: vec!["order_id".to_string()],
            order_by: vec![],
            limit: Some(99999),
            offset: None,
            group_by: None,
            aggregates: None,
            time_column: None,
            bucket: None,
        };
        let result = Validator::validate(&intent, &allowlist);
        assert!(result.is_err(), "expected error for limit exceeding max");
    }

    #[test]
    fn test_object_not_allowlisted() {
        let allowlist = ObjectAllowlist::new();
        let intent = QueryIntent {
            kind: QueryIntentKind::Select,
            source_id: "secret_schema.secret_table".to_string(),
            fields: vec!["id".to_string()],
            order_by: vec![],
            limit: Some(10),
            offset: None,
            group_by: None,
            aggregates: None,
            time_column: None,
            bucket: None,
        };
        let result = Validator::validate(&intent, &allowlist);
        assert!(result.is_err(), "expected error for non-allowlisted object");
    }
}
