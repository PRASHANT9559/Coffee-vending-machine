//! PostgreSQL introspection SQL queries — all read-only, parameterized,
//! bounded, and safe. These run against `information_schema` and `pg_catalog`.

/// List all schemas accessible to the current user (excluding system schemas).
pub const LIST_SCHEMAS: &str = r#"
    SELECT schema_name
    FROM information_schema.schemata
    WHERE schema_name NOT IN ('pg_catalog', 'information_schema')
      AND schema_name NOT LIKE 'pg_%'
    ORDER BY schema_name
"#;

/// List tables, views, and materialized views in allowed schemas.
pub const LIST_OBJECTS: &str = r#"
    SELECT
        n.nspname AS schema_name,
        c.relname AS object_name,
        CASE c.relkind
            WHEN 'r' THEN 'table'
            WHEN 'v' THEN 'view'
            WHEN 'm' THEN 'materialized_view'
            WHEN 'p' THEN 'table'
            ELSE 'other'
        END AS object_type,
        obj_description(c.oid) AS comment,
        c.reltuples::bigint AS estimated_rows
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname NOT IN ('pg_catalog', 'information_schema')
      AND n.nspname NOT LIKE 'pg_%'
      AND c.relkind IN ('r', 'v', 'm', 'p')
    ORDER BY n.nspname, c.relname
"#;

/// List columns for a given schema.object.
pub const LIST_COLUMNS: &str = r#"
    SELECT
        c.column_name,
        c.ordinal_position AS ordinal,
        c.data_type,
        (c.is_nullable = 'YES') AS nullable,
        c.column_default AS default_expr
    FROM information_schema.columns c
    WHERE c.table_schema = $1
      AND c.table_name = $2
    ORDER BY c.ordinal_position
"#;

/// List primary key column names for a given schema.object.
pub const LIST_PRIMARY_KEYS: &str = r#"
    SELECT a.attname AS column_name
    FROM pg_index i
    JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
    WHERE i.indisprimary
      AND i.indrelid = (
          SELECT c.oid FROM pg_class c
          JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE n.nspname = $1 AND c.relname = $2
      )
    ORDER BY a.attnum
"#;

/// List foreign key (from_column -> to_table.to_column) for a given schema.object.
pub const LIST_FOREIGN_KEYS: &str = r#"
    SELECT
        a.attname AS from_column,
        fn.nspname || '.' || fc.relname AS to_table,
        fa.attname AS to_column
    FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    JOIN pg_class fc ON fc.oid = con.confrelid
    JOIN pg_namespace fn ON fn.oid = fc.relnamespace
    JOIN LATERAL unnest(con.conkey) WITH ORDINALITY AS k(attnum, ord) ON true
    JOIN LATERAL unnest(con.confkey) WITH ORDINALITY AS f(attnum, ord) ON f.ord = k.ord
    JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum = k.attnum
    JOIN pg_attribute fa ON fa.attrelid = fc.oid AND fa.attnum = f.attnum
    WHERE con.contype = 'f'
      AND n.nspname = $1
      AND c.relname = $2
    ORDER BY a.attnum
"#;

/// All foreign key relationships across allowed schemas.
pub const LIST_ALL_FOREIGN_KEYS: &str = r#"
    SELECT
        (tc.table_schema || '.' || tc.table_name) AS from_object,
        kcu.column_name AS from_column,
        (ccu.table_schema || '.' || ccu.table_name) AS to_object,
        ccu.column_name AS to_column
    FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
        ON tc.constraint_name = kcu.constraint_name
       AND tc.table_schema = kcu.table_schema
    JOIN information_schema.constraint_column_usage ccu
        ON tc.constraint_name = ccu.constraint_name
       AND tc.table_schema = ccu.table_schema
    WHERE tc.constraint_type = 'FOREIGN KEY'
      AND tc.table_schema NOT IN ('pg_catalog', 'information_schema')
      AND tc.table_schema NOT LIKE 'pg_%'
    ORDER BY from_object, from_column
"#;

/// Column read from LIST_COLUMNS.
#[derive(Debug, Clone)]
pub struct DiscoveredColumn {
    pub column_name: String,
    pub ordinal: i32,
    pub data_type: String,
    pub nullable: bool,
    pub default_expr: Option<String>,
}

/// Foreign key read from LIST_FOREIGN_KEYS.
#[derive(Debug, Clone)]
pub struct DiscoveredForeignKey {
    pub from_column: String,
    pub to_table: String,
    pub to_column: String,
}
