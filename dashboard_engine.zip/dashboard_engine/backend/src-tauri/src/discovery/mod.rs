//! Schema discovery — introspection, JSONB profiling, relationship inference.
//! Bounded and cancellable. Read-only only.

use crate::{EngineError, EngineResult};
use serde::{Deserialize, Serialize};
use std::collections::HashSet;

#[cfg(feature = "postgres")]
use std::collections::HashMap;

/// Immutable result of one discovery run.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SchemaSnapshot {
    pub id: String,
    pub data_source_id: String,
    pub fingerprint: String,
    pub engine_version: String,
    pub status: String, // complete | partial | stale | failed
    pub tables: Vec<SchemaObject>,
    pub relationships: Vec<RelationshipCandidate>,
    pub profiled: Option<JsonbProfileSummary>,
}

/// Discovered database object.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SchemaObject {
    pub object_id: String,
    pub schema_name: String,
    pub object_name: String,
    pub object_type: String, // table | view | materialized_view
    pub estimated_rows: Option<i64>,
    pub columns: Vec<SchemaColumn>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SchemaColumn {
    pub column_name: String,
    pub ordinal: i32,
    pub data_type: String,
    pub nullable: bool,
    pub is_primary_key: bool,
    pub is_foreign_key: bool,
    pub default_expr: Option<String>,
}

/// Relationship candidate with confidence/provenance.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RelationshipCandidate {
    pub id: String,
    pub from_object_id: String,
    pub from_columns: Vec<String>,
    pub to_object_id: String,
    pub to_columns: Vec<String>,
    pub kind: String, // fk | unique_inferred | name_inferred | jsonb_inferred
    pub confidence: f64,
    pub provenance: String, // constraint | index | profile | heuristic
    pub reviewed: bool,
    pub accepted: Option<bool>,
}

/// JSONB profiling summary (bounded, aggregated — no raw samples).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JsonbProfileSummary {
    pub object_id: String,
    pub column_name: String,
    pub paths: Vec<JsonbPathProfile>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JsonbPathProfile {
    pub path: String,
    pub value_type: String,
    pub null_fraction: f64,
    pub distinct_cap: i32,
}

/// Discovery engine — coordinates PostgreSQL introspection + inference.
pub struct Discovery;

impl Discovery {
    /// Introspect a PostgreSQL data source and produce a snapshot.
    #[cfg(feature = "postgres")]
    pub async fn inspect(
        connection_string: &str,
        max_objects: i32,
        timeout_sec: u64,
    ) -> EngineResult<SchemaSnapshot> {
        use tokio_postgres::NoTls;

        let (client, connection) = tokio_postgres::connect(connection_string, NoTls)
            .await
            .map_err(|e| EngineError::internal(format!("postgres connect: {e}")))?;

        // The connection object performs the actual I/O; spawn it so it runs
        // concurrently while we issue queries on the client.
        tokio::spawn(async move {
            if let Err(e) = connection.await {
                tracing::warn!("postgres connection dropped: {e}");
            }
        });

        let work = async {
            let objects = Self::list_objects(&client, max_objects).await?;
            let relationships = Self::infer_relationships(&client, &objects).await?;
            Ok::<_, EngineError>((objects, relationships))
        };

        let (objects, relationships) = tokio::time::timeout(
            std::time::Duration::from_secs(timeout_sec.max(1)),
            work,
        )
        .await
        .map_err(|_| EngineError::timeout("schema discovery timed out".to_string()))??;

        let fingerprint = Self::fingerprint(&objects);

        Ok(SchemaSnapshot {
            id: uuid::Uuid::new_v4().to_string(),
            data_source_id: "".to_string(), // filled by caller
            fingerprint,
            engine_version: crate::ENGINE_VERSION.to_string(),
            status: "complete".to_string(),
            tables: objects,
            relationships,
            profiled: None,
        })
    }

    #[cfg(not(feature = "postgres"))]
    pub async fn inspect(
        _connection_string: &str,
        _max_objects: i32,
        _timeout_sec: u64,
    ) -> EngineResult<SchemaSnapshot> {
        Err(EngineError::internal(
            "postgres feature not enabled".to_string(),
        ))
    }

    /// Verify a connection string can open a session and run `SELECT 1`.
    #[cfg(feature = "postgres")]
    pub async fn test_connection(connection_string: &str) -> EngineResult<()> {
        use tokio_postgres::NoTls;

        let (client, connection) = tokio_postgres::connect(connection_string, NoTls)
            .await
            .map_err(|e| EngineError::internal(format!("postgres connect: {e}")))?;

        tokio::spawn(async move {
            if let Err(e) = connection.await {
                tracing::warn!("postgres connection dropped: {e}");
            }
        });

        client
            .simple_query("SELECT 1")
            .await
            .map_err(|e| EngineError::internal(format!("connection test: {e}")))?;
        Ok(())
    }

    #[cfg(not(feature = "postgres"))]
    pub async fn test_connection(_connection_string: &str) -> EngineResult<()> {
        Err(EngineError::internal("postgres feature not enabled".to_string()))
    }

    /// List tables/views/materialized views up to `max_objects`.
    #[cfg(feature = "postgres")]
    async fn list_objects(
        client: &tokio_postgres::Client,
        max_objects: i32,
    ) -> EngineResult<Vec<SchemaObject>> {
        use crate::discovery::postgres::LIST_OBJECTS;

        let rows = client.query(LIST_OBJECTS, &[]).await.map_err(|e| {
            EngineError::internal(format!("list objects: {e}"))
        })?;

        let mut objects = Vec::new();
        for row in rows.into_iter().take(max_objects.max(1) as usize) {
            let schema_name: String = row.try_get("schema_name").unwrap_or_default();
            let object_name: String = row.try_get("object_name").unwrap_or_default();
            let object_type: String = row.try_get("object_type").unwrap_or_default();
            let estimated_rows: Option<i64> = row.try_get("estimated_rows").ok().flatten();

            let object_id = format!("{}.{}", schema_name, object_name);

            let columns = Self::list_columns(client, &schema_name, &object_name).await?;
            let primary_keys = Self::list_primary_keys(client, &schema_name, &object_name).await?;
            let foreign_keys = Self::list_foreign_keys(client, &schema_name, &object_name).await?;

            let fk_cols: HashSet<String> = foreign_keys.iter().flat_map(|fk| fk.from_columns.clone()).collect();

            let mut out_cols = Vec::new();
            for col in columns {
                out_cols.push(SchemaColumn {
                    column_name: col.column_name,
                    ordinal: col.ordinal,
                    data_type: col.data_type,
                    nullable: col.nullable,
                    is_primary_key: primary_keys.contains(&col.column_name),
                    is_foreign_key: fk_cols.contains(&col.column_name),
                    default_expr: col.default_expr,
                });
            }

            objects.push(SchemaObject {
                object_id,
                schema_name,
                object_name,
                object_type,
                estimated_rows,
                columns: out_cols,
            });
        }

        Ok(objects)
    }

    #[cfg(feature = "postgres")]
    async fn list_columns(
        client: &tokio_postgres::Client,
        schema: &str,
        object: &str,
    ) -> EngineResult<Vec<crate::discovery::postgres::DiscoveredColumn>> {
        use crate::discovery::postgres::LIST_COLUMNS;
        let rows = client.query(LIST_COLUMNS, &[&schema, &object]).await.map_err(|e| {
            EngineError::internal(format!("list columns: {e}"))
        })?;
        Ok(rows
            .into_iter()
            .map(|r| crate::discovery::postgres::DiscoveredColumn {
                column_name: r.try_get("column_name").unwrap_or_default(),
                ordinal: r.try_get("ordinal").unwrap_or(0),
                data_type: r.try_get("data_type").unwrap_or_default(),
                nullable: r.try_get("nullable").unwrap_or(true),
                default_expr: r.try_get("default_expr").ok().flatten(),
            })
            .collect())
    }

    #[cfg(feature = "postgres")]
    async fn list_primary_keys(
        client: &tokio_postgres::Client,
        schema: &str,
        object: &str,
    ) -> EngineResult<HashSet<String>> {
        use crate::discovery::postgres::LIST_PRIMARY_KEYS;
        let rows = client.query(LIST_PRIMARY_KEYS, &[&schema, &object]).await.map_err(|e| {
            EngineError::internal(format!("list primary keys: {e}"))
        })?;
        Ok(rows
            .into_iter()
            .filter_map(|r| r.try_get("column_name").ok())
            .collect())
    }

    #[cfg(feature = "postgres")]
    async fn list_foreign_keys(
        client: &tokio_postgres::Client,
        schema: &str,
        object: &str,
    ) -> EngineResult<Vec<crate::discovery::postgres::DiscoveredForeignKey>> {
        use crate::discovery::postgres::LIST_FOREIGN_KEYS;
        let rows = client.query(LIST_FOREIGN_KEYS, &[&schema, &object]).await.map_err(|e| {
            EngineError::internal(format!("list foreign keys: {e}"))
        })?;
        Ok(rows
            .into_iter()
            .map(|r| crate::discovery::postgres::DiscoveredForeignKey {
                from_column: r.try_get("from_column").unwrap_or_default(),
                to_table: r.try_get("to_table").unwrap_or_default(),
                to_column: r.try_get("to_column").unwrap_or_default(),
            })
            .collect())
    }

    /// Infer relationships from FK constraints and naming heuristics.
    #[cfg(feature = "postgres")]
    async fn infer_relationships(
        client: &tokio_postgres::Client,
        objects: &[SchemaObject],
    ) -> EngineResult<Vec<RelationshipCandidate>> {
        use crate::discovery::postgres::LIST_ALL_FOREIGN_KEYS;

        let mut rels = Vec::new();
        let rows = client.query(LIST_ALL_FOREIGN_KEYS, &[]).await.map_err(|e| {
            EngineError::internal(format!("infer relationships: {e}"))
        })?;

        let mut seen = HashSet::new();
        for row in rows {
            let from_object: String = row.try_get("from_object").unwrap_or_default();
            let from_column: String = row.try_get("from_column").unwrap_or_default();
            let to_object: String = row.try_get("to_object").unwrap_or_default();
            let to_column: String = row.try_get("to_column").unwrap_or_default();

            let key = format!("{}:{}->{}:{}", from_object, from_column, to_object, to_column);
            if !seen.insert(key.clone()) {
                continue;
            }

            let id = uuid::Uuid::new_v4().to_string();
            rels.push(RelationshipCandidate {
                id,
                from_object_id: from_object.clone(),
                from_columns: vec![from_column],
                to_object_id: to_object.clone(),
                to_columns: vec![to_column],
                kind: "fk".to_string(),
                confidence: 1.0,
                provenance: "constraint".to_string(),
                reviewed: false,
                accepted: None,
            });
        }

        // Name-inferred heuristics: col "org_id" -> table "organizations"(id)
        let object_by_name: HashMap<String, &SchemaObject> = objects
            .iter()
            .map(|o| (o.object_name.clone(), o))
            .collect();
        for obj in objects {
            for col in &obj.columns {
                if col.is_foreign_key {
                    continue;
                }
                // Strip trailing "_id" / "id" and look for a matching table.
                let candidate = col.column_name.trim_end_matches("_id");
                if candidate.is_empty() || candidate == col.column_name {
                    continue;
                }
                if let Some(target) = object_by_name.get(candidate) {
                    // Only if target has a primary key named "id".
                    let target_has_id = target.columns.iter().any(|c| {
                        c.column_name == "id" && c.is_primary_key
                    });
                    if target_has_id {
                        let key = format!("{}:{}->{}:id", obj.object_id, col.column_name, target.object_id);
                        if seen.insert(key.clone()) {
                            rels.push(RelationshipCandidate {
                                id: uuid::Uuid::new_v4().to_string(),
                                from_object_id: obj.object_id.clone(),
                                from_columns: vec![col.column_name.clone()],
                                to_object_id: target.object_id.clone(),
                                to_columns: vec!["id".to_string()],
                                kind: "name_inferred".to_string(),
                                confidence: 0.6,
                                provenance: "heuristic".to_string(),
                                reviewed: false,
                                accepted: None,
                            });
                        }
                    }
                }
            }
        }

        Ok(rels)
    }

    /// Compute a stable fingerprint from canonical DDL.
    pub fn fingerprint(objects: &[SchemaObject]) -> String {
        use std::hash::{Hash, Hasher};

        let mut canonical = String::new();
        for obj in objects {
            canonical.push_str(&format!("{}.{}:{}|", obj.schema_name, obj.object_name, obj.object_type));
            for col in &obj.columns {
                canonical.push_str(&format!("{}:{}:{}:{}|", col.column_name, col.data_type, col.nullable, col.ordinal));
            }
        }
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        canonical.hash(&mut hasher);
        format!("{:x}", hasher.finish())
    }

    /// Classify drift between two snapshots.
    pub fn classify_drift(old: &SchemaSnapshot, new: &SchemaSnapshot) -> DriftClass {
        let old_keys: HashSet<String> = old
            .tables
            .iter()
            .map(|t| format!("{}.{}", t.schema_name, t.object_name))
            .collect();
        let new_keys: HashSet<String> = new
            .tables
            .iter()
            .map(|t| format!("{}.{}", t.schema_name, t.object_name))
            .collect();

        let removed: Vec<_> = old_keys.difference(&new_keys).collect();
        if !removed.is_empty() {
            return DriftClass::Breaking;
        }

        let added: Vec<_> = new_keys.difference(&old_keys).collect();
        if !added.is_empty() {
            return DriftClass::Additive;
        }

        // Column-level changes within same objects.
        for new_obj in &new.tables {
            let old_obj = old.tables.iter().find(|o| o.object_id == new_obj.object_id);
            if let Some(old_obj) = old_obj {
                let old_cols: HashSet<&str> = old_obj.columns.iter().map(|c| c.column_name.as_str()).collect();
                let new_cols: HashSet<&str> = new_obj.columns.iter().map(|c| c.column_name.as_str()).collect();
                let removed_cols: Vec<_> = old_cols.difference(&new_cols).collect();
                if !removed_cols.is_empty() {
                    return DriftClass::Breaking;
                }
                let added_cols: Vec<_> = new_cols.difference(&old_cols).collect();
                if !added_cols.is_empty() {
                    return DriftClass::Additive;
                }
            }
        }

        DriftClass::Unchanged
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum DriftClass {
    Unchanged,
    Additive,
    Breaking,
}

pub mod postgres;
