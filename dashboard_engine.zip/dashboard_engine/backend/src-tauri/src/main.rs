//! Main Tauri application entry point.
//! Built only for desktop (Linux/Windows/macOS) — not on Termux.
//!
//! Run with:
//!   cargo run --features tauri --bin dde-core
//!
//! The core library and CLI build without Tauri:
//!   cargo test
//!   cargo run --bin dde-cli -- ping

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use dde_core::commands::{
    dashboard_create, dashboard_delete, dashboard_get, dashboard_list, dashboard_save,
    dashboard_save_uiir, dashboard_validate_uiir, datasource_create, datasource_delete,
    datasource_get, datasource_list, datasource_test, diagnostics_get, discovery_inspect,
    discovery_profile_jsonb, discovery_snapshot, ping, query_cancel, query_execute,
    uiir_apply_draft, uiir_generate, uiir_migrate, workspace_get_layout, workspace_save_layout,
    AppState,
};
use dde_core::engine::{Engine, EngineConfig};
use std::sync::{Arc, Mutex};

fn main() {
    let config = EngineConfig::default();
    let engine = Engine::new(config).expect("failed to initialize the engine store");

    let state = AppState {
        engine: Arc::new(Mutex::new(engine)),
    };

    tauri::Builder::default()
        .plugin(tauri_plugin_log::Builder::default().build())
        .manage(state)
        .invoke_handler(tauri::generate_handler![
            ping,
            dashboard_create,
            dashboard_list,
            dashboard_get,
            dashboard_save,
            dashboard_save_uiir,
            dashboard_validate_uiir,
            dashboard_delete,
            datasource_list,
            datasource_create,
            datasource_get,
            datasource_test,
            datasource_delete,
            discovery_inspect,
            discovery_snapshot,
            discovery_profile_jsonb,
            query_execute,
            query_cancel,
            uiir_generate,
            uiir_apply_draft,
            uiir_migrate,
            workspace_save_layout,
            workspace_get_layout,
            diagnostics_get,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
