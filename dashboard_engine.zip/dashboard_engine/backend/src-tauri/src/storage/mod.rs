//! SQLite local storage for dashboard configuration, revisions, data sources,
//! schema snapshots, and workspace layout.
//! Business data never lives here.

use crate::{EngineError, EngineResult};
use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use std::path::Path;
use uuid::Uuid;

/// A dashboard record (config, not business data).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Dashboard {
    pub id: String,
    pub name: String,
    pub description: String,
    pub icon_json: Option<String>,
    pub status: String, // draft | active | archived
    pub current_rev: i64,
    pub ir_version: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

/// One immutable saved revision of a dashboard's UI-IR document.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DashboardRevision {
    pub dashboard_id: String,
    pub revision: i64,
    pub ir_json: String,
    pub compiled_json: Option<String>,
    pub ir_version: String,
    pub source: String, // user | generator | migration | import
    pub note: Option<String>,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataSource {
    pub id: String,
    pub name: String,
    pub kind: String, // postgres | timescale
    pub host: String,
    pub port: i32,
    pub database_name: String,
    pub username: String,
    pub secret_ref: String, // pointer only, never the secret
    pub ssl_mode: String,
    pub created_at: String,
    pub updated_at: String,
}

/// SQLite-backed store.
pub struct Store {
    conn: Connection,
}

impl Store {
    /// Borrow the underlying connection (used by query execution).
    pub fn conn(&self) -> &Connection {
        &self.conn
    }

    pub fn open<P: AsRef<Path>>(path: P) -> EngineResult<Self> {
        let conn = Connection::open(path)?;
        conn.pragma_update(None, "journal_mode", "WAL")?;
        conn.pragma_update(None, "foreign_keys", "ON")?;
        Self::migrate(&conn)?;
        Ok(Self { conn })
    }

    fn migrate(conn: &Connection) -> EngineResult<()> {
        conn.execute_batch(
            "
            CREATE TABLE IF NOT EXISTS dashboards (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                icon_json TEXT,
                status TEXT NOT NULL DEFAULT 'draft',
                current_rev INTEGER NOT NULL DEFAULT 0,
                ir_version TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS dashboard_revisions (
                dashboard_id TEXT NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
                revision INTEGER NOT NULL,
                ir_json TEXT NOT NULL,
                compiled_json TEXT,
                ir_version TEXT NOT NULL,
                source TEXT NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL,
                PRIMARY KEY (dashboard_id, revision)
            );
            CREATE TABLE IF NOT EXISTS data_sources (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                kind TEXT NOT NULL,
                host TEXT NOT NULL,
                port INTEGER NOT NULL,
                database_name TEXT NOT NULL,
                username TEXT NOT NULL,
                secret_ref TEXT NOT NULL,
                ssl_mode TEXT NOT NULL DEFAULT 'require',
                options_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS dashboard_data_sources (
                dashboard_id TEXT NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
                data_source_id TEXT NOT NULL REFERENCES data_sources(id),
                permission_scope TEXT NOT NULL DEFAULT 'read',
                allowed_schemas TEXT NOT NULL DEFAULT '[\"public\"]',
                max_rows INTEGER NOT NULL DEFAULT 1000,
                timeout_ms INTEGER NOT NULL DEFAULT 15000,
                PRIMARY KEY (dashboard_id, data_source_id)
            );
            CREATE TABLE IF NOT EXISTS schema_snapshots (
                id TEXT PRIMARY KEY,
                data_source_id TEXT NOT NULL REFERENCES data_sources(id) ON DELETE CASCADE,
                fingerprint TEXT NOT NULL,
                engine_version TEXT NOT NULL,
                status TEXT NOT NULL,
                summary_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS schema_objects (
                snapshot_id TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
                object_id TEXT NOT NULL,
                schema_name TEXT NOT NULL,
                object_name TEXT NOT NULL,
                object_type TEXT NOT NULL,
                estimated_rows INTEGER,
                PRIMARY KEY (snapshot_id, object_id)
            );
            CREATE TABLE IF NOT EXISTS schema_columns (
                snapshot_id TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
                object_id TEXT NOT NULL,
                column_name TEXT NOT NULL,
                ordinal INTEGER NOT NULL,
                data_type TEXT NOT NULL,
                nullable INTEGER NOT NULL,
                is_primary_key INTEGER NOT NULL DEFAULT 0,
                is_foreign_key INTEGER NOT NULL DEFAULT 0,
                default_expr TEXT,
                PRIMARY KEY (snapshot_id, object_id, column_name)
            );
            CREATE TABLE IF NOT EXISTS relationships (
                snapshot_id TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
                id TEXT NOT NULL,
                from_object_id TEXT NOT NULL,
                from_columns_json TEXT NOT NULL,
                to_object_id TEXT NOT NULL,
                to_columns_json TEXT NOT NULL,
                kind TEXT NOT NULL,
                confidence REAL NOT NULL,
                provenance TEXT NOT NULL,
                reviewed INTEGER NOT NULL DEFAULT 0,
                accepted INTEGER,
                PRIMARY KEY (snapshot_id, id)
            );
            CREATE TABLE IF NOT EXISTS jsonb_profiles (
                snapshot_id TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
                object_id TEXT NOT NULL,
                column_name TEXT NOT NULL,
                path TEXT NOT NULL,
                value_type TEXT NOT NULL,
                null_fraction REAL,
                distinct_cap INTEGER,
                sample_json TEXT,
                PRIMARY KEY (snapshot_id, object_id, column_name, path)
            );
            CREATE TABLE IF NOT EXISTS workspace_layouts (
                id TEXT PRIMARY KEY DEFAULT 'default',
                layout_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS query_cache (
                cache_key TEXT PRIMARY KEY,
                scope TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                bytes INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT
            );
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                at TEXT NOT NULL,
                actor TEXT,
                action TEXT NOT NULL,
                subject TEXT,
                outcome TEXT NOT NULL,
                detail_json TEXT
            );
            ",
        )?;
        Ok(())
    }

    pub fn create_dashboard(&self, name: String, description: String) -> EngineResult<Dashboard> {
        let id = Uuid::new_v4().to_string();
        let now = chrono::Utc::now().to_rfc3339();
        self.conn.execute(
            "INSERT INTO dashboards (id, name, description, status, current_rev, created_at, updated_at)
             VALUES (?1, ?2, ?3, 'draft', 0, ?4, ?4)",
            params![id, name, description, now],
        )?;
        Ok(Dashboard {
            id,
            name,
            description,
            icon_json: None,
            status: "draft".to_string(),
            current_rev: 0,
            ir_version: None,
            created_at: now.clone(),
            updated_at: now,
        })
    }

    pub fn list_dashboards(&self) -> EngineResult<Vec<Dashboard>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, name, description, icon_json, status, current_rev, ir_version, created_at, updated_at
             FROM dashboards ORDER BY updated_at DESC",
        )?;
        let rows = stmt.query_map([], |r| {
            Ok(Dashboard {
                id: r.get(0)?,
                name: r.get(1)?,
                description: r.get(2)?,
                icon_json: r.get(3)?,
                status: r.get(4)?,
                current_rev: r.get(5)?,
                ir_version: r.get(6)?,
                created_at: r.get(7)?,
                updated_at: r.get(8)?,
            })
        })?;
        let mut out = Vec::new();
        for row in rows {
            out.push(row?);
        }
        Ok(out)
    }

    pub fn get_dashboard(&self, id: &str) -> EngineResult<Option<Dashboard>> {
        let row: Option<Dashboard> = self.conn.query_row(
            "SELECT id, name, description, icon_json, status, current_rev, ir_version, created_at, updated_at
             FROM dashboards WHERE id = ?1",
            params![id],
            |r| Ok(Dashboard {
                id: r.get(0)?,
                name: r.get(1)?,
                description: r.get(2)?,
                icon_json: r.get(3)?,
                status: r.get(4)?,
                current_rev: r.get(5)?,
                ir_version: r.get(6)?,
                created_at: r.get(7)?,
                updated_at: r.get(8)?,
            }),
        ).optional()?;
        Ok(row)
    }

    pub fn update_dashboard(&self, id: &str, name: Option<String>, desc: Option<String>) -> EngineResult<()> {
        let now = chrono::Utc::now().to_rfc3339();
        let changed = self.conn.execute(
            "UPDATE dashboards
             SET name = COALESCE(?2, name),
                 description = COALESCE(?3, description),
                 updated_at = ?4
             WHERE id = ?1",
            params![id, name, desc, now],
        )?;
        if changed == 0 {
            return Err(EngineError::internal(format!("dashboard {id} not found")));
        }
        Ok(())
    }

    /// Set the dashboard icon. The value is stored as JSON so the UI can later
    /// support image icons alongside emoji.
    pub fn update_dashboard_icon(&self, id: &str, icon_json: &str) -> EngineResult<()> {
        let now = chrono::Utc::now().to_rfc3339();
        let changed = self.conn.execute(
            "UPDATE dashboards SET icon_json = ?2, updated_at = ?3 WHERE id = ?1",
            params![id, icon_json, now],
        )?;
        if changed == 0 {
            return Err(EngineError::internal(format!("dashboard {id} not found")));
        }
        Ok(())
    }

    /// Persist a new immutable revision and advance the dashboard's pointer.
    ///
    /// When `base_revision` is supplied, the write is rejected if another
    /// writer advanced the dashboard in the meantime (optimistic concurrency).
    pub fn save_revision(
        &self,
        dashboard_id: &str,
        ir_json: String,
        compiled_json: Option<String>,
        ir_version: String,
        source: String,
        note: Option<String>,
        base_revision: Option<i64>,
    ) -> EngineResult<DashboardRevision> {
        let dash = self
            .get_dashboard(dashboard_id)?
            .ok_or_else(|| EngineError::internal(format!("dashboard {dashboard_id} not found")))?;

        if let Some(base) = base_revision {
            if base != dash.current_rev {
                return Err(EngineError::config_conflict(format!(
                    "revision conflict: current revision is {}, got base {}",
                    dash.current_rev, base
                )));
            }
        }

        let revision = dash.current_rev + 1;
        let now = chrono::Utc::now().to_rfc3339();

        let tx = self.conn.unchecked_transaction()?;
        tx.execute(
            "INSERT INTO dashboard_revisions
                (dashboard_id, revision, ir_json, compiled_json, ir_version, source, note, created_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
            params![
                dashboard_id,
                revision,
                ir_json,
                compiled_json,
                ir_version,
                source,
                note,
                now
            ],
        )?;
        tx.execute(
            "UPDATE dashboards
             SET current_rev = ?2, ir_version = ?3, updated_at = ?4
             WHERE id = ?1",
            params![dashboard_id, revision, ir_version, now],
        )?;
        tx.commit()?;

        Ok(DashboardRevision {
            dashboard_id: dashboard_id.to_string(),
            revision,
            ir_json,
            compiled_json,
            ir_version,
            source,
            note,
            created_at: now,
        })
    }

    /// Latest saved revision for a dashboard, if any.
    pub fn get_current_revision(&self, dashboard_id: &str) -> EngineResult<Option<DashboardRevision>> {
        let row = self
            .conn
            .query_row(
                "SELECT dashboard_id, revision, ir_json, compiled_json, ir_version, source, note, created_at
                 FROM dashboard_revisions
                 WHERE dashboard_id = ?1
                 ORDER BY revision DESC
                 LIMIT 1",
                params![dashboard_id],
                |r| {
                    Ok(DashboardRevision {
                        dashboard_id: r.get(0)?,
                        revision: r.get(1)?,
                        ir_json: r.get(2)?,
                        compiled_json: r.get(3)?,
                        ir_version: r.get(4)?,
                        source: r.get(5)?,
                        note: r.get(6)?,
                        created_at: r.get(7)?,
                    })
                },
            )
            .optional()?;
        Ok(row)
    }

    /// Persist the workspace panel layout (single row, id = "default").
    pub fn save_workspace_layout(&self, layout: &serde_json::Value) -> EngineResult<()> {
        let layout_json = serde_json::to_string(layout)?;
        let now = chrono::Utc::now().to_rfc3339();
        self.conn.execute(
            "INSERT INTO workspace_layouts (id, layout_json, updated_at)
             VALUES ('default', ?1, ?2)
             ON CONFLICT(id) DO UPDATE SET
                layout_json = excluded.layout_json,
                updated_at = excluded.updated_at",
            params![layout_json, now],
        )?;
        Ok(())
    }

    /// Load the saved workspace layout, if any.
    pub fn get_workspace_layout(&self) -> EngineResult<Option<serde_json::Value>> {
        let stored: Option<String> = self
            .conn
            .query_row(
                "SELECT layout_json FROM workspace_layouts WHERE id = 'default'",
                [],
                |r| r.get(0),
            )
            .optional()?;
        match stored {
            Some(json) => Ok(Some(serde_json::from_str(&json)?)),
            None => Ok(None),
        }
    }

    pub fn delete_dashboard(&self, id: &str) -> EngineResult<()> {
        self.conn.execute("DELETE FROM dashboards WHERE id = ?1", params![id])?;
        Ok(())
    }

    /// Lightweight counters for the diagnostics view.
    pub fn diagnostics_counts(&self) -> EngineResult<serde_json::Value> {
        fn count(conn: &Connection, table: &str) -> i64 {
            conn.query_row(&format!("SELECT COUNT(*) FROM {table}"), [], |r| r.get(0))
                .unwrap_or(0)
        }
        Ok(serde_json::json!({
            "dashboards": count(&self.conn, "dashboards"),
            "revisions": count(&self.conn, "dashboard_revisions"),
            "dataSources": count(&self.conn, "data_sources"),
            "snapshots": count(&self.conn, "schema_snapshots"),
            "queryCacheEntries": count(&self.conn, "query_cache"),
        }))
    }

    // -----------------------------------------------------------------
    // Data sources (config only — secrets stay in the OS keychain/env)
    // -----------------------------------------------------------------

    pub fn create_data_source(
        &self,
        name: String,
        kind: String,
        host: String,
        port: i32,
        database_name: String,
        username: String,
        secret_ref: String,
        ssl_mode: String,
    ) -> EngineResult<DataSource> {
        let id = Uuid::new_v4().to_string();
        let now = chrono::Utc::now().to_rfc3339();
        self.conn.execute(
            "INSERT INTO data_sources
                (id, name, kind, host, port, database_name, username, secret_ref, ssl_mode, options_json, created_at, updated_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, '{}', ?10, ?10)",
            params![
                id,
                name,
                kind,
                host,
                port,
                database_name,
                username,
                secret_ref,
                ssl_mode,
                now
            ],
        )?;
        Ok(DataSource {
            id,
            name,
            kind,
            host,
            port,
            database_name,
            username,
            secret_ref,
            ssl_mode,
            created_at: now.clone(),
            updated_at: now,
        })
    }

    pub fn list_data_sources(&self) -> EngineResult<Vec<DataSource>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, name, kind, host, port, database_name, username, secret_ref, ssl_mode, created_at, updated_at
             FROM data_sources ORDER BY name ASC",
        )?;
        let rows = stmt.query_map([], |r| {
            Ok(DataSource {
                id: r.get(0)?,
                name: r.get(1)?,
                kind: r.get(2)?,
                host: r.get(3)?,
                port: r.get(4)?,
                database_name: r.get(5)?,
                username: r.get(6)?,
                secret_ref: r.get(7)?,
                ssl_mode: r.get(8)?,
                created_at: r.get(9)?,
                updated_at: r.get(10)?,
            })
        })?;
        let mut out = Vec::new();
        for row in rows {
            out.push(row?);
        }
        Ok(out)
    }

    pub fn get_data_source(&self, id: &str) -> EngineResult<Option<DataSource>> {
        let row = self
            .conn
            .query_row(
                "SELECT id, name, kind, host, port, database_name, username, secret_ref, ssl_mode, created_at, updated_at
                 FROM data_sources WHERE id = ?1",
                params![id],
                |r| {
                    Ok(DataSource {
                        id: r.get(0)?,
                        name: r.get(1)?,
                        kind: r.get(2)?,
                        host: r.get(3)?,
                        port: r.get(4)?,
                        database_name: r.get(5)?,
                        username: r.get(6)?,
                        secret_ref: r.get(7)?,
                        ssl_mode: r.get(8)?,
                        created_at: r.get(9)?,
                        updated_at: r.get(10)?,
                    })
                },
            )
            .optional()?;
        Ok(row)
    }

    pub fn delete_data_source(&self, id: &str) -> EngineResult<()> {
        // Clear dashboard links first: the join table references data_sources
        // without ON DELETE CASCADE, so an orphaned link would block the delete.
        let tx = self.conn.unchecked_transaction()?;
        tx.execute(
            "DELETE FROM dashboard_data_sources WHERE data_source_id = ?1",
            params![id],
        )?;
        tx.execute("DELETE FROM data_sources WHERE id = ?1", params![id])?;
        tx.commit()?;
        Ok(())
    }

    // -----------------------------------------------------------------
    // Schema snapshots + discovered objects / relationships
    // -----------------------------------------------------------------

    pub fn save_schema_snapshot(
        &self,
        data_source_id: &str,
        fingerprint: &str,
        engine_version: &str,
        status: &str,
        summary_json: &str,
    ) -> EngineResult<String> {
        let id = Uuid::new_v4().to_string();
        let now = chrono::Utc::now().to_rfc3339();
        self.conn.execute(
            "INSERT INTO schema_snapshots
                (id, data_source_id, fingerprint, engine_version, status, summary_json, created_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
            params![id, data_source_id, fingerprint, engine_version, status, summary_json, now],
        )?;
        Ok(id)
    }

    pub fn get_schema_snapshot(&self, id: &str) -> EngineResult<Option<String>> {
        let stored: Option<String> = self
            .conn
            .query_row(
                "SELECT summary_json FROM schema_snapshots WHERE id = ?1",
                params![id],
                |r| r.get(0),
            )
            .optional()?;
        Ok(stored)
    }

    pub fn get_latest_snapshot_for_source(
        &self,
        data_source_id: &str,
    ) -> EngineResult<Option<String>> {
        let stored: Option<String> = self
            .conn
            .query_row(
                "SELECT summary_json FROM schema_snapshots
                 WHERE data_source_id = ?1
                 ORDER BY created_at DESC
                 LIMIT 1",
                params![data_source_id],
                |r| r.get(0),
            )
            .optional()?;
        Ok(stored)
    }

    pub fn save_schema_objects(
        &self,
        snapshot_id: &str,
        objects: &[crate::discovery::SchemaObject],
    ) -> EngineResult<()> {
        let tx = self.conn.unchecked_transaction()?;
        for obj in objects {
            tx.execute(
                "INSERT OR IGNORE INTO schema_objects
                    (snapshot_id, object_id, schema_name, object_name, object_type, estimated_rows)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
                params![
                    snapshot_id,
                    obj.object_id,
                    obj.schema_name,
                    obj.object_name,
                    obj.object_type,
                    obj.estimated_rows
                ],
            )?;
            self.save_schema_columns(&tx, snapshot_id, &obj.object_id, &obj.columns)?;
        }
        tx.commit()?;
        Ok(())
    }

    fn save_schema_columns(
        &self,
        tx: &rusqlite::Transaction,
        snapshot_id: &str,
        object_id: &str,
        columns: &[crate::discovery::SchemaColumn],
    ) -> EngineResult<()> {
        for col in columns {
            tx.execute(
                "INSERT OR IGNORE INTO schema_columns
                    (snapshot_id, object_id, column_name, ordinal, data_type, nullable,
                     is_primary_key, is_foreign_key, default_expr)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
                params![
                    snapshot_id,
                    object_id,
                    col.column_name,
                    col.ordinal,
                    col.data_type,
                    if col.nullable { 1 } else { 0 },
                    if col.is_primary_key { 1 } else { 0 },
                    if col.is_foreign_key { 1 } else { 0 },
                    col.default_expr
                ],
            )?;
        }
        Ok(())
    }

    pub fn save_relationships(
        &self,
        snapshot_id: &str,
        relationships: &[crate::discovery::RelationshipCandidate],
    ) -> EngineResult<()> {
        let tx = self.conn.unchecked_transaction()?;
        for rel in relationships {
            tx.execute(
                "INSERT OR IGNORE INTO relationships
                    (snapshot_id, id, from_object_id, from_columns_json, to_object_id,
                     to_columns_json, kind, confidence, provenance)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
                params![
                    snapshot_id,
                    rel.id,
                    rel.from_object_id,
                    serde_json::to_string(&rel.from_columns)?,
                    rel.to_object_id,
                    serde_json::to_string(&rel.to_columns)?,
                    rel.kind,
                    rel.confidence,
                    rel.provenance
                ],
            )?;
        }
        tx.commit()?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_store() -> (tempfile::TempDir, Store) {
        let dir = tempfile::tempdir().expect("temp dir");
        let store = Store::open(dir.path().join("test.sqlite")).expect("open store");
        (dir, store)
    }

    #[test]
    fn revisions_advance_and_reject_stale_base() {
        let (_dir, store) = temp_store();
        let dash = store
            .create_dashboard("Test".to_string(), "desc".to_string())
            .expect("create dashboard");

        let first = store
            .save_revision(
                &dash.id,
                "{\"v\":1}".to_string(),
                None,
                "1.0.0".to_string(),
                "user".to_string(),
                None,
                Some(0),
            )
            .expect("save revision 1");
        assert_eq!(first.revision, 1);

        let current = store
            .get_current_revision(&dash.id)
            .expect("read revision")
            .expect("revision exists");
        assert_eq!(current.revision, 1);
        assert_eq!(current.ir_json, "{\"v\":1}");

        let stale = store.save_revision(
            &dash.id,
            "{}".to_string(),
            None,
            "1.0.0".to_string(),
            "user".to_string(),
            None,
            Some(0),
        );
        assert!(stale.is_err(), "stale baseRevision must be rejected");

        let updated = store
            .get_dashboard(&dash.id)
            .expect("read dashboard")
            .expect("dashboard exists");
        assert_eq!(updated.current_rev, 1);
        assert_eq!(updated.ir_version.as_deref(), Some("1.0.0"));
    }

    #[test]
    fn workspace_layout_roundtrip() {
        let (_dir, store) = temp_store();
        assert!(store.get_workspace_layout().expect("read empty").is_none());

        let layout = serde_json::json!({
            "id": "default",
            "panels": [],
            "orientation": "horizontal",
            "activeId": null,
            "updated_at": "2026-01-01T00:00:00Z"
        });

        store.save_workspace_layout(&layout).expect("save layout");
        let loaded = store
            .get_workspace_layout()
            .expect("read layout")
            .expect("layout exists");
        assert_eq!(loaded, layout);
    }

    #[test]
    fn delete_cascades_revisions() {
        let (_dir, store) = temp_store();
        let dash = store
            .create_dashboard("Temp".to_string(), String::new())
            .expect("create dashboard");
        store
            .save_revision(
                &dash.id,
                "{}".to_string(),
                None,
                "1.0.0".to_string(),
                "user".to_string(),
                None,
                Some(0),
            )
            .expect("save revision");

        store.delete_dashboard(&dash.id).expect("delete dashboard");
        assert!(store
            .get_current_revision(&dash.id)
            .expect("read revision")
            .is_none());
    }

    #[test]
    fn data_source_crud() {
        let (_dir, store) = temp_store();
        let source = store
            .create_data_source(
                "Production".to_string(),
                "postgres".to_string(),
                "db.example.com".to_string(),
                5432,
                "analytics".to_string(),
                "readonly".to_string(),
                "keyring:prod_pg".to_string(),
                "require".to_string(),
            )
            .expect("create data source");

        let items = store.list_data_sources().expect("list data sources");
        assert_eq!(items.len(), 1);
        assert_eq!(items[0].id, source.id);

        let loaded = store
            .get_data_source(&source.id)
            .expect("get data source")
            .expect("data source exists");
        assert_eq!(loaded.host, "db.example.com");
        assert_eq!(loaded.port, 5432);

        store
            .delete_data_source(&source.id)
            .expect("delete data source");
        assert!(store
            .get_data_source(&source.id)
            .expect("get deleted data source")
            .is_none());
    }

    #[test]
    fn schema_snapshot_roundtrip() {
        use crate::discovery::{SchemaColumn, SchemaObject};

        let (_dir, store) = temp_store();
        let snap_id = store
            .save_schema_snapshot(
                "ds_1",
                "abc123",
                "1.0.0",
                "complete",
                "{\"tables\":[]}",
            )
            .expect("save snapshot");

        let summary = store
            .get_schema_snapshot(&snap_id)
            .expect("get snapshot")
            .expect("snapshot exists");
        assert_eq!(summary, "{\"tables\":[]}");

        let latest = store
            .get_latest_snapshot_for_source("ds_1")
            .expect("latest snapshot")
            .expect("latest exists");
        assert_eq!(latest, "{\"tables\":[]}");

        let objects = vec![SchemaObject {
            object_id: "public.users".to_string(),
            schema_name: "public".to_string(),
            object_name: "users".to_string(),
            object_type: "table".to_string(),
            estimated_rows: Some(100),
            columns: vec![SchemaColumn {
                column_name: "id".to_string(),
                ordinal: 1,
                data_type: "integer".to_string(),
                nullable: false,
                is_primary_key: true,
                is_foreign_key: false,
                default_expr: None,
            }],
        }];

        store
            .save_schema_objects(&snap_id, &objects)
            .expect("save objects");

        let rels = vec![crate::discovery::RelationshipCandidate {
            id: "rel_1".to_string(),
            from_object_id: "public.orders".to_string(),
            from_columns: vec!["user_id".to_string()],
            to_object_id: "public.users".to_string(),
            to_columns: vec!["id".to_string()],
            kind: "fk".to_string(),
            confidence: 1.0,
            provenance: "constraint".to_string(),
            reviewed: false,
            accepted: None,
        }];

        store
            .save_relationships(&snap_id, &rels)
            .expect("save relationships");
    }
}
