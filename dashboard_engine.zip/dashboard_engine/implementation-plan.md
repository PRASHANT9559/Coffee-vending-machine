# 📋 Universal UI & Auto-Dashboard Engine — Implementation Plan

## Goal Description

Build the **Universal UI & Auto-Dashboard Engine** — a desktop-first platform for creating, configuring, and operating multiple data-driven dashboards through a reusable engine. The project is divided into **two major parts**: **Backend (Rust)** and **Frontend (Next.js + Tauri)**, with a comprehensive `docs/` folder containing all architectural documents, roadmaps, workflows, and references.

> [!IMPORTANT]
> **Termux Environment**: The user is working on an Android phone inside Termux. Package downloads may fail or behave differently. All documentation and planning will be created first. Actual code scaffolding will be done carefully with Termux-compatible commands.

---

## User Review Required

> [!WARNING]
> **Termux Limitations for Development**
> - Tauri 2 desktop builds **cannot run on Termux** (needs Linux/Windows/macOS desktop)
> - Rust compilation on Termux is possible but **very slow on phone hardware** and may need `pkg install rust` or `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`
> - PostgreSQL client libraries (`libpq`) may need `pkg install postgresql`
> - Node.js works: `pkg install nodejs-lts`
> - SQLite works: `pkg install sqlite`
> - **Recommendation**: Use Termux for documentation, planning, and light code editing. Use a desktop/server for actual compilation and testing.

> [!IMPORTANT]
> **This plan phase creates ONLY documentation files.** No code compilation or package installation will be attempted. All outputs are `.md` files inside the `docs/` folder.

---

## Open Questions

> [!IMPORTANT]
> 1. **Database Priority**: Should we start with PostgreSQL only, or include TimescaleDB support from Phase 1?
> 2. **Auth Strategy**: Local-only (no login) for desktop MVP, or basic auth from the start?
> 3. **Plugin System**: Should the plugin architecture be designed in Phase 1 docs, or deferred to later phases?
> 4. **Remote Service**: Is the optional Rust remote service (for shared/cloud deployments) in scope for initial planning?

---

## Proposed Documentation Structure

The `docs/` folder will be organized as follows:

```
dashboard_engine/
├── Universal-UI-Auto-DashboardEngine.md    # (existing) Master spec
├── README.md                                # [NEW] Project overview & quick start
└── docs/
    ├── README.md                            # [NEW] Docs index / table of contents
    ├── roadmap.md                            # [NEW] Phased development roadmap
    ├── architecture-overview.md             # [NEW] High-level system architecture
    │
    ├── backend/
    │   ├── README.md                        # [NEW] Backend overview & responsibilities
    │   ├── architecture.md                  # [NEW] Rust engine architecture
    │   ├── database-discovery.md            # [NEW] Schema discovery & profiling
    │   ├── query-engine.md                  # [NEW] Query validation & execution
    │   ├── ui-ir-spec.md                    # [NEW] UI Intermediate Representation spec
    │   ├── plugin-system.md                 # [NEW] Plugin architecture & interfaces
    │   ├── caching-strategy.md              # [NEW] Caching, fingerprints, invalidation
    │   ├── security.md                      # [NEW] Security model & threat boundaries
    │   ├── api-reference.md                 # [NEW] Tauri IPC command reference
    │   └── data-models.md                   # [NEW] SQLite schemas & data structures
    │
    ├── frontend/
    │   ├── README.md                        # [NEW] Frontend overview & responsibilities
    │   ├── architecture.md                  # [NEW] Next.js app architecture
    │   ├── component-registry.md            # [NEW] UI component system & registry
    │   ├── dashboard-hub.md                 # [NEW] Hub UI — create/browse/manage
    │   ├── workspace-manager.md             # [NEW] Multi-panel workspace system
    │   ├── dashboard-renderer.md            # [NEW] UI-IR rendering pipeline
    │   ├── state-management.md              # [NEW] Per-dashboard state isolation
    │   ├── theming.md                       # [NEW] Theme system & Tailwind config
    │   ├── navigation.md                    # [NEW] Routing, sidebar, navigation tree
    │   └── forms-and-filters.md             # [NEW] Form system, filters, search
    │
    ├── workflows/
    │   ├── dashboard-lifecycle.md           # [NEW] Create → Configure → Generate → Use
    │   ├── schema-change-workflow.md        # [NEW] How schema changes are handled
    │   ├── development-workflow.md          # [NEW] Dev setup, build, test, deploy
    │   └── error-recovery.md               # [NEW] Failure scenarios & recovery paths
    │
    └── references/
        ├── tech-stack.md                    # [NEW] Technology choices & rationale
        ├── glossary.md                      # [NEW] Key terms & definitions
        ├── testing-strategy.md              # [NEW] Test plan & scenarios
        └── termux-dev-guide.md              # [NEW] Termux-specific development notes
```

**Total: 27 new `.md` files + 1 existing spec file = 28 documents**

---

## Proposed Changes

### Part 1: Root-Level Files

---

#### [NEW] `README.md`
Project-level README with:
- Project name, tagline, badges
- What this project does (2-3 paragraphs)
- Tech stack summary table
- Quick-start instructions (with Termux notes)
- Project structure overview
- Links to all docs
- License placeholder

---

#### [NEW] `docs/README.md`
Documentation index:
- Categorized links to every doc file
- Reading order recommendation
- Quick navigation table

---

### Part 2: Backend Documentation (Rust Engine)

The backend is the **brain** of the system. All intelligence, security, and data logic lives here.

---

#### [NEW] `docs/backend/README.md`
Overview of what the Rust backend does:

```
┌──────────────────────────────────────────────────────┐
│                   RUST CORE ENGINE                    │
├──────────────┬───────────────┬───────────────────────┤
│  Schema      │  Query        │  UI-IR                │
│  Discovery   │  Engine       │  Generator            │
│  & Profiler  │  & Validator  │  & Validator          │
├──────────────┼───────────────┼───────────────────────┤
│  Relationship│  Caching &    │  Plugin               │
│  Analyzer    │  Fingerprint  │  Manager              │
├──────────────┼───────────────┼───────────────────────┤
│  SQLite      │  PostgreSQL   │  TimescaleDB          │
│  Local Store │  Connector    │  Connector            │
├──────────────┴───────────────┴───────────────────────┤
│            Tauri IPC Command Layer                    │
└──────────────────────────────────────────────────────┘
```

**Key Responsibilities:**
- Database connection management & pooling
- Schema introspection (tables, views, columns, keys, indexes, JSONB)
- Relationship detection (explicit FK + inferred)
- Analytics pattern recognition & query planning
- Query validation, parameterization, timeouts, pagination
- UI-IR generation & validation
- Dashboard config persistence (SQLite)
- Cache management with schema fingerprints
- Plugin lifecycle management
- Tauri IPC command handling

---

#### [NEW] `docs/backend/architecture.md`
Detailed Rust module architecture:

```mermaid
flowchart TD
    A["Tauri IPC Commands"] --> B["Core Engine Orchestrator"]
    B --> C["Schema Discovery"]
    B --> D["Query Engine"]
    B --> E["UI-IR Generator"]
    B --> F["Dashboard Manager"]
    
    C --> G["PostgreSQL Adapter"]
    C --> H["TimescaleDB Adapter"]
    C --> I["JSONB Profiler"]
    
    D --> J["Query Validator"]
    D --> K["Query Executor"]
    D --> L["Result Transformer"]
    
    E --> M["Page Generator"]
    E --> N["Component Mapper"]
    E --> O["Layout Planner"]
    
    F --> P["SQLite Store"]
    F --> Q["Config Migrator"]
    
    B --> R["Cache Manager"]
    B --> S["Plugin Registry"]
```

Proposed Rust crate structure:
```
src-tauri/
├── Cargo.toml
├── src/
│   ├── main.rs                    # Tauri app entry
│   ├── lib.rs                     # Engine public API
│   ├── commands/                  # Tauri IPC command handlers
│   │   ├── mod.rs
│   │   ├── dashboard.rs           # CRUD dashboard commands
│   │   ├── discovery.rs           # Schema discovery commands
│   │   ├── query.rs               # Query execution commands
│   │   └── workspace.rs           # Workspace layout commands
│   ├── engine/                    # Core engine logic
│   │   ├── mod.rs
│   │   ├── orchestrator.rs        # Main coordination logic
│   │   └── config.rs              # Engine configuration
│   ├── discovery/                 # Schema discovery
│   │   ├── mod.rs
│   │   ├── postgres.rs            # PostgreSQL introspection
│   │   ├── timescale.rs           # TimescaleDB extensions
│   │   ├── jsonb.rs               # JSONB profiling
│   │   ├── relationships.rs       # FK + inferred relationships
│   │   └── types.rs               # Discovery data types
│   ├── query/                     # Query system
│   │   ├── mod.rs
│   │   ├── builder.rs             # Safe query construction
│   │   ├── validator.rs           # Permission & safety checks
│   │   ├── executor.rs            # Query execution & pooling
│   │   └── types.rs               # Query data types
│   ├── uiir/                      # UI Intermediate Representation
│   │   ├── mod.rs
│   │   ├── schema.rs              # UI-IR type definitions
│   │   ├── generator.rs           # Generate UI-IR from metadata
│   │   ├── validator.rs           # Validate UI-IR integrity
│   │   └── migrator.rs            # UI-IR version migration
│   ├── storage/                   # Local persistence
│   │   ├── mod.rs
│   │   ├── sqlite.rs              # SQLite operations
│   │   ├── migrations.rs          # Schema migrations
│   │   └── models.rs              # Data models
│   ├── cache/                     # Caching system
│   │   ├── mod.rs
│   │   ├── manager.rs             # Cache lifecycle
│   │   └── fingerprint.rs         # Schema fingerprinting
│   ├── plugins/                   # Plugin system
│   │   ├── mod.rs
│   │   ├── registry.rs            # Plugin registration
│   │   ├── loader.rs              # Plugin loading
│   │   └── traits.rs              # Plugin interfaces
│   └── security/                  # Security & auth
│       ├── mod.rs
│       ├── permissions.rs         # Permission model
│       └── credentials.rs         # Secret management
```

---

#### [NEW] `docs/backend/database-discovery.md`
Schema discovery deep-dive:
- PostgreSQL `information_schema` + `pg_catalog` queries
- Table/view/column/constraint/index extraction
- JSONB column profiling strategy (bounded sampling)
- Relationship detection algorithm (explicit FK → naming convention → type matching)
- Confidence scoring for inferred relationships
- TimescaleDB hypertable & continuous aggregate detection
- Discovery result caching & fingerprinting

---

#### [NEW] `docs/backend/query-engine.md`
Query system design:
- Query intention model (what the dashboard wants, not raw SQL)
- Validation pipeline (permissions → table access → column access → filters → limits)
- Parameterized query construction
- Connection pooling strategy
- Timeout, cancellation, and pagination
- Aggregation patterns (COUNT, SUM, AVG, MIN, MAX, DISTINCT, GROUP BY)
- Time-series query patterns for TimescaleDB
- Error handling & diagnostic messages

---

#### [NEW] `docs/backend/ui-ir-spec.md`
The UI Intermediate Representation specification:

```json
{
  "version": "1.0.0",
  "dashboard": {
    "id": "uuid",
    "name": "E-Commerce Dashboard",
    "theme": { "mode": "dark", "primary": "#3B82F6" },
    "navigation": {
      "sidebar": [
        { "id": "nav-1", "label": "Overview", "icon": "home", "route": "/overview" },
        { "id": "nav-2", "label": "Products", "icon": "box", "route": "/products" }
      ]
    },
    "pages": [
      {
        "id": "page-1",
        "route": "/overview",
        "title": "Overview",
        "layout": { "type": "grid", "columns": 12, "gap": "md" },
        "components": [
          {
            "id": "comp-1",
            "type": "metric-card",
            "gridArea": { "col": "1/4", "row": "1/2" },
            "props": {
              "title": "Total Orders",
              "binding": { "source": "orders", "aggregate": "count" },
              "format": "number"
            }
          }
        ]
      }
    ]
  }
}
```

- Full type definitions for every UI-IR node
- Versioning strategy & migration rules
- Validation rules & error types
- Component type → prop contract mapping

---

#### [NEW] `docs/backend/plugin-system.md`
Plugin architecture:
- Plugin manifest format
- Lifecycle (discover → load → validate → register → activate)
- Plugin categories & trait interfaces
- Capability declaration & dependency resolution
- Sandboxing & permission model
- Version compatibility ranges

---

#### [NEW] `docs/backend/caching-strategy.md`
- What gets cached (schema metadata, compiled config, query results)
- Cache key design & fingerprinting
- TTL vs fingerprint-based invalidation
- Cache corruption recovery
- Memory budget management

---

#### [NEW] `docs/backend/security.md`
- Threat model & trust boundaries
- Credential storage (OS keychain / encrypted store)
- Per-dashboard permission context
- Query allowlists & restrictions
- IPC command validation
- Plugin sandboxing
- Multi-tenant isolation (future)

---

#### [NEW] `docs/backend/api-reference.md`
Tauri IPC command catalog:
```
# Dashboard Management
dashboard:create      → CreateDashboardRequest → DashboardInfo
dashboard:list        → void → DashboardInfo[]
dashboard:get         → { id } → DashboardDetail
dashboard:update      → UpdateDashboardRequest → DashboardInfo
dashboard:delete      → { id } → void

# Schema Discovery
discovery:connect     → ConnectionConfig → ConnectionStatus
discovery:inspect     → { dashboardId } → SchemaMetadata
discovery:profile     → { dashboardId, table } → TableProfile
discovery:relationships → { dashboardId } → Relationship[]

# Query Execution
query:execute         → QueryRequest → QueryResult
query:aggregate       → AggregateRequest → AggregateResult
query:cancel          → { queryId } → void

# UI-IR
uiir:generate         → { dashboardId, mode } → UiIrDocument
uiir:validate         → UiIrDocument → ValidationResult
uiir:save             → { dashboardId, uiir } → void

# Workspace
workspace:save-layout → WorkspaceLayout → void
workspace:get-layout  → void → WorkspaceLayout
```

---

#### [NEW] `docs/backend/data-models.md`
SQLite schema for local storage:
```sql
-- Dashboard registry
CREATE TABLE dashboards (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    config_version TEXT NOT NULL
);

-- Connection references (no secrets here)
CREATE TABLE connections (
    id TEXT PRIMARY KEY,
    dashboard_id TEXT NOT NULL REFERENCES dashboards(id),
    adapter_type TEXT NOT NULL,
    host TEXT,
    port INTEGER,
    database_name TEXT,
    credential_ref TEXT  -- reference to OS keychain
);

-- Cached schema metadata
CREATE TABLE schema_cache (
    id TEXT PRIMARY KEY,
    connection_id TEXT NOT NULL REFERENCES connections(id),
    fingerprint TEXT NOT NULL,
    metadata BLOB NOT NULL,
    cached_at TEXT NOT NULL
);

-- Dashboard UI-IR
CREATE TABLE dashboard_uiir (
    dashboard_id TEXT PRIMARY KEY REFERENCES dashboards(id),
    version TEXT NOT NULL,
    document BLOB NOT NULL,
    updated_at TEXT NOT NULL
);

-- Workspace layout
CREATE TABLE workspace_layouts (
    id TEXT PRIMARY KEY,
    name TEXT,
    layout BLOB NOT NULL,
    is_active INTEGER DEFAULT 0,
    updated_at TEXT NOT NULL
);
```

---

### Part 3: Frontend Documentation (Next.js + Tailwind + Tauri)

The frontend is the **face** of the system. All UI rendering, user interaction, and visual state lives here.

---

#### [NEW] `docs/frontend/README.md`
Overview of frontend responsibilities:

```
┌─────────────────────────────────────────────────────────┐
│                    NEXT.JS FRONTEND                      │
├────────────────┬──────────────┬─────────────────────────┤
│  Dashboard Hub │  Workspace   │  Dashboard              │
│  (Browse/CRUD) │  Manager     │  Renderer               │
│                │  (Panels)    │  (UI-IR → Components)   │
├────────────────┼──────────────┼─────────────────────────┤
│  Component     │  State       │  Theme                  │
│  Registry      │  Manager     │  Engine                 │
├────────────────┼──────────────┼─────────────────────────┤
│  Navigation    │  Forms &     │  Error                  │
│  System        │  Filters     │  Boundaries             │
├────────────────┴──────────────┴─────────────────────────┤
│              Tauri IPC Bridge Layer                       │
└─────────────────────────────────────────────────────────┘
```

**Key Responsibilities:**
- Dashboard Hub UI (card grid, create wizard, search)
- Multi-panel workspace (split views, resize, maximize)
- UI-IR rendering (JSON → React components)
- Component registry (validated, type-safe components)
- Per-dashboard state isolation (navigation, filters, data)
- Theme system (dark/light, custom palettes, Tailwind)
- Sidebar & navigation tree rendering
- Forms, filters, search, pagination
- Error boundaries per panel
- Loading states & skeleton screens

---

#### [NEW] `docs/frontend/architecture.md`
Next.js app architecture:

```
src/
├── app/                           # Next.js App Router
│   ├── layout.tsx                 # Root layout + providers
│   ├── page.tsx                   # Redirect to hub
│   ├── hub/
│   │   ├── page.tsx               # Dashboard Hub
│   │   └── create/
│   │       └── page.tsx           # Create dashboard wizard
│   └── workspace/
│       └── page.tsx               # Multi-dashboard workspace
│
├── components/
│   ├── hub/                       # Hub-specific components
│   │   ├── DashboardCard.tsx
│   │   ├── DashboardGrid.tsx
│   │   ├── CreateWizard.tsx
│   │   └── HubSearch.tsx
│   ├── workspace/                 # Workspace components
│   │   ├── WorkspaceContainer.tsx
│   │   ├── PanelManager.tsx
│   │   ├── Panel.tsx
│   │   ├── PanelResizer.tsx
│   │   └── LayoutPresets.tsx
│   ├── dashboard/                 # Per-dashboard components
│   │   ├── DashboardShell.tsx
│   │   ├── Sidebar.tsx
│   │   ├── TopBar.tsx
│   │   └── PageRenderer.tsx
│   ├── registry/                  # Component registry
│   │   ├── index.ts
│   │   ├── MetricCard.tsx
│   │   ├── DataTable.tsx
│   │   ├── Chart.tsx
│   │   ├── FilterBar.tsx
│   │   └── FallbackComponent.tsx
│   └── ui/                        # Shared UI primitives
│       ├── Button.tsx
│       ├── Card.tsx
│       ├── Input.tsx
│       ├── Modal.tsx
│       └── ...
│
├── lib/
│   ├── tauri/                     # Tauri IPC bridge
│   │   ├── commands.ts            # Type-safe command wrappers
│   │   └── types.ts               # Shared types
│   ├── store/                     # State management
│   │   ├── hub-store.ts           # Hub state
│   │   ├── workspace-store.ts     # Workspace layout state
│   │   └── dashboard-store.ts     # Per-dashboard state factory
│   ├── uiir/                      # UI-IR processing
│   │   ├── renderer.ts            # UI-IR → React tree
│   │   ├── validator.ts           # Client-side validation
│   │   └── types.ts               # UI-IR TypeScript types
│   └── theme/                     # Theme system
│       ├── provider.tsx
│       ├── tokens.ts
│       └── presets.ts
│
└── styles/
    └── globals.css                # Tailwind base + custom
```

---

#### [NEW] `docs/frontend/component-registry.md`
- Registry pattern (component type string → React component)
- Supported component types and their prop contracts
- Validation of UI-IR component nodes before rendering
- Fallback component for unknown types
- Component categories (data display, input, layout, chart, metric)

---

#### [NEW] `docs/frontend/dashboard-hub.md`
- Hub page layout and interactions
- Dashboard card design (icon, name, description, status, actions)
- Create wizard flow (multi-step form)
- Search and filter capabilities
- Dashboard actions (open, edit config, duplicate, archive, delete)

---

#### [NEW] `docs/frontend/workspace-manager.md`
- Panel layout system (1, 2, 3 panels)
- Split directions (horizontal, vertical)
- Preset layouts with diagrams
- Panel resize interaction
- Maximize/restore behavior
- Dashboard assignment to panels
- Layout persistence

---

#### [NEW] `docs/frontend/dashboard-renderer.md`
- UI-IR document → React component tree pipeline
- Page resolution from active route
- Grid layout computation
- Component instantiation from registry
- Data binding resolution (via Tauri IPC)
- Loading skeleton generation
- Error boundary per component

---

#### [NEW] `docs/frontend/state-management.md`
- State isolation architecture (each dashboard gets its own store instance)
- Store factory pattern
- What belongs in each store:
  - Hub store: dashboard list, search, selected
  - Workspace store: panel layout, panel↔dashboard mapping
  - Dashboard store (per instance): active route, sidebar state, filters, data, loading, errors
- Why global state must not leak between dashboards

---

#### [NEW] `docs/frontend/theming.md`
- Tailwind CSS configuration
- Theme tokens (colors, spacing, typography, shadows, radii)
- Dark/light mode toggle
- Per-dashboard theme overrides
- CSS custom properties strategy

---

#### [NEW] `docs/frontend/navigation.md`
- Sidebar generation from UI-IR navigation tree
- Route handling within a dashboard panel
- Nested navigation support
- Active route highlighting
- Navigation isolation between panels

---

#### [NEW] `docs/frontend/forms-and-filters.md`
- Filter bar component design
- Filter types (text search, select, date range, numeric range, boolean)
- Filter state per dashboard instance
- Form generation for data entry (future)
- Validation and error display

---

### Part 4: Workflow & Reference Documentation

---

#### [NEW] `docs/workflows/dashboard-lifecycle.md`

```mermaid
flowchart LR
    A["Create"] --> B["Configure"]
    B --> C["Discover Schema"]
    C --> D["Generate UI-IR"]
    D --> E["Review & Customize"]
    E --> F["Save"]
    F --> G["Reopen & Use"]
    G --> H["Update on Schema Change"]
    H --> E
```

Detailed walkthrough of each lifecycle stage with actor (user/engine), inputs, outputs, and failure handling.

---

#### [NEW] `docs/workflows/schema-change-workflow.md`
- How schema changes are detected (fingerprint comparison)
- Classification: no-op / incremental / breaking
- User notification and review flow
- Regeneration with customization preservation

---

#### [NEW] `docs/workflows/development-workflow.md`
- Dev environment setup (Rust, Node.js, Tauri prerequisites)
- Termux-specific setup notes
- Build commands (dev, production)
- Testing commands
- Project structure navigation
- Contribution guidelines

---

#### [NEW] `docs/workflows/error-recovery.md`
- Failure scenario catalog
- Each scenario: symptoms, root cause, recovery steps, prevention
- Covers: DB unavailable, expired credentials, invalid UI-IR, corrupted cache, plugin crash, query timeout

---

#### [NEW] `docs/references/tech-stack.md`
Technology choices with rationale:

| Technology | Role | Why Chosen |
|-----------|------|-----------|
| Rust | Core engine | Performance, safety, Tauri integration |
| SQLite | Local storage | Zero-config, embedded, reliable |
| PostgreSQL | Business DB | Industry standard, rich metadata |
| TimescaleDB | Time-series | PostgreSQL-compatible, hypertables |
| Next.js | Frontend | React ecosystem, app router, SSG |
| Tailwind CSS | Styling | Utility-first, design system friendly |
| Tauri 2 | Desktop shell | Lightweight, Rust backend, cross-platform |

---

#### [NEW] `docs/references/glossary.md`
Key terms: Dashboard, Workspace, Panel, UI-IR, Schema Discovery, Profiling, Fingerprint, Component Registry, Dashboard Hub, Binding, etc.

---

#### [NEW] `docs/references/testing-strategy.md`
- Unit tests (Rust: `cargo test`, Frontend: `vitest`)
- Integration tests (Rust ↔ PostgreSQL, Frontend ↔ Tauri mock)
- E2E tests (Tauri + WebDriver)
- Critical test scenarios from the spec
- Performance benchmarks

---

#### [NEW] `docs/references/termux-dev-guide.md`
- Termux package installation commands
- Known limitations and workarounds
- Recommended workflow (edit on phone, build on desktop/server via SSH)
- File sync strategies

---

### Part 5: Roadmap

#### [NEW] `docs/roadmap.md`

```mermaid
flowchart TD
    P1["Phase 1: Foundation"] --> P2["Phase 2: Schema Intelligence"]
    P2 --> P3["Phase 3: Dashboard Generation"]
    P3 --> P4["Phase 4: Multi-Dashboard Workspace"]
    P4 --> P5["Phase 5: Polish & Plugins"]
    P5 --> P6["Phase 6: Advanced Features"]
```

| Phase | Backend | Frontend | Duration |
|-------|---------|----------|----------|
| **Phase 1: Foundation** | Tauri project scaffold, SQLite setup, dashboard CRUD commands, connection management | Next.js scaffold, Hub UI, dashboard cards, create wizard | 3-4 weeks |
| **Phase 2: Schema Intelligence** | PostgreSQL adapter, schema discovery, JSONB profiling, relationship detection | Discovery status UI, schema browser, relationship viewer | 3-4 weeks |
| **Phase 3: Dashboard Generation** | UI-IR type system, generator, validator, query engine basics | UI-IR renderer, component registry (5-8 core components), sidebar, routing | 4-5 weeks |
| **Phase 4: Multi-Dashboard** | Workspace layout persistence, panel state isolation, concurrent query management | Panel manager, split layouts, resize, maximize, per-panel error boundaries | 3-4 weeks |
| **Phase 5: Polish & Plugins** | Plugin loader, caching system, schema change detection, performance optimization | Theme system, filter bar, search, loading states, skeleton screens | 3-4 weeks |
| **Phase 6: Advanced** | TimescaleDB adapter, advanced analytics, optional remote service | Charts, time-series components, realtime updates, advanced layouts | 4-6 weeks |

---

## Verification Plan

### Documentation Verification
After creating all files:
1. Verify every file exists at the correct path
2. Verify internal links between documents are consistent
3. Verify the `docs/README.md` index links to all documents
4. Verify Mermaid diagrams render correctly (syntax check)
5. Verify no placeholder content remains

### Structure Verification
```bash
# Count all .md files in docs/
find docs/ -name "*.md" | wc -l
# Expected: 25 files

# Verify directory structure
find docs/ -type f | sort
```

### Manual Verification
- User should review the documentation for:
  - Completeness: Does it cover all aspects from the master spec?
  - Accuracy: Do the technical decisions align with their vision?
  - Clarity: Is each document understandable on its own?
  - Termux compatibility: Are the dev workflow notes realistic?
