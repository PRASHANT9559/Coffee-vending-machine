# Universal UI & Auto-Dashboard Engine

![status](https://img.shields.io/badge/status-planning-yellow)
![backend](https://img.shields.io/badge/backend-Rust-orange)
![frontend](https://img.shields.io/badge/frontend-Next.js%20%2B%20Tailwind-black)
![shell](https://img.shields.io/badge/shell-Tauri%202-blue)
![license](https://img.shields.io/badge/license-TBD-lightgrey)

> One reusable engine. Many independently configured dashboards.

A desktop-first platform for creating, configuring, and operating
data-driven dashboards without building a separate app for every project.
The engine inspects a database, proposes a dashboard from real schema
metadata, renders it through a validated UI representation, and lets users
open several dashboards side by side in one workspace.

The project is split into two buildable parts:

| Part | Role | Stack |
| --- | --- | --- |
| **Backend** | The brain: discovery, profiling, planning, validation, execution, persistence | Rust, SQLite, PostgreSQL, TimescaleDB |
| **Frontend** | The face: hub, workspace, UI-IR renderer, components, theme | Next.js, Tailwind CSS, Tauri 2 |

They meet at one versioned contract: **UI-IR** plus a typed IPC command
surface. The frontend never touches SQL or database credentials, and
configuration never executes arbitrary code.

## What it does

1. Create a dashboard resource with a name, description, icon, and data
   source reference.
2. Discover the schema: tables, views, columns, keys, constraints, indexes,
   and bounded JSONB profiles.
3. Generate a first draft (hybrid mode) with navigation, overview metrics,
   tables, charts, and filters.
4. Review, edit, rearrange, save, and reopen the dashboard.
5. Open two or three dashboards at once in resizable, independent panels.

## Quick start (Termux)

This repository is being planned and authored on an Android phone.

```bash
# Use Termux home, not Android shared storage, for tooling
mkdir -p ~/dashboard_engine
cp -a /mnt/sdcard/download/project/dashboard_engine/. ~/dashboard_engine/
cd ~/dashboard_engine

# Documentation is the current phase; no build required yet.
cat docs/README.md
```

When scaffolding exists, the expected loop is:

```bash
# Frontend (works on phone)
cd frontend
npm install --no-audit --no-fund
NEXT_TELEMETRY_DISABLED=1 npm run dev
# open http://127.0.0.1:3000

# Backend core/CLI (if Rust is available locally)
cd ../backend
cargo test --workspace
cargo run -p dde-cli -- ping
```

Tauri desktop builds are **not** done on the phone. See
[Termux Dev Guide](docs/references/termux-dev-guide.md).

## Project structure

```
dashboard_engine/
├── Universal-UI-Auto-DashboardEngine.md   # master specification
├── README.md                              # this file
└── docs/
    ├── README.md                          # documentation index
    ├── ROADMAP.md                         # phases and exit criteria
    ├── architecture-overview.md           # system shape and boundaries
    ├── backend/                           # Rust engine docs (10)
    ├── frontend/                          # Next.js UI docs (10)
    ├── workflows/                         # lifecycle and process docs (4)
    └── references/                        # stack, glossary, testing, Termux (4)
```

## Documentation

Start with the [documentation index](docs/README.md). Recommended order:

1. [Architecture overview](docs/architecture-overview.md)
2. [Roadmap](docs/ROADMAP.md)
3. [Backend overview](docs/backend/README.md)
4. [Frontend overview](docs/frontend/README.md)
5. [Dashboard lifecycle](docs/workflows/dashboard-lifecycle.md)
6. [Termux dev guide](docs/references/termux-dev-guide.md)

## Status and scope

Current phase: **P1 end-to-end slice**. Backend and frontend code exists, but
the product is not production-ready yet. Build steps live in
[`P0_VERIFY.md`](P0_VERIFY.md), the first slice status in
[`P1_PROGRESS.md`](P1_PROGRESS.md), and the full audit in
[`audit_report.md`](audit_report.md).

In scope for the first release: reusable engine, dashboard hub,
PostgreSQL/TimescaleDB discovery, hybrid generation, editable workspace,
three-panel desktop layout.

Out of scope initially: mobile apps, unrestricted writes, automatic
business-semantic inference, arbitrary executable plugins, guaranteed
offline mutation.

## License

TBD — placeholder until a license is chosen.
