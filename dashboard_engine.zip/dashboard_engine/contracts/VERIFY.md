# Contract Verification

Verify that fixtures pass/fail as expected against `ui-ir.schema.json`.

## Prerequisites

Install a JSON Schema validator. Options:

```bash
# Node (works on Termux)
npm install -g ajv-cli

# Python
pip install jsonschema
```

## Run validation

### With ajv-cli (Node)

```bash
# Valid fixtures must pass
for f in contracts/fixtures/valid/*.json; do
  ajv validate -s contracts/ui-ir.schema.json -d "$f" || echo "FAIL: $f"
done

# Invalid fixtures must fail
for f in contracts/fixtures/invalid/*.json; do
  ajv validate -s contracts/ui-ir.schema.json -d "$f" && echo "UNEXPECTED PASS: $f"
done
```

### With Python jsonschema

```bash
python3 - <<'PY'
import json, glob, jsonschema

schema = json.load(open("contracts/ui-ir.schema.json"))
validator = jsonschema.Draft7Validator(schema)

print("=== Valid fixtures (must pass) ===")
for f in sorted(glob.glob("contracts/fixtures/valid/*.json")):
    data = json.load(open(f))
    errors = list(validator.iter_errors(data))
    status = "PASS" if not errors else f"FAIL ({len(errors)} errors)"
    print(f"  {f}: {status}")

print("=== Invalid fixtures (must fail) ===")
for f in sorted(glob.glob("contracts/fixtures/invalid/*.json")):
    data = json.load(open(f))
    errors = list(validator.iter_errors(data))
    status = "PASS (rejected)" if errors else "FAIL (accepted!)"
    print(f"  {f}: {status}")
PY
```

## Expected results

| Fixture | Expected | Reason |
| --- | --- | --- |
| `valid/dashboard-ecommerce.json` | PASS | Complete valid dashboard |
| `valid/dashboard-analytics.json` | PASS | Charts + time-series |
| `invalid/bad-version.json` | FAIL | `version` != "1.0.0" |
| `invalid/dangling-binding.json` | PASS (schema) | Schema OK; semantic check catches it in code |
| `invalid/unknown-component.json` | FAIL | `type` not in enum |
| `invalid/over-limit.json` | PASS (schema) | `pageSize` in props is free-form; semantic check needed |
| `invalid/duplicate-ids.json` | PASS (schema) | Schema doesn't check cross-array uniqueness; code does |
| `invalid/script-injection.json` | PASS (schema) | Text rendered as text; security check in renderer |
| `invalid/dangling-route.json` | PASS (schema) | Route reference check in code |

Note: Schema catches type/enum/structure errors. Cross-reference and
semantic rules are enforced by the code validators (Rust + TypeScript).
