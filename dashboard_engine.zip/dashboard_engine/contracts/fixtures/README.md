# Schema Drift Fixture

`dashboard-schema-drift.json` — a dashboard with two pages (Orders, Customers)
that references `obj_public_orders` and `obj_public_customers`. Used to test
drift detection workflows:

| Drift scenario | Fixture change | Expected handling |
| --- | --- | --- |
| Add column | New column in `orders` | Suggest as additive; no breakage |
| Drop column | Remove `status` from `orders` | Mark `bnd_orders` invalid; review prompt |
| Rename column | `created_at` → `created_date` | Mapping prompt; no silent rebind |
| Type change | `total` numeric → text | Disable affected components |
| Drop table | Remove `customers` | Placeholder page; config intact |

# JSONB Profiling Fixture

`dashboard-jsonb-profiling.json` — a dashboard built on an `events` table
with a `metadata` JSONB column. Tests:

- JSONB key path components (`cmp_metadata_keys`, `cmp_metadata_types`)
- JSONB profile table (`cmp_metadata_detail`)
- Bounded profiling queries (`q_metadata_keys`, `q_metadata_types`, `q_metadata_detail`)
- No raw sample values exposed (only aggregated stats)

# JSONB Sensitive Keys (Invalid)

`jsonb-sensitive-keys.json` — references a `profile` JSONB column that may
contain sensitive keys (email, phone, token). Tests that:

- Profiling redacts sensitive keys
- No raw sample values are returned
- Only null fraction and cardinality are profiled for denied columns
