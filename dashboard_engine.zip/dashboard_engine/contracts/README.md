# UI-IR Contract

This directory holds the **versioned, validated contract** between the
Rust backend and the Next.js frontend:

| File | Purpose |
| --- | --- |
| `ui-ir.schema.json` | JSON Schema (draft-07) for UI-IR v1.0.0 |
| `commands.json` | Tauri IPC command/response/event contract |
| `fixtures/valid/*.json` | Valid UI-IR documents that must pass validation |
| `fixtures/invalid/*.json` | Invalid UI-IR documents that must be rejected |
| `fixtures/README.md` | Drift and JSONB profiling scenario notes |

## Contract rules

1. **Versioned**: `version` must be `"1.0.0"`. Unknown versions are rejected.
2. **Closed vocabulary**: component types, result shapes, refresh modes, and
   refresh modes come from fixed enums. Anything else is invalid.
3. **Structural validation**: JSON Schema enforces types, bounds, enums, and
   `additionalProperties: false`.
4. **Semantic validation**: Cross-reference checks (ids unique, references
   resolve, layout spans fit grid) are implemented in code
   ([backend/uiir/validator.rs](../backend/src-tauri/src/uiir/mod.rs) and
   [frontend/src/lib/uiir/validator.ts](../frontend/src/lib/uiir/validator.ts)).
5. **No executable content**: string fields are rendered as text; no arbitrary
   JS/HTML blobs.

## Validation gate

Every change to the contract must:

- [ ] Update `ui-ir.schema.json`
- [ ] Update `commands.json` if IPC surface changes
- [ ] Add/update valid fixtures that pass `ajv` / `jsonschema`
- [ ] Add invalid fixtures that produce the expected error codes
- [ ] Update Rust structs in `backend/src-tauri/src/uiir/mod.rs`
- [ ] Update TypeScript types in `frontend/src/lib/tauri/types.ts`
- [ ] Update both validators

## Contract changes

A change to UI-IR or IPC is a **contract change**. It requires both backend
and frontend review before merge, plus a version bump when persisted meaning
changes.
