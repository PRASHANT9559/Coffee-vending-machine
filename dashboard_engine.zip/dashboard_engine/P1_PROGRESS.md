# P1 Progress — First End-to-End Slice

**Goal:** Dashboard create → SQLite save → list → get → stored UI-IR render, with a real Tauri IPC bridge.

> Phone par heavy build nahi chalaya gaya. Neeche diye commands PC par chalane hain.

---

## Kya implement ho gaya

### Backend

| Area | Change | File |
| --- | --- | --- |
| Default UI-IR | `default_dashboard_ir(id, name, description)` — valid starter doc, unbound components | `backend/src-tauri/src/uiir/mod.rs` |
| UI-IR defaults | `description`, `icon`, `theme` ab schema-optional (serde defaults) | `backend/src-tauri/src/uiir/mod.rs` |
| Revision model | `DashboardRevision` + `save_revision()` with optimistic `base_revision` check | `backend/src-tauri/src/storage/mod.rs` |
| Dashboard update | Real `update_dashboard()` (COALESCE name/description) | `backend/src-tauri/src/storage/mod.rs` |
| Icon | `update_dashboard_icon()` stores emoji as JSON | `backend/src-tauri/src/storage/mod.rs` |
| Workspace | `save_workspace_layout()` / `get_workspace_layout()` (SQLite upsert) | `backend/src-tauri/src/storage/mod.rs` |
| Data sources | Create / list / get / delete config rows (secret_ref only) | `backend/src-tauri/src/storage/mod.rs` |
| Data source IPC | `datasource_list`, `datasource_create`, `datasource_get` | `backend/src-tauri/src/commands/mod.rs` |
| Create | Creates dashboard + seeds revision 1 with default UI-IR | `backend/src-tauri/src/commands/mod.rs` |
| Get | `dashboard_get` ab latest revision ka UI-IR bhi return karta hai | `backend/src-tauri/src/commands/mod.rs` |
| Save UI-IR | `dashboard_save_uiir` — parse → validate → save revision | `backend/src-tauri/src/commands/mod.rs` |
| Validate UI-IR | `dashboard_validate_uiir` | `backend/src-tauri/src/commands/mod.rs` |
| Generate | `uiir_generate` returns starter UI-IR (schema-driven later) | `backend/src-tauri/src/commands/mod.rs` |
| Workspace IPC | save/get layout real SQLite se wired | `backend/src-tauri/src/commands/mod.rs` |
| DTO casing | Command request/response structs camelCase | `backend/src-tauri/src/commands/mod.rs` |
| Registration | New commands `generate_handler!` me registered | `backend/src-tauri/src/main.rs` |
| Contract | `contracts/commands.json` snake_case command names + new commands | `contracts/commands.json` |

### Frontend

| Area | Change | File |
| --- | --- | --- |
| Bridge | Real `@tauri-apps/api` `invoke`/`listen`, `{ req: payload }`, dev fallback error | `frontend/src/lib/tauri/commands.ts` |
| Dependency | `@tauri-apps/api` added | `frontend/package.json` |
| Create flow | Form → `dashboard_create` → redirect `/dashboard?id=...` | `frontend/src/app/create/page.tsx` |
| Detail route | Static-export friendly `?id=` route | `frontend/src/app/dashboard/page.tsx` |
| Hub open | Dashboard card ab detail route kholta hai | `frontend/src/app/page.tsx` |
| Detail | `dashboard_get` se dashboard + UI-IR, route/page sync fix | `frontend/src/components/dashboard/dashboard-detail.tsx` |
| Renderer | Saare layout rows + `renderComponent()` (sirf first row nahi) | `frontend/src/components/dashboard/page-renderer.tsx` |
| Workspace | Layout load + debounced save via IPC | `frontend/src/app/workspace/page.tsx` |

---

## PC par verify karne ka order

```bash
# 1. Frontend install + typecheck + build
cd frontend
npm install
npm run typecheck
npm run build

# 2. Backend tests + desktop build
cd ../backend/src-tauri
cargo fmt --check
cargo test
cargo run --bin dde-cli -- ping
cargo build --features tauri --bin dde-core
```

Frontend build pehle chalao, kyunki Tauri `frontend/out` embed karta hai.

---

## Manual end-to-end test (desktop app)

1. App start karo:
   ```bash
   cd backend/src-tauri
   cargo run --features tauri --bin dde-core
   ```
   (ya `cd backend && cargo tauri dev`)

2. Hub khulega → **Add New** → name/description/icon bharo → **Create dashboard**.

3. Expected:
   - Dashboard create hota hai.
   - Detail page khulta hai.
   - Default UI-IR render hota hai: heading + 3 metric cards + detail card.
   - Sidebar me "Overview" active dikhta hai.

4. App band karke dobara kholo:
   - Hub list me dashboard phir dikhna chahiye (SQLite persistence).
   - Open karne par wahi UI-IR render ho.

5. Workspace kholo, panel ratio badlo, app restart karo:
   - Layout persist hona chahiye (SQLite `workspace_layouts`).

---

## Abhi kya baaki hai (P2+)

P2–P6 ka detailed status `P2_P6_PROGRESS.md` me hai. Short version:

- Discovery, query execution, schema-driven UI-IR, plugins registry, CLI,
  icons, CI — code-level complete (PC build pending).
- JSONB profiling abhi explicit "not implemented" error deta hai.
- Revision history UI / conflict prompt, charts rendering, plugin sandbox,
  code signing — future work.

---

## Known compile-risk areas (PC par pehle dekho)

1. `rusqlite::Connection::unchecked_transaction` — rusqlite 0.31 me available hona chahiye; agar version issue ho to `&mut self` + `transaction()` use karna.
2. `@tauri-apps/api` ke saath `tauriListen` generic cast — TS strict me issue aaye to `on` implementation ko explicitly generic likhna.
3. Tauri command arg naming: abhi sab `req` hai, jo camelCase conversion se unaffected hai.
4. Static export: `/dashboard?id=...` route `out/dashboard.html` banega; Tauri asset resolver ise serve karta hai.
