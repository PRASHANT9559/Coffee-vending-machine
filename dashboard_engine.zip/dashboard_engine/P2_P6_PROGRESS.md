# P2–P6 Progress — Schema, Query, Generation, Plugins, Packaging

> Phone par koi heavy build (`npm install`, `next build`, `cargo`) nahi chalaya
> gaya. Neeche sab code-level changes + PC verification steps hain.

---

## P2 — Schema discovery (real PostgreSQL introspection)

| Area | Change | File |
| --- | --- | --- |
| Introspection | `Discovery::inspect()` — bounded, timeout-guarded `tokio_postgres` run | `backend/src-tauri/src/discovery/mod.rs` |
| Connection test | `Discovery::test_connection()` (`SELECT 1`) | `backend/src-tauri/src/discovery/mod.rs` |
| SQL catalog | Objects/columns/PK/FK/relationships queries; `is_nullable` cast to bool | `backend/src-tauri/src/discovery/postgres.rs` |
| Relationship inference | FK constraints + `*_id` naming heuristic with confidence/provenance | `backend/src-tauri/src/discovery/mod.rs` |
| Snapshot persistence | `save_schema_snapshot`, `save_schema_objects`, `save_schema_columns`, `save_relationships` | `backend/src-tauri/src/storage/mod.rs` |
| IPC | `discovery_inspect`, `discovery_snapshot`; `discovery_profile_jsonb` returns an explicit "not implemented" error | `backend/src-tauri/src/commands/mod.rs` |
| Async safety | Engine lock released before `.await` (no `MutexGuard` across await) | `backend/src-tauri/src/commands/mod.rs` |

**Feature gate:** all real I/O is behind `--features postgres`; default build
returns a clear `postgres feature not enabled` error instead of panicking.

## P3 — Query execution

| Area | Change | File |
| --- | --- | --- |
| Compiler | `compile_query()` builds read-only, allowlisted, bounded `SELECT` plans | `backend/src-tauri/src/query/mod.rs` |
| Executor | `execute()` with timeout, typed param mapping, row shaping | `backend/src-tauri/src/query/executor.rs` |
| Cancel | `cancel()` best-effort no-op (in-flight registry is future work) | `backend/src-tauri/src/query/executor.rs` |
| IPC | `query_execute` (paged), `query_cancel` | `backend/src-tauri/src/commands/mod.rs` |
| Data source pick | Uses the dashboard link, falls back to the first configured source | `backend/src-tauri/src/commands/mod.rs` |
| Frontend | `DashboardDetail` executes one query per `data-table` component and feeds `dataByBinding` | `frontend/src/components/dashboard/dashboard-detail.tsx` |
| Frontend | `PageRenderer` falls back to component-id keys for generated drafts | `frontend/src/components/dashboard/page-renderer.tsx` |
| Types | `QueryResult` aligned with the real `{ columns, rows, truncated, ms }` | `frontend/src/lib/tauri/types.ts` |

## P4 — UI-IR generation / apply / migrate

| Area | Change | File |
| --- | --- | --- |
| Generator | `starter_from_tables()` — one `data-table` per discovered table | `backend/src-tauri/src/uiir/mod.rs` |
| Generator | `Generator::generate_draft(snapshot)` | `backend/src-tauri/src/uiir/mod.rs` |
| Migration | `Generator::migrate()` — 1.x forward-only, rejects downgrades / future majors | `backend/src-tauri/src/uiir/mod.rs` |
| IPC | `uiir_generate` now prefers the latest stored snapshot | `backend/src-tauri/src/commands/mod.rs` |
| IPC | `uiir_apply_draft` validates the supplied draft before saving a revision | `backend/src-tauri/src/commands/mod.rs` |
| IPC | `uiir_migrate` | `backend/src-tauri/src/commands/mod.rs` |

## P5 — Plugins

| Area | Change | File |
| --- | --- | --- |
| Manifest | Validation (id format, semver, sandbox level, capabilities) | `backend/src-tauri/src/plugins/mod.rs` |
| Compatibility | `VersionReq` check against `ENGINE_VERSION` | `backend/src-tauri/src/plugins/mod.rs` |
| Registry | register / unregister / list / set_state / enable / disable | `backend/src-tauri/src/plugins/mod.rs` |
| Lifecycle | `Plugin` trait + reserved capability traits | `backend/src-tauri/src/plugins/mod.rs` |
| Loader | `loader::parse` + `loader::load` (manifest-only, no native code) | `backend/src-tauri/src/plugins/mod.rs` |
| Tests | register/list, duplicate id, incompatible engine, dependency ordering | `backend/src-tauri/src/plugins/mod.rs` |

## P6 — Packaging, CLI, CI

| Area | Change | File |
| --- | --- | --- |
| Icons | Generated placeholder PNGs (32/128/256/512 + `@2x`) and `icon.ico` | `backend/src-tauri/icons/` |
| Bundle config | Icons, category, descriptions, Linux/Windows/macOS options, window label | `backend/src-tauri/tauri.conf.json` |
| CLI | `migrate`, `discover`, `generate`, `validate`, `query`, `diagnose` wired to the real engine | `backend/src-tauri/src/bin/dde-cli.rs` |
| CI | Rust fmt/clippy/test + `--features postgres` check; frontend typecheck/build; optional Tauri deb smoke | `.github/workflows/ci.yml` |

### CLI examples

```bash
cd backend/src-tauri
cargo run --bin dde-cli -- ping
cargo run --bin dde-cli -- migrate --db ./engine.sqlite
cargo run --bin dde-cli -- validate --ir ../../contracts/example-uiir.json
cargo run --bin dde-cli -- generate --db ./engine.sqlite --dashboard <id>
cargo run --bin dde-cli -- query --source public.users --intent intent.json
cargo run --features postgres --bin dde-cli -- discover --source "host=localhost port=5432 dbname=app user=readonly"
```

---

## Frontend wiring completed

- Configure page → `dashboard_save` (real metadata update).
- Discover page → lists `datasource_list`, runs `discovery_inspect`, shows tables/relationships.
- Settings → data source create (camelCase payload) and delete.
- Dashboard → per-table `query_execute` + refresh button.
- Hub → real delete with list refresh.

---

## PC par verify karne ka order

```bash
# 1. Frontend
cd frontend
npm install
npm run typecheck
npm run build

# 2. Rust core
cd ../backend/src-tauri
cargo fmt --all
cargo clippy --all-targets -- -D warnings
cargo test --all-targets
cargo check --features postgres

# 3. CLI smoke
cargo run --bin dde-cli -- ping
cargo run --bin dde-cli -- validate --ir ../../P0_VERIFY.md   # expected: parse error, proves wiring
cargo run --bin dde-cli -- migrate --db /tmp/dde-test.sqlite

# 4. Desktop
cargo build --features tauri --bin dde-core
```

---

## Known compile/runtime risks (fix on PC first)

1. `tokio-postgres` API details in `executor.rs` / `discovery/mod.rs` —
   `try_get` with optional types, `client.query` param slice.
2. `LIST_FOREIGN_KEYS` uses `LATERAL unnest(...) WITH ORDINALITY`; verify on
   PostgreSQL 13+.
3. Tauri 2 capability schema: window label is now `main`; regenerate
   `gen/schemas` with `cargo tauri dev` once.
4. `next.config.mjs` is ESM (`export default`) — do not convert back to
   `module.exports`.
5. `next` pinned to `14.2.35` to match React 18; regenerate `package-lock.json`
   on PC (`npm install`).
6. `Cargo.lock` not committed yet — generate on PC.

## Abhi bhi baaki (post-P6)

- JSONB profiling (`discovery_profile_jsonb`) — explicit not-implemented error.
- Real query cancellation registry (currently best-effort).
- Revision history UI + conflict resolution dialog.
- Charts rendering (currently a placeholder box).
- Code signing / notarization / auto-update.
- Plugin sandbox runtime (WASM/sidecar) — only manifests + registry today.
