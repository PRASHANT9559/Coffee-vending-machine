# P0 Verification Guide (Run on PC)

**Purpose:** P0 ka actual proof PC par lena hai. Phone/Termux par heavy build nahi karna.

**Project root:** `/path/to/dashboard_engine`

---

## 0. Prerequisites

- **Node.js 20+** and npm 10+
- **Rust stable** (`rustup`)
- **Tauri v2 system dependencies** (Linux example):
  ```bash
  sudo apt install build-essential curl wget file libssl-dev \
    libwebkit2gtk-4.1-dev libayatana-appindicator3-dev librsvg2-dev
  ```
- Optional: `cargo install tauri-cli --version "^2"` (or use `npx @tauri-apps/cli@2`)

> Phone/Termux note: `npm install` and `next build` are intentionally not run on `/mnt/sdcard`.
> Next.js does not publish an Android arm64 SWC binary, so production builds must run on PC.

---

## 1. Frontend: install + typecheck + build

```bash
cd frontend
npm install
npm run typecheck
npm run build
```

Expected:

- `npm install` creates `package-lock.json` (commit it).
- `npm run typecheck` exits with no errors.
- `npm run build` creates `frontend/out/` (static export).

If `next build` fails on `use client` / prerender:

1. Check the failing route.
2. Any component using hooks/state/effects must live in a `"use client"` file.
3. Server pages must not export `metadata` and use hooks in the same file; split into a server wrapper + client component.

### Known current status

- `npx tsc --noEmit` already passed on 4 Nov 2026 after the P0 type fixes.
- `next build` could not complete on Android because Next tried to download `@next/swc-android-arm64` (404). This is a platform limitation, not a project-code failure.
- `next.config.js` sets `experimental.useWasmBinary` only when `process.platform === "android"`; PC builds use native SWC.

---

## 2. Backend: test + build (core first)

```bash
cd backend/src-tauri

# Formatting check (fixes are safe to apply with `cargo fmt`)
cargo fmt --check

# Core/unit tests (no Tauri/GTK needed)
cargo test

# CLI smoke test
cargo run --bin dde-cli -- ping

# Desktop shell build (Tauri)
cargo build --features tauri --bin dde-core
```

Expected:

- `cargo test` compiles the library and runs the existing unit tests.
- `dde-cli ping` prints the engine version and capabilities.
- `dde-core` builds with Tauri.

If `cargo build --features tauri` fails:

1. Confirm `frontend/out/` exists (run frontend build first).
2. Confirm `build.rs` and `[build-dependencies] tauri-build` are present.
3. Confirm `src-tauri/tauri.conf.json` exists and paths are correct.
4. Confirm `src-tauri/capabilities/default.json` exists.
5. Check Tauri system dependencies and Rust version.

### Known current status

- `cargo`/`rustc` were not installed in the phone environment, so backend compile was not executed.
- Static P0 fixes applied: `Stage::Internal`, `From` impls, feature-gated modules, optional dependencies, sync Tauri commands, `Arc<Mutex<Engine>>` state, `tauri.conf.json`, `build.rs`, capabilities.
- Remaining compile risk is low but must be proven by `cargo test` / `cargo build` on PC.

---

## 3. Generate lockfiles (commit both)

```bash
cd frontend
npm install --package-lock-only
cd ../backend/src-tauri
cargo generate-lockfile
```

Or simply let the normal install/build create them:

- `frontend/package-lock.json`
- `backend/src-tauri/Cargo.lock`

Commit both files so builds are reproducible.

---

## 4. Tauri packaging smoke test (after frontend/backend build)

```bash
cd frontend
npm run build

# Tauri CLI app dir = the directory that contains `src-tauri` (i.e. `backend`).
cd ../backend
cargo tauri build
# or: npx @tauri-apps/cli@2 build
```

Expected:

- A desktop bundle is produced under `backend/src-tauri/target/release/bundle/`.
- If packaging fails only on icons/signing, treat it as a P6 packaging task; the code build is still green.
- Direct binary build without the CLI: `cd backend/src-tauri && cargo build --features tauri --bin dde-core`.

---

## 5. Re-check P0 checklist

| # | Item | Command / Evidence | Status |
| --- | --- | --- | --- |
| 1 | Frontend typecheck | `npm run typecheck` | ✅ passed on phone |
| 2 | Frontend production build | `npm run build` → `frontend/out/` | ⏳ run on PC |
| 3 | Backend unit tests | `cargo test` | ⏳ run on PC |
| 4 | Backend desktop build | `cargo build --features tauri --bin dde-core` | ⏳ run on PC |
| 5 | Tauri config present | `src-tauri/tauri.conf.json` | ✅ |
| 6 | Tauri build script | `src-tauri/build.rs` + `tauri-build` | ✅ |
| 7 | Tauri capabilities | `src-tauri/capabilities/default.json` | ✅ |
| 8 | Lockfiles | `package-lock.json`, `Cargo.lock` | ⏳ generate and commit |

---

## 6. What P0 does *not* fix

P0 only makes the skeleton build. These still return stubs or are not wired:

- `datasource_test`
- `discovery_inspect`
- `query_execute`
- `uiir_generate`
- `workspace_save_layout` / `workspace_get_layout`
- real Tauri IPC bridge (frontend still uses the error-only mock)
- PostgreSQL adapter, discovery, query execution, UI-IR generation, revisions, real workspace persistence
- tests/CI/security enforcement/packaging icons

Those move to P1–P6 in `audit_report.md`.

---

## 7. Quick commands (copy/paste)

```bash
# Frontend
cd frontend && npm install && npm run typecheck && npm run build

# Backend
cd ../backend/src-tauri && cargo fmt --check && cargo test && \
  cargo run --bin dde-cli -- ping && cargo build --features tauri --bin dde-core

# Lockfiles
cd ../../frontend && npm install --package-lock-only
cd ../backend/src-tauri && cargo generate-lockfile
```
