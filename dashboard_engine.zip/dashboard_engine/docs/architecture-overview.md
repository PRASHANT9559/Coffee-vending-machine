# Architecture Overview

High-level system shape. Implementation details live in
[backend/architecture.md](backend/architecture.md) and
[frontend/architecture.md](frontend/architecture.md).

## 1. The idea in one picture

```mermaid
flowchart LR
    U["User"] --> FE["Frontend: Next.js + Tailwind"]
    FE -->|"typed IPC commands"| BE["Backend: Rust core"]
    BE -->|"UI-IR + query results"| FE
    BE --> CFG[("SQLite: config and cache")]
    BE -->|"read-only"| PG[("PostgreSQL")]
    BE -->|"read-only"| TS[("TimescaleDB")]
```

Two parts, one contract. The frontend is responsible for interaction and
rendering. The backend is the only component allowed to inspect schemas,
hold credentials, or execute queries.

## 2. Part A and Part B

| Concern | Frontend (A) | Backend (B) |
| --- | --- | --- |
| Dashboard hub | owns | provides list/CRUD |
| Creation wizard | owns forms | validates and persists |
| Schema discovery | displays results | owns |
| Relationship inference | displays/overrides | owns |
| Analytics planning | renders output | owns |
| UI-IR | validates and renders | generates and validates |
| Query execution | requests | owns |
| Permissions | reflects | enforces |
| Secrets | never sees | resolves by reference |
| Multi-panel workspace | owns | supports via concurrency and persistence |
| Theme | owns | stores preference only |
| Local storage | never touches | owns SQLite |

Shared artifacts (versioned, reviewed by both sides):

- UI-IR JSON document — [backend/ui-ir-spec.md](backend/ui-ir-spec.md)
- IPC commands/events — [backend/api-reference.md](backend/api-reference.md)
- Error codes and permission vocabulary
- Compatibility matrix (engine ↔ UI-IR ↔ local schema ↔ plugin API)

## 3. Trust boundaries

| Zone | Trust level | Allowed to |
| --- | --- | --- |
| Dashboard config / UI-IR | untrusted data | describe supported components; never execute |
| Frontend renderer | trusted for UX, not for authorization | render registry components, call IPC |
| Rust core | trusted | validate, plan, execute bounded queries, persist config |
| Local SQLite | trusted local state | config/cache only |
| Business database | authoritative | read-only through validated plans |

Rules:

- The frontend cannot construct SQL. It names query intents; the core
  compiles them.
- The core re-validates UI-IR before saving and before deriving work.
- Visibility in the UI is not an authorization boundary.
- Configuration never supplies executable code.

## 4. Primary data flows

### 4.1 Create a dashboard

```
Hub -> wizard -> IPC dashboard:create
  -> core validates identity + connection reference
  -> SQLite: dashboards row + revision 1
  -> returns dashboard id
```

### 4.2 Discover and generate

```
IPC discovery:inspect { dashboardId }
  -> resolve connection (read-only)
  -> introspect objects/columns/keys/indexes
  -> bounded profiling (stats, nulls, JSONB paths)
  -> relationship candidates with confidence
  -> store immutable snapshot + fingerprint
  -> planner proposes analytics
  -> UI-IR generator builds a draft (hybrid)
  -> returns draft + validation report (not auto-applied)
```

### 4.3 Render a panel

```
Workspace opens dashboard
  -> IPC dashboard:get -> UI-IR (or migration-required error)
  -> frontend validates
  -> renderer resolves routes/pages/components/bindings
  -> components request data via query:execute
  -> core validates plan -> bounded read-only query -> shaped rows
```

### 4.4 Arrange the workspace

```
Frontend edits split -> IPC workspace:save-layout
  -> core persists {panels:[dashboardId], ratios, activeId}
```

The arrangement never rewrites dashboard definitions.

## 5. Runtime modes

| Mode | Renderer | Core | Transport |
| --- | --- | --- | --- |
| Desktop (target) | static Next.js export in Tauri | in-process Tauri commands | `invoke` + events |
| Phone dev | `next dev` in phone browser | CLI or local dev bridge | HTTP/JSON |
| Remote (Phase 6, optional) | same web build | Rust service | HTTPS/WebSocket |

Business logic does not fork by mode; only the transport adapter changes.

## 6. Multi-dashboard isolation

```
Workspace
├── Panel 1: DashboardRuntime(dashboard A)
│   ├── route stack, filters, selection, pagination, scroll
│   ├── request map, errors, connection state
│   └── unsaved flag
├── Panel 2: DashboardRuntime(dashboard B)  (same shape, separate instance)
└── Panel 3: DashboardRuntime(dashboard C)  (same shape, separate instance)
```

App-level state is limited to the hub list, workspace arrangement, theme,
toasts, and bridge status. Everything dashboard-specific lives in a panel
instance.

Shared infrastructure (engine, adapters, registry) is reused; identity,
navigation, runtime state, and authorization context are not.

## 7. Failure containment

| Failure | Containment |
| --- | --- |
| One panel's query fails | that binding only; other panels unaffected |
| Panel component crash | panel/page error boundary |
| Discovery timeout | last good snapshot kept, marked stale |
| Invalid UI-IR | dashboard blocked with diagnostics; hub still works |
| Corrupt cache | drop/rebuild derived data; config intact |
| Database unavailable | per-source disconnected state |
| Config conflict | revision conflict surfaced; no silent overwrite |
| Plugin incompatible | plugin disabled; engine starts |

## 8. Performance budgets (initial)

| Path | Target | Notes |
| --- | --- | --- |
| Shell interactive | < 1.5 s warm | static export |
| Hub render (50 cards) | < 100 ms | no schema work on hub |
| Panel activation (cached IR) | < 300 ms | no rediscovery |
| First query (local PG) | < 1 s p50 | excludes cold connect |
| Split to three panels | < 800 ms | inactive panels lazy |
| Discovery (100 tables) | < 5 s | bounded, cancellable |
| Idle background work | ~0 | no polling by default |

Budgets are measured per phase; phone and desktop numbers are labeled
separately.

## 9. Key decisions

| # | Decision | Consequence |
| --- | --- | --- |
| 1 | Two parts with a written contract | parallel work, contract discipline |
| 2 | UI-IR is the source of truth for rendering | no per-project page code |
| 3 | Rust owns SQLite and all DB access | simpler, safer frontend |
| 4 | Static Next.js export inside Tauri | no SSR/server routes in desktop build |
| 5 | Desktop shell built in CI/desktop, not on phone | honest verification, CLI-first core |
| 6 | Dashboard config separated from workspace layout | resizing never dirties a dashboard |
| 7 | Per-panel runtime state, no global nav store | isolation is testable |
| 8 | Hybrid generation with explicit apply | user control preserved |
| 9 | Read-only analytics in v1 | simpler security model |
| 10 | Plugins deferred to Phase 5 | avoid premature generalization |
| 11 | Secrets stored outside config DB | export/import handles missing refs |
| 12 | Everything bounded | limits on rows, time, memory, depth |

## 10. Out of scope (initial release)

- Mobile applications and mobile layouts.
- Unrestricted database writes or DDL.
- Automatic business-meaning inference from names.
- Arbitrary user-supplied executable plugins.
- Guaranteed offline mutation.
- Multi-tenant hosting (design notes only until Phase 6).

## 11. Where to read next

- Delivery order: [ROADMAP.md](ROADMAP.md)
- Backend modules: [backend/architecture.md](backend/architecture.md)
- Contract: [backend/ui-ir-spec.md](backend/ui-ir-spec.md)
- Security rules: [backend/security.md](backend/security.md)
- Frontend app: [frontend/architecture.md](frontend/architecture.md)
