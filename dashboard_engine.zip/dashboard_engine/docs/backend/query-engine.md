# Query Engine

Query system design for the backend. Covers validation, execution, and
aggregation patterns for read-only analytics.

## 1. Query intention model

Dashboards never supply raw SQL. They submit a **query intent** — a
declarative description of what is needed:

```rust
pub struct QueryIntent {
    pub kind: QueryIntentKind,          // select | aggregate | grouped | timeseries | distribution | top_n
    pub source_id: String,              // discovered object id
    pub fields: Vec<String>,            // explicit column list
    pub order_by: Vec<SortSpec>,        // field + direction
    pub limit: Option<i64>,             // enforced cap
    pub offset: Option<i64>,
    pub params: Vec<QueryParam>,        // typed parameters only
    pub group_by: Option<Vec<String>>,  // for grouped aggregation
    pub aggregates: Option<Vec<Aggregate>>, // count/sum/avg/min/max/distinct
    pub time_column: Option<String>,    // for timeseries
    pub bucket: Option<String>,         // e.g. '1 day' for TimescaleDB
}
```

The backend compiles this into parameterized SQL per adapter dialect.

## 2. Validation pipeline

Enforced in order:

1. **Authenticate** request context (local user / remote session).
2. **Resolve** dashboard + data source + permission scope.
3. **Parse** intent (typed, not SQL).
4. **Check** intent kind allowed for this scope.
5. **Check** every object/column in the allowlist for this dashboard.
6. **Check** limits: `limit <= max`, `offset <= max`, `timeout <= max`.
7. **Compile** parameterized SQL for the adapter.
8. **Open** read-only transaction / read-only role.
9. **Set** statement timeout + fetch cap; register cancellation token.
10. **Execute**, stream/truncate safely.
11. **Strip** internal details from response; record audit entry (no values).

If any step fails → typed error, no partial unsafe fallback.

## 3. Permission checks

- Source-level: which data sources a dashboard may use.
- Object-level: allowed schemas/objects (default: configured list).
- Column-level: optional deny list for sensitive columns.
- Operation-level: read-only analytics in v1.
- Scope label (e.g. `analytics:read`) used in cache keys and audit logs.

Default deny. UI hiding is cosmetic; the core re-checks on every query.

## 4. Connection pooling

- One pool per data source, sized by configured concurrency cap.
- Read-only role / `default_transaction_read_only = on` where possible.
- Statement timeout at role level as second line of defense.
- Idle connections closed after TTL.

## 5. Bounds

| Limit | Default | Hard max |
| --- | --- | --- |
| Rows per query | 1,000 | 10,000 |
| Query timeout | 15 s | 60 s |
| Global concurrent queries | 6 | 16 |
| Per-dashboard concurrent queries | 2 | 4 |
| Joins per query | 3 | 3 |
| GROUP BY cap | enforced | high-cardinality text capped |

Every query bounded, cancellable, and protected by timeouts.

## 6. Aggregation patterns

| Pattern | Use case | Notes |
| --- | --- | --- |
| COUNT | row counts | cheap |
| SUM / AVG | measures | numeric only |
| MIN / MAX | bounds | numeric/temporal |
| COUNT(DISTINCT) | cardinality | capped |
| GROUP BY | categories | low-cardinality only |
| Time bucket | time series | TimescaleDB |
| Top-N | ranked lists | with limit |

Domain analytics (churn, MRR, cohorts) are plugin territory — never
inferred from column names alone.

## 7. Time-series patterns (TimescaleDB)

When TimescaleDB is available:

- `time_bucket(bucket, time_column)` for grouped time series.
- Continuous aggregates queried like views.
- Hypertable metadata used to choose optimal time column.

Same validation path applies — no special-casing safety away.

## 8. Cancellation

Every execution gets a cancellation token tied to the IPC request. Panel
close, navigation change, or timeout triggers cancellation. Best-effort
but observed via request status in frontend.

## 9. Result shaping

Response includes:

- `columns[]` with names/types
- `rows[]` shaped values (no secrets)
- `row_count`, `truncated`, `execution_ms`
- Cache metadata where applicable

Errors carry stable codes: `QUERY_FORBIDDEN`, `QUERY_TIMEOUT`,
`QUERY_CANCELLED`, `QUERY_LIMIT_EXCEEDED`, `QUERY_INVALID`.

## Where to read next

- [database-discovery.md](database-discovery.md) — object/column sources
- [ui-ir-spec.md](ui-ir-spec.md) — bindings reference queries
- [security.md](security.md) — permission model
- [caching-strategy.md](caching-strategy.md) — query cache keys
