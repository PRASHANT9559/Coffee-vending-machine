# Database Discovery

Schema discovery deep-dive for the backend. This document covers how the
engine inspects databases safely and within bounds.

## 1. Supported sources

| Source | Adapter | Support |
| --- | --- | --- |
| PostgreSQL | `postgres` | Full (tables, views, columns, keys, constraints, indexes) |
| TimescaleDB | `timescale` | Full + hypertable & continuous aggregate metadata |

Discovery is **read-only only**. No `ALTER`, `DROP`, or `CREATE` issued
by the engine. Credentials resolved from secret references.

## 2. Introspection queries

All introspection runs against `information_schema` and `pg_catalog`
using parameterized, read-only queries.

### 2.1 Objects

Schemas, tables, views, materialized views:

```sql
SELECT n.nspname AS schema_name,
       c.relname AS object_name,
       c.relkind AS object_type,
       obj_description(c.oid) AS comment
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind IN ('r','v','m','p')
  AND n.nspname NOT IN ('pg_catalog','information_schema')
```

### 2.2 Columns

```sql
SELECT table_schema, table_name, column_name, ordinal_position,
       data_type, character_maximum_length, numeric_precision,
       numeric_scale, is_nullable, column_default
FROM information_schema.columns
ORDER BY table_schema, table_name, ordinal_position
```

### 2.3 Keys & constraints

Primary keys, foreign keys, unique constraints extracted from
`pg_constraint`, `information_schema.table_constraints`, and
`information_schema.key_column_usage`.

### 2.4 Indexes

Names, columns, uniqueness from `pg_index` / `pg_stat_user_indexes`.

### 2.5 Row estimates

Catalog statistics (`pg_class.reltuples`) used instead of `COUNT(*)`
to avoid unbounded scans.

## 3. JSONB profiling (bounded)

Allowed, all bounded:

- Key path enumeration up to depth 3.
- Value-type distribution per path (aggregated counts only).
- Null fraction per column/path via sampling (`TABLESAMPLE` or `LIMIT`).
- Distinct count capped at a configured limit.
- Sensitive columns (by deny list/config: email, phone, token, secret,
  PII) profiled only for null/cardinality — never sample values.

Forbidden:

- Full row selection into local storage.
- Unbounded `DISTINCT` or `GROUP BY`.
- Profiling binary/large-object columns.

Output: bounded JSONB profile object stored in `jsonb_profiles`, never
exposing raw sample values unnecessarily.

## 4. Relationship inference

Represented with source and confidence:

| Evidence | Kind | Confidence band |
| --- | --- | --- |
| Declared FK constraint | `fk` | 1.00 |
| Unique + compatible type + name similarity | `unique_inferred` | 0.70–0.90 |
| Index + compatible type + name similarity | `unique_inferred` | 0.55–0.75 |
| Name match + compatible type | `name_inferred` | 0.40–0.70 |
| JSONB path mirrors another object's key | `jsonb_inferred` | 0.20–0.50 |

Rules:

- Only `fk` candidates used automatically for generated joins.
- Inferred candidates shown to user for accept/reject.
- Never silently become authoritative DB constraints.
- Rejected candidates persist as rejected until user changes them.
- Confidence drops with type mismatch, missing uniqueness, or ambiguity.

## 5. TimescaleDB extensions

Hypertable detection (`timescaledb_information.hypertables`), continuous
aggregates, and retention policies inspected when available. Time bucket
query patterns registered for time-series generation.

## 6. Snapshots & fingerprints

Each discovery run produces an **immutable snapshot** keyed by a stable
fingerprint (hash of canonical DDL representation).

- New discovery creates a new snapshot; old snapshots retained.
- Fingerprint compared on subsequent runs to detect drift.
- Partial discovery (timeout/cancel) marked `partial` with reasons; never
  presented as complete.
- Snapshots referenced by dashboard config by snapshot id.

## 7. Bounds

| Limit | Default | Notes |
| --- | --- | --- |
| Objects per discovery | 500 | hard max 2,000 |
| Discovery timeout | 30 s | hard max 120 s |
| JSONB depth | 3 | configurable |
| Sample rows per table | 1,000 | capped |
| Distinct count cap | 1,000 | exact > cap estimated |

Discovery and profiling are cancellable via request token tied to the
IPC request.

## Where to read next

- [query-engine.md](query-engine.md) — how discovery feeds queries
- [caching-strategy.md](caching-strategy.md) — fingerprint-based cache
- [security.md](security.md) — read-only enforcement
