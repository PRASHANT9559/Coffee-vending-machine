# Backend API Reference

Tauri IPC command catalog and event surface. Commands are typed
request/response pairs; events are advisory backend → frontend
notifications.

## Command format

Tauri v2 invocation: `invoke(command, { req: payload })`. The frontend
`BridgeClient` wraps the result into
`{ id, ok, data?, error?: { code, message, retryable? } }` for consistent UI
handling. `ping` takes no `req` argument.

## 1. Dashboard management

| Command | Request | Response | Notes |
| --- | --- | --- | --- |
| `dashboard_create` | `{ name, description?, icon? }` | `{ dashboardId }` | draft + starter UI-IR |
| `dashboard_list` | `{ query?, cursor? }` | `{ items[], next? }` | hub |
| `dashboard_get` | `{ dashboardId }` | `{ dashboard, uiir?, revision }` | render |
| `dashboard_save` | `{ dashboardId, name?, description? }` | `{ dashboardId, revision }` | metadata |
| `dashboard_delete` | `{ dashboardId, confirmName }` | `{ ok }` | archive/remove |
| `dashboard_save_uiir` | `{ dashboardId, ir, baseRevision?, source?, note? }` | `{ dashboardId, revision, validation }` | optimistic concurrency |
| `dashboard_validate_uiir` | `{ ir }` | `{ valid, version, errors[], warnings[] }` | editor pre-check |

## 2. Data sources

| Command | Request | Response | Notes |
| --- | --- | --- | --- |
| `datasource_list` | `{}` | `{ items[] }` | no secrets |
| `datasource_create` | `{ name, kind, host, port, databaseName, username, secretRef, sslMode? }` | `{ dataSourceId }` | config only |
| `datasource_test` | `{ dataSourceId }` | `{ ok, latencyMs, errorCode? }` | `SELECT 1` when the `postgres` feature is on |
| `datasource_get` | `{ dataSourceId }` | `{ dataSource }` | no secret |
| `datasource_delete` | `{ dataSourceId }` | `{ ok }` | dashboard links cascade |

## 3. Schema discovery

| Command | Request | Response | Notes |
| --- | --- | --- | --- |
| `discovery_inspect` | `{ dashboardId, dataSourceId }` | `{ snapshotId, fingerprint, status, tableCount, relationshipCount, warnings[] }` | persists snapshot + objects + relationships |
| `discovery_snapshot` | `{ snapshotId }` | `{ snapshotId, summary }` | display-safe JSON summary |
| `discovery_profile_jsonb` | `{ snapshotId, table, column }` | `{ paths[] }` | reserved (returns an explicit error today) |

## 4. Query execution

| Command | Request | Response | Notes |
| --- | --- | --- | --- |
| `query_execute` | `{ dashboardId, queryId, params?, page? }` | `{ columns[], rows[], truncated, ms }` | read-only; `queryId` is the table name on this path |
| `query_cancel` | `{ requestId }` | `{ ok }` | best effort |

## 5. UI-IR

| Command | Request | Response | Notes |
| --- | --- | --- | --- |
| `uiir_generate` | `{ dashboardId, mode }` | `{ draftId, uiir, report }` | schema-driven from the latest snapshot |
| `uiir_apply_draft` | `{ dashboardId, draftId, uiir, strategy }` | `{ revision, uiir }` | validates before saving |
| `uiir_migrate` | `{ uiir, toVersion }` | `{ uiir, report }` | explicit |

## 6. Workspace

| Command | Request | Response | Notes |
| --- | --- | --- | --- |
| `workspace_save_layout` | `{ layout }` | `{ ok }` | arrangement only |
| `workspace_get_layout` | `{}` | `{ layout }` | restore |

## 7. Diagnostics

| Command | Request | Response |
| --- | --- | --- |
| `diagnostics_get` | `{}` | `{ versions, health[], cacheStats }` (no secrets) |
| `ping` | `{}` | `{ version, capabilities }` |

## 8. Events (backend → frontend)

| Event | Payload | Purpose |
| --- | --- | --- |
| `query:progress` | `{ requestId, stage }` | long discovery/query |
| `data:changed` | `{ dashboardId, bindingIds[] }` | targeted refresh |
| `connection:state` | `{ dataSourceId, state }` | per-source status |
| `schema:drift` | `{ dashboardId, snapshotId, changes[] }` | review prompt |
| `config:recovered` | `{ dashboardId, fromRevision }` | recovery notice |

Events advisory; frontend refetches on demand if missed.

## 9. Error codes (stable)

| Code | Meaning |
| --- | --- |
| `DS_UNREACHABLE` | source cannot connect |
| `DS_AUTH_FAILED` | credentials invalid |
| `DS_READ_ONLY_DENIED` | write attempt |
| `DISCOVERY_TIMEOUT` | discovery exceeded limit |
| `DISCOVERY_PARTIAL` | incomplete snapshot |
| `QUERY_FORBIDDEN` | object/column not allowlisted |
| `QUERY_INVALID` | malformed intent |
| `QUERY_TIMEOUT` | statement timeout |
| `QUERY_CANCELLED` | request cancelled |
| `QUERY_LIMIT_EXCEEDED` | row/offset cap |
| `IR_INVALID` | UI-IR validation failed |
| `IR_VERSION_UNSUPPORTED` | version mismatch |
| `CONFIG_CONFLICT` | stale baseRevision |
| `CONFIG_CORRUPT` | store integrity failure |
| `PLUGIN_INCOMPATIBLE` | plugin version mismatch |
| `CACHE_CORRUPT` | cache index failure |
| `INTERNAL` | unexpected |

## Where to read next

- [ui-ir-spec.md](ui-ir-spec.md) — payload shapes
- [security.md](security.md) — IPC hardening
- [frontend/architecture.md](../frontend/architecture.md) — bridge client
