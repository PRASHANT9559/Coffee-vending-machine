# Security

Security model for the backend. Security is a **backend responsibility**;
the frontend reflects permissions but never enforces them.

## 1. Threat model

| Asset | Risk if exposed |
| --- | --- |
| DB credentials | full data compromise |
| Business rows | privacy / compliance breach |
| Schema details | reconnaissance |
| Dashboard config | tampering, privilege escalation |
| Logs/diagnostics | leakage of values |

## 2. Trust boundaries

| Zone | Trust | May do |
| --- | --- | --- |
| UI-IR / config | untrusted data | describe components; never execute |
| Frontend | trusted for UX, not auth | render registry, call IPC |
| Rust core | trusted | validate, plan, execute bounded queries |
| SQLite | trusted local state | config/cache only |
| Business DB | authoritative | read-only via validated plans |

## 3. Query execution pipeline

```
1. authenticate context
2. resolve dashboard + source + scope
3. parse intent (typed)
4. check intent kind allowed
5. check objects/columns in allowlist
6. check limits (max rows, timeout)
7. compile parameterized SQL
8. open read-only transaction
9. set statement_timeout + fetch cap + cancel token
10. execute, stream/truncate safely
11. strip internal details from response
12. record audit entry (no values)
```

## 4. Authorization model (v1)

- Default deny; allowlist explicit.
- Source-level, object-level, optional column-level deny.
- Operation-level: read-only analytics.
- Scope label used in cache keys and audits.
- UI hiding cosmetic; core re-checks every query.

## 5. Credentials

- Never stored in SQLite/dashboard descriptions/UI config.
- `secret_ref` pointer only; resolved via OS keyring / env / secret
  manager.
- Connection strings with embedded passwords not accepted.
- Never logged, echoed, or exported.

## 6. IPC hardening

- All commands validate full input shape.
- Command allowlist; no generic "execute" RPC.
- Tauri capabilities restrict filesystem/shell access.
- Rate-limit expensive commands per dashboard.
- Long operations return request id + cancellation.

## 7. Logging & errors

Emitted: stable code, stage, duration, counts, dashboard/source ids.

Never emitted: passwords, tokens, raw SQL params with PII, row values,
full connection strings.

Error envelope example:

```jsonc
{ "code": "QUERY_TIMEOUT", "message": "Query exceeded 15s", "requestId": "req_...", "retryable": true }
```

## 8. Database role guidance

- Dedicated read-only role for analytics.
- `USAGE` on allowed schemas, `SELECT` on allowed objects only.
- `default_transaction_read_only = on` where possible.
- Statement timeout at role level as second defense.

## 9. Recovery & abuse limits

- Repeated failed auth → backoff, no credential echo.
- Discovery/profiling bounded (time, object count, samples).
- Query concurrency cap per dashboard + global.
- Cancel queries on panel close.
- Cache never authorization bypass.

## 10. Security checklist per milestone

- No secret in SQLite, logs, UI-IR, exports.
- Validation tests for every new command.
- Denial tests for every new query shape.
- Limits enforced server-side.
- Cross-panel/scope isolation tested.
- Errors contain codes, not row values.
- Dependency additions reviewed for supply-chain risk.
- Residual risks documented.
