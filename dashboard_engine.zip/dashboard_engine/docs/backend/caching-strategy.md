# Caching Strategy

Cache design for the backend: what is cached, key design, invalidation,
and recovery.

## 1. What gets cached

| Cache | Contents | Rebuildable? |
| --- | --- | --- |
| Schema snapshots | Introspection results, fingerprints | Yes (re-discover) |
| JSONB profiles | Key paths, types, null fractions | Yes |
| Query results | Shaped columns + rows + metadata | Yes (re-execute) |
| Compiled UI-IR | Normalized dashboard document | Yes (regenerate) |
| Config revisions | Stored as source of truth | No (authoritative) |

Business data is **never** mirrored locally by default.

## 2. Cache key design

```
queryKey = H(
  dataSourceId,
  schemaFingerprint,
  queryIntentHash,
  normalizedParamsHash,
  permissionScope,
  rowLimit,
  engineQueryVersion
)
```

Every cache entry scoped to a permission scope. Cache never used to
bypass authorization — scope mismatch = cache miss.

## 3. Invalidation

| Trigger | Action |
| --- | --- |
| Fingerprint change | invalidate derived cache for source |
| Permission scope change | invalidate relevant entries |
| TTL expiry | evict entry |
| Manual refresh | invalidate and re-execute |
| Schema drift event | mark entries stale, prompt review |
| Cache corruption | drop and rebuild |

## 4. Fingerprinting

Stable hash of canonical DDL representation:

```
(schema, object, type, columns(name,type,nullable,ordinal,default),
 keys, constraints, indexes)
```

Excludes volatile stats (row estimates) so fingerprints don't churn on
data changes alone. Stored with snapshot; compared on subsequent
discovery.

Drift classification:

| Class | Example | Action |
| --- | --- | --- |
| Unchanged | same fingerprint | no-op |
| Additive | new table/column | suggest additions |
| Breaking | dropped referenced column | review prompt, disable binding |

## 5. Memory budget

| Item | Default | Hard max |
| --- | --- | --- |
| Cache entry bytes | 2 MB | 8 MB |
| Total cache bytes | 64 MB | 256 MB |
| Schema snapshots per source | last 5 | — |
| Query cache entries | bounded by byte cap | LRU eviction |

LRU eviction enforced on total byte cap.

## 6. Recovery

- Corrupt entry → delete, continue.
- Corrupt cache index → rebuild from config/snapshots.
- Unavailable source → keep last snapshot marked stale, show per-source
  status.
- Pre-migration backup copy retained (bounded count, e.g. 3).

## 7. What is NOT cached

- Secrets or credentials.
- Raw business rows beyond query result caps.
- Unbounded schema scans.

## Where to read next

- [query-engine.md](query-engine.md) — query hashing
- [database-discovery.md](database-discovery.md) — fingerprint source
- [security.md](security.md) — cache scope rules
