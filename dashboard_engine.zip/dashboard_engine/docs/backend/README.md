# Backend — Rust Core Engine

The backend is the **brain** of the system. All intelligence, security,
and data logic lives here.

## Capability map

```
┌──────────────────────────────────────────────────────┐
│                   RUST CORE ENGINE                    │
├──────────────┬───────────────┬───────────────────────┤
│  Schema      │  Query        │  UI-IR                │
│  Discovery   │  Engine       │  Generator            │
│  & Profiler  │  & Validator  │  & Validator          │
├──────────────┼───────────────┼───────────────────────┤
│  Relationship│  Caching &    │  Plugin               │
│  Analyzer    │  Fingerprint  │  Manager              │
├──────────────┼───────────────┼───────────────────────┤
│  SQLite      │  PostgreSQL   │  TimescaleDB          │
│  Local Store │  Connector    │  Connector            │
├──────────────┴───────────────┴───────────────────────┤
│            Tauri IPC Command Layer                    │
└──────────────────────────────────────────────────────┘
```

## Key responsibilities

1. **Database connection management & pooling** — PostgreSQL primary,
   TimescaleDB optional. Read-only enforcement at the adapter level.
2. **Schema introspection** — tables, views, columns, types, keys,
   constraints, indexes, JSONB profiling (bounded).
3. **Relationship detection** — explicit FKs plus inferred candidates
   with confidence/provenance.
4. **Analytics pattern recognition** — counts, sums, averages, distinct,
   grouped summaries, time series, top-N.
5. **Query validation & execution** — parameterized, bounded, cancellable,
   timeouts, pagination.
6. **UI-IR generation & validation** — versioned, closed component set.
7. **Dashboard config persistence** — SQLite store, revisions, migrations.
8. **Cache management** — schema fingerprints, invalidation, recovery.
9. **Plugin lifecycle** — manifests, loading, sandboxing (Phase 5+).
10. **Tauri IPC command handling** — typed commands/events to frontend.

## Trust model

The backend is the **only trusted component**. The frontend reflects
permissions but never enforces them. The backend never exposes credentials
in UI-IR, errors, or exports; credentials live in secret references
resolved at connect time.

## Frontend contract

Backend meets frontend through:

- [UI-IR specification](ui-ir-spec.md) — versioned JSON contract.
- [API reference](api-reference.md) — IPC commands and events.
- [Data models](data-models.md) — SQLite schemas.

## Build constraints

- Core library + CLI crate must build without GUI dependencies (Termux,
  CI).
- `src-tauri` shell crate is separate and built in CI/desktop.
- External dependencies kept few and small for phone compatibility.

## Where to read next

- [architecture.md](architecture.md) — module layout and engine internals
- [ui-ir-spec.md](ui-ir-spec.md) — the contract
- [api-reference.md](api-reference.md) — IPC surface
- [security.md](security.md) — trust boundaries
