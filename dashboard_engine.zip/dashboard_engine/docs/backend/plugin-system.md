# Plugin System

Plugin architecture for the backend. Introduced after the essential
end-to-end path is stable (Phase 5).

## 1. Design goals

- Explicit interfaces, not frequent invasive core changes.
- Capability-based: plugins declare what they need, get only that.
- Fail safely on incompatibility.
- No ambient host access implied by registration.

## 2. Plugin categories

| Category | Purpose |
| --- | --- |
| Database adapters | New source connectors beyond Postgres/Timescale |
| Schema profilers | Alternative profiling strategies |
| Relationship providers | Custom relationship inference |
| Domain analytics | Business-specific metrics (churn, MRR, etc.) |
| UI components | Extended component types (frontend registry side) |
| Auth providers | Authentication backends |
| Realtime adapters | Realtime channel implementations |

## 3. Manifest format

```jsonc
{
  "id": "com.example.timescale-adapter",
  "name": "TimescaleDB Adapter",
  "version": "1.0.0",
  "compatibility": { "engine": ">=0.5.0,<1.0.0", "bridge": "1.x" },
  "capabilities": ["db-adapter:postgres-compatible"],
  "dependencies": [],
  "config_requirements": ["host", "port", "database", "credential_ref"],
  "sandbox_level": "restricted"
}
```

## 4. Lifecycle

```
discover → load → validate → register → activate
```

- **Discover**: scan manifest + dependencies.
- **Load**: instantiate with capability handles only.
- **Validate**: compatibility ranges; fail clearly on mismatch.
- **Register**: add to internal registry; no core access beyond traits.
- **Activate**: enable capabilities; start any background loops.

Incompatible plugin → load error surfaced to diagnostics; engine still
starts.

## 5. Traits (Rust interfaces)

Reserved interfaces (implemented in Phase 5):

- `DatabaseAdapter` — connect, health, introspect, execute.
- `SchemaProfiler` — profile columns/JSONB paths.
- `RelationshipProvider` — supply relationship candidates.
- `AnalyticsProvider` — domain-specific metrics.
- `AuthProvider` — authenticate/authorize requests.
- `RealtimeAdapter` — subscribe/publish updates.

Plugins receive only the handles corresponding to declared capabilities.

## 6. Sandboxing & permissions

- No filesystem access beyond declared config paths.
- No network access except declared adapter endpoints.
- No arbitrary code execution from plugin config.
- Plugin config validated against manifest `config_requirements`.

## 7. Version compatibility

- `engine` and `bridge` semver ranges in manifest.
- Load rejects plugin outside ranges with `PLUGIN_INCOMPATIBLE`.
- Compatibility matrix published per release.

## 8. Where plugin lives

- `src-tauri/src/plugins/` — registry, loader, traits.
- Deferred until Phase 5; no plugin loading in Phases 1–4.

## Where to read next

- [architecture.md](architecture.md) — module placement
- [security.md](security.md) — sandbox boundaries
- [ROADMAP.md](../ROADMAP.md) — Phase 5 plugin timeline
