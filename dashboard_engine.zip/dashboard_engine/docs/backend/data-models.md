# Data Models

SQLite schema for local configuration and cache. Business data never
lives here.

## 1. Boundaries

| Category | Storage | Examples |
| --- | --- | --- |
| Business data | source DB only | orders, users, events |
| Dashboard definition | SQLite | identity, nav, layout, components, bindings |
| Runtime state | frontend memory | active route, filters, scroll |
| Derived metadata | SQLite (rebuildable) | snapshots, profiles, compiled IR |
| Secrets | OS keyring / env | passwords, tokens |

## 2. SQLite schema (v1)

```sql
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- dashboards
CREATE TABLE dashboards (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  description   TEXT NOT NULL DEFAULT '',
  icon_json     TEXT,
  status        TEXT NOT NULL DEFAULT 'draft', -- draft|active|archived
  current_rev   INTEGER NOT NULL DEFAULT 0,
  ir_version    TEXT,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

-- revisions (append-only)
CREATE TABLE dashboard_revisions (
  dashboard_id  TEXT NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
  revision      INTEGER NOT NULL,
  ir_json       TEXT NOT NULL,
  compiled_json TEXT,
  ir_version    TEXT NOT NULL,
  source        TEXT NOT NULL, -- user|generator|migration|import
  note          TEXT,
  created_at    TEXT NOT NULL,
  PRIMARY KEY (dashboard_id, revision)
);

-- data sources (credentials by ref only)
CREATE TABLE data_sources (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  kind          TEXT NOT NULL, -- postgres|timescale
  host          TEXT NOT NULL,
  port          INTEGER NOT NULL,
  database_name TEXT NOT NULL,
  username      TEXT NOT NULL,
  secret_ref    TEXT NOT NULL, -- keyring key, never the secret
  ssl_mode      TEXT NOT NULL DEFAULT 'require',
  options_json  TEXT NOT NULL DEFAULT '{}',
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

-- dashboard ↔ source permissions
CREATE TABLE dashboard_data_sources (
  dashboard_id    TEXT NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
  data_source_id  TEXT NOT NULL REFERENCES data_sources(id),
  permission_scope TEXT NOT NULL DEFAULT 'read',
  allowed_schemas  TEXT NOT NULL DEFAULT '["public"]',
  max_rows         INTEGER NOT NULL DEFAULT 1000,
  timeout_ms       INTEGER NOT NULL DEFAULT 15000,
  PRIMARY KEY (dashboard_id, data_source_id)
);

-- schema snapshots (immutable)
CREATE TABLE schema_snapshots (
  id             TEXT PRIMARY KEY,
  data_source_id TEXT NOT NULL REFERENCES data_sources(id) ON DELETE CASCADE,
  fingerprint    TEXT NOT NULL,
  engine_version TEXT NOT NULL,
  status         TEXT NOT NULL, -- complete|partial|stale|failed
  summary_json   TEXT NOT NULL DEFAULT '{}',
  created_at     TEXT NOT NULL
);

-- objects / columns / relationships
CREATE TABLE schema_objects (
  snapshot_id   TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
  object_id     TEXT NOT NULL,
  schema_name   TEXT NOT NULL,
  object_name   TEXT NOT NULL,
  object_type   TEXT NOT NULL,
  estimated_rows INTEGER,
  PRIMARY KEY (snapshot_id, object_id)
);

CREATE TABLE schema_columns (
  snapshot_id   TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
  object_id     TEXT NOT NULL,
  column_name   TEXT NOT NULL,
  ordinal       INTEGER NOT NULL,
  data_type     TEXT NOT NULL,
  nullable      INTEGER NOT NULL,
  is_primary_key INTEGER NOT NULL DEFAULT 0,
  is_foreign_key INTEGER NOT NULL DEFAULT 0,
  default_expr  TEXT,
  PRIMARY KEY (snapshot_id, object_id, column_name)
);

CREATE TABLE relationships (
  snapshot_id       TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
  id                TEXT NOT NULL,
  from_object_id    TEXT NOT NULL,
  from_columns_json TEXT NOT NULL,
  to_object_id      TEXT NOT NULL,
  to_columns_json   TEXT NOT NULL,
  kind              TEXT NOT NULL, -- fk|unique_inferred|name_inferred|jsonb_inferred
  confidence        REAL NOT NULL,
  provenance        TEXT NOT NULL,
  reviewed          INTEGER NOT NULL DEFAULT 0,
  accepted          INTEGER, -- NULL=unknown, 0=rejected, 1=accepted
  PRIMARY KEY (snapshot_id, id)
);

-- JSONB profiles
CREATE TABLE jsonb_profiles (
  snapshot_id   TEXT NOT NULL REFERENCES schema_snapshots(id) ON DELETE CASCADE,
  object_id     TEXT NOT NULL,
  column_name   TEXT NOT NULL,
  path          TEXT NOT NULL,
  value_type    TEXT NOT NULL,
  null_fraction REAL,
  distinct_cap  INTEGER,
  sample_json   TEXT, -- redacted/aggregated only
  PRIMARY KEY (snapshot_id, object_id, column_name, path)
);

-- workspace layout (references only)
CREATE TABLE workspace_layouts (
  id          TEXT PRIMARY KEY DEFAULT 'default',
  layout_json TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);

-- app settings
CREATE TABLE app_settings (
  key        TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- query cache
CREATE TABLE query_cache (
  cache_key   TEXT PRIMARY KEY,
  scope       TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  bytes       INTEGER NOT NULL,
  created_at  TEXT NOT NULL,
  expires_at  TEXT
);

-- migrations
CREATE TABLE schema_migrations (
  version    INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL
);

-- audit log
CREATE TABLE audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  at         TEXT NOT NULL,
  actor      TEXT,
  action     TEXT NOT NULL,
  subject    TEXT,
  outcome    TEXT NOT NULL,
  detail_json TEXT -- sanitized
);
```

## 3. Key invariants

- `dashboards.current_rev` points to existing revision.
- Revisions append-only; edits create new revision.
- `compiled_json` derivable from `ir_json`; droppable/rebuildable.
- Snapshots immutable; new discovery = new snapshot.
- Cache rows always deletable.
- `secret_ref` is a pointer only.
- `query_cache.scope` must match requesting scope.

## 4. Migration policy

- Forward-only migrations, transactional, tested from previous fixtures.
- Pre-migration backup copy (bounded retention).
- No destructive change without config export backup.
- Failure → DB stays at last good version; recovery mode (read-only
  export).

## 5. Config export/import

Portable JSON bundle:

```jsonc
{
  "format": "dde.config",
  "version": 1,
  "exportedAt": "...",
  "dashboards": [{ "id": "...", "revisions": [{ "revision": 3, "ir": { ... } }] }],
  "dataSources": [{ "id": "...", "secretRef": "..." }],
  "settings": { ... }
}
```

Import validates every IR before writing. Missing secrets reported as
user actions, not silently defaulted.

## 6. Cache keys & invalidation

```
queryKey = H(dataSourceId, schemaFingerprint, queryIntentHash,
             normalizedParamsHash, permissionScope, rowLimit,
             engineQueryVersion)
```

Invalidate on fingerprint change, permission change, TTL, manual
refresh, drift event. Byte cap + LRU enforced. Never across scopes.

## 7. Size discipline

| Item | Cap |
| --- | --- |
| Cached result payload | 2 MB entry / 64 MB total |
| Schema snapshots | last 5 per source |
| Audit log | 10k rows, rotate |
| JSONB samples | aggregated only |

Large results paginated/aggregated, never mirrored locally.
