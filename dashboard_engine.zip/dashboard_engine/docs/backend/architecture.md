# Backend Architecture

Detailed Rust module architecture for the core engine.

## Module diagram

```mermaid
flowchart TD
    A["Tauri IPC Commands"] --> B["Core Engine Orchestrator"]
    B --> C["Schema Discovery"]
    B --> D["Query Engine"]
    B --> E["UI-IR Generator"]
    B --> F["Dashboard Manager"]
    
    C --> G["PostgreSQL Adapter"]
    C --> H["TimescaleDB Adapter"]
    C --> I["JSONB Profiler"]
    
    D --> J["Query Validator"]
    D --> K["Query Executor"]
    D --> L["Result Transformer"]
    
    E --> M["Page Generator"]
    E --> N["Component Mapper"]
    E --> O["Layout Planner"]
    
    F --> P["SQLite Store"]
    F --> Q["Config Migrator"]
    
    B --> R["Cache Manager"]
    B --> S["Plugin Registry"]
```

## Crate structure

```
src-tauri/
├── Cargo.toml
├── src/
│   ├── main.rs                    # Tauri app entry
│   ├── lib.rs                     # Engine public API
│   ├── commands/                  # Tauri IPC command handlers
│   │   ├── mod.rs
│   │   ├── dashboard.rs           # CRUD dashboard commands
│   │   ├── discovery.rs           # Schema discovery commands
│   │   ├── query.rs               # Query execution commands
│   │   └── workspace.rs           # Workspace layout commands
│   ├── engine/                    # Core engine logic
│   │   ├── mod.rs
│   │   ├── orchestrator.rs        # Main coordination logic
│   │   └── config.rs              # Engine configuration
│   ├── discovery/                 # Schema discovery
│   │   ├── mod.rs
│   │   ├── postgres.rs            # PostgreSQL introspection
│   │   ├── timescale.rs           # TimescaleDB extensions
│   │   ├── jsonb.rs               # JSONB profiling
│   │   ├── relationships.rs       # FK + inferred relationships
│   │   └── types.rs               # Discovery data types
│   ├── query/                     # Query system
│   │   ├── mod.rs
│   │   ├── builder.rs             # Safe query construction
│   │   ├── validator.rs           # Permission & safety checks
│   │   ├── executor.rs            # Query execution & pooling
│   │   └── types.rs               # Query data types
│   ├── uiir/                      # UI Intermediate Representation
│   │   ├── mod.rs
│   │   ├── schema.rs              # UI-IR type definitions
│   │   ├── generator.rs           # Generate UI-IR from metadata
│   │   ├── validator.rs           # Validate UI-IR integrity
│   │   └── migrator.rs            # UI-IR version migration
│   ├── storage/                   # Local persistence
│   │   ├── mod.rs
│   │   ├── sqlite.rs              # SQLite operations
│   │   ├── migrations.rs          # Schema migrations
│   │   └── models.rs              # Data models
│   ├── cache/                     # Caching system
│   │   ├── mod.rs
│   │   ├── manager.rs             # Cache lifecycle
│   │   └── fingerprint.rs         # Schema fingerprinting
│   ├── plugins/                   # Plugin system
│   │   ├── mod.rs
│   │   ├── registry.rs            # Plugin registration
│   │   ├── loader.rs              # Plugin loading
│   │   └── traits.rs              # Plugin interfaces
│   └── security/                  # Security & auth
│       ├── mod.rs
│       ├── permissions.rs         # Permission model
│       └── credentials.rs         # Secret management
```

## Core pipeline

```
resolve connection
  -> authorize (dashboard context)
  -> discover (cached by fingerprint)
  -> plan (analytics intent -> logical query)
  -> validate (allowlist, types, limits, read-only)
  -> compile (parameterized SQL, per adapter)
  -> execute (timeout, row cap, cancellation)
  -> shape (columns, types, truncation, cache key)
```

Cross-cutting concerns:

- **Config store**: versioned migrations, revisions, rollback of drafts.
- **Cache**: keyed by `(sourceId, fingerprint, queryHash, paramsHash,
  permissionScope)` plus TTL; never used to bypass auth.
- **Errors**: typed codes with safe messages; details separated from
  sensitive values.
- **Observability**: timing per stage, cache hit/miss, query counts; no
  secrets or row values in logs.

## Build constraints

- `core` crate must build without async DB drivers (for phone/CLI use).
- `src-tauri` links the full core with async adapters for desktop builds.
- CLI entrypoint provided for Termux/CI verification without GUI deps.

## Where to read next

- [ui-ir-spec.md](ui-ir-spec.md) — contract shape
- [query-engine.md](query-engine.md) — query pipeline details
- [database-discovery.md](database-discovery.md) — discovery internals
- [security.md](security.md) — trust boundaries
