# UI-IR Specification

The UI Intermediate Representation (UI-IR) is the versioned, validated
contract between the Rust backend and the Next.js frontend.

## 1. Principles

1. **Versioned**: every document carries `version` (semantic). Unknown
   newer versions are rejected, not guessed.
2. **Validated twice**: backend validates before saving; frontend
   validates before rendering.
3. **Declarative**: describes what to show, never how to execute code.
4. **Closed set**: component types and actions from a fixed registry.
5. **Migratable**: version N → N+1 migrations explicit, tested, lossless
   or fail loudly.
6. **Bounded**: every growable list has a documented cap.

## 2. UI-IR 1.0.0 document

```json
{
  "version": "1.0.0",
  "dashboard": {
    "id": "dash_01H...",
    "name": "E-Commerce",
    "description": "Orders and catalog overview",
    "icon": { "kind": "emoji", "value": "🛒" },
    "theme": { "mode": "system", "primary": "#3B82F6" },
    "navigation": {
      "style": "sidebar",
      "groups": [
        {
          "id": "grp_catalog",
          "label": "Catalog",
          "items": [
            { "id": "nav_products", "label": "Products", "routeId": "rt_products", "icon": "box" },
            { "id": "nav_orders", "label": "Orders", "routeId": "rt_orders", "icon": "receipt" }
          ]
        }
      ],
      "footer": [{ "id": "nav_settings", "label": "Settings", "routeId": "rt_settings" }]
    },
    "routes": [
      { "id": "rt_orders", "path": "/orders", "pageId": "pg_orders", "title": "Orders" },
      { "id": "rt_products", "path": "/products", "pageId": "pg_products", "title": "Products" }
    ],
    "pages": [
      {
        "id": "pg_orders",
        "title": "Orders",
        "layout": {
          "kind": "grid",
          "columns": 12,
          "rows": [
            { "id": "row_metrics", "height": "auto", "items": [
              { "componentId": "cmp_revenue", "span": 3 },
              { "componentId": "cmp_orders", "span": 3 },
              { "componentId": "cmp_aov", "span": 3 },
              { "componentId": "cmp_returns", "span": 3 }
            ]},
            { "id": "row_table", "height": "fill", "items": [
              { "componentId": "cmp_orders_table", "span": 12 }
            ]}
          ]
        }
      }
    ],
    "components": [
      {
        "id": "cmp_revenue",
        "type": "metric-card",
        "title": "Revenue",
        "bindingId": "bnd_revenue",
        "format": "currency",
        "props": { "trend": "none" },
        "gridArea": { "col": "1/4", "row": "1/2" }
      },
      {
        "id": "cmp_orders_table",
        "type": "data-table",
        "title": "Recent orders",
        "bindingId": "bnd_orders",
        "props": {
          "pageSize": 25,
          "columns": [
            { "key": "order_id", "label": "Order", "sortable": true },
            { "key": "customer", "label": "Customer", "sortable": true },
            { "key": "total", "label": "Total", "align": "end", "format": "currency" },
            { "key": "status", "label": "Status" }
          ],
          "filters": ["status", "created_at"],
          "selectable": true
        }
      }
    ],
    "bindings": [
      { "id": "bnd_revenue", "queryId": "q_revenue", "resultShape": "scalar", "refresh": { "mode": "manual", "staleAfterSec": 60 } },
      { "id": "bnd_orders", "queryId": "q_orders", "resultShape": "rows", "refresh": { "mode": "manual", "staleAfterSec": 30 } }
    ],
    "queries": [
      {
        "id": "q_orders",
        "intent": {
          "kind": "select",
          "sourceId": "obj_public_orders",
          "fields": ["order_id", "customer", "total", "status", "created_at"],
          "orderBy": [{ "field": "created_at", "direction": "desc" }],
          "limit": 100
        },
        "params": [],
        "cacheable": true
      }
    ],
    "permissions": { "hide": ["nav_settings"], "readOnly": true, "scopes": ["analytics:read"] },
    "fallbacks": { "unknownComponent": "placeholder-card", "missingBinding": "empty-state" }
}
```

## 3. Closed vocabularies (v1.0.0)

| Field | Allowed values |
| --- | --- |
| `component.type` | `metric-card`, `data-table`, `chart.line`, `chart.bar`, `chart.pie`, `list`, `detail`, `form.readonly`, `filters`, `section`, `placeholder-card` |
| `resultShape` | `scalar`, `rows`, `series`, `distribution`, `none` |
| `intent.kind` | `select`, `aggregate`, `grouped`, `timeseries`, `distribution`, `top_n` |
| `format` | `text`, `number`, `currency`, `percent`, `date`, `datetime`, `relative` |
| `alignment` | `start`, `center`, `end` |
| `refresh.mode` | `manual`, `on_mount`, `interval` (interval capped) |
| `theme.mode` | `light`, `dark`, `system` |
| `row.height` | `auto`, `fill`, `<px>px` |

## 4. Validation rules

- `version` present and compatible.
- All ids unique within collection; references resolve (route → page,
  nav → route, component → binding → query).
- Every route points to existing page; every nav item to existing route.
- Component `type` in registry; `bindingId` resolves.
- Query `sourceId` exists in current snapshot.
- Field names exist in that source's columns.
- Layout spans fit grid; page has at least one component or explicit
  empty state.
- `limit` / `pageSize` ≤ configured max.
- No `additionalProperties`; no executable strings; no HTML/CSS blobs.
- All text rendered as text.

Invalid documents: **do not render, do not execute**. Structured
validation report returned instead.

## 5. Versioning & migration

- Additive optional fields allowed in minor version only if old clients
  can ignore safely.
- Removing/renaming/retyping requires major version bump + migration.
- Persisted UI-IR stored as written plus compiled form.
- Migration on read, written back as new revision after user confirmation
  (or automatically if lossless).
- Frontend refuses versions it cannot render.

## 6. Error codes

| Code | Meaning |
| --- | --- |
| `IR_INVALID_VERSION` | version unsupported |
| `IR_UNKNOWN_COMPONENT` | type not in registry |
| `IR_DANGLING_REFERENCE` | binding/route/page unresolved |
| `IR_INVALID_LAYOUT` | spans exceed grid |
| `IR_QUERY_INVALID` | intent fails validation |
| `IR_OVER_LIMIT` | limit/pageSize exceeds cap |

## Where to read next

- [query-engine.md](query-engine.md) — intent model backend compiles
- [api-reference.md](api-reference.md) — IPC surface for UI-IR
- [frontend/dashboard-renderer.md](../frontend/dashboard-renderer.md) — how frontend renders UI-IR
