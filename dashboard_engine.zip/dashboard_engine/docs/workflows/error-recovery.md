# Error Recovery

Failure scenario catalog. Every scenario lists symptoms, root cause,
recovery steps, and prevention.

## 1. Unavailable database

| Symptom | dashboard shows disconnected badge; queries fail |
| --- | --- |
| Cause | network, DB down, wrong host/port |
| Recovery | retry connection; show per-source status; keep last snapshot marked stale |
| Prevention | read-only role, connection timeout, health checks |

## 2. Expired credentials

| Symptom | `DS_AUTH_FAILED` on connect/query |
| --- | --- |
| Cause | rotated password/token |
| Recovery | update secret ref in keyring/env; test source; dashboards unaffected |
| Prevention | secret rotation process; no credentials in config |

## 3. Invalid UI-IR

| Symptom | dashboard blocked; diagnostics show error code + path |
| --- | --- |
| Cause | unknown component, dangling binding, over-limit |
| Recovery | fix via editor/validation report; fallback renders other dashboards |
| Prevention | client + server validation; closed registry |

## 4. Corrupted local cache

| Symptom | stale/wrong data or cache read errors |
| --- | --- |
| Cause | disk write interruption, concurrent corruption |
| Recovery | delete corrupt entry/index; rebuild from config/snapshots; config intact |
| Prevention | byte caps, LRU, atomic writes, pre-migration backups |

## 5. Plugin incompatibility

| Symptom | `PLUGIN_INCOMPATIBLE`; plugin disabled |
| --- | --- |
| Cause | manifest version outside engine range |
| Recovery | engine starts without plugin; update or remove plugin |
| Prevention | compatibility matrix; load-time validation |

## 6. Query timeout / cancellation

| Symptom | `QUERY_TIMEOUT` / `QUERY_CANCELLED` for one binding |
| --- | --- |
| Cause | heavy query, panel closed, statement timeout |
| Recovery | retry with lower limit; panel stays usable; other panels unaffected |
| Prevention | row caps, timeouts, cancellation tokens |

## 7. Schema drift (breaking)

| Symptom | `schema:drift` event; bindings invalidated |
| --- | --- |
| Cause | dropped/renamed column, type change |
| Recovery | review surface; merge/replace apply; revision note |
| Prevention | fingerprint comparison; user confirmation before apply |

## 8. Config conflict

| Symptom | `CONFIG_CONFLICT` on save |
| --- | --- |
| Cause | two edits from stale revision |
| Recovery | merge/choose dialog; no silent overwrite |
| Prevention | `baseRevision` optimistic concurrency |

## 9. Panel component crash

| Symptom | one panel's component errors; rest of page OK |
| --- | --- |
| Cause | component bug, bad data shape |
| Recovery | slot-level error boundary; other panels unaffected |
| Prevention | fallback components, per-slot boundaries |

## 10. Multi-panel state leakage

| Symptom | action in panel 1 changes panel 2 |
| --- | --- |
| Cause | shared store / global state bug |
| Recovery | per-panel store factory; isolation test suite |
| Prevention | explicit isolation rules; test matrix |

## 11. Audit & diagnostics

- All failures emit typed error codes (never raw SQL/params/secrets).
- Diagnostics endpoint shows versions, health, cache stats (sanitized).
- "Copy sanitized report" action for support.

## Where to read next

- [backend/security.md](../backend/security.md) — error model
- [backend/caching-strategy.md](../backend/caching-strategy.md) — cache recovery
- [workflows/dashboard-lifecycle.md](dashboard-lifecycle.md) — failure handling per stage
