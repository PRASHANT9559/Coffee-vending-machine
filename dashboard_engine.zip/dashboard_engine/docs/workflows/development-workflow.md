# Development Workflow

How changes are made: slices, branches, verification, and Termux notes.

## 1. Ground rules

1. **One slice at a time** — small end-to-end behavior, not a layer.
2. **Contract first** — UI-IR/IPC changes update spec + fixtures before
   code.
3. **Verify before claiming** — state what ran; untested paths are
   limitations.
4. **No secrets in the repo** — ever.
5. **No big dependencies without a note** — especially on phone.
6. **Do not break saved dashboards** — migrations or explicit rejection.

## 2. Slice template

```
Slice: <one sentence behavior>
Part: A | B | S
Touches: <files/modules>
Contract change: yes/no (+ version)
Acceptance:
  - <observable behavior>
Verification:
  - <command/test/manual step>
Limitations:
  - <what is not supported>
```

## 3. Branches & commits

- Default: `main` (always buildable).
- Branches: `fe/<slice>`, `be/<slice>`, `contract/<slice>`, `docs/<topic>`.
- Rebase on `main` before review.
- Commit style: `feat(fe/hub): add dashboard card grid`.

## 4. Definition of Done (per slice)

- [ ] Acceptance behaviors observable.
- [ ] Tests added and passing (local or CI — state which).
- [ ] Contract fixtures updated if contract changed.
- [ ] Error paths return typed codes.
- [ ] Limits/timeouts considered for anything that grows.
- [ ] No secret/row logging.
- [ ] Docs updated when behavior/limits changed.
- [ ] Limitations recorded honestly.

## 5. Build commands

Frontend (phone-compatible):

```bash
cd frontend
npm install --no-audit --no-fund
NEXT_TELEMETRY_DISABLED=1 npm run dev       # http://127.0.0.1:3000
npm run build                                # static export
```

Backend core/CLI (if Rust available):

```bash
cd backend
cargo fmt --check
cargo clippy -- -D warnings
cargo test --workspace
cargo run -p dde-cli -- ping
```

Tauri desktop builds: CI or desktop only — **not** on Termux.

## 6. Testing minimum

| Change | Verification |
| --- | --- |
| Docs only | link check |
| Contract | schema validation + fixtures + types |
| Backend logic | unit + one integration test |
| SQL/executor | denial + timeout tests |
| Frontend component | render + fallback test |
| Workspace | isolation test |
| Migration | upgrade from previous fixture |

Full matrix: [references/testing-strategy.md](../references/testing-strategy.md).

## 7. Honest reporting template

```
Verified locally (Termux, <device>):
  - npm run typecheck   PASS
  - cargo test          NOT RUN (rust unavailable)

Verified in CI:
  - cargo test --workspace PASS

Not verified:
  - Windows build

Known limitations:
  - JSONB depth capped at 3
```

## 8. Termux-specific setup

Use Termux home (`~`), not Android shared storage, for tooling:

```bash
mkdir -p ~/dashboard_engine
# copy project here
pkg install nodejs-lts git sqlite python
# optional: pkg install rust
```

Full guide: [references/termux-dev-guide.md](../references/termux-dev-guide.md).

## 9. Anti-patterns

- Building an entire layer before any vertical slice works.
- Direct SQL in the frontend.
- Global state for per-dashboard concerns.
- Auto-applying generated changes over user edits.
- Silent schema regeneration.
- Claiming a test passed without running it.

## Where to read next

- [ROADMAP.md](../ROADMAP.md) — phase sequencing
- [backend/README.md](../backend/README.md) — backend ownership
- [frontend/README.md](../frontend/README.md) — frontend ownership
