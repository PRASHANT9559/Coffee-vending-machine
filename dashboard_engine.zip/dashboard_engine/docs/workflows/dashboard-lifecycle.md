# Dashboard Lifecycle

End-to-end lifecycle of a dashboard resource, from creation to update.

## Stages

```mermaid
flowchart LR
    A["Create"] --> B["Configure"]
    B --> C["Discover Schema"]
    C --> D["Generate UI-IR"]
    D --> E["Review & Customize"]
    E --> F["Save"]
    F --> G["Reopen & Use"]
    G --> H["Update on Schema Change"]
    H --> E
```

## Stage details

### 1. Create

- **Actor:** User
- **Input:** Name, description, icon, data source reference.
- **Output:** Dashboard draft in SQLite (status: `draft`), revision 1.
- **Failure:** Invalid identity → form error; conflict → duplicate name check.

### 2. Configure

- **Actor:** User
- **Input:** Navigation, sidebar, theme, layout, access controls, allowed schemas/objects.
- **Output:** Updated config revision.
- **Failure:** Validation errors on allowlist/limits shown inline.

### 3. Discover

- **Actor:** Engine (backend)
- **Input:** Data source connection.
- **Output:** Immutable schema snapshot + fingerprint; relationship candidates with confidence.
- **Failure:** Unreachable/auth-failed → per-source disconnected state, retry offered.

### 4. Generate

- **Actor:** Engine (backend) + User review
- **Input:** Snapshot, accepted relationships, generation mode.
- **Output:** UI-IR draft + validation report (not auto-applied).
- **Modes:** automatic / configured / hybrid (preferred).

### 5. Review & Customize

- **Actor:** User
- **Input:** Generated draft.
- **Output:** Accepted / removed / rearranged elements; assumptions edited.
- **Failure:** Invalid customizations blocked with stable codes.

### 6. Save

- **Actor:** User
- **Input:** Final UI-IR.
- **Output:** New revision with `baseRevision` conflict guard.
- **Failure:** Stale revision → `CONFIG_CONFLICT`, user chooses merge/overwrite.

### 7. Reopen & Use

- **Actor:** User
- **Input:** Dashboard id.
- **Output:** UI-IR loaded into workspace panel; queries execute bounded.
- **Failure:** Migration needed → version error; offered migration path.

### 8. Update on Schema Change

- **Actor:** Engine detects drift; User decides.
- **Input:** New fingerprint vs stored snapshot.
- **Output:** Drift event → review surface → regeneration (merge/replace).
- **Failure:** Breaking change → affected bindings disabled, not silently regenerated.

## Failure handling per stage

| Stage | Failure | User-visible outcome |
| --- | --- | --- |
| Create | duplicate name | inline error, retry |
| Configure | invalid allowlist | inline error |
| Discover | DB unreachable | disconnected badge, retry |
| Generate | unsupported schema | skipped items with reasons |
| Save | conflict | merge/choose dialog |
| Reopen | version mismatch | migration prompt |
| Update | breaking drift | review before apply |

## Where to read next

- [schema-change-workflow.md](schema-change-workflow.md) — drift handling
- [backend/data-models.md](../backend/data-models.md) — revisions table
- [backend/ui-ir-spec.md](../backend/ui-ir-spec.md) — UI-IR versioning
