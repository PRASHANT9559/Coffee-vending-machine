# Schema Change Workflow

How the engine detects, classifies, and handles changes to the database
schema after a dashboard has been saved.

## 1. Detection

Each dashboard references a schema snapshot by id + fingerprint. On
discovery refresh (user-triggered or scheduled within bounds), the
engine recomputes the fingerprint and compares:

- Same fingerprint → **unchanged**, no action.
- Different fingerprint → drift event `schema:drift` emitted with change
  summary.

## 2. Classification

| Class | Example | Automatic? | User action |
| --- | --- | --- | --- |
| Unchanged | identical fingerprint | yes | none |
| Additive | new table/column | suggest only | accept/reject |
| Breaking | dropped referenced column | no | review & fix |
| Renamed (heuristic) | drop + add similarity | no | mapping prompt |
| Type change (incompatible) | text → binary | no | disable binding |
| Table dropped | source table gone | no | placeholder page |

Never silently regenerate or destroy user customization.

## 3. Review flow

1. Drift event surfaces in affected panel + diagnostics.
2. User opens review screen showing diff summary + affected bindings.
3. For additive: suggested additions listed; user accepts.
4. For breaking: affected components marked invalid; user maps to new
   columns or removes.
5. User confirms apply → new revision with `source: migration`.

## 4. Regeneration policy

- **Merge (default):** preserve pinned/renamed/customized elements; add
  proposals in free slots.
- **Replace:** only with explicit confirmation; discards customization.
- Every apply creates a revision note describing the drift.

## 5. Edge cases

| Scenario | Handling |
| --- | --- |
| Discovery times out | keep last snapshot marked `stale` |
| Partial snapshot | marked `partial`; generation warns |
| Source unreachable | per-source disconnected state |
| Credential expired | auth error; refresh credentials |
| Cache corrupt | drop cache, rebuild from snapshot |

## 6. Tests required

- Add column → suggestions appear, no breakage.
- Drop referenced column → bindings invalid, review prompt.
- Rename column → mapping prompt, no silent rebind.
- Type change → affected components disabled.
- Drop table → placeholder page, config intact.

## Where to read next

- [dashboard-lifecycle.md](dashboard-lifecycle.md) — lifecycle stage 8
- [backend/database-discovery.md](../backend/database-discovery.md) — fingerprints
- [backend/caching-strategy.md](../backend/caching-strategy.md) — invalidation
