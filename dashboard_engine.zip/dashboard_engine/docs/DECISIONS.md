# Decisions and Open Questions

Architecture Decision Records (ADRs) in lightweight form. Status values:
`accepted`, `proposed`, `deferred`, `rejected`.

---

## Accepted ADRs

### ADR-001 — Split the product into frontend and backend with a written contract

**Status:** accepted

**Context:** The source spec separates configuration, data intelligence, UI
rendering, and workspace management. On a phone, backend and frontend have
very different toolchain constraints.

**Decision:** Two parts (A frontend, B backend) that communicate only
through versioned UI-IR and typed commands/events.

**Consequences:** Parallel work; contract changes cost more; no SQL in the
UI; the renderer can be developed against fixtures.

---

### ADR-002 — UI-IR is the single source of truth for rendered UI

**Status:** accepted

**Context:** Users must be able to save, reopen, migrate, and edit generated
dashboards.

**Decision:** Persist UI-IR JSON (versioned). Frontend renders it through a
closed component registry. Backend generates and validates it.

**Consequences:** No ad-hoc page code per project; every new UI capability
needs a registry entry + schema update; persisted documents require
migrations.

---

### ADR-003 — Rust core owns SQLite and all database access

**Status:** accepted

**Context:** Security boundary and consistency.

**Decision:** The frontend never opens SQLite or PostgreSQL. All config,
metadata, and queries go through the core.

**Consequences:** Frontend is simpler and safer; core must expose enough
read models for the hub/workspace; IPC payloads need review.

---

### ADR-004 — Desktop build uses static Next.js export inside Tauri 2

**Status:** accepted

**Context:** Tauri needs renderer assets; SSR requires a Node sidecar.

**Decision:** Use `output: "export"` for the desktop bundle. Avoid runtime
Node-only Next.js features unless a sidecar is explicitly chosen.

**Consequences:** No route handlers/ISR in the desktop build; data always
comes from the Rust bridge; dev mode can still use `next dev`.

---

### ADR-005 — Rust/Tauri verification is CI-first, not phone-first

**Status:** accepted (environment-driven)

**Context:** Termux/PRoot has no reliable GTK/WebKit/display stack; Rust
toolchain may be too heavy.

**Decision:** The Rust core is structured as a library + CLI that can be
tested without the desktop shell. Tauri packaging runs in CI or on a
desktop. Phone work focuses on frontend and contract/docs.

**Consequences:** Local backend feedback is slower; slices must state where
they were verified; CI setup is required early, not late.

---

### ADR-006 — Dashboard configuration and workspace arrangement are separate records

**Status:** accepted

**Context:** User explicitly requires independence and stable behavior.

**Decision:** `dashboards` / `dashboard_revisions` store definitions;
`workspace_layouts` stores only panel references, ratios, and active id.

**Consequences:** Resizing never dirties a dashboard; deleting a dashboard
must degrade the layout to a placeholder; no duplicated config.

---

### ADR-007 — Per-panel runtime state, no global navigation store

**Status:** accepted

**Context:** Multi-dashboard is a core invariant.

**Decision:** Each panel owns its route stack, filters, selection,
pagination, scroll, request state, and unsaved flag. Global state is limited
to app shell concerns.

**Consequences:** Slightly more plumbing; isolation is testable; no
accidental cross-panel changes.

---

### ADR-008 — Generation is hybrid by default and never auto-applies over edits

**Status:** accepted

**Context:** Schema does not prove business meaning.

**Decision:** Produce a draft with confidence/provenance; require explicit
apply with merge/replace; record a revision.

**Consequences:** Safer UX; more UI work (review screen); regeneration
policy must preserve customization.

---

### ADR-009 — Read-only analytics only in the initial product

**Status:** accepted

**Context:** Writes require conflict, validation, and audit design.

**Decision:** No INSERT/UPDATE/DELETE/DDL from dashboards in v1.

**Consequences:** Simpler security model; some use cases deferred.

---

### ADR-010 — No plugin system before the end-to-end path is stable

**Status:** accepted

**Context:** Premature generalization risk named in the spec.

**Decision:** Define interfaces only when a second real implementation
exists. First plugin candidate: an additional database adapter.

**Consequences:** Some duplication early; lower complexity; plugin manifest
design deferred.

---

### ADR-011 — Secrets live outside the config database

**Status:** accepted

**Decision:** Store `secret_ref` only; resolve via OS keyring or environment.
Dev-only restricted file fallback is documented.

**Consequences:** Export/import must handle missing secrets explicitly.

---

### ADR-012 — Bounded everything

**Status:** accepted

**Decision:** Every discovery, profile, query, cache entry, array, and
background task has an explicit limit and a cancellation path.

**Consequences:** Some large datasets require aggregation/pagination;
limits are configurable but capped.

---

### ADR-013 — Phones are for authoring, CI is for platform verification

**Status:** accepted

**Decision:** Do not block progress on building desktop artifacts on the
phone; record unverified paths.

**Consequences:** Requires CI from milestone M0/M1; honesty in reporting.

---

### ADR-014 — JSONB profiling is bounded and never exposes raw samples

**Status:** accepted

**Context:** JSONB columns may contain sensitive keys (email, token, PII).

**Decision:** Profiling enumerates key paths up to depth 3, records value
types and null fractions only, and never returns raw sample values.
Sensitive-looking columns (by deny list) are profiled only for null /
cardinality.

**Consequences:** JSONB metadata components (`cmp_metadata_keys`,
`cmp_metadata_types`) work from aggregated stats; no data leakage.

---

### ADR-015 — Schema drift is additive / breaking / unchanged, never silent

**Status:** accepted

**Decision:** Fingerprint comparison classifies drift. Additive changes are
suggested, breaking changes require user review, and regeneration never
destroys customization without explicit confirmation.

**Consequences:** Drift review UI in frontend; fingerprint logic in
backend `discovery/postgres.rs`.

---

## Closed Open Questions

| # | Question | Decision | Status |
| --- | --- | --- | --- |
| Q1 | Database priority | PostgreSQL only in Phases 1–5; TimescaleDB in Phase 6 | **Closed** |
| Q2 | Auth strategy | Local-only, no login for desktop MVP; per-dashboard permission scopes still enforced | **Closed** |
| Q3 | Plugin system | Documented now, implemented in Phase 5; no executable plugin loading earlier | **Closed** |
| Q4 | Remote service | Design note in Phase 6, implementation optional | **Closed** |
| Q5 | Chart library | Custom SVG for v1 metrics/lines/bar/pie; decide on Recharts/ECharts at M3 | **Closed** |
| Q6 | JSONB profiling depth | 3 levels, bounded samples, no raw values | **Closed** |
| Q7 | Relationship auto-accept threshold | Never auto-authoritative; suggest only | **Closed** |
| Q8 | Workspace restore strictness | Restore with placeholders, notify on missing dashboard | **Closed** |
| Q9 | Theme customization depth | Tokens only in v1 | **Closed** |
| Q10 | Multi-user local profiles | None in v1 | **Closed** |
| Q11 | TimescaleDB support depth | Hypertable + continuous aggregate metadata in M2/M6 | **Closed** |
| Q12 | i18n | English only, keep strings centralized | **Closed** |

All 12 open questions from the implementation plan are now closed.

---

## Rejected (for the record)

| Idea | Why rejected |
| --- | --- |
| Arbitrary JS in dashboard config | violates "configuration never executes code" |
| Shared global store for all panels | breaks isolation invariant |
| Auto-accepting inferred relationships as real FKs | spec forbids silently becoming authoritative |
| Mirroring business tables into SQLite for speed | violates data boundary and privacy |
| Building plugin host in v1 | premature; core path not stable |
| Mobile-first layout work | out of initial scope |
