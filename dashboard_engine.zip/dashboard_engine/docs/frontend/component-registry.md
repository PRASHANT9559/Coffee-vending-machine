# Component Registry

The component registry is the closed set of trusted UI components the
renderer uses to turn UI-IR into React output.

## Registry pattern

Component type string → React component with validated props:

```ts
type RegistryEntry<P> = {
  type: string;
  version: number;
  resultShape: 'scalar' | 'rows' | 'series' | 'distribution' | 'none';
  validateProps(props: unknown): P;
  Component: React.ComponentType<RenderProps<P>>;
  fallback?: React.ComponentType<{ reason: string }>;
  maxProps?: Record<string, number>;
};

type RenderProps<P> = {
  id: string;
  title?: string;
  props: P;
  data: QueryResult | null;
  status: 'idle' | 'loading' | 'ok' | 'error' | 'stale';
  error?: { code: string; message: string };
  permissions: { readOnly: boolean; hidden: string[] };
};
```

Rules:

- **Closed**: no config-driven imports, no `eval`, no remote components.
- Props validated per type; unknown props rejected at IR validation.
- Every component handles loading, empty, error, stale, no-data.
- Components never fetch directly; data arrives via bindings.

## v1 component table

| Type | Shape | Key props | Notes |
| --- | --- | --- | --- |
| `metric-card` | scalar | `format`, `trend`, `comparison` | single value + label |
| `data-table` | rows | `columns[]`, `pageSize`, `sortable`, `filters[]`, `selectable` | server page/sort |
| `list` | rows | `primaryKey`, `secondaryKey`, `maxItems` | compact lists |
| `detail` | rows (1) | `fields[]`, `layout` | read-only record view |
| `chart.line` | series | `x`, `y`, `seriesKey?`, `maxPoints` | downsample |
| `chart.bar` | rows/series | `category`, `value`, `maxBars` | horizontal option |
| `chart.pie` | distribution | `category`, `value` | small multiples |
| `filters` | none | `fields[]` | emits param changes |
| `section` | none | `title`, `collapsible` | grouping |
| `placeholder-card` | none | `reason` | unknown/missing fallback |

New types require: registry entry, schema enum update, fixture, render
test, docs update, version bump if persisted meaning changes.

## Fallbacks

- Unknown component type → `placeholder-card` + diagnostic entry.
- Missing binding → empty state in the slot.
- Component crash → slot-level error boundary; rest of page renders.

## Where to read next

- [dashboard-renderer.md](dashboard-renderer.md) — how components load
- [backend/ui-ir-spec.md](../backend/ui-ir-spec.md) — component type vocabulary
- [forms-and-filters.md](forms-and-filters.md) — filter component details
