# Forms & Filters

Filter bar, search, and form system for dashboard interaction.

## Filter bar

Filter types supported (v1):

- Text search
- Select (single/multi)
- Date range
- Numeric range
- Boolean

Filter state is per-dashboard instance (panel state). Filters map to
declared query params only; a filter that cannot be expressed as a
declared param is not offered.

## Forms

Read-only forms in v1 (no writes). Future phases may add data entry
forms with validation.

## Validation & errors

- Field validation messages shown inline.
- Component-level errors render as inline states, not global alerts.
- Filter changes debounced where appropriate.

## Where to read next

- [dashboard-renderer.md](dashboard-renderer.md) — filter binding to query
- [component-registry.md](component-registry.md) — filter component
- [state-management.md](state-management.md) — filter state per panel
