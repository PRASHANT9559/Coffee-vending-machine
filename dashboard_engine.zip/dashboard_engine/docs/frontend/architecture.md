# Frontend Architecture

Next.js app architecture for the desktop-first renderer.

## Build model

Desktop target uses **static export** (`output: "export"`), bundled inside
the Tauri 2 shell. No server-side rendering, no route handlers, no ISR,
no middleware requiring a Node runtime. Dev mode (`next dev`) is used on
the phone for iteration.

## Folder structure

```
src/
├── app/                           # Next.js App Router
│   ├── layout.tsx                 # root layout + providers
│   ├── page.tsx                   # redirect to hub
│   ├── hub/
│   │   ├── page.tsx               # Dashboard Hub
│   │   └── create/
│   │       └── page.tsx           # create wizard
│   └── workspace/
│       └── page.tsx               # multi-panel workspace
│
├── components/
│   ├── hub/                       # DashboardCard, Grid, CreateWizard, Search
│   ├── workspace/                 # WorkspaceContainer, PanelManager, Panel, Resizer, Presets
│   ├── dashboard/                 # DashboardShell, Sidebar, TopBar, PageRenderer
│   ├── registry/                  # MetricCard, DataTable, Chart, FilterBar, Fallback
│   └── ui/                        # Button, Card, Input, Modal, ...
│
├── lib/
│   ├── tauri/                     # IPC bridge: commands.ts, types.ts
│   ├── store/                     # hub-store, workspace-store, dashboard-store factory
│   ├── uiir/                      # renderer.ts, validator.ts, types.ts
│   └── theme/                     # provider.tsx, tokens.ts, presets.ts
│
└── styles/
    └── globals.css                # Tailwind base + custom
```

## Providers

Root layout composes:

- **ThemeProvider** — light/dark/system, density, tokens.
- **BridgeProvider** — typed IPC client (mock in dev, real in Tauri).
- **HubStoreProvider** — dashboard list, search, selected id.
- **WorkspaceStoreProvider** — panel layout, panel↔dashboard mapping.

## Panel state model

Each panel mounts its own `DashboardStore` instance (factory pattern,
not a global singleton):

```ts
type PanelState = {
  dashboardId: string;
  ir: UiIr | null;
  routeId: string | null;
  history: string[];
  filters: Record<string, unknown>;
  selection: string[];
  pagination: Record<string, { page: number; pageSize: number }>;
  scroll: Record<string, number>;
  requests: Record<string, { status; error? }>;
  connection: 'online' | 'offline' | 'degraded';
  dirty: boolean;
};
```

App-level state limited to: hub list, workspace arrangement, theme,
toasts, bridge status.

## Bridge boundary

All backend calls go through `lib/tauri/commands.ts`. Responses validated
at the boundary. Mock adapter used when Rust core unavailable (phone
dev).

## Where to read next

- [component-registry.md](component-registry.md) — supported components
- [dashboard-renderer.md](dashboard-renderer.md) — rendering pipeline
- [workspace-manager.md](workspace-manager.md) — panels & splits
- [state-management.md](state-management.md) — isolation rules
