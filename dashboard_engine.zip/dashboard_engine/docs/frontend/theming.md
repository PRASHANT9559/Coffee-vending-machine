# Theming

Theme system and Tailwind configuration for the frontend.

## Theme tokens

| Token | Purpose | Example values |
| --- | --- | --- |
| `color-primary` | brand accent | blue-600 |
| `color-surface` | card backgrounds | white / slate-950 |
| `color-text` | primary text | slate-900 / slate-100 |
| `spacing` | layout gaps | 4, 8, 16, 24 px |
| `radius` | component corners | md, lg |
| `density` | compact/comfortable | tight / normal / loose |

## Modes

- `light`, `dark`, `system` (respects OS preference).
- Stored per-app preference; reflected in UI-IR `theme.mode`.
- Per-dashboard theme overrides allowed but minimal in v1.

## Implementation

- Tailwind CSS config defines tokens as CSS custom properties.
- `ThemeProvider` injects `data-theme` attribute on root.
- Components read tokens via Tailwind classes; no runtime CSS-in-JS.

## Density

Three density modes affect padding/font size scale globally. Selected in
settings, persisted to app settings.

## Where to read next

- [architecture.md](architecture.md) — ThemeProvider placement
- [dashboard-renderer.md](dashboard-renderer.md) — theme in UI-IR
