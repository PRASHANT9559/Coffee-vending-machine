# Frontend — Next.js Renderer

The frontend is the **face** of the system. All UI rendering, user
interaction, and visual state lives here. It never touches SQL, database
credentials, or SQLite.

## Responsibility map

```
┌─────────────────────────────────────────────────────────┐
│                    NEXT.JS FRONTEND                      │
├────────────────┬──────────────┬─────────────────────────┤
│  Dashboard Hub │  Workspace   │  Dashboard              │
│  (Browse/CRUD) │  Manager     │  Renderer               │
│                │  (Panels)    │  (UI-IR → Components)   │
├────────────────┼──────────────┼─────────────────────────┤
│  Component     │  State       │  Theme                  │
│  Registry      │  Manager     │  Engine                 │
├────────────────┼──────────────┼─────────────────────────┤
│  Navigation    │  Forms &     │  Error                  │
│  System        │  Filters     │  Boundaries             │
├────────────────┴──────────────┴─────────────────────────┤
│              Tauri IPC Bridge Layer                       │
└─────────────────────────────────────────────────────────┘
```

## Key responsibilities

- Dashboard Hub UI (card grid, create wizard, search)
- Multi-panel workspace (split views, resize, maximize)
- UI-IR rendering (JSON → React via component registry)
- Component registry (validated, type-safe)
- Per-dashboard state isolation (navigation, filters, data)
- Theme system (dark/light, Tailwind tokens)
- Sidebar & navigation tree rendering
- Forms, filters, search, pagination
- Panel-scoped error boundaries
- Loading states & skeleton screens

## Out of scope

- Connecting to PostgreSQL/TimescaleDB
- Reading/writing SQLite
- Generating SQL or schema metadata
- Enforcing authorization
- Inferring business meaning
- Mobile layouts (initial release)

## Stack

| Choice | Reason |
| --- | --- |
| Next.js (App Router) | desktop bundle inside Tauri |
| `output: "export"` | static export, no SSR in desktop build |
| Tailwind CSS | utility-first design system |
| TypeScript strict | contract safety |
| Tauri IPC bridge | typed commands/events |

## Folder structure

```
frontend/
├── app/                    # Next.js App Router
│   ├── layout.tsx          # providers
│   ├── page.tsx            # hub
│   ├── hub/                # dashboard hub
│   └── workspace/          # multi-dashboard workspace
├── components/
│   ├── hub/                # cards, wizard, search
│   ├── workspace/          # splits, panels, presets
│   ├── dashboard/          # shell, sidebar, page renderer
│   ├── registry/           # component implementations
│   └── ui/                 # shared primitives
├── lib/
│   ├── tauri/              # IPC bridge client + mock
│   ├── store/              # panel store factory
│   ├── uiir/               # renderer + validator
│   └── theme/              # tokens & providers
├── public/
└── package.json
```

## Where to read next

- [architecture.md](architecture.md) — app layout & providers
- [dashboard-renderer.md](dashboard-renderer.md) — UI-IR → React pipeline
- [workspace-manager.md](workspace-manager.md) — multi-panel system
- [state-management.md](state-management.md) — per-dashboard isolation
