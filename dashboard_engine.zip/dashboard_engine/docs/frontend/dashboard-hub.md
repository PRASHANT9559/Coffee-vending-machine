# Dashboard Hub

The Dashboard Hub is the entry point for managing dashboard resources.
It is not itself a business dashboard; it is the management surface.

## Hub page layout

- Header with app title and user actions.
- Searchable/browsable card grid of dashboards.
- Prominent **Add New** action.
- Empty state when no dashboards exist.
- Status badges (draft, active, archived, stale schema).

## Dashboard card design

Each card displays:

- Icon or image
- Dashboard name
- Description
- Status/metadata (last opened, data source health)
- Action overflow menu: open, edit config, duplicate, archive, delete

## Create wizard (multi-step)

1. Identity — name, description, icon.
2. Data source — connection reference (no secrets in UI).
3. Navigation — sidebar entries, theme, layout, access controls.
4. Review — summary before save.

Create → save → dashboard row in SQLite (draft status) → revision 1.

## Dashboard actions

| Action | Behavior |
| --- | --- |
| Open | load UI-IR into workspace panel |
| Edit config | reopen wizard on existing dashboard |
| Duplicate | copy config, new id, prompt for name |
| Archive | mark archived, remove from active list |
| Delete | confirm by typing name; soft-delete with recovery window |
| Restore | recover archived dashboard |

## Search & filter

- Search by name/description.
- Filter by status.
- Sort by name / last modified.

## Empty & error states

- No dashboards: show Add New prominently.
- Load failure: retry action + diagnostics link.
- Corrupt config: recovery notice with revision options.

## Where to read next

- [workspace-manager.md](workspace-manager.md) — where dashboards open
- [backend/data-models.md](../backend/data-models.md) — dashboard store schema
- [workflows/dashboard-lifecycle.md](../workflows/dashboard-lifecycle.md) — create flow
