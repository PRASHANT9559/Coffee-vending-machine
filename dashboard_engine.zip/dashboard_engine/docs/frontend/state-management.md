# State Management

Per-dashboard state isolation architecture. Each dashboard instance
maintains its own state; shared app state is limited to shell concerns.

## Store layers

| Layer | Scope | Contents |
| --- | --- | --- |
| Hub store | app-level | dashboard list, search, selected id |
| Workspace store | app-level | panel layout, panel↔dashboard mapping |
| Dashboard store (per instance) | panel-level | route, filters, selection, pagination, scroll, dirty, connection |

## Dashboard store (factory-created)

```ts
type PanelState = {
  dashboardId: string;
  ir: UiIr | null;
  routeId: string | null;
  history: string[];
  filters: Record<string, unknown>;
  selection: string[];
  pagination: Record<string, { page: number; pageSize: number }>;
  scroll: Record<string, number>;
  requests: Record<string, { status; error? }>;
  connection: 'online' | 'offline' | 'degraded';
  dirty: boolean;
};
```

## Isolation rules

- No panel reads another panel's state.
- Navigation in a panel never touches the global router.
- Failed request updates only the requesting binding.
- Closing a panel cancels its requests and releases its cache.
- Unsaved edits prompt on close/navigate, scoped to that panel.
- Theme and hub list are shared; everything dashboard-specific is per
  instance.

## Why no global navigation store

Multi-dashboard is a core invariant. A global store risks navigation
state leakage between panels. Per-panel stores make isolation testable
and explicit.

## Where to read next

- [workspace-manager.md](workspace-manager.md) — panel lifecycle
- [dashboard-renderer.md](dashboard-renderer.md) — rendering per panel
- [architecture.md](architecture.md) — provider composition
