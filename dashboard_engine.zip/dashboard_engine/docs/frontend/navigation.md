# Navigation

Sidebar generation, route handling, and navigation isolation per panel.

## Sidebar generation

Generated from UI-IR `navigation` tree:

- Groups with labels and icons.
- Items mapping to routes.
- Footer items (settings, etc.).

Active route highlighted; nav items hidden by permissions are removed
from rendering (cosmetic only; backend still enforces access).

## Route handling

Each panel owns its own route stack:

- Active route → page resolution via UI-IR.
- Back/forward history scoped to the panel.
- Nested navigation supported where page structure allows.
- Route change triggers data re-fetch for affected bindings.

## Isolation rules

- Selecting an item in panel 1 sidebar does not change panel 2/3 route
  or sidebar.
- Panel history independent; browser back does not cross panels.
- No shared "current route" across panels.

## Where to read next

- [dashboard-renderer.md](dashboard-renderer.md) — route → page → components
- [state-management.md](state-management.md) — per-panel route state
- [backend/ui-ir-spec.md](../backend/ui-ir-spec.md) — navigation vocabulary
