# Dashboard Renderer

UI-IR → React component tree pipeline. The renderer is where UI-IR
becomes pixels.

## Pipeline

```
raw UI-IR (from bridge)
  -> shape validation (schema + local)
  -> version check (supported range)
  -> reference resolution
       nav → route → page → component → binding → query
  -> normalization (defaults, caps)
  -> render tree
       page → layout rows → component slots → registry component
  -> per-binding data request (via bridge)
  -> component render with {data, state, permissions}
```

## Failure handling

- Do not partially render a broken dashboard.
- Show diagnostics surface with stable codes and paths.
- Keep hub and other panels alive.

## Layout engine (v1)

- Grid with capped columns (default 12).
- Rows: `auto | fill | <px>px`.
- Items with `span` 1..columns.
- Max one `fill` row per page; last row fills remaining if none.
- Minimum component height; overflow scrolls inside component.

## Data bindings

- Binding → query id + normalized params.
- Request key dedupes identical concurrent requests within panel only.
- Cancellation on route change, panel close, dashboard switch.
- Stale policy: manual (default), on_mount, interval (capped, active
  panel only).

## Filters / sort / pagination / selection

- Panel state, never global.
- Filters map to declared query params only.
- Sort limited to `sortable: true` columns.
- Page size capped.
- Selection = primary keys; cleared per component reset policy.

## Where to read next

- [component-registry.md](component-registry.md) — component contracts
- [backend/ui-ir-spec.md](../backend/ui-ir-spec.md) — UI-IR shape
- [state-management.md](state-management.md) — panel state ownership
