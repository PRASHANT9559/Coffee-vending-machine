# Workspace Manager

Multi-panel workspace system. Multi-dashboard is a first-class capability,
not merely tabs or switching between pages.

## Layout modes

| Mode | Description |
| --- | --- |
| Single | one dashboard fills the workspace |
| Two-panel | split into two visible panels |
| Three-panel | split into three visible panels |

Split directions: vertical and horizontal.

## Preset layouts

- Equal splits (50/50, 33/33/33)
- Asymmetric (60/40, 70/30)
- Three-up variants
- Custom ratios saved per workspace

## Interactions

- Drag divider to resize panels.
- Double-click divider to equalize.
- Maximize one panel; restore returns previous ratios.
- Active panel gets visible focus ring; keyboard shortcuts scoped to it.
- Adding a dashboard to a full workspace asks which panel to replace.
- Deleted/archived dashboard → placeholder panel with actions, not a crash.

## Panel chrome

Each panel shows: dashboard name, refresh, maximize, close, overflow
menu.

## Persistence

Workspace arrangement stored separately from dashboard definitions:

```jsonc
{
  "panels": [{ "dashboardId": "...", "ratio": 0.5 }],
  "orientation": "horizontal|vertical",
  "activeId": "..."
}
```

Arrangement changes never rewrite dashboard config. Restore with missing
dashboard degrades to placeholder, not crash.

## Where to read next

- [state-management.md](state-management.md) — per-panel store factory
- [dashboard-renderer.md](dashboard-renderer.md) — rendering inside panel
- [backend/data-models.md](../backend/data-models.md) — workspace layout table
