# Documentation Index

Entry point for all project documentation. The master specification lives
at [`../Universal-UI-Auto-DashboardEngine.md`](../Universal-UI-Auto-DashboardEngine.md).

Phase: **P1 end-to-end slice**. Skeleton code exists; the product is not
production-ready yet. See [`../P0_VERIFY.md`](../P0_VERIFY.md),
[`../P1_PROGRESS.md`](../P1_PROGRESS.md), and
[`../audit_report.md`](../audit_report.md).

## Reading order

| # | Document | Why read it |
| --- | --- | --- |
| 1 | [architecture-overview.md](architecture-overview.md) | System shape, trust boundaries, data flow |
| 2 | [ROADMAP.md](ROADMAP.md) | Phases, deliverables, exit criteria |
| 3 | [backend/README.md](backend/README.md) | What the Rust engine owns |
| 4 | [frontend/README.md](frontend/README.md) | What the Next.js app owns |
| 5 | [backend/ui-ir-spec.md](backend/ui-ir-spec.md) | The contract between the two parts |
| 6 | [workflows/dashboard-lifecycle.md](workflows/dashboard-lifecycle.md) | Create → generate → use → update |
| 7 | [references/termux-dev-guide.md](references/termux-dev-guide.md) | Phone environment constraints |

## Navigation table

### Top level

| Document | Contents |
| --- | --- |
| [architecture-overview.md](architecture-overview.md) | High-level architecture, parts A/B, boundaries, key decisions |
| [ROADMAP.md](ROADMAP.md) | Phases 1–6, backend/frontend workstreams, risks, open questions |

### Backend (Rust engine)

| Document | Contents |
| --- | --- |
| [backend/README.md](backend/README.md) | Responsibilities, capability map, pipeline summary |
| [backend/architecture.md](backend/architecture.md) | Module layout, orchestrator, errors, concurrency |
| [backend/database-discovery.md](backend/database-discovery.md) | Introspection, JSONB profiling, relationship inference |
| [backend/query-engine.md](backend/query-engine.md) | Intent model, validation, execution, aggregation |
| [backend/ui-ir-spec.md](backend/ui-ir-spec.md) | UI-IR 1.0.0 specification and versioning rules |
| [backend/plugin-system.md](backend/plugin-system.md) | Manifests, lifecycle, traits, sandboxing |
| [backend/caching-strategy.md](backend/caching-strategy.md) | Cache keys, fingerprints, invalidation, recovery |
| [backend/security.md](backend/security.md) | Threat model, permissions, credentials, IPC |
| [backend/api-reference.md](backend/api-reference.md) | IPC command catalog and event surface |
| [backend/data-models.md](backend/data-models.md) | SQLite schemas, revisions, migrations |

### Frontend (Next.js + Tauri)

| Document | Contents |
| --- | --- |
| [frontend/README.md](frontend/README.md) | Responsibilities, stack, folder overview |
| [frontend/architecture.md](frontend/architecture.md) | App Router layout, providers, build model |
| [frontend/component-registry.md](frontend/component-registry.md) | Component types, prop contracts, fallbacks |
| [frontend/dashboard-hub.md](frontend/dashboard-hub.md) | Card grid, create wizard, management actions |
| [frontend/workspace-manager.md](frontend/workspace-manager.md) | Multi-panel splits, presets, resize, restore |
| [frontend/dashboard-renderer.md](frontend/dashboard-renderer.md) | UI-IR → React pipeline |
| [frontend/state-management.md](frontend/state-management.md) | Per-dashboard isolation and store factories |
| [frontend/theming.md](frontend/theming.md) | Tailwind tokens, dark/light, per-dashboard overrides |
| [frontend/navigation.md](frontend/navigation.md) | Sidebar, routes, history, isolation |
| [frontend/forms-and-filters.md](frontend/forms-and-filters.md) | Filters, search, validation, future forms |

### Workflows

| Document | Contents |
| --- | --- |
| [workflows/dashboard-lifecycle.md](workflows/dashboard-lifecycle.md) | Lifecycle stages, actors, failure handling |
| [workflows/schema-change-workflow.md](workflows/schema-change-workflow.md) | Drift detection, classification, regeneration |
| [workflows/development-workflow.md](workflows/development-workflow.md) | Setup, build, test, branches, contribution |
| [workflows/error-recovery.md](workflows/error-recovery.md) | Failure catalog and recovery paths |

### References

| Document | Contents |
| --- | --- |
| [references/tech-stack.md](references/tech-stack.md) | Technology choices and rationale |
| [references/glossary.md](references/glossary.md) | Shared vocabulary |
| [references/testing-strategy.md](references/testing-strategy.md) | Test layers, scenarios, CI, reporting |
| [references/termux-dev-guide.md](references/termux-dev-guide.md) | Phone setup, limits, workarounds |

## Document conventions

- **MUST** = required for the milestone to be complete.
- **SHOULD** = expected unless a documented decision defers it.
- **MAY** = optional.
- Every MUST should appear in
  [testing-strategy.md](references/testing-strategy.md) or in a limitations
  list.
- A change to UI-IR or IPC is a **contract change** and updates
  [ui-ir-spec.md](backend/ui-ir-spec.md),
  [api-reference.md](backend/api-reference.md), and fixtures together.

## Source of truth

| Topic | Owner document |
| --- | --- |
| Product goals and invariants | master spec + [architecture-overview.md](architecture-overview.md) |
| UI-IR shape and versions | [backend/ui-ir-spec.md](backend/ui-ir-spec.md) |
| IPC commands | [backend/api-reference.md](backend/api-reference.md) |
| Local storage | [backend/data-models.md](backend/data-models.md) |
| Security rules | [backend/security.md](backend/security.md) |
| Delivery order | [ROADMAP.md](ROADMAP.md) |
| Dev process | [workflows/development-workflow.md](workflows/development-workflow.md) |

When documents disagree, the master spec wins for product intent, UI-IR
spec wins for contract shape, and the roadmap wins for sequencing.
