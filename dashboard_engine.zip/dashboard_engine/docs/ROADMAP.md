# Roadmap

Six phases from empty repository to a usable desktop product. Each phase
has backend and frontend workstreams that can run in parallel but merge at
the exit criteria.

```mermaid
flowchart TD
    P1["Phase 1: Foundation"] --> P2["Phase 2: Schema Intelligence"]
    P2 --> P3["Phase 3: Dashboard Generation"]
    P3 --> P4["Phase 4: Multi-Dashboard Workspace"]
    P4 --> P5["Phase 5: Polish and Plugins"]
    P5 --> P6["Phase 6: Advanced Features"]
```

## Phase summary

| Phase | Backend | Frontend | Duration |
| --- | --- | --- | --- |
| 1. Foundation | Tauri scaffold, SQLite, dashboard CRUD, connection management | Next.js scaffold, hub UI, cards, create wizard | 3–4 weeks |
| 2. Schema Intelligence | PostgreSQL adapter, discovery, JSONB profiling, relationships | Discovery status, schema browser, relationship viewer | 3–4 weeks |
| 3. Dashboard Generation | UI-IR types, generator, validator, query engine basics | Renderer, registry (5–8 components), sidebar, routing | 4–5 weeks |
| 4. Multi-Dashboard | Layout persistence, panel isolation, concurrent queries | Panel manager, splits, resize, maximize, error boundaries | 3–4 weeks |
| 5. Polish & Plugins | Plugin loader, caching, drift detection, performance | Theme, filters, search, loading, skeletons | 3–4 weeks |
| 6. Advanced | TimescaleDB adapter, advanced analytics, optional remote service | Charts, time series, realtime, advanced layouts | 4–6 weeks |

Durations assume part-time solo development on phone + CI. They are
estimates, not promises.

---

## Phase 1 — Foundation

Goal: a dashboard can be created, stored, listed, reopened, and renamed
without touching a business database.

**Backend**

- Tauri 2 project scaffold; `src-tauri` linking a core library.
- SQLite store: `dashboards`, `connections`, `dashboard_uiir`,
  `workspace_layouts`; migrations v1.
- Dashboard CRUD commands; connection config with credential references.
- Config export/import; pre-migration backup.
- Core/CLI buildable without GUI deps (for Termux/CI).

**Frontend**

- Next.js App Router scaffold, Tailwind, strict TypeScript.
- Hub page with dashboard cards, search, empty state.
- Create wizard step 1: name, description, icon, connection reference.
- Bridge client with mock adapter.
- Basic settings page (theme, defaults).

**Exit criteria**

- [ ] Create → save → restart → reopen keeps identity and config.
- [ ] Stale save returns a conflict, not a silent overwrite.
- [ ] Hub reflects store state; mock mode works without Rust.
- [ ] One command proves the local toolchain path (or CI does, stated).

**Risks**: Rust toolchain size on phone; shared-storage filesystem.
Mitigation: CLI-first crate + CI builds.

---

## Phase 2 — Schema Intelligence

Goal: real metadata from a real PostgreSQL database, safely and within
bounds.

**Backend**

- PostgreSQL adapter: connect, health check, read-only enforcement.
- Introspection via `information_schema` and `pg_catalog`: schemas,
  tables, views, columns, types, nullability, PK, FK, unique, indexes,
  row estimates.
- JSONB profiling: key paths, value types, null fractions, bounded depth
  and samples, sensitive-column redaction.
- Relationship candidates with `kind`, `confidence`, `provenance`.
- Snapshot persistence + stable fingerprint.
- Cancellable, bounded discovery with partial-result reporting.

**Frontend**

- Discovery progress and status surface.
- Schema browser: objects, columns, types, keys.
- Relationship viewer with confidence labels and accept/reject.
- Error states for unreachable/auth-failed discovery.

**Exit criteria**

- [ ] 100+ table schema snapshots correctly within budget or cancels cleanly.
- [ ] Every candidate relationship shows confidence and provenance.
- [ ] Partial discovery is visibly marked, never presented as complete.
- [ ] No secrets or row values in logs.

**Risks**: catalog query performance; JSONB profiling cost.
Mitigation: object caps, sampling, timeouts, cancellation tokens.

---

## Phase 3 — Dashboard Generation

Goal: the first end-to-end dashboard, generated and rendered.

**Backend**

- UI-IR 1.0.0 type system, validator, migrator.
- Analytics planner: counts, sums, averages, distinct, grouped, time
  series, distributions, top-N.
- Generator (hybrid): overview page, per-object pages, sidebar groups,
  filters.
- Draft → review → apply with merge/replace; revision notes.
- Query engine: intent → validated plan → parameterized SQL → bounded
  result; cancellation and timeouts.

**Frontend**

- UI-IR renderer: validate → resolve → layout → registry.
- Registry v1: `metric-card`, `data-table`, `list`, `chart`, `filter-bar`,
  `section`, `fallback`.
- Sidebar and in-panel routing.
- Loading skeletons and per-component error boundaries.
- Generation review screen: accept, remove, reorder.

**Exit criteria**

- [ ] Generate a dashboard from a real schema and render it.
- [ ] Invalid UI-IR never renders; diagnostics show stable codes.
- [ ] Unknown components fall back without crashing the page.
- [ ] Edits survive save/reopen; regeneration preserves pinned items.

**Risks**: over-promising business meaning; UI-IR churn.
Mitigation: hybrid drafts, assumptions listed, fixtures, versioning.

---

## Phase 4 — Multi-Dashboard Workspace

Goal: the core differentiator — two or three dashboards at once, isolated.

**Backend**

- Per-dashboard query context; concurrency caps (global + per dashboard).
- Cancellation tied to panel lifecycle.
- Workspace layout persistence (references only, validated size/shape).
- Stale dashboard references handled without engine errors.

**Frontend**

- 1/2/3 panel layouts; horizontal/vertical splits.
- Presets (equal, 60/40, 70/30, three-up), minimum sizes.
- Drag resize; maximize/restore; active-panel focus.
- Per-panel store factory: route, filters, selection, pagination, scroll,
  unsaved flag, connection state.
- Panel chrome and panel-scoped error boundary.
- Restore arrangement; placeholder for deleted/archived dashboards.

**Exit criteria**

- [ ] Isolation matrix passes: actions in panel 1 do not change panels 2/3.
- [ ] Three panels stay within the performance budget.
- [ ] Closing a panel cancels its in-flight work.
- [ ] Restore after dashboard deletion degrades gracefully.

**Risks**: state leakage; resource pressure. Mitigation: explicit stores,
caps, lazy panels, isolation tests.

---

## Phase 5 — Polish and Plugins

Goal: production hygiene and a safe extension point.

**Backend**

- Query cache: scoped keys, TTL, byte caps, LRU, invalidation.
- Fingerprint diff: unchanged / additive / breaking.
- Drift events and regeneration policy preserving customization.
- Cache corruption recovery; config recovery from revisions/backups.
- Diagnostics endpoint (versions, health, cache stats; no secrets).
- Plugin manifest v0 + registry + one real adapter/profiler plugin.
- Performance measurements against budgets.

**Frontend**

- Theme system with tokens, density, dark/light/system.
- Filter bar polish, saved search, column sizing, sticky headers.
- Loading/skeleton consistency; offline shell with stale markers.
- Drift review UI, one-click refresh, recovery notices.
- Keyboard shortcuts and command palette (active panel scoped).

**Exit criteria**

- [ ] Corrupt cache recovers without losing dashboards.
- [ ] Drift scenarios each produce a tested, visible outcome.
- [ ] Incompatible plugin fails safely; engine still starts.
- [ ] Measured performance report recorded.
- [ ] Keyboard-only primary workflow works.

---

## Phase 6 — Advanced Features

Goal: time-series depth and optional shared deployment.

**Backend**

- TimescaleDB adapter: hypertables, continuous aggregates, time_bucket
  query patterns.
- Advanced analytics: comparisons, trends, cohort-style plugins.
- Optional Rust remote service behind the same IPC contract, with
  server-side authorization.
- Realtime adapters (targeted binding refresh).
- Multi-tenant design notes (implementation only if required).

**Frontend**

- Time-series charts with range selection and downsampling.
- Realtime refresh indicators scoped per panel.
- Advanced layouts within the IR subset (sections, tabs later).
- Report export (read-only static snapshot).

**Exit criteria**

- [ ] TimescaleDB queries work through the same validation path.
- [ ] Remote mode does not change frontend contract shape.
- [ ] Realtime updates refresh only affected bindings.
- [ ] Limitations and compatibility matrix updated.

---

## Cross-phase rules

1. Contract first: UI-IR/IPC changes update spec + fixtures before code.
2. Every phase ends with a demo script and honest limitations list.
3. No plugin execution before Phase 5.
4. No TimescaleDB work before PostgreSQL is stable.
5. No mobile layout work in Phases 1–6.
6. Regeneration never destroys user customization without confirmation.
7. Performance budgets are measured, not assumed.

## Decisions on the plan's open questions

| Question | Decision for planning | Revisit |
| --- | --- | --- |
| Database priority | PostgreSQL only in Phases 1–5; TimescaleDB in Phase 6 | Phase 6 |
| Auth strategy | Local-only, no login for desktop MVP; per-dashboard permission scopes still enforced | Phase 6 / remote |
| Plugin system | Documented now, implemented in Phase 5; no executable plugin loading earlier | Phase 5 |
| Remote service | Design note in Phase 6, implementation optional | Phase 6 |

## Risk register

| Risk | Likelihood | Impact | Mitigation |
| --- | --- | --- | --- |
| Phone cannot build the desktop shell | high | medium | CI/desktop builds; CLI-first core |
| npm install fails on shared storage | high | medium | work in Termux home; minimal deps |
| SQL inference over-promises meaning | medium | high | hybrid drafts, assumptions, review |
| Multi-panel state leakage | medium | high | store factory + isolation tests |
| UI-IR churn breaks saved dashboards | medium | high | versioning, migrations, fixtures |
| Query load from 3 panels | medium | medium | concurrency caps, cancels, lazy |
| Scope creep into mobile/offline writes | medium | medium | documented non-goals |
| Secret leakage | low | critical | secret refs, redaction tests |

## Definition of success

A user can configure a supported database, generate and customize a
dashboard, save and reopen it, manage several dashboards in the hub, open
two or three in one window, and work in each independently without state
leakage — through stable contracts, with documented limits.
