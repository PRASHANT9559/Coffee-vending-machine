# Termux Dev Guide

Termux / Android phone development notes. Development happens on the
phone; this changes what is realistic.

## 1. Reality check

| Task | On phone | Notes |
| --- | --- | --- |
| Next.js dev server | ✅ | `127.0.0.1`, phone browser |
| Next.js static build | ⚠️ | slow/heavy; watch memory |
| TypeScript / unit tests | ✅ | keep runner light |
| SQLite | ✅ | `pkg install sqlite` |
| Rust core (library/CLI) | ⚠️ | possible if toolchain installs; aarch64 |
| Tauri desktop build | ❌ | needs GTK/WebKit/X11; CI/desktop only |
| Playwright e2e | ❌ | CI only |
| Docker Postgres tests | ❌ | remote test DB or CI |
| `npm install` on `/mnt/sdcard` | ❌ | FUSE mount; slow/broken symlinks |

Observed environment: Node.js, git, python3 present; cargo, rustc,
sqlite3, pnpm, yarn missing. PRoot Debian 13 (aarch64).

## 2. Filesystem

Do not build in `/mnt/sdcard` (Android shared storage). Use Termux home:

```bash
mkdir -p ~/dashboard_engine
cp -a /mnt/sdcard/download/project/dashboard_engine/. ~/dashboard_engine/
cd ~/dashboard_engine
```

## 3. Base packages

Termux native:

```bash
pkg update
pkg install nodejs-lts git sqlite python
# optional Rust (large):
pkg install rust binutils
```

PRoot Debian:

```bash
apt update
apt install -y nodejs npm git sqlite3 build-essential pkg-config
# optional: apt install -y cargo rustc
```

Verify:

```bash
node -v && npm -v && sqlite3 --version
cargo --version || echo "no rust locally"
```

## 4. npm on phone

```bash
npm config set fund false
npm config set audit false
npm config set progress false
npm config set loglevel error
npm config set fetch-retries 2
npm config set fetch-timeout 60000

npm install --no-audit --no-fund --omit=optional <pkg>
export NODE_OPTIONS="--max-old-space-size=1024"
export NEXT_TELEMETRY_DISABLED=1
```

Rules: minimal deps, no native build steps unless required, no monorepo
orchestrator, pin versions, commit lockfile, `node_modules` in .gitignore.

## 5. Frontend loop

```bash
cd ~/dashboard_engine/frontend
npm install --no-audit --no-fund
NEXT_TELEMETRY_DISABLED=1 npm run dev
# open http://127.0.0.1:3000 in phone browser
```

Mock bridge used when Rust core unavailable.

## 6. Backend loop

```bash
cd ~/dashboard_engine/backend
cargo test -p dde-core
cargo run -p dde-cli -- ping
```

If Rust unavailable: verify in CI, state limitation honestly. Never run
`cargo tauri build` on the phone.

## 7. Database for dev

- Local SQLite for config work.
- PostgreSQL: free/managed remote for integration, or CI containers,
  or fixtures + mock adapter for unit tests.
- Never commit connection strings/passwords; use env vars locally.

## 8. Daily loop

1. Pull latest main.
2. Pick one slice from roadmap.
3. Update contract + fixtures if needed.
4. Implement smallest working path.
5. Run typecheck + tests (or state CI).
6. Manual check in phone browser.
7. Update docs + limitations.
8. Commit scoped message.

## 9. Battery / disk / heat

- `target/` grows fast; `cargo clean` between milestones.
- `node_modules` 300–600 MB; one copy only.
- Avoid dev server + cargo build + browser + DB client together.
- `du -sh node_modules target ~/.cargo` to monitor.

## 10. Troubleshooting

| Symptom | Fix |
| --- | --- |
| `EACCES`/`EPERM` on npm install | move project to `~` |
| `ENOSPC` | clean `target/`, `node_modules` |
| npm hangs | `npm cache verify`, lower retries |
| `next build` killed | OOM; raise `NODE_OPTIONS`, build in CI |
| `cargo` missing | `pkg install rust` or CI-only |
| Rust link errors | `pkg install binutils`, check `pkg-config` |
| Tauri build fails | no GTK/WebKit/display; use CI |
| SQLite locked | close one writer, enable WAL |
| Browser can't reach server | bind to `127.0.0.1` |

## 11. CI fallback

CI handles: `cargo fmt/clippy/test`, `npm ci` + typecheck + unit
tests, contract validation, Tauri desktop builds (Linux, later
Win/macOS), Playwright e2E. Phone = authoring/UX iteration; CI =
platform verification.
