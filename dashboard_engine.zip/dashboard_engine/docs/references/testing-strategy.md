# Testing Strategy

Tests protect invariants, not inflate percentages. Report results
honestly: what ran, where, and what did not.

## Test layers

| Layer | Protects | Runs on phone? |
| --- | --- | --- |
| Unit (Rust) | planner, validator, inference, migrations, cache keys | yes (if Rust present) |
| Unit (TS) | renderer, registry, state stores, guards | yes |
| Contract | UI-IR schema, fixtures, generated types | yes (Node) |
| Integration (backend) | adapter, discovery, executor vs real PG | CI / remote DB |
| Isolation (frontend) | panel independence | yes (unit) / CI (e2e) |
| Security | denial paths, limits, redaction | yes (unit) / CI |
| Performance | budgets from architecture | desktop/CI |
| Packaging | Tauri builds per platform | CI only |

## Required scenarios (from master spec)

1. Many tables + mixed structured/JSONB data.
2. Explicit + inferred relationships with confidence levels.
3. Schema changes after dashboard saved.
4. Invalid/incompatible UI-IR and plugin config.
5. Two or three dashboards open simultaneously.
6. Nav/filters/selection in one panel don't affect another.
7. Failed query/refresh in one panel; others usable.
8. Permission differences across dashboards/sources.
9. Corrupted cache and unavailable DB recovery.
10. Query limits, timeouts, cancellation under load.
11. Linux/Windows/macOS build and distribution checks.
12. UI-IR migration: old doc loads, migrates, or rejected loudly.

## Isolation test matrix

Action in panel 1 vs. panels 2/3 staying unchanged:

| Action | Must not change in 2/3 |
| --- | --- |
| Navigate to another page | active route, sidebar highlight |
| Change filter/search | filter values, result set |
| Select a row | selection |
| Change page/scroll | pagination, scroll |
| Refresh/retry | loading or error state |
| Lose connection | connection banner |
| Open unsaved editor | unsaved-change flag |
| Resize panel 1 | dashboard state |
| Maximize/restore | dashboard state |

## Security tests (minimum)

- Non-allowlisted table/column → `QUERY_FORBIDDEN`.
- Write/DDL intent → rejected before SQL compilation.
- Over-limit → clamped or rejected per policy.
- Timeout → `QUERY_TIMEOUT`, connection returned.
- Cancel → query stops, no partial result.
- Cache scope mismatch → miss, never cross-scope hit.
- Malformed UI-IR → validation error, no render/execute.
- Logs contain no secret and no row values.
- Stale `baseRevision` → `CONFIG_CONFLICT`, no data loss.

## Contract tests

- `tests/fixtures/ir/valid/*.json` → must validate.
- `tests/fixtures/ir/invalid/*.json` → must fail with expected code.
- Round-trip: generate → save → load → render tree stable.
- Version mismatch rejection tested.

## Migration tests

- Each SQLite migration from previous fixture → assert schema + data.
- Migration abort → DB stays at last good version; backup exists.
- UI-IR migration fixtures per supported version; lossless asserted.

## Performance checks

Measure and record (no tight unit-test thresholds):

- Shell interactive, hub render, panel activation, first query,
  split-to-three panels, discovery of 100 tables, idle background work.
- Compare to budgets; label phone vs desktop numbers.

## Test data

- Fixtures synthetic, no real personal data.
- JSONB fixtures: nested, arrays, mixed types, nulls, deep paths,
  sensitive-looking keys (to prove redaction).
- Never commit production dumps.

## Honest reporting template

```
Verified locally (Termux, <device>):
  - npm run typecheck   PASS
  - npm run test        PASS (N)
  - cargo test          NOT RUN (rust unavailable)

Verified in CI:
  - cargo test --workspace PASS (run #N)
  - playwright e2e        PASS (N specs)

Not verified:
  - Windows build

Known limitations:
  - JSONB depth capped at 3
```

## Trustworthy suite rules

- Failing test blocks merge.
- Flaky tests quarantined with issue, not silently retried.
- Every named invariant has a negative test.
- Coverage is a signal, not a target.
- Untested/unsupported behavior documented, not hidden.

## Where to read next

- [workflows/development-workflow.md](../workflows/development-workflow.md) — how to run
- [backend/security.md](../backend/security.md) — security checklist
- [architecture-overview.md](../architecture-overview.md) — performance budgets
