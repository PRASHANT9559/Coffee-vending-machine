# Technology Stack

Technology choices with rationale for each layer.

| Technology | Role | Why chosen |
| --- | --- | --- |
| Rust | Core engine | Memory safety, performance, Tauri integration, CLI-friendly |
| SQLite | Local store | Zero-config, embedded, reliable, WAL mode |
| PostgreSQL | Primary business DB | Industry standard, rich metadata, read-only roles |
| TimescaleDB | Time-series | PostgreSQL-compatible, hypertables, continuous aggregates |
| Next.js | Frontend renderer | React ecosystem, App Router, static export |
| Tailwind CSS | Styling | Utility-first, design tokens, no runtime CSS-in-JS |
| Tauri 2 | Desktop shell | Lightweight, Rust backend, Linux/Windows/macOS |
| TypeScript | Frontend types | Contract safety, strict checking |

## Boundaries

- Rust: orchestration, discovery, profiling, planning, validation,
  execution, caching, plugins.
- SQLite: local config, preferences, migrations, cache metadata.
- PostgreSQL/TimescaleDB: business data, read-only access.
- Next.js: dashboard UI renderer.
- Tailwind: styling and design system.
- Tauri 2: desktop shell, IPC bridge.

## Initial platform targets

Linux, Windows, macOS (desktop-first). Android/iOS not initial targets
despite Tauri mobile capability.

## Optional

Rust-based remote service (authenticated remote access, shared
deployments, realtime) — Phase 6 design note only.

## Phone development (Termux)

- Node.js works for frontend dev/build.
- Rust core/CLI possible but slow; CI/desktop recommended for builds.
- PostgreSQL client libraries may need `pkg install postgresql`.
- Full guide: [termux-dev-guide.md](termux-dev-guide.md).

## Dependency discipline

- Few, small dependencies.
- Avoid native build steps unless required.
- No monorepo orchestrator on phone.
- Pin versions; commit lockfiles.
