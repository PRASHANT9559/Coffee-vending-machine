# Glossary

Shared vocabulary for the project.

| Term | Meaning |
| --- | --- |
| **Engine** | Reusable Rust backend core: discovery, planning, generation, validation, execution. |
| **Dashboard** | Persistent, independently configured resource (identity, sources, nav, layout, components, permissions). |
| **Dashboard Hub** | Management surface listing dashboards; not a business dashboard itself. |
| **Dashboard instance** | Running dashboard inside one workspace panel, with its own state. |
| **Workspace** | Arrangement of one to three dashboard instances in the app window. |
| **Panel** | One visible region hosting a dashboard instance. |
| **UI-IR** | Versioned, validated JSON representation of a dashboard's UI, bindings, navigation, permissions. |
| **Component registry** | Closed set of trusted UI component types and validated props. |
| **Renderer** | Frontend pipeline turning UI-IR into React output via registry. |
| **Binding** | Link between a UI component and a query result shape. |
| **Query intent** | Declarative description of desired data (not SQL). |
| **Query plan** | Validated, compiled form of an intent. |
| **Adapter** | Backend module for a specific database kind (PostgreSQL, TimescaleDB). |
| **Discovery** | Inspection of schema metadata: objects, columns, types, keys, constraints, indexes. |
| **Snapshot** | Immutable result of one discovery run, identified by fingerprint. |
| **Fingerprint** | Stable hash of relevant schema structure for cache validity and drift detection. |
| **Profiling** | Bounded statistical observation of data (nulls, distinct caps, JSONB paths). |
| **Relationship candidate** | Possible join with `confidence` and `provenance`. |
| **Confidence** | 0..1 strength of evidence for a candidate relationship. |
| **Provenance** | Evidence source: constraint, index, profile, heuristic. |
| **Generation mode** | `automatic` / `configured` / `hybrid`. |
| **Draft** | Generated UI-IR proposal not yet applied. |
| **Revision** | Immutable saved version of a dashboard definition. |
| **Schema drift** | Difference between current DB schema and snapshot a dashboard was built on. |
| **Permission scope** | Label describing granted access (e.g. `analytics:read`). |
| **Secret ref** | Pointer to a secret stored outside the config database. |
| **Bridge** | Typed command/event interface between frontend and backend. |
| **Command** | Frontend → backend request. |
| **Event** | Backend → frontend notification. |
| **Plugin manifest** | Declared identity, version, compatibility, capabilities, config. |
| **Bounded** | Explicit caps on rows, time, memory, concurrency, depth. |
| **Isolation** | Guarantee one dashboard instance's state/failures don't affect another. |
| **Stale** | Data/metadata older than its validity window. |
| **Recovery path** | Defined, visible way to return to usable state after failure. |
| **Vertical slice** | Small end-to-end behavior delivered and verified as a unit. |
| **Part A / Part B** | Frontend / backend workstreams. |
| **Termux** | Android terminal environment used for development on the phone. |
| **PRoot** | Userspace chroot-like environment used here (Debian on Android). |
| **Tauri** | Desktop shell wrapping the web renderer and Rust core. |
