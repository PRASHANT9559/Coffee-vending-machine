/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  reactStrictMode: true,
  images: {
    unoptimized: true,
  },
  // ESLint is not part of the P0 toolchain yet; typecheck runs separately.
  eslint: {
    ignoreDuringBuilds: true,
  },
  // Trailing slashes keep `out/dashboard/index.html` resolvable from the
  // Tauri asset protocol on every platform.
  trailingSlash: true,
}

export default nextConfig
