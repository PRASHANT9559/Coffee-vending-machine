/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  reactStrictMode: true,
  images: {
    unoptimized: true,
  },
  // ESLint is not part of the P0 toolchain yet; typecheck is run separately.
  eslint: {
    ignoreDuringBuilds: true,
  },
  // Next does not publish native SWC binaries for Android/Termux.
  // Best-effort wasm fallback there; production builds still belong on desktop.
  experimental: {
    useWasmBinary: process.platform === "android",
  },
}

module.exports = nextConfig
