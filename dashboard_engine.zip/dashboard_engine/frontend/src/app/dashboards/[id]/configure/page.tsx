import { ConfigureView } from "@/components/dashboard/configure-view"

export function generateStaticParams() {
  return [{ id: "demo" }]
}

export default function ConfigurePage({ params }: { params: { id: string } }) {
  return <ConfigureView id={params.id} />
}
