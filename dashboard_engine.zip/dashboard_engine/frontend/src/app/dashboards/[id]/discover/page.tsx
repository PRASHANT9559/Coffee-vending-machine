import { DiscoverView } from "@/components/dashboard/discover-view"

export function generateStaticParams() {
  return [{ id: "demo" }]
}

export default function DiscoverPage({ params }: { params: { id: string } }) {
  return <DiscoverView id={params.id} />
}
