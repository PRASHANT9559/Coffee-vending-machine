import { DashboardDetail } from "@/components/dashboard/dashboard-detail"

// Static export needs at least one concrete param. Arbitrary dashboard ids
// are loaded client-side from the hub; this seed keeps the route buildable.
export function generateStaticParams() {
  return [{ id: "demo" }]
}

export default function DashboardPage({ params }: { params: { id: string } }) {
  return <DashboardDetail id={params.id} />
}
