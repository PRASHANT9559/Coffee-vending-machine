"use client"

import Link from "next/link"
import { useCallback, useEffect, useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { PageHeader } from "@/components/layout/page-header"
import { DashboardGrid } from "@/components/hub/dashboard-grid"
import { DashboardGridSkeleton } from "@/components/common/loading-skeleton"
import { HubSearch } from "@/components/hub/hub-search"
import { Alert } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { EmptyState } from "@/components/ui/empty-state"
import {
  IconChart,
  IconLayoutDashboard,
  IconPencil,
  IconPlus,
  IconRefresh,
} from "@/components/ui/icons"
import { useHubStore } from "@/lib/store/hub-store"
import { getBridge } from "@/lib/tauri/commands"
import type { Dashboard } from "@/lib/tauri/types"

type StatusFilter = "all" | "active" | "draft" | "archived"

const statusFilters: Array<{ value: StatusFilter; label: string }> = [
  { value: "all", label: "All" },
  { value: "active", label: "Active" },
  { value: "draft", label: "Draft" },
  { value: "archived", label: "Archived" },
]

export default function HubPage() {
  const {
    dashboards,
    setDashboards,
    setStatus,
    status,
    error,
    selectDashboard,
    searchQuery,
    setSearchQuery,
    filteredDashboards,
  } = useHubStore()
  const [bridge] = useState(() => getBridge())
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all")

  const loadDashboards = useCallback(() => {
    setStatus("loading")
    bridge
      .invoke<{ items: Dashboard[] }>("dashboard_list", {})
      .then((res: any) => {
        if (res.ok) {
          setDashboards(res.data?.items ?? [])
          setStatus("idle")
        } else {
          setStatus("error", res.error?.message ?? "Failed to load dashboards")
        }
      })
      .catch(() => {
        setStatus("error", "Failed to connect to backend")
      })
  }, [bridge, setDashboards, setStatus])

  useEffect(() => {
    loadDashboards()
  }, [loadDashboards])

  const searched = filteredDashboards()
  const visible = searched.filter((d) => statusFilter === "all" || d.status === statusFilter)
  const isLoading = status === "loading" && dashboards.length === 0
  const hasError = status === "error"

  const counts = {
    all: dashboards.length,
    active: dashboards.filter((d) => d.status === "active").length,
    draft: dashboards.filter((d) => d.status === "draft").length,
    archived: dashboards.filter((d) => d.status === "archived").length,
  }

  const handleDelete = async (id: string) => {
    const target = dashboards.find((d) => d.id === id)
    if (!window.confirm(`Delete dashboard "${target?.name ?? id}"? This cannot be undone.`)) return

    const res = await bridge.invoke("dashboard_delete", {
      dashboardId: id,
      confirmName: target?.name ?? id,
    })

    if (res.ok) {
      setDashboards(dashboards.filter((d) => d.id !== id))
      setStatus("idle")
    } else {
      setStatus("error", res.error?.message ?? "Could not delete dashboard.")
    }
  }

  return (
    <AppShell
      action={
        <Link href="/create">
          <Button>
            <IconPlus size={15} />
            New dashboard
          </Button>
        </Link>
      }
    >
      <PageHeader
        eyebrow="Workspace"
        title="Dashboard Hub"
        description="Connect a data source, generate a dashboard, and keep every view one click away."
        actions={
          <Button variant="secondary" size="md" onClick={loadDashboards} disabled={isLoading}>
            <IconRefresh size={15} />
            Refresh
          </Button>
        }
      />

      <section aria-label="Dashboard summary" className="grid gap-3 sm:grid-cols-3">
        <StatCard
          label="Total dashboards"
          value={counts.all}
          hint="All saved dashboards"
          icon={<IconLayoutDashboard size={18} />}
          tone="primary"
        />
        <StatCard
          label="Active"
          value={counts.active}
          hint="Ready for daily use"
          icon={<IconChart size={18} />}
          tone="success"
        />
        <StatCard
          label="Drafts"
          value={counts.draft}
          hint="Still being configured"
          icon={<IconPencil size={18} />}
          tone="warning"
        />
      </section>

      <div className="mt-8 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <HubSearch value={searchQuery} onChange={setSearchQuery} />
        <div
          className="no-scrollbar -mx-1 flex items-center gap-1 overflow-x-auto px-1"
          role="group"
          aria-label="Filter dashboards by status"
        >
          {statusFilters.map((filter) => {
            const active = statusFilter === filter.value
            return (
              <button
                key={filter.value}
                type="button"
                onClick={() => setStatusFilter(filter.value)}
                aria-pressed={active}
                className={`inline-flex h-8 shrink-0 cursor-pointer items-center gap-1.5 rounded-lg px-3 text-xs font-semibold transition-colors ${
                  active
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "border border-border bg-card text-muted-foreground hover:bg-surface-muted hover:text-foreground"
                }`}
              >
                {filter.label}
                <span
                  className={`tabular text-[10px] ${active ? "opacity-80" : "text-muted-foreground/80"}`}
                >
                  {counts[filter.value]}
                </span>
              </button>
            )
          })}
        </div>
      </div>

      {hasError && (
        <Alert className="mt-4" title="Could not load dashboards">
          <div className="flex flex-wrap items-center gap-3">
            <span>{error}</span>
            <button
              type="button"
              onClick={loadDashboards}
              className="cursor-pointer font-semibold underline underline-offset-2"
            >
              Try again
            </button>
          </div>
        </Alert>
      )}

      <section className="mt-5" aria-label="Dashboards">
        {isLoading ? (
          <DashboardGridSkeleton />
        ) : dashboards.length === 0 ? (
          <Card padded={false}>
            <EmptyState
              title="No dashboards yet"
              description="Create your first dashboard, connect a supported database, and generate a layout in minutes."
              actionLabel="Create dashboard"
              action={() => {
                window.location.href = "/create"
              }}
              icon={<IconLayoutDashboard size={24} />}
            />
          </Card>
        ) : visible.length === 0 ? (
          <Card padded={false}>
            <EmptyState
              title="No matching dashboards"
              description="Try a different search term or switch the status filter."
              actionLabel="Clear filters"
              action={() => {
                setSearchQuery("")
                setStatusFilter("all")
              }}
              icon={<IconChart size={24} />}
            />
          </Card>
        ) : (
          <>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-xs font-medium text-muted-foreground">
                Showing <span className="tabular text-foreground">{visible.length}</span>{" "}
                {visible.length === 1 ? "dashboard" : "dashboards"}
              </p>
            </div>
            <DashboardGrid
              dashboards={visible}
              onOpen={(id) => selectDashboard(id)}
              onDelete={(id) => void handleDelete(id)}
            />
          </>
        )}
      </section>
    </AppShell>
  )
}

function StatCard({
  label,
  value,
  hint,
  icon,
  tone,
}: {
  label: string
  value: number
  hint: string
  icon: React.ReactNode
  tone: "primary" | "success" | "warning"
}) {
  const tones = {
    primary: "border-primary/15 bg-primary-soft text-primary",
    success: "border-success/20 bg-success-soft text-success",
    warning: "border-warning/25 bg-warning-soft text-warning",
  }

  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border border-border bg-card p-4 shadow-card">
      <div className="min-w-0">
        <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
          {label}
        </p>
        <p className="mt-1.5 text-2xl font-bold tracking-tight text-foreground tabular">{value}</p>
        <p className="mt-0.5 truncate text-[11px] text-muted-foreground">{hint}</p>
      </div>
      <span
        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border ${tones[tone]}`}
        aria-hidden="true"
      >
        {icon}
      </span>
    </div>
  )
}
