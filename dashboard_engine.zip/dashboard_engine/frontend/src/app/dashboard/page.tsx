"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { DashboardDetail } from "@/components/dashboard/dashboard-detail"
import { AppShell } from "@/components/layout/app-shell"
import { EmptyState } from "@/components/ui/empty-state"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/common/loading-skeleton"
import { IconFile } from "@/components/ui/icons"

// Static-export friendly dashboard route: ids are read from `?id=...` at
// runtime instead of relying on a dynamic segment that Next cannot prebuild.
export default function DashboardByIdPage() {
  const [ready, setReady] = useState(false)
  const [id, setId] = useState<string | null>(null)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    setId(params.get("id"))
    setReady(true)
  }, [])

  if (!ready) {
    return (
      <AppShell active="/" wide>
        <Skeleton className="h-7 w-52" />
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <Skeleton className="h-28 rounded-xl" />
          <Skeleton className="h-28 rounded-xl" />
          <Skeleton className="h-28 rounded-xl" />
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
      </AppShell>
    )
  }

  if (!id) {
    return (
      <AppShell active="/">
        <div className="rounded-xl border border-border bg-card shadow-card">
          <EmptyState
            title="No dashboard selected"
            description="Open a dashboard from the hub or create a new one to get started."
            icon={<IconFile size={24} />}
          />
          <div className="flex justify-center gap-2 pb-8">
            <Link href="/">
              <Button variant="secondary">Back to hub</Button>
            </Link>
            <Link href="/create">
              <Button>Create dashboard</Button>
            </Link>
          </div>
        </div>
      </AppShell>
    )
  }

  return <DashboardDetail id={id} />
}
