"use client"

import { Button } from "@/components/ui/button"
import { IconAlert, IconRefresh } from "@/components/ui/icons"

export default function Error({
  error,
  reset,
}: {
  error: Error
  reset: () => void
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-danger/25 bg-danger-soft text-danger">
        <IconAlert size={24} />
      </div>
      <h1 className="mt-4 text-xl font-bold tracking-tight text-foreground">Something went wrong</h1>
      <p className="mt-2 max-w-md text-pretty text-sm leading-relaxed text-muted-foreground">
        {error.message || "An unexpected error interrupted this view."}
      </p>
      <Button className="mt-6" onClick={() => reset()}>
        <IconRefresh size={15} />
        Try again
      </Button>
    </div>
  )
}
