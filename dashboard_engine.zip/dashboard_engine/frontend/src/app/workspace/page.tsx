"use client"

import Link from "next/link"
import { useEffect, useMemo, useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { PageHeader } from "@/components/layout/page-header"
import { useWorkspaceStore } from "@/lib/store/workspace-store"
import { useHubStore } from "@/lib/store/hub-store"
import { getBridge } from "@/lib/tauri/commands"
import type { WorkspaceLayout } from "@/lib/tauri/types"
import { WorkspaceContainer } from "@/components/workspace/workspace-container"
import { Button } from "@/components/ui/button"
import { EmptyState } from "@/components/ui/empty-state"
import { Card } from "@/components/ui/card"
import { Select } from "@/components/ui/select"
import { IconLayoutGrid, IconPlus } from "@/components/ui/icons"

export default function WorkspacePage() {
  const { layout, setLayout, addPanel, removePanel, setActivePanel, setOrientation } =
    useWorkspaceStore()
  const { dashboards, selectDashboard } = useHubStore()
  const [bridge] = useState(() => getBridge())
  const [pickedDashboard, setPickedDashboard] = useState("")

  // Load the persisted layout once; keep the local store when the backend has
  // nothing saved yet.
  useEffect(() => {
    let cancelled = false
    bridge
      .invoke<{ layout: WorkspaceLayout | null }>("workspace_get_layout", {})
      .then((res) => {
        if (cancelled) return
        if (res.ok && res.data?.layout) setLayout(res.data.layout)
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [bridge, setLayout])

  // Debounced persistence so resizing does not spam SQLite.
  useEffect(() => {
    if (!layout) return
    const timer = window.setTimeout(() => {
      void bridge.invoke("workspace_save_layout", { layout })
    }, 400)
    return () => window.clearTimeout(timer)
  }, [bridge, layout])

  const names = useMemo(
    () => Object.fromEntries(dashboards.map((dashboard) => [dashboard.id, dashboard.name])),
    [dashboards]
  )

  const available = dashboards.filter(
    (dashboard) => !layout?.panels.some((panel) => panel.dashboardId === dashboard.id)
  )

  if (!layout) {
    return (
      <AppShell>
        <div className="rounded-xl border border-border bg-card shadow-card">
          <EmptyState
            title="Workspace not initialized"
            description="The workspace layout could not be loaded. Reload the page to try again."
            icon={<IconLayoutGrid size={24} />}
          />
        </div>
      </AppShell>
    )
  }

  const handlePanelClick = (dashboardId: string) => {
    setActivePanel(dashboardId)
    selectDashboard(dashboardId)
  }

  const handleResize = (panelIndex: number, delta: number) => {
    if (!layout) return
    const next = [...layout.panels]
    next[panelIndex].ratio = Math.min(Math.max(next[panelIndex].ratio + delta, 0.15), 0.85)
    setLayout({ ...layout, panels: next, updated_at: new Date().toISOString() })
  }

  const handleAdd = () => {
    const id = pickedDashboard || available[0]?.id
    if (!id) return
    addPanel(id)
    setActivePanel(id)
    setPickedDashboard("")
  }

  return (
    <AppShell
      wide
      action={
        <Link href="/">
          <Button variant="secondary">
            <IconLayoutGrid size={15} />
            Browse hub
          </Button>
        </Link>
      }
    >
      <PageHeader
        eyebrow="Multi-view"
        title="Workspace"
        description="Arrange dashboards side by side. Each panel keeps its own route, filters, and query state."
        actions={
          <div
            className="inline-flex rounded-lg border border-border bg-card p-0.5 shadow-xs"
            role="group"
            aria-label="Workspace orientation"
          >
            {(["horizontal", "vertical"] as const).map((orientation) => {
              const active = layout.orientation === orientation
              return (
                <button
                  key={orientation}
                  type="button"
                  onClick={() => setOrientation(orientation)}
                  aria-pressed={active}
                  className={`cursor-pointer rounded-md px-3 py-1.5 text-xs font-semibold capitalize transition-colors ${
                    active
                      ? "bg-primary-soft text-primary"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {orientation}
                </button>
              )
            })}
          </div>
        }
      />

      {layout.panels.length === 0 ? (
        <Card padded={false}>
          <EmptyState
            title="No panels open"
            description="Add a dashboard to this workspace to compare views side by side. You can resize panels by dragging the divider."
            icon={<IconLayoutGrid size={24} />}
            actionLabel={dashboards.length > 0 ? "Add first dashboard" : undefined}
            action={dashboards.length > 0 ? () => handleAdd() : undefined}
          />
          {dashboards.length === 0 && (
            <div className="flex justify-center pb-8">
              <Link href="/create">
                <Button>
                  <IconPlus size={15} />
                  Create a dashboard
                </Button>
              </Link>
            </div>
          )}
        </Card>
      ) : (
        <Card padded={false} className="overflow-hidden">
          <div className="flex flex-col gap-3 border-b border-border/70 bg-surface-muted/40 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="font-semibold uppercase tracking-[0.08em]">Layout</span>
              <span aria-hidden="true">·</span>
              <span className="capitalize">{layout.orientation}</span>
              <span aria-hidden="true">·</span>
              <span className="tabular">
                {layout.panels.length} panel{layout.panels.length > 1 ? "s" : ""}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div className="w-full sm:w-56">
                <Select
                  aria-label="Dashboard to add"
                  value={pickedDashboard || available[0]?.id || ""}
                  onChange={(event) => setPickedDashboard(event.target.value)}
                  disabled={available.length === 0}
                >
                  {available.length === 0 ? (
                    <option value="">All dashboards added</option>
                  ) : (
                    available.map((dashboard) => (
                      <option key={dashboard.id} value={dashboard.id}>
                        {dashboard.name}
                      </option>
                    ))
                  )}
                </Select>
              </div>
              <Button size="sm" onClick={handleAdd} disabled={available.length === 0}>
                <IconPlus size={14} />
                Add panel
              </Button>
            </div>
          </div>

          <WorkspaceContainer
            panels={layout.panels}
            orientation={layout.orientation}
            activeId={layout.activeId}
            names={names}
            onPanelClick={handlePanelClick}
            onResize={handleResize}
            onClose={removePanel}
          />
        </Card>
      )}
    </AppShell>
  )
}
