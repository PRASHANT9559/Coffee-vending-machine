import Link from "next/link"
import { Button } from "@/components/ui/button"
import { IconArrowLeft, IconSearch } from "@/components/ui/icons"

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-border bg-card text-muted-foreground shadow-card">
        <IconSearch size={24} />
      </div>
      <p className="mt-4 text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
        404
      </p>
      <h1 className="mt-1 text-xl font-bold tracking-tight text-foreground">Page not found</h1>
      <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
        The page you are looking for does not exist or has moved.
      </p>
      <Link href="/" className="mt-6">
        <Button variant="secondary">
          <IconArrowLeft size={15} />
          Go to hub
        </Button>
      </Link>
    </div>
  )
}
