"use client"

import Link from "next/link"
import { useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { PageHeader } from "@/components/layout/page-header"
import { Alert } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardTitle } from "@/components/ui/card"
import { Field } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  IconArrowRight,
  IconChart,
  IconDatabase,
  IconShield,
  IconSparkles,
} from "@/components/ui/icons"
import { getBridge } from "@/lib/tauri/commands"

export default function CreatePage() {
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [icon, setIcon] = useState("")
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleCreate = async () => {
    if (!name.trim()) {
      setError("Dashboard name is required.")
      return
    }

    setSaving(true)
    setError(null)

    const res = await getBridge().invoke<{ dashboardId: string }>("dashboard_create", {
      name: name.trim(),
      description: description.trim(),
      icon: icon.trim() || undefined,
    })

    setSaving(false)

    if (!res.ok) {
      setError(res.error?.message ?? "Could not create dashboard.")
      return
    }

    const id = res.data?.dashboardId
    window.location.href = id ? `/dashboard?id=${encodeURIComponent(id)}` : "/"
  }

  return (
    <AppShell
      active="/create"
      action={
        <Link href="/">
          <Button variant="secondary">Cancel</Button>
        </Link>
      }
    >
      <PageHeader
        backHref="/"
        backLabel="Back to hub"
        eyebrow="New dashboard"
        title="Create a dashboard"
        description="Start with a name and description. You can connect data sources and generate views right after creation."
      />

      <form
        className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]"
        onSubmit={(event) => {
          event.preventDefault()
          void handleCreate()
        }}
      >
        <div className="space-y-4">
          <Card padded={false}>
            <div className="border-b border-border/70 p-5">
              <div className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-soft text-primary">
                  <IconSparkles size={16} />
                </span>
                <div>
                  <CardTitle>Identity</CardTitle>
                  <CardDescription>How this dashboard appears in the hub.</CardDescription>
                </div>
              </div>
            </div>

            <div className="space-y-5 p-5">
              <Field label="Dashboard name" htmlFor="dashboard-name" required>
                <Input
                  id="dashboard-name"
                  placeholder="E-Commerce Orders"
                  required
                  autoFocus
                  value={name}
                  onChange={(event) => {
                    setName(event.target.value)
                    if (error) setError(null)
                  }}
                  aria-invalid={Boolean(error) && !name.trim()}
                />
              </Field>

              <Field
                label="Description"
                htmlFor="dashboard-description"
                hint="A short sentence helps teammates pick the right dashboard."
              >
                <Textarea
                  id="dashboard-description"
                  rows={3}
                  placeholder="What this dashboard shows, who it is for, and which decisions it supports."
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                />
              </Field>

              <Field
                label="Icon or emoji"
                htmlFor="dashboard-icon"
                hint="Optional. Leave blank to use the default chart icon."
              >
                <Input
                  id="dashboard-icon"
                  placeholder="📦"
                  maxLength={4}
                  value={icon}
                  onChange={(event) => setIcon(event.target.value)}
                />
              </Field>
            </div>

            <div className="flex items-center justify-between gap-3 border-t border-border/70 bg-surface-muted/40 px-5 py-4">
              <Link
                href="/"
                className="text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Cancel
              </Link>
              <Button type="submit" disabled={saving}>
                {saving ? "Creating…" : "Create dashboard"}
                {!saving && <IconArrowRight size={15} />}
              </Button>
            </div>
          </Card>

          {error && <Alert title="Could not create dashboard">{error}</Alert>}

          <Card className="border-primary/15 bg-primary-soft/40">
            <div className="flex gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-card text-primary">
                <IconDatabase size={17} />
              </span>
              <div className="min-w-0">
                <p className="text-[13px] font-semibold text-foreground">Data sources come next</p>
                <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
                  Connection setup opens after creation. Credentials are resolved through your OS
                  keychain or environment — never stored in the dashboard file.
                </p>
                <Link
                  href="/settings"
                  className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
                >
                  Manage data sources in Settings
                  <IconArrowRight size={12} />
                </Link>
              </div>
            </div>
          </Card>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <Card padded={false} className="overflow-hidden">
            <div className="border-b border-border/70 px-5 py-3">
              <p className="eyebrow">Live preview</p>
            </div>
            <div className="p-5">
              <div className="rounded-xl border border-border bg-card p-4 shadow-xs">
                <div className="flex items-start justify-between gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-primary/10 bg-primary-soft text-primary">
                    {icon.trim() ? (
                      <span className="text-lg leading-none" aria-hidden="true">
                        {icon.trim().slice(0, 4)}
                      </span>
                    ) : (
                      <IconChart size={19} />
                    )}
                  </span>
                  <Badge variant="warning" dot>
                    Draft
                  </Badge>
                </div>
                <h3 className="mt-4 truncate text-[15px] font-semibold text-foreground">
                  {name.trim() || "Untitled dashboard"}
                </h3>
                <p className="mt-1.5 line-clamp-2 min-h-[2.5rem] text-[13px] leading-relaxed text-muted-foreground">
                  {description.trim() || "No description yet."}
                </p>
                <div className="mt-4 border-t border-border/70 pt-3 text-[11px] text-muted-foreground">
                  Just now
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-2">
              <IconShield size={16} className="text-success" />
              <p className="text-[13px] font-semibold text-foreground">Safe by default</p>
            </div>
            <ul className="mt-3 space-y-2 text-xs leading-relaxed text-muted-foreground">
              <li>Read-only analytics connections</li>
              <li>Secrets stay in the keychain</li>
              <li>Every query is bounded before execution</li>
            </ul>
          </Card>
        </aside>
      </form>
    </AppShell>
  )
}
