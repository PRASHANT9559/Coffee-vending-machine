export function Loading() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
      <div
        className="h-9 w-9 animate-spin rounded-full border-[3px] border-border border-t-primary"
        role="status"
        aria-label="Loading"
      />
      <p className="mt-4 text-sm text-muted-foreground">Loading…</p>
    </div>
  )
}

export default Loading
