"use client"

import { useEffect, useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { PageHeader } from "@/components/layout/page-header"
import { Alert } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Field } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Skeleton } from "@/components/common/loading-skeleton"
import { SettingsForm } from "@/components/settings/settings-form"
import { useTheme } from "@/components/theme-provider"
import {
  IconDatabase,
  IconHardDrive,
  IconPlus,
  IconShield,
  IconTrash,
  IconX,
} from "@/components/ui/icons"
import { getBridge } from "@/lib/tauri/commands"
import type { DataSource } from "@/lib/tauri/types"

type SettingsValues = {
  theme: "light" | "dark" | "system"
  density: "compact" | "comfortable" | "spacious"
  cacheSize: "16 MB" | "32 MB" | "64 MB"
  language: string
}

const defaults: SettingsValues = {
  theme: "system",
  density: "comfortable",
  cacheSize: "64 MB",
  language: "en",
}

const sections = [
  { id: "appearance", label: "Appearance" },
  { id: "cache", label: "Cache" },
  { id: "data-sources", label: "Data sources" },
  { id: "about", label: "About" },
]

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()
  const [values, setValues] = useState<SettingsValues>(defaults)

  const [dataSources, setDataSources] = useState<DataSource[]>([])
  const [dsLoading, setDsLoading] = useState(false)
  const [dsError, setDsError] = useState<string | null>(null)
  const [showAddForm, setShowAddForm] = useState(false)

  const [dsName, setDsName] = useState("")
  const [dsKind, setDsKind] = useState<"postgres" | "timescale">("postgres")
  const [dsHost, setDsHost] = useState("")
  const [dsPort, setDsPort] = useState("5432")
  const [dsDatabase, setDsDatabase] = useState("")
  const [dsUsername, setDsUsername] = useState("")
  const [dsSecretRef, setDsSecretRef] = useState("")
  const [dsSslMode, setDsSslMode] = useState("require")
  const [dsCreating, setDsCreating] = useState(false)

  useEffect(() => {
    setValues((prev) => ({ ...prev, theme }))
  }, [theme])

  const handleChange = (patch: Partial<SettingsValues>) => {
    setValues((prev) => ({ ...prev, ...patch }))
    if (patch.theme) setTheme(patch.theme)
  }

  const handleReset = () => {
    setValues(defaults)
    setTheme(defaults.theme)
  }

  const refreshDataSources = () => {
    setDsLoading(true)
    setDsError(null)
    getBridge()
      .invoke<{ items: DataSource[] }>("datasource_list", {})
      .then((res) => {
        setDsLoading(false)
        if (res.ok && res.data?.items) {
          setDataSources(res.data.items)
        } else {
          setDsError(res.error?.message ?? "Failed to load data sources")
        }
      })
      .catch(() => {
        setDsLoading(false)
        setDsError("Failed to connect to backend")
      })
  }

  useEffect(() => {
    refreshDataSources()
  }, [])

  const handleCreateDataSource = async () => {
    if (!dsName.trim() || !dsHost.trim() || !dsDatabase.trim() || !dsUsername.trim()) {
      setDsError("Name, host, database, and username are required.")
      return
    }
    setDsCreating(true)
    setDsError(null)

    // Backend DTOs are camelCase (`#[serde(rename_all = "camelCase")]`).
    const res = await getBridge().invoke<{ dataSourceId: string }>("datasource_create", {
      name: dsName.trim(),
      kind: dsKind,
      host: dsHost.trim(),
      port: parseInt(dsPort, 10) || 5432,
      databaseName: dsDatabase.trim(),
      username: dsUsername.trim(),
      secretRef: dsSecretRef.trim() || "keyring:default",
      sslMode: dsSslMode,
    })

    setDsCreating(false)
    if (!res.ok) {
      setDsError(res.error?.message ?? "Failed to create data source")
      return
    }

    setShowAddForm(false)
    setDsName("")
    setDsHost("")
    setDsDatabase("")
    setDsUsername("")
    setDsSecretRef("")
    refreshDataSources()
  }

  const handleDeleteDataSource = async (id: string) => {
    const target = dataSources.find((source) => source.id === id)
    if (
      !window.confirm(
        `Delete "${target?.name ?? id}"? Dashboards linked to it will lose the connection.`
      )
    ) {
      return
    }
    setDsError(null)
    const res = await getBridge().invoke<{ ok: boolean }>("datasource_delete", {
      dataSourceId: id,
    })
    if (!res.ok) {
      setDsError(res.error?.message ?? "Failed to delete data source")
      return
    }
    refreshDataSources()
  }

  return (
    <AppShell>
      <PageHeader
        eyebrow="Preferences"
        title="Settings"
        description="Tune the interface, local cache, and the read-only data sources this app can query."
      />

      <div className="grid gap-6 lg:grid-cols-[180px_minmax(0,1fr)]">
        <nav className="hidden lg:block" aria-label="Settings sections">
          <div className="sticky top-24 space-y-1">
            {sections.map((section) => (
              <a
                key={section.id}
                href={`#${section.id}`}
                className="block rounded-lg px-3 py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-card hover:text-foreground"
              >
                {section.label}
              </a>
            ))}
          </div>
        </nav>

        <div className="min-w-0 space-y-5">
          <Card id="appearance" padded={false} className="scroll-mt-24">
            <SectionHeading
              title="Appearance"
              description="Theme, density, and interface language."
            />
            <div className="p-5">
              <SettingsForm values={values} onChange={handleChange} onReset={handleReset} />
            </div>
          </Card>

          <Card id="cache" padded={false} className="scroll-mt-24">
            <SectionHeading
              title="Query cache"
              description="Local cache for query results on this device."
            />
            <div className="space-y-4 p-5">
              <div>
                <p className="field-label">Cache size</p>
                <div className="grid grid-cols-3 gap-2">
                  {(["16 MB", "32 MB", "64 MB"] as const).map((size) => {
                    const active = values.cacheSize === size
                    return (
                      <button
                        key={size}
                        type="button"
                        onClick={() => handleChange({ cacheSize: size })}
                        aria-pressed={active}
                        className={`cursor-pointer rounded-lg border px-3 py-2.5 text-[13px] font-semibold transition-colors ${
                          active
                            ? "border-primary/40 bg-primary-soft text-primary"
                            : "border-border bg-card text-muted-foreground hover:bg-surface-muted hover:text-foreground"
                        }`}
                      >
                        {size}
                      </button>
                    )
                  })}
                </div>
                <p className="field-hint">Larger values use more memory but keep more results warm.</p>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-surface-muted/50 px-4 py-3">
                <div className="flex items-center gap-2 text-[13px] text-foreground">
                  <IconHardDrive size={16} className="text-muted-foreground" />
                  Cache status
                </div>
                <Badge variant="success" dot>
                  Healthy
                </Badge>
              </div>

              <Button variant="secondary" className="w-full" disabled title="Cache controls are not wired yet">
                Clear query cache
              </Button>
            </div>
          </Card>

          <Card id="data-sources" padded={false} className="scroll-mt-24">
            <SectionHeading
              title="Data sources"
              description="Read-only connections. Secrets are resolved through your OS keychain or environment."
              action={
                <Button
                  variant={showAddForm ? "secondary" : "primary"}
                  size="sm"
                  onClick={() => setShowAddForm((open) => !open)}
                >
                  {showAddForm ? <IconX size={14} /> : <IconPlus size={14} />}
                  {showAddForm ? "Close" : "Add source"}
                </Button>
              }
            />

            <div className="space-y-4 p-5">
              {dsError && <Alert title="Data source error">{dsError}</Alert>}

              {showAddForm && (
                <div className="rounded-xl border border-border bg-surface-muted/40 p-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Name" htmlFor="ds-name" required>
                      <Input
                        id="ds-name"
                        placeholder="Production warehouse"
                        value={dsName}
                        onChange={(e) => setDsName(e.target.value)}
                      />
                    </Field>
                    <Field label="Kind" htmlFor="ds-kind">
                      <Select
                        id="ds-kind"
                        value={dsKind}
                        onChange={(e) => setDsKind(e.target.value as "postgres" | "timescale")}
                      >
                        <option value="postgres">PostgreSQL</option>
                        <option value="timescale">TimescaleDB</option>
                      </Select>
                    </Field>
                    <Field label="Host" htmlFor="ds-host" required>
                      <Input
                        id="ds-host"
                        placeholder="db.internal.example"
                        value={dsHost}
                        onChange={(e) => setDsHost(e.target.value)}
                      />
                    </Field>
                    <Field label="Port" htmlFor="ds-port">
                      <Input
                        id="ds-port"
                        type="number"
                        placeholder="5432"
                        value={dsPort}
                        onChange={(e) => setDsPort(e.target.value)}
                      />
                    </Field>
                    <Field label="Database" htmlFor="ds-database" required>
                      <Input
                        id="ds-database"
                        placeholder="analytics"
                        value={dsDatabase}
                        onChange={(e) => setDsDatabase(e.target.value)}
                      />
                    </Field>
                    <Field label="Username" htmlFor="ds-username" required>
                      <Input
                        id="ds-username"
                        placeholder="readonly_user"
                        value={dsUsername}
                        onChange={(e) => setDsUsername(e.target.value)}
                      />
                    </Field>
                    <Field
                      label="Secret reference"
                      htmlFor="ds-secret"
                      hint="Example: keyring:prod_warehouse"
                    >
                      <Input
                        id="ds-secret"
                        placeholder="keyring:default"
                        value={dsSecretRef}
                        onChange={(e) => setDsSecretRef(e.target.value)}
                      />
                    </Field>
                    <Field label="SSL mode" htmlFor="ds-ssl">
                      <Select
                        id="ds-ssl"
                        value={dsSslMode}
                        onChange={(e) => setDsSslMode(e.target.value)}
                      >
                        <option value="require">Require</option>
                        <option value="verify-full">Verify full</option>
                        <option value="prefer">Prefer</option>
                        <option value="disable">Disable</option>
                      </Select>
                    </Field>
                  </div>
                  <div className="mt-4 flex items-center justify-between gap-3">
                    <p className="text-xs text-muted-foreground">
                      Plain-text secrets are never stored in this dashboard file.
                    </p>
                    <Button onClick={() => void handleCreateDataSource()} disabled={dsCreating}>
                      {dsCreating ? "Creating…" : "Add source"}
                    </Button>
                  </div>
                </div>
              )}

              {dsLoading ? (
                <div className="space-y-2" aria-busy="true" aria-label="Loading data sources">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-3/4" />
                </div>
              ) : dataSources.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border px-4 py-10 text-center">
                  <span className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-primary-soft text-primary">
                    <IconDatabase size={20} />
                  </span>
                  <p className="text-[13px] font-semibold text-foreground">No data sources yet</p>
                  <p className="mt-1 max-w-xs text-xs leading-relaxed text-muted-foreground">
                    Add a read-only connection so dashboards can discover tables and run bounded queries.
                  </p>
                </div>
              ) : (
                <div className="table-shell">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Kind</th>
                        <th>Host</th>
                        <th>Database</th>
                        <th>User</th>
                        <th className="text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataSources.map((source) => (
                        <tr key={source.id}>
                          <td className="font-medium">
                            <div className="flex items-center gap-2">
                              <IconDatabase size={14} className="text-muted-foreground" />
                              <span className="truncate">{source.name}</span>
                            </div>
                          </td>
                          <td>
                            <Badge variant="primary">{source.kind}</Badge>
                          </td>
                          <td className="whitespace-nowrap font-mono text-xs text-muted-foreground">
                            {source.host}:{source.port}
                          </td>
                          <td className="text-muted-foreground">{source.database_name}</td>
                          <td className="text-muted-foreground">{source.username}</td>
                          <td className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => void handleDeleteDataSource(source.id)}
                              className="text-danger hover:bg-danger-soft hover:text-danger"
                            >
                              <IconTrash size={14} />
                              Delete
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="flex items-start gap-2 rounded-lg border border-border bg-card px-3 py-2.5 text-xs text-muted-foreground">
                <IconShield size={15} className="mt-0.5 shrink-0 text-success" />
                <span>
                  Connections are read-only by default. Credentials are referenced, never embedded in
                  dashboard files.
                </span>
              </div>
            </div>
          </Card>

          <Card id="about" padded={false} className="scroll-mt-24">
            <SectionHeading title="About" description="Build information for this app." />
            <dl className="divide-y divide-border/70 text-[13px]">
              {[
                ["Application", "Universal UI & Auto-Dashboard Engine"],
                ["Frontend", "v0.1.0"],
                ["Stack", "Next.js · Tailwind · Tauri"],
                ["Theme", values.theme],
                ["Density", values.density],
              ].map(([label, value]) => (
                <div key={label} className="flex items-center justify-between gap-4 px-5 py-3">
                  <dt className="text-muted-foreground">{label}</dt>
                  <dd className="text-right font-medium text-foreground">{value}</dd>
                </div>
              ))}
            </dl>
          </Card>
        </div>
      </div>
    </AppShell>
  )
}

function SectionHeading({
  title,
  description,
  action,
}: {
  title: string
  description?: string
  action?: React.ReactNode
}) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-border/70 px-5 py-4">
      <div className="min-w-0">
        <h2 className="text-[15px] font-semibold tracking-tight text-foreground">{title}</h2>
        {description && (
          <p className="mt-0.5 text-[13px] leading-relaxed text-muted-foreground">{description}</p>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  )
}
