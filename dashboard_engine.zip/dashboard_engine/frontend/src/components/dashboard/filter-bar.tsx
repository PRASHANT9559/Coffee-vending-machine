export interface FilterControl {
  key: string;
  label: string;
  type: "text" | "select" | "date" | "number" | "boolean";
  options?: Array<{ label: string; value: string | number }>;
}

export interface FilterBarProps {
  filters: FilterControl[];
  values: Record<string, unknown>;
  onChange: (key: string, value: unknown) => void;
  onReset: () => void;
  className?: string;
}

export function FilterBar({
  filters,
  values,
  onChange,
  onReset,
  className = "",
}: FilterBarProps) {
  const hasActive = Object.values(values).some(
    (v) => v !== undefined && v !== null && v !== ""
  );

  return (
    <div
      className={`rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 ${className}`}
    >
      <div className="flex flex-col sm:flex-row gap-3">
        {filters.map((filter) => {
          const isActive =
            values[filter.key] !== undefined &&
            values[filter.key] !== null &&
            values[filter.key] !== "";
          return (
            <div key={filter.key} className="flex-1 min-w-[140px]">
              <label className="block text-xs font-semibold text-[var(--text-main)] mb-1">
                {filter.label}
              </label>
              {filter.type === "select" && filter.options ? (
                <select
                  value={String(values[filter.key] ?? "")}
                  onChange={(e) => onChange(filter.key, e.target.value)}
                  className="w-full rounded-md border border-[var(--border-color)] bg-[var(--page-bg)] px-3 py-2 text-sm text-[var(--text-main)] focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]"
                >
                  <option value="">All</option>
                  {filter.options.map((opt) => (
                    <option key={String(opt.value)} value={String(opt.value)}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type={filter.type === "number" ? "number" : filter.type}
                  placeholder={filter.label}
                  value={String(values[filter.key] ?? "")}
                  onChange={(e) => onChange(filter.key, e.target.value)}
                  className="w-full rounded-md border border-[var(--border-color)] bg-[var(--page-bg)] px-3 py-2 text-sm text-[var(--text-main)] focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]"
                />
              )}
              {isActive && (
                <button
                  type="button"
                  onClick={() => onChange(filter.key, "")}
                  className="mt-1 text-[10px] text-[#DC2626] underline decoration-[1px]"
                >
                  Clear
                </button>
              )}
            </div>
          );
        })}
      </div>
      <div className="flex items-center gap-2">
        {hasActive && (
          <button
            type="button"
            onClick={onReset}
            className="rounded-md px-3 py-2 text-xs font-medium text-[#DC2626] hover:bg-[#FEF2F2] transition-colors"
          >
            Reset filters
          </button>
        )}
        <button
          type="button"
          className="rounded-md bg-[var(--brand-primary)] px-3 py-2 text-xs font-medium text-[var(--page-bg)] transition-colors hover:opacity-90"
        >
          Apply
        </button>
      </div>
    </div>
  );
}
