"use client"

import Link from "next/link"
import { useCallback, useEffect, useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { EmptyState } from "@/components/ui/empty-state"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/common/loading-skeleton"
import { TopBar } from "@/components/dashboard/top-bar"
import { Sidebar } from "@/components/dashboard/sidebar"
import { PageRenderer, type BindingRenderState } from "@/components/dashboard/page-renderer"
import { IconAlert, IconFile, IconLayoutGrid, IconRefresh } from "@/components/ui/icons"
import { useHubStore } from "@/lib/store/hub-store"
import { getBridge } from "@/lib/tauri/commands"
import type { Dashboard, QueryResult, UiIrDocument } from "@/lib/tauri/types"

interface DashboardGetData {
  dashboard: Dashboard
  uiir: UiIrDocument | null
}

export function DashboardDetail({ id }: { id: string }) {
  const { dashboards, selectDashboard } = useHubStore()
  const [dashboard, setDashboard] = useState<Dashboard | null>(
    () => dashboards.find((d) => d.id === id) ?? null
  )
  const [ir, setIr] = useState<UiIrDocument | null>(null)
  const [routeId, setRouteId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dataByBinding, setDataByBinding] = useState<Record<string, BindingRenderState>>({})

  useEffect(() => {
    selectDashboard(id)
  }, [id, selectDashboard])

  /**
   * Execute one bounded read-only query per table-backed component. Results
   * are keyed by component id so generated drafts (no explicit bindings) and
   * hand-authored bindings both work.
   */
  const loadData = useCallback(
    async (doc: UiIrDocument | null) => {
      if (!doc) return
      const tables = doc.dashboard.components.filter(
        (component) =>
          component.type === "data-table" && typeof component.props?.table === "string"
      )
      if (tables.length === 0) return

      const loadingState: Record<string, BindingRenderState> = {}
      for (const component of tables) {
        loadingState[component.id] = { status: "loading" }
      }
      setDataByBinding((prev) => ({ ...prev, ...loadingState }))

      await Promise.all(
        tables.map(async (component) => {
          const table = String(component.props.table)
          const res = await getBridge().invoke<QueryResult>("query_execute", {
            dashboardId: id,
            queryId: table,
          })
          setDataByBinding((prev) => ({
            ...prev,
            [component.id]:
              res.ok && res.data
                ? { status: "ok", data: res.data.rows }
                : {
                    status: "error",
                    error: {
                      code: res.error?.code ?? "INTERNAL",
                      message: res.error?.message ?? "Query failed.",
                    },
                  },
          }))
        })
      )
    },
    [id]
  )

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    setError(null)

    getBridge()
      .invoke<DashboardGetData>("dashboard_get", { dashboardId: id })
      .then((res) => {
        if (cancelled) return

        if (!res.ok || !res.data) {
          setError(res.error?.message ?? "Could not load dashboard.")
          setLoading(false)
          return
        }

        const doc = res.data.uiir
        setDashboard(res.data.dashboard)
        setIr(doc)
        // Keep the active route as a route id so the sidebar highlight and the
        // rendered page always agree.
        setRouteId(doc?.dashboard.routes[0]?.id ?? null)
        setLoading(false)
        void loadData(doc)
      })
      .catch((err) => {
        if (cancelled) return
        setError(String(err))
        setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [id, loadData])

  if (loading) {
    return (
      <AppShell active="/" wide>
        <div className="mb-4 flex items-center justify-between">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-9 w-28" />
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <Skeleton className="h-28 rounded-xl" />
          <Skeleton className="h-28 rounded-xl" />
          <Skeleton className="h-28 rounded-xl" />
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
        <div className="mt-4">
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </AppShell>
    )
  }

  if (error) {
    return (
      <AppShell active="/">
        <div className="rounded-xl border border-border bg-card shadow-card">
          <EmptyState
            title="Could not load dashboard"
            description={error}
            icon={<IconAlert size={24} />}
          />
          <div className="flex justify-center pb-8">
            <Link href="/">
              <Button variant="secondary">
                <IconLayoutGrid size={15} />
                Back to hub
              </Button>
            </Link>
          </div>
        </div>
      </AppShell>
    )
  }

  if (!dashboard) {
    return (
      <AppShell active="/">
        <div className="rounded-xl border border-border bg-card shadow-card">
          <EmptyState
            title="Dashboard not found"
            description="This dashboard is not in the hub list. Open it from the hub or create a new one."
            icon={<IconFile size={24} />}
          />
          <div className="flex justify-center pb-8">
            <Link href="/">
              <Button variant="secondary">
                <IconLayoutGrid size={15} />
                Back to hub
              </Button>
            </Link>
          </div>
        </div>
      </AppShell>
    )
  }

  if (!ir) {
    return (
      <AppShell active="/" wide>
        <div className="mb-4 flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">{dashboard.name}</h1>
          <Link href="/">
            <Button variant="secondary" size="sm">
              Back to hub
            </Button>
          </Link>
        </div>
        <div className="rounded-xl border border-border bg-card shadow-card">
          <EmptyState
            title="No dashboard configuration"
            description="Run schema discovery or configure this dashboard to generate its first view."
            icon={<IconFile size={24} />}
          />
        </div>
      </AppShell>
    )
  }

  const navItems = ir.dashboard.navigation?.groups?.flatMap((group) => group.items) ?? []
  const activeItem = navItems.find((item) => item.routeId === routeId)

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <TopBar
        title={dashboard.name}
        dashboardId={id}
        status={dashboard.status}
        onRefresh={() => void loadData(ir)}
      />
      <div className="mx-auto flex w-full max-w-[1500px] flex-1">
        <Sidebar navItems={navItems} activeRoute={routeId} onNavClick={setRouteId} />
        <main className="min-w-0 flex-1 p-3 sm:p-4 lg:p-6">
          <div className="no-scrollbar mb-4 flex items-center gap-1 overflow-x-auto pb-1 lg:hidden">
            {navItems.map((item) => {
              const isActive = routeId === item.routeId
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setRouteId(item.routeId)}
                  className={`inline-flex h-8 shrink-0 cursor-pointer items-center gap-1.5 rounded-lg px-3 text-xs font-medium transition-colors ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "border border-border bg-card text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {item.icon && <span aria-hidden="true">{item.icon}</span>}
                  {item.label}
                </button>
              )
            })}
          </div>
          <PageRenderer
            ir={ir.dashboard}
            panelState={{ routeId, filters: {} }}
            onDataRequest={() => void loadData(ir)}
            dataByBinding={dataByBinding}
          />
        </main>
      </div>
      <div className="border-t border-border/60 px-4 py-3 text-[11px] text-muted-foreground">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-3">
          <span className="truncate">
            {dashboard.name}
            {activeItem ? ` · ${activeItem.label}` : ""}
          </span>
          <button
            type="button"
            onClick={() => void loadData(ir)}
            className="inline-flex cursor-pointer items-center gap-1 font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <IconRefresh size={12} />
            Refresh data
          </button>
        </div>
      </div>
    </div>
  )
}
