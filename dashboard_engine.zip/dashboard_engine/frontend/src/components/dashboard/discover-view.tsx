"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { PageHeader } from "@/components/layout/page-header"
import { useHubStore } from "@/lib/store/hub-store"
import { Alert } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { EmptyState } from "@/components/ui/empty-state"
import { Field } from "@/components/ui/field"
import { Select } from "@/components/ui/select"
import {
  IconDatabase,
  IconFile,
  IconRefresh,
  IconSearch,
  IconTable,
} from "@/components/ui/icons"
import { getBridge } from "@/lib/tauri/commands"
import type { DataSource } from "@/lib/tauri/types"

interface DiscoverInspectResponse {
  snapshotId: string
  fingerprint: string
  status: string
  tableCount: number
  relationshipCount: number
  warnings: string[]
}

export function DiscoverView({ id }: { id: string }) {
  const { dashboards } = useHubStore()
  const dashboard = dashboards.find((d) => d.id === id)
  const [dataSources, setDataSources] = useState<DataSource[]>([])
  const [selectedSourceId, setSelectedSourceId] = useState<string | null>(null)
  const [discovering, setDiscovering] = useState(false)
  const [result, setResult] = useState<DiscoverInspectResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    getBridge()
      .invoke<{ items: DataSource[] }>("datasource_list", {})
      .then((res) => {
        if (cancelled) return
        if (res.ok && res.data?.items) {
          setDataSources(res.data.items)
          setSelectedSourceId((current) => current ?? res.data?.items?.[0]?.id ?? null)
        }
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [])

  const handleDiscover = async () => {
    if (!selectedSourceId) {
      setError("No data source selected.")
      return
    }
    setDiscovering(true)
    setError(null)
    setResult(null)

    const res = await getBridge().invoke<DiscoverInspectResponse>("discovery_inspect", {
      dashboardId: id,
      dataSourceId: selectedSourceId,
    })

    setDiscovering(false)
    if (!res.ok) {
      setError(res.error?.message ?? "Discovery failed.")
      return
    }
    setResult(res.data ?? null)
  }

  if (!dashboard) {
    return (
      <AppShell active="/">
        <div className="rounded-xl border border-border bg-card shadow-card">
          <EmptyState
            title="Dashboard not found"
            description="Open the dashboard from the hub before running discovery."
            icon={<IconSearch size={24} />}
          />
          <div className="flex justify-center pb-8">
            <Link href="/">
              <Button variant="secondary">Back to hub</Button>
            </Link>
          </div>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell active="/">
      <PageHeader
        backHref={`/dashboard?id=${encodeURIComponent(id)}`}
        backLabel="Back to dashboard"
        eyebrow="Schema discovery"
        title="Inspect your database"
        description={`Discover tables, views, columns, keys, and relationships for ${dashboard.name}.`}
        actions={
          <Button onClick={() => void handleDiscover()} disabled={discovering || !selectedSourceId}>
            <IconRefresh size={15} />
            {discovering ? "Discovering…" : "Run discovery"}
          </Button>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-4">
          <Card>
            <Field
              label="Data source"
              htmlFor="discover-source"
              hint={
                dataSources.length === 0
                  ? "Configure a data source in Settings before running discovery."
                  : "Discovery only reads schema metadata. Your data is never modified."
              }
            >
              <Select
                id="discover-source"
                value={selectedSourceId ?? ""}
                onChange={(event) => setSelectedSourceId(event.target.value || null)}
                disabled={dataSources.length === 0}
              >
                {dataSources.length === 0 ? (
                  <option value="">No data sources configured</option>
                ) : (
                  dataSources.map((source) => (
                    <option key={source.id} value={source.id}>
                      {source.name} ({source.kind})
                    </option>
                  ))
                )}
              </Select>
            </Field>
          </Card>

          {error && <Alert title="Discovery failed">{error}</Alert>}

          {result ? (
            <Card padded={false} className="animate-slide-up">
              <div className="flex items-center justify-between gap-3 border-b border-border/70 px-5 py-4">
                <div>
                  <h2 className="text-[15px] font-semibold text-foreground">Discovery result</h2>
                  <p className="mt-0.5 text-[13px] text-muted-foreground">
                    Snapshot is ready to generate dashboard views.
                  </p>
                </div>
                <Badge variant={result.status === "ok" ? "success" : "warning"} dot>
                  {result.status}
                </Badge>
              </div>

              <div className="grid gap-3 p-5 sm:grid-cols-2">
                <ResultStat
                  label="Tables"
                  value={String(result.tableCount)}
                  icon={<IconTable size={16} />}
                />
                <ResultStat
                  label="Relationships"
                  value={String(result.relationshipCount)}
                  icon={<IconDatabase size={16} />}
                />
              </div>

              <div className="border-t border-border/70 px-5 py-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
                  Fingerprint
                </p>
                <p className="mt-1 break-all font-mono text-xs text-foreground">
                  {result.fingerprint || result.snapshotId}
                </p>
              </div>

              {result.warnings.length > 0 && (
                <div className="border-t border-border/70 px-5 py-4">
                  <Alert variant="warning" title="Warnings">
                    <ul className="list-inside list-disc space-y-1">
                      {result.warnings.map((warning) => (
                        <li key={warning}>{warning}</li>
                      ))}
                    </ul>
                  </Alert>
                </div>
              )}
            </Card>
          ) : (
            !error && (
              <Card padded={false}>
                <EmptyState
                  title={
                    dataSources.length > 0
                      ? "Run discovery to inspect the database"
                      : "No data source configured"
                  }
                  description={
                    dataSources.length > 0
                      ? "Discovery inspects tables, views, columns, keys, constraints, and indexes. It then proposes a dashboard layout based on the schema."
                      : "Add a read-only connection in Settings, then return here to inspect its schema."
                  }
                  icon={<IconSearch size={24} />}
                  actionLabel={dataSources.length === 0 ? "Open settings" : undefined}
                  action={
                    dataSources.length === 0
                      ? () => {
                          window.location.href = "/settings#data-sources"
                        }
                      : undefined
                  }
                />
              </Card>
            )
          )}
        </div>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <Card>
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-soft text-primary">
                <IconFile size={16} />
              </span>
              <p className="text-[13px] font-semibold text-foreground">What discovery does</p>
            </div>
            <ul className="mt-3 space-y-2 text-xs leading-relaxed text-muted-foreground">
              <li>Reads schema metadata and constraints</li>
              <li>Builds a snapshot for layout generation</li>
              <li>Never modifies tables or rows</li>
              <li>Keeps a fingerprint for change detection</li>
            </ul>
          </Card>

          <div className="rounded-lg border border-border bg-card px-4 py-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
              Dashboard
            </p>
            <p className="mt-1 truncate text-[13px] font-medium text-foreground">{dashboard.name}</p>
            <p className="mt-0.5 text-xs capitalize text-muted-foreground">{dashboard.status}</p>
          </div>
        </aside>
      </div>
    </AppShell>
  )
}

function ResultStat({
  label,
  value,
  icon,
}: {
  label: string
  value: string
  icon: React.ReactNode
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border bg-surface-muted/40 p-3">
      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-card text-primary shadow-xs">
        {icon}
      </span>
      <div>
        <p className="text-[11px] font-medium uppercase tracking-[0.06em] text-muted-foreground">
          {label}
        </p>
        <p className="text-lg font-bold leading-tight text-foreground tabular">{value}</p>
      </div>
    </div>
  )
}
