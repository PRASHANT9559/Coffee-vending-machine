import type { CSSProperties } from "react";
import type { UiIrComponent, UiIrPage, UiIrRoute } from "@/lib/tauri/types";
import { renderComponent, type RenderContext } from "@/lib/uiir/renderer";
import { IconFile } from "@/components/ui/icons";

export interface BindingRenderState {
  status: RenderContext["status"];
  data?: unknown;
  error?: { code: string; message: string };
}

export function PageRenderer({
  ir,
  panelState,
  dataByBinding,
}: {
  ir: {
    routes: UiIrRoute[];
    pages: UiIrPage[];
    components: UiIrComponent[];
  };
  panelState: { routeId: string | null; filters: Record<string, unknown> };
  onDataRequest: (bindingId: string) => void;
  dataByBinding?: Record<string, BindingRenderState>;
}) {
  // `routeId` is a route id (not a page id). Resolve it through the route
  // table so sidebar navigation and page rendering cannot drift apart.
  const activeRoute = panelState.routeId
    ? ir.routes.find((route) => route.id === panelState.routeId)
    : undefined;
  const activePage =
    (activeRoute && ir.pages.find((page) => page.id === activeRoute.pageId)) ??
    ir.pages[0];

  if (!activePage) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card py-16 text-center">
        <IconFile size={22} className="text-muted-foreground/60" />
        <p className="mt-2 text-sm text-muted-foreground">No page found</p>
      </div>
    );
  }

  const columns = Math.max(activePage.layout.columns || 1, 1);
  const gridStyle = { "--ir-columns": columns } as CSSProperties;

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-end justify-between gap-3 border-b border-border pb-3">
        <div className="min-w-0">
          <p className="eyebrow">View</p>
          <h1 className="mt-1 truncate text-xl font-bold tracking-tight text-foreground">
            {activePage.title}
          </h1>
        </div>
        <span className="shrink-0 text-[11px] text-muted-foreground tabular">
          {activePage.layout.rows.reduce((count, row) => count + row.items.length, 0)} blocks
        </span>
      </div>

      {activePage.layout.rows.map((row) => (
        <div key={row.id} className="ir-grid" style={gridStyle}>
          {row.items.map((item) => {
            const component = ir.components.find((c) => c.id === item.componentId);

            if (!component) {
              return (
                <div
                  key={item.componentId}
                  style={{ "--ir-span": clampSpan(item.span, columns) } as CSSProperties}
                  className="rounded-xl border border-dashed border-border bg-card p-4 text-xs text-muted-foreground"
                >
                  Missing component: {item.componentId}
                </div>
              );
            }

            // Generated components may be bound directly by id when there is
            // no explicit UI-IR binding (schema-driven drafts).
            const bindingId = component.bindingId;
            const bindingState = bindingId
              ? dataByBinding?.[bindingId]
              : dataByBinding?.[component.id];

            return (
              <div
                key={component.id}
                style={{ "--ir-span": clampSpan(item.span, columns) } as CSSProperties}
                className="min-w-0"
              >
                {renderComponent({
                  component,
                  data: bindingState?.data,
                  status: bindingState?.status ?? "idle",
                  error: bindingState?.error,
                })}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function clampSpan(span: number, columns: number): number {
  if (!Number.isFinite(span) || span < 1) return 1;
  return Math.min(Math.round(span), columns);
}
