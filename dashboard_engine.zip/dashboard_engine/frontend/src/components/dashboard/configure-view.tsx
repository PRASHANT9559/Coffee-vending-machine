"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { PageHeader } from "@/components/layout/page-header"
import { useHubStore } from "@/lib/store/hub-store"
import { Alert } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { EmptyState } from "@/components/ui/empty-state"
import { Field } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { IconDatabase, IconFile, IconShield } from "@/components/ui/icons"
import { getBridge } from "@/lib/tauri/commands"

export function ConfigureView({ id }: { id: string }) {
  const { dashboards, selectDashboard } = useHubStore()
  const dashboard = dashboards.find((d) => d.id === id)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [name, setName] = useState(dashboard?.name ?? "")
  const [description, setDescription] = useState(dashboard?.description ?? "")
  const [icon, setIcon] = useState("")

  useEffect(() => {
    if (dashboard) {
      setName(dashboard.name)
      setDescription(dashboard.description ?? "")
    }
  }, [dashboard])

  const handleSave = async () => {
    if (!name.trim()) {
      setError("Dashboard name is required.")
      return
    }
    setSaving(true)
    setError(null)

    const bridge = getBridge()
    const res = await bridge.invoke<{ dashboardId: string; revision: number }>(
      "dashboard_save",
      {
        dashboardId: id,
        name: name.trim(),
        description: description.trim() || undefined,
      }
    )

    setSaving(false)

    if (!res.ok) {
      setError(res.error?.message ?? "Could not save dashboard.")
      return
    }

    selectDashboard(id)
    window.location.href = `/dashboard?id=${encodeURIComponent(id)}`
  }

  if (!dashboard) {
    return (
      <AppShell active="/">
        <div className="rounded-xl border border-border bg-card shadow-card">
          <EmptyState
            title="Dashboard not found"
            description="Open the dashboard from the hub before configuring it."
            icon={<IconFile size={24} />}
          />
          <div className="flex justify-center pb-8">
            <Link href="/">
              <Button variant="secondary">Back to hub</Button>
            </Link>
          </div>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell active="/">
      <PageHeader
        backHref={`/dashboard?id=${encodeURIComponent(id)}`}
        backLabel="Back to dashboard"
        eyebrow="Dashboard settings"
        title="Configure dashboard"
        description={`Update identity and connection settings for ${dashboard.name}.`}
        actions={
          <Button variant="secondary" onClick={() => void handleSave()} disabled={saving}>
            {saving ? "Saving…" : "Save changes"}
          </Button>
        }
      />

      <form
        className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_300px]"
        onSubmit={(event) => {
          event.preventDefault()
          void handleSave()
        }}
      >
        <div className="space-y-4">
          <Card padded={false}>
            <div className="border-b border-border/70 px-5 py-4">
              <h2 className="text-[15px] font-semibold text-foreground">Identity</h2>
              <p className="mt-0.5 text-[13px] text-muted-foreground">
                How this dashboard appears in the hub and navigation.
              </p>
            </div>
            <div className="grid gap-4 p-5 sm:grid-cols-2">
              <Field label="Dashboard name" htmlFor="configure-name" required className="sm:col-span-2">
                <Input
                  id="configure-name"
                  required
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                />
              </Field>
              <Field label="Description" htmlFor="configure-description" className="sm:col-span-2">
                <Textarea
                  id="configure-description"
                  rows={3}
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                />
              </Field>
              <Field label="Icon or emoji" htmlFor="configure-icon" hint="Optional short glyph shown on the hub card.">
                <Input
                  id="configure-icon"
                  maxLength={4}
                  placeholder="📊"
                  value={icon}
                  onChange={(event) => setIcon(event.target.value)}
                />
              </Field>
            </div>
          </Card>

          <Card padded={false}>
            <div className="border-b border-border/70 px-5 py-4">
              <h2 className="text-[15px] font-semibold text-foreground">Data source</h2>
              <p className="mt-0.5 text-[13px] text-muted-foreground">
                Bounded, read-only access to the connected warehouse.
              </p>
            </div>
            <div className="grid gap-4 p-5 sm:grid-cols-2">
              <Field label="Adapter" htmlFor="configure-adapter">
                <Select id="configure-adapter" defaultValue="postgres">
                  <option value="postgres">PostgreSQL</option>
                  <option value="timescale">TimescaleDB</option>
                </Select>
              </Field>
              <Field label="Allowed schemas" htmlFor="configure-schemas">
                <Input id="configure-schemas" defaultValue='["public"]' />
              </Field>
            </div>
            <div className="flex items-start gap-2 border-t border-border/70 bg-surface-muted/40 px-5 py-3 text-xs text-muted-foreground">
              <IconShield size={15} className="mt-0.5 shrink-0 text-success" />
              Credentials are managed outside this dashboard via your OS keychain or environment.
            </div>
          </Card>

          <Card padded={false}>
            <div className="border-b border-border/70 px-5 py-4">
              <h2 className="text-[15px] font-semibold text-foreground">Permissions</h2>
              <p className="mt-0.5 text-[13px] text-muted-foreground">
                Generated queries always run in read-only mode.
              </p>
            </div>
            <div className="p-5">
              <Field label="Operation mode" htmlFor="configure-mode">
                <Select id="configure-mode" defaultValue="read">
                  <option value="read">Read-only analytics</option>
                </Select>
              </Field>
            </div>
          </Card>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <Card>
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-soft text-primary">
                <IconDatabase size={16} />
              </span>
              <p className="text-[13px] font-semibold text-foreground">About this dashboard</p>
            </div>
            <dl className="mt-3 space-y-2 text-xs">
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">Status</dt>
                <dd className="font-medium capitalize text-foreground">{dashboard.status}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">Revision</dt>
                <dd className="font-medium text-foreground tabular">{dashboard.current_rev}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">IR version</dt>
                <dd className="font-medium text-foreground">{dashboard.ir_version ?? "—"}</dd>
              </div>
            </dl>
          </Card>

          {error && <Alert title="Could not save">{error}</Alert>}

          <div className="flex flex-col gap-2">
            <Link href={`/dashboard?id=${encodeURIComponent(id)}`} className="w-full">
              <Button variant="secondary" type="button" className="w-full">
                Cancel
              </Button>
            </Link>
          </div>
        </aside>
      </form>
    </AppShell>
  )
}
