export interface ChartProps {
  title?: string
  type: "line" | "bar" | "pie"
  data: unknown
  status: "idle" | "loading" | "ok" | "error" | "stale"
  error?: { code: string; message: string }
  maxPoints?: number
  maxBars?: number
}

const PALETTE = [
  "var(--primary)",
  "var(--accent)",
  "var(--success)",
  "#7c3aed",
  "#0891b2",
  "#db2777",
  "#65a30d",
  "#ea580c",
]

const numberFormat = new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 })

function toPoints(data: unknown): Array<{ label: string; value: number }> {
  if (!Array.isArray(data)) return []
  return data
    .map((row: any, index) => {
      if (row && typeof row === "object") {
        const label = row.label !== undefined ? String(row.label) : String(index + 1)
        const raw = row.value ?? row.count ?? row.total
        const value = Number(raw)
        return { label, value: Number.isFinite(value) ? value : 0 }
      }
      const value = Number(row)
      return { label: String(index + 1), value: Number.isFinite(value) ? value : 0 }
    })
    .filter((row) => row.label.length > 0)
}

function donutPath(cx: number, cy: number, rOuter: number, rInner: number, start: number, end: number) {
  const polar = (r: number, angle: number) => {
    const rad = ((angle - 90) * Math.PI) / 180
    return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)]
  }
  const large = end - start > 180 ? 1 : 0
  const [x1, y1] = polar(rOuter, start)
  const [x2, y2] = polar(rOuter, end)
  const [x3, y3] = polar(rInner, end)
  const [x4, y4] = polar(rInner, start)
  return [
    `M ${x1} ${y1}`,
    `A ${rOuter} ${rOuter} 0 ${large} 1 ${x2} ${y2}`,
    `L ${x3} ${y3}`,
    `A ${rInner} ${rInner} 0 ${large} 0 ${x4} ${y4}`,
    "Z",
  ].join(" ")
}

export function Chart({
  title,
  type,
  data,
  status,
  error,
  maxPoints = 50,
  maxBars = 20,
}: ChartProps) {
  const chartTitle = title ?? "Chart"
  const allRows = status === "ok" || status === "stale" ? toPoints(data) : []
  const limited =
    type === "line" ? allRows.slice(-maxPoints) : type === "bar" ? allRows.slice(0, maxBars) : allRows
  const values = limited.map((row) => row.value)

  return (
    <div className="flex h-full flex-col rounded-xl border border-border bg-card p-4 shadow-card">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="truncate text-[13px] font-semibold tracking-tight text-foreground">
          {chartTitle}
        </h3>
        <div className="flex shrink-0 items-center gap-2">
          {status === "stale" && (
            <span className="rounded-full border border-warning/25 bg-warning-soft px-2 py-0.5 text-[10px] font-semibold text-warning">
              Stale
            </span>
          )}
          {limited.length > 0 && status !== "error" && (
            <span className="text-[10px] text-muted-foreground tabular">{limited.length} pts</span>
          )}
        </div>
      </div>

      {status === "loading" ? (
        <div className="flex h-52 items-end gap-2 px-2 pb-2" aria-busy="true" aria-label="Loading chart">
          {Array.from({ length: 8 }).map((_, index) => (
            <div
              key={index}
              className="flex-1 animate-pulse rounded-t-md bg-muted"
              style={{ height: `${25 + ((index * 37) % 65)}%` }}
            />
          ))}
        </div>
      ) : status === "error" && error ? (
        <div className="flex h-52 flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-danger/30 bg-danger-soft/40 px-4 text-center">
          <p className="text-xs font-semibold text-danger">Chart failed to load</p>
          <p className="text-xs text-danger/80">{error.message}</p>
        </div>
      ) : limited.length === 0 ? (
        <div className="flex h-52 flex-col items-center justify-center rounded-lg border border-dashed border-border bg-surface-muted/40 px-4 text-center">
          <p className="text-xs font-medium text-muted-foreground">No data for this view</p>
          <p className="mt-1 text-[11px] text-muted-foreground/80">
            Run the query or adjust filters to populate this chart.
          </p>
        </div>
      ) : type === "pie" ? (
        <PieChart rows={limited} title={chartTitle} />
      ) : (
        <CartesianChart rows={limited} type={type} title={chartTitle} />
      )}

      {limited.length > 0 && status !== "error" && type !== "pie" && (
        <div className="mt-3 flex items-center justify-between border-t border-border/60 pt-2 text-[10px] text-muted-foreground">
          <span>
            Min <span className="font-semibold text-foreground tabular">{numberFormat.format(Math.min(...values))}</span>
          </span>
          <span>
            Max <span className="font-semibold text-foreground tabular">{numberFormat.format(Math.max(...values))}</span>
          </span>
          <span>
            Count <span className="font-semibold text-foreground tabular">{values.length}</span>
          </span>
        </div>
      )}
    </div>
  )
}

function CartesianChart({
  rows,
  type,
  title,
}: {
  rows: Array<{ label: string; value: number }>
  type: "line" | "bar"
  title: string
}) {
  const W = 640
  const H = 240
  const padding = { top: 14, right: 14, bottom: 34, left: 44 }
  const innerW = W - padding.left - padding.right
  const innerH = H - padding.top - padding.bottom
  const maxValue = Math.max(...rows.map((row) => Math.abs(row.value)), 1)
  const niceMax = Math.ceil(maxValue / 4) * 4 || 4
  const xFor = (index: number) =>
    rows.length === 1
      ? padding.left + innerW / 2
      : padding.left + (index / (rows.length - 1)) * innerW
  const yFor = (value: number) =>
    padding.top + innerH - (Math.max(0, value) / niceMax) * innerH
  const baseY = padding.top + innerH
  const gridValues = [0, 0.25, 0.5, 0.75, 1].map((step) => niceMax * step)
  const labelStep = Math.max(1, Math.ceil(rows.length / 8))

  const linePoints = rows.map((row, index) => `${xFor(index)},${yFor(row.value)}`).join(" ")
  const areaPoints = `${padding.left},${baseY} ${linePoints} ${xFor(rows.length - 1)},${baseY}`

  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        role="img"
        aria-label={`${title} ${type} chart`}
        className="h-52 w-full overflow-visible"
      >
        <title>{`${title}: ${rows
          .slice(0, 10)
          .map((row) => `${row.label} ${row.value}`)
          .join(", ")}`}</title>

        {gridValues.map((gridValue) => {
          const y = yFor(gridValue)
          return (
            <g key={gridValue}>
              <line
                x1={padding.left}
                x2={W - padding.right}
                y1={y}
                y2={y}
                stroke="var(--border)"
                strokeDasharray="3 4"
                strokeWidth={1}
              />
              <text
                x={padding.left - 8}
                y={y + 3}
                textAnchor="end"
                fontSize={9}
                fill="var(--muted-foreground)"
              >
                {numberFormat.format(gridValue)}
              </text>
            </g>
          )
        })}

        {type === "bar" ? (
          rows.map((row, index) => {
            const band = innerW / rows.length
            const barWidth = Math.min(38, band * 0.56)
            const x = padding.left + index * band + (band - barWidth) / 2
            const y = yFor(row.value)
            const height = Math.max(2, baseY - y)
            return (
              <g key={`${row.label}-${index}`}>
                <rect
                  x={x}
                  y={y}
                  width={barWidth}
                  height={height}
                  rx={4}
                  fill="var(--primary)"
                  opacity={0.9}
                >
                  <title>{`${row.label}: ${row.value}`}</title>
                </rect>
              </g>
            )
          })
        ) : (
          <>
            <polygon points={areaPoints} fill="var(--primary)" opacity={0.1} />
            <polyline
              points={linePoints}
              fill="none"
              stroke="var(--primary)"
              strokeWidth={2.25}
              strokeLinejoin="round"
              strokeLinecap="round"
            />
            {rows.map((row, index) => (
              <circle
                key={`${row.label}-${index}`}
                cx={xFor(index)}
                cy={yFor(row.value)}
                r={3}
                fill="var(--card)"
                stroke="var(--primary)"
                strokeWidth={2}
              >
                <title>{`${row.label}: ${row.value}`}</title>
              </circle>
            ))}
          </>
        )}

        {rows.map((row, index) => {
          if (index % labelStep !== 0 && index !== rows.length - 1) return null
          const x = type === "bar" ? padding.left + (index + 0.5) * (innerW / rows.length) : xFor(index)
          const label = row.label.length > 12 ? `${row.label.slice(0, 11)}…` : row.label
          return (
            <text
              key={`label-${row.label}-${index}`}
              x={x}
              y={H - 10}
              textAnchor="middle"
              fontSize={9}
              fill="var(--muted-foreground)"
            >
              {label}
            </text>
          )
        })}
      </svg>
    </div>
  )
}

function PieChart({ rows, title }: { rows: Array<{ label: string; value: number }>; title: string }) {
  const total = rows.reduce((sum, row) => sum + Math.max(0, row.value), 0) || 1
  const topRows = rows.slice(0, 7)
  let cursor = 0

  return (
    <div className="flex flex-col items-center gap-3 sm:flex-row sm:items-center sm:gap-5">
      <svg
        viewBox="0 0 220 220"
        role="img"
        aria-label={`${title} donut chart`}
        className="h-44 w-44 shrink-0"
      >
        <title>{`${title}: ${rows.map((row) => `${row.label} ${row.value}`).join(", ")}`}</title>
        <circle cx={110} cy={110} r={88} fill="var(--surface-muted)" opacity={0.4} />
        {topRows.map((row, index) => {
          const start = cursor
          const sweep = (Math.max(0, row.value) / total) * 360
          cursor += sweep
          if (sweep <= 0) return null
          return (
            <path
              key={`${row.label}-${index}`}
              d={donutPath(110, 110, 90, 56, start, start + Math.min(sweep, 359.99))}
              fill={PALETTE[index % PALETTE.length]}
            >
              <title>{`${row.label}: ${row.value} (${Math.round((row.value / total) * 100)}%)`}</title>
            </path>
          )
        })}
        <text
          x={110}
          y={106}
          textAnchor="middle"
          fontSize={20}
          fontWeight={700}
          fill="var(--foreground)"
        >
          {numberFormat.format(total)}
        </text>
        <text x={110} y={124} textAnchor="middle" fontSize={10} fill="var(--muted-foreground)">
          total
        </text>
      </svg>

      <ul className="flex w-full min-w-0 flex-col gap-1.5">
        {topRows.map((row, index) => (
          <li key={`${row.label}-${index}`} className="flex items-center gap-2 text-xs">
            <span
              className="h-2.5 w-2.5 shrink-0 rounded-sm"
              style={{ backgroundColor: PALETTE[index % PALETTE.length] }}
              aria-hidden="true"
            />
            <span className="min-w-0 flex-1 truncate text-muted-foreground">{row.label}</span>
            <span className="shrink-0 font-semibold text-foreground tabular">
              {Math.round((row.value / total) * 100)}%
            </span>
          </li>
        ))}
        {rows.length > topRows.length && (
          <li className="pl-6 text-[11px] text-muted-foreground">
            +{rows.length - topRows.length} more
          </li>
        )}
      </ul>
    </div>
  )
}
