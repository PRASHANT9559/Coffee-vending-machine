import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  IconArrowLeft,
  IconDatabase,
  IconPencil,
  IconRefresh,
} from "@/components/ui/icons"

export function TopBar({
  title,
  dashboardId,
  status,
  onRefresh,
}: {
  title: string
  dashboardId?: string
  status?: string
  onRefresh: () => void
}) {
  const statusVariant =
    status === "active" ? "success" : status === "archived" ? "default" : "warning"

  return (
    <header className="sticky top-0 z-30 border-b border-border/80 bg-card/85 backdrop-blur-md">
      <div className="mx-auto flex h-14 w-full max-w-[1500px] items-center gap-2 px-3 sm:gap-3 sm:px-5">
        <Link
          href="/"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          aria-label="Back to dashboard hub"
          title="Back to hub"
        >
          <IconArrowLeft size={17} />
        </Link>

        <div className="min-w-0 flex-1">
          <div className="hidden items-center gap-1 text-[10px] font-medium uppercase tracking-[0.1em] text-muted-foreground sm:flex">
            <span>Hub</span>
            <span aria-hidden="true">/</span>
            <span>Dashboard</span>
          </div>
          <div className="flex min-w-0 items-center gap-2">
            <h1 className="truncate text-[13px] font-semibold text-foreground sm:text-sm">{title}</h1>
            {status && (
              <Badge variant={statusVariant} dot className="hidden sm:inline-flex">
                {status}
              </Badge>
            )}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1.5">
          {dashboardId && (
            <>
              <Link href={`/dashboards/${encodeURIComponent(dashboardId)}/discover`} className="hidden md:block">
                <Button variant="secondary" size="sm">
                  <IconDatabase size={14} />
                  Discover
                </Button>
              </Link>
              <Link href={`/dashboards/${encodeURIComponent(dashboardId)}/configure`} className="hidden md:block">
                <Button variant="secondary" size="sm">
                  <IconPencil size={14} />
                  Configure
                </Button>
              </Link>
            </>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={onRefresh}
            aria-label="Refresh dashboard data"
            title="Refresh data"
          >
            <IconRefresh size={16} />
          </Button>
          <ThemeToggle compact />
        </div>
      </div>
    </header>
  )
}
