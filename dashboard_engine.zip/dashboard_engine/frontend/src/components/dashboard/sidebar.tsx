import { IconLayoutGrid } from "@/components/ui/icons"

export function Sidebar({
  navItems,
  activeRoute,
  onNavClick,
}: {
  navItems: Array<{ id: string; label: string; routeId: string; icon?: string }>
  activeRoute: string | null
  onNavClick: (routeId: string) => void
}) {
  return (
    <aside className="hidden w-60 shrink-0 border-r border-border/80 bg-card/40 lg:flex lg:flex-col">
      <div className="px-4 pb-2 pt-5">
        <p className="eyebrow">Navigation</p>
      </div>
      <nav className="space-y-1 px-2 pb-4" aria-label="Dashboard views">
        {navItems.length === 0 && (
          <p className="px-3 py-2 text-xs text-muted-foreground">No views configured.</p>
        )}
        {navItems.map((item) => {
          const isActive = activeRoute === item.routeId
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavClick(item.routeId)}
              aria-current={isActive ? "page" : undefined}
              className={`flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-3 py-2 text-left text-[13px] font-medium transition-colors ${
                isActive
                  ? "bg-primary-soft text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <span
                className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md ${
                  isActive ? "bg-primary/10" : "bg-muted/60"
                }`}
                aria-hidden="true"
              >
                {item.icon ? (
                  <span className="text-[11px] leading-none">{item.icon}</span>
                ) : (
                  <IconLayoutGrid size={13} />
                )}
              </span>
              <span className="truncate">{item.label}</span>
            </button>
          )
        })}
      </nav>
      <div className="mt-auto border-t border-border/70 p-3">
        <p className="rounded-lg bg-surface-muted/60 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
          Views are generated from the dashboard schema.
        </p>
      </div>
    </aside>
  )
}
