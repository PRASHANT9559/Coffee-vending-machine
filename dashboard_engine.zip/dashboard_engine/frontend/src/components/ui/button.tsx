import type { ButtonHTMLAttributes } from "react"

type Variant = "primary" | "secondary" | "ghost" | "danger" | "soft"
type Size = "sm" | "md" | "lg" | "icon"

export function Button({
  children,
  className = "",
  variant = "primary",
  size = "md",
  type = "button",
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant
  size?: Size
}) {
  const base =
    "inline-flex cursor-pointer select-none items-center justify-center gap-2 whitespace-nowrap rounded-lg font-semibold transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 active:translate-y-px"

  const variants: Record<Variant, string> = {
    primary:
      "bg-primary text-primary-foreground shadow-sm hover:bg-primary-hover",
    secondary:
      "border border-border bg-card text-foreground shadow-xs hover:border-muted-foreground/35 hover:bg-surface-muted",
    ghost:
      "text-muted-foreground hover:bg-muted hover:text-foreground",
    soft:
      "bg-primary-soft text-primary hover:bg-primary/15",
    danger:
      "bg-danger text-danger-foreground shadow-sm hover:bg-danger-hover",
  }

  const sizes: Record<Size, string> = {
    sm: "h-8 px-3 text-xs",
    md: "h-9 px-4 text-[13px]",
    lg: "h-10 px-5 text-sm",
    icon: "h-9 w-9 p-0",
  }

  return (
    <button
      type={type}
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}
