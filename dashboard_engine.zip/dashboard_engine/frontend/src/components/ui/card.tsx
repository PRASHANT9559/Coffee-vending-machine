export function Card({
  children,
  className = "",
  padded = true,
  ...rest
}: React.HTMLAttributes<HTMLDivElement> & {
  children: React.ReactNode
  className?: string
  padded?: boolean
}) {
  return (
    <div
      className={`rounded-xl border border-border bg-card shadow-card ${padded ? "p-5" : ""} ${className}`}
      {...rest}
    >
      {children}
    </div>
  )
}

export function CardHeader({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  return <div className={`mb-4 ${className}`}>{children}</div>
}

export function CardTitle({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <h3 className={`text-[15px] font-semibold tracking-tight text-foreground ${className}`}>
      {children}
    </h3>
  )
}

export function CardDescription({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  return <p className={`mt-1 text-[13px] leading-relaxed text-muted-foreground ${className}`}>{children}</p>
}

export function CardContent({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  return <div className={className}>{children}</div>
}

export function CardFooter({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={`mt-4 flex items-center justify-between gap-3 border-t border-border/70 pt-4 ${className}`}
    >
      {children}
    </div>
  )
}
