import type { ReactNode } from "react"
import { IconAlert, IconCheck } from "@/components/ui/icons"

export function Alert({
  variant = "danger",
  title,
  children,
  className = "",
}: {
  variant?: "danger" | "info" | "success" | "warning"
  title?: string
  children?: ReactNode
  className?: string
}) {
  const styles = {
    danger: "border-danger/25 bg-danger-soft text-danger",
    info: "border-primary/20 bg-primary-soft text-primary",
    success: "border-success/25 bg-success-soft text-success",
    warning: "border-warning/25 bg-warning-soft text-warning",
  }

  const Icon = variant === "success" ? IconCheck : IconAlert

  return (
    <div className={`flex gap-3 rounded-xl border px-4 py-3 ${styles[variant]} ${className}`} role="status">
      <Icon size={17} className="mt-0.5 shrink-0" />
      <div className="min-w-0 text-[13px] leading-relaxed">
        {title && <p className="font-semibold">{title}</p>}
        {children && <div className={title ? "mt-0.5 opacity-90" : ""}>{children}</div>}
      </div>
    </div>
  )
}
