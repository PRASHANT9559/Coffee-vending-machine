export function Divider({ className = "" }: { className?: string }) {
  return <div className={`my-4 h-px w-full bg-border ${className}`} />
}
