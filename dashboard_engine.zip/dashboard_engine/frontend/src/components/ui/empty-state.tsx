import type { ReactNode } from "react"
import { IconInbox } from "@/components/ui/icons"

export function EmptyState({
  title,
  description,
  action,
  actionLabel,
  icon,
  className = "",
}: {
  title: string
  description?: string
  action?: () => void
  actionLabel?: string
  icon?: ReactNode
  className?: string
}) {
  return (
    <div className={`flex flex-col items-center justify-center px-6 py-16 text-center ${className}`}>
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-primary/15 bg-primary-soft text-primary">
        {icon ?? <IconInbox size={24} />}
      </div>
      <h2 className="text-base font-semibold tracking-tight text-foreground">{title}</h2>
      {description && (
        <p className="mt-1.5 max-w-sm text-[13px] leading-relaxed text-muted-foreground">
          {description}
        </p>
      )}
      {action && actionLabel && (
        <button
          type="button"
          onClick={action}
          className="mt-5 inline-flex h-9 cursor-pointer items-center justify-center gap-2 rounded-lg bg-primary px-4 text-[13px] font-semibold text-primary-foreground shadow-sm transition-colors hover:bg-primary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          {actionLabel}
        </button>
      )}
    </div>
  )
}
