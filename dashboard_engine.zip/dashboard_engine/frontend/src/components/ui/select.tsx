import { IconChevronDown } from "@/components/ui/icons"

export function Select({
  className = "",
  children,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className={`relative ${className}`}>
      <select
        {...props}
        className="h-9 w-full cursor-pointer appearance-none rounded-lg border border-input bg-card pl-3 pr-9 text-[13px] text-foreground shadow-xs outline-none transition-colors hover:border-muted-foreground/40 focus:border-primary focus:ring-2 focus:ring-primary/20 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {children}
      </select>
      <IconChevronDown
        size={15}
        className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
      />
    </div>
  )
}
