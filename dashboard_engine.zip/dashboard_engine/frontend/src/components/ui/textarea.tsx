export function Textarea({
  className = "",
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`w-full rounded-lg border border-input bg-card px-3 py-2 text-[13px] leading-relaxed text-foreground shadow-xs outline-none transition-colors placeholder:text-muted-foreground/80 hover:border-muted-foreground/40 focus:border-primary focus:ring-2 focus:ring-primary/20 disabled:cursor-not-allowed disabled:opacity-60 ${className}`}
    />
  )
}
