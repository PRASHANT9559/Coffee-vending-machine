export function Input({
  className = "",
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`h-9 w-full rounded-lg border border-input bg-card px-3 text-[13px] text-foreground shadow-xs outline-none transition-colors placeholder:text-muted-foreground/80 hover:border-muted-foreground/40 focus:border-primary focus:ring-2 focus:ring-primary/20 disabled:cursor-not-allowed disabled:opacity-60 aria-[invalid=true]:border-danger aria-[invalid=true]:ring-danger/20 ${className}`}
    />
  )
}
