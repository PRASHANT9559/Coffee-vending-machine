export function Badge({
  className = "",
  variant = "default",
  dot = false,
  children,
}: {
  className?: string
  variant?: "default" | "brand" | "primary" | "green" | "success" | "amber" | "warning" | "danger"
  dot?: boolean
  children: React.ReactNode
}) {
  const base =
    "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-[11px] font-semibold leading-5"

  const variants: Record<string, string> = {
    default: "border-border bg-muted text-muted-foreground",
    brand: "border-transparent bg-primary text-primary-foreground",
    primary: "border-primary/15 bg-primary-soft text-primary",
    green: "border-success/20 bg-success-soft text-success",
    success: "border-success/20 bg-success-soft text-success",
    amber: "border-warning/25 bg-warning-soft text-warning",
    warning: "border-warning/25 bg-warning-soft text-warning",
    danger: "border-danger/25 bg-danger-soft text-danger",
  }

  const dotColors: Record<string, string> = {
    default: "bg-muted-foreground",
    brand: "bg-primary-foreground",
    primary: "bg-primary",
    green: "bg-success",
    success: "bg-success",
    amber: "bg-warning",
    warning: "bg-warning",
    danger: "bg-danger",
  }

  return (
    <span className={`${base} ${variants[variant]} ${className}`}>
      {dot && <span className={`h-1.5 w-1.5 rounded-full ${dotColors[variant]}`} aria-hidden="true" />}
      {children}
    </span>
  )
}
