"use client"

import { useEffect, useState } from "react"

export function PanelResizer({
  orientation,
  onResize,
  panelIndex,
}: {
  orientation: "horizontal" | "vertical"
  onResize: (panelIndex: number, delta: number) => void
  panelIndex: number
}) {
  const [start, setStart] = useState<{ x: number; y: number } | null>(null)

  useEffect(() => {
    if (!start) return

    const onMouseMove = (e: MouseEvent) => {
      const dx = e.clientX - start.x
      const dy = e.clientY - start.y
      const delta = orientation === "horizontal" ? dy / 100 : dx / 100
      onResize(panelIndex, delta)
      setStart({ x: e.clientX, y: e.clientY })
    }

    const onMouseUp = () => setStart(null)

    window.addEventListener("mousemove", onMouseMove)
    window.addEventListener("mouseup", onMouseUp)
    return () => {
      window.removeEventListener("mousemove", onMouseMove)
      window.removeEventListener("mouseup", onMouseUp)
    }
  }, [start, orientation, onResize, panelIndex])

  return (
    <div
      role="separator"
      aria-orientation={orientation === "horizontal" ? "horizontal" : "vertical"}
      aria-label="Resize panels"
      tabIndex={0}
      onMouseDown={(e) => {
        e.preventDefault()
        setStart({ x: e.clientX, y: e.clientY })
      }}
      className={`shrink-0 select-none rounded-full bg-border transition-colors hover:bg-primary/50 ${
        orientation === "horizontal"
          ? "mx-2 h-1.5 w-auto cursor-row-resize"
          : "my-2 h-auto w-1.5 cursor-col-resize"
      }`}
    />
  )
}
