import Link from "next/link"
import { Fragment } from "react"
import { PanelResizer } from "@/components/workspace/panel-resizer"
import { IconArrowUpRight, IconLayoutGrid, IconX } from "@/components/ui/icons"

export function WorkspaceContainer({
  panels,
  orientation,
  activeId,
  names,
  onPanelClick,
  onResize,
  onClose,
}: {
  panels: Array<{ dashboardId: string; ratio: number }>
  orientation: "horizontal" | "vertical"
  activeId: string | null
  names?: Record<string, string>
  onPanelClick: (dashboardId: string) => void
  onResize: (panelIndex: number, delta: number) => void
  onClose?: (dashboardId: string) => void
}) {
  const isHorizontal = orientation === "horizontal"

  return (
    <div
      className={`flex ${isHorizontal ? "flex-col" : "flex-row"} h-[calc(100vh-280px)] min-h-[360px] rounded-b-xl bg-surface-muted/40 p-3`}
    >
      {panels.map((panel, index) => {
        const isActive = panel.dashboardId === activeId
        const label = names?.[panel.dashboardId] ?? panel.dashboardId
        return (
          <Fragment key={panel.dashboardId}>
            <div
              className="flex min-h-0 min-w-0 flex-col"
              style={{ flex: `1 1 ${panel.ratio * 100}%` }}
            >
              <div
                className={`flex min-h-0 flex-1 flex-col overflow-hidden rounded-xl border bg-card transition-shadow ${
                  isActive
                    ? "border-primary/40 shadow-pop ring-1 ring-primary/20"
                    : "border-border shadow-card"
                }`}
                onClick={() => onPanelClick(panel.dashboardId)}
              >
              <div className="flex items-center justify-between gap-2 border-b border-border/70 bg-surface-muted/50 px-3 py-2">
                <div className="flex min-w-0 items-center gap-2">
                  <span
                    className={`h-2 w-2 shrink-0 rounded-full ${
                      isActive ? "bg-success" : "bg-muted-foreground/40"
                    }`}
                    aria-hidden="true"
                  />
                  <span className="truncate text-xs font-semibold text-foreground">{label}</span>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <Link
                    href={`/dashboard?id=${encodeURIComponent(panel.dashboardId)}`}
                    onClick={(event) => event.stopPropagation()}
                    className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                    aria-label={`Open ${label}`}
                    title="Open dashboard"
                  >
                    <IconArrowUpRight size={14} />
                  </Link>
                  {onClose && panels.length > 1 && (
                    <button
                      type="button"
                      onClick={(event) => {
                        event.stopPropagation()
                        onClose(panel.dashboardId)
                      }}
                      className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-danger-soft hover:text-danger"
                      aria-label={`Close ${label}`}
                      title="Close panel"
                    >
                      <IconX size={14} />
                    </button>
                  )}
                </div>
              </div>
              <div className="flex flex-1 items-center justify-center p-4">
                <div className="flex max-w-xs flex-col items-center text-center">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-border bg-surface-muted text-muted-foreground">
                    <IconLayoutGrid size={20} />
                  </span>
                  <p className="mt-3 text-[13px] font-semibold text-foreground">{label}</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    Panel preview. Open the dashboard to interact with its views.
                  </p>
                  <Link
                    href={`/dashboard?id=${encodeURIComponent(panel.dashboardId)}`}
                    onClick={(event) => event.stopPropagation()}
                    className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
                  >
                    Open dashboard
                    <IconArrowUpRight size={12} />
                  </Link>
                </div>
              </div>
            </div>
            </div>
            {index < panels.length - 1 && (
              <PanelResizer
                orientation={isHorizontal ? "horizontal" : "vertical"}
                onResize={onResize}
                panelIndex={index}
              />
            )}
          </Fragment>
        )
      })}
    </div>
  )
}
