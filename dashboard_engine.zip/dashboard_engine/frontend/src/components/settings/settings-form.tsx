"use client"

import { IconMonitor, IconMoon, IconSun } from "@/components/ui/icons"
import { Select } from "@/components/ui/select"

export interface SettingsFormValues {
  theme: "light" | "dark" | "system"
  density: "compact" | "comfortable" | "spacious"
  cacheSize: "16 MB" | "32 MB" | "64 MB"
  language: string
}

const themeOptions = [
  { value: "light" as const, label: "Light", icon: IconSun },
  { value: "dark" as const, label: "Dark", icon: IconMoon },
  { value: "system" as const, label: "System", icon: IconMonitor },
]

export function SettingsForm({
  values,
  onChange,
  onReset,
}: {
  values: SettingsFormValues
  onChange: (patch: Partial<SettingsFormValues>) => void
  onReset: () => void
}) {
  return (
    <form
      onSubmit={(e) => e.preventDefault()}
      className="space-y-6"
      aria-label="Appearance settings"
    >
      <fieldset>
        <legend className="field-label">Theme mode</legend>
        <div className="grid grid-cols-3 gap-2">
          {themeOptions.map(({ value, label, icon: Icon }) => {
            const active = values.theme === value
            return (
              <button
                key={value}
                type="button"
                onClick={() => onChange({ theme: value })}
                aria-pressed={active}
                className={`flex cursor-pointer items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-[13px] font-semibold transition-colors ${
                  active
                    ? "border-primary/40 bg-primary-soft text-primary"
                    : "border-border bg-card text-muted-foreground hover:bg-surface-muted hover:text-foreground"
                }`}
              >
                <Icon size={15} />
                {label}
              </button>
            )
          })}
        </div>
        <p className="field-hint">System follows your operating system appearance.</p>
      </fieldset>

      <fieldset>
        <legend className="field-label">Density</legend>
        <div className="grid grid-cols-3 gap-2">
          {(["compact", "comfortable", "spacious"] as const).map((density) => {
            const active = values.density === density
            return (
              <button
                key={density}
                type="button"
                onClick={() => onChange({ density })}
                aria-pressed={active}
                className={`cursor-pointer rounded-lg border px-3 py-2.5 text-[13px] font-semibold capitalize transition-colors ${
                  active
                    ? "border-primary/40 bg-primary-soft text-primary"
                    : "border-border bg-card text-muted-foreground hover:bg-surface-muted hover:text-foreground"
                }`}
              >
                {density}
              </button>
            )
          })}
        </div>
        <p className="field-hint">Controls spacing in tables and generated dashboard views.</p>
      </fieldset>

      <div>
        <label htmlFor="language" className="field-label">
          Language
        </label>
        <Select
          id="language"
          value={values.language}
          onChange={(e) => onChange({ language: e.target.value })}
        >
          <option value="en">English</option>
          <option value="hi">हिन्दी (Hindi)</option>
          <option value="es">Español</option>
          <option value="fr">Français</option>
          <option value="de">Deutsch</option>
          <option value="ja">日本語</option>
        </Select>
        <p className="field-hint">Interface language. Dashboard content is not translated.</p>
      </div>

      <div className="flex items-center gap-3 border-t border-border/70 pt-4">
        <button
          type="button"
          onClick={onReset}
          className="inline-flex h-9 cursor-pointer items-center justify-center rounded-lg border border-border bg-card px-4 text-[13px] font-semibold text-foreground shadow-xs transition-colors hover:bg-surface-muted"
        >
          Reset to defaults
        </button>
      </div>
    </form>
  )
}
