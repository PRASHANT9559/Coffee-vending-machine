export function CreateWizard() {
  return (
    <div className="max-w-lg mx-auto">
      <form className="space-y-6">
        <div className="space-y-4">
          <label className="block text-xs font-semibold text-[var(--text-main)]">
            Dashboard name
          </label>
          <input
            type="text"
            placeholder="E-Commerce Orders"
            className="w-full rounded-md border border-[var(--border-color)] bg-[var(--page-bg)] px-3 py-2 text-sm text-[var(--text-main)] focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]"
          />
        </div>
        <div className="space-y-4">
          <label className="block text-xs font-semibold text-[var(--text-main)]">
            Description
          </label>
          <textarea
            placeholder="What this dashboard shows"
            rows={3}
            className="w-full rounded-md border border-[var(--border-color)] bg-[var(--page-bg)] px-3 py-2 text-sm text-[var(--text-main)] focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]"
          />
        </div>
        <div className="space-y-4">
          <label className="block text-xs font-semibold text-[var(--text-main)]">
            Icon or emoji
          </label>
          <input
            type="text"
            placeholder="📦"
            className="w-full rounded-md border border-[var(--border-color)] bg-[var(--page-bg)] px-3 py-2 text-sm text-[var(--text-main)] focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]"
          />
        </div>
      </form>
    </div>
  );
}
