import { DashboardCard } from "./dashboard-card"

export function DashboardGrid({
  dashboards,
  onOpen,
  onDelete,
}: {
  dashboards: Array<{
    id: string
    name: string
    description: string
    status: string
    updated_at: string
    icon_json?: string | null
  }>
  onOpen: (id: string) => void
  onDelete: (id: string) => void
}) {
  if (dashboards.length === 0) return null

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {dashboards.map((d) => (
        <DashboardCard
          key={d.id}
          dashboard={d}
          onOpen={() => onOpen(d.id)}
          onDelete={() => onDelete(d.id)}
        />
      ))}
    </div>
  )
}
