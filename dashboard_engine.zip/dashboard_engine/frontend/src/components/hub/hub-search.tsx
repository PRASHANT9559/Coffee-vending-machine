import { IconSearch, IconX } from "@/components/ui/icons"

export function HubSearch({
  value,
  onChange,
  placeholder = "Search dashboards",
}: {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}) {
  return (
    <div className="relative w-full max-w-md">
      <IconSearch
        size={16}
        className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
      />
      <input
        type="search"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-label="Search dashboards"
        className="h-9 w-full rounded-lg border border-input bg-card pl-9 pr-9 text-[13px] text-foreground shadow-xs outline-none transition-colors placeholder:text-muted-foreground/80 hover:border-muted-foreground/40 focus:border-primary focus:ring-2 focus:ring-primary/20 [&::-webkit-search-cancel-button]:hidden"
      />
      {value && (
        <button
          type="button"
          onClick={() => onChange("")}
          className="absolute right-2 top-1/2 flex h-6 w-6 -translate-y-1/2 cursor-pointer items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          aria-label="Clear search"
        >
          <IconX size={13} />
        </button>
      )}
    </div>
  )
}
