import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import {
  IconArrowUpRight,
  IconChart,
  IconClock,
  IconTrash,
} from "@/components/ui/icons"

type DashboardStatus = "draft" | "active" | "archived"

const statusMap: Record<
  DashboardStatus,
  { label: string; variant: "success" | "warning" | "default" }
> = {
  active: { label: "Active", variant: "success" },
  draft: { label: "Draft", variant: "warning" },
  archived: { label: "Archived", variant: "default" },
}

function formatUpdated(iso: string): string {
  if (!iso) return "—"
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return "—"

  const diff = Date.now() - date.getTime()
  const minutes = Math.floor(diff / 60_000)
  if (minutes < 1) return "Just now"
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${days}d ago`
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
}

function parseGlyph(iconJson?: string | null): string | null {
  if (!iconJson) return null
  const raw = iconJson.trim()
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw)
    if (typeof parsed === "string") return parsed.slice(0, 4)
    if (parsed && typeof parsed.value === "string") return parsed.value.slice(0, 4)
    if (parsed && typeof parsed.emoji === "string") return parsed.emoji.slice(0, 4)
  } catch {
    if (raw.length <= 4) return raw
  }
  return null
}

export function DashboardCard({
  dashboard,
  onOpen,
  onDelete,
}: {
  dashboard: {
    id: string
    name: string
    description: string
    status: string
    updated_at: string
    icon_json?: string | null
  }
  onOpen: () => void
  onDelete: () => void
}) {
  const status = statusMap[dashboard.status as DashboardStatus] ?? statusMap.draft
  const glyph = parseGlyph(dashboard.icon_json)

  return (
    <article className="group relative flex flex-col rounded-xl border border-border bg-card p-5 shadow-card transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-pop">
      <Link
        href={`/dashboard?id=${encodeURIComponent(dashboard.id)}`}
        onClick={onOpen}
        className="absolute inset-0 z-0 rounded-xl"
        aria-label={`Open dashboard ${dashboard.name}`}
      >
        <span className="sr-only">Open {dashboard.name}</span>
      </Link>

      <div className="relative z-10 flex items-start justify-between gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-primary/10 bg-primary-soft text-primary">
          {glyph ? (
            <span className="text-lg leading-none" aria-hidden="true">
              {glyph}
            </span>
          ) : (
            <IconChart size={19} />
          )}
        </div>
        <Badge variant={status.variant} dot>
          {status.label}
        </Badge>
      </div>

      <h3 className="relative z-10 mt-4 truncate text-[15px] font-semibold tracking-tight text-foreground">
        {dashboard.name}
      </h3>
      <p className="relative z-10 mt-1.5 line-clamp-2 min-h-[2.5rem] text-[13px] leading-relaxed text-muted-foreground">
        {dashboard.description || "No description yet."}
      </p>

      <div className="relative z-10 mt-5 flex items-center justify-between gap-2 border-t border-border/70 pt-3">
        <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <IconClock size={13} />
          <span className="tabular">{formatUpdated(dashboard.updated_at)}</span>
        </span>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={(event) => {
              event.preventDefault()
              event.stopPropagation()
              onDelete()
            }}
            className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-md text-muted-foreground opacity-0 transition-all hover:bg-danger-soft hover:text-danger focus-visible:opacity-100 group-hover:opacity-100"
            aria-label={`Delete dashboard ${dashboard.name}`}
            title="Delete dashboard"
          >
            <IconTrash size={14} />
          </button>
          <span className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition-colors group-hover:bg-primary-soft group-hover:text-primary">
            <IconArrowUpRight size={15} />
          </span>
        </div>
      </div>
    </article>
  )
}
