"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import type { ReactNode } from "react"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  IconChart,
  IconLayoutDashboard,
  IconLayoutGrid,
  IconSettings,
} from "@/components/ui/icons"

const navItems = [
  { href: "/", label: "Hub", icon: IconLayoutDashboard },
  { href: "/workspace", label: "Workspace", icon: IconLayoutGrid },
  { href: "/settings", label: "Settings", icon: IconSettings },
]

export function AppShell({
  children,
  action,
  active,
  wide = false,
}: {
  children: ReactNode
  action?: ReactNode
  active?: string
  wide?: boolean
}) {
  const pathname = usePathname()
  const current = active ?? pathname

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b border-border/80 bg-card/85 backdrop-blur-md">
        <div
          className={`mx-auto flex h-16 w-full items-center gap-4 px-4 sm:px-6 ${
            wide ? "max-w-[1500px]" : "max-w-7xl"
          }`}
        >
          <Link href="/" className="group flex shrink-0 items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm transition-transform group-hover:scale-[1.03]">
              <IconChart size={19} />
            </span>
            <span className="flex min-w-0 flex-col">
              <span className="truncate text-[15px] font-bold leading-tight tracking-tight text-foreground">
                Dashboard Engine
              </span>
              <span className="hidden text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground sm:block">
                Universal UI
              </span>
            </span>
          </Link>

          <nav className="ml-2 hidden items-center gap-1 md:flex" aria-label="Primary">
            {navItems.map((item) => {
              const isActive =
                item.href === "/" ? current === "/" || current === "/create" : current.startsWith(item.href)
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={isActive ? "page" : undefined}
                  className={`inline-flex h-9 items-center gap-2 rounded-lg px-3 text-[13px] font-medium transition-colors ${
                    isActive
                      ? "bg-primary-soft text-primary"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                >
                  <Icon size={16} />
                  {item.label}
                </Link>
              )
            })}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <ThemeToggle />
            {action}
          </div>
        </div>

        <nav
          className="flex items-center gap-1 overflow-x-auto border-t border-border/70 px-3 py-2 md:hidden"
          aria-label="Primary mobile"
        >
          {navItems.map((item) => {
            const isActive =
              item.href === "/" ? current === "/" || current === "/create" : current.startsWith(item.href)
            const Icon = item.icon
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive ? "page" : undefined}
                className={`inline-flex h-8 shrink-0 items-center gap-1.5 rounded-lg px-3 text-xs font-medium transition-colors ${
                  isActive
                    ? "bg-primary-soft text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <Icon size={14} />
                {item.label}
              </Link>
            )
          })}
        </nav>
      </header>

      <main
        className={`mx-auto w-full flex-1 px-4 py-6 sm:px-6 sm:py-8 ${
          wide ? "max-w-[1500px]" : "max-w-7xl"
        }`}
      >
        {children}
      </main>

      <footer className="border-t border-border/60 py-4">
        <div
          className={`mx-auto flex w-full flex-col items-center justify-between gap-1 px-4 text-[11px] text-muted-foreground sm:flex-row sm:px-6 ${
            wide ? "max-w-[1500px]" : "max-w-7xl"
          }`}
        >
          <span>Universal UI &amp; Auto-Dashboard Engine</span>
          <span className="tabular">v0.1.0 · Next.js · Tauri</span>
        </div>
      </footer>
    </div>
  )
}
