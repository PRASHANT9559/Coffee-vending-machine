"use client"

import { useState, type ReactNode } from "react"

export function ErrorBoundary({
  children,
  fallback,
}: {
  children: ReactNode
  fallback?: ReactNode
}) {
  const [error] = useState<Error | null>(null)

  if (error) {
    return (
      fallback ?? (
        <div className="rounded-lg border border-[#DC2626] bg-[#FEF2F2] p-4">
          <h3 className="text-sm font-semibold text-[#DC2626]">Something went wrong</h3>
          <p className="mt-1 text-xs text-[#DC2626]">{error.message}</p>
        </div>
      )
    )
  }

  return <>{children}</>
}

export function useErrorBoundary() {
  return { error: null as Error | null }
}
