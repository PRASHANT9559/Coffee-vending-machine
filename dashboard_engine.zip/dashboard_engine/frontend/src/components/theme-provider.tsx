"use client"

import { createContext, useContext, useEffect, useState, useCallback } from "react"

export type Theme = "light" | "dark" | "system"

interface ThemeContextType {
  theme: Theme
  setTheme: (next: Theme) => void
  resolvedTheme: "light" | "dark"
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>("system")
  const [resolved, setResolved] = useState<"light" | "dark">("light")

  const applyTheme = useCallback((next: Theme) => {
    if (typeof document === "undefined") return
    const html = document.documentElement

    let nextResolved: "light" | "dark"
    if (next === "system") {
      nextResolved = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
    } else {
      nextResolved = next
    }

    html.setAttribute("data-theme", nextResolved)
    html.style.colorScheme = nextResolved
    setResolved(nextResolved)
  }, [])

  useEffect(() => {
    try {
      const stored = localStorage.getItem("dde-theme") as Theme | null
      if (stored === "light" || stored === "dark" || stored === "system") {
        setTheme(stored)
        applyTheme(stored)
        return
      }
    } catch {}
    applyTheme(theme)
  }, [applyTheme, theme])

  useEffect(() => {
    if (theme !== "system" || typeof window === "undefined") return
    const mq = window.matchMedia("(prefers-color-scheme: dark)")
    const handler = () => applyTheme("system")
    mq.addEventListener("change", handler)
    return () => mq.removeEventListener("change", handler)
  }, [theme, applyTheme])

  const changeTheme = useCallback(
    (next: Theme) => {
      setTheme(next)
      try {
        localStorage.setItem("dde-theme", next)
      } catch {}
      applyTheme(next)
    },
    [applyTheme]
  )

  return (
    <ThemeContext.Provider value={{ theme, setTheme: changeTheme, resolvedTheme: resolved }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider")
  return ctx
}
