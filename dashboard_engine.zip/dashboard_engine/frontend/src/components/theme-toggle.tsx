"use client"

import { useTheme } from "@/components/theme-provider"
import type { Theme } from "@/components/theme-provider"
import { IconMonitor, IconMoon, IconSun } from "@/components/ui/icons"

export function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const { theme, setTheme, resolvedTheme } = useTheme()

  const labels: Record<Theme, string> = {
    light: "Light",
    dark: "Dark",
    system: "System",
  }

  const Icon = theme === "system" ? IconMonitor : resolvedTheme === "dark" ? IconMoon : IconSun

  return (
    <button
      type="button"
      onClick={() => {
        const next: Theme =
          theme === "light" ? "dark" : theme === "dark" ? "system" : "light"
        setTheme(next)
      }}
      className="inline-flex h-9 cursor-pointer items-center gap-2 rounded-lg border border-border bg-card px-2.5 text-[13px] font-medium text-foreground shadow-xs transition-colors hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
      aria-label={`Theme: ${labels[theme]}. Activate to switch theme.`}
      title={`Theme: ${labels[theme]} (${resolvedTheme})`}
    >
      <Icon size={16} className="text-muted-foreground" />
      {!compact && <span className="hidden sm:inline">{labels[theme]}</span>}
    </button>
  )
}
