// Minimal client-side validation of UI-IR shape before rendering.
// Backend is authoritative; this is defense-in-depth.

export function validateUiIr(ir: unknown): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!ir || typeof ir !== "object") {
    return { valid: false, errors: ["UI-IR must be an object"] };
  }

  const doc = ir as Record<string, unknown>;
  if (!doc.version || typeof doc.version !== "string") {
    errors.push("Missing ui-ir version");
  }

  const dashboard = doc.dashboard;
  if (!dashboard || typeof dashboard !== "object") {
    errors.push("Missing dashboard object");
    return { valid: errors.length === 0, errors };
  }

  const d = dashboard as Record<string, unknown>;

  if (!d.id || typeof d.id !== "string") errors.push("Missing dashboard.id");
  if (!d.name || typeof d.name !== "string") errors.push("Missing dashboard.name");

  // Routes must reference existing pages
  const routes = (d.routes as unknown[]) ?? [];
  const pages = (d.pages as unknown[]) ?? [];
  const pageIds = new Set((pages as any[]).map((p) => p?.id));
  routes.forEach((r, i) => {
    const route = r as Record<string, unknown>;
    if (route.pageId && !pageIds.has(route.pageId)) {
      errors.push(`Route ${i} references unknown page ${route.pageId}`);
    }
  });

  // Components must reference existing bindings
  const components = (d.components as unknown[]) ?? [];
  const bindings = (d.bindings as unknown[]) ?? [];
  const bindingIds = new Set((bindings as any[]).map((b) => b?.id));
  components.forEach((c, i) => {
    const comp = c as Record<string, unknown>;
    if (comp.bindingId && !bindingIds.has(comp.bindingId)) {
      errors.push(`Component ${i} references unknown binding ${comp.bindingId}`);
    }
  });

  return { valid: errors.length === 0, errors };
}
