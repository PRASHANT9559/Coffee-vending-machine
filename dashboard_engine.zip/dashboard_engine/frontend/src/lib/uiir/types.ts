// UI-IR public surface. The canonical types live in `@/lib/tauri/types`
// so backend, contract, and renderer stay aligned.

export type {
  UiIrDocument,
  UiIrComponent,
  UiIrBinding,
  UiIrQuery,
  UiIrPage,
  UiIrLayout,
} from "@/lib/tauri/types";

export { validateUiIr } from "./validator";
export { renderComponent, type RenderContext } from "./renderer";
