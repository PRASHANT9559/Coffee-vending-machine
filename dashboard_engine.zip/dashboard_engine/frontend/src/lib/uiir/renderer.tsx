// UI-IR renderer — turns a validated UI-IR document into a React component tree.
// Pure function of (ir, panelState). No backend imports here.

import type { ReactElement } from "react";
import type { UiIrComponent } from "@/lib/tauri/types";
import { Chart } from "@/components/dashboard/chart";
import { Skeleton } from "@/components/common/loading-skeleton";
import {
  IconAlert,
  IconFile,
  IconGauge,
  IconSliders,
  IconTable,
} from "@/components/ui/icons";

export interface RenderContext {
  component: UiIrComponent;
  data: unknown;
  status: "idle" | "loading" | "ok" | "error" | "stale";
  error?: { code: string; message: string };
}

export function renderComponent(context: RenderContext): ReactElement {
  const { component } = context;

  // Unknown component types render a safe fallback (never crash the page).
  switch (component.type) {
    case "metric-card":
      return <MetricCard {...context} />;
    case "data-table":
      return <DataTable {...context} />;
    case "chart.line":
      return <ChartCard {...context} type="line" />;
    case "chart.bar":
      return <ChartCard {...context} type="bar" />;
    case "chart.pie":
      return <ChartCard {...context} type="pie" />;
    case "list":
      return <List {...context} />;
    case "detail":
      return <Detail {...context} />;
    case "filters":
      return <FilterBar {...context} />;
    case "section":
      return <Section component={component} />;
    case "placeholder-card":
    default:
      return (
        <PlaceholderCard
          component={component}
          reason={context.error?.message ?? "Unknown component type"}
        />
      );
  }
}

// --- Primitive components (inline, no external deps) ---

function metricValue(data: unknown): string | null {
  if (data === null || data === undefined) return null
  if (typeof data === "number" || typeof data === "string") return String(data)
  if (Array.isArray(data)) {
    if (data.length === 1 && data[0] && typeof data[0] === "object") {
      const first = data[0] as Record<string, unknown>
      const key = ["value", "count", "total"].find((k) => first[k] !== undefined)
      if (key) return String(first[key])
    }
    return String(data.length)
  }
  if (typeof data === "object") {
    const obj = data as Record<string, unknown>
    const key = ["value", "count", "total"].find((k) => obj[k] !== undefined)
    if (key) return String(obj[key])
  }
  return null
}

function MetricCard({ component, data, status, error }: RenderContext) {
  const title = component.title ?? "Metric";
  const value = status === "ok" || status === "stale" ? metricValue(data) : null;

  return (
    <div className="flex h-full flex-col justify-between rounded-xl border border-border bg-card p-4 shadow-card">
      <div className="flex items-start justify-between gap-3">
        <div className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
          {title}
        </div>
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-soft text-primary">
          <IconGauge size={16} />
        </span>
      </div>

      {status === "loading" ? (
        <Skeleton className="mt-3 h-8 w-24" />
      ) : status === "error" ? (
        <div className="mt-3 text-sm font-semibold text-danger">Error</div>
      ) : (
        <div className="mt-3 truncate text-[28px] font-bold leading-none tracking-tight text-foreground tabular">
          {value ?? "--"}
        </div>
      )}

      {status === "error" && error ? (
        <p className="mt-2 text-[11px] text-danger">{error.message}</p>
      ) : (
        <p className="mt-2 text-[11px] text-muted-foreground">
          {status === "loading" ? "Loading…" : status === "idle" ? "Waiting for data" : "Current value"}
        </p>
      )}
    </div>
  );
}

function DataTable({ component, data, status, error }: RenderContext) {
  const title = component.title ?? "Table";
  const rows =
    (status === "ok" || status === "stale") && Array.isArray(data)
      ? (data as Array<Record<string, unknown>>)
      : [];
  const columns = rows.length > 0 ? Object.keys(rows[0]) : [];

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
        <div className="flex min-w-0 items-center gap-2">
          <IconTable size={15} className="shrink-0 text-muted-foreground" />
          <h3 className="truncate text-[13px] font-semibold text-foreground">{title}</h3>
        </div>
        {rows.length > 0 && (
          <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-[10px] font-semibold text-muted-foreground tabular">
            {rows.length} {rows.length === 1 ? "row" : "rows"}
          </span>
        )}
      </div>

      {status === "loading" ? (
        <div className="space-y-2 p-4" aria-busy="true" aria-label={`Loading ${title}`}>
          <Skeleton className="h-7 w-full" />
          <Skeleton className="h-7 w-full" />
          <Skeleton className="h-7 w-4/5" />
        </div>
      ) : status === "error" && error ? (
        <div className="p-4">
          <div className="rounded-lg border border-danger/25 bg-danger-soft px-3 py-2 text-xs text-danger">
            {error.message}
          </div>
        </div>
      ) : rows.length === 0 ? (
        <div className="flex flex-col items-center justify-center px-4 py-10 text-center">
          <IconTable size={22} className="text-muted-foreground/60" />
          <p className="mt-2 text-xs font-medium text-muted-foreground">No rows returned</p>
          <p className="mt-0.5 text-[11px] text-muted-foreground/80">
            Adjust filters or refresh this view.
          </p>
        </div>
      ) : (
        <div className="max-h-[420px] overflow-auto">
          <table className="data-table">
            <thead>
              <tr>
                {columns.map((key) => (
                  <th key={key}>{key}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={index}>
                  {columns.map((key) => (
                    <td key={key} className="whitespace-nowrap">
                      {String(row[key] ?? "—")}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function normalizeSeries(data: unknown): Array<{ label: string; value: number }> {
  if (!data) return []
  if (Array.isArray(data)) {
    return data.map((row, index) => {
      if (row && typeof row === "object") {
        const obj = row as Record<string, unknown>
        const label = obj.label ?? obj.name ?? obj.category ?? obj.key ?? index + 1
        const raw = obj.value ?? obj.count ?? obj.total ?? obj.amount ?? 0
        const value = Number(raw)
        return { label: String(label), value: Number.isFinite(value) ? value : 0 }
      }
      const value = Number(row)
      return { label: String(index + 1), value: Number.isFinite(value) ? value : 0 }
    })
  }
  if (typeof data === "object") {
    return Object.entries(data as Record<string, unknown>).map(([label, raw]) => {
      const value = Number(raw)
      return { label, value: Number.isFinite(value) ? value : 0 }
    })
  }
  return []
}

function ChartCard({
  component,
  data,
  status,
  error,
  type,
}: RenderContext & { type: "line" | "bar" | "pie" }) {
  return (
    <Chart
      title={component.title ?? "Chart"}
      type={type}
      data={normalizeSeries(data)}
      status={status}
      error={error}
    />
  );
}

function List({ component, data, status, error }: RenderContext) {
  const title = component.title ?? "List";
  const items =
    (status === "ok" || status === "stale") && Array.isArray(data) ? (data as unknown[]) : [];

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h3 className="text-[13px] font-semibold text-foreground">{title}</h3>
        {items.length > 0 && (
          <span className="text-[10px] text-muted-foreground tabular">{items.length}</span>
        )}
      </div>
      <ul className="divide-y divide-border/70">
        {status === "loading" &&
          Array.from({ length: 4 }).map((_, index) => (
            <li key={index} className="px-4 py-3">
              <Skeleton className="h-3 w-2/3" />
            </li>
          ))}
        {items.map((item, index) => (
          <li key={index} className="px-4 py-2.5 text-[13px] text-foreground">
            {typeof item === "object" && item !== null
              ? String(
                  (item as Record<string, unknown>).label ??
                    (item as Record<string, unknown>).name ??
                    JSON.stringify(item)
                )
              : String(item)}
          </li>
        ))}
        {items.length === 0 && status !== "loading" && status !== "error" && (
          <li className="px-4 py-6 text-center text-xs text-muted-foreground">No items</li>
        )}
        {error && <li className="px-4 py-3 text-xs text-danger">{error.message}</li>}
      </ul>
    </div>
  );
}

function Detail({ component, data, status, error }: RenderContext) {
  const title = component.title ?? "Detail";
  const entries =
    (status === "ok" || status === "stale") && data && typeof data === "object"
      ? Object.entries(data as Record<string, unknown>)
      : [];

  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-card">
      <div className="flex items-center gap-2">
        <IconFile size={15} className="text-muted-foreground" />
        <h3 className="text-[13px] font-semibold text-foreground">{title}</h3>
      </div>
      {status === "error" && error && (
        <div className="mt-3 rounded-lg border border-danger/25 bg-danger-soft px-3 py-2 text-xs text-danger">
          {error.message}
        </div>
      )}
      {entries.length > 0 && (
        <dl className="mt-3 space-y-2">
          {entries.map(([key, value]) => (
            <div key={key} className="flex items-start justify-between gap-3 text-xs">
              <dt className="text-muted-foreground">{key}</dt>
              <dd className="text-right font-medium text-foreground">{String(value ?? "—")}</dd>
            </div>
          ))}
        </dl>
      )}
      {entries.length === 0 && status !== "error" && (
        <p className="mt-3 text-xs text-muted-foreground">
          {status === "loading" ? "Loading…" : "No detail data"}
        </p>
      )}
    </div>
  );
}

function FilterBar({ component }: RenderContext) {
  const title = component.title ?? "Filters";
  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 shadow-card">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-soft text-primary">
        <IconSliders size={16} />
      </span>
      <div className="min-w-0">
        <h3 className="text-[13px] font-semibold text-foreground">{title}</h3>
        <p className="text-[11px] text-muted-foreground">Filter controls render here</p>
      </div>
    </div>
  );
}

function Section({ component }: { component: UiIrComponent }) {
  const title = component.title ?? "Section";
  return (
    <div className="border-b border-border pb-2">
      <h3 className="text-[13px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
        {title}
      </h3>
    </div>
  );
}

function PlaceholderCard({ component, reason }: { component: UiIrComponent; reason: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-warning/40 bg-warning-soft/40 p-6 text-center">
      <IconAlert size={18} className="text-warning" />
      <div className="mt-2 text-[13px] font-semibold text-foreground">{component.type}</div>
      <div className="mt-1 text-[11px] text-muted-foreground">{reason}</div>
    </div>
  );
}
