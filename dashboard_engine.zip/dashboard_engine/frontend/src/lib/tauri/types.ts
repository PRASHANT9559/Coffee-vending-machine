// Shared TypeScript types for the frontend (bridge-aligned, no mock data)

export type ThemeMode = "light" | "dark" | "system";

export type DataSourceKind = "postgres" | "timescale";

export interface DataSource {
  id: string;
  name: string;
  kind: DataSourceKind;
  host: string;
  port: number;
  database_name: string;
  username: string;
  secret_ref: string; // reference only, never the actual secret
  ssl_mode: string;
  created_at: string;
  updated_at: string;
}

export interface Dashboard {
  id: string;
  name: string;
  description: string;
  icon_json: string | null;
  status: "draft" | "active" | "archived";
  current_rev: number;
  ir_version: string | null;
  created_at: string;
  updated_at: string;
}

export interface DashboardRevision {
  dashboard_id: string;
  revision: number;
  ir_json: string;
  compiled_json: string | null;
  ir_version: string;
  source: "user" | "generator" | "migration" | "import";
  note: string | null;
  created_at: string;
}

// Bridge command / response envelopes
export interface BridgeRequest<T = unknown> {
  id: string;
  payload: T;
}

export interface BridgeResponse<T = unknown> {
  id: string;
  ok: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    retryable?: boolean;
  };
}

// UI-IR types (aligned with backend ui-ir-spec.md)
export type ComponentType =
  | "metric-card"
  | "data-table"
  | "chart.line"
  | "chart.bar"
  | "chart.pie"
  | "list"
  | "detail"
  | "form.readonly"
  | "filters"
  | "section"
  | "placeholder-card";

export type ResultShape = "scalar" | "rows" | "series" | "distribution" | "none";
export type RefreshMode = "manual" | "on_mount" | "interval";
export type ThemeUIMode = "light" | "dark" | "system";

export interface UiIrComponent {
  id: string;
  type: ComponentType;
  title?: string;
  bindingId?: string;
  format?: string;
  props: Record<string, unknown>;
  gridArea?: { col: string; row: string };
}

export interface UiIrBinding {
  id: string;
  queryId: string;
  resultShape: ResultShape;
  refresh: {
    mode: RefreshMode;
    staleAfterSec?: number;
  };
}

export interface UiIrQuery {
  id: string;
  intent: {
    kind: "select" | "aggregate" | "grouped" | "timeseries" | "distribution" | "top_n";
    sourceId: string;
    fields: string[];
    orderBy?: Array<{ field: string; direction: "asc" | "desc" }>;
    limit?: number;
  };
  params: Array<{ name: string; value: unknown }>;
  cacheable: boolean;
}

export interface UiIrNavItem {
  id: string;
  label: string;
  routeId: string;
  icon?: string;
}

export interface UiIrNavGroup {
  id: string;
  label: string;
  items: UiIrNavItem[];
}

export interface UiIrNavigation {
  style: "sidebar";
  groups: UiIrNavGroup[];
  footer: UiIrNavItem[];
}

export interface UiIrRoute {
  id: string;
  path: string;
  pageId: string;
  title: string;
}

export interface UiIrLayoutRow {
  id: string;
  height: "auto" | "fill" | `${number}px`;
  items: Array<{ componentId: string; span: number }>;
}

export interface UiIrLayout {
  kind: "grid";
  columns: number;
  rows: UiIrLayoutRow[];
}

export interface UiIrPage {
  id: string;
  title: string;
  layout: UiIrLayout;
}

export interface UiIrTheme {
  mode: ThemeUIMode;
  tokens?: Record<string, string>;
}

export interface UiIrApp {
  id: string;
  name: string;
  description: string;
  icon: { kind: "emoji" | "image"; value: string };
  theme: UiIrTheme;
  navigation: UiIrNavigation;
  routes: UiIrRoute[];
  pages: UiIrPage[];
  components: UiIrComponent[];
  bindings: UiIrBinding[];
  queries: UiIrQuery[];
  permissions: { hide: string[]; readOnly: boolean; scopes: string[] };
  fallbacks: { unknownComponent: string; missingBinding: string };
}

export interface UiIrDocument {
  version: string;
  dashboard: UiIrApp;
}

// Query result shape from the backend `query_execute` command.
export interface QueryResult {
  columns: string[];
  rows: Array<Record<string, unknown>>;
  truncated: boolean;
  ms: number;
}

// Workspace layout (stored by backend, references only)
export interface WorkspacePanel {
  dashboardId: string;
  ratio: number;
}

export interface WorkspaceLayout {
  id: string;
  panels: WorkspacePanel[];
  orientation: "horizontal" | "vertical";
  activeId: string | null;
  updated_at: string;
}

// Bridge error codes
export const BridgeErrorCode = {
  DS_UNREACHABLE: "DS_UNREACHABLE",
  DS_AUTH_FAILED: "DS_AUTH_FAILED",
  QUERY_FORBIDDEN: "QUERY_FORBIDDEN",
  QUERY_TIMEOUT: "QUERY_TIMEOUT",
  QUERY_CANCELLED: "QUERY_CANCELLED",
  QUERY_LIMIT_EXCEEDED: "QUERY_LIMIT_EXCEEDED",
  IR_INVALID: "IR_INVALID",
  IR_VERSION_UNSUPPORTED: "IR_VERSION_UNSUPPORTED",
  CONFIG_CONFLICT: "CONFIG_CONFLICT",
  PLUGIN_INCOMPATIBLE: "PLUGIN_INCOMPATIBLE",
  CACHE_CORRUPT: "CACHE_CORRUPT",
  INTERNAL: "INTERNAL",
} as const;
