// Typed Tauri IPC bridge client.
//
// In a Tauri desktop build this forwards to the real backend through
// `@tauri-apps/api`. In a plain browser / phone preview there is no backend,
// so calls return a structured BRIDGE_UNAVAILABLE error (never mock data).

import { invoke as tauriInvoke } from "@tauri-apps/api/core";
import { listen as tauriListen } from "@tauri-apps/api/event";

export type CommandName =
  | "ping"
  | "dashboard_create"
  | "dashboard_list"
  | "dashboard_get"
  | "dashboard_save"
  | "dashboard_delete"
  | "dashboard_save_uiir"
  | "dashboard_validate_uiir"
  | "datasource_list"
  | "datasource_create"
  | "datasource_get"
  | "datasource_test"
  | "datasource_delete"
  | "discovery_inspect"
  | "discovery_snapshot"
  | "discovery_profile_jsonb"
  | "query_execute"
  | "query_cancel"
  | "uiir_generate"
  | "uiir_apply_draft"
  | "uiir_migrate"
  | "workspace_save_layout"
  | "workspace_get_layout"
  | "diagnostics_get";

// Commands whose Rust handler takes no request DTO. Everything else receives
// the payload as the named `req` argument.
const NO_REQUEST_COMMANDS: ReadonlySet<CommandName> = new Set(["ping"]);

let nextId = 0;
function nextRequestId(): string {
  return `req_${++nextId}_${Date.now()}`;
}

function isTauriRuntime(): boolean {
  if (typeof window === "undefined") return false;
  return "__TAURI_INTERNALS__" in window || "__TAURI__" in window;
}

export interface BridgeError {
  code: string;
  message: string;
  retryable?: boolean;
}

export interface BridgeResponse<T = unknown> {
  id: string;
  ok: boolean;
  data?: T;
  error?: BridgeError;
}

export interface BridgeClient {
  invoke<T = unknown>(command: CommandName, payload?: unknown): Promise<BridgeResponse<T>>;
  on<T = unknown>(event: string, handler: (payload: T) => void): () => void;
}

function normalizeError(err: unknown): BridgeError {
  if (typeof err === "string") {
    return { code: "INTERNAL", message: err, retryable: false };
  }
  if (err && typeof err === "object") {
    const value = err as Record<string, unknown>;
    return {
      code: typeof value.code === "string" ? value.code : "INTERNAL",
      message:
        typeof value.message === "string" ? value.message : JSON.stringify(err),
      retryable: typeof value.retryable === "boolean" ? value.retryable : false,
    };
  }
  return { code: "INTERNAL", message: String(err), retryable: false };
}

export function createBridgeClient(): BridgeClient {
  return {
    invoke: async (command, payload) => {
      const id = nextRequestId();

      if (!isTauriRuntime()) {
        return {
          id,
          ok: false,
          error: {
            code: "BRIDGE_UNAVAILABLE",
            message:
              "Desktop backend is not connected. Run the Tauri app to use dashboard commands.",
            retryable: false,
          },
        };
      }

      try {
        const args = NO_REQUEST_COMMANDS.has(command) ? {} : { req: payload ?? {} };
        const data = await tauriInvoke(command, args);
        return { id, ok: true, data };
      } catch (err) {
        return { id, ok: false, error: normalizeError(err) };
      }
    },
    on: <T = unknown>(event: string, handler: (payload: T) => void) => {
      if (!isTauriRuntime()) {
        return () => {
          // no-op outside Tauri
        };
      }

      let disposed = false;
      let unlisten: (() => void) | undefined;

      tauriListen<T>(event, (e) => handler(e.payload))
        .then((fn) => {
          if (disposed) fn();
          else unlisten = fn;
        })
        .catch(() => {
          // Listener registration failures should not break the UI.
        });

      return () => {
        disposed = true;
        unlisten?.();
      };
    },
  };
}

// Singleton instance
let bridge: BridgeClient | null = null;

export function getBridge(): BridgeClient {
  if (!bridge) {
    bridge = createBridgeClient();
  }
  return bridge;
}
