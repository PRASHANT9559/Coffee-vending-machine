// Per-dashboard store factory — each panel instance gets its own store.
// This guarantees isolation: route, filters, selection, pagination, scroll
// never leak between panels.

import { create } from "zustand";
import type { UiIrDocument } from "@/lib/tauri/types";

export interface PanelRequestState {
  status: "idle" | "loading" | "ok" | "error";
  error?: { code: string; message: string };
  data?: unknown;
}

export interface DashboardStoreState {
  dashboardId: string;
  ir: UiIrDocument | null;
  routeId: string | null;
  history: string[];
  filters: Record<string, unknown>;
  selection: string[];
  pagination: Record<string, { page: number; pageSize: number }>;
  scroll: Record<string, number>;
  requests: Record<string, PanelRequestState>;
  connection: "online" | "offline" | "degraded";
  dirty: boolean;
  setIr: (ir: UiIrDocument | null) => void;
  setRoute: (routeId: string) => void;
  goBack: () => void;
  setFilter: (key: string, value: unknown) => void;
  clearFilters: () => void;
  setSelection: (ids: string[]) => void;
  toggleSelection: (id: string) => void;
  setPage: (componentId: string, page: number, pageSize?: number) => void;
  setScroll: (componentId: string, y: number) => void;
  setRequest: (requestId: string, state: PanelRequestState) => void;
  cancelRequest: (requestId: string) => void;
  setConnection: (status: "online" | "offline" | "degraded") => void;
  setDirty: (dirty: boolean) => void;
  reset: () => void;
}

export function createDashboardStore(dashboardId: string) {
  return create<DashboardStoreState>((set, get) => ({
    dashboardId,
    ir: null,
    routeId: null,
    history: [],
    filters: {},
    selection: [],
    pagination: {},
    scroll: {},
    requests: {},
    connection: "online",
    dirty: false,
    setIr: (ir) => set({ ir, dirty: false }),
    setRoute: (routeId) =>
      set((state) => ({
        routeId,
        history: [...state.history.filter((h) => h !== routeId), routeId],
      })),
    goBack: () =>
      set((state) => {
        const history = state.history.slice();
        if (history.length > 1) {
          history.pop(); // remove current
          const previous = history.pop(); // get previous
          return { routeId: previous ?? null, history };
        }
        return state;
      }),
    setFilter: (key, value) =>
      set((state) => ({ filters: { ...state.filters, [key]: value } })),
    clearFilters: () => set({ filters: {} }),
    setSelection: (ids) => set({ selection: ids }),
    toggleSelection: (id) =>
      set((state) => {
        const ids = state.selection.includes(id)
          ? state.selection.filter((i) => i !== id)
          : [...state.selection, id];
        return { selection: ids };
      }),
    setPage: (componentId, page, pageSize) =>
      set((state) => ({
        pagination: {
          ...state.pagination,
          [componentId]: { page, pageSize: pageSize ?? state.pagination[componentId]?.pageSize ?? 25 },
        },
      })),
    setScroll: (componentId, y) =>
      set((state) => ({ scroll: { ...state.scroll, [componentId]: y } })),
    setRequest: (requestId, state) =>
      set((s) => ({ requests: { ...s.requests, [requestId]: state } })),
    cancelRequest: (requestId) =>
      set((s) => {
        const requests = { ...s.requests };
        if (requests[requestId]) {
          requests[requestId] = { ...requests[requestId], status: "idle" };
        }
        return { requests };
      }),
    setConnection: (connection) => set({ connection }),
    setDirty: (dirty) => set({ dirty }),
    reset: () =>
      set({
        ir: null,
        routeId: null,
        history: [],
        filters: {},
        selection: [],
        pagination: {},
        scroll: {},
        requests: {},
        connection: "online",
        dirty: false,
      }),
  }));
}
