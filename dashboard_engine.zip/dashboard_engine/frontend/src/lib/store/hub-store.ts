// Hub store — app-level dashboard list & selection.
// No dashboard-specific state lives here (that belongs to per-panel stores).

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Dashboard, DataSource } from "@/lib/tauri/types";

interface HubState {
  dashboards: Dashboard[];
  dataSources: DataSource[];
  selectedDashboardId: string | null;
  searchQuery: string;
  status: "idle" | "loading" | "error";
  error: string | null;
  setDashboards: (dashboards: Dashboard[]) => void;
  setDataSources: (sources: DataSource[]) => void;
  selectDashboard: (id: string | null) => void;
  setSearchQuery: (q: string) => void;
  setStatus: (status: HubState["status"], error?: string | null) => void;
  filteredDashboards: () => Dashboard[];
}

export const useHubStore = create<HubState>()(
  persist(
    (set, get) => ({
      dashboards: [],
      dataSources: [],
      selectedDashboardId: null,
      searchQuery: "",
      status: "idle",
      error: null,
      setDashboards: (dashboards) => set({ dashboards }),
      setDataSources: (dataSources) => set({ dataSources }),
      selectDashboard: (id) => set({ selectedDashboardId: id }),
      setSearchQuery: (q) => set({ searchQuery: q }),
      setStatus: (status, error = null) => set({ status, error }),
      filteredDashboards: () => {
        const { dashboards, searchQuery } = get();
        if (!searchQuery) return dashboards;
        const q = searchQuery.toLowerCase();
        return dashboards.filter(
          (d) => d.name.toLowerCase().includes(q) || d.description.toLowerCase().includes(q)
        );
      },
    }),
    {
      name: "dde-hub-storage",
      partialize: (state) => ({ selectedDashboardId: state.selectedDashboardId, searchQuery: state.searchQuery }),
    }
  )
);
