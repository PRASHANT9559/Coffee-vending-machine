// Workspace store — app-level panel layout & panel↔dashboard mapping.
// Each panel instance owns its own DashboardStore (see dashboard-store.ts).

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { WorkspaceLayout } from "@/lib/tauri/types";

interface WorkspaceState {
  layout: WorkspaceLayout | null;
  setLayout: (layout: WorkspaceLayout) => void;
  addPanel: (dashboardId: string) => void;
  removePanel: (dashboardId: string) => void;
  setActivePanel: (dashboardId: string | null) => void;
  setOrientation: (orientation: WorkspaceLayout["orientation"]) => void;
}

const defaultLayout: WorkspaceLayout = {
  id: "default",
  panels: [],
  orientation: "horizontal",
  activeId: null,
  updated_at: new Date().toISOString(),
};

export const useWorkspaceStore = create<WorkspaceState>()(
  persist(
    (set) => ({
      layout: defaultLayout,
      setLayout: (layout) => set({ layout }),
      addPanel: (dashboardId) =>
        set((state) => {
          if (!state.layout) return state;
          if (state.layout.panels.some((p) => p.dashboardId === dashboardId)) return state;
          const next = {
            ...state.layout,
            panels: [
              ...state.layout.panels,
              { dashboardId, ratio: 1 / (state.layout.panels.length + 1) },
            ],
            updated_at: new Date().toISOString(),
          };
          // Normalize ratios
          const total = next.panels.reduce((sum, p) => sum + p.ratio, 0);
          next.panels = next.panels.map((p) => ({ ...p, ratio: p.ratio / total }));
          return { layout: next };
        }),
      removePanel: (dashboardId) =>
        set((state) => {
          if (!state.layout) return state;
          const next = {
            ...state.layout,
            panels: state.layout.panels.filter((p) => p.dashboardId !== dashboardId),
            activeId:
              state.layout.activeId === dashboardId
                ? state.layout.panels.find((p) => p.dashboardId !== dashboardId)?.dashboardId ?? null
                : state.layout.activeId,
            updated_at: new Date().toISOString(),
          };
          if (next.panels.length > 0) {
            const total = next.panels.reduce((sum, p) => sum + p.ratio, 0);
            next.panels = next.panels.map((p) => ({ ...p, ratio: p.ratio / total }));
          }
          return { layout: next };
        }),
      setActivePanel: (dashboardId) =>
        set((state) => ({
          layout: state.layout ? { ...state.layout, activeId: dashboardId } : state.layout,
        })),
      setOrientation: (orientation) =>
        set((state) => ({
          layout: state.layout ? { ...state.layout, orientation } : state.layout,
        })),
    }),
    { name: "dde-workspace-storage" }
  )
);
