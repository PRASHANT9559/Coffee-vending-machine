# Universal UI & Auto-Dashboard Engine

## Project Overview

The **Universal UI & Auto-Dashboard Engine** is a desktop-first platform
for creating, configuring, and operating multiple data-driven dashboards
through a reusable engine rather than building a separate dashboard
application for every project.

The engine discovers database structure, analyzes available metadata,
identifies useful relationships, plans safe data queries, and produces a
validated UI representation that a frontend renderer can turn into
working screens. Users can create multiple dashboard projects, configure
each one independently, and open them in a shared workspace.

The central goal is to separate **dashboard configuration, data
intelligence, UI rendering, and workspace management** so the system can
be reused across different business domains without coupling the core
engine to one application or database schema.

## The Core Idea

A user should be able to create a dashboard in a manner similar to
creating a managed resource in an application:

-   Give it a name, description, and optional identifying image or icon.
-   Configure its data sources and permitted database access.
-   Configure navigation, sidebar entries, theme, layout, and access
    controls.
-   Let the engine inspect the available schema and prepare an initial
    dashboard.
-   Open the dashboard later, refine its layout, and continue using it
    without rebuilding the application.

The dashboard hub is the entry point for managing these dashboard
resources. It is not itself a business dashboard; it is the management
surface from which individual dashboards are created, discovered,
opened, and organized.

## Product Goals

1.  **Reusable engine:** Support many projects and business domains
    without requiring custom engine code for each one.
2.  **Database-driven generation:** Use database metadata and approved
    configuration to propose useful pages, tables, metrics, charts, and
    navigation.
3.  **Independent dashboards:** Treat each dashboard as a separately
    configured workspace with its own routes, sidebar, data context,
    permissions, theme, and UI state.
4.  **Simultaneous work:** Allow users to view and operate multiple
    dashboards at the same time in one desktop window.
5.  **Safe extensibility:** Add database adapters, domain intelligence,
    and UI components through explicit, versioned interfaces.
6.  **Desktop-first usability:** Prioritize the screen space and
    interaction patterns needed for complex data work.
7.  **Long-term maintainability:** Preserve stable contracts, migration
    paths, testable module boundaries, and recoverable configuration.
8.  **User control:** Make generated decisions editable. Automatic
    generation should accelerate setup, not remove user control.

## Dashboard Hub and Lifecycle

The Dashboard Hub presents the available dashboards as a searchable or
browsable list of cards. Each card may display an icon or image,
dashboard name, description, and relevant status or metadata. A
prominent **Add New** action begins dashboard creation.

A dashboard lifecycle includes:

-   **Create:** Define the dashboard identity and initial configuration.
-   **Configure:** Set up data-source references, sidebar/navigation,
    theme, layout, and security settings.
-   **Discover:** Inspect the configured data source and collect schema
    metadata.
-   **Generate:** Produce an initial dashboard definition from available
    schema, data profiles, user settings, and enabled capabilities.
-   **Review and customize:** Let the user adjust generated pages,
    components, navigation, filters, and layouts.
-   **Save and reopen:** Persist dashboard configuration so it can be
    loaded consistently later.
-   **Update:** Detect relevant schema or configuration changes and
    refresh affected metadata or generated elements in a controlled way.
-   **Manage:** Open, rename, configure, duplicate where supported,
    archive, or remove a dashboard according to defined lifecycle rules.

A dashboard's configuration and the business data it reads are separate
concerns. The engine should store dashboard configuration and local
application state locally where appropriate, while the authoritative
business records remain in their configured source systems.

## Multi-Dashboard Workspace

### What "Multi-Dashboard" Means

Multi-Dashboard is a first-class workspace capability, not merely a
collection of tabs or a shortcut for switching between pages.

The user can divide the available application window into two or three
visible panels and operate different dashboards concurrently. For
example, one panel may show E-Commerce orders, a second may show User
Management, and a third may show business analytics. This resembles a
desktop streaming setup where a game and live chat are visible together,
except that each panel hosts a complete dashboard workspace.

The workspace should support:

-   A single-dashboard full-workspace mode.
-   Two-panel and three-panel arrangements.
-   Vertical and horizontal splits.
-   Useful preset layouts, including equal splits and asymmetric
    arrangements.
-   Resizable panels so users can allocate more space to the dashboard
    they are actively using.
-   Maximizing one panel and returning to the previous multi-panel
    arrangement.
-   Keeping selected dashboards visible together for repeated workflows.
-   Restoring the workspace arrangement where practical and safe.

The number of simultaneously active dashboards should remain
configurable and constrained by available screen space, memory,
data-source capacity, and query load. Three visible panels are a
supported use case, not a promise that every dashboard must run
unlimited background work.

### Dashboard Independence Is a Core Invariant

Every panel must behave as an independent dashboard instance. Opening or
navigating one dashboard must not unexpectedly alter another dashboard.

Each dashboard instance maintains its own:

-   Navigation tree, sidebar, active route, and page history.
-   Filters, selected records, search state, pagination, and scroll
    position.
-   Layout, visible components, and dashboard-specific preferences.
-   Data-source context and applicable authorization rules.
-   Loading, error, refresh, and connection state.
-   Unsaved UI state, with explicit handling when a user attempts to
    discard changes.

For example, selecting **Products** in the E-Commerce sidebar must not
change the User Management panel's route or sidebar. A failure or
refresh in one panel should not reset unrelated panels.

The engine, database adapters, validated component registry, and other
safe infrastructure may be shared. Dashboard identity, navigation,
runtime state, and authorization context must not be accidentally
shared. Shared infrastructure must never become a shortcut around
dashboard-specific permissions.

### Workspace and Dashboard Are Different Concepts

A **dashboard** is a persistent, independently configured resource.

A **workspace arrangement** is the way one or more dashboards are placed
in the application window at a particular time.

The workspace should refer to dashboard identities rather than duplicate
their full configuration. Changing a panel's size should not rewrite the
dashboard's saved business configuration. Conversely, changing a
dashboard's sidebar should not corrupt the user's split-screen
arrangement.

## Database-Driven Dashboard Generation

The engine should support three operating modes:

-   **Automatic:** Propose an initial dashboard from schema metadata,
    profiling, and supported analytics patterns.
-   **Configured:** Use explicit user-defined pages, components,
    bindings, navigation, and query intentions.
-   **Hybrid:** Generate a useful starting point and allow the user to
    review, remove, rearrange, or add elements.

Hybrid mode is the preferred product direction because database
structure alone does not reliably reveal business meaning. A table name,
column type, or JSONB field may suggest an interpretation, but it cannot
prove that interpretation is correct.

### Schema Discovery

For supported PostgreSQL-compatible sources, discovery may inspect
tables, views, columns, data types, keys, constraints, indexes, and
available relationship metadata. TimescaleDB support may additionally
inspect relevant time-series structures and metadata.

For JSONB columns, profiling may identify observed key paths, value
types, nesting, arrays, null frequency, and safe aggregate
characteristics. Profiling must be bounded and must avoid exposing
sensitive sample values unnecessarily.

### Relationship Inference

Relationships should be represented with their source and confidence:

-   Explicit database constraints are stronger evidence than inferred
    relationships.
-   Uniqueness and compatible key types may support a relationship
    hypothesis.
-   Similar names or JSONB references are clues, not proof.
-   Inferred relationships must not silently become authoritative
    database constraints.

Users must be able to review or override uncertain interpretations where
they affect generated behavior.

### Analytics and Components

Depending on data types, permissions, and available semantics, the
engine may propose counts, sums, averages, minimums, maximums, distinct
counts, grouped summaries, time series, distributions, top-N lists, and
trend comparisons.

Generic analytics should remain separate from domain-specific logic.
Business concepts such as subscription churn or recurring revenue
require explicit domain rules or plugins; they should not be inferred
from column names alone.

## UI Representation and Rendering

The engine and frontend should communicate through a **versioned,
validated UI Intermediate Representation (UI-IR)**. UI-IR describes
application metadata, navigation, routes, pages, layouts, components,
data bindings, actions, forms, filters, permissions, themes, and
relevant version information.

The Rust core generates or validates this representation. The frontend
renders it through a trusted component registry. Configuration data
describes which supported components to use; it must not supply
arbitrary executable JavaScript or bypass the renderer's safety rules.

The component registry should define supported component types and their
validated properties. Unknown or incompatible component types should
produce a controlled validation result and safe fallback rather than
crash the entire application.

UI-IR must be versioned and migrated deliberately. A frontend update
must not silently reinterpret older persisted configuration in a way
that changes its meaning.

## Technology Responsibilities

The intended stack has clear boundaries:

-   **Rust:** Core orchestration, schema discovery, profiling,
    relationship analysis, analytics planning, query validation,
    caching, plugin interfaces, and other trusted engine
    responsibilities.
-   **SQLite:** Local dashboard configuration, application preferences,
    local metadata, migration history, and cache or synchronization
    metadata where appropriate.
-   **PostgreSQL:** Primary business-data connector.
-   **TimescaleDB:** Time-series database capabilities through a
    compatible integration.
-   **Next.js:** Primary dashboard UI renderer.
-   **Tailwind CSS:** UI styling and design system.
-   **Tauri 2:** Desktop application shell for Linux, Windows, and
    macOS.
-   **Optional Rust-based remote service:** Authenticated remote access,
    shared deployments, or realtime delivery when a deployment requires
    it.

The initial product is **desktop-first**. Linux, Windows, and macOS are
the target platforms. Android and iOS are not initial targets, even
though Tauri 2 has mobile capabilities. Mobile support should not add
complexity unless a later product decision establishes a real
requirement.

A shared Rust engine does not mean that all data, navigation, or
permissions should be globally shared. Responsibilities and security
boundaries remain explicit.

## Configuration, State, and Data Boundaries

Three categories must remain distinct:

1.  **Business data:** Authoritative records in the configured database.
2.  **Dashboard definition:** Persistent settings describing identity,
    connections by reference, navigation, layouts, components, bindings,
    and permitted behavior.
3.  **Runtime state and cache:** Temporary or restorable state such as
    active routes, panel arrangements, query cache entries, schema
    fingerprints, and synchronization status.

SQLite is not a replacement for the business database and should not
become a mirror of all remote business records. Large or sensitive
datasets should not be copied locally by default. Any offline data
retention must be deliberate, bounded, and governed by permissions and
retention rules.

Database credentials and other secrets must not be stored in ordinary
dashboard descriptions or UI configuration. Use an appropriate
secret-management mechanism for the deployment environment.

## Query Execution and Security

Generated dashboards must not gain unrestricted database access simply
because they were generated automatically.

The trusted execution path must validate the requested operation, data
source, table and column access, filters, sort keys, limits, and
applicable authorization before executing a query. Queries should be
parameterized, bounded, cancellable where practical, and protected by
timeouts and pagination or aggregation strategies.

Security responsibilities include:

-   Read-only credentials for analytics wherever possible.
-   Explicit allowlists and restrictions for permitted operations.
-   Server-side authorization for remote or shared deployments.
-   Dashboard-specific permission context.
-   Strict validation of UI-IR, configuration, plugin metadata, and IPC
    commands.
-   No arbitrary command execution from dashboard configuration.
-   No secrets in logs or ordinary configuration files.
-   Auditable errors without leaking sensitive query results.
-   Isolation between dashboard instances and between tenants when
    multi-tenant deployment is enabled.

Frontend visibility is not an authorization boundary. The trusted engine
or remote service must enforce access rules.

## Plugins and Extensibility

The system should grow through explicit interfaces rather than frequent
invasive changes to the core. Potential plugin categories include
database adapters, schema profilers, relationship providers, domain
analytics, UI components, authentication providers, and realtime
adapters.

Each plugin should declare its identity, version, compatibility range,
capabilities, dependencies, and configuration requirements. Incompatible
plugins must fail clearly and safely. Plugin registration must not imply
unrestricted access to the engine or host system.

The plugin system should be introduced after the essential end-to-end
path is stable. Premature generalization can increase complexity before
real extension requirements are known.

## Caching, Schema Changes, and Recovery

The engine should cache reusable metadata and compiled configuration to
reduce repeated work. Cache validity should be based on explicit
versions and stable fingerprints, not assumptions that schemas never
change.

When a database schema changes, the engine should distinguish between
unchanged metadata, incremental updates, and changes that require review
or regeneration. It should avoid silently destroying user customization
when regenerating dashboard elements.

Expected failure scenarios include unavailable databases, expired
credentials, invalid configuration, unsupported schema changes, query
timeouts, malformed UI-IR, corrupted local cache, plugin
incompatibility, and disconnected realtime channels.

Each failure should have a visible status, a useful diagnostic, and a
defined recovery path. Cache corruption must be recoverable from
authoritative configuration or by rebuilding derived metadata when safe.

## Realtime and Offline Behavior

Realtime updates are optional capabilities, not a requirement that every
deployment use a remote server. Where enabled, updates should refresh
only affected data bindings or components when possible rather than
reloading every dashboard.

Each dashboard instance must maintain its own loading and connection
status. A disconnected realtime channel in one dashboard should not
falsely mark unrelated data sources as disconnected.

Offline behavior should preserve the application shell, locally
available configuration, navigation, and permitted cached metadata.
Offline writes, if ever supported, require an explicit queueing,
authorization, validation, and conflict-resolution policy. The system
must not imply that stale cached data is live data.

## Performance and Resource Management

Performance must be evaluated across the full path: application startup,
schema discovery, configuration compilation, first query, initial
dashboard render, split-screen activation, and realtime propagation.

Multi-dashboard mode introduces additional resource pressure. The
workspace should therefore support bounded query concurrency,
cancellation of obsolete work, lazy loading where useful, controlled
refresh behavior, and isolation of panel failures. Inactive panels
should not continuously perform expensive work without a defined reason.

The system should avoid unbounded schema scans, unbounded query results,
unnecessary repeated metadata reads, and duplicate requests for
identical safe operations. Performance decisions must be supported by
measurements rather than assumptions.

## Reliability and Compatibility

The project should maintain explicit versions for UI-IR, local database
schema, project configuration, plugin interfaces, and any remote API
contracts. Schema migrations and configuration migrations must be
deliberate, testable, and recoverable.

Architectural changes that affect contracts should be documented with
their motivation, compatibility implications, and migration approach. A
phase should not be considered complete merely because code was written;
the relevant build, tests, integration behavior, and documentation must
be checked.

## Testing Strategy

Testing should cover individual logic, database integrations, UI
contracts, workspace independence, security boundaries, performance, and
packaging.

Important scenarios include:

-   A project with many tables and mixed structured/JSONB data.
-   Explicit and inferred relationships with different confidence
    levels.
-   Schema changes after a dashboard has been saved.
-   Invalid or incompatible UI-IR and plugin configurations.
-   Two or three dashboards open simultaneously.
-   Navigation, filters, and selected records changing in one panel
    without affecting another.
-   A failed query or refresh in one panel while other panels remain
    usable.
-   Permission differences across dashboards and data sources.
-   Corrupted cache and unavailable database recovery.
-   Query limits, timeouts, and cancellation under load.
-   Linux, Windows, and macOS build and distribution checks.

Test outcomes must be reported honestly. Unsupported behavior and
untested paths must remain documented as limitations.

## Product Principles

The following principles govern future implementation decisions:

1.  **One reusable engine, many independently configured dashboards.**
2.  **A dashboard is a persistent resource; a workspace is its current
    arrangement on screen.**
3.  **Multi-dashboard means simultaneous independent workspaces, not
    merely tabs.**
4.  **Shared infrastructure must not create shared navigation state or
    bypass authorization.**
5.  **Database structure informs generation but does not prove business
    meaning.**
6.  **Generated UI remains editable and explicitly versioned.**
7.  **Business data stays in its authoritative source unless deliberate
    caching is required.**
8.  **Configuration never executes arbitrary code.**
9.  **Every query and background operation must have bounded behavior.**
10. **Schema changes, migrations, cache failures, and plugin
    incompatibilities need recovery paths.**
11. **Desktop-first is a product decision, not an assumption that mobile
    support is already required.**
12. **Implement and verify incrementally; do not attempt the entire
    system in one unreviewed generation pass.**

## Scope Boundaries

The initial product focuses on a reusable engine, a dashboard management
hub, database-driven generation, an editable dashboard workspace,
independent dashboard instances, and desktop multi-dashboard layouts.

Features such as mobile applications, unrestricted database writes,
automatic business-semantic inference, arbitrary user-supplied
executable plugins, and guaranteed offline mutation are not implied by
this scope. They require separate design and security decisions before
implementation.

## Definition of Success

The project succeeds when a user can configure a supported database,
generate and customize a dashboard, save and reopen it, and manage
multiple dashboard definitions through the hub. The user can then open
two or three dashboards in one desktop window, arrange their panels, and
work in each independently without navigation or state leakage.

The engine must do this through stable contracts and reusable
capabilities rather than project-specific hardcoding, while remaining
secure, observable, testable, and maintainable.
