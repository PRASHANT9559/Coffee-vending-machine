plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.kotlin.kapt)
}

android {
    namespace = "com.benchsuite.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.benchsuite.app"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0-ui"

        vectorDrawables { useSupportLibrary = true }
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf("-Xjvm-default=all")
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.appcompat)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    kapt(libs.androidx.room.compiler)

    debugImplementation(libs.androidx.compose.ui.tooling)
}

/* ------------------------------------------------------------------ */
/* Native core (Rust)                                                 */
/* ------------------------------------------------------------------ */

// Opt-in so a plain Studio sync works before the Rust toolchain exists.
// Build the shared library with:
//   ./gradlew :app:assembleDebug -Pnative=true
val nativeBuildRequested = providers.gradleProperty("native").orNull?.toBoolean() ?: false

if (nativeBuildRequested) {
    val nativeOutput = layout.projectDirectory.dir("src/main/jniLibs")
    val cargoNdkBuild = tasks.register<Exec>("cargoNdkBuild") {
        group = "build"
        description = "Builds the Rust bench-core shared library for arm64-v8a."
        workingDir = rootProject.file("native/bench-core")
        commandLine(
            "cargo",
            "ndk",
            "-t",
            "arm64-v8a",
            "-o",
            nativeOutput.asFile.absolutePath,
            "build",
            "--release",
        )
        doFirst { nativeOutput.asFile.mkdirs() }
    }
    tasks.matching { it.name == "preBuild" }.configureEach {
        dependsOn(cargoNdkBuild)
    }
}
