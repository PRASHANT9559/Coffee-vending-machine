# Keep navigation route names used by reflection-free typed helpers.
-keepnames class com.benchsuite.app.navigation.** { *; }
-keepattributes *Annotation*, InnerClasses

# JNI: symbol names are part of the native ABI and must not be renamed.
-keep class com.benchsuite.app.nativecore.NativeBridge { *; }
-keepclasseswithmembernames class * { native <methods>; }
