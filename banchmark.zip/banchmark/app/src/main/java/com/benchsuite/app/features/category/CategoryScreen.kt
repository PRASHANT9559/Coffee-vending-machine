package com.benchsuite.app.features.category

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.data.model.CategorySpec
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.components.BandChip
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChartAxis
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.DeltaText
import com.benchsuite.app.ui.components.FrameTimeHistogram
import com.benchsuite.app.ui.components.GradientLegend
import com.benchsuite.app.ui.components.Heatmap
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.InsightCard
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.MetricGrid
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.components.TestRow
import com.benchsuite.app.ui.components.UseCaseRow
import com.benchsuite.app.ui.components.bandColor
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

/**
 * One screen implementation backs all eight category destinations; the route
 * argument selects the CategorySpec. See README screens 11-18.
 */
@Composable
fun CategoryScreen(categoryId: String, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val spec: CategorySpec = TestCatalog.categorySpecs.firstOrNull { it.id == categoryId } ?: TestCatalog.cpuSpec
    val isHealth = spec.id == "health"
    val gaugeMax = if (isHealth) 100 else 1100
    val runVerified = SessionState.latestRecordedRunOrNull?.verified == true

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = spec.shortTitle,
            subtitle = spec.tagline,
            onBack = onBack,
            actions = {
                IconAction(Icons.Outlined.Description, "Category report") {
                    SessionState.latestRecordedRunOrNull?.let { onNavigate(Routes.report(it.id)) }
                }
                IconAction(Icons.Outlined.PlayArrow, "Run ${spec.shortTitle}") {
                    onNavigate(Routes.preTest(spec.id))
                }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Category benchmark",
                    title = spec.title,
                    body = spec.description,
                )
            }

            item {
                // Real category score from the latest recorded run — never a static placeholder.
                val realScore = SessionState.latestRecordedRunOrNull
                    ?.categories?.firstOrNull { it.id == spec.id }
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (realScore != null) {
                            BandChip(realScore.band)
                            Spacer(Modifier.width(6.dp))
                            if (runVerified) {
                                StatusChip("Verified", tint = BenchTheme.colors.success, icon = Icons.Outlined.Verified)
                            }
                            Spacer(Modifier.weight(1f))
                            DeltaText(realScore.deltaPct)
                        } else {
                            StatusChip("Not measured", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        ScoreGauge(
                            score = realScore?.score ?: 0,
                            maxScore = gaugeMax,
                            gaugeSize = 196.dp,
                            color = realScore?.let { bandColor(it.band) } ?: MaterialTheme.colorScheme.onSurfaceVariant,
                            label = if (realScore == null) "not measured" else if (isHealth) "of 100" else "of 1,100",
                            caption = realScore?.band?.label ?: "Run this category to measure it",
                        )
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        StatBlock("Peak", realScore?.peak?.toString() ?: "—", Modifier.weight(1f))
                        StatBlock("Sustained", realScore?.sustained?.toString() ?: "—", Modifier.weight(1f), BenchTheme.colors.warning)
                        StatBlock("Tests", spec.tests.size.toString(), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
                    }
                    Spacer(Modifier.height(Spacing.xs))
                    Text(
                        text = realScore?.summary
                            ?: "No ${spec.shortTitle} score recorded on this device yet. Run the benchmark to measure it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                SectionHeader(title = "Included tests")
            }

            item {
                // Real telemetry recorded during runs of this device, if any.
                val telemetry = SessionState.latestTelemetrySamples
                if (telemetry.size >= 2) {
                    ChartCard(
                        title = "Recorded telemetry",
                        caption = "Real samples captured at 10 Hz during the most recent run.",
                    ) {
                        LineChart(
                            points = telemetry.map { it.tempCelsius.toFloat() },
                            color = BenchTheme.colors.warning,
                            height = 170.dp,
                        )
                        ChartAxis("Battery temperature (°C)", "Latest sample")
                    }
                } else {
                    SurfaceCard {
                        Text(
                            "No telemetry recorded yet. Placeholder charts are intentionally not shown.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "What this means for you",
                    actionLabel = "All insights",
                    onAction = { onNavigate(Routes.INSIGHTS) },
                )
            }
            item {
                val fits = SessionState.latestRecordedRunOrNull?.let { SessionState.getUseCaseFits(it) } ?: emptyList()
                SurfaceCard {
                    if (fits.isEmpty()) {
                        Text(
                            "No use-case verdicts recorded yet. Verdicts appear after a real run.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        fits.forEachIndexed { index, fit ->
                            UseCaseRow(fit)
                            if (index != fits.lastIndex) Spacer(Modifier.height(Spacing.sm))
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Included tests",
                    actionLabel = "Build custom",
                    onAction = { onNavigate(Routes.CUSTOM_BUILDER) },
                )
            }
            items(spec.tests.size) { index ->
                val test = spec.tests[index]
                TestRow(
                    test = test,
                    onRun = { onNavigate(Routes.preTest(spec.id)) },
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Methodology", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        Text("2.4.1", style = NumericSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Three iterations per test, median with a 5% outlier trim. Scores are normalized against a reference device where 1000 is the baseline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag("Peak + sustained")
                        Tag("Cool start")
                        Tag("Signed result")
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = { onNavigate(Routes.preTest(spec.id)) },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Run ${spec.shortTitle}")
                    }
                    OutlinedButton(
                        onClick = { onNavigate(Routes.CUSTOM_BUILDER) },
                        modifier = Modifier.height(50.dp),
                    ) {
                        Text("Customize")
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, modifier = Modifier.size(15.dp))
                    }
                }
            }

            item {
                Text(
                    text = "Scores are comparable across runs only when conditions and methodology match.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = Spacing.xs),
                )
            }
        }
    }
}

@Composable
private fun StatBlock(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.onSurface,
) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = NumericSmall.copy(fontSize = 19.sp), color = color)
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
