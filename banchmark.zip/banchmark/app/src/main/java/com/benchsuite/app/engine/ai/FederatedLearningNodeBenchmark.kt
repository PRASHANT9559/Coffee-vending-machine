package com.benchsuite.app.engine.ai

import com.benchsuite.app.util.*

import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 3.8: Federated Learning Node Benchmark
 *
 * Simulates participation in a federated learning round: measure local training speed, gradient
 * compression efficiency, and battery impact. Privacy-preserving AI requires on-device training.
 *
 * Data source: local training simulation model keyed to accelerator class.
 * Limitations: No real federated learning round or model training; metrics modeled per device
 * class, not fabricated measured values.
 */
object FederatedLearningNodeBenchmark {

    data class FlRoundResult(
        val roundIndex: Int,
        val localTrainMs: Double,
        val gradientCompressionRatio: Double,
        val uploadKb: Double,
        val batteryDrawnMah: Double,
    )

    data class FederatedReport(
        val modelName: String,
        val rounds: Int,
        val roundResults: List<FlRoundResult>,
        val averageTrainMs: Double,
        val averageCompressionRatio: Double,
        val totalBatteryMah: Double,
        val flNodeScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun detectNpu(): Boolean {
        val soc = Build.HARDWARE.lowercase()
        return soc.contains("qcom") || soc.contains("sm8") || soc.contains("exynos") ||
            soc.contains("mt") || soc.contains("dimensity") || soc.contains("gs") ||
            Build.MANUFACTURER.lowercase().contains("google")
    }

    /**
     * Simulates federated learning rounds and measures local training/compression.
     */
    fun runFederatedLearningRound(): FederatedReport {
        val npu = detectNpu()
        val modelName = "FedAvg-CNN-INT8"
        val rounds = 5
        val rng = java.util.Random(2026)

        val roundResults = (1..rounds).map { i ->
            val baseTrain = if (npu) 450.0 else 1400.0
            val trainMs = (baseTrain * (0.9 + rng.nextDouble() * 0.2) * 10.0).roundToInt() / 10.0
            val compression = if (npu) 8.5 else 4.2
            val uploadKb = (256.0 / compression * 100.0).roundToInt() / 100.0
            val batteryMah = (trainMs / 1000.0 * 0.15 * 100.0).roundToInt() / 100.0
            FlRoundResult(i, trainMs, compression, uploadKb, batteryMah)
        }

        val avgTrain = roundResults.averageOf { it.localTrainMs }
        val avgCompression = roundResults.averageOf { it.gradientCompressionRatio }
        val totalBattery = roundResults.sumOf { it.batteryDrawnMah }

        val score = when {
            npu && avgTrain <= 600.0 -> 920
            npu -> 780
            avgTrain <= 1200.0 -> 620
            else -> 450
        }

        val verdict = when {
            npu && avgTrain <= 600.0 -> "Device is a capable federated learning node; fast local training."
            npu -> "Can participate in FL rounds; training is usable but not fast."
            avgTrain <= 1200.0 -> "Marginal FL node; slow local training increases round latency."
            else -> "Not practical as a federated learning node; CPU-bound training."
        }

        return FederatedReport(
            modelName = modelName,
            rounds = rounds,
            roundResults = roundResults,
            averageTrainMs = (avgTrain * 10.0).roundToInt() / 10.0,
            averageCompressionRatio = (avgCompression * 100.0).roundToInt() / 100.0,
            totalBatteryMah = (totalBattery * 100.0).roundToInt() / 100.0,
            flNodeScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real federated learning round; metrics modeled per accelerator class.",
        )
    }
}
