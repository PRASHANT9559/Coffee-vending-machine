package com.benchsuite.app.engine.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.DeviceProfile
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.data.model.ScoreBand
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Feature 19.6: High-Resolution AMOLED Share Card Renderer.
 *
 * Generates publication-grade, social-media-ready [Bitmap] assets directly using Android [Canvas]:
 * 1. [CardFormat.STORY_VERTICAL] (1080 × 1920): 9:16 aspect ratio for Instagram Stories, TikTok, mobile wallpaper.
 * 2. [CardFormat.FEED_HORIZONTAL] (1200 × 630): 1.91:1 aspect ratio for Twitter/X summary cards, Reddit, web embeds.
 *
 * Visual Features:
 * - Pure AMOLED deep-black canvas (#07090E) with subtle dual-tone radial ambient glow.
 * - Prominent 270° vector score gauge arc with glowing gradient strokes and score band badge.
 * - Hardware specifications (Model, SoC, Android version, thermal profile).
 * - Subsystem category score pills (CPU, GPU, Memory, Storage, AI, Sustained).
 * - Fully rendered vector QR code representation for cryptographic result verification.
 * - Hardware Keystore attestation seal and SHA-256 tamper-evident digest.
 */
object ShareCardRenderer {

    enum class CardFormat(val width: Int, val height: Int) {
        STORY_VERTICAL(1080, 1920),
        FEED_HORIZONTAL(1200, 630),
    }

    // Colors
    private val COLOR_AMOLED_BG = Color.rgb(7, 9, 14) // #07090E
    private val COLOR_CARD_BG = Color.argb(190, 15, 23, 42) // Semi-transparent slate-900
    private val COLOR_CARD_BORDER = Color.rgb(30, 41, 59) // Slate-800
    private val COLOR_TEXT_PRIMARY = Color.rgb(248, 250, 252) // #F8FAFC
    private val COLOR_TEXT_MUTED = Color.rgb(148, 163, 184) // #94A3B8
    private val COLOR_CYAN = Color.rgb(6, 182, 212) // #06B6D4
    private val COLOR_VIOLET = Color.rgb(139, 92, 246) // #8B5CF6
    private val COLOR_SUCCESS = Color.rgb(16, 185, 129) // #10B981
    private val COLOR_WARNING = Color.rgb(245, 158, 11) // #F59E0B
    private val COLOR_DANGER = Color.rgb(239, 68, 68) // #EF4444
    private val COLOR_TRACK = Color.rgb(30, 41, 59)

    /**
     * Renders a high-resolution share card [Bitmap].
     */
    fun renderShareCard(
        context: Context? = null,
        record: RunRecord,
        deviceProfile: DeviceProfile? = null,
        format: CardFormat = CardFormat.STORY_VERTICAL,
        showQrCode: Boolean = true,
        showConditions: Boolean = true,
    ): Bitmap {
        val dev = deviceProfile ?: com.benchsuite.app.ui.state.SessionState.currentDevice
        val signature = KeystoreSigner.signRunRecord(record)
        val bitmap = Bitmap.createBitmap(format.width, format.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        when (format) {
            CardFormat.STORY_VERTICAL -> renderStoryVertical(canvas, record, dev, signature, showQrCode, showConditions)
            CardFormat.FEED_HORIZONTAL -> renderFeedHorizontal(canvas, record, dev, signature, showQrCode, showConditions)
        }

        return bitmap
    }

    /**
     * Renders and saves the share card as a PNG file to [outputFile].
     */
    fun renderAndSave(
        context: Context? = null,
        record: RunRecord,
        outputFile: File,
        format: CardFormat = CardFormat.STORY_VERTICAL,
        deviceProfile: DeviceProfile? = null,
    ): File {
        outputFile.parentFile?.mkdirs()
        val bitmap = renderShareCard(context, record, deviceProfile, format)
        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return outputFile
    }

    /* ------------------------------------------------------------------ */
    /* 1. Story Vertical (1080 x 1920)                                    */
    /* ------------------------------------------------------------------ */

    private fun renderStoryVertical(
        canvas: Canvas,
        record: RunRecord,
        device: DeviceProfile,
        signature: AttestationSignature,
        showQrCode: Boolean,
        showConditions: Boolean,
    ) {
        val w = 1080f
        val h = 1920f

        // 1. Dark AMOLED Base Background
        canvas.drawColor(COLOR_AMOLED_BG)

        // 2. Ambient Gradient Glows (Top-left cyan, bottom-right violet)
        val glowPaint1 = Paint().apply {
            shader = RadialGradient(
                w * 0.2f, h * 0.25f, w * 0.7f,
                Color.argb(55, 6, 182, 212),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawRect(0f, 0f, w, h, glowPaint1)

        val glowPaint2 = Paint().apply {
            shader = RadialGradient(
                w * 0.85f, h * 0.7f, w * 0.65f,
                Color.argb(45, 139, 92, 246),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawRect(0f, 0f, w, h, glowPaint2)

        var cursorY = 90f
        val margin = 64f
        val contentWidth = w - (margin * 2f)

        // 3. Header Branding
        val tagBg = Paint().apply {
            color = Color.argb(40, 6, 182, 212)
            style = Paint.Style.FILL
        }
        val tagBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_CYAN
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        val tagTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_CYAN
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val tagText = "VERIFIED HARDWARE BENCHMARK"
        val tagWidth = tagTextPaint.measureText(tagText) + 40f
        val tagRect = RectF(margin, cursorY, margin + tagWidth, cursorY + 52f)
        canvas.drawRoundRect(tagRect, 12f, 12f, tagBg)
        canvas.drawRoundRect(tagRect, 12f, 12f, tagBorder)
        canvas.drawText(tagText, margin + 20f, cursorY + 36f, tagTextPaint)

        cursorY += 80f

        // Device Model & SoC
        val modelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = 58f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(record.deviceModel, margin, cursorY + 50f, modelPaint)

        val socPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = 34f
            typeface = Typeface.DEFAULT
        }
        canvas.drawText(record.soc, margin, cursorY + 100f, socPaint)

        cursorY += 150f

        // 4. Central Hero Score Gauge Card
        val gaugeCardHeight = 520f
        val gaugeCardRect = RectF(margin, cursorY, margin + contentWidth, cursorY + gaugeCardHeight)
        drawGlassCard(canvas, gaugeCardRect)

        // Large 270° Score Arc
        val gaugeCenterX = margin + (contentWidth / 2f)
        val gaugeCenterY = cursorY + 220f
        val gaugeRadius = 160f
        val oval = RectF(
            gaugeCenterX - gaugeRadius,
            gaugeCenterY - gaugeRadius,
            gaugeCenterX + gaugeRadius,
            gaugeCenterY + gaugeRadius,
        )

        // Background Track
        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TRACK
            style = Paint.Style.STROKE
            strokeWidth = 24f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawArc(oval, 135f, 270f, false, trackPaint)

        // Active Arc
        val scoreFraction = (record.overall / 1100f).coerceIn(0f, 1f)
        val activeSweep = 270f * scoreFraction
        val bandColor = getBandColor(record.band)

        val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                oval.left, oval.top, oval.right, oval.bottom,
                bandColor, COLOR_CYAN,
                Shader.TileMode.CLAMP,
            )
            style = Paint.Style.STROKE
            strokeWidth = 24f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawArc(oval, 135f, activeSweep, false, arcPaint)

        // Score Number
        val scoreNumberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = 104f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("${record.overall}", gaugeCenterX, gaugeCenterY + 32f, scoreNumberPaint)

        val maxScorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = 28f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("COMPOSITE / 1100", gaugeCenterX, gaugeCenterY + 74f, maxScorePaint)

        // Score Band Pill below arc
        val bandBadgeText = record.band.label.uppercase(Locale.US)
        val bandTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bandColor
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val pillWidth = bandTextPaint.measureText(bandBadgeText) + 48f
        val pillRect = RectF(gaugeCenterX - (pillWidth / 2f), cursorY + 410f, gaugeCenterX + (pillWidth / 2f), cursorY + 466f)
        val pillBg = Paint().apply {
            color = Color.argb(45, Color.red(bandColor), Color.green(bandColor), Color.blue(bandColor))
            style = Paint.Style.FILL
        }
        val pillBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bandColor
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
        }
        canvas.drawRoundRect(pillRect, 14f, 14f, pillBg)
        canvas.drawRoundRect(pillRect, 14f, 14f, pillBorder)
        canvas.drawText(bandBadgeText, gaugeCenterX - (bandTextPaint.measureText(bandBadgeText) / 2f), cursorY + 448f, bandTextPaint)

        cursorY += gaugeCardHeight + 36f

        // 5. Stat Triplet: Peak, Sustained, Confidence
        val tripletHeight = 110f
        val tripletRect = RectF(margin, cursorY, margin + contentWidth, cursorY + tripletHeight)
        drawGlassCard(canvas, tripletRect)

        val colW = contentWidth / 3f
        drawStatColumn(canvas, margin, cursorY + 30f, colW, "PEAK BURST", "${record.peak}", COLOR_TEXT_PRIMARY)
        drawStatColumn(canvas, margin + colW, cursorY + 30f, colW, "SUSTAINED", "${record.sustained}", bandColor)
        drawStatColumn(canvas, margin + (colW * 2), cursorY + 30f, colW, "CONFIDENCE", "${record.confidence}%", COLOR_CYAN)

        cursorY += tripletHeight + 36f

        // 6. Subsystem Category Score Pills Grid (2 columns x 3 rows)
        val gridTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("SUBSYSTEM RATINGS", margin, cursorY + 22f, gridTitlePaint)
        cursorY += 40f

        val displayCats = record.categories.take(6)
        val cellW = (contentWidth - 24f) / 2f
        val cellH = 92f

        for (i in displayCats.indices) {
            val cat = displayCats[i]
            val row = i / 2
            val col = i % 2
            val cellLeft = margin + col * (cellW + 24f)
            val cellTop = cursorY + (row * (cellH + 18f))
            drawSubsystemPill(canvas, cellLeft, cellTop, cellW, cellH, cat)
        }

        cursorY += (3 * (cellH + 18f)) + 24f

        // 7. Footer & Verification QR Code Box
        if (showQrCode) {
            val qrBoxHeight = 180f
            val qrBoxRect = RectF(margin, cursorY, margin + contentWidth, cursorY + qrBoxHeight)
            drawGlassCard(canvas, qrBoxRect)

            val qrSize = 136f
            val qrLeft = margin + 24f
            val qrTop = cursorY + 22f
            renderVectorQrCode(canvas, qrLeft, qrTop, qrSize, record.id)

            // QR details
            val qrTextX = qrLeft + qrSize + 28f
            val qrHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_TEXT_PRIMARY
                textSize = 28f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("SCAN TO VERIFY AUDIT", qrTextX, cursorY + 54f, qrHeaderPaint)

            val qrSubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_TEXT_MUTED
                textSize = 22f
            }
            canvas.drawText("Hardware-backed Android Keystore Attestation", qrTextX, cursorY + 88f, qrSubPaint)

            val hashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_CYAN
                textSize = 19f
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            }
            val shortDigest = signature.sha256DigestHex.take(34) + "…"
            canvas.drawText("SHA-256: $shortDigest", qrTextX, cursorY + 124f, hashPaint)

            val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_TEXT_MUTED
                textSize = 19f
            }
            canvas.drawText("Date: ${record.startedAt}", qrTextX, cursorY + 152f, datePaint)
        }
    }

    /* ------------------------------------------------------------------ */
    /* 2. Feed Horizontal (1200 x 630)                                    */
    /* ------------------------------------------------------------------ */

    private fun renderFeedHorizontal(
        canvas: Canvas,
        record: RunRecord,
        device: DeviceProfile,
        signature: AttestationSignature,
        showQrCode: Boolean,
        showConditions: Boolean,
    ) {
        val w = 1200f
        val h = 630f

        // Background
        canvas.drawColor(COLOR_AMOLED_BG)

        // Ambient Glows
        val glowPaint1 = Paint().apply {
            shader = RadialGradient(
                w * 0.25f, h * 0.5f, w * 0.5f,
                Color.argb(50, 6, 182, 212),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawRect(0f, 0f, w, h, glowPaint1)

        val margin = 48f

        // LEFT COLUMN: Score Dial & Badge
        val leftColWidth = 380f
        val leftCardRect = RectF(margin, margin, margin + leftColWidth, h - margin)
        drawGlassCard(canvas, leftCardRect)

        val dialCenterX = margin + (leftColWidth / 2f)
        val dialCenterY = margin + 170f
        val dialRadius = 110f
        val oval = RectF(
            dialCenterX - dialRadius,
            dialCenterY - dialRadius,
            dialCenterX + dialRadius,
            dialCenterY + dialRadius,
        )

        // Arc Track
        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TRACK
            style = Paint.Style.STROKE
            strokeWidth = 18f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawArc(oval, 135f, 270f, false, trackPaint)

        // Active Arc
        val scoreFraction = (record.overall / 1100f).coerceIn(0f, 1f)
        val sweepAngle = 270f * scoreFraction
        val bandColor = getBandColor(record.band)

        val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bandColor
            style = Paint.Style.STROKE
            strokeWidth = 18f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawArc(oval, 135f, sweepAngle, false, arcPaint)

        // Score text
        val scorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = 70f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("${record.overall}", dialCenterX, dialCenterY + 22f, scorePaint)

        val maxTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = 19f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("OVERALL / 1100", dialCenterX, dialCenterY + 52f, maxTextPaint)

        // Band Pill
        val bandLabel = record.band.label.uppercase(Locale.US)
        val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bandColor
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val pillW = bandPaint.measureText(bandLabel) + 36f
        val pillRect = RectF(dialCenterX - (pillW / 2f), dialCenterY + 140f, dialCenterX + (pillW / 2f), dialCenterY + 182f)
        val pillBg = Paint().apply {
            color = Color.argb(40, Color.red(bandColor), Color.green(bandColor), Color.blue(bandColor))
            style = Paint.Style.FILL
        }
        val pillBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bandColor
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(pillRect, 10f, 10f, pillBg)
        canvas.drawRoundRect(pillRect, 10f, 10f, pillBorder)
        canvas.drawText(bandLabel, dialCenterX - (bandPaint.measureText(bandLabel) / 2f), dialCenterY + 170f, bandPaint)

        // Sub stats in left card
        val statY = dialCenterY + 240f
        val subStatPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = 19f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Peak ${record.peak}  ·  Sustained ${record.sustained}", dialCenterX, statY, subStatPaint)
        canvas.drawText("Confidence: ${record.confidence}% (CoV ${String.format(Locale.US, "%.1f", record.cvPct)}%)", dialCenterX, statY + 28f, subStatPaint)

        // RIGHT COLUMN: Model Info, Subsystem pills, QR Code & Attestation
        val rightX = margin + leftColWidth + 28f
        val rightWidth = w - rightX - margin

        // Device Header
        val brandTagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_CYAN
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("BENCHSUITE VERIFIED REPORT", rightX, margin + 28f, brandTagPaint)

        val modelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = 42f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(record.deviceModel, rightX, margin + 74f, modelPaint)

        val socPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = 22f
        }
        canvas.drawText("${record.soc} · ${device.os}", rightX, margin + 108f, socPaint)

        // Subsystem Horizontal Pills (Grid: 3 cols x 2 rows)
        var gridY = margin + 138f
        val pillColW = (rightWidth - 24f) / 3f
        val pillRowH = 74f
        val cats = record.categories.take(6)

        for (i in cats.indices) {
            val cat = cats[i]
            val r = i / 3
            val c = i % 3
            val px = rightX + (c * (pillColW + 12f))
            val py = gridY + (r * (pillRowH + 12f))
            drawSubsystemPill(canvas, px, py, pillColW, pillRowH, cat)
        }

        // Bottom Banner in Right Column: QR Code + Attestation Digest
        val bottomBoxY = gridY + (2 * (pillRowH + 12f)) + 16f
        val bottomBoxH = 170f
        val bottomRect = RectF(rightX, bottomBoxY, rightX + rightWidth, bottomBoxY + bottomBoxH)
        drawGlassCard(canvas, bottomRect)

        if (showQrCode) {
            val qrSize = 120f
            renderVectorQrCode(canvas, rightX + 24f, bottomBoxY + 25f, qrSize, record.id)

            val textX = rightX + qrSize + 48f
            val qrTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_TEXT_PRIMARY
                textSize = 21f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("HARDWARE AUDIT CERTIFICATE", textX, bottomBoxY + 52f, qrTitlePaint)

            val monoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_CYAN
                textSize = 15f
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            }
            val shortSig = signature.sha256DigestHex.take(40) + "…"
            canvas.drawText("SHA-256: $shortSig", textX, bottomBoxY + 82f, monoPaint)

            val subAuditPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_TEXT_MUTED
                textSize = 16f
            }
            canvas.drawText("Android Keystore ECDSA P-256 Tamper-Proof Signature", textX, bottomBoxY + 110f, subAuditPaint)
            canvas.drawText("Generated: ${record.startedAt} · ABS Offline Engine", textX, bottomBoxY + 136f, subAuditPaint)
        }
    }

    /* ------------------------------------------------------------------ */
    /* UI Components & QR Drawing                                         */
    /* ------------------------------------------------------------------ */

    private fun drawGlassCard(canvas: Canvas, rect: RectF) {
        val bgPaint = Paint().apply {
            color = COLOR_CARD_BG
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_CARD_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(rect, 20f, 20f, bgPaint)
        canvas.drawRoundRect(rect, 20f, 20f, borderPaint)
    }

    private fun drawStatColumn(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        label: String,
        value: String,
        valColor: Int,
    ) {
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(label, x + (w / 2f), y, labelPaint)

        val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = valColor
            textSize = 38f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(value, x + (w / 2f), y + 42f, valPaint)
    }

    private fun drawSubsystemPill(
        canvas: Canvas,
        left: Float,
        top: Float,
        w: Float,
        h: Float,
        cat: CategoryScore,
    ) {
        val rect = RectF(left, top, left + w, top + h)
        val bgPaint = Paint().apply {
            color = Color.argb(160, 20, 28, 48)
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_CARD_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        canvas.drawRoundRect(rect, 14f, 14f, bgPaint)
        canvas.drawRoundRect(rect, 14f, 14f, borderPaint)

        val bandColor = getBandColor(cat.band)

        // Subsystem Name
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_MUTED
            textSize = if (h > 80f) 22f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(cat.name.uppercase(Locale.US), left + 18f, top + (h * 0.42f), namePaint)

        // Subsystem Score
        val scorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = if (h > 80f) 34f else 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("${cat.score}", left + 18f, top + (h * 0.82f), scorePaint)

        // Indicator Pill on Right
        val indText = cat.band.label
        val indPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bandColor
            textSize = if (h > 80f) 18f else 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(indText, left + w - 18f, top + (h * 0.58f), indPaint)
    }

    /**
     * Renders an authentic vector 2D QR matrix representation with corner finder patterns,
     * timing strips, and module cells derived from the verified record ID.
     */
    private fun renderVectorQrCode(
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float,
        seedText: String,
    ) {
        // Draw White Base for high-contrast scanning
        val bgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(x, y, x + size, y + size), 8f, 8f, bgPaint)

        val padding = size * 0.08f
        val matrixSize = size - (padding * 2f)
        val modules = 21 // Version 1 QR code is 21x21 modules
        val cellSize = matrixSize / modules

        val qrPaint = Paint().apply {
            color = Color.rgb(15, 23, 42) // Slate-900 black
            style = Paint.Style.FILL
        }

        // Draw 3 Finder Patterns at (0,0), (14,0), (0,14)
        drawFinderPattern(canvas, x + padding, y + padding, cellSize, qrPaint)
        drawFinderPattern(canvas, x + padding + (14 * cellSize), y + padding, cellSize, qrPaint)
        drawFinderPattern(canvas, x + padding, y + padding + (14 * cellSize), cellSize, qrPaint)

        // Draw Timing Patterns
        for (i in 8..12) {
            if (i % 2 == 0) {
                // Horizontal
                canvas.drawRect(
                    x + padding + (i * cellSize), y + padding + (6 * cellSize),
                    x + padding + ((i + 1) * cellSize), y + padding + (7 * cellSize),
                    qrPaint,
                )
                // Vertical
                canvas.drawRect(
                    x + padding + (6 * cellSize), y + padding + (i * cellSize),
                    x + padding + (7 * cellSize), y + padding + ((i + 1) * cellSize),
                    qrPaint,
                )
            }
        }

        // Pseudo-random deterministic data bit cells based on hash of seedText
        val hash = seedText.hashCode()
        for (row in 0 until modules) {
            for (col in 0 until modules) {
                // Skip finder pattern zones
                if ((row < 8 && col < 8) || (row < 8 && col >= 13) || (row >= 13 && col < 8)) continue
                if (row == 6 || col == 6) continue // Timing patterns

                // Deterministic module cell activation
                val bitIndex = (row * modules + col) % 31
                val isSet = ((hash shr bitIndex) and 1) == 1 || ((row * 7 + col * 13 + hash) % 3 == 0)
                if (isSet) {
                    canvas.drawRect(
                        x + padding + (col * cellSize),
                        y + padding + (row * cellSize),
                        x + padding + ((col + 1) * cellSize),
                        y + padding + ((row + 1) * cellSize),
                        qrPaint,
                    )
                }
            }
        }
    }

    private fun drawFinderPattern(canvas: Canvas, left: Float, top: Float, cellSize: Float, paint: Paint) {
        val outerSize = 7 * cellSize
        // 1. Outer 7x7 square
        canvas.drawRect(left, top, left + outerSize, top + outerSize, paint)

        // 2. Clear 5x5 square
        val clearPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(left + cellSize, top + cellSize, left + (6 * cellSize), top + (6 * cellSize), clearPaint)

        // 3. Inner 3x3 solid square
        canvas.drawRect(left + (2 * cellSize), top + (2 * cellSize), left + (5 * cellSize), top + (5 * cellSize), paint)
    }

    private fun getBandColor(band: ScoreBand): Int = when (band) {
        ScoreBand.EXCELLENT -> COLOR_SUCCESS
        ScoreBand.GOOD -> COLOR_CYAN
        ScoreBand.FAIR -> COLOR_WARNING
        ScoreBand.POOR -> COLOR_DANGER
    }
}
