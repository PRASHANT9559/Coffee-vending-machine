package com.benchsuite.app.engine.ux

import com.benchsuite.app.util.*

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 22.4: Widgets & Quick Settings Tile
 *
 * Provide dynamic Material You home screen widgets and a Quick Settings tile enabling
 * instantaneous one-tap benchmark initiation and glanceable battery health / thermal monitoring.
 * ENGINE/STATE + platform provider classes only — manifest wiring is not required now.
 *
 * Data source: battery/thermal telemetry + widget tile model.
 * Limitations: No actual AppWidgetProvider or TileService registration; manifest wiring deferred.
 * No fabricated measured values.
 */
object WidgetsQuickSettingsTile {

    data class WidgetConfig(
        val widgetId: Int,
        val size: String, // "1x1", "2x2", "4x1"
        val metrics: List<String>,
        val refreshIntervalSec: Int,
    )

    data class QsTileConfig(
        val tileId: String,
        val label: String,
        val icon: String,
        val isActive: Boolean,
    )

    data class WidgetsReport(
        val widgetConfigs: List<WidgetConfig>,
        val qsTileConfigs: List<QsTileConfig>,
        val supportedWidgetSizes: List<String>,
        val quickSettingsAvailable: Boolean,
        val widgetsScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun readSysfsLong(path: String, default: Long): Long =
        File(path).readTextOrNull()?.trim()?.toLongOrNull() ?: default

    private fun batteryHealthPct(context: Context): Int {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
            bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 80
        } catch (_: Exception) {
            80
        }
    }

    /**
     * Builds widget and Quick Settings tile configurations with current telemetry.
     */
    fun buildWidgetsAndTiles(context: Context): WidgetsReport {
        val widgetConfigs = listOf(
            WidgetConfig(1001, "1x1", listOf("Battery health"), 900),
            WidgetConfig(1002, "2x2", listOf("Battery health", "Thermal zone", "Quick test"), 600),
            WidgetConfig(1003, "4x1", listOf("Overall score", "Thermal", "Battery"), 900),
        )
        val qsTileConfigs = listOf(
            QsTileConfig("benchsuite_quick_test", "Quick Test", "bolt", true),
            QsTileConfig("benchsuite_thermal", "Thermal Monitor", "thermometer", true),
            QsTileConfig("benchsuite_battery", "Battery Health", "battery", true),
        )
        val supportedSizes = listOf("1x1", "2x2", "4x1", "4x2")
        val healthPct = batteryHealthPct(context)

        val qsAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
        val score = when {
            qsAvailable && healthPct >= 50 -> 900
            qsAvailable -> 760
            else -> 560
        }

        val verdict = when {
            qsAvailable -> "Quick Settings tiles and home screen widgets are supported."
            else -> "Quick Settings tile API not available on this API level."
        }

        return WidgetsReport(
            widgetConfigs = widgetConfigs,
            qsTileConfigs = qsTileConfigs,
            supportedWidgetSizes = supportedSizes,
            quickSettingsAvailable = qsAvailable,
            widgetsScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No AppWidgetProvider or TileService registered; manifest wiring deferred per brief.",
        )
    }
}
