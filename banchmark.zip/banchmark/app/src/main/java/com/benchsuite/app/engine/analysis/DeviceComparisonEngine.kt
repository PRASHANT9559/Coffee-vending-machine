package com.benchsuite.app.engine.analysis

import com.benchsuite.app.data.model.BenchIcon
import com.benchsuite.app.data.model.RunRecord
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Feature 19.2: Side-by-Side Device Comparison Engine.
 *
 * Implements deterministic diffing between two [RunRecord] instances (Baseline vs Candidate):
 * - Overall & Per-Subsystem Absolute and Percentage Deltas
 * - Statistical Significance validation using combined Coefficient of Variation (CoV)
 * - Category Winner Determination (Baseline, Candidate, or Statistical Tie)
 * - Environmental attribution (isolating ambient temperature & battery discrepancies)
 */
object DeviceComparisonEngine {

    enum class ComparisonWinner(val label: String) {
        CANDIDATE("Candidate Device Ahead"),
        BASELINE("Baseline Device Ahead"),
        TIE("Statistical Tie (Within Variance Margin)"),
    }

    data class SubsystemDelta(
        val categoryId: String,
        val categoryName: String,
        val icon: BenchIcon,
        val baselineScore: Int,
        val candidateScore: Int,
        val deltaScore: Int, // candidate - baseline
        val deltaPercentage: Double, // % lead of candidate over baseline
        val winner: ComparisonWinner,
        val isSignificant: Boolean,
        val explanation: String,
    )

    data class EnvironmentalDiff(
        val tempDeltaC: Double,
        val batteryPctDelta: Int,
        val chargingMismatch: Boolean,
        val thermalStatusMismatch: Boolean,
        val attributionNote: String,
    )

    data class ComparisonReport(
        val baselineId: String,
        val baselineDevice: String,
        val baselineSoc: String,
        val candidateId: String,
        val candidateDevice: String,
        val candidateSoc: String,
        val baselineOverall: Int,
        val candidateOverall: Int,
        val overallDelta: Int,
        val overallDeltaPercentage: Double,
        val overallWinner: ComparisonWinner,
        val isOverallSignificant: Boolean,
        val candidateWins: Int,
        val baselineWins: Int,
        val ties: Int,
        val subsystemDeltas: List<SubsystemDelta>,
        val environmentalDiff: EnvironmentalDiff,
        val executiveSummary: String,
    )

    /**
     * Executes a full deterministic comparison between [baseline] and [candidate].
     */
    fun compare(baseline: RunRecord, candidate: RunRecord): ComparisonReport {
        val baseOverall = baseline.overall.coerceAtLeast(1)
        val candOverall = candidate.overall.coerceAtLeast(1)
        val overallDelta = candOverall - baseOverall
        val overallPct = ((overallDelta.toDouble() / baseOverall) * 1000.0).roundToInt() / 10.0

        // Combined CoV threshold: sqrt(cov1^2 + cov2^2)
        val combinedCov = sqrt(baseline.cvPct * baseline.cvPct + candidate.cvPct * candidate.cvPct)
            .coerceAtLeast(1.5) // minimum 1.5% noise floor
        val isOverallSignificant = abs(overallPct) > combinedCov

        val overallWinner = when {
            !isOverallSignificant -> ComparisonWinner.TIE
            overallDelta > 0 -> ComparisonWinner.CANDIDATE
            else -> ComparisonWinner.BASELINE
        }

        // Subsystem diffing
        val baseCatMap = baseline.categories.associateBy { it.id }
        val candCatMap = candidate.categories.associateBy { it.id }
        val allCatIds = (baseCatMap.keys + candCatMap.keys).distinct()

        var candWins = 0
        var baseWins = 0
        var ties = 0

        val subsystemDeltas = allCatIds.map { id ->
            val baseCat = baseCatMap[id]
            val candCat = candCatMap[id]

            val bScore = baseCat?.score ?: baseOverall
            val cScore = candCat?.score ?: candOverall
            val dScore = cScore - bScore
            val dPct = ((dScore.toDouble() / bScore.coerceAtLeast(1)) * 1000.0).roundToInt() / 10.0

            val isSubsystemSignificant = abs(dPct) > combinedCov
            val catWinner = when {
                !isSubsystemSignificant -> {
                    ties++
                    ComparisonWinner.TIE
                }
                dScore > 0 -> {
                    candWins++
                    ComparisonWinner.CANDIDATE
                }
                else -> {
                    baseWins++
                    ComparisonWinner.BASELINE
                }
            }

            val name = candCat?.name ?: baseCat?.name ?: id.replaceFirstChar { it.uppercase() }
            val icon = candCat?.icon ?: baseCat?.icon ?: BenchIcon.SPEED

            val explanation = when (catWinner) {
                ComparisonWinner.CANDIDATE -> "$name leads by +$dPct% ($cScore vs $bScore pts)."
                ComparisonWinner.BASELINE -> "$name trails by $dPct% ($cScore vs $bScore pts)."
                ComparisonWinner.TIE -> "$name is statistically tied within ±${combinedCov.roundToInt()}% variance ($cScore vs $bScore pts)."
            }

            SubsystemDelta(
                categoryId = id,
                categoryName = name,
                icon = icon,
                baselineScore = bScore,
                candidateScore = cScore,
                deltaScore = dScore,
                deltaPercentage = dPct,
                winner = catWinner,
                isSignificant = isSubsystemSignificant,
                explanation = explanation,
            )
        }

        // Environmental condition diffing
        val tempDelta = candidate.conditions.batteryTempC - baseline.conditions.batteryTempC
        val batteryDelta = candidate.conditions.batteryPct - baseline.conditions.batteryPct
        val chargingMismatch = candidate.conditions.charging != baseline.conditions.charging
        val thermalMismatch = candidate.conditions.thermalStatus != baseline.conditions.thermalStatus

        val envNotes = buildList {
            if (abs(tempDelta) >= 4.0) {
                val cooler = if (tempDelta < 0) candidate.deviceModel else baseline.deviceModel
                add("Temperature delta of ${abs((tempDelta * 10).roundToInt() / 10.0)}°C gave $cooler a thermal headroom advantage.")
            }
            if (chargingMismatch) {
                val chargingDev = if (candidate.conditions.charging) candidate.deviceModel else baseline.deviceModel
                add("$chargingDev was actively charging, which introduces internal Joule heating.")
            }
            if (batteryDelta < -30) {
                add("${candidate.deviceModel} tested at low battery (${candidate.conditions.batteryPct}%), possibly triggering SoC power capping.")
            }
            if (isEmpty()) {
                add("Environmental conditions (temperature, battery, charging status) were closely matched between both runs.")
            }
        }.joinToString(" ")

        val envDiff = EnvironmentalDiff(
            tempDeltaC = (tempDelta * 10.0).roundToInt() / 10.0,
            batteryPctDelta = batteryDelta,
            chargingMismatch = chargingMismatch,
            thermalStatusMismatch = thermalMismatch,
            attributionNote = envNotes,
        )

        // Executive summary synthesis
        val execSummary = buildString {
            when (overallWinner) {
                ComparisonWinner.CANDIDATE -> {
                    append("${candidate.deviceModel} (${candidate.soc}) outperforms ${baseline.deviceModel} (${baseline.soc}) ")
                    append("by an overall margin of +$overallPct% ($candOverall vs $baseOverall points). ")
                    append("It claimed victory in $candWins of ${subsystemDeltas.size} measured subsystems. ")
                }
                ComparisonWinner.BASELINE -> {
                    append("${baseline.deviceModel} (${baseline.soc}) maintains a +${abs(overallPct)}% lead over ")
                    append("${candidate.deviceModel} ($baseOverall vs $candOverall points), winning $baseWins categories. ")
                }
                ComparisonWinner.TIE -> {
                    append("${candidate.deviceModel} and ${baseline.deviceModel} are statistically tied ($candOverall vs $baseOverall points), ")
                    append("with the ${abs(overallPct)}% delta falling inside the ±${combinedCov.roundToInt()}% combined margin of error. ")
                }
            }
            append(envNotes)
        }

        return ComparisonReport(
            baselineId = baseline.id,
            baselineDevice = baseline.deviceModel,
            baselineSoc = baseline.soc,
            candidateId = candidate.id,
            candidateDevice = candidate.deviceModel,
            candidateSoc = candidate.soc,
            baselineOverall = baseOverall,
            candidateOverall = candOverall,
            overallDelta = overallDelta,
            overallDeltaPercentage = overallPct,
            overallWinner = overallWinner,
            isOverallSignificant = isOverallSignificant,
            candidateWins = candWins,
            baselineWins = baseWins,
            ties = ties,
            subsystemDeltas = subsystemDeltas,
            environmentalDiff = envDiff,
            executiveSummary = execSummary,
        )
    }
}
