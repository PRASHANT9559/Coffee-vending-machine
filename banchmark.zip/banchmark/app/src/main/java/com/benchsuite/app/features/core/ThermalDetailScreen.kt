package com.benchsuite.app.features.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.benchsuite.app.ui.state.SessionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Thermal domain deep-dive.
 *
 * Sub-features: active_cooling, zone_correlation.
 */
@Composable
fun ThermalDetailScreen(
    subFeature: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<DomainDetailResult?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        isLoading = true
        error = null
        scope.launch(Dispatchers.Default) {
            runCatching { measure(subFeature) }
                .onSuccess { result = it }
                .onFailure { error = it.message ?: "Thermal feature failed" }
            isLoading = false
        }
    }

    LaunchedEffect(subFeature) { load() }

    DomainDetailScaffold(
        title = titleFor(subFeature),
        subtitle = "Thermal · measured on this device",
        result = result,
        isLoading = isLoading,
        error = error,
        onRetry = { load() },
        onBack = onBack,
        onNavigate = onNavigate,
    )
}

private fun titleFor(subFeature: String): String = when (subFeature) {
    "active_cooling" -> "Active cooling efficiency"
    "zone_correlation" -> "Thermal zone correlation"
    else -> "Thermal feature"
}

private fun measure(subFeature: String): DomainDetailResult = when (subFeature) {
    "active_cooling" -> {
        val r = SessionState.runThermalActiveCooling()
        val tempDrop = r.baselineTempCelsius - r.cooledTempCelsius
        DomainDetailResult(
            score = r.coolingScore,
            verdict = r.verdict,
            metrics = listOf(
                DetailMetric("Active cooling", if (r.hasActiveCooling) "Yes" else "No"),
                DetailMetric("Baseline", fmt(r.baselineTempCelsius), "°C"),
                DetailMetric("Cooled", fmt(r.cooledTempCelsius), "°C"),
                DetailMetric("Drop", fmt(tempDrop), "°C"),
                DetailMetric("Perf delta", fmt(r.performanceDeltaPct), "%"),
                DetailMetric("Phases", r.phases.size.toString()),
            ),
            radar = listOf(
                r.coolingScore / 10f,
                (tempDrop.toFloat() * 10f).coerceIn(0f, 100f),
                r.performanceDeltaPct.toFloat().coerceIn(0f, 100f),
                if (r.hasActiveCooling) 100f else 30f,
                (r.phases.size * 20f).coerceIn(0f, 100f),
            ),
            radarLabels = listOf("Score", "Temp drop", "Perf kept", "Hardware", "Phases"),
            radarMax = 100f,
            radarTitle = "Cooling effectiveness",
            radarCaption = "Temperature reduction against performance retained",
            chartTitle = "Temperature per phase",
            chartCaption = "How temperature evolves through the cooling run",
            chartSeries = r.phases.map { it.avgTempCelsius.toFloat() },
            chartSeries2 = r.phases.map { it.avgPerformancePct.toFloat() },
            chartUnit = "°C",
            distributionTitle = "Phase duration",
            distributionCaption = "Seconds spent in each cooling phase",
            distribution = r.phases.map { it.durationSec.coerceIn(0, 600) },
            distributionFooter = r.phases.map {
                it.phase to "${it.durationSec} s · ${fmt(it.avgPerformancePct, 0)} % perf"
            },
        )
    }

    "zone_correlation" -> {
        val r = SessionState.runThermalZoneMap()
        val hottest = r.zones.maxByOrNull { it.tempCelsius }
        DomainDetailResult(
            score = r.correlationScore,
            verdict = r.verdict,
            metrics = listOf(
                DetailMetric("Zones", r.zones.size.toString()),
                DetailMetric("Pairs", r.correlations.size.toString()),
                DetailMetric("Hottest zone", r.hottestZone),
                DetailMetric("Hottest temp", fmt(r.hottestTempCelsius), "°C"),
                DetailMetric("Peak type", hottest?.type ?: "–"),
            ),
            radar = listOf(
                r.correlationScore / 10f,
                (100f - r.hottestTempCelsius.toFloat() + 30f).coerceIn(0f, 100f),
                (r.zones.size * 12f).coerceIn(0f, 100f),
                (r.correlations.map { it.correlationPct }.averageOrZero().toFloat()).coerceIn(0f, 100f),
                if (r.hottestTempCelsius > 45.0) 35f else 95f,
            ),
            radarLabels = listOf("Score", "Thermals", "Coverage", "Coupling", "Headroom"),
            radarMax = 100f,
            radarTitle = "Thermal coupling",
            radarCaption = "How strongly each zone follows the others",
            chartTitle = "Temperature per zone",
            chartCaption = "Every thermal zone sorted by temperature",
            chartSeries = r.zones.sortedBy { it.tempCelsius }.map { it.tempCelsius.toFloat() },
            chartUnit = "°C",
            distributionTitle = "Zone temperature buckets",
            distributionCaption = "Temperature × 10 per zone, hottest last",
            distribution = r.zones.sortedBy { it.tempCelsius }
                .map { (it.tempCelsius * 10).toInt().coerceIn(0, 900) },
            distributionFooter = r.zones.takeLast(4).map {
                it.name to "${fmt(it.tempCelsius)} °C · ${it.type}"
            },
        )
    }

    else -> DomainDetailResult(score = 0, verdict = "Unknown thermal sub-feature: $subFeature")
}

private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()
