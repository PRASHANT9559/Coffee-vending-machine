package com.benchsuite.app.engine.export

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.benchsuite.app.data.model.RunRecord
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Android Keystore cryptographic signing engine for benchmark reports and export artifacts.
 *
 * Implements hardware-backed ECDSA digital signatures over NIST curve P-256 (secp256r1)
 * with SHA-256 digests. Keys are generated inside the device Trusted Execution
 * Environment (TEE) or StrongBox Keymaster where available.
 *
 * Provides graceful fallback to local software ECDSA keys if AndroidKeyStore
 * provider is unavailable (e.g. during off-device JVM tests).
 */
object KeystoreSigner {

    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val DEFAULT_KEY_ALIAS = "benchsuite_attestation_key_p256"
    private const val EC_CURVE = "secp256r1"
    private const val SIGNATURE_ALGORITHM = "SHA256withECDSA"

    /**
     * Computes the canonical SHA-256 digest and ECDSA digital signature for a [RunRecord].
     */
    fun signRunRecord(
        record: RunRecord,
        keyAlias: String = DEFAULT_KEY_ALIAS,
    ): AttestationSignature {
        val canonicalPayload = buildCanonicalPayload(record)
        val payloadBytes = canonicalPayload.toByteArray(StandardCharsets.UTF_8)

        val digest = MessageDigest.getInstance("SHA-256").digest(payloadBytes)
        val digestHex = formatDigestHex(digest)

        val signatureBytes = signWithKey(payloadBytes, keyAlias)
        val signatureHex = signatureBytes.joinToString("") { "%02x".format(it) }

        val isoTimestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date())

        val isHardwareBacked = isKeyHardwareBacked(keyAlias)

        return AttestationSignature(
            sha256DigestHex = digestHex,
            signatureHex = signatureHex,
            algorithm = SIGNATURE_ALGORITHM,
            keyAlias = keyAlias,
            hardwareBacked = isHardwareBacked,
            keystoreType = if (isHardwareBacked) "AndroidKeyStore(TEE/StrongBox)" else "AndroidKeyStore(Software)",
            signatureTimestamp = isoTimestamp,
        )
    }

    /**
     * Formats raw 32-byte digest into colon-separated hex blocks (e.g. "8d21:44ce:9f07:...").
     */
    fun formatDigestHex(digest: ByteArray): String {
        val hex = digest.joinToString("") { "%02x".format(it) }
        return hex.chunked(4).joinToString(":")
    }

    /**
     * Canonical string serialization of record fields ensuring tamper-evident reproducibility.
     */
    fun buildCanonicalPayload(record: RunRecord): String = buildString {
        append("abs_report_v2|")
        append("id=").append(record.id).append("|")
        append("started_at=").append(record.startedAt).append("|")
        append("device=").append(record.deviceModel).append("|")
        append("soc=").append(record.soc).append("|")
        append("overall=").append(record.overall).append("|")
        append("peak=").append(record.peak).append("|")
        append("sustained=").append(record.sustained).append("|")
        append("confidence=").append(record.confidence).append("|")
        append("cv_pct=").append(record.cvPct).append("|")
        append("conditions=[")
        append("bat=").append(record.conditions.batteryPct).append("%,")
        append("chg=").append(record.conditions.charging).append(",")
        append("temp=").append(record.conditions.batteryTempC).append("C,")
        append("load=").append(record.conditions.backgroundLoadPct).append("%,")
        append("mode=").append(record.conditions.powerMode)
        append("]|")
        append("categories=[")
        record.categories.sortedBy { it.id }.forEachIndexed { idx, cat ->
            if (idx > 0) append(",")
            append("${cat.id}:${cat.score}/${cat.peak}/${cat.sustained}")
        }
        append("]|")
        append("methodology=").append(record.methodologyVersion)
    }

    private fun signWithKey(data: ByteArray, alias: String): ByteArray {
        return try {
            val privateKey = getOrCreateAndroidKeyStoreKey(alias)
            val signature = Signature.getInstance(SIGNATURE_ALGORITHM)
            signature.initSign(privateKey)
            signature.update(data)
            signature.sign()
        } catch (_: Throwable) {
            // Fallback to in-memory standard software EC key if AndroidKeyStore provider fails
            signWithFallbackKey(data)
        }
    }

    @Synchronized
    private fun getOrCreateAndroidKeyStoreKey(alias: String): java.security.PrivateKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        if (keyStore.containsAlias(alias)) {
            val keyEntry = keyStore.getEntry(alias, null) as? KeyStore.PrivateKeyEntry
            if (keyEntry != null) return keyEntry.privateKey
        }

        val keyGenSpec = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY,
        )
            .setAlgorithmParameterSpec(ECGenParameterSpec(EC_CURVE))
            .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
            .build()

        val keyPairGenerator = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_EC,
            KEYSTORE_PROVIDER,
        )
        keyPairGenerator.initialize(keyGenSpec)
        val pair = keyPairGenerator.generateKeyPair()
        return pair.private
    }

    @Volatile
    private var fallbackKeyPair: java.security.KeyPair? = null

    private fun signWithFallbackKey(data: ByteArray): ByteArray {
        val pair = fallbackKeyPair ?: synchronized(this) {
            fallbackKeyPair ?: KeyPairGenerator.getInstance("EC").apply {
                initialize(ECGenParameterSpec(EC_CURVE))
            }.generateKeyPair().also { fallbackKeyPair = it }
        }
        val signature = Signature.getInstance(SIGNATURE_ALGORITHM)
        signature.initSign(pair.private)
        signature.update(data)
        return signature.sign()
    }

    private fun isKeyHardwareBacked(alias: String): Boolean {
        return try {
            val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
            val key = keyStore.getKey(alias, null) ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // KeyInfo check where available
                val factory = java.security.KeyFactory.getInstance(key.algorithm, KEYSTORE_PROVIDER)
                val keyInfoClass = Class.forName("android.security.keystore.KeyInfo")
                val keyInfo = factory.getKeySpec(key, keyInfoClass as Class<java.security.spec.KeySpec>)
                val isInsideSecureHardware = keyInfoClass.getMethod("isInsideSecureHardware").invoke(keyInfo) as? Boolean
                isInsideSecureHardware ?: true
            } else {
                true
            }
        } catch (_: Throwable) {
            false
        }
    }
}
