package com.benchsuite.app.features.core

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.theme.Spacing

/**
 * Catalogue of the deep-dive screens that are wired to real engine measurements.
 *
 * Every entry here opens a screen that runs an actual benchmark, so the list is
 * deliberately limited to the domains that are fully implemented.
 */
private data class DeepDive(
    val domain: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val subFeatures: List<Pair<String, String>>,
)

private val deepDives = listOf(
    DeepDive(
        domain = "cpu",
        title = "CPU micro-architecture",
        subtitle = "Scheduler, cache staircase, SIMD, branch prediction",
        icon = Icons.Outlined.Memory,
        subFeatures = listOf(
            "scheduler" to "Scheduler",
            "cache" to "Cache",
            "simd" to "SIMD",
            "branch" to "Branch",
        ),
    ),
    DeepDive(
        domain = "gpu",
        title = "GPU pipeline",
        subtitle = "VRS, shader stutter, frequency residency, fillrate",
        icon = Icons.Outlined.Speed,
        subFeatures = listOf(
            "vrs" to "VRS",
            "stutter" to "Shader stutter",
            "frequency" to "Frequency",
            "compression" to "Compression",
            "fillrate" to "Fillrate",
        ),
    ),
    DeepDive(
        domain = "ai",
        title = "On-device AI",
        subtitle = "LLM context, Pareto frontier, NPU thermal, RAG",
        icon = Icons.Outlined.Memory,
        subFeatures = listOf(
            "llm" to "LLM context",
            "multimodal" to "Multi-modal",
            "pareto" to "Pareto",
            "stable" to "Diffusion",
            "npu_thermal" to "NPU thermal",
            "load" to "Model load",
            "speculative" to "Speculative",
            "federated" to "Federated",
            "rag" to "RAG",
            "speech" to "Speech",
            "energy" to "Energy/token",
        ),
    ),
    DeepDive(
        domain = "storage",
        title = "Storage behaviour",
        subtitle = "Fragmentation, ZRAM, UFS throttling, endurance",
        icon = Icons.Outlined.Memory,
        subFeatures = listOf(
            "fragmentation" to "Fragmentation",
            "ai_workload" to "AI workload",
            "zram" to "ZRAM",
            "ufs_thermal" to "UFS thermal",
            "endurance" to "Endurance",
            "app_install" to "Install/DEX",
            "small_file" to "Small files",
        ),
    ),
    DeepDive(
        domain = "network",
        title = "Network & radios",
        subtitle = "Wi-Fi 7 MLO, URLLC, UWB, eSIM, bufferbloat",
        icon = Icons.Outlined.Speed,
        subFeatures = listOf(
            "wifi7_mlo" to "Wi-Fi 7 MLO",
            "urllc" to "5G URLLC",
            "satellite_sos" to "Satellite SOS",
            "uwb" to "UWB",
            "esim" to "eSIM",
            "le_audio" to "LE Audio",
            "handover" to "Handover",
            "bufferbloat" to "Bufferbloat",
            "modem_thermal" to "Modem thermal",
            "wifi_roaming" to "Roaming",
        ),
    ),
    DeepDive(
        domain = "battery",
        title = "Power & charging",
        subtitle = "Per-app attribution, wireless, wired curve, idle drain",
        icon = Icons.Outlined.Speed,
        subFeatures = listOf(
            "per_app" to "Per-app",
            "wireless" to "Wireless",
            "reverse_wireless" to "Reverse",
            "wired" to "Wired",
            "idle_drain" to "Idle drain",
        ),
    ),
    DeepDive(
        domain = "gaming",
        title = "Gaming experience",
        subtitle = "Predicted FPS, cloud readiness, touch-to-photon",
        icon = Icons.Outlined.Speed,
        subFeatures = listOf(
            "predicted_fps" to "Predicted FPS",
            "emulator" to "Emulator",
            "cloud_gaming" to "Cloud",
            "app_launch" to "App launch",
            "touch_photon" to "Touch→photon",
            "cold_warm" to "Cold vs warm",
        ),
    ),
    DeepDive(
        domain = "thermal",
        title = "Thermal behaviour",
        subtitle = "Active cooling index, zone correlation map",
        icon = Icons.Outlined.Memory,
        subFeatures = listOf(
            "active_cooling" to "Active cooling",
            "zone_correlation" to "Zone map",
        ),
    ),
)

private val nativeKernels = listOf(
    Routes.NATIVE_CONTEXT_SWITCH to "Context switch",
    Routes.NATIVE_INTERRUPT_LATENCY to "Interrupt latency",
    Routes.NATIVE_PQC to "Post-quantum crypto",
    Routes.NATIVE_RAY_TRACING to "Ray tracing",
    Routes.NATIVE_MESH_SHADER to "Mesh shader",
    Routes.NATIVE_ASYNC_COMPUTE to "Async compute",
    Routes.NATIVE_VULKAN to "Vulkan scanner",
    Routes.NATIVE_MEMORY_PRESSURE to "Memory pressure",
    Routes.NATIVE_RANDOM_IOPS to "Random IOPS",
)

/**
 * Deep-dive directory shown on the Benchmarks tab. Each chip jumps straight to
 * the matching sub-feature screen instead of forcing a second selection step.
 */
@Composable
fun EngineDeepDiveSection(onNavigate: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(Spacing.xs)) {
        deepDives.forEach { dive ->
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        dive.icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(dive.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            dive.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable {
                                dive.subFeatures.firstOrNull()?.let { (id, _) ->
                                    onNavigate(Routes.detail(dive.domain, id))
                                }
                            },
                    )
                }
                Spacer(Modifier.height(Spacing.xs))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    dive.subFeatures.forEach { (id, label) ->
                        StatusChip(
                            text = label,
                            modifier = Modifier.clickable {
                                onNavigate(Routes.detail(dive.domain, id))
                            },
                        )
                    }
                }
            }
        }
    }
}

/** Native (Rust/JNI) kernels, each backed by a real JNI call. */
@Composable
fun NativeKernelSection(onNavigate: (String) -> Unit) {
    SurfaceCard {
        Text("Native kernels (Rust)", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(2.dp))
        Text(
            "JNI-backed microbenchmarks. Unavailable kernels report honestly instead of faking numbers.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        NativeRows(onNavigate)
    }
}

@Composable
private fun NativeRows(onNavigate: (String) -> Unit) {
    Column(Modifier.padding(top = Spacing.xs)) {
        nativeKernels.forEachIndexed { index, (route, label) ->
            if (index > 0) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(route) }
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowForward,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}
