package com.benchsuite.app.nativecore

import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/* ------------------------------------------------------------------ */
/* JSON contract shared with native/bench-core (serde camelCase)      */
/* ------------------------------------------------------------------ */

@Serializable
data class NativeMetric(
    val id: String,
    val label: String,
    val value: Double,
    val unit: String,
    val score: Double,
    val reference: Double,
)

@Serializable
data class NativeSample(
    val tMs: Double,
    val value: Double,
)

@Serializable
data class NativeComponentResult(
    val component: String = "unknown",
    val score: Double = 0.0,
    val band: String = "Poor",
    val confidence: Double = 0.0,
    val cv: Double = 0.0,
    val durationMs: Long = 0,
    val metrics: List<NativeMetric> = emptyList(),
    val samples: List<NativeSample> = emptyList(),
    val notes: List<String> = emptyList(),
)

@Serializable
data class NativeCapabilities(
    val engineVersion: String,
    val abi: String,
    val cores: Int,
    val pageSizeBytes: Long,
    val hasNeon: Boolean,
    val pointerBits: Int,
)

@Serializable
data class NativeVulkanCapabilities(
    val supported: Boolean = false,
    val apiVersion: String = "1.0",
    val deviceName: String = "",
    val deviceType: String = "",
    val driverVersion: String = "",
    val vendorId: Int = 0,
    val deviceId: Int = 0,
    val extensions: List<String> = emptyList(),
    val features: Map<String, Boolean> = emptyMap(),
    val queueFamilies: List<String> = emptyList(),
    val readinessScore: Double = 0.0,
    val notes: List<String> = emptyList(),
)

@Serializable
data class NativeOverallScore(
    val score: Double,
    val band: String,
    val confidence: Double,
    val categories: Int,
    val weights: Map<String, Double> = emptyMap(),
)

@Serializable
data class NativeFinding(
    val id: String = "",
    val severity: String = "",
    val detail: String = "",
)

@Serializable
data class NativeFairPlayReport(
    val risk: Int = 0,
    val verdict: String = "Clean",
    val findings: List<NativeFinding> = emptyList(),
    val notes: List<String> = emptyList(),
)

@Serializable
data class NativeVulkanProbeReport(
    val available: Boolean = false,
    val apiVersion: String = "",
    val driverVersion: String = "",
    val deviceName: String = "",
    val deviceType: String = "",
    val queueFamilies: Int = 0,
    val extensions: List<String> = emptyList(),
    val rayTracing: Boolean = false,
    val rayQuery: Boolean = false,
    val meshShaders: Boolean = false,
    val accelerationStructure: Boolean = false,
    val descriptorIndexing: Boolean = false,
    val geometryShader: Boolean = false,
    val tessellation: Boolean = false,
    val memoryHeapsGb: Double = 0.0,
    val note: String = "",
)

@Serializable
data class NativeThermalPoint(
    val tSec: Double,
    val tempC: Double,
    val powerW: Double,
    val clockGhz: Double,
)

@Serializable
data class NativeThermalPhase(
    val name: String = "",
    val startS: Double = 0.0,
    val endS: Double = 0.0,
    val avgTempC: Double = 0.0,
    val avgClockGhz: Double = 0.0,
    val note: String = "",
)

@Serializable
data class NativeThermalReport(
    val startTempC: Double = 0.0,
    val peakTempC: Double = 0.0,
    val endTempC: Double = 0.0,
    val throttleAtS: Double? = null,
    val peakClockGhz: Double = 0.0,
    val sustainedClockGhz: Double = 0.0,
    val sustainedClockRatio: Double = 0.0,
    val clockDropPct: Double = 0.0,
    val peakPowerW: Double = 0.0,
    val sustainedPowerW: Double = 0.0,
    val powerDropPct: Double = 0.0,
    val verdict: String = "",
    val phases: List<NativeThermalPhase> = emptyList(),
    val notes: List<String> = emptyList(),
)

/**
 * Type-safe wrapper around the Rust core.
 *
 * The library is optional: if `libbench_core.so` is not packaged (UI-only
 * builds), every call returns null and the app keeps using mock data. The
 * `native` Gradle property wires the cargo-ndk build.
 */
object NativeBridge {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    val isAvailable: Boolean
    val version: String
    val loadError: String?

    init {
        var loaded = false
        var loadedVersion = "unavailable"
        var failureMessage: String? = null
        try {
            System.loadLibrary("bench_core")
            loadedVersion = nativeVersion()
            loaded = true
        } catch (failure: Throwable) {
            failureMessage = failure.message ?: failure::class.java.simpleName
        }
        isAvailable = loaded
        version = loadedVersion
        loadError = failureMessage
    }

    val statusLabel: String
        get() = if (isAvailable) "bench-core $version" else "Not packaged (mock mode)"

    val defaultThreads: Int
        get() = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

    private external fun nativeVersion(): String
    private external fun nativeCapabilities(): String
    private external fun nativeRunCpu(durationMs: Int, threads: Int): String
    private external fun nativeRunMemory(durationMs: Int, bufferMb: Int): String
    private external fun nativeRunStorage(directory: String, sizeMb: Int): String
    private external fun nativeRunStress(durationMs: Int, threads: Int): String
    private external fun nativeRunAi(durationMs: Int): String
    private external fun nativeRunGpu(frames: Int, readback: Boolean): String
    private external fun nativeRunContextSwitch(durationMs: Int, threads: Int): String
    private external fun nativeRunStorageQueueDepth(directory: String, queueDepth: Int, sizeMb: Int): String
    private external fun nativeRunMemoryCascade(targetMb: Int, stepMb: Int): String
    private external fun nativeScanVulkanCapabilities(): String
    private external fun nativeRunPqc(durationMs: Int, iterations: Int): String
    private external fun nativeOverallScore(scoresJson: String, confidence: Double): String
    private external fun nativeRunCache(): String
    private external fun nativeFairPlay(): String
    private external fun nativeVulkanCaps(): String
    private external fun nativeAnalyzeThermal(samplesJson: String, thresholdC: Double): String
    private external fun nativeRunRayTracing(durationMs: Int, triangles: Int): String
    private external fun nativeRunMeshShader(durationMs: Int, meshletDensity: Int): String
    private external fun nativeRunAsyncCompute(durationMs: Int, iterations: Int): String

    fun capabilities(): NativeCapabilities? =
        if (!isAvailable) null
        else decode { nativeCapabilities() }

    /** Short integer and FP run, typically 2–3 s per workload. */
    fun runCpu(
        durationMs: Int = 2_500,
        threads: Int = defaultThreads,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunCpu(
                durationMs.coerceIn(250, 15_000),
                threads.coerceIn(1, 32),
            )
        }

    fun runMemory(
        durationMs: Int = 1_500,
        bufferMb: Int = 24,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunMemory(
                durationMs.coerceIn(200, 10_000),
                bufferMb.coerceIn(4, 128),
            )
        }

    /** [directory] must be app-private storage, e.g. `context.filesDir`. */
    fun runStorage(
        directory: File,
        sizeMb: Int = 16,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunStorage(
                directory.absolutePath,
                sizeMb.coerceIn(2, 128),
            )
        }

    /** Sustained all-core load; pair with platform thermal sampling. */
    fun runStress(
        durationMs: Int = 8_000,
        threads: Int = defaultThreads,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunStress(
                durationMs.coerceIn(1_000, 60_000),
                threads.coerceIn(1, 32),
            )
        }

    /** Int8 GEMM and decode proxy until the LiteRT delegate path lands. */
    fun runAi(durationMs: Int = 2_000): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunAi(durationMs.coerceIn(500, 10_000))
        }

    /**
     * Headless GLES offscreen workload. [readback] includes GPU→CPU transfer
     * in the measurement; keep it true for an honest end-to-end number.
     */
    fun runGpu(
        frames: Int = 60,
        readback: Boolean = true,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunGpu(
                frames.coerceIn(8, 240),
                readback,
            )
        }

    /**
     * Feature 1.2: Context Switch Storm.
     * Measures pthread synchronization & context switch latency under high thread counts.
     */
    fun runContextSwitch(
        durationMs: Int = 2_000,
        threads: Int = defaultThreads.coerceAtLeast(2),
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunContextSwitch(
                durationMs.coerceIn(250, 15_000),
                threads.coerceIn(2, 64),
            )
        }

    /**
     * Feature 4.6: Random IOPS Queue-Depth Scaling.
     * Evaluates storage throughput and tail latency across varying queue depths.
     */
    fun runStorageQueueDepth(
        directory: File,
        queueDepth: Int = 16,
        sizeMb: Int = 16,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunStorageQueueDepth(
                directory.absolutePath,
                queueDepth.coerceIn(1, 64),
                sizeMb.coerceIn(2, 128),
            )
        }

    /**
     * Feature 4.3: Memory Pressure Cascade.
     * Stresses allocation throughput and page faulting up to safe thresholds.
     */
    fun runMemoryCascade(
        targetMb: Int = 256,
        stepMb: Int = 32,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunMemoryCascade(
                targetMb.coerceIn(32, 2048),
                stepMb.coerceIn(4, 128),
            )
        }

    /**
     * Feature 2.8: Vulkan Feature & Extension Scanner.
     * Inspects physical device properties, queue families, API version, and extensions.
     */
    fun scanVulkanCapabilities(): NativeVulkanCapabilities? =
        if (!isAvailable) null
        else decode {
            nativeScanVulkanCapabilities()
        }

    /**
     * Feature 1.8: Post-Quantum Cryptography Benchmark.
     * Executes NIST FIPS 203 (ML-KEM-768) and FIPS 204 (ML-DSA-65).
     */
    fun runPqc(
        durationMs: Int = 2_000,
        iterations: Int = 100,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunPqc(
                durationMs.coerceIn(200, 10_000),
                iterations.coerceIn(5, 5_000),
            )
        }

    /**
     * Feature 1.9 & Native cache probe: Pointer-chasing latency across growing working sets (16 KiB - 16 MiB).
     */
    fun runCache(): NativeComponentResult? =
        if (!isAvailable) null
        else decode { nativeRunCache() }

    /**
     * Feature 2.1: Native Ray Tracing BVH & Traversal Workload.
     */
    fun runRayTracing(
        durationMs: Int = 2_000,
        triangles: Int = 50_000,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunRayTracing(
                durationMs.coerceIn(200, 10_000),
                triangles.coerceIn(1_000, 500_000),
            )
        }

    /**
     * Feature 2.4: Native Mesh Shader Pipeline & Task/Meshlet Culling Workload.
     */
    fun runMeshShader(
        durationMs: Int = 2_000,
        meshletDensity: Int = 64,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunMeshShader(
                durationMs.coerceIn(200, 10_000),
                meshletDensity.coerceIn(16, 256),
            )
        }

    /**
     * Feature 2.5: Native GPU Async Compute Saturation.
     */
    fun runAsyncCompute(
        durationMs: Int = 2_000,
        iterations: Int = 100,
    ): NativeComponentResult? =
        if (!isAvailable) null
        else decode {
            nativeRunAsyncCompute(
                durationMs.coerceIn(200, 10_000),
                iterations.coerceIn(10, 2_000),
            )
        }

    /**
     * Feature 17.1 / Fair-Play: Native environment integrity and hook scanner (Frida, Magisk, debugger).
     */
    fun fairPlay(): NativeFairPlayReport? =
        if (!isAvailable) null
        else decode { nativeFairPlay() }

    /**
     * Feature 2.8: Probes Vulkan hardware capabilities (RT, mesh shaders, descriptor indexing).
     */
    fun probeVulkan(): NativeVulkanProbeReport? =
        if (!isAvailable) null
        else decode { nativeVulkanCaps() }

    /**
     * Feature 10.1 & 10.5: Native Thermal Dynamics & Phase Breakdown Storyteller.
     */
    fun analyzeThermal(
        points: List<NativeThermalPoint>,
        thresholdC: Double = 42.0,
    ): NativeThermalReport? =
        if (!isAvailable) null
        else decode {
            nativeAnalyzeThermal(
                json.encodeToString(points),
                thresholdC,
            )
        }

    /**
     * Weighted geometric mean across available component scores.
     * Keys: cpu, gpu, ai, sustained, memory, storage, realWorld.
     */
    fun overallScore(
        scores: Map<String, Double>,
        confidence: Double = 0.8,
    ): NativeOverallScore? =
        if (!isAvailable) null
        else decode {
            nativeOverallScore(
                json.encodeToString(scores),
                confidence.coerceIn(0.0, 1.0),
            )
        }

    private inline fun <reified T> decode(block: () -> String): T? =
        runCatching { json.decodeFromString<T>(block()) }.getOrNull()
}
