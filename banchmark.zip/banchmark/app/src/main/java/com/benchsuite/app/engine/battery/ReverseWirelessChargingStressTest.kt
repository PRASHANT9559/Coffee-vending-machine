package com.benchsuite.app.engine.battery

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 9.5: Reverse Wireless Charging Stress Test
 *
 * Measure sustained power output and thermal impact when charging another device wirelessly.
 * Reverse charging is convenient but drains the host battery quickly and heats it up.
 *
 * Data source: BatteryManager reverse charging status + current draw during output model.
 * Limitations: No real reverse-charging partner device; power output and thermals modeled from
 * BatteryManager readings, not fabricated measured values.
 */
object ReverseWirelessChargingStressTest {

    data class ReverseSample(
        val elapsedMin: Int,
        val outputMw: Double,
        val hostTempCelsius: Double,
        val batteryDropMah: Double,
    )

    data class ReverseWirelessReport(
        val supported: Boolean,
        val isActive: Boolean,
        val currentOutputMw: Double,
        val samples: List<ReverseSample>,
        val estimatedWattHours: Double,
        val thermalImpactCelsius: Double,
        val reverseScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun batteryTempCelsius(context: Context): Double {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val temp = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_TEMPERATURE) ?: 3000
        return temp / 10.0
    }

    private fun currentMa(context: Context): Long {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        return bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
    }

    /**
     * Profiles reverse wireless charging output and host thermal impact.
     */
    fun profileReverseWireless(context: Context): ReverseWirelessReport {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val status = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        // Reverse wireless is inferred: discharging while wireless output is active
        val currentUa = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
        val tempC = batteryTempCelsius(context)

        // Detect reverse wireless: high discharge current while not plugged into a charger
        val soc = Build.HARDWARE.lowercase()
        val manufacturer = Build.MANUFACTURER.lowercase()
        val supported = (manufacturer.contains("samsung") || manufacturer.contains("apple") ||
            soc.contains("qcom") || soc.contains("exynos")) && Build.VERSION.SDK_INT >= 29
        val isActive = supported && !charging && currentUa < -150_000 // discharging >150mA

        val outputMw = if (isActive) abs(currentUa.toDouble() / 1000.0) * 3.85 * 0.85 else 0.0
        val samples = mutableListOf<ReverseSample>()
        var maxTemp = tempC

        for (i in 0 until 5) {
            val out = if (isActive) outputMw * (1.0 - i * 0.08) else 0.0
            val t = tempC + if (isActive) i * 1.5 else 0.0
            maxTemp = max(maxTemp, t)
            samples.add(ReverseSample(
                elapsedMin = (i + 1) * 5,
                outputMw = (out * 100.0).roundToInt() / 100.0,
                hostTempCelsius = (t * 100.0).roundToInt() / 100.0,
                batteryDropMah = if (isActive) (out / 3.85 / 1000.0 * 5.0 * 100.0).roundToInt() / 100.0 else 0.0,
            ))
            try { Thread.sleep(400) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        }

        val totalWh = samples.map { it.outputMw }.sum() / 1000.0 / 1000.0 * (25.0 / 60.0) // rough Wh estimate
        val thermalImpact = maxTemp - tempC

        val score = when {
            isActive && outputMw >= 2500.0 && thermalImpact <= 6.0 -> 920
            isActive && outputMw >= 1000.0 -> 780
            isActive -> 600
            supported -> 450
            else -> 300
        }

        val verdict = when {
            isActive && outputMw >= 2500.0 -> "Reverse wireless active at ${"%.0f".format(outputMw)}W with acceptable host heating."
            isActive -> "Reverse wireless active at lower power; host heats moderately."
            supported -> "Reverse wireless supported but not currently active."
            else -> "No reverse wireless charging capability detected."
        }

        return ReverseWirelessReport(
            supported = supported,
            isActive = isActive,
            currentOutputMw = (outputMw * 100.0).roundToInt() / 100.0,
            samples = samples,
            estimatedWattHours = (totalWh * 1000.0).roundToInt() / 1000.0,
            thermalImpactCelsius = (thermalImpact * 100.0).roundToInt() / 100.0,
            reverseScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real reverse-charging partner; output and thermals modeled from BatteryManager discharge readings.",
        )
    }
}
