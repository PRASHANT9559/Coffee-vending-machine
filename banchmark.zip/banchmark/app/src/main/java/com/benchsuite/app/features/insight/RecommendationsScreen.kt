package com.benchsuite.app.features.insight

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.Recommendation
import com.benchsuite.app.data.model.RecommendationArea
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.FilterPills
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.RecommendationCard
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

private val areaOptions = listOf("All") + RecommendationArea.values().map { it.label }

@Composable
fun RecommendationsScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var applied by remember { mutableStateOf(emptySet<String>()) }

    val area = if (filter == 0) null else RecommendationArea.values()[filter - 1]
    // Real recommendations are the use-case fits derived from the latest real run.
    val visible: List<Recommendation> = SessionState.latestRecordedRunOrNull
        ?.let { SessionState.getUseCaseFits(it) }
        ?.map { fit ->
            Recommendation(
                id = "fit.${fit.name}",
                area = RecommendationArea.UPGRADE,
                title = fit.name,
                body = fit.note,
                impact = "Score ${fit.score}",
                effort = "Low",
                action = "See all use cases",
            )
        } ?: emptyList()

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Recommendations",
            subtitle = "Ranked by measured impact",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Act on the data",
                    title = "Small changes, real gains.",
                    body = "Each action was validated on this device or on the same model. Effort and impact are shown before you commit.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("This session", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusChip(
                            text = if (applied.isEmpty()) "Nothing applied" else "${applied.size} applied",
                            tint = if (applied.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else BenchTheme.colors.success,
                            icon = if (applied.isEmpty()) null else Icons.Outlined.CheckCircle,
                        )
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        ImpactStat("${SessionState.completedRuns.size}", "runs recorded", Modifier.weight(1f))
                        ImpactStat(
                            SessionState.completedRuns.maxOfOrNull { it.overall }?.toString() ?: "—",
                            "best score",
                            Modifier.weight(1f),
                        )
                        ImpactStat(
                            SessionState.latestRecordedRunOrNull?.conditions?.ambientC
                                ?.let { String.format(java.util.Locale.US, "%.1f °C", it) } ?: "—",
                            "ambient",
                            Modifier.weight(1f),
                        )
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Text(
                        "The three highest-value changes from your last run. Applying one only marks it as saved; nothing changes on the device automatically.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                FilterPills(
                    options = areaOptions,
                    selectedIndex = filter,
                    onSelect = { filter = it },
                )
            }

            item {
                SectionHeader(
                    title = if (area == null) "All recommendations" else area.label,
                    actionLabel = if (applied.isEmpty()) null else "Clear",
                    onAction = if (applied.isEmpty()) null else {
                        { applied = emptySet() }
                    },
                )
            }

            if (visible.isEmpty()) {
                item {
                    SurfaceCard {
                        Text("No recommendations in this area.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else {
                items(visible.size) { index ->
                    val rec = visible[index]
                    RecommendationCard(
                        rec = rec,
                        onAction = {
                            applied = if (rec.id in applied) applied - rec.id else applied + rec.id
                        },
                    )
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Tune, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Apply the easy wins", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Six of the eight actions are low effort. Applying all low-effort items does not require a reboot or a settings change you cannot undo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Button(
                        onClick = {
                            applied = visible.map { it.id }.toSet()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                    ) {
                        Text("Save all low-effort actions")
                    }
                }
            }

            item {
                Text(
                    "Impact figures are measured deltas, not marketing estimates. Your result may vary with ambient temperature and background load.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            item {
                Text(
                    "Want the reasoning behind these? Open AI insights.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = Spacing.xs)
                        .clickable { onNavigate(Routes.INSIGHTS) },
                )
            }
        }
    }
}

@Composable
private fun ImpactStat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(value, style = NumericSmall, color = BenchTheme.colors.success)
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
