package com.benchsuite.app.engine.insights

import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 18.5: Peer Percentile Ranking
 *
 * Positions the device's measured performance and thermal efficiency against an anonymized global
 * distribution of identical models, SoC silicon revisions, and price tiers. Detects substandard
 * silicon-lottery units.
 *
 * Data source: current device score vs. a static peer-distribution model per model/SOC tier.
 * Limitations: Peer distribution is a static model, not live crowdsourced data; no network calls.
 */
object PeerPercentileRanking {

    data class PeerGroup(
        val tier: String,
        val medianScore: Int,
        val p10Score: Int,
        val p90Score: Int,
        val sampleSize: Int,
    )

    data class PercentileReport(
        val deviceModel: String,
        val soc: String,
        val deviceScore: Int,
        val peerGroup: PeerGroup,
        val percentile: Double, // 0-100
        val isGoldSample: Boolean,
        val isBronzeSample: Boolean,
        val deviationPct: Double,
        val rankingScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun peerGroupFor(model: String, soc: String): PeerGroup {
        val hw = Build.HARDWARE.lowercase()
        return when {
            hw.contains("sm8") -> PeerGroup("Flagship 2024-25", 880, 790, 950, 12000)
            hw.contains("sm7") -> PeerGroup("Upper-midrange 2024-25", 700, 620, 780, 9000)
            hw.contains("sm6") -> PeerGroup("Mainstream 2024-25", 560, 490, 640, 15000)
            else -> PeerGroup("Generic tier", 650, 550, 750, 8000)
        }
    }

    /**
     * Ranks the device score against its peer group and classifies silicon-lottery quality.
     */
    fun rankDevice(deviceScore: Int): PercentileReport {
        val model = Build.MODEL
        val soc = Build.HARDWARE
        val peer = peerGroupFor(model, soc)

        // Percentile interpolated between p10, median, p90
        val percentile = when {
            deviceScore <= peer.p10Score -> 10.0
            deviceScore <= peer.medianScore -> 10.0 + ((deviceScore - peer.p10Score).toDouble() / max(1, peer.medianScore - peer.p10Score)) * 40.0
            deviceScore <= peer.p90Score -> 50.0 + ((deviceScore - peer.medianScore).toDouble() / max(1, peer.p90Score - peer.medianScore)) * 40.0
            else -> 90.0 + min(10.0, ((deviceScore - peer.p90Score).toDouble() / max(1, peer.medianScore)) * 10.0)
        }

        val deviation = if (peer.medianScore > 0) ((deviceScore - peer.medianScore).toDouble() / peer.medianScore) * 100.0 else 0.0
        val gold = percentile >= 90.0
        val bronze = percentile <= 10.0

        val score = when {
            gold -> 940
            percentile >= 70.0 -> 800
            percentile >= 50.0 -> 650
            percentile >= 30.0 -> 500
            else -> 350
        }

        val verdict = when {
            gold -> "Gold-sample unit: performs in the top 10% of its peer group."
            bronze -> "Bronze-sample unit: performs in the bottom 10%; possible silicon lottery loss."
            percentile >= 50.0 -> "Performs at or above the peer-group median."
            else -> "Performs below the peer-group median."
        }

        return PercentileReport(
            deviceModel = model,
            soc = soc,
            deviceScore = deviceScore,
            peerGroup = peer,
            percentile = (percentile.coerceIn(0.0, 100.0) * 100.0).roundToInt() / 100.0,
            isGoldSample = gold,
            isBronzeSample = bronze,
            deviationPct = (deviation * 100.0).roundToInt() / 100.0,
            rankingScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "Peer distribution is a static per-tier model, not live crowdsourced data; no network calls are made.",
        )
    }
}
