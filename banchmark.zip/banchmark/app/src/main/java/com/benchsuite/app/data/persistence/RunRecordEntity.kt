package com.benchsuite.app.data.persistence

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.RunConditions
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Room entity for persisting a completed benchmark run.
 *
 * Categories and conditions are stored as JSON strings because they are complex
 * object graphs. All primitive fields are flat columns for fast queries.
 */
@Entity(tableName = "run_records")
data class RunRecordEntity(
    @PrimaryKey
    val id: String,
    val startedAt: String,
    val durationLabel: String,
    val deviceModel: String,
    val soc: String,
    val overall: Int,
    val peak: Int,
    val sustained: Int,
    val confidence: Int,
    val cvPct: Double,
    val categoriesJson: String,
    val conditionsJson: String,
    val methodologyVersion: String,
    val verified: Boolean,
    val note: String,
    val createdAtMs: Long = System.currentTimeMillis(),
) {
    val categories: List<CategoryScore>
        get() = Json.decodeFromString(categoriesJson)

    val conditions: RunConditions
        get() = Json.decodeFromString(conditionsJson)

    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        fun fromModel(record: com.benchsuite.app.data.model.RunRecord): RunRecordEntity =
            RunRecordEntity(
                id = record.id,
                startedAt = record.startedAt,
                durationLabel = record.durationLabel,
                deviceModel = record.deviceModel,
                soc = record.soc,
                overall = record.overall,
                peak = record.peak,
                sustained = record.sustained,
                confidence = record.confidence,
                cvPct = record.cvPct,
                categoriesJson = json.encodeToString(CategoryScore.serializer(), record.categories),
                conditionsJson = json.encodeToString(RunConditions.serializer(), record.conditions),
                methodologyVersion = record.methodologyVersion,
                verified = record.verified,
                note = record.note,
            )

        fun toModel(entity: RunRecordEntity): com.benchsuite.app.data.model.RunRecord =
            com.benchsuite.app.data.model.RunRecord(
                id = entity.id,
                startedAt = entity.startedAt,
                durationLabel = entity.durationLabel,
                deviceModel = entity.deviceModel,
                soc = entity.soc,
                overall = entity.overall,
                peak = entity.peak,
                sustained = entity.sustained,
                confidence = entity.confidence,
                cvPct = entity.cvPct,
                categories = entity.categories,
                conditions = entity.conditions,
                methodologyVersion = entity.methodologyVersion,
                verified = entity.verified,
                note = entity.note,
            )
    }
}
