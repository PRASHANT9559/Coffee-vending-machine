package com.benchsuite.app.engine.analysis

import com.benchsuite.app.data.model.BenchIcon
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.UseCaseFit
import com.benchsuite.app.data.model.bandFor
import kotlin.math.roundToInt

/**
 * Feature 18.3: Use-Case Fit Calculator.
 *
 * Evaluates raw and sustained subsystem performance from a [RunRecord] to compute
 * four distinct persona-oriented fit scores (0–100 scale, with corresponding 0–1100
 * category score mapping for UI consistency):
 * 1. Gaming Fit (GPU + Sustained Thermals + Burst CPU + RAM)
 * 2. Daily Driver Fit (CPU Responsiveness + RAM Headroom + Storage 4K IOPS + Battery/Thermals)
 * 3. Creator / Media Fit (GPU Compute + Storage Throughput + Multi-Core CPU + Sustained)
 * 4. AI / Future-Proof Fit (NPU/AI + Memory Bandwidth + SIMD/Vector CPU + Storage QD)
 */
object UseCaseFitCalculator {

    data class FitScoreDetail(
        val name: String,
        val score100: Int,
        val score1100: Int,
        val band: ScoreBand,
        val summaryNote: String,
        val icon: BenchIcon,
        val contributingWeights: Map<String, Double>,
    ) {
        fun toUseCaseFit(): UseCaseFit = UseCaseFit(
            name = name,
            score = score1100,
            note = summaryNote,
            icon = icon,
        )
    }

    data class UseCaseFitReport(
        val gamingFit: FitScoreDetail,
        val dailyDriverFit: FitScoreDetail,
        val creatorFit: FitScoreDetail,
        val aiFutureProofFit: FitScoreDetail,
    ) {
        fun toList(): List<UseCaseFit> = listOf(
            gamingFit.toUseCaseFit(),
            dailyDriverFit.toUseCaseFit(),
            creatorFit.toUseCaseFit(),
            aiFutureProofFit.toUseCaseFit(),
        )
    }

    /**
     * Calculates the 4 persona fit scores from a [RunRecord].
     */
    fun calculate(record: RunRecord): UseCaseFitReport {
        val scoreMap = record.categories.associate { it.id to it.score.toDouble() }

        // Fallbacks for missing categories using record overall or sensible defaults
        val overallD = record.overall.toDouble()
        val cpu = scoreMap["cpu"] ?: overallD
        val gpu = scoreMap["gpu"] ?: overallD
        val memory = scoreMap["memory"] ?: overallD
        val storage = scoreMap["storage"] ?: overallD
        val ai = scoreMap["ai"] ?: overallD
        val sustained = scoreMap["thermal"] ?: scoreMap["sustained"] ?: record.sustained.toDouble()

        val peak = record.peak.coerceAtLeast(1).toDouble()
        val sustainedRecord = record.sustained.coerceAtLeast(1).toDouble()
        val dropRatio = ((peak - sustainedRecord) / peak).coerceIn(0.0, 1.0)

        // 1. Gaming Fit: GPU (35%) + Sustained (30%) + CPU (20%) + Memory (15%)
        val gamingWeights = mapOf(
            "gpu" to 0.35,
            "sustained" to 0.30,
            "cpu" to 0.20,
            "memory" to 0.15,
        )
        var rawGaming = (gpu * 0.35) + (sustained * 0.30) + (cpu * 0.20) + (memory * 0.15)
        // Thermal stability penalty: steep drops degrade gaming experience
        if (dropRatio > 0.15) {
            val penaltyFactor = 1.0 - ((dropRatio - 0.15) * 0.5) // up to 15% penalty
            rawGaming *= penaltyFactor.coerceIn(0.80, 1.0)
        }
        val gaming1100 = rawGaming.roundToInt().coerceIn(1, 1100)
        val gaming100 = (gaming1100 / 11.0).roundToInt().coerceIn(0, 100)
        val gamingNote = when {
            gaming100 >= 85 -> "Exceptional 90–120 FPS high-refresh stability with strong thermal endurance."
            gaming100 >= 70 -> "Smooth 60 FPS in demanding 3D titles; minor frame pacing drops during extended play."
            gaming100 >= 55 -> "Playable in standard titles; thermal throttling reduces sustained frame rates in 3D games."
            else -> "Constrained graphics headroom; recommended for 2D or casual gaming at low settings."
        }

        // 2. Daily Driver Fit: CPU (30%) + Memory (25%) + Storage (25%) + Thermals/Battery (20%)
        val dailyWeights = mapOf(
            "cpu" to 0.30,
            "memory" to 0.25,
            "storage" to 0.25,
            "sustained" to 0.20,
        )
        val rawDaily = (cpu * 0.30) + (memory * 0.25) + (storage * 0.25) + (sustained * 0.20)
        val daily1100 = rawDaily.roundToInt().coerceIn(1, 1100)
        val daily100 = (daily1100 / 11.0).roundToInt().coerceIn(0, 100)
        val dailyNote = when {
            daily100 >= 85 -> "Instantaneous app switching, fluid 120Hz animations, and zero multitasking lag."
            daily100 >= 70 -> "Fast daily responsiveness; handles heavy messaging, browsing, and media streaming effortlessly."
            daily100 >= 55 -> "Reliable general use; occasional micro-stutter when resuming background apps."
            else -> "Basic everyday responsiveness; background apps reload frequently under memory pressure."
        }

        // 3. Creator / Media Fit: GPU (30%) + Storage (30%) + CPU (25%) + Sustained (15%)
        val creatorWeights = mapOf(
            "gpu" to 0.30,
            "storage" to 0.30,
            "cpu" to 0.25,
            "sustained" to 0.15,
        )
        val rawCreator = (gpu * 0.30) + (storage * 0.30) + (cpu * 0.25) + (sustained * 0.15)
        val creator1100 = rawCreator.roundToInt().coerceIn(1, 1100)
        val creator100 = (creator1100 / 11.0).roundToInt().coerceIn(0, 100)
        val creatorNote = when {
            creator100 >= 85 -> "Top-tier 4K/8K video timeline scrub and rapid RAW photo batch export with high sustained writes."
            creator100 >= 70 -> "Capable 4K video rendering and fast photo processing; suitable for content creators."
            creator100 >= 55 -> "Adequate for 1080p social video editing; longer export render times on multi-track timelines."
            else -> "Limited media encoding capacity; heavy exports may trigger thermal step-downs."
        }

        // 4. AI / Future-Proof Fit: AI (40%) + Memory (25%) + CPU SIMD (20%) + Storage (15%)
        val aiWeights = mapOf(
            "ai" to 0.40,
            "memory" to 0.25,
            "cpu" to 0.20,
            "storage" to 0.15,
        )
        val rawAi = (ai * 0.40) + (memory * 0.25) + (cpu * 0.20) + (storage * 0.15)
        val ai1100 = rawAi.roundToInt().coerceIn(1, 1100)
        val ai100 = (ai1100 / 11.0).roundToInt().coerceIn(0, 100)
        val aiNote = when {
            ai100 >= 85 -> "Hardware NPU acceleration ready for on-device 3B+ LLM inference, diffusion, and multi-modal models."
            ai100 >= 70 -> "Solid neural coprocessor performance; handles real-time speech, camera AI, and vector search."
            ai100 >= 55 -> "Partial AI acceleration with occasional CPU fallback; adequate for basic ML tasks."
            else -> "CPU-emulated AI inference; lacks dedicated NPU hardware delegate for local generative models."
        }

        return UseCaseFitReport(
            gamingFit = FitScoreDetail(
                name = "Gaming Fit",
                score100 = gaming100,
                score1100 = gaming1100,
                band = bandFor(gaming1100),
                summaryNote = gamingNote,
                icon = BenchIcon.GAMING,
                contributingWeights = gamingWeights,
            ),
            dailyDriverFit = FitScoreDetail(
                name = "Daily Driver Fit",
                score100 = daily100,
                score1100 = daily1100,
                band = bandFor(daily1100),
                summaryNote = dailyNote,
                icon = BenchIcon.BOLT,
                contributingWeights = dailyWeights,
            ),
            creatorFit = FitScoreDetail(
                name = "Creator / Media Fit",
                score100 = creator100,
                score1100 = creator1100,
                band = bandFor(creator1100),
                summaryNote = creatorNote,
                icon = BenchIcon.CAMERA,
                contributingWeights = creatorWeights,
            ),
            aiFutureProofFit = FitScoreDetail(
                name = "AI / Future-Proof Fit",
                score100 = ai100,
                score1100 = ai1100,
                band = bandFor(ai1100),
                summaryNote = aiNote,
                icon = BenchIcon.AI,
                contributingWeights = aiWeights,
            ),
        )
    }
}
