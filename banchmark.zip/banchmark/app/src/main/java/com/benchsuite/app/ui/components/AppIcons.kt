package com.benchsuite.app.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.benchsuite.app.data.model.BenchIcon

/** Single place mapping domain icons to Material symbols. */
fun iconFor(icon: BenchIcon): ImageVector = when (icon) {
    BenchIcon.CPU -> Icons.Outlined.DeveloperBoard
    BenchIcon.GPU -> Icons.Outlined.Memory
    BenchIcon.MEMORY -> Icons.Outlined.Storage
    BenchIcon.STORAGE -> Icons.Outlined.Folder
    BenchIcon.AI -> Icons.Outlined.Psychology
    BenchIcon.GAMING -> Icons.Outlined.SportsEsports
    BenchIcon.THERMAL -> Icons.Outlined.Thermostat
    BenchIcon.HEALTH -> Icons.Outlined.MonitorHeart
    BenchIcon.INSIGHT -> Icons.Outlined.Lightbulb
    BenchIcon.BATTERY -> Icons.Outlined.BatteryChargingFull
    BenchIcon.SECURITY -> Icons.Outlined.Security
    BenchIcon.DISPLAY -> Icons.Outlined.Smartphone
    BenchIcon.NETWORK -> Icons.Outlined.Wifi
    BenchIcon.CAMERA -> Icons.Outlined.PhotoCamera
    BenchIcon.AUDIO -> Icons.Outlined.GraphicEq
    BenchIcon.SENSOR -> Icons.Outlined.Sensors
    BenchIcon.FOLDABLE -> Icons.Outlined.Tablet
    BenchIcon.AGING -> Icons.Outlined.HourglassEmpty
    BenchIcon.LEADERBOARD -> Icons.Outlined.Leaderboard
    BenchIcon.REPORT -> Icons.Outlined.Description
    BenchIcon.SETTINGS -> Icons.Outlined.Settings
    BenchIcon.DEVICE -> Icons.Outlined.Devices
    BenchIcon.STAR -> Icons.Outlined.Star
    BenchIcon.TUNE -> Icons.Outlined.Tune
    BenchIcon.SPEED -> Icons.Outlined.Speed
    BenchIcon.BOLT -> Icons.Outlined.Bolt
    BenchIcon.SHIELD -> Icons.Outlined.Shield
}
