package com.benchsuite.app.engine.enterprise

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 21.2: CLI & ADB Automation
 *
 * Exposes a command-line interface and broadcast-intent receiver for zero-touch headless benchmark
 * invocation, automated device reboot recovery, and automated JSON result harvesting.
 * COMMAND/INTENT PROTOCOL BUILDER ONLY — no host-side execution, no shell spawning.
 *
 * Data source: in-memory command registry + intent action model.
 * Limitations: No adb shell invocation or command execution; protocol model only.
 */
object CliAdbAutomation {

    const val ACTION_BENCHSUITE_RUN = "com.benchsuite.app.action.RUN_BENCHMARK"
    const val ACTION_BENCHSUITE_ABORT = "com.benchsuite.app.action.ABORT_BENCHMARK"
    const val ACTION_BENCHSUITE_RESULT = "com.benchsuite.app.action.RESULT_READY"
    const val EXTRA_SUITE_ID = "com.benchsuite.app.extra.SUITE_ID"
    const val EXTRA_RESULT_JSON = "com.benchsuite.app.extra.RESULT_JSON"

    enum class Command(val label: String) {
        RUN_QUICK_TEST("run-quick-test"),
        RUN_FULL_SUITE("run-full-suite"),
        ABORT("abort"),
        EXPORT_JSON("export-json"),
        REBOOT_AND_RECOVER("reboot-and-recover"),
    }

    @Serializable
    data class CliCommand(
        val command: Command,
        val args: List<String>,
        val timestampMs: Long,
    )

    @Serializable
    data class AutomationResult(
        val command: Command,
        val accepted: Boolean,
        val resultJson: String?,
        val exitCode: Int,
        val message: String,
    )

    private val json = Json { ignoreUnknownKeys = true; isLenient = true; encodeDefaults = true }

    /**
     * Parses a CLI-style command string into a structured CliCommand.
     */
    fun parseCommand(input: String): CliCommand {
        val parts = input.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        val cmd = when (parts.firstOrNull()?.lowercase()) {
            "run-quick-test" -> Command.RUN_QUICK_TEST
            "run-full-suite" -> Command.RUN_FULL_SUITE
            "abort" -> Command.ABORT
            "export-json" -> Command.EXPORT_JSON
            "reboot-and-recover" -> Command.REBOOT_AND_RECOVER
            else -> Command.ABORT
        }
        return CliCommand(command = cmd, args = parts.drop(1), timestampMs = System.currentTimeMillis())
    }

    /**
     * Builds an AutomationResult for a parsed command (execution delegated to the host).
     */
    fun buildResult(command: CliCommand): AutomationResult {
        return when (command.command) {
            Command.RUN_QUICK_TEST, Command.RUN_FULL_SUITE -> AutomationResult(
                command = command.command,
                accepted = true,
                resultJson = null,
                exitCode = 0,
                message = "Benchmark invocation accepted (host executes the suite).",
            )
            Command.ABORT -> AutomationResult(
                command = command.command,
                accepted = true,
                resultJson = null,
                exitCode = 0,
                message = "Abort signal accepted (host stops the active run).",
            )
            Command.EXPORT_JSON -> AutomationResult(
                command = command.command,
                accepted = true,
                resultJson = null,
                exitCode = 0,
                message = "JSON export requested (host streams results).",
            )
            Command.REBOOT_AND_RECOVER -> AutomationResult(
                command = command.command,
                accepted = true,
                resultJson = null,
                exitCode = 0,
                message = "Reboot-and-recover requested (host reboots device).",
            )
        }
    }

    /**
     * Returns the IntentFilter an Activity/Service should register to receive ADB broadcast commands.
     */
    fun intentFilter(): IntentFilter {
        return IntentFilter().apply {
            addAction(ACTION_BENCHSUITE_RUN)
            addAction(ACTION_BENCHSUITE_ABORT)
            addAction(ACTION_BENCHSUITE_RESULT)
        }
    }

    /**
     * Creates a BroadcastReceiver stub that routes ADB broadcast commands to a handler callback.
     */
    fun broadcastReceiver(onCommand: (CliCommand) -> Unit): BroadcastReceiver {
        return object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val action = intent.action ?: return
                val command = when (action) {
                    ACTION_BENCHSUITE_RUN -> Command.RUN_QUICK_TEST
                    ACTION_BENCHSUITE_ABORT -> Command.ABORT
                    else -> Command.ABORT
                }
                val suiteId = intent.getStringExtra(EXTRA_SUITE_ID) ?: ""
                val cliCommand = CliCommand(
                    command = command,
                    args = listOf(suiteId),
                    timestampMs = System.currentTimeMillis(),
                )
                onCommand(cliCommand)
            }
        }
    }

    /**
     * Serializes an AutomationResult to JSON for ADB result harvesting.
     */
    fun resultToJson(result: AutomationResult): String = json.encodeToString(result)
}
