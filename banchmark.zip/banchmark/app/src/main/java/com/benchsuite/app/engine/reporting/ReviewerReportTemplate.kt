package com.benchsuite.app.engine.reporting

import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 20.3: Reviewer Report Template
 *
 * Provide standardized, press-ready editorial layout templates with predefined chart dimensions,
 * callout boxes, and comparative bar graphs formatted specifically for tech articles. ENGINE
 * MODEL ONLY — no Compose screen, no CMS integration.
 *
 * Data source: current device telemetry + template model.
 * Limitations: No actual chart rendering or CMS export; templates are in-memory models, not
 * fabricated values.
 */
object ReviewerReportTemplate {

    enum class TemplateType(val label: String) {
        FLAGSHIP_REVIEW("Flagship device review"),
        MID_RANGE("Mid-range device review"),
        GAMING_FOCUS("Gaming-focused review"),
        BATTERY_FOCUS("Battery endurance review"),
        CAMERA_FOCUS("Camera-focused review");
    }

    data class ChartPreset(
        val name: String,
        val widthPx: Int,
        val heightPx: Int,
        val chartType: String,
    )

    data class ReportTemplate(
        val type: TemplateType,
        val sections: List<String>,
        val chartPresets: List<ChartPreset>,
        val wordCountEstimate: Int,
    )

    data class ReviewerReport(
        val deviceModel: String,
        val selectedTemplate: TemplateType,
        val template: ReportTemplate,
        val exportFormats: List<String>,
        val templateScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun templateFor(model: String): TemplateType {
        val soc = Build.HARDWARE.lowercase()
        return when {
            soc.contains("sm8") -> TemplateType.FLAGSHIP_REVIEW
            soc.contains("sm7") -> TemplateType.MID_RANGE
            Build.HARDWARE.lowercase().contains("sm6") || Build.HARDWARE.lowercase().contains("mt") -> TemplateType.MID_RANGE
            else -> TemplateType.MID_RANGE
        }
    }

    /**
     * Generates a press-ready reviewer report template for the device.
     */
    fun generateReviewerTemplate(): ReviewerReport {
        val model = Build.MODEL
        val type = templateFor(model)
        val sections = when (type) {
            TemplateType.FLAGSHIP_REVIEW -> listOf("Executive summary", "Design & build", "Display",
                "Performance & gaming", "Camera", "Battery & charging", "Software", "Verdict")
            TemplateType.GAMING_FOCUS -> listOf("Executive summary", "Thermal performance", "Sustained FPS",
                "Touch-to-photon latency", "Battery during gaming", "Verdict")
            TemplateType.BATTERY_FOCUS -> listOf("Executive summary", "Battery capacity", "Idle drain",
                "Screen-on time", "Charging curve", "Verdict")
            TemplateType.CAMERA_FOCUS -> listOf("Executive summary", "Main camera", "Night mode",
                "Video stabilization", "Selfie camera", "Verdict")
            TemplateType.MID_RANGE -> listOf("Executive summary", "Display", "Performance",
                "Camera", "Battery", "Value verdict")
        }
        val chartPresets = listOf(
            ChartPreset("Score radar", 800, 600, "radar"),
            ChartPreset("Thermal decay", 900, 400, "line"),
            ChartPreset("FPS consistency", 900, 400, "line"),
            ChartPreset("Battery drain", 800, 400, "bar"),
        )

        val score = when {
            type == TemplateType.FLAGSHIP_REVIEW -> 940
            type == TemplateType.GAMING_FOCUS -> 880
            else -> 800
        }

        val verdict = when {
            type == TemplateType.FLAGSHIP_REVIEW -> "Flagship review template with all premium sections."
            type == TemplateType.GAMING_FOCUS -> "Gaming-focused template emphasizing thermal and FPS."
            else -> "Standard review template for mid-range devices."
        }

        return ReviewerReport(
            deviceModel = model,
            selectedTemplate = type,
            template = ReportTemplate(type, sections, chartPresets, sections.size * 350),
            exportFormats = listOf("PDF", "Markdown", "HTML"),
            templateScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No actual chart rendering or CMS export; template is an in-memory editorial model.",
        )
    }
}
