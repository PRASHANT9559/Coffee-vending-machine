package com.benchsuite.app.features.data

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.ComparisonBar
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.RadarChart
import com.benchsuite.app.ui.components.RadarLegend
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.SegmentedControl
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.components.bandColor
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing
import java.util.Locale

@Composable
fun CompareScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val current = SessionState.latestRecordedRunOrNull ?: return
    val previous = SessionState.allHistoryRuns.getOrElse(1) { null }
    val hasPrevious = previous != null
    val other = if (hasPrevious) previous!! else current
    val otherLabel = if (hasPrevious) "Previous run" else "No previous run"
    val scoreDelta = if (hasPrevious) current.overall - other.overall else 0

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Comparison",
            subtitle = "${current.deviceModel} vs ${other.deviceModel}",
            onBack = onBack,
            actions = {
                IconAction(Icons.Outlined.Share, "Share comparison") { onNavigate(Routes.SHARE) }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Side by side",
                    title = "Two runs, same protocol.",
                    body = "Compare against the same model or a reference device. Differences are normalized, not raw milliseconds.",
                )
            }

            item {
                SegmentedControl(
                    options = listOf("Previous run"),
                    selectedIndex = 0,
                    onSelect = { },
                    enabled = hasPrevious,
                )
                if (!hasPrevious) {
                    SurfaceCard {
                        Text(
                            "No previous run to compare against. Run a benchmark again to enable comparison.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(current.deviceModel, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                            Text(current.startedAt, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            current.overall.toString(),
                            style = NumericDisplay.copy(fontSize = 30.sp),
                            color = bandColor(current.band),
                        )
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(other.deviceModel, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                            Text(other.startedAt, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            other.overall.toString(),
                            style = NumericDisplay.copy(fontSize = 30.sp),
                            color = bandColor(other.band),
                        )
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusChip(
                            text = if (scoreDelta >= 0) "+$scoreDelta overall" else "$scoreDelta overall",
                            tint = if (scoreDelta >= 0) BenchTheme.colors.success else BenchTheme.colors.danger,
                        )
                        Spacer(Modifier.width(6.dp))
                        StatusChip("Same methodology", tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.weight(1f))
                        Text("2.4.1", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            item {
                ChartCard(
                    title = "Category fingerprint",
                    caption = "Normalized scores. The shaded polygon is $otherLabel.",
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadarChart(
                            values = current.categories.filter { it.id != "health" }.map { it.score.toFloat() },
                            comparison = if (hasPrevious) other.categories.filter { it.id != "health" }.map { it.score.toFloat() } else emptyList(),
                            size = 228.dp,
                        )
                        Spacer(Modifier.width(Spacing.sm))
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            LegendRow(MaterialTheme.colorScheme.primary, "This device")
                            if (hasPrevious) LegendRow(MaterialTheme.colorScheme.secondary, otherLabel)
                        }
                        RadarLegend(current.categories.filter { it.id != "health" }.map { it.name })
                    }
                }
            }

            item { SectionHeader(title = "Category by category", actionLabel = "Report", onAction = {
                SessionState.latestRecordedRunOrNull?.let { onNavigate(Routes.report(it.id)) }
            }) }
            item {
                SurfaceCard {
                    current.categories.forEachIndexed { index, category ->
                        val otherCategory = if (hasPrevious) other.categories.firstOrNull { it.id == category.id } else null
                        if (otherCategory != null) {
                            ComparisonBar(
                                label = category.name,
                                primaryValue = category.score,
                                secondaryValue = otherCategory.score,
                                primaryLabel = "You",
                                secondaryLabel = otherLabel.take(4),
                            )
                            if (index != current.categories.lastIndex) Spacer(Modifier.height(Spacing.md))
                        }
                    }
                }
            }

            item { SectionHeader(title = "Conditions") }
            item {
                SurfaceCard {
                    InfoRow("Battery", "${current.conditions.batteryPct}% vs ${if (hasPrevious) other.conditions.batteryPct else "—"}%")
                    InfoRow("Battery temperature", String.format(Locale.US, "%.1f °C vs ${if (hasPrevious) "%.1f °C" else "—"}", current.conditions.batteryTempC, if (hasPrevious) other.conditions.batteryTempC else 0.0))
                    InfoRow("Ambient", String.format(Locale.US, "%.1f °C vs ${if (hasPrevious) "%.1f °C" else "—"}", current.conditions.ambientC, if (hasPrevious) other.conditions.ambientC else 0.0))
                    InfoRow("Background load", "${current.conditions.backgroundLoadPct}% vs ${if (hasPrevious) other.conditions.backgroundLoadPct else "—"}%")
                    InfoRow("Thermal status", "${current.conditions.thermalStatus} vs ${if (hasPrevious) other.conditions.thermalStatus else "—"}")
                    InfoRow("Free storage", String.format(Locale.US, "%.1f GB vs ${if (hasPrevious) "%.1f GB" else "—"}", current.conditions.freeStorageGb, if (hasPrevious) other.conditions.freeStorageGb else 0.0))
                    InfoRow("Power mode", "${current.conditions.powerMode} vs ${if (hasPrevious) other.conditions.powerMode else "—"}")
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Read this fairly", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusChip("Normalized", tint = BenchTheme.colors.success)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "A 71-point gap is meaningful. Anything under 15 points is inside run-to-run variance and should not drive a purchase or upgrade decision.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag("Confidence 92%")
                        Tag("CV 1.8%")
                        Tag("3 iterations")
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = { SessionState.latestRecordedRunOrNull?.let { onNavigate(Routes.report(it.id)) } },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Icon(Icons.Outlined.Description, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Open comparison report")
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendRow(color: androidx.compose.ui.graphics.Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(color, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
