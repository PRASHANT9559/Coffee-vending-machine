package com.benchsuite.app.engine.export

import kotlinx.serialization.Serializable

/**
 * Standardized time-series telemetry sample polled at 10 Hz (100 ms intervals).
 *
 * Used across the reporting and export subsystem for CSV generation, JSON streaming,
 * and high-resolution vector PDF thermal/power telemetry charts.
 */
@Serializable
data class TelemetrySample(
    val timestampMs: Long,
    val elapsedSec: Double,
    val cpuFreqKhz: Long,
    val gpuLoadPct: Int,
    val tempCelsius: Double,
    val powerMw: Double,
    val batteryPct: Int = 0,
    val fps: Int = 0,
)

/**
 * Hardware-backed cryptographic attestation signature and hash for tamper-proofing.
 */
@Serializable
data class AttestationSignature(
    val sha256DigestHex: String,
    val signatureHex: String,
    val algorithm: String = "SHA256withECDSA",
    val keyAlias: String = "benchsuite_attestation_key",
    val hardwareBacked: Boolean = true,
    val keystoreType: String = "AndroidKeyStore",
    val signatureTimestamp: String,
)
