package com.benchsuite.app.engine.analysis

import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 14.6: Security Patch Freshness & Exposure Score Scanner.
 *
 * Inspects `Build.VERSION.SECURITY_PATCH`, computes patch lag days relative to
 * current release cycles, evaluates OS End-Of-Life (EOL) posture, and calculates
 * a 0–100 Security Exposure Score.
 */
object SecurityPatchScanner {

    enum class SecurityRiskBand(val label: String, val minScore: Int, val maxScore: Int) {
        MINIMAL("Current / Fully Patched", 0, 15),
        LOW("Low Exposure", 16, 35),
        MODERATE("Moderate Risk (Update Pending)", 36, 60),
        HIGH("High Exposure (Patch Lapsed)", 61, 85),
        CRITICAL("Critical Risk (Severe Lag / EOL)", 86, 100),
    }

    enum class EolStatus(val label: String, val isEol: Boolean) {
        ACTIVE_SUPPORT("Active Official Support (Security Patches Active)", false),
        APPROACHING_EOL("Approaching Maintenance End-of-Life", false),
        END_OF_LIFE("End of Life (No Security Updates Provided)", true),
    }

    data class PatchScanResult(
        val patchDateString: String,
        val parsedDate: Date?,
        val evaluationDate: Date,
        val patchLagDays: Long,
        val exposureScore: Int, // 0 = Best (Zero exposure), 100 = Worst (Critical)
        val riskBand: SecurityRiskBand,
        val eolStatus: EolStatus,
        val androidApiLevel: Int,
        val androidRelease: String,
        val cveWindowSummary: String,
        val complianceVerdict: String,
        val recommendations: List<String>,
    )

    /**
     * Scans the current device environment and evaluates security patch posture.
     * [overridePatchDate] allows injecting a patch string for testing or historical verification.
     * [referenceDate] overrides current wall clock for deterministic time calculations.
     */
    fun scan(
        overridePatchDate: String? = null,
        referenceDate: Date = Date(),
    ): PatchScanResult {
        val rawPatch = overridePatchDate ?: Build.VERSION.SECURITY_PATCH
        val apiLevel = Build.VERSION.SDK_INT
        val release = Build.VERSION.RELEASE

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var parsedDate: Date? = null
        try {
            parsedDate = dateFormat.parse(rawPatch)
        } catch (_: Exception) {
            // Some vendors format as "d MMMM yyyy" or similar fallback
            val altFormats = listOf(
                SimpleDateFormat("d MMMM yyyy", Locale.US),
                SimpleDateFormat("MMMM yyyy", Locale.US),
                SimpleDateFormat("yyyy-MM", Locale.US),
            )
            for (fmt in altFormats) {
                try {
                    parsedDate = fmt.parse(rawPatch)
                    if (parsedDate != null) break
                } catch (_: Exception) { }
            }
        }

        // Calculate lag in days
        val lagDays: Long = if (parsedDate != null) {
            val diffMs = referenceDate.time - parsedDate.time
            max(0L, TimeUnit.MILLISECONDS.toDays(diffMs))
        } else {
            // If completely unparseable, penalize with 180 days default
            180L
        }

        // Evaluate Android OS EOL Status
        val eolStatus = when {
            apiLevel >= 33 -> EolStatus.ACTIVE_SUPPORT // Android 13, 14, 15, 16+
            apiLevel in 31..32 -> EolStatus.APPROACHING_EOL // Android 12 / 12L
            else -> EolStatus.END_OF_LIFE // Android 11, 10 or earlier
        }

        // Calculate 0 - 100 Exposure Score (0 = secure, 100 = extreme risk)
        val baseExposure = when {
            lagDays <= 30 -> (lagDays / 30.0 * 15.0)
            lagDays <= 90 -> 15.0 + ((lagDays - 30) / 60.0 * 20.0) // 15 - 35
            lagDays <= 180 -> 35.0 + ((lagDays - 90) / 90.0 * 25.0) // 35 - 60
            lagDays <= 365 -> 60.0 + ((lagDays - 180) / 185.0 * 25.0) // 60 - 85
            else -> 85.0 + min(15.0, (lagDays - 365) / 100.0 * 15.0) // 85 - 100
        }

        val eolPenalty = when (eolStatus) {
            EolStatus.END_OF_LIFE -> 20.0
            EolStatus.APPROACHING_EOL -> 8.0
            EolStatus.ACTIVE_SUPPORT -> 0.0
        }

        val exposureScore = (baseExposure + eolPenalty).roundToInt().coerceIn(0, 100)

        val riskBand = when {
            exposureScore <= SecurityRiskBand.MINIMAL.maxScore -> SecurityRiskBand.MINIMAL
            exposureScore <= SecurityRiskBand.LOW.maxScore -> SecurityRiskBand.LOW
            exposureScore <= SecurityRiskBand.MODERATE.maxScore -> SecurityRiskBand.MODERATE
            exposureScore <= SecurityRiskBand.HIGH.maxScore -> SecurityRiskBand.HIGH
            else -> SecurityRiskBand.CRITICAL
        }

        val cveSummary = when {
            lagDays <= 30 -> "Up to date: Protected against all known Android Security Bulletin CVEs published to date."
            lagDays <= 90 -> "Minor window: Vulnerable to recent high-severity bulletin CVEs patched in the last 1–3 months."
            lagDays <= 180 -> "Expanded vulnerability window: Exposed to kernel and framework privilege escalation CVEs from past 6 months."
            else -> "Severe exposure window: Missing critical remote code execution (RCE) and local privilege escalation (LPE) patches."
        }

        val verdict = when (riskBand) {
            SecurityRiskBand.MINIMAL -> "Compliant with enterprise zero-trust security baselines."
            SecurityRiskBand.LOW -> "Adequate consumer security posture; update available soon."
            SecurityRiskBand.MODERATE -> "Security update overdue. Check System Settings > Software Update."
            SecurityRiskBand.HIGH -> "High risk. Device firmware is lagging behind active Android security bulletins."
            SecurityRiskBand.CRITICAL -> "Critical compliance failure. OS is End-of-Life or unpatched for >1 year."
        }

        val recs = mutableListOf<String>()
        if (lagDays > 45) {
            recs.add("Navigate to Settings > Security > System Update to check for pending OEM firmware updates.")
        }
        if (eolStatus.isEol) {
            recs.add("Android $release (API $apiLevel) has reached End of Life. Consider migrating to a supported Android 14+ device.")
        }
        if (recs.isEmpty()) {
            recs.add("Device security patch level is optimal. Maintain automatic background system updates.")
        }

        return PatchScanResult(
            patchDateString = rawPatch,
            parsedDate = parsedDate,
            evaluationDate = referenceDate,
            patchLagDays = lagDays,
            exposureScore = exposureScore,
            riskBand = riskBand,
            eolStatus = eolStatus,
            androidApiLevel = apiLevel,
            androidRelease = release,
            cveWindowSummary = cveSummary,
            complianceVerdict = verdict,
            recommendations = recs,
        )
    }
}
