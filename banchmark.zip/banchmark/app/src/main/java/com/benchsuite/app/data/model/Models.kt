package com.benchsuite.app.data.model

import kotlinx.serialization.Serializable

/* ----------------------------- Scores ----------------------------- */

enum class ScoreBand(val label: String) {
    EXCELLENT("Excellent"),
    GOOD("Good"),
    FAIR("Fair"),
    POOR("Poor"),
}

fun bandFor(score: Int): ScoreBand = when {
    score >= 1200 -> ScoreBand.EXCELLENT
    score >= 900 -> ScoreBand.GOOD
    score >= 600 -> ScoreBand.FAIR
    else -> ScoreBand.POOR
}

enum class Trend { UP, DOWN, FLAT }

enum class BenchIcon {
    CPU, GPU, MEMORY, STORAGE, AI, GAMING, THERMAL, HEALTH,
    INSIGHT, BATTERY, SECURITY, DISPLAY, NETWORK, CAMERA,
    AUDIO, SENSOR, FOLDABLE, AGING, LEADERBOARD, REPORT,
    SETTINGS, DEVICE, STAR, TUNE, SPEED, BOLT, SHIELD,
}

/* --------------------------- Categories --------------------------- */

@Serializable
data class CategoryScore(
    val id: String,
    val name: String,
    val score: Int,
    val peak: Int,
    val sustained: Int,
    val deltaPct: Double,
    val icon: BenchIcon,
    val summary: String,
    val testCount: Int,
) {
    val band: ScoreBand get() = bandFor(score)
}

data class TestDefinition(
    val id: String,
    val name: String,
    val description: String,
    val categoryId: String,
    val minutes: Int,
    val difficulty: String,
    val innovation: Int,
    val priority: String,
    val availability: TestAvailability = TestAvailability.READY,
    val availabilityNote: String = "Ready",
)

enum class TestAvailability { READY, LIMITED, UNAVAILABLE }

/**
 * Pure catalog definition for a benchmark category. Contains NO measured data:
 * scores, metrics, charts, insights and verdicts always come from real runs
 * (see SessionState) or honest empty states.
 */
data class CategorySpec(
    val id: String,
    val title: String,
    val shortTitle: String,
    val icon: BenchIcon,
    val tagline: String,
    val description: String,
    val tests: List<TestDefinition>,
)

data class MetricValue(
    val label: String,
    val value: String,
    val unit: String = "",
    val caption: String,
    val trend: Trend = Trend.FLAT,
    val trendLabel: String = "",
)

data class UseCaseFit(
    val name: String,
    val score: Int,
    val note: String,
    val icon: BenchIcon,
) {
    val band: ScoreBand get() = bandFor(score)
}

/* ------------------------------ Runs ----------------------------- */

@Serializable
data class RunConditions(
    val batteryPct: Int,
    val charging: Boolean,
    val batteryTempC: Double,
    val ambientC: Double,
    val backgroundLoadPct: Int,
    val thermalStatus: String,
    val freeStorageGb: Double,
    val powerMode: String,
    // Phase 5: real hardware detection
    val ramTotalMb: Long = 0,
    val ramType: String = "Unknown",
    val storageTechnology: String = "Unknown",
    val displayWidthPx: Int = 0,
    val displayHeightPx: Int = 0,
    val batteryCapacityMah: Int = 0,
)

data class RunRecord(
    val id: String,
    val startedAt: String,
    val durationLabel: String,
    val deviceModel: String,
    val soc: String,
    val overall: Int,
    val peak: Int,
    val sustained: Int,
    val confidence: Int,
    val cvPct: Double,
    val categories: List<CategoryScore>,
    val conditions: RunConditions,
    val methodologyVersion: String,
    val verified: Boolean,
    val note: String = "",
) {
    val band: ScoreBand get() = bandFor(overall)
}

/* --------------------------- Intelligence ------------------------ */

enum class InsightSeverity { STRENGTH, INFO, WARNING, CRITICAL }

data class Insight(
    val id: String,
    val severity: InsightSeverity,
    val title: String,
    val body: String,
    val evidence: String,
    val tag: String,
)

data class Recommendation(
    val id: String,
    val area: RecommendationArea,
    val title: String,
    val body: String,
    val impact: String,
    val effort: String,
    val action: String,
)

enum class RecommendationArea(val label: String) {
    GAMING("Gaming"),
    THERMAL("Thermal"),
    BATTERY("Battery"),
    AI("AI"),
    STORAGE("Storage"),
    UPGRADE("Upgrade"),
}

/* ---------------------------- Reports ---------------------------- */

enum class ReportType(val label: String) {
    FULL("Full report"),
    QUICK("Quick report"),
    HEALTH("Health report"),
    COMPARISON("Comparison"),
    CUSTOM("Custom suite"),
}

data class ReportItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val date: String,
    val type: ReportType,
    val pages: Int,
    val score: Int,
    val shared: Boolean,
    val sizeLabel: String,
)

/* --------------------------- Community --------------------------- */

data class LeaderboardEntry(
    val rank: Int,
    val model: String,
    val soc: String,
    val score: Int,
    val region: String,
    val verified: Boolean,
    val isMine: Boolean = false,
    val deltaRank: Int = 0,
)

data class Badge(
    val id: String,
    val title: String,
    val description: String,
    val unlocked: Boolean,
    val icon: BenchIcon,
)

/* ----------------------------- Device ---------------------------- */

data class CapabilityItem(
    val name: String,
    val supported: Boolean,
    val detail: String,
)

data class DeviceProfile(
    val manufacturer: String,
    val model: String,
    val soc: String,
    val cpuTopology: String,
    val gpu: String,
    val npu: String,
    val ram: String,
    val ramType: String,
    val storage: String,
    val storageType: String,
    val display: String,
    val resolution: String,
    val refresh: String,
    val os: String,
    val securityPatch: String,
    val kernel: String,
    val battery: String,
    val charging: String,
    val build: String,
    val fingerprint: String,
    val thermalZones: Int,
    val capabilities: List<CapabilityItem>,
    val storageFreeGb: Double,
    val batteryHealthPct: Int,
    val batteryCycles: Int,
)

/* ----------------------------- Charts ---------------------------- */

data class ChartPoint(val x: Float, val y: Float)

data class ChartSeries(
    val label: String,
    val points: List<Float>,
    val colorIndex: Int = 0,
)

data class HistoryPoint(val label: String, val score: Int, val runId: String)

data class FaqItem(val question: String, val answer: String)

data class ScheduleItem(
    val id: String,
    val title: String,
    val cadence: String,
    val nextRun: String,
    val priority: String,
    val enabled: Boolean,
)

data class CustomTestOption(
    val test: TestDefinition,
    val selected: Boolean,
)

/* ---------------------------- Settings --------------------------- */

enum class ThemeMode { SYSTEM, DARK, LIGHT }
enum class ChartStyle { LINE, AREA, BAR }
enum class UnitsMode { METRIC, IMPERIAL }

data class SettingsState(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val dynamicColor: Boolean = false,
    val reduceMotion: Boolean = false,
    val chartStyle: ChartStyle = ChartStyle.AREA,
    val units: UnitsMode = UnitsMode.METRIC,
    val keepScreenOn: Boolean = true,
    val performanceMode: Boolean = true,
    val haptics: Boolean = true,
    val scheduledHealth: Boolean = true,
    val anomalyAlerts: Boolean = true,
    val crashReports: Boolean = false,
    val analytics: Boolean = false,
    val leaderboardUpload: Boolean = false,
    val cloudSync: Boolean = false,
)

data class ConsentItem(
    val title: String,
    val body: String,
    val enabled: Boolean,
    val required: Boolean = false,
)

data class PrivacyInventory(
    val label: String,
    val detail: String,
    val stored: String,
)

/* --------------------------- Live run ---------------------------- */

data class ActiveRun(
    val categoryId: String,
    val title: String,
    val totalTests: Int,
    val completedTests: Int,
    val currentTest: String,
    val progress: Float,
    val elapsedSec: Int,
    val etaSec: Int,
    val liveFps: Int,
    val temperatureC: Double,
    val powerW: Double,
    val cpuClockGhz: Double,
    val paused: Boolean,
    val cooling: Boolean,
    val isNative: Boolean = false,
) {
    val remainingLabel: String
        get() {
            val m = etaSec / 60
            val s = etaSec % 60
            return if (m > 0) "${m}m ${s}s left" else "${s}s left"
        }
}

data class RunTestStep(
    val name: String,
    val category: String,
    val state: StepState,
    val detail: String,
)

enum class StepState { DONE, ACTIVE, PENDING, SKIPPED }

/* ----------------------------- Misc ------------------------------ */

data class NavigationShortcut(
    val key: String,
    val title: String,
    val subtitle: String,
    val icon: BenchIcon,
)

data class EnvironmentCheck(
    val title: String,
    val detail: String,
    val status: CheckStatus,
    val fixLabel: String? = null,
)

enum class CheckStatus { PASS, WARN, FAIL }

data class TrendStat(
    val label: String,
    val value: String,
    val delta: String,
    val trend: Trend,
)
