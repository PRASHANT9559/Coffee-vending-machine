package com.benchsuite.app.engine.productivity

import com.benchsuite.app.util.*

import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 13.1: Mobile Video Export Time Predictor
 *
 * Predicts export time for 4K/8K HEVC/AV1 video projects based on hardware capabilities and
 * thermal profile. Video editors need to know "will this export before my flight boards?"
 *
 * Data source: hardware class detection + encode-time model per resolution/codec.
 * Limitations: No real video encoder is invoked; export times are modeled per device class, not
 * fabricated measured values.
 */
object MobileVideoExportTimePredictor {

    data class ExportPrediction(
        val resolution: String,
        val codec: String,
        val durationMinutes: Double,
        val predictedExportSec: Double,
        val thermalThrottleRisk: String,
    )

    data class ExportReport(
        val deviceClass: String,
        val predictions: List<ExportPrediction>,
        val averageExportSecPerMinute: Double,
        val exportScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun deviceTier(): String {
        val hw = Build.HARDWARE.lowercase()
        val model = Build.MODEL.lowercase()
        return when {
            hw.contains("sm8") || model.contains("galaxy s2") || model.contains("pixel 8") ||
            model.contains("pixel 9") -> "Flagship"
            hw.contains("sm7") || model.contains("galaxy a") || model.contains("pixel 7") -> "Upper-midrange"
            hw.contains("sm6") -> "Mainstream"
            else -> "Entry-level"
        }
    }

    /**
     * Predicts video export time per minute of source footage by resolution/codec.
     */
    fun predictExportTimes(): ExportReport {
        val tier = deviceTier()
        val tierFactor = when (tier) {
            "Flagship" -> 0.5
            "Upper-midrange" -> 1.0
            "Mainstream" -> 1.9
            else -> 3.2
        }

        val predictions = listOf(
            Triple("1080p", "HEVC", 60.0),
            Triple("4K", "HEVC", 60.0),
            Triple("4K", "AV1", 60.0),
            Triple("8K", "HEVC", 60.0),
        ).map { (res, codec, srcMin) ->
            val baseSecPerMin = when (res) {
                "1080p" -> 20.0
                "4K" -> 90.0
                "8K" -> 340.0
                else -> 45.0
            }
            val codecFactor = if (codec == "AV1") 1.8 else 1.0
            val predicted = baseSecPerMin * tierFactor * codecFactor
            val thermalRisk = when {
                predicted <= 60.0 -> "Low"
                predicted <= 180.0 -> "Moderate"
                else -> "High"
            }
            ExportPrediction(
                resolution = res,
                codec = codec,
                durationMinutes = srcMin,
                predictedExportSec = (predicted * 10.0).roundToInt() / 10.0,
                thermalThrottleRisk = thermalRisk,
            )
        }

        val avgSecPerMin = predictions.averageOf { it.predictedExportSec / it.durationMinutes }
        val score = when {
            avgSecPerMin <= 60.0 -> 920
            avgSecPerMin <= 150.0 -> 780
            avgSecPerMin <= 300.0 -> 600
            else -> 420
        }

        val verdict = when {
            avgSecPerMin <= 60.0 -> "Fast export; real-time or better for most codecs."
            avgSecPerMin <= 150.0 -> "Acceptable export times for mobile editing."
            else -> "Slow export; long waits for 4K/8K projects."
        }

        return ExportReport(
            deviceClass = tier,
            predictions = predictions,
            averageExportSecPerMinute = (avgSecPerMin * 100.0).roundToInt() / 100.0,
            exportScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real video encoder invoked; export times are modeled per device class and codec.",
        )
    }
}
