package com.benchsuite.app.engine.productivity

import com.benchsuite.app.util.*

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 13.6: Photo Batch Edit & RAW Export
 *
 * Process a fixed set of RAW photos with edits and export, reporting throughput. Photographers
 * need batch speed on mobile.
 *
 * Data source: camera RAW capability + per-photo edit/export timing model.
 * Limitations: No real RAW photos or image pipeline; throughput modeled per photo count, not
 * fabricated measured values.
 */
object PhotoBatchEditRawExport {

    data class BatchResult(
        val photoCount: Int,
        val editOps: Int,
        val totalTimeSec: Double,
        val photosPerSec: Double,
        val avgEditMs: Double,
    )

    data class PhotoBatchReport(
        val rawSupported: Boolean,
        val results: List<BatchResult>,
        val averagePhotosPerSec: Double,
        val photoBatchScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun supportsRaw(context: Context): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_RAW)
    }

    /**
     * Benchmarks batch photo edit and RAW export throughput.
     */
    fun benchmarkBatchExport(context: Context): PhotoBatchReport {
        val rawSupported = supportsRaw(context)
        val tierFactor = when {
            Build.HARDWARE.lowercase().contains("sm8") -> 0.7
            Build.HARDWARE.lowercase().contains("sm7") -> 1.0
            else -> 1.6
        }

        val results = listOf(10, 25, 50).map { count ->
            val editMsPerPhoto = 450.0 * tierFactor
            val exportMsPerPhoto = if (rawSupported) 900.0 * tierFactor else 400.0 * tierFactor
            val totalMs = count * (editMsPerPhoto + exportMsPerPhoto)
            BatchResult(count, 3, (totalMs / 1000.0 * 100.0).roundToInt() / 100.0,
                (count.toDouble() / max(totalMs, 1.0) * 1000.0 * 100.0).roundToInt() / 100.0,
                ((editMsPerPhoto + exportMsPerPhoto) * 100.0).roundToInt() / 100.0)
        }

        val avgPhotosPerSec = results.averageOf { it.photosPerSec }
        val score = when {
            avgPhotosPerSec >= 1.5 -> 900
            avgPhotosPerSec >= 0.8 -> 740
            avgPhotosPerSec >= 0.4 -> 580
            else -> 400
        }

        val verdict = when {
            avgPhotosPerSec >= 1.5 -> "Fast batch RAW export; photographers can cull and export quickly."
            avgPhotosPerSec >= 0.8 -> "Acceptable batch editing throughput."
            else -> "Slow batch export; large RAW sets take significant time."
        }

        return PhotoBatchReport(
            rawSupported = rawSupported,
            results = results,
            averagePhotosPerSec = (avgPhotosPerSec * 100.0).roundToInt() / 100.0,
            photoBatchScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real RAW photos or image pipeline; throughput modeled per photo count and device tier.",
        )
    }
}
