package com.benchsuite.app.engine.social

import com.benchsuite.app.util.*

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 19.5: Community Heatmap
 *
 * Aggregate anonymized thermal, battery drain, and sustained performance telemetry across
 * crowd-sourced devices to generate global real-world stability heatmaps. ENGINE/STATE ONLY —
 * no network upload or map rendering.
 *
 * Data source: SharedPreferences stored anonymized samples.
 * Limitations: No crowd-sourced aggregation or network; heatmap modeled from local samples,
 * not fabricated values.
 */
object CommunityHeatmap {

    private const val PREFS = "benchsuite_community_heatmap"
    private const val KEY_SAMPLES = "heatmap_samples"
    private const val MAX_SAMPLES = 100

    data class HeatmapSample(
        val model: String,
        val soc: String,
        val thermalCelsius: Double,
        val batteryDrainMahPerHour: Double,
        val sustainedScore: Int,
        val region: String,
        val timestampMs: Long,
    )

    data class HeatmapReport(
        val samples: List<HeatmapSample>,
        val sampleCount: Int,
        val averageThermalCelsius: Double,
        val averageDrainMahPerHour: Double,
        val averageSustainedScore: Int,
        val hotspotRegions: List<String>,
        val heatmapScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun loadSamples(prefs: SharedPreferences): List<HeatmapSample> {
        return try {
            val json = prefs.getString(KEY_SAMPLES, null) ?: return emptyList()
            json.split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
                val parts = line.split("\\|".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                if (parts.size >= 6) {
                    HeatmapSample(parts[0], parts[1], parts[2].toDoubleOrNull() ?: 0.0,
                        parts[3].toDoubleOrNull() ?: 0.0, parts[4].toIntOrNull() ?: 0,
                        parts[5], parts.getOrNull(6)?.toLongOrNull() ?: System.currentTimeMillis())
                } else null
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveSamples(prefs: SharedPreferences, samples: List<HeatmapSample>) {
        val csv = samples.map { "${it.model}|${it.soc}|${it.thermalCelsius}|${it.batteryDrainMahPerHour}|${it.sustainedScore}|${it.region}|${it.timestampMs}" }
            .joinToString("\n")
        prefs.edit().putString(KEY_SAMPLES, csv).apply()
    }

    /**
     * Records an anonymized telemetry sample and aggregates the community heatmap view.
     */
    fun recordCommunitySample(context: Context, thermalCelsius: Double, batteryDrainMahPerHour: Double, sustainedScore: Int): HeatmapReport {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val samples = loadSamples(prefs).toMutableList()
        samples.add(HeatmapSample(Build.MODEL, Build.HARDWARE, thermalCelsius, batteryDrainMahPerHour, sustainedScore,
            "local", System.currentTimeMillis()))
        if (samples.size > MAX_SAMPLES) samples.removeAt(0)
        saveSamples(prefs, samples)

        val avgThermal = samples.averageOf { it.thermalCelsius }
        val avgDrain = samples.averageOf { it.batteryDrainMahPerHour }
        val avgScore = samples.averageOf { it.sustainedScore }.roundToInt()
        val hotspots = samples.filter { it.thermalCelsius > 45.0 }.map { it.region }.distinct()

        val score = when {
            avgThermal <= 40.0 && avgDrain <= 200.0 -> 920
            avgThermal <= 45.0 && avgDrain <= 350.0 -> 780
            avgThermal <= 50.0 -> 620
            else -> 450
        }

        val verdict = when {
            avgThermal <= 40.0 -> "Community thermals are healthy; no widespread overheating hotspots."
            avgThermal <= 45.0 -> "Moderate community temperatures; some warm devices observed."
            else -> "Community thermal hotspots detected; sustained performance may be impacted."
        }

        return HeatmapReport(
            samples = samples,
            sampleCount = samples.size,
            averageThermalCelsius = (avgThermal * 100.0).roundToInt() / 100.0,
            averageDrainMahPerHour = (avgDrain * 100.0).roundToInt() / 100.0,
            averageSustainedScore = avgScore,
            hotspotRegions = hotspots,
            heatmapScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No crowd-sourced aggregation or network upload; heatmap aggregates local samples only.",
        )
    }
}
