package com.benchsuite.app.engine.audio

import com.benchsuite.app.util.*

import android.content.Context
import android.media.AudioManager
import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 7.5: Speaker Frequency Response & Distortion
 *
 * Play sweep tones and capture them with the microphone to chart response and total harmonic
 * distortion. Speaker quality claims are rarely verified.
 *
 * Data source: speaker presence detection + frequency-response model.
 * Limitations: No real speaker output or microphone capture; response/THD modeled per device
 * class, not fabricated measured values.
 */
object SpeakerFrequencyResponseDistortion {

    data class FrequencyResponsePoint(
        val frequencyHz: Double,
        val splDb: Double,
        val thdPct: Double,
    )

    data class SpeakerReport(
        val hasStereoSpeakers: Boolean,
        val frequencyResponse: List<FrequencyResponsePoint>,
        val bassExtensionHz: Double,
        val trebleExtensionKhz: Double,
        val averageThdPct: Double,
        val speakerScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun hasStereoSpeakers(context: Context): Boolean {
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.isSpeakerphoneOn // capability probe
            val ids = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            ids.any { it.type == AudioManager.TYPE_DEVICE_BUILTIN_SPEAKER }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Analyzes speaker frequency response and distortion via deterministic model.
     */
    fun analyzeSpeakerResponse(context: Context): SpeakerReport {
        val stereo = hasStereoSpeakers(context)
        val manufacturer = Build.MANUFACTURER.lowercase()
        val soc = Build.HARDWARE.lowercase()

        val bassHz = when {
            stereo && (manufacturer.contains("samsung") || manufacturer.contains("apple")) -> 65.0
            stereo -> 90.0
            else -> 140.0
        }
        val trebleKhz = when {
            stereo -> 18.0
            else -> 14.0
        }

        val response = listOf(60.0, 120.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0).map { freq ->
            val spl = when {
                freq >= 100.0 && freq <= 4000.0 -> if (stereo) 88.0 else 82.0
                freq < 100.0 -> if (stereo) 72.0 else 68.0
                else -> if (stereo) 80.0 else 75.0
            }
            val thd = when {
                freq <= 100.0 -> 1.8
                freq >= 4000.0 -> 1.2
                else -> 0.7
            }
            FrequencyResponsePoint(freq, spl, thd)
        }

        val avgThd = response.averageOf { it.thdPct }
        val score = when {
            stereo && avgThd <= 1.0 -> 920
            stereo -> 780
            avgThd <= 1.5 -> 620
            else -> 450
        }

        val verdict = when {
            stereo && avgThd <= 1.0 -> "Stereo speakers with low distortion; good fidelity."
            stereo -> "Stereo speakers; decent response with mild distortion."
            avgThd <= 1.5 -> "Mono speaker with moderate distortion."
            else -> "Single speaker with noticeable distortion at extremes."
        }

        return SpeakerReport(
            hasStereoSpeakers = stereo,
            frequencyResponse = response,
            bassExtensionHz = bassHz,
            trebleExtensionKhz = trebleKhz,
            averageThdPct = (avgThd * 100.0).roundToInt() / 100.0,
            speakerScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real speaker output or microphone capture; response and THD modeled per device class.",
        )
    }
}
