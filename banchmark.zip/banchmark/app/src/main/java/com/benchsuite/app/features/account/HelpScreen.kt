package com.benchsuite.app.features.account

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Feedback
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.benchsuite.app.data.model.FaqItem
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun HelpScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var query by rememberSaveable { mutableStateOf("") }
    var expanded by rememberSaveable { mutableIntStateOf(-1) }
    var diagnosticsSent by remember { mutableStateOf(false) }

    val faqs: List<FaqItem> = emptyList()

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Help and support",
            subtitle = "Answers first, humans second",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Troubleshooting",
                    title = "Start here before a ticket.",
                    body = "Most score differences come from heat, battery and background load. These guides explain each one.",
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    HelpTopic("Run won't start", "Conditions", Icons.Outlined.MonitorHeart, Modifier.weight(1f)) {
                        query = "Why is a test marked limited?"
                    }
                    HelpTopic("Score dropped", "Variance", Icons.Outlined.Speed, Modifier.weight(1f)) {
                        query = "Why do my scores differ"
                    }
                    HelpTopic("Device is hot", "Thermal", Icons.Outlined.Thermostat, Modifier.weight(1f)) {
                        query = "sustained"
                    }
                    HelpTopic("Battery drain", "Power", Icons.Outlined.BatteryChargingFull, Modifier.weight(1f)) {
                        query = "battery"
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search help, e.g. sustained or upload", style = MaterialTheme.typography.bodyMedium) },
                    leadingIcon = { Icon(Icons.Outlined.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Outlined.Close, "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    textStyle = MaterialTheme.typography.bodyMedium,
                )
            }

            item {
                SectionHeader(
                    title = if (query.isBlank()) "Frequently asked" else "Results for \"$query\"",
                    actionLabel = if (query.isBlank()) null else "Clear",
                    onAction = if (query.isBlank()) null else {
                        { query = "" }
                    },
                )
            }

            if (faqs.isEmpty()) {
                item {
                    SurfaceCard {
                        Text("No help articles match that search.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Try a shorter term, or contact support below.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                items(faqs.size) { index ->
                    val faq = faqs[index]
                    val open = expanded == index
                    SurfaceCard(onClick = { expanded = if (open) -1 else index }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                faq.question,
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.weight(1f),
                            )
                            Spacer(Modifier.width(8.dp))
                            Icon(
                                if (open) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                                contentDescription = if (open) "Collapse" else "Expand",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                        if (open) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                faq.answer,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            item { SectionHeader(title = "Contact support") }
            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(42.dp).background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.SupportAgent, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(21.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Talk to a human", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "support@benchsuite.local · replies within two working days",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Text(
                        "Attach diagnostics so we can see the device model, app version, last run and the exact error. No personal data is included.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        Button(
                            onClick = {
                                val dev = SessionState.currentDevice
                                val diag = "BenchSuite Diagnostics:\nDevice: ${dev.model}\nSoC: ${dev.soc}\nOS: ${dev.os}\nBuild: ${dev.build}\nFingerprint: ${dev.fingerprint}"
                                clipboard.setText(AnnotatedString(diag))
                                diagnosticsSent = true
                            },
                            modifier = Modifier.weight(1f).height(46.dp),
                        ) {
                            Icon(Icons.Outlined.Feedback, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(if (diagnosticsSent) "Diagnostics copied" else "Attach diagnostics")
                        }
                        OutlinedButton(
                            onClick = {
                                val dev = SessionState.currentDevice
                                val intent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("mailto:support@benchsuite.app")
                                    putExtra(Intent.EXTRA_SUBJECT, "BenchSuite Support: ${dev.model}")
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "App version: 1.0.0-ui · debug\nDevice: ${dev.model}\nSoC: ${dev.soc}\nOS: ${dev.os}\nBuild: ${dev.build}\n\nDescribe your issue here:\n",
                                    )
                                }
                                runCatching { context.startActivity(intent) }
                            },
                            modifier = Modifier.height(46.dp),
                        ) {
                            Text("Email")
                        }
                    }
                }
            }

            item { SectionHeader(title = "Diagnostic summary") }
            item {
                val dev = SessionState.currentDevice
                val lastRunText = SessionState.latestNativeRun?.let { "${it.id} · ${it.date}" } ?: "No runs recorded yet"
                SurfaceCard {
                    InfoRow("App version", "1.0.0-ui · debug")
                    InfoRow("Device", dev.model)
                    InfoRow("SoC", dev.soc)
                    InfoRow("Android", dev.os)
                    InfoRow("Last run", lastRunText)
                    InfoRow("Methodology", "2.4.1")
                    InfoRow("Log size", "Local diagnostics only")
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag("No IMEI")
                        Tag("No serial")
                        Tag("No ad ID")
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.MonitorHeart, null, tint = BenchTheme.colors.success, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "The in-app diagnostic report covers crashes, failed runs and skipped tests.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                Text(
                    "Support never asks for your full device fingerprint, keystore keys or raw telemetry unless you explicitly export it.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(top = Spacing.xs),
                )
            }
        }
    }
}

@Composable
private fun HelpTopic(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    SurfaceCard(
        modifier = modifier,
        onClick = onClick,
        contentPadding = PaddingValues(10.dp),
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
