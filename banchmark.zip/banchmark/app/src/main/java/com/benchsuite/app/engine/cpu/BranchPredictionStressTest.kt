package com.benchsuite.app.engine.cpu

import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 1.4: Branch Prediction Stress Test
 *
 * Measures branch predictor accuracy under adversarial and random branch patterns, exposing
 * microarchitectural branch handling quality per core cluster.
 *
 * Data source: timed branch-heavy loop iterations with predictable vs. unpredictable patterns.
 * Limitations: No hardware performance counters; misprediction rate is modeled from loop timing,
 * not fabricated measured values.
 */
object BranchPredictionStressTest {

    data class PatternResult(
        val patternName: String,
        val iterations: Long,
        val elapsedMs: Double,
        val estimatedMispredictionPct: Double,
        val opsPerSec: Double,
    )

    data class BranchReport(
        val predictableOpsPerSec: Double,
        val unpredictableOpsPerSec: Double,
        val mispredictionPenaltyMs: Double,
        val predictorQualityScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun runBranchLoop(predictable: Boolean, iterations: Long): Double {
        val data = IntArray(1024) { (it * 31) and 1023 }
        var sum = 0
        val start = SystemClock.elapsedRealtimeNanos()
        for (i in 0 until iterations) {
            val idx = (i * 7) and 1023
            val v = data[idx]
            if (predictable) {
                if (v < 512) sum += v else sum - v
            } else {
                if ((i and 1) == 0) sum += v else sum - v
            }
        }
        val elapsedNs = SystemClock.elapsedRealtimeNanos() - start
        return if (elapsedNs > 0) elapsedNs / 1_000_000.0 else 0.0
    }

    /**
     * Stresses branch prediction with predictable vs adversarial patterns.
     */
    fun runBranchPredictionTest(): BranchReport {
        val iterations = 20_000_000L
        val predictableMs = runBranchLoop(predictable = true, iterations = iterations)
        val unpredictableMs = runBranchLoop(predictable = false, iterations = iterations)
        val predictableOps = if (predictableMs > 0) iterations / predictableMs * 1000.0 else 0.0
        val unpredictableOps = if (unpredictableMs > 0) iterations / unpredictableMs * 1000.0 else 0.0
        val penaltyMs = unpredictableMs - predictableMs
        val mispredPct = min(40.0, max(0.0, (penaltyMs / max(predictableMs, 1.0)) * 25.0))

        val score = when {
            mispredPct <= 5.0 -> 940
            mispredPct <= 12.0 -> 800
            mispredPct <= 20.0 -> 640
            else -> 460
        }

        val verdict = when {
            mispredPct <= 5.0 -> "Branch predictor handles adversarial patterns well."
            mispredPct <= 12.0 -> "Good prediction accuracy with modest penalty on random branches."
            mispredPct <= 20.0 -> "Noticeable misprediction penalty under random patterns."
            else -> "Weak branch prediction; unpredictable code suffers significant stalls."
        }

        return BranchReport(
            predictableOpsPerSec = (predictableOps * 100.0).roundToInt() / 100.0,
            unpredictableOpsPerSec = (unpredictableOps * 100.0).roundToInt() / 100.0,
            mispredictionPenaltyMs = (penaltyMs * 100.0).roundToInt() / 100.0,
            predictorQualityScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No hardware performance counters; misprediction rate modeled from loop timing deltas.",
        )
    }
}
