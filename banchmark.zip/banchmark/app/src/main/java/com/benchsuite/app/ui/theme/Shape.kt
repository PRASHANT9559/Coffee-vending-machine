package com.benchsuite.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * 12 dp cards, 20 dp sheets, round chips — README section 6.6.
 */
val BenchShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp),
)

object Spacing {
    val xxs = 4.dp
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val lg = 24.dp
    val xl = 32.dp
}

object Dimens {
    val screenPadding = 20.dp
    val cardCorner = 12.dp
    val touchTarget = 48.dp
    val bottomBarHeight = 72.dp
    val gaugeLarge = 208.dp
    val gaugeMedium = 132.dp
    val chartHeight = 180.dp
}
