package com.benchsuite.app.engine.storage

import com.benchsuite.app.util.*

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 4.8: App Install & DEX Optimization Time
 *
 * Times package install, ahead-of-time compilation and first launch for reference apps. Install
 * and update speed shapes daily experience after every app update.
 *
 * Data source: PackageManager install session timing model + dexopt cost model per app size.
 * Limitations: No real APK install/dexopt (requires permissions and user consent); times modeled
 * per app size, not fabricated measured values.
 */
object AppInstallDexOptimizationTime {

    data class AppResult(
        val packageName: String,
        val sizeMb: Double,
        val installMs: Double,
        val dexoptMs: Double,
        val firstLaunchMs: Double,
        val totalMs: Double,
    )

    data class InstallReport(
        val apps: List<AppResult>,
        val averageInstallMs: Double,
        val averageDexoptMs: Double,
        val averageFirstLaunchMs: Double,
        val installScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun storageSpeedClass(): Double {
        return try {
            val seq = File("/sys/block/mmcblk0/device/ext_csd").readTextOrNull()
            if (seq != null && seq.contains("UFS")) 1.0 else 0.6
        } catch (_: Exception) {
            0.6
        }
    }

    /**
     * Models app install + DEX optimization time for reference apps.
     */
    fun benchmarkAppInstallTimes(): InstallReport {
        val speed = storageSpeedClass()
        val apps = listOf(
            Triple("com.benchsuite.reference.light", 8.0),
            Triple("com.benchsuite.reference.medium", 45.0),
            Triple("com.benchsuite.reference.heavy", 180.0),
            Triple("com.benchsuite.reference.game", 650.0),
        ).map { (pkg, sizeMb) ->
            val installMs = (sizeMb * 120.0 / speed * 10.0).roundToInt() / 10.0
            val dexoptMs = (sizeMb * 200.0 / speed * 10.0).roundToInt() / 10.0
            val firstLaunchMs = (sizeMb * 40.0 / speed * 10.0).roundToInt() / 10.0
            AppResult(pkg, sizeMb, installMs, dexoptMs, firstLaunchMs, installMs + dexoptMs + firstLaunchMs)
        }

        val avgInstall = apps.averageOf { it.installMs }
        val avgDexopt = apps.averageOf { it.dexoptMs }
        val avgLaunch = apps.averageOf { it.firstLaunchMs }

        val score = when {
            avgInstall <= 5000.0 && avgDexopt <= 8000.0 -> 920
            avgInstall <= 12000.0 -> 760
            avgInstall <= 25000.0 -> 580
            else -> 400
        }

        val verdict = when {
            avgInstall <= 5000.0 -> "Fast app install and DEX optimization; updates feel instant."
            avgInstall <= 12000.0 -> "Acceptable install times for typical app sizes."
            else -> "Slow install/dexopt; large app updates take noticeable time."
        }

        return InstallReport(
            apps = apps,
            averageInstallMs = (avgInstall * 10.0).roundToInt() / 10.0,
            averageDexoptMs = (avgDexopt * 10.0).roundToInt() / 10.0,
            averageFirstLaunchMs = (avgLaunch * 10.0).roundToInt() / 10.0,
            installScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real APK install/dexopt invoked; times modeled per app size and storage class.",
        )
    }
}
