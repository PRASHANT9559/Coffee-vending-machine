package com.benchsuite.app.engine.sensors

import com.benchsuite.app.util.*

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 11.1: MEMS Sensor Calibration Quality Score
 *
 * Measures accelerometer/gyroscope bias, noise floor, and cross-axis sensitivity against ground
 * truth. Poor calibration causes AR drift and navigation errors.
 *
 * Data source: SensorManager accelerometer/gyroscope samples averaged over a short still window.
 * Limitations: Requires the device to be held still; no ground-truth reference is available, so
 * calibration quality is inferred from bias/noise spread rather than fabricated values.
 */
object MemsSensorCalibrationQualityScore {

    data class AxisStats(val axis: String, val mean: Double, val stdDev: Double, val min: Double, val max: Double)

    data class SensorCalibrationResult(
        val sensorType: String,
        val samples: Int,
        val bias: Double,
        val noiseFloor: Double,
        val crossAxisSensitivityPct: Double,
        val axisStats: List<AxisStats>,
        val qualityScore: Int, // 0 - 1000
    )

    data class CalibrationReport(
        val accelerometer: SensorCalibrationResult,
        val gyroscope: SensorCalibrationResult,
        val overallCalibrationScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun collectSensor(context: Context, sensorType: Int, durationMs: Long): SensorCalibrationResult {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(sensorType)
        val latch = CountDownLatch(1)
        val values = mutableListOf<FloatArray>()
        var captured = 0

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                values.add(event.values.copyOf())
                captured++
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        val registered = sm.registerListener(listener, sensor, SensorManager.SENSOR_NORMAL)
        try {
            Thread.sleep(durationMs)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        } finally {
            sm.unregisterListener(listener)
        }

        val sampleCount = values.size
        val axes = listOf("X", "Y", "Z")
        val axisStats = axes.mapIndexed { idx, axis ->
            val col = values.map { it[idx] }
            val mean = col.averageOrNull() ?: 0.0
            val variance = col.map { (it - mean) * (it - mean) }.averageOrNull() ?: 0.0
            AxisStats(axis, mean, kotlin.math.sqrt(variance), col.minOrNull() ?: 0.0, col.maxOrNull() ?: 0.0)
        }

        val bias = axisStats.map { Math.abs(it.mean) }.averageOrNull() ?: 0.0
        val noiseFloor = axisStats.map { it.stdDev }.averageOrNull() ?: 0.0
        val crossAxis = if (sampleCount > 0) min(100.0, bias * 100.0) else 0.0

        val qualityScore = when {
            bias <= 0.05 && noiseFloor <= 0.02 -> 950
            bias <= 0.15 && noiseFloor <= 0.06 -> 780
            bias <= 0.35 && noiseFloor <= 0.12 -> 600
            else -> 420
        }

        return SensorCalibrationResult(
            sensorType = when (sensorType) {
                Sensor.TYPE_ACCELEROMETER -> "Accelerometer (m/s^2)"
                Sensor.TYPE_GYROSCOPE -> "Gyroscope (rad/s)"
                else -> "Sensor $sensorType"
            },
            samples = sampleCount,
            bias = (bias * 1000.0).roundToInt() / 1000.0,
            noiseFloor = (noiseFloor * 1000.0).roundToInt() / 1000.0,
            crossAxisSensitivityPct = (crossAxis * 100.0).roundToInt() / 100.0,
            axisStats = axisStats,
            qualityScore = qualityScore.coerceIn(0, 1000),
        )
    }

    /**
     * Collects accelerometer and gyroscope calibration samples and scores quality.
     */
    fun assessCalibration(context: Context): CalibrationReport {
        val accel = collectSensor(context, Sensor.TYPE_ACCELEROMETER, 600)
        val gyro = collectSensor(context, Sensor.TYPE_GYROSCOPE, 600)
        val overall = ((accel.qualityScore + gyro.qualityScore) / 2).coerceIn(0, 1000)

        val verdict = when {
            overall >= 800 -> "Sensors are well calibrated; low bias and noise floor."
            overall >= 650 -> "Acceptable calibration; minor AR/navigation drift possible."
            else -> "Poor calibration; expect AR drift and navigation error."
        }

        return CalibrationReport(
            accelerometer = accel,
            gyroscope = gyro,
            overallCalibrationScore = overall,
            verdict = verdict,
            limitations = "No ground-truth reference; calibration quality inferred from bias/noise spread over a short still window.",
        )
    }
}
