package com.benchsuite.app.features.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.data.model.TestDefinition
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.FilterPills
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

private data class SuitePreset(
    val title: String,
    val subtitle: String,
    val ids: Set<String>,
)

private val presets: List<SuitePreset>
    get() = listOf(
        SuitePreset(
            "Quick check",
            "Health + patch posture · ~3 min",
            TestCatalog.tests.filter { it.categoryId == "health" }.map { it.id }.toSet(),
        ),
        SuitePreset(
            "Gaming night",
            "Frame pacing + thermal soak · ~40 min",
            TestCatalog.tests.filter { it.categoryId in listOf("gaming", "thermal") && it.priority != "Nice to Have" }.map { it.id }.toSet(),
        ),
        SuitePreset(
            "AI deep dive",
            "LLM, NPU fallback, diffusion · ~35 min",
            TestCatalog.tests.filter { it.categoryId == "ai" }.map { it.id }.toSet(),
        ),
        SuitePreset(
            "Everything important",
            "All must-have tests · ~60 min",
            TestCatalog.tests.filter { it.priority == "Must Have" }.map { it.id }.toSet(),
        ),
    )

@Composable
fun CustomBuilderScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var category by rememberSaveable { mutableIntStateOf(0) }
    val categoryOptions = listOf("All") + TestCatalog.categorySpecs.map { it.shortTitle }
    val selected = SessionState.selectedTests
    val visibleTests: List<TestDefinition> = if (category == 0) {
        TestCatalog.tests
    } else {
        val id = TestCatalog.categorySpecs[category - 1].id
        TestCatalog.testsFor(id)
    }

    Column(Modifier.fillMaxSize()) {
        BenchTopBar(
            title = "Custom builder",
            subtitle = "${selected.size} tests selected",
            onBack = onBack,
            actions = {
                IconAction(Icons.Outlined.RestartAlt, "Reset selection") {
                    SessionState.selectedTestIds = TestCatalog.tests
                        .filter { it.categoryId in listOf("cpu", "gpu", "gaming", "thermal") && it.priority != "Nice to Have" }
                        .map { it.id }
                        .toSet()
                }
            },
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 16.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Your protocol",
                    title = "Compose your own suite.",
                    body = "Pick only what answers your question. Every test explains its cost before you add it.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(40.dp).background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.13f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.Tune, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${selected.size} tests", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${selected.map { it.categoryId }.distinct().size} categories · about ${SessionState.customDurationMinutes} min",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text(
                            "${selected.sumOf { it.innovation }}★",
                            style = NumericSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusChip("Peak + sustained", tint = MaterialTheme.colorScheme.primary)
                        StatusChip("Signed", tint = BenchTheme.colors.success)
                        if (selected.isEmpty()) {
                            StatusChip("Empty", tint = BenchTheme.colors.warning)
                        }
                    }
                }
            }

            item {
                SectionHeader(title = "Start from a preset")
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    presets.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                            row.forEach { preset ->
                                PresetCard(
                                    preset = preset,
                                    selected = preset.ids == SessionState.selectedTestIds,
                                    modifier = Modifier.weight(1f),
                                    onClick = { SessionState.selectedTestIds = preset.ids },
                                )
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                FilterPills(
                    options = categoryOptions,
                    selectedIndex = category,
                    onSelect = { category = it },
                )
            }

            item {
                SectionHeader(
                    title = if (category == 0) "All tests" else categoryOptions[category],
                    actionLabel = "Clear all",
                    onAction = { SessionState.selectedTestIds = emptySet() },
                )
            }

            items(visibleTests.size) { index ->
                val test = visibleTests[index]
                SelectableTestRow(
                    test = test,
                    checked = test.id in SessionState.selectedTestIds,
                    onToggle = { SessionState.toggleTest(test.id) },
                )
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .navigationBarsPadding()
                .padding(horizontal = Dimens.screenPadding, vertical = Spacing.sm),
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Estimated",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            "${SessionState.customDurationMinutes} min · ${selected.size} tests",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    Button(
                        onClick = {
                            SessionState.startRun("custom", "Custom suite")
                            onNavigate(Routes.LIVE_RUN)
                        },
                        enabled = selected.isNotEmpty(),
                        modifier = Modifier.height(50.dp),
                    ) {
                        Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Start custom run")
                    }
                }
                Text(
                    "Tests run in the order shown. Limited tests are flagged and skipped with a reason.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun PresetCard(
    preset: SuitePreset,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    SurfaceCard(
        modifier = modifier,
        onClick = onClick,
        contentPadding = PaddingValues(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(8.dp).background(
                    if (selected) BenchTheme.colors.success else MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                    CircleShape,
                ),
            )
            Spacer(Modifier.weight(1f))
            if (selected) {
                Text("Active", style = MaterialTheme.typography.labelSmall, color = BenchTheme.colors.success)
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(preset.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            preset.subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
        )
    }
}

@Composable
private fun SelectableTestRow(
    test: TestDefinition,
    checked: Boolean,
    onToggle: () -> Unit,
) {
    SurfaceCard(onClick = onToggle, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
            Spacer(Modifier.width(2.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    test.name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    test.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tag("${test.minutes} min")
                    Tag(test.priority)
                    Tag(test.difficulty)
                }
            }
        }
    }
}
