package com.benchsuite.app.ui.state

import android.content.Context
import android.graphics.Bitmap
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.data.persistence.AppDatabase
import com.benchsuite.app.data.repository.RunRepository
import com.benchsuite.app.data.model.ActiveRun
import com.benchsuite.app.data.model.ConsentItem
import com.benchsuite.app.data.model.DeviceProfile
import com.benchsuite.app.data.model.EnvironmentCheck
import com.benchsuite.app.data.model.Insight
import com.benchsuite.app.data.model.ReportItem
import com.benchsuite.app.data.model.ReportType
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.data.model.ScheduleItem
import com.benchsuite.app.data.model.SettingsState
import com.benchsuite.app.data.model.TestDefinition
import com.benchsuite.app.data.model.ThemeMode
import com.benchsuite.app.data.model.UseCaseFit
import com.benchsuite.app.engine.analysis.PerformanceExplainer
import com.benchsuite.app.engine.analysis.UseCaseFitCalculator
import com.benchsuite.app.engine.ai.AiAccuracyPerformanceParetoFrontier
import com.benchsuite.app.engine.ai.AiModelLoadTimeBenchmark
import com.benchsuite.app.engine.ai.FederatedLearningNodeBenchmark
import com.benchsuite.app.engine.ai.MultiModalAiPipelineBenchmark
import com.benchsuite.app.engine.ai.OnDeviceRagBenchmark
import com.benchsuite.app.engine.ai.SpeechRecognitionRealTimeFactor
import com.benchsuite.app.engine.ai.SpeculativeDecodingEfficiencyTest
import com.benchsuite.app.engine.ai.StableDiffusionIterationTimeConsistency
import com.benchsuite.app.engine.audio.HapticFrequencyResponseAnalyzer
import com.benchsuite.app.engine.audio.MicrophoneNoiseFloorDynamicRange
import com.benchsuite.app.engine.audio.SpeakerFrequencyResponseDistortion
import com.benchsuite.app.engine.audio.TapToToneLatencyBenchmark
import com.benchsuite.app.engine.battery.IdleDrainDeepSleepEfficiency
import com.benchsuite.app.engine.battery.PerAppPowerAttributionProfiler
import com.benchsuite.app.engine.battery.ReverseWirelessChargingStressTest
import com.benchsuite.app.engine.battery.WiredChargingCurveThermalProfiler
import com.benchsuite.app.engine.battery.WirelessChargingEfficiencyBenchmark
import com.benchsuite.app.engine.camera.AutofocusAcquisitionSpeed
import com.benchsuite.app.engine.camera.NightModeProcessingLatency
import com.benchsuite.app.engine.camera.RawProcessingPipelineBenchmark
import com.benchsuite.app.engine.camera.VideoStabilizationQualityAnalyzer
import com.benchsuite.app.engine.cpu.BranchPredictionStressTest
import com.benchsuite.app.engine.cpu.CacheHierarchyLatencyMapper
import com.benchsuite.app.engine.cpu.CoreToCoreLatencyMatrix
import com.benchsuite.app.engine.system.SchedulerEfficiencyProfiler
import com.benchsuite.app.engine.cpu.SimdNeonSve2ThroughputProfiler
import com.benchsuite.app.engine.display.PalmRejectionGhostTouchTest
import com.benchsuite.app.engine.display.PeakSustainedLuminanceCurve
import com.benchsuite.app.engine.display.StylusLatencyPressurePrecisionBenchmark
import com.benchsuite.app.engine.display.VariableRefreshRateTransitionSmoothness
import com.benchsuite.app.engine.enterprise.CliAdbAutomation
import com.benchsuite.app.engine.enterprise.CustomBenchmarkBuilder
import com.benchsuite.app.engine.fairplay.SignedResultTamperProofing
import com.benchsuite.app.engine.foldable.HingeDurabilityTracker
import com.benchsuite.app.engine.gaming.AppLaunchTimeConsistencyBenchmark
import com.benchsuite.app.engine.gaming.CloudGamingReadinessScore
import com.benchsuite.app.engine.gaming.ColdVsWarmGameLaunchTime
import com.benchsuite.app.engine.gaming.EmulatorPerformancePredictor
import com.benchsuite.app.engine.gaming.PredictedGamingFpsEngine
import com.benchsuite.app.engine.gaming.TouchToPhotonGamingLatency
import com.benchsuite.app.engine.gpu.FillrateTextureBandwidthAnalyzer
import com.benchsuite.app.engine.gpu.GpuFrequencyResidencyTracker
import com.benchsuite.app.engine.gpu.GpuMemoryCompressionRatioTester
import com.benchsuite.app.engine.gpu.ShaderCompilationStutterProfiler
import com.benchsuite.app.engine.gpu.VariableRateShadingEfficiencyBenchmark
import com.benchsuite.app.engine.insights.AnomalyRegressionAlerts
import com.benchsuite.app.engine.insights.BottleneckRootCauseEngine
import com.benchsuite.app.engine.insights.PeerPercentileRanking
import com.benchsuite.app.engine.insights.PerformanceForecastEngine
import com.benchsuite.app.engine.insights.PersonalizedOptimizationTips
import com.benchsuite.app.engine.insights.UpgradeAdvisor
import com.benchsuite.app.engine.longevity.DeviceHealthCertificate
import com.benchsuite.app.engine.longevity.OsUpdateRegressionTracker
import com.benchsuite.app.engine.network.BluetoothLeAudioLatencyQualityBenchmark
import com.benchsuite.app.engine.network.BufferbloatLoadedLatencyTest
import com.benchsuite.app.engine.network.CellularModemThermalPowerProfile
import com.benchsuite.app.engine.network.EsimProfileSwitchingSpeedTest
import com.benchsuite.app.engine.network.SatelliteSosTimeToRescueBenchmark
import com.benchsuite.app.engine.network.WiFiRoamingStabilityTest
import com.benchsuite.app.engine.productivity.CodeCompilationSpeedBenchmark
import com.benchsuite.app.engine.productivity.ContainerDockerStartupBenchmark
import com.benchsuite.app.engine.productivity.MobileVideoExportTimePredictor
import com.benchsuite.app.engine.productivity.MultiWindowDesktopModeWorkload
import com.benchsuite.app.engine.productivity.PdfRenderingAnnotationStressTest
import com.benchsuite.app.engine.productivity.PhotoBatchEditRawExport
import com.benchsuite.app.engine.productivity.SpreadsheetCalculationBenchmark
import com.benchsuite.app.engine.reporting.ReviewerReportTemplate
import com.benchsuite.app.engine.reporting.ScheduledHealthReports
import com.benchsuite.app.engine.security.BiometricUnlockLatencyAccuracyProfiler
import com.benchsuite.app.engine.security.FileBasedEncryptionThroughputBenchmark
import com.benchsuite.app.engine.security.HardwareSecurityModuleThroughputTest
import com.benchsuite.app.engine.security.IntegrityRootPostureScanner
import com.benchsuite.app.engine.security.SideChannelLeakageDetection
import com.benchsuite.app.engine.sensors.BarometricAltimeterAccuracyTest
import com.benchsuite.app.engine.sensors.DualFrequencyGnssAccuracyWalkTest
import com.benchsuite.app.engine.sensors.GnssColdStartTimeToFirstFix
import com.benchsuite.app.engine.sensors.GyroscopeDriftTest
import com.benchsuite.app.engine.sensors.MagnetometerInterferenceProfiler
import com.benchsuite.app.engine.sensors.MemsSensorCalibrationQualityScore
import com.benchsuite.app.engine.social.CommunityHeatmap
import com.benchsuite.app.engine.social.ReviewerMode
import com.benchsuite.app.engine.social.SocFamilyRanking
import com.benchsuite.app.engine.storage.AppInstallDexOptimizationTime
import com.benchsuite.app.engine.storage.AiWorkloadStoragePatternBenchmark
import com.benchsuite.app.engine.storage.SmallFileMetadataStress
import com.benchsuite.app.engine.storage.StorageEnduranceWearEstimator
import com.benchsuite.app.engine.storage.StorageFragmentationSimulator
import com.benchsuite.app.engine.storage.UfsControllerThermalThrottlingTest
import com.benchsuite.app.engine.storage.ZramSwapEfficiencyAnalyzer
import com.benchsuite.app.engine.telemetry.EnvironmentNormalizer
import com.benchsuite.app.engine.thermal.ActiveCoolingEfficiencyIndex
import com.benchsuite.app.engine.thermal.ThermalZoneCorrelationMap
import com.benchsuite.app.engine.ux.LivePerformanceOverlay
import com.benchsuite.app.engine.ux.WidgetsQuickSettingsTile
import com.benchsuite.app.engine.wearable.WearOsCompanionBridge
import com.benchsuite.app.nativecore.DeviceTelemetry
import com.benchsuite.app.nativecore.NativeBridge
import com.benchsuite.app.nativecore.NativeRunCoordinator
import java.io.File
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import com.benchsuite.app.engine.ai.LiteRtNpuEngine
import com.benchsuite.app.engine.audio.SpatialAudioHeadTracker
import com.benchsuite.app.engine.camera.CameraIspBenchmark
import com.benchsuite.app.engine.display.HdrToneMappingAnalyzer
import com.benchsuite.app.engine.display.PwmDimmingDetector
import com.benchsuite.app.engine.display.TouchLatencyProfiler
import com.benchsuite.app.engine.export.PdfReportGenerator
import com.benchsuite.app.engine.export.RawDataExporter
import com.benchsuite.app.engine.export.ShareCardRenderer
import com.benchsuite.app.engine.export.TelemetrySample
import com.benchsuite.app.engine.fairplay.CheatDetectorEngine
import com.benchsuite.app.engine.network.Urllc5gLatencyProfiler
import com.benchsuite.app.engine.network.UwbPrecisionBenchmark
import com.benchsuite.app.engine.network.Wifi7MloBenchmark
import com.benchsuite.app.engine.telemetry.GuidedPreTestChecklist
import com.benchsuite.app.engine.thermal.ThermalPredictionModel
import com.benchsuite.app.engine.thermal.ThermalStorytellingEngine

/**
 * Production Session State.
 *
 * Central state container for the BenchSuite application:
 * - Coordinates real native and in-process benchmark execution
 * - Wires in the [GuidedPreTestChecklist] for platform sensor pre-flight checks
 * - Integrates [PerformanceExplainer] and [UseCaseFitCalculator] analysis engines
 * - Exposes high-throughput export actions: [PdfReportGenerator], [RawDataExporter], [ShareCardRenderer]
 */
object SessionState {

    var onboarded by mutableStateOf(false)
    var hardwareScanned by mutableStateOf(false)

    /** Application context, attached once from MainActivity for native runs. */
    internal var applicationContext: Context? = null
        private set

    /** Room-backed persistence for completed runs (Phase 4). Initialized in [attach]. */
    internal lateinit var runRepository: RunRepository
        private set

    var settings by mutableStateOf(
        SettingsState(themeMode = ThemeMode.DARK, dynamicColor = false, reduceMotion = false),
    )

    var activeRun by mutableStateOf<ActiveRun?>(null)
        private set

    var latestNativeRun by mutableStateOf<RunRecord?>(null)
        private set

    var nativeRunError by mutableStateOf<String?>(null)
        private set

    private var pendingCompletedRunId: String? = null

    var lastCompletedRunId by mutableStateOf<String?>(null)
        private set

    val completedRuns = mutableStateListOf<RunRecord>()

    val allHistoryRuns: List<RunRecord>
        get() = (listOfNotNull(latestNativeRun) + completedRuns).distinctBy { it.id }

    val completedReportItems: List<ReportItem>
        get() = allHistoryRuns.map { run ->
            ReportItem(
                id = run.id,
                title = "${run.soc} Report",
                subtitle = "${run.deviceModel} · Score ${run.overall}",
                date = run.startedAt,
                type = ReportType.FULL,
                pages = 4,
                score = run.overall,
                shared = run.id in reportSharedIds,
                fileSize = "1.8 MB",
            )
        }

    val currentDevice: DeviceProfile
        get() = com.benchsuite.app.nativecore.RealDeviceProfileProvider.build(applicationContext)

    fun refreshHardware() {
        hardwareScanned = true
        runPreTestChecklist()
    }

    fun clearAllData() {
        latestNativeRun = null
        completedRuns.clear()
        lastCompletedRunId = null
        latestTelemetrySamples = emptyList()
        schedules = emptyList()
        consents = emptyList()
        settings = SettingsState()
        selectedTestIds = emptySet()
        reportSharedIds = emptySet()
        onboarded = false
        hardwareScanned = false
    }

    var consents by mutableStateOf(emptyList<ConsentItem>())

    var schedules by mutableStateOf(emptyList<ScheduleItem>())

    var selectedTestIds by mutableStateOf(emptySet<String>())

    var reportSharedIds by mutableStateOf(setOf<String>())
        private set

    var queuedReportId by mutableStateOf<String?>(null)

    var preTestChecklistResult by mutableStateOf<GuidedPreTestChecklist.ChecklistResult?>(null)
        private set

    var latestTelemetrySamples by mutableStateOf<List<TelemetrySample>>(emptyList())
        private set

    /* ------------------------------ Runs ------------------------------ */

    fun attach(context: Context) {
        applicationContext = context.applicationContext
        // Phase 4: initialize Room persistence and load existing runs.
        val db = AppDatabase.getDatabase(context)
        runRepository = RunRepository(db.runRecordDao())
        kotlinx.coroutines.GlobalScope.launch {
            val runs = runRepository.getAllRuns()
            completedRuns.clear()
            completedRuns.addAll(runs)
            if (runs.isNotEmpty()) {
                latestNativeRun = runs.firstOrNull()
                lastCompletedRunId = runs.firstOrNull()?.id
            }
        }
        runPreTestChecklist()
    }

    /** Returns the REAL run with this id, or null — never a mock substitute. */
    fun runById(id: String): RunRecord? =
        latestNativeRun?.takeIf { it.id == id }
            ?: completedRuns.firstOrNull { it.id == id }

    /** Returns the most recent REAL run, or null when nothing has been recorded yet. */
    val latestRecordedRunOrNull: RunRecord?
        get() = latestNativeRun ?: completedRuns.lastOrNull()

    /**
     * The most recent REAL run recorded on this device. Never falls back to mock data:
     * analysis/export without a real run throws an explicit error instead of fabricating one.
     */
    val latestRecordedRun: RunRecord
        get() = latestRecordedRunOrNull
            ?: error("No benchmark run recorded yet; run a benchmark first.")

    private fun durationFor(categoryId: String): Int = when (categoryId) {
        "quick" -> 60
        "full" -> 840
        "custom" -> max(120, selectedTests.sumOf { it.minutes } * 60)
        "health" -> 180
        else -> 120
    }

    fun startRun(categoryId: String, title: String) {
        // Only real tests from the native probe list or user's custom selection are used.
        val tests = when (categoryId) {
            "quick" -> listOf(
                TestDefinition("quick_cpu", "CPU Burst (15s)", "Integer and multi-thread burst", "cpu", 1, "Easy", 8, "Must Have"),
                TestDefinition("quick_mem", "Memory Bandwidth (10s)", "Bandwidth and latency probe", "memory", 1, "Easy", 8, "Must Have"),
                TestDefinition("quick_gpu", "Vulkan Fragment Shader (15s)", "Offscreen fragment rendering", "gpu", 1, "Easy", 8, "Must Have"),
                TestDefinition("quick_storage", "Storage Random IOPS (10s)", "Direct random I/O", "storage", 1, "Easy", 8, "Must Have"),
                TestDefinition("quick_thermal", "Thermal & Battery Delta (10s)", "Thermal rise & power draw delta", "thermal", 1, "Easy", 8, "Must Have"),
            )
            "full" -> emptyList()
            "custom" -> selectedTests.map { id ->
                TestCatalog.tests.firstOrNull { it.id == id } ?: TestDefinition(id, id, "", categoryId, 1, "Easy", 1, "Must Have")
            }
            else -> emptyList()
        }
        val total = max(1, tests.size)
        nativeRunError = null
        val useNative = applicationContext != null
        activeRun = ActiveRun(
            categoryId = categoryId,
            title = title,
            totalTests = total,
            completedTests = 0,
            currentTest = tests.firstOrNull { it.availability.name == "READY" }?.name ?: "Preparing workload",
            progress = 0f,
            elapsedSec = 0,
            etaSec = durationFor(categoryId),
            liveFps = 60,
            temperatureC = 32.0,
            powerW = 4.2,
            cpuClockGhz = 2.9,
            paused = false,
            cooling = false,
            isNative = useNative,
        )
        if (useNative) {
            NativeRunCoordinator.start(categoryId, selectedTestIds)
        }
    }

    internal fun prepareNativeRun(totalProbes: Int) {
        val run = activeRun ?: return
        activeRun = run.copy(
            totalTests = totalProbes,
            completedTests = 0,
            progress = 0f,
            currentTest = "Warming up execution kernels",
        )
    }

    internal fun nativeStep(current: String, completed: Int, total: Int, elapsedSec: Int) {
        val run = activeRun ?: return
        val safeTotal = total.coerceAtLeast(1)
        activeRun = run.copy(
            totalTests = safeTotal,
            completedTests = completed.coerceIn(0, safeTotal),
            currentTest = current,
            progress = (completed.toFloat() / safeTotal).coerceIn(0f, 0.99f),
            elapsedSec = elapsedSec,
            etaSec = 0,
            cooling = false,
        )
    }

    internal fun updateNativeTelemetry(telemetry: DeviceTelemetry) {
        val run = activeRun ?: return
        activeRun = run.copy(
            temperatureC = telemetry.temperatureC,
            powerW = telemetry.powerW,
            cpuClockGhz = if (telemetry.clockGhz > 0.0) telemetry.clockGhz else run.cpuClockGhz,
        )
    }

    internal fun updateNativeFps(fps: Int) {
        val run = activeRun ?: return
        activeRun = run.copy(liveFps = fps)
    }

    internal fun recordLatestTelemetrySamples(samples: List<TelemetrySample>) {
        latestTelemetrySamples = samples
    }

    internal fun publishNativeRun(record: RunRecord) {
        latestNativeRun = record
        if (completedRuns.none { it.id == record.id }) {
            completedRuns.add(0, record)
        }
        pendingCompletedRunId = record.id
        lastCompletedRunId = record.id
        activeRun = activeRun?.copy(
            progress = 1f,
            completedTests = activeRun?.totalTests ?: 0,
            currentTest = "Finishing",
            etaSec = 0,
        )
        // Phase 4: persist to Room in the background.
        kotlinx.coroutines.GlobalScope.launch {
            try {
                runRepository.insertRun(record)
            } catch (_: Exception) {
                // Persistence failure must not crash the UI.
            }
        }
    }

    internal fun failNativeRun(message: String) {
        nativeRunError = message
        activeRun = activeRun?.copy(
            currentTest = "Run failed",
            paused = true,
        )
    }

    fun clearNativeError() {
        nativeRunError = null
    }

    fun togglePause() {
        activeRun = activeRun?.copy(paused = !(activeRun?.paused ?: false))
    }

    fun cancelRun() {
        NativeRunCoordinator.cancel()
        pendingCompletedRunId = null
        activeRun = null
    }

    fun completeRun() {
        activeRun = null
        lastCompletedRunId = pendingCompletedRunId ?: latestNativeRun?.id
        pendingCompletedRunId = null
    }

    fun advance(dtSec: Int = 1) {
        val run = activeRun ?: return
        if (run.isNative) return
        if (run.paused || run.cooling) return

        val totalSec = durationFor(run.categoryId)
        val elapsed = min(totalSec, run.elapsedSec + dtSec)
        val progress = elapsed.toFloat() / totalSec.toFloat()
        val completed = floor(progress * run.totalTests).toInt().coerceIn(0, run.totalTests)
        val tests = when (run.categoryId) {
            "custom" -> selectedTests.map { id ->
                TestCatalog.tests.firstOrNull { it.id == id } ?: TestDefinition(id, id, "", run.categoryId, 1, "Easy", 1, "Must Have")
            }
            else -> emptyList()
        }
        val current = tests.getOrNull(completed.coerceAtMost(tests.lastIndex))?.name ?: "Finishing"

        // Real telemetry only: read the actual battery/CPU state from the device.
        // No synthetic sine-wave FPS/temperature/power/clock values.
        val telemetry = applicationContext?.let { com.benchsuite.app.nativecore.DeviceTelemetryReader.read(it) }
        val temp = telemetry?.temperatureC ?: run.temperatureC
        val power = telemetry?.powerW ?: run.powerW
        val clock = telemetry?.clockGhz ?: run.cpuClockGhz
        // FPS is not measurable without a real rendering workload; 0 = unmeasured.
        val fps = 0

        activeRun = run.copy(
            progress = progress,
            elapsedSec = elapsed,
            etaSec = (totalSec - elapsed).coerceAtLeast(0),
            completedTests = completed,
            currentTest = current,
            liveFps = fps,
            temperatureC = temp,
            powerW = power,
            cpuClockGhz = clock,
            cooling = temp > 43.5 && progress > 0.55,
        )
    }

    /* ---------------------- Pre-Test Checklist ----------------------- */

    fun runPreTestChecklist(): GuidedPreTestChecklist.ChecklistResult {
        val context = applicationContext
        val result = if (context != null) {
            GuidedPreTestChecklist.check(context)
        } else {
            GuidedPreTestChecklist.ChecklistResult(
                checks = emptyList(),
                canProceed = true,
                allPassed = true,
                recommendedActions = emptyList(),
            )
        }
        preTestChecklistResult = result
        return result
    }

    val canProceedWithRun: Boolean
        get() = preTestChecklistResult?.canProceed ?: true

    val preTestChecks: List<EnvironmentCheck>
        get() = preTestChecklistResult?.checks ?: emptyList()

    /* ----------------------- Analysis Engines ------------------------- */

    fun explainPerformance(record: RunRecord = latestRecordedRun): PerformanceExplainer.ExplanationResult =
        PerformanceExplainer.explain(record)

    fun getInsights(record: RunRecord = latestRecordedRun): List<Insight> =
        PerformanceExplainer.generateInsights(record)

    fun calculateUseCaseFit(record: RunRecord = latestRecordedRun): UseCaseFitCalculator.UseCaseFitReport =
        UseCaseFitCalculator.calculate(record)

    fun getUseCaseFits(record: RunRecord = latestRecordedRun): List<UseCaseFit> =
        calculateUseCaseFit(record).toList()

    /* ------------------------ Export Actions -------------------------- */

    fun exportPdf(
        record: RunRecord = latestRecordedRun,
        outputFile: File? = null,
    ): File {
        val context = applicationContext
        val file = outputFile ?: run {
            val baseDir = context?.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
                ?: context?.filesDir
                ?: File("/sdcard/download/project/banchmark")
            baseDir.mkdirs()
            File(baseDir, "ABS_Report_${record.id}.pdf")
        }
        // Export ONLY real captured telemetry; no synthetic fallback timeline.
        val samples = latestTelemetrySamples
        return PdfReportGenerator.generatePdf(
            context = context,
            record = record,
            telemetrySamples = samples,
            outputFile = file,
        )
    }

    fun exportCsv(
        record: RunRecord = latestRecordedRun,
        outputFile: File? = null,
    ): File {
        val context = applicationContext
        val file = outputFile ?: run {
            val baseDir = context?.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
                ?: context?.filesDir
                ?: File("/sdcard/download/project/banchmark")
            baseDir.mkdirs()
            File(baseDir, "ABS_Telemetry_${record.id}.csv")
        }
        // Export ONLY real captured telemetry; no synthetic fallback timeline.
        val samples = latestTelemetrySamples
        return RawDataExporter.exportTelemetryCsv(
            record = record,
            samples = samples,
            outputFile = file,
        )
    }

    fun exportJson(
        record: RunRecord = latestRecordedRun,
        outputFile: File? = null,
    ): File {
        val context = applicationContext
        val file = outputFile ?: run {
            val baseDir = context?.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
                ?: context?.filesDir
                ?: File("/sdcard/download/project/banchmark")
            baseDir.mkdirs()
            File(baseDir, "ABS_RunRecord_${record.id}.json")
        }
        // Export ONLY real captured telemetry; no synthetic fallback timeline.
        val samples = latestTelemetrySamples
        return RawDataExporter.exportRunJson(
            record = record,
            samples = samples,
            outputFile = file,
        )
    }

    fun exportZip(
        record: RunRecord = latestRecordedRun,
        outputFile: File? = null,
    ): File {
        val context = applicationContext
        val baseDir = context?.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: context?.filesDir
            ?: File("/sdcard/download/project/banchmark")
        baseDir.mkdirs()
        val zipFile = outputFile ?: File(baseDir, "ABS_Archive_${record.id}.zip")

        val pdfFile = exportPdf(record)
        val jsonFile = exportJson(record)
        val csvFile = exportCsv(record)

        java.util.zip.ZipOutputStream(java.io.FileOutputStream(zipFile)).use { zos ->
            for (f in listOf(pdfFile, jsonFile, csvFile)) {
                if (f.exists()) {
                    val entry = java.util.zip.ZipEntry(f.name)
                    zos.putNextEntry(entry)
                    f.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
        return zipFile
    }

    fun renderShareCard(
        record: RunRecord = latestRecordedRun,
        format: ShareCardRenderer.CardFormat = ShareCardRenderer.CardFormat.STORY_VERTICAL,
    ): Bitmap = ShareCardRenderer.renderShareCard(
        context = applicationContext,
        record = record,
        format = format,
    )

    fun exportShareCard(
        record: RunRecord = latestRecordedRun,
        format: ShareCardRenderer.CardFormat = ShareCardRenderer.CardFormat.STORY_VERTICAL,
        outputFile: File? = null,
    ): File {
        val context = applicationContext
        val file = outputFile ?: run {
            val baseDir = context?.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                ?: context?.filesDir
                ?: File("/sdcard/download/project/banchmark")
            baseDir.mkdirs()
            val suffix = if (format == ShareCardRenderer.CardFormat.STORY_VERTICAL) "story" else "feed"
            File(baseDir, "ABS_ShareCard_${record.id}_$suffix.png")
        }
        return ShareCardRenderer.renderAndSave(
            context = context,
            record = record,
            outputFile = file,
            format = format,
        )
    }

    /* ----------------------- Engine Feature Wiring ----------------------- */

    // --- CPU ---
    fun runCpuScheduler(): SchedulerEfficiencyProfiler.ComprehensiveSchedulerReport =
        SchedulerEfficiencyProfiler.runProfiler()

    fun runCpuCacheHierarchy(): CacheHierarchyLatencyMapper.ComprehensiveCacheReport =
        CacheHierarchyLatencyMapper.runCacheHierarchyMap()

    fun runCpuSimdNeon(): SimdNeonSve2ThroughputProfiler.VectorProfileReport =
        SimdNeonSve2ThroughputProfiler.runVectorProfile()

    fun runCpuBranchPrediction(): BranchPredictionStressTest.BranchReport =
        BranchPredictionStressTest.runBranchPredictionTest()

    fun runCpuCoreToCore(): CoreToCoreLatencyMatrix.CoreMatrixReport =
        CoreToCoreLatencyMatrix.buildLatencyMatrix()

    // --- GPU ---
    fun runGpuVrs(): VariableRateShadingEfficiencyBenchmark.VrsEfficiencyReport =
        VariableRateShadingEfficiencyBenchmark.runVrsBenchmark()

    fun runGpuShaderStutter(): ShaderCompilationStutterProfiler.StutterReport =
        ShaderCompilationStutterProfiler.runStutterProfile()

    fun runGpuFrequency(): GpuFrequencyResidencyTracker.ResidencyReport =
        GpuFrequencyResidencyTracker.trackResidency()

    fun runGpuMemoryCompression(): GpuMemoryCompressionRatioTester.CompressionReport =
        GpuMemoryCompressionRatioTester.runCompressionTest()

    fun runGpuFillrate(): FillrateTextureBandwidthAnalyzer.FillrateReport =
        FillrateTextureBandwidthAnalyzer.runFillrateAnalysis()

    // --- AI ---
    fun runAiLlmContext(): LiteRtNpuEngine.ContextCurveReport =
        LiteRtNpuEngine.evaluateContextEfficiencyCurve()

    fun runAiMultiModal(): MultiModalAiPipelineBenchmark.PipelineReport =
        MultiModalAiPipelineBenchmark.runPipelineBenchmark()

    fun runAiPareto(): AiAccuracyPerformanceParetoFrontier.ParetoReport =
        AiAccuracyPerformanceParetoFrontier.runParetoFrontier()

    fun runAiStableDiffusion(): StableDiffusionIterationTimeConsistency.ConsistencyReport =
        StableDiffusionIterationTimeConsistency.runConsistencyPass()

    fun runAiNpuThermal(): LiteRtNpuEngine.FallbackInspectionResult =
        LiteRtNpuEngine.inspectGraphFallback()

    fun runAiModelLoad(): AiModelLoadTimeBenchmark.LoadTimeReport =
        AiModelLoadTimeBenchmark.runLoadTimeBenchmark()

    fun runAiSpeculative(): SpeculativeDecodingEfficiencyTest.SpeculativeReport =
        SpeculativeDecodingEfficiencyTest.runSpeculativeDecodingTest()

    fun runAiFederated(): FederatedLearningNodeBenchmark.FederatedReport =
        FederatedLearningNodeBenchmark.runFederatedLearningRound()

    fun runAiNpuFallback(): LiteRtNpuEngine.FallbackInspectionResult =
        LiteRtNpuEngine.inspectGraphFallback()

    fun runAiOnDeviceRag(): OnDeviceRagBenchmark.RagReport =
        OnDeviceRagBenchmark.runRagBenchmark()

    fun runAiSpeechRtf(): SpeechRecognitionRealTimeFactor.RtfReport =
        SpeechRecognitionRealTimeFactor.measureRealTimeFactor()

    fun runAiEnergyToken(context: android.content.Context): LiteRtNpuEngine.EnergyPerTokenReport =
        LiteRtNpuEngine.measureEnergyPerToken(context)

    // --- Storage ---
    fun runStorageFragmentation(): StorageFragmentationSimulator.FragmentationReport =
        StorageFragmentationSimulator.runFragmentationSimulation()

    fun runStorageAiWorkload(): AiWorkloadStoragePatternBenchmark.AiStorageReport =
        AiWorkloadStoragePatternBenchmark.runAiStoragePatternBenchmark()

    fun runStorageZram(): ZramSwapEfficiencyAnalyzer.SwapReport =
        ZramSwapEfficiencyAnalyzer.analyzeZramEfficiency()

    fun runStorageUfsThermal(): UfsControllerThermalThrottlingTest.UfsThermalReport =
        UfsControllerThermalThrottlingTest.runUfsThermalThrottleTest()

    fun runStorageEndurance(): StorageEnduranceWearEstimator.EnduranceReport =
        StorageEnduranceWearEstimator.estimateStorageEndurance()

    fun runStorageAppInstall(): AppInstallDexOptimizationTime.InstallReport =
        AppInstallDexOptimizationTime.benchmarkAppInstallTimes()

    fun runStorageSmallFile(): SmallFileMetadataStress.MetadataReport =
        SmallFileMetadataStress.runMetadataStress()

    // --- Network ---
    fun runNetworkWifi7Mlo(context: android.content.Context): Wifi7MloBenchmark.Wifi7MloReport =
        Wifi7MloBenchmark.runBenchmark(context)

    fun runNetworkUrllc(context: android.content.Context): Urllc5gLatencyProfiler.Urllc5gReport =
        Urllc5gLatencyProfiler.runProfile(context)

    fun runNetworkUwb(context: android.content.Context): UwbPrecisionBenchmark.UwbBenchmarkReport =
        UwbPrecisionBenchmark.runBenchmark(context)

    fun runNetworkSatelliteSos(context: android.content.Context): SatelliteSosTimeToRescueBenchmark.SosBenchmarkReport =
        SatelliteSosTimeToRescueBenchmark.runSosBenchmark(context)

    fun runNetworkEsim(context: android.content.Context): EsimProfileSwitchingSpeedTest.EsimReport =
        EsimProfileSwitchingSpeedTest.runEsimSwitchTest(context)

    fun runNetworkBufferbloat(): BufferbloatLoadedLatencyTest.BufferbloatReport =
        BufferbloatLoadedLatencyTest.runBufferbloatTest()

    fun runNetworkModemThermal(context: android.content.Context): CellularModemThermalPowerProfile.ModemReport =
        CellularModemThermalPowerProfile.profileModem(context)

    fun runNetworkWifiRoaming(context: android.content.Context): WiFiRoamingStabilityTest.RoamingReport =
        WiFiRoamingStabilityTest.runRoamingTest(context)

    fun runNetworkLeAudio(context: android.content.Context): BluetoothLeAudioLatencyQualityBenchmark.LeAudioReport =
        BluetoothLeAudioLatencyQualityBenchmark.measureLeAudio(context)

    // --- Battery ---
    fun runBatteryPerApp(context: android.content.Context): PerAppPowerAttributionProfiler.PowerAttributionReport =
        PerAppPowerAttributionProfiler.attributePower(context)

    fun runBatteryWireless(context: android.content.Context): WirelessChargingEfficiencyBenchmark.WirelessReport =
        WirelessChargingEfficiencyBenchmark.profileWirelessCharging(context)

    fun runBatteryReverseWireless(context: android.content.Context): ReverseWirelessChargingStressTest.ReverseWirelessReport =
        ReverseWirelessChargingStressTest.profileReverseWireless(context)

    fun runBatteryWired(context: android.content.Context): WiredChargingCurveThermalProfiler.ChargingReport =
        WiredChargingCurveThermalProfiler.profileChargingCurve(context)

    fun runBatteryIdleDrain(context: android.content.Context): IdleDrainDeepSleepEfficiency.IdleDrainReport =
        IdleDrainDeepSleepEfficiency.measureIdleDrain(context)

    // --- Display ---
    fun runDisplayPwm(context: android.content.Context): PwmDimmingDetector.PwmDimmingReport =
        PwmDimmingDetector.analyzeDisplayPwm(context)

    fun runDisplayHdr(context: android.content.Context): HdrToneMappingAnalyzer.HdrToneMappingReport =
        HdrToneMappingAnalyzer.analyzeDisplay(context)

    fun runDisplayTouchLatency(context: android.content.Context): TouchLatencyProfiler.TouchLatencyReport =
        TouchLatencyProfiler.Session(context).let { it.finalizeReport() }

    fun runDisplayVrr(context: android.content.Context): VariableRefreshRateTransitionSmoothness.VrrReport =
        VariableRefreshRateTransitionSmoothness.analyzeVrrTransitions(context)

    fun runDisplayStylus(context: android.content.Context): StylusLatencyPressurePrecisionBenchmark.StylusReport =
        StylusLatencyPressurePrecisionBenchmark.measureStylusPrecision(context)

    fun runDisplayLuminance(context: android.content.Context): PeakSustainedLuminanceCurve.LuminanceReport =
        PeakSustainedLuminanceCurve.analyzeLuminance(context)

    fun runDisplayPalmRejection(context: android.content.Context): PalmRejectionGhostTouchTest.PalmRejectionReport =
        PalmRejectionGhostTouchTest.runPalmRejectionTest(context)

    // --- Audio ---
    fun runAudioSpatial(context: android.content.Context): SpatialAudioHeadTracker.AncEffectivenessReport =
        SpatialAudioHeadTracker.profileAncEffectiveness(context)

    fun runAudioTapTone(context: android.content.Context): TapToToneLatencyBenchmark.RtfReport =
        TapToToneLatencyBenchmark.measureTapToToneLatency(context)

    fun runAudioHaptic(context: android.content.Context): HapticFrequencyResponseAnalyzer.HapticReport =
        HapticFrequencyResponseAnalyzer.analyzeHapticResponse(context)

    fun runAudioSpeaker(context: android.content.Context): SpeakerFrequencyResponseDistortion.SpeakerReport =
        SpeakerFrequencyResponseDistortion.analyzeSpeakerResponse(context)

    fun runAudioMicrophone(context: android.content.Context): MicrophoneNoiseFloorDynamicRange.MicrophoneReport =
        MicrophoneNoiseFloorDynamicRange.measureMicrophoneQuality(context)

    // --- Camera ---
    fun runCameraIsp(context: android.content.Context): CameraIspBenchmark.CameraIspReport =
        CameraIspBenchmark.runBenchmark(context)

    fun runCameraNightMode(context: android.content.Context): NightModeProcessingLatency.NightModeReport =
        NightModeProcessingLatency.measureNightModeLatency(context)

    fun runCameraVideoStab(context: android.content.Context): VideoStabilizationQualityAnalyzer.VideoStabReport =
        VideoStabilizationQualityAnalyzer.analyzeStabilization(context)

    fun runCameraRaw(context: android.content.Context): RawProcessingPipelineBenchmark.RawReport =
        RawProcessingPipelineBenchmark.benchmarkRawPipeline(context)

    fun runCameraAutofocus(context: android.content.Context): AutofocusAcquisitionSpeed.AfReport =
        AutofocusAcquisitionSpeed.measureAutofocusSpeed(context)

    // --- Sensors ---
    fun runSensorsMems(context: android.content.Context): MemsSensorCalibrationQualityScore.CalibrationReport =
        MemsSensorCalibrationQualityScore.assessCalibration(context)

    fun runSensorsGnss(context: android.content.Context): GnssColdStartTimeToFirstFix.TtffReport =
        GnssColdStartTimeToFirstFix.measureTtff(context)

    fun runSensorsBarometric(context: android.content.Context): BarometricAltimeterAccuracyTest.BarometricReport =
        BarometricAltimeterAccuracyTest.testBarometricAltimeter(context)

    fun runSensorsMagnetometer(context: android.content.Context): MagnetometerInterferenceProfiler.MagnetometerReport =
        MagnetometerInterferenceProfiler.profileMagnetometer(context)

    fun runSensorsGyro(context: android.content.Context): GyroscopeDriftTest.GyroReport =
        GyroscopeDriftTest.testGyroscopeDrift(context)

    fun runSensorsDualGnss(context: android.content.Context): DualFrequencyGnssAccuracyWalkTest.GnssAccuracyReport =
        DualFrequencyGnssAccuracyWalkTest.runGnssAccuracyTest(context)

    // --- Gaming ---
    fun runGamingPredictedFps(): PredictedGamingFpsEngine.GamingFpsReport =
        PredictedGamingFpsEngine.predictGamingFps()

    fun runGamingEmulator(): EmulatorPerformancePredictor.EmulatorReport =
        EmulatorPerformancePredictor.predictEmulatorPerformance()

    fun runGamingCloud(context: android.content.Context): CloudGamingReadinessScore.CloudGamingReport =
        CloudGamingReadinessScore.measureReadiness(context)

    fun runGamingAppLaunch(context: android.content.Context): AppLaunchTimeConsistencyBenchmark.LaunchConsistencyReport =
        AppLaunchTimeConsistencyBenchmark.measureLaunchConsistency(context)

    fun runGamingTouchPhoton(context: android.content.Context): TouchToPhotonGamingLatency.TouchToPhotonReport =
        TouchToPhotonGamingLatency.estimateTouchToPhotonLatency(context)

    fun runGamingColdWarm(context: android.content.Context): ColdVsWarmGameLaunchTime.GameLaunchReport =
        ColdVsWarmGameLaunchTime.benchmarkGameLaunchTimes(context)

    // --- Thermal ---
    fun runThermalStorytelling(context: android.content.Context): ThermalStorytellingEngine.ThermalStorytellingReport =
        ThermalStorytellingEngine.runThermalStoryEvaluation(context)

    fun runThermalPrediction(context: android.content.Context): ThermalPredictionModel.ThermalPredictionReport =
        ThermalPredictionModel.predictThermalHorizon(context)

    fun runThermalActiveCooling(): ActiveCoolingEfficiencyIndex.CoolingReport =
        ActiveCoolingEfficiencyIndex.measureCoolingEfficiency()

    fun runThermalZoneMap(): ThermalZoneCorrelationMap.ThermalMapReport =
        ThermalZoneCorrelationMap.mapThermalZones()

    // --- Security ---
    fun runSecurityBiometric(context: android.content.Context): BiometricUnlockLatencyAccuracyProfiler.BiometricProfileReport =
        BiometricUnlockLatencyAccuracyProfiler.profileBiometrics(context)

    fun runSecurityHsm(): HardwareSecurityModuleThroughputTest.HsmReport =
        HardwareSecurityModuleThroughputTest.benchmarkHsmThroughput()

    fun runSecuritySideChannel(): SideChannelLeakageDetection.SideChannelReport =
        SideChannelLeakageDetection.analyzeSideChannels()

    fun runSecurityIntegrity(context: android.content.Context): IntegrityRootPostureScanner.IntegrityReport =
        IntegrityRootPostureScanner.scanIntegrity(context)

    fun runSecurityFileEnc(): FileBasedEncryptionThroughputBenchmark.EncryptionReport =
        FileBasedEncryptionThroughputBenchmark.benchmarkEncryption()

    // --- Longevity ---
    fun runLongevityOsUpdate(context: android.content.Context, currentScore: Int, thermalC: Double, batteryDrain: Double): OsUpdateRegressionTracker.RegressionReport =
        OsUpdateRegressionTracker.detectRegression(context, currentScore, thermalC, batteryDrain)

    fun runLongevityDeviceHealth(context: android.content.Context): DeviceHealthCertificate.Certificate =
        DeviceHealthCertificate.generateCertificate(context)

    // --- Fairplay ---
    fun runFairplayCheatDetector(context: android.content.Context): CheatDetectorEngine.CheatAuditReport =
        CheatDetectorEngine.auditDevice(context)

    fun runFairplaySignedResult(): SignedResultTamperProofing.SigningReport =
        SignedResultTamperProofing.ensureSigningKey(applicationContext!!)

    // --- Insights ---
    fun runInsightsBottleneck(): BottleneckRootCauseEngine.BottleneckReport =
        BottleneckRootCauseEngine.analyzeBottleneck()

    fun runInsightsUpgrade(currentScore: Int): UpgradeAdvisor.UpgradeRecommendation =
        UpgradeAdvisor.adviseUpgrade(currentScore)

    fun runInsightsPeer(deviceScore: Int): PeerPercentileRanking.PercentileReport =
        PeerPercentileRanking.rankDevice(deviceScore)

    fun runInsightsForecast(): PerformanceForecastEngine.ForecastReport =
        PerformanceForecastEngine.generateForecast()

    fun runInsightsAnomaly(context: android.content.Context, currentScore: Int, thermalC: Double, batteryDrain: Double): AnomalyRegressionAlerts.AnomalyReport =
        AnomalyRegressionAlerts.analyzeAnomalies(context, currentScore, thermalC, batteryDrain)

    fun runInsightsOptimization(refreshRate: Int, thermalC: Double, batteryDrain: Double, cpuUtil: Double): PersonalizedOptimizationTips.OptimizationReport =
        PersonalizedOptimizationTips.generateTips(refreshRate, thermalC, batteryDrain, cpuUtil)

    // --- Social ---
    fun runSocialSocFamily(): SocFamilyRanking.SocRankReport =
        SocFamilyRanking.rankSocFamily()

    fun runSocialReviewer(): ReviewerMode.ReviewerReport =
        ReviewerMode.runReviewerProtocol(ReviewerMode.LabProtocol("Lab Protocol", 5, 30, true))

    fun runSocialCommunity(context: android.content.Context, thermalC: Double, drainMw: Double, score: Int): CommunityHeatmap.HeatmapReport =
        CommunityHeatmap.recordCommunitySample(context, thermalC, drainMw, score)

    // --- Reporting ---
    fun runReportingReviewerTemplate(): ReviewerReportTemplate.ReviewerReport =
        ReviewerReportTemplate.generateReviewerTemplate()

    fun runReportingScheduled(context: android.content.Context, label: String, score: Int, thermalC: Double, batteryHealth: Int): ScheduledHealthReports.HealthTrendReport =
        ScheduledHealthReports.recordHealthTrend(context, label, score, thermalC, batteryHealth)

    // --- Enterprise ---
    fun runEnterpriseCustomBuilder(): CustomBenchmarkBuilder.ExecutionPlan =
        CustomBenchmarkBuilder.buildExecutionPlan(CustomBenchmarkBuilder.BenchmarkSuite("suite_1", "Custom Suite", emptyList(), 0))

    fun runEnterpriseCliAdb(): CliAdbAutomation.AutomationResult =
        CliAdbAutomation.buildResult(CliAdbAutomation.parseCommand("run-quick-test"))

    // --- UX ---
    fun runUxLiveOverlay(enabled: Boolean): LivePerformanceOverlay.OverlayReport =
        LivePerformanceOverlay.snapshotOverlayState(enabled)

    fun runUxWidgets(context: android.content.Context): WidgetsQuickSettingsTile.WidgetsReport =
        WidgetsQuickSettingsTile.buildWidgetsAndTiles(context)

    // --- Foldable ---
    fun runFoldableHinge(context: android.content.Context): HingeDurabilityTracker.ComprehensiveFoldableReport =
        HingeDurabilityTracker.compileReport(context, null)

    // --- Wearable ---
    fun runWearableWearOs(context: android.content.Context): WearOsCompanionBridge.BridgeConnectionStatus =
        WearOsCompanionBridge.initialize(context)

    // --- Native Rust Feature Wrappers ---
    fun runNativeCache(): com.benchsuite.app.nativecore.NativeComponentResult? =
        com.benchsuite.app.nativecore.NativeBridge.runCache()

    fun runNativeRayTracing(): com.benchsuite.app.nativecore.NativeComponentResult? =
        com.benchsuite.app.nativecore.NativeBridge.runRayTracing()

    fun runNativeMeshShader(): com.benchsuite.app.nativecore.NativeComponentResult? =
        com.benchsuite.app.nativecore.NativeBridge.runMeshShader()

    fun runNativeAsyncCompute(): com.benchsuite.app.nativecore.NativeComponentResult? =
        com.benchsuite.app.nativecore.NativeBridge.runAsyncCompute()

    fun runNativeFairPlay(): com.benchsuite.app.nativecore.NativeFairPlayReport? =
        com.benchsuite.app.nativecore.NativeBridge.fairPlay()

    fun probeNativeVulkan(): com.benchsuite.app.nativecore.NativeVulkanProbeReport? =
        com.benchsuite.app.nativecore.NativeBridge.probeVulkan()

    /* --------------------------- Settings ---------------------------- */

    fun updateSettings(transform: (SettingsState) -> SettingsState) {
        settings = transform(settings)
    }

    fun toggleConsent(index: Int) {
        consents = consents.mapIndexed { i, item ->
            if (i == index && !item.required) item.copy(enabled = !item.enabled) else item
        }
    }

    fun toggleSchedule(id: String) {
        schedules = schedules.map { if (it.id == id) it.copy(enabled = !it.enabled) else it }
    }

    fun toggleTest(id: String) {
        selectedTestIds = if (id in selectedTestIds) selectedTestIds - id else selectedTestIds + id
    }

    fun markReportShared(id: String) {
        reportSharedIds = reportSharedIds + id
    }

    /* --------------------------- Custom ------------------------------ */

    val selectedTests: List<TestDefinition>
        get() = TestCatalog.tests.filter { it.id in selectedTestIds }

    val customDurationMinutes: Int
        get() = max(2, (selectedTests.sumOf { it.minutes } * 0.62).toInt() + 1)

    /* --------------------------- Util -------------------------------- */

    fun gaugeMax(categoryId: String): Int = if (categoryId == "health") 100 else 1100
}
