package com.benchsuite.app.features.account

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    var showDelete by remember { mutableStateOf(false) }
    var deleted by remember { mutableStateOf(false) }
    var exported by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Privacy and data",
            subtitle = "Local-first by design",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Your rights, in plain language",
                    title = "Nothing leaves unless you ask.",
                    body = "Benchmarks run offline. Every upload is an explicit, signed action you can revoke.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).background(BenchTheme.colors.success.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.Shield, null, tint = BenchTheme.colors.success, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Local storage active", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Runs, telemetry and reports are stored on this device only.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        StatusChip(if (deleted) "Cleared" else "Protected", tint = if (deleted) BenchTheme.colors.warning else BenchTheme.colors.success)
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag("No ads ID")
                        Tag("No account")
                        Tag("No trackers")
                    }
                }
            }

            item { SectionHeader(title = "Consent") }
            item {
                SurfaceCard {
                    SessionState.consents.forEachIndexed { index, consent ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(consent.title, style = MaterialTheme.typography.bodyLarge)
                                    if (consent.required) {
                                        Spacer(Modifier.width(6.dp))
                                        StatusChip("Required", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                                Text(
                                    consent.body,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Spacer(Modifier.width(Spacing.sm))
                            Switch(
                                checked = consent.enabled,
                                onCheckedChange = { SessionState.toggleConsent(index) },
                                enabled = !consent.required,
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Required consent covers local storage only. Everything else can be switched off without losing features.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item { SectionHeader(title = "What is stored") }
            item {
                SurfaceCard {
                    Text(
                        "वास्तविक स्टोरेज इनवेंट्री रन रिकॉर्ड से जनरेट की जाएगी।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item { SectionHeader(title = "Your data rights") }
            item {
                SurfaceCard {
                    Text(
                        "Export a signed archive or delete everything. Deletion removes runs, reports, raw telemetry and your local identity; it cannot be undone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        OutlinedButton(
                            onClick = {
                                runCatching { SessionState.exportJson() }
                                exported = "JSON"
                            },
                            modifier = Modifier.weight(1f).height(46.dp),
                        ) {
                            Icon(Icons.Outlined.Download, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("JSON")
                        }
                        OutlinedButton(
                            onClick = {
                                runCatching { SessionState.exportCsv() }
                                exported = "CSV"
                            },
                            modifier = Modifier.weight(1f).height(46.dp),
                        ) {
                            Icon(Icons.Outlined.Download, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("CSV")
                        }
                        Button(
                            onClick = { showDelete = true },
                            modifier = Modifier.height(46.dp),
                        ) {
                            Icon(Icons.Outlined.DeleteForever, null, modifier = Modifier.size(16.dp))
                        }
                    }
                    if (exported != null) {
                        Spacer(Modifier.height(Spacing.sm))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.CheckCircle, null, tint = BenchTheme.colors.success, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "$exported archive prepared · saved to Downloads",
                                style = MaterialTheme.typography.bodySmall,
                                color = BenchTheme.colors.success,
                            )
                        }
                    }
                    if (deleted) {
                        Spacer(Modifier.height(Spacing.sm))
                        Text(
                            "All local benchmark data has been deleted. A new run will start a fresh history.",
                            style = MaterialTheme.typography.bodySmall,
                            color = BenchTheme.colors.warning,
                        )
                    }
                }
            }

            item { SectionHeader(title = "Retention") }
            item {
                SurfaceCard {
                    RetentionRow("Run records", "Kept until deleted")
                    RetentionRow("Raw telemetry", "90 days, then aggregated")
                    RetentionRow("Reports", "Until deleted")
                    RetentionRow("Crash traces", "7 days, only if opt-in")
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Uses Android scoped storage. No broad file access is requested.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                SurfaceCard {
                    Text("Security model", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Results are signed with a hardware-backed key. The app verifies signatures locally before marking a score as verified. There is no server that can alter your history.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Privacy contact: privacy@benchsuite.local",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                Text(
                    "Privacy policy version 2026.11 · applies to app version 1.0.0",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete all local data?") },
            text = {
                Text(
                    "This removes every run, report, raw telemetry file and the local install identity. It cannot be undone. Leaderboard entries already uploaded are not affected.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDelete = false
                        deleted = true
                        exported = null
                        SessionState.clearAllData()
                    },
                ) {
                    Text("Delete everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) { Text("Keep my data") }
            },
            icon = { Icon(Icons.Outlined.DeleteForever, null, tint = BenchTheme.colors.danger) },
        )
    }
}

@Composable
private fun RetentionRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
