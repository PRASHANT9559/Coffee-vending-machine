package com.benchsuite.app.data.persistence

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.benchsuite.app.data.model.RunRecord

@Dao
interface RunRecordDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: RunRecordEntity)

    @Query("SELECT * FROM run_records ORDER BY createdAtMs DESC")
    suspend fun getAll(): List<RunRecordEntity>

    @Query("SELECT * FROM run_records WHERE id = :id")
    suspend fun findById(id: String): RunRecordEntity?

    @Query("DELETE FROM run_records")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM run_records")
    suspend fun count(): Int

    @Query("SELECT * FROM run_records ORDER BY createdAtMs DESC LIMIT 1")
    suspend fun getLatest(): RunRecordEntity?

    // Convenience wrappers that map to/from the domain model.
    suspend fun insertRun(record: RunRecord) {
        insert(RunRecordEntity.fromModel(record))
    }

    suspend fun getAllRuns(): List<RunRecord> =
        getAll().map { RunRecordEntity.toModel(it) }

    suspend fun findRunById(id: String): RunRecord? =
        findById(id)?.let { RunRecordEntity.toModel(it) }

    suspend fun getLatestRun(): RunRecord? =
        getLatest()?.let { RunRecordEntity.toModel(it) }
}
