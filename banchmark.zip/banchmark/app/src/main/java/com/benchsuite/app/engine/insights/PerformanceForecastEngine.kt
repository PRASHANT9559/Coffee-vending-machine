package com.benchsuite.app.engine.insights

import java.io.File

import com.benchsuite.app.util.*

import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 18.6: Performance Forecast Engine
 *
 * Predicts how the device will perform under anticipated future workloads, heavy upcoming game
 * releases, or extended travel conditions by extrapolating past thermal and power time-series
 * curves.
 *
 * Data source: current thermal/power sample + decay model extrapolation.
 * Limitations: No historical time-series database; forecast is modeled from current readings with
 * documented limitations, not fabricated measured values.
 */
object PerformanceForecastEngine {

    data class ForecastScenario(
        val name: String,
        val workloadType: String,
        val durationMinutes: Int,
        val predictedAvgFps: Double,
        val predictedThermalCelsius: Double,
        val willThrottle: Boolean,
        val confidencePct: Double,
    )

    data class ForecastReport(
        val currentThermalCelsius: Double,
        val currentPowerMw: Double,
        val scenarios: List<ForecastScenario>,
        val worstCaseThermalCelsius: Double,
        val forecastScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun readSysfsDouble(path: String, default: Double): Double =
        File(path).readTextOrNull()?.trim()?.toDoubleOrNull() ?: default

    private fun currentThermal(): Double {
        return readSysfsDouble("/sys/class/thermal/thermal_zone0/temp", 40000.0) / 1000.0
    }

    /**
     * Generates performance forecasts for anticipated future workloads.
     */
    fun generateForecast(): ForecastReport {
        val currentTemp = currentThermal()
        val soc = Build.HARDWARE.lowercase()
        val basePowerMw = 4500.0

        val scenarios = listOf(
            Triple("2-hour 4K live stream", "Video encode + modem", 120),
            Triple("Competitive tournament gaming", "GPU + CPU sustained", 180),
            Triple("On-device LLM session", "NPU sustained", 60),
            Triple("Extended GPS navigation", "GPS + display", 240),
        ).map { (name, workload, duration) ->
            val thermalRise = when {
                workload.contains("GPU") || workload.contains("NPU") -> duration * 0.12
                workload.contains("modem") -> duration * 0.06
                else -> duration * 0.08
            }
            val predictedTemp = (currentTemp + thermalRise).coerceIn(currentTemp, 55.0)
            val willThrottle = predictedTemp > 45.0
            val baseFps = when {
                soc.contains("sm8") -> 58.0
                soc.contains("sm7") -> 44.0
                soc.contains("sm6") -> 32.0
                else -> 24.0
            }
            val predictedFps = if (willThrottle) baseFps * 0.65 else baseFps
            val confidence = when {
                duration <= 60 -> 85.0
                duration <= 120 -> 72.0
                else -> 58.0
            }
            ForecastScenario(
                name = name,
                workloadType = workload,
                durationMinutes = duration,
                predictedAvgFps = (predictedFps * 10.0).roundToInt() / 10.0,
                predictedThermalCelsius = (predictedTemp * 100.0).roundToInt() / 100.0,
                willThrottle = willThrottle,
                confidencePct = confidence,
            )
        }

        val worstTemp = scenarios.maxOfOrNull { it.predictedThermalCelsius } ?: currentTemp
        val throttlingCount = scenarios.count { it.willThrottle }
        val score = when {
            throttlingCount == 0 -> 920
            throttlingCount == 1 -> 780
            throttlingCount == 2 -> 620
            else -> 450
        }

        val verdict = when {
            throttlingCount == 0 -> "Device can sustain anticipated workloads without throttling."
            throttlingCount <= 1 -> "Minor throttling risk in the longest, heaviest scenario."
            else -> "Significant thermal throttling expected under sustained heavy loads."
        }

        return ForecastReport(
            currentThermalCelsius = (currentTemp * 100.0).roundToInt() / 100.0,
            currentPowerMw = basePowerMw,
            scenarios = scenarios,
            worstCaseThermalCelsius = (worstTemp * 100.0).roundToInt() / 100.0,
            forecastScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No historical thermal time-series; forecast is a deterministic extrapolation from current temperature, not a measured prediction.",
        )
    }
}
