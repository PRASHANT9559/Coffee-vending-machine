package com.benchsuite.app.features.entry

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeveloperBoard
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Smartphone
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.ui.components.BrandMark
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.ProgressLine
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.Spacing
import kotlinx.coroutines.delay

/* ------------------------------- Splash ---------------------------- */

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1500)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                        MaterialTheme.colorScheme.background,
                    ),
                    radius = 900f,
                ),
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandMark(84.dp)
            Spacer(Modifier.height(Spacing.lg))
            Text("BenchSuite", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "Understand why your device performs.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(Spacing.xl))
            ProgressLine(
                progress = 0.72f,
                modifier = Modifier.width(120.dp),
                height = 2.dp,
            )
        }
        Text(
            text = "v1.0 · methodology 2.4.1",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 28.dp),
        )
    }
}

/* ----------------------------- Onboarding -------------------------- */

private data class OnboardingPage(
    val eyebrow: String,
    val title: String,
    val body: String,
    val icon: ImageVector,
    val points: List<String>,
)

private val onboardingPages = listOf(
    OnboardingPage(
        eyebrow = "Beyond one number",
        title = "Peak speed is not real speed.",
        body = "Every run reports peak and sustained performance together, with a thermal decay curve and a confidence level.",
        icon = Icons.Outlined.Speed,
        points = listOf(
            "Peak vs sustained, always together",
            "Thermal decay plotted over time",
            "Reproducibility confidence on every score",
        ),
    ),
    OnboardingPage(
        eyebrow = "Insight layer",
        title = "Numbers, translated into answers.",
        body = "Find out what your device is actually good at: gaming, video editing, offline AI, battery life or multitasking.",
        icon = Icons.Outlined.Insights,
        points = listOf(
            "Per-use-case verdicts, not guesses",
            "Bottleneck root-cause explanations",
            "Actions ranked by measured impact",
        ),
    ),
    OnboardingPage(
        eyebrow = "Local-first",
        title = "Your data stays on your device.",
        body = "Benchmarks run offline. Leaderboard uploads are opt-in, signed and limited to scores plus model-level hardware info.",
        icon = Icons.Outlined.Lock,
        points = listOf(
            "No advertising ID, ever",
            "Export or delete everything",
            "Hardware-backed result signatures",
        ),
    ),
)

@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    val page = onboardingPages[step]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Dimens.screenPadding),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            BrandMark(34.dp)
            Spacer(Modifier.width(10.dp))
            Text("BenchSuite", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = onFinished) { Text("Skip") }
        }
        Spacer(Modifier.weight(0.7f))

        AnimatedContent(
            targetState = step,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
            label = "onboarding",
        ) { index ->
            val current = onboardingPages[index]
            Column {
                Box(
                    Modifier
                        .size(68.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(current.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.height(Spacing.lg))
                Text(
                    current.eyebrow.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.3.sp,
                )
                Spacer(Modifier.height(8.dp))
                Text(current.title, style = MaterialTheme.typography.displaySmall)
                Spacer(Modifier.height(12.dp))
                Text(
                    current.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(Spacing.lg))
                current.points.forEach { point ->
                    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.CheckCircle, null, tint = BenchTheme.colors.success, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(9.dp))
                        Text(point, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = Spacing.lg)) {
            onboardingPages.indices.forEach { index ->
                Box(
                    Modifier
                        .height(5.dp)
                        .width(if (index == step) 26.dp else 7.dp)
                        .background(
                            if (index == step) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            CircleShape,
                        ),
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm), modifier = Modifier.fillMaxWidth()) {
            if (step > 0) {
                OutlinedButton(
                    onClick = { step-- },
                    modifier = Modifier.height(52.dp),
                ) { Text("Back") }
            }
            Button(
                onClick = {
                    if (step == onboardingPages.lastIndex) onFinished() else step++
                },
                modifier = Modifier.weight(1f).height(52.dp),
            ) {
                Text(if (step == onboardingPages.lastIndex) "Set up my device" else "Continue")
                Spacer(Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(Modifier.height(Spacing.md))
    }
}

/* ----------------------------- Permissions ------------------------- */

private data class PermissionItem(
    val key: String,
    val title: String,
    val body: String,
    val icon: ImageVector,
    val required: Boolean,
)

private val permissionItems = listOf(
    PermissionItem(
        "notifications", "Notifications",
        "Run progress, scheduled health checks and anomaly alerts.",
        Icons.Outlined.Notifications, false,
    ),
    PermissionItem(
        "battery", "Ignore battery optimizations",
        "Keeps scheduled runs reliable. Never used for wake locks outside a run.",
        Icons.Outlined.BatteryChargingFull, false,
    ),
    PermissionItem(
        "usage", "Usage access",
        "Measures app launch consistency. Only package names and timings are read.",
        Icons.Outlined.Smartphone, false,
    ),
    PermissionItem(
        "storage", "Files access for exports",
        "Saves PDF, JSON and CSV reports where you choose. Nothing is uploaded.",
        Icons.Outlined.Storage, false,
    ),
)

@Composable
fun PermissionsScreen(onBack: () -> Unit, onContinue: () -> Unit) {
    var granted by remember { mutableStateOf(setOf<String>()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Spacer(Modifier.height(12.dp))

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.screenPadding),
        ) {
            Box(
                Modifier
                    .size(52.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.Shield, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.height(Spacing.md))
            Text("A few permissions,\nwith clear reasons.", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(10.dp))
            Text(
                "Every permission is optional and can be revoked later. The benchmark works offline without any of them.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(Spacing.lg))

            permissionItems.forEach { item ->
                val isGranted = item.key in granted
                SurfaceCard(modifier = Modifier.padding(bottom = Spacing.xs)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(item.icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(19.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(2.dp))
                            Text(item.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isGranted) {
                            StatusChip("Granted", tint = BenchTheme.colors.success, icon = Icons.Outlined.CheckCircle)
                        } else {
                            StatusChip("Optional", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(
                            onClick = {
                                granted = if (isGranted) granted - item.key else granted + item.key
                            },
                        ) {
                            Text(if (isGranted) "Revoke" else "Allow")
                        }
                    }
                }
            }

            Spacer(Modifier.height(Spacing.sm))
            Text(
                "You can change all of this later in Settings → Privacy and data.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Start,
            )
            Spacer(Modifier.height(Spacing.lg))
        }

        Column(Modifier.padding(horizontal = Dimens.screenPadding, vertical = Spacing.sm)) {
            Button(
                onClick = onContinue,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                Text(if (granted.isEmpty()) "Continue without permissions" else "Continue")
                Spacer(Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, modifier = Modifier.size(18.dp))
            }
            TextButton(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
                Text("Decide later", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/* -------------------------- Hardware detection --------------------- */

private data class ScanRow(val label: String, val value: String, val at: Float, val icon: ImageVector)

private val scanRows = emptyList()

@Composable
fun HardwareDetectionScreen(onBack: () -> Unit, onContinue: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        while (progress < 1f) {
            delay(55)
            progress = (progress + 0.025f).coerceAtMost(1f)
        }
    }

    val done = progress >= 1f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Spacer(Modifier.height(12.dp))

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.screenPadding),
        ) {
            Text(
                "One-time scan".uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(6.dp))
            Text("Mapping your hardware.", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(8.dp))
            Text(
                "This builds the capability map so unsupported tests are skipped with a reason, not a failure.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(Spacing.lg))

            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Outlined.Smartphone, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        val profile = com.benchsuite.app.ui.state.SessionState.currentDevice
                        Text(profile.model, style = MaterialTheme.typography.titleMedium)
                        Text(profile.soc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    StatusChip(if (done) "Ready" else "Scanning", tint = if (done) BenchTheme.colors.success else MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(Spacing.md))
                ProgressLine(progress.titleSafe(), height = 4.dp)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (done) "Capability map complete · 12 of 12 features" else "Reading system properties and Vulkan capabilities…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Spacer(Modifier.height(Spacing.md))
            SurfaceCard {
                Text("Detected components", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(Spacing.xs))
                scanRows.forEach { row ->
                    val visible = progress >= row.at
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            row.icon,
                            null,
                            tint = if (visible) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                            modifier = Modifier.size(17.dp),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            row.label,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (visible) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.weight(1f),
                        )
                        if (visible) {
                            Text(row.value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Text("—", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            }

            Spacer(Modifier.height(Spacing.md))
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Lock, null, tint = BenchTheme.colors.success, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Device fingerprint stays on this device", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(Spacing.lg))
        }

        Column(Modifier.padding(horizontal = Dimens.screenPadding, vertical = Spacing.sm)) {
            Button(
                onClick = onContinue,
                enabled = done,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            ) {
                Text(if (done) "Go to dashboard" else "Scanning…")
                if (done) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(Modifier.height(Spacing.xs))
        }
    }
}

private fun Float.titleSafe(): Float = coerceIn(0f, 1f)
