package com.benchsuite.app.features.core

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.data.model.UseCaseFit
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.components.BandChip
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.CategoryBarRow
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.InsightCard
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.UseCaseRow
import com.benchsuite.app.ui.components.bandColor
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing
import java.util.Locale

@Composable
fun ResultSummaryScreen(runId: String, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val run: RunRecord = SessionState.runById(runId) ?: return
    val isNative = run.methodologyVersion.endsWith("-native")
    val categories = run.categories

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Result summary",
            subtitle = run.startedAt,
            onBack = onBack,
            actions = {
                IconAction(Icons.Outlined.Description, "Open report") { onNavigate(Routes.report(run.id)) }
                IconAction(Icons.Outlined.Share, "Share card") { onNavigate(Routes.SHARE) }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Run complete",
                    title = "Here is the honest picture.",
                    body = "Peak and sustained results, with the conditions that shaped them.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusChip(if (isNative) "Native run" else "Full suite", tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(6.dp))
                        if (run.verified) {
                            StatusChip("Verified", tint = BenchTheme.colors.success, icon = Icons.Outlined.Verified)
                        }
                        Spacer(Modifier.weight(1f))
                        Text(run.methodologyVersion, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        ScoreGauge(
                            score = run.overall,
                            maxScore = 1100,
                            gaugeSize = 210.dp,
                            color = bandColor(run.band),
                            label = "of 1,100",
                            caption = run.band.label,
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(run.deviceModel, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${run.soc} · ${run.durationLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    }
                    Spacer(Modifier.height(Spacing.md))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        StatBlock("Peak", run.peak.toString(), "Best short burst", Modifier.weight(1f))
                        StatBlock("Sustained", run.sustained.toString(), "After 20 minutes", Modifier.weight(1f), BenchTheme.colors.warning)
                        StatBlock("Confidence", "${run.confidence}%", "CV ${run.cvPct}%", Modifier.weight(1f), BenchTheme.colors.success)
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Insights, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("The short version", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (isNative) {
                            "Measured on-device by the native bench-core. ${run.note}. Confidence is ${run.confidence}% with a ${run.cvPct}% coefficient of variation; conditions are recorded below."
                        } else {
                            "गैर-नेटिव रन के लिए वास्तविक विश्लेषण उपलब्ध नहीं है। कृपया नेटिव बेंचमार्क रन पूरा करें।"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (isNative) {
                            StatusChip("${categories.size} components", tint = MaterialTheme.colorScheme.primary)
                            StatusChip("On-device", tint = BenchTheme.colors.success)
                            StatusChip("Unsigned", tint = BenchTheme.colors.warning)
                        } else {
                            StatusChip("Strong CPU", tint = BenchTheme.colors.success)
                            StatusChip("Thermal ceiling", tint = BenchTheme.colors.warning)
                            StatusChip("AI fallback", tint = BenchTheme.colors.danger)
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Use-case verdicts",
                    actionLabel = "All recommendations",
                    onAction = { onNavigate(Routes.RECOMMENDATIONS) },
                )
            }
            item {
                val fits = SessionState.getUseCaseFits(run)
                SurfaceCard {
                    if (fits.isEmpty()) {
                        Text(
                            "No use-case verdicts available for this run yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        fits.forEachIndexed { index, fit ->
                            UseCaseRow(fit)
                            if (index != fits.lastIndex) {
                                Spacer(Modifier.height(Spacing.sm))
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Score breakdown",
                    actionLabel = "Details",
                    onAction = { onNavigate(Routes.resultDetail(run.id)) },
                )
            }
            item {
                SurfaceCard {
                    categories.forEachIndexed { index, category ->
                        CategoryBarRow(category)
                        if (index != categories.lastIndex) Spacer(Modifier.height(Spacing.sm))
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Text(
                        "Weighted geometric mean · one weak category cannot be hidden by a strong one",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                SectionHeader(
                    title = "What stands out",
                    actionLabel = "Insights",
                    onAction = { onNavigate(Routes.INSIGHTS) },
                )
            }
            val dynamicInsights = SessionState.getInsights(run)
            if (dynamicInsights.isEmpty()) {
                item {
                    SurfaceCard {
                        Text(
                            "No insights generated for this run yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                items(dynamicInsights.size.coerceAtMost(3)) { index ->
                    InsightCard(dynamicInsights[index], onClick = { onNavigate(Routes.INSIGHTS) })
                }
            }

            item {
                SectionHeader(title = "Recorded conditions")
            }
            item {
                SurfaceCard {
                    InfoRow("Battery", "${run.conditions.batteryPct}% · ${if (run.conditions.charging) "charging" else "unplugged"}")
                    InfoRow("Battery temperature", String.format(Locale.US, "%.1f °C", run.conditions.batteryTempC))
                    InfoRow("Ambient", String.format(Locale.US, "%.1f °C", run.conditions.ambientC))
                    InfoRow("Background load", "${run.conditions.backgroundLoadPct}%")
                    InfoRow("Thermal status", run.conditions.thermalStatus)
                    InfoRow("Free storage", String.format(Locale.US, "%.1f GB", run.conditions.freeStorageGb))
                    InfoRow("Power mode", run.conditions.powerMode)
                    InfoRow("Methodology", run.methodologyVersion)
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = { onNavigate(Routes.resultDetail(run.id)) },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Text("Full detail")
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, modifier = Modifier.size(17.dp))
                    }
                    OutlinedButton(
                        onClick = { onNavigate(Routes.SHARE) },
                        modifier = Modifier.height(50.dp),
                    ) {
                        Icon(Icons.Outlined.Share, null, modifier = Modifier.size(17.dp))
                    }
                }
            }

            item {
                TextButton(
                    onClick = { onNavigate(Routes.INSIGHTS) },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("Explain this result with AI insights")
                }
            }

            item {
                Text(
                    "Signed with a hardware-backed key · verified locally · methodology ${run.methodologyVersion}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun StatBlock(
    label: String,
    value: String,
    caption: String,
    modifier: Modifier = Modifier,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.primary,
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = NumericSmall.copy(fontSize = 22.sp), color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(caption, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), maxLines = 1)
    }
}
