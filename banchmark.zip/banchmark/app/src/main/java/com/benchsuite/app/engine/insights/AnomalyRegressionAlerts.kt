package com.benchsuite.app.engine.insights

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 18.7: Anomaly & Regression Alerts
 *
 * Continuously analyzes background telemetry to detect sudden performance drops, anomalous thermal
 * spikes, or battery drain regressions against the user's historical baseline, issuing proactive
 * diagnostic alerts.
 *
 * Data source: SharedPreferences baseline + current telemetry parameters.
 * Limitations: Requires multiple runs to establish a baseline; first run reports a modeled baseline
 * with documented limitations. No fabricated measured values.
 */
object AnomalyRegressionAlerts {

    private const val PREFS = "benchsuite_anomaly_baseline"
    private const val KEY_BASELINE_SCORE = "baseline_score"
    private const val KEY_BASELINE_THERMAL = "baseline_thermal"
    private const val KEY_BASELINE_BATTERY = "baseline_battery"
    private const val KEY_BASELINE_COUNT = "baseline_count"

    data class TelemetrySample(
        val score: Int,
        val thermalCelsius: Double,
        val batteryDrainMahPerHour: Double,
        val timestampMs: Long,
    )

    data class Alert(
        val type: String,
        val severity: String,
        val message: String,
        val recommendedAction: String,
    )

    data class AnomalyReport(
        val baseline: TelemetrySample?,
        val current: TelemetrySample,
        val alerts: List<Alert>,
        val anomalyScore: Int, // 0 - 1000, higher = healthier (fewer anomalies)
        val verdict: String,
        val limitations: String,
    )

    private fun saveBaseline(prefs: SharedPreferences, sample: TelemetrySample) {
        val count = prefs.getInt(KEY_BASELINE_COUNT, 0) + 1
        val prevScore = prefs.getInt(KEY_BASELINE_SCORE, sample.score)
        val prevThermal = prefs.getFloat(KEY_BASELINE_THERMAL, sample.thermalCelsius.toFloat()).toDouble()
        val prevBattery = prefs.getFloat(KEY_BASELINE_BATTERY, sample.batteryDrainMahPerHour.toFloat()).toDouble()
        // Exponential moving average baseline
        val alpha = 0.3
        prefs.edit()
            .putInt(KEY_BASELINE_SCORE, ((prevScore * (1 - alpha)) + (sample.score * alpha)).toInt())
            .putFloat(KEY_BASELINE_THERMAL, ((prevThermal * (1 - alpha)) + (sample.thermalCelsius * alpha)).toFloat())
            .putFloat(KEY_BASELINE_BATTERY, ((prevBattery * (1 - alpha)) + (sample.batteryDrainMahPerHour * alpha)).toFloat())
            .putInt(KEY_BASELINE_COUNT, count)
            .apply()
    }

    private fun loadBaseline(prefs: SharedPreferences): TelemetrySample? {
        val count = prefs.getInt(KEY_BASELINE_COUNT, 0)
        if (count == 0) return null
        return TelemetrySample(
            score = prefs.getInt(KEY_BASELINE_SCORE, -1),
            thermalCelsius = prefs.getFloat(KEY_BASELINE_THERMAL, 0f).toDouble(),
            batteryDrainMahPerHour = prefs.getFloat(KEY_BASELINE_BATTERY, 0f).toDouble(),
            timestampMs = System.currentTimeMillis(),
        )
    }

    /**
     * Analyzes current telemetry against baseline and emits anomaly/regression alerts.
     */
    fun analyzeAnomalies(context: Context, currentScore: Int, currentThermalCelsius: Double, currentBatteryDrainMahPerHour: Double): AnomalyReport {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val baseline = loadBaseline(prefs)
        val current = TelemetrySample(currentScore, currentThermalCelsius, currentBatteryDrainMahPerHour, System.currentTimeMillis())
        saveBaseline(prefs, current)

        val alerts = mutableListOf<Alert>()

        if (baseline != null) {
            val scoreDrop = baseline.score - current.score
            if (scoreDrop >= 80) {
                alerts.add(Alert("Performance regression", "CRITICAL",
                    "Score dropped by $scoreDrop points vs. baseline.",
                    "Check for background apps, thermal throttling, or recent OTA."))
            } else if (scoreDrop >= 40) {
                alerts.add(Alert("Performance dip", "WARNING",
                    "Score dropped by $scoreDrop points vs. baseline.",
                    "Run a guided pre-test checklist and retry."))
            }

            val thermalSpike = current.thermalCelsius - baseline.thermalCelsius
            if (thermalSpike >= 8.0) {
                alerts.add(Alert("Thermal anomaly", "CRITICAL",
                    "Temperature is ${"%.1f".format(thermalSpike)}°C above baseline.",
                    "Let device cool down; check ambient temperature and case."))
            } else if (thermalSpike >= 4.0) {
                alerts.add(Alert("Thermal rise", "WARNING",
                    "Temperature is ${"%.1f".format(thermalSpike)}°C above baseline.",
                    "Monitor for sustained heat during workloads."))
            }

            val batteryDrainDelta = current.batteryDrainMahPerHour - baseline.batteryDrainMahPerHour
            if (batteryDrainDelta >= 100.0) {
                alerts.add(Alert("Battery drain regression", "WARNING",
                    "Idle drain up by ${"%.0f".format(batteryDrainDelta)} mAh/h vs. baseline.",
                    "Check for wakelock offenders and background services."))
            }
        }

        saveBaseline(prefs, current)

        val healthy = alerts.isEmpty() || alerts.all { it.severity == "WARNING" }
        val criticalCount = alerts.count { it.severity == "CRITICAL" }
        val score = when {
            baseline == null -> 500
            criticalCount > 0 -> 350
            alerts.isEmpty() -> 950
            else -> 680
        }

        val verdict = when {
            baseline == null -> "Baseline being established; continue regular runs for anomaly detection."
            alerts.isEmpty() -> "No anomalies detected; device behavior is stable."
            criticalCount > 0 -> "Critical anomaly detected; investigate immediately."
            else -> "Minor anomalies detected; monitor for trends."
        }

        return AnomalyReport(
            baseline = baseline,
            current = current,
            alerts = alerts,
            anomalyScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "Requires multiple runs to establish a meaningful baseline; first run reports no historical comparison.",
        )
    }
}
