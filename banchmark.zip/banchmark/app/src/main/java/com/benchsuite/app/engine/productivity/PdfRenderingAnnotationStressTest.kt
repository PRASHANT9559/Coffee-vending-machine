package com.benchsuite.app.engine.productivity

import com.benchsuite.app.util.*

import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 13.4: PDF Rendering & Annotation Stress Test
 *
 * Open, render, and annotate 100MB+ PDFs with complex vector graphics. Professionals use tablets
 * for document review; rendering speed varies.
 *
 * Data source: synthetic PDF page render model per page count and complexity.
 * Limitations: No real PDF file or rendering engine; render times modeled per page, not
 * fabricated measured values.
 */
object PdfRenderingAnnotationStressTest {

    data class PdfResult(
        val pages: Int,
        val fileSizeMb: Double,
        val renderTimeMs: Double,
        val pagesPerSec: Double,
        val annotationLatencyMs: Double,
    )

    data class PdfReport(
        val results: List<PdfResult>,
        val averagePagesPerSec: Double,
        val pdfScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun deviceTier(): String {
        val hw = Build.HARDWARE.lowercase()
        return when {
            hw.contains("sm8") -> "Flagship"
            hw.contains("sm7") -> "Upper-midrange"
            hw.contains("sm6") -> "Mainstream"
            else -> "Entry-level"
        }
    }

    /**
     * Stresses PDF rendering and annotation across document sizes.
     */
    fun runPdfStressTest(): PdfReport {
        val tier = deviceTier()
        val tierFactor = when (tier) {
            "Flagship" -> 0.7
            "Upper-midrange" -> 1.0
            "Mainstream" -> 1.6
            else -> 2.4
        }

        val results = listOf(
            Triple(50, 10.0),
            Triple(100, 30.0),
            Triple(200, 100.0),
        ).map { (pages, sizeMb) ->
            val baseMsPerPage = 150.0 * tierFactor
            val renderMs = pages * baseMsPerPage
            PdfResult(pages, sizeMb, (renderMs * 10.0).roundToInt() / 10.0,
                (pages.toDouble() / max(renderMs, 1.0) * 1000.0 * 100.0).roundToInt() / 100.0,
                (baseMsPerPage * 0.3 * 100.0).roundToInt() / 100.0)
        }

        val avgPagesPerSec = results.averageOf { it.pagesPerSec }
        val score = when {
            avgPagesPerSec >= 1.5 -> 900
            avgPagesPerSec >= 0.8 -> 740
            avgPagesPerSec >= 0.4 -> 580
            else -> 400
        }

        val verdict = when {
            avgPagesPerSec >= 1.5 -> "Fast PDF rendering; large documents open smoothly."
            avgPagesPerSec >= 0.8 -> "Acceptable PDF rendering for document review."
            else -> "Slow PDF rendering; large documents lag on page turns."
        }

        return PdfReport(
            results = results,
            averagePagesPerSec = (avgPagesPerSec * 100.0).roundToInt() / 100.0,
            pdfScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real PDF file or rendering engine; times modeled per page count and device tier.",
        )
    }
}
