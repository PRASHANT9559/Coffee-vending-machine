package com.benchsuite.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.model.ActiveRun
import com.benchsuite.app.data.model.Badge
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.CategorySpec
import com.benchsuite.app.data.model.CheckStatus
import com.benchsuite.app.data.model.EnvironmentCheck
import com.benchsuite.app.data.model.HistoryPoint
import com.benchsuite.app.data.model.Insight
import com.benchsuite.app.data.model.LeaderboardEntry
import com.benchsuite.app.data.model.Recommendation
import com.benchsuite.app.data.model.ReportItem
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.data.model.TestAvailability
import com.benchsuite.app.data.model.TestDefinition
import com.benchsuite.app.data.model.UseCaseFit
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

/* ----------------------------- Chart card -------------------------- */

@Composable
fun ChartCard(
    title: String,
    caption: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    SurfaceCard(modifier = modifier) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        if (caption != null) {
            Spacer(Modifier.height(4.dp))
            Text(
                caption,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(Spacing.sm))
        content()
    }
}

/* --------------------------- Score summary ------------------------- */

@Composable
fun RunScoreCard(
    run: RunRecord,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    SurfaceCard(modifier = modifier, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScoreGauge(
                score = run.overall,
                maxScore = 1100,
                gaugeSize = 148.dp,
                color = bandColor(run.band),
                label = "of 1,100",
                caption = run.band.label,
            )
            Spacer(Modifier.width(Spacing.md))
            Column(Modifier.weight(1f)) {
                Text("Overall score", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = run.deviceModel,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(Spacing.sm))
                MiniStat("Peak", run.peak.toString(), MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(6.dp))
                MiniStat("Sustained", run.sustained.toString(), BenchTheme.colors.warning)
                Spacer(Modifier.height(6.dp))
                MiniStat("Confidence", "${run.confidence}%", BenchTheme.colors.success)
            }
        }
        Spacer(Modifier.height(Spacing.sm))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "${run.startedAt} · ${run.durationLabel}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (run.verified) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Verified, null, tint = BenchTheme.colors.success, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(3.dp))
                    Text("Verified", style = MaterialTheme.typography.labelSmall, color = BenchTheme.colors.success)
                }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).background(color, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, style = NumericSmall)
    }
}

@Composable
fun ScoreBadge(score: Int, maxScore: Int = 1100, size: androidx.compose.ui.unit.Dp = 48.dp) {
    val color = bandColor(com.benchsuite.app.data.model.bandFor(score))
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 3.dp.toPx()
            val inset = stroke
            drawArc(
                color = color.copy(alpha = 0.15f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(this.size.width - inset * 2, this.size.height - inset * 2),
                style = Stroke(stroke),
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * (score.toFloat() / maxScore).coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(this.size.width - inset * 2, this.size.height - inset * 2),
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Text(score.toString(), style = NumericSmall.copy(fontSize = 14.sp), color = MaterialTheme.colorScheme.onSurface)
    }
}

/* --------------------------- Category tile ------------------------- */

@Composable
fun CategoryTile(
    spec: CategorySpec,
    modifier: Modifier = Modifier,
    realScore: CategoryScore? = null,
    onClick: () -> Unit,
) {
    SurfaceCard(modifier = modifier, onClick = onClick, contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(iconFor(spec.icon), contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
            }
            Spacer(Modifier.weight(1f))
            if (realScore != null) {
                Text(
                    text = realScore.score.toString(),
                    style = NumericSmall.copy(fontSize = 17.sp),
                    color = bandColor(realScore.band),
                )
            } else {
                Text(
                    text = "—",
                    style = NumericSmall.copy(fontSize = 17.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(spec.shortTitle, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(2.dp))
        Text(
            text = if (realScore != null) "${realScore.sustained} sustained" else "Not measured yet",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (realScore != null) {
                Box(Modifier.size(5.dp).background(bandColor(realScore.band), CircleShape))
                Spacer(Modifier.width(5.dp))
                Text(realScore.band.label, style = MaterialTheme.typography.labelSmall, color = bandColor(realScore.band))
            } else {
                Box(Modifier.size(5.dp).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), CircleShape))
                Spacer(Modifier.width(5.dp))
                Text("No run recorded", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/* ------------------------------ Insight ---------------------------- */

@Composable
fun InsightCard(insight: Insight, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val color = severityColor(insight.severity)
    SurfaceCardAccent(accent = color, modifier = modifier, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(severityIcon(insight.severity), contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                text = insight.tag.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = color,
            )
            Spacer(Modifier.weight(1f))
            if (onClick != null) {
                Icon(
                    Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(insight.title, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(4.dp))
        Text(
            insight.body,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            insight.evidence,
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
        )
    }
}

/* --------------------------- Recommendation ------------------------ */

@Composable
fun RecommendationCard(rec: Recommendation, modifier: Modifier = Modifier, onAction: () -> Unit) {
    SurfaceCard(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Tag(rec.area.label, MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.weight(1f))
            Text("Impact ${rec.impact}", style = MaterialTheme.typography.labelSmall, color = BenchTheme.colors.success)
        }
        Spacer(Modifier.height(8.dp))
        Text(rec.title, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(4.dp))
        Text(rec.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Effort ${rec.effort}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onAction) { Text(rec.action, style = MaterialTheme.typography.labelMedium) }
        }
    }
}

/* ------------------------------ Test row --------------------------- */

@Composable
fun TestRow(
    test: TestDefinition,
    modifier: Modifier = Modifier,
    onRun: (() -> Unit)? = null,
) {
    val statusColor = when (test.availability) {
        TestAvailability.READY -> BenchTheme.colors.success
        TestAvailability.LIMITED -> BenchTheme.colors.warning
        TestAvailability.UNAVAILABLE -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    SurfaceCard(modifier = modifier, contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(statusColor, CircleShape))
            Spacer(Modifier.width(8.dp))
            Text(
                test.name,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (onRun != null && test.availability != TestAvailability.UNAVAILABLE) {
                IconButton(onClick = onRun, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = "Run ${test.name}", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            test.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Tag("${test.minutes} min")
            Tag(test.difficulty, if (test.difficulty == "Hard") BenchTheme.colors.danger else MaterialTheme.colorScheme.onSurfaceVariant)
            Tag("★ ${test.innovation}")
            if (test.availability != TestAvailability.READY) {
                Text(test.availabilityNote, style = MaterialTheme.typography.labelSmall, color = statusColor, maxLines = 1)
            }
        }
    }
}

/* ----------------------------- Use case ---------------------------- */

@Composable
fun UseCaseRow(fit: UseCaseFit, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(iconFor(fit.icon), contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(fit.name, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(fit.score.toString(), style = NumericSmall, color = bandColor(fit.band))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(5.dp).background(bandColor(fit.band), CircleShape))
            Spacer(Modifier.width(4.dp))
            Text(fit.band.label, style = MaterialTheme.typography.labelSmall, color = bandColor(fit.band))
        }
        Spacer(Modifier.height(5.dp))
        ProgressLine(fit.score / 1100f, color = bandColor(fit.band), height = 5.dp)
        Spacer(Modifier.height(4.dp))
        Text(fit.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/* ---------------------------- Checklist ---------------------------- */

@Composable
fun ChecklistRow(check: EnvironmentCheck, modifier: Modifier = Modifier, onAction: (() -> Unit)? = null) {
    val color = checkColor(check.status)
    Row(
        modifier = modifier.fillMaxWidth().padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (check.status == CheckStatus.PASS) Icons.Outlined.CheckCircle else Icons.Outlined.Warning,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(check.title, style = MaterialTheme.typography.bodyMedium)
            Text(check.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (onAction != null) {
            TextButton(onClick = onAction) { Text("Fix") }
        } else {
            StatusChip(
                text = when (check.status) {
                    CheckStatus.PASS -> "Pass"
                    CheckStatus.WARN -> "Check"
                    CheckStatus.FAIL -> "Blocked"
                },
                tint = color,
            )
        }
    }
}

/* ---------------------------- Run banner --------------------------- */

@Composable
fun RunBanner(run: ActiveRun, modifier: Modifier = Modifier, onClick: () -> Unit, onStop: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "live")
    val pulse by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(850), RepeatMode.Reverse),
        label = "pulse",
    )
    Card(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, BenchTheme.colors.outlineSubtle),
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(8.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = pulse), CircleShape))
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(run.title, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                    Text(
                        text = if (run.paused) "Paused · ${run.remainingLabel}" else "${run.completedTests}/${run.totalTests} tests · ${run.remainingLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text("${(run.progress * 100).toInt()}%", style = NumericSmall, color = MaterialTheme.colorScheme.primary)
                IconButton(onClick = onStop, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Outlined.Stop, contentDescription = "Stop run", tint = BenchTheme.colors.danger, modifier = Modifier.size(18.dp))
                }
            }
            ProgressLine(run.progress, height = 2.dp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

/* ---------------------------- History row -------------------------- */

@Composable
fun HistoryRunRow(run: RunRecord, modifier: Modifier = Modifier, onClick: () -> Unit) {
    SurfaceCard(modifier = modifier, onClick = onClick, contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(run.startedAt, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(2.dp))
                Text(
                    "${run.durationLabel} · ${run.categories.size - 1} categories",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(run.overall.toString(), style = NumericSmall.copy(fontSize = 20.sp), color = bandColor(run.band))
                Text(run.band.label, style = MaterialTheme.typography.labelSmall, color = bandColor(run.band))
            }
            Spacer(Modifier.width(8.dp))
            Icon(
                Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

/* ----------------------------- Report row -------------------------- */

@Composable
fun ReportRow(report: ReportItem, modifier: Modifier = Modifier, onClick: () -> Unit, onShare: () -> Unit) {
    SurfaceCard(modifier = modifier, onClick = onClick, contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text(report.pages.toString(), style = NumericSmall, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(report.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                Text(report.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Tag(report.type.label)
                    Tag(report.date)
                    Tag(report.sizeLabel)
                }
            }
            IconButton(onClick = onShare, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Outlined.Share, contentDescription = "Share report", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
        }
    }
}

/* --------------------------- Leaderboard row ----------------------- */

@Composable
fun LeaderboardRow(entry: LeaderboardEntry, modifier: Modifier = Modifier) {
    val mineColor = MaterialTheme.colorScheme.primary
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                if (entry.isMine) mineColor.copy(alpha = 0.07f) else Color.Transparent,
                RoundedCornerShape(10.dp),
            )
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "#${entry.rank}",
            style = NumericSmall,
            color = if (entry.rank <= 3) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(32.dp),
        )
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(entry.model, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (entry.verified) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Outlined.Verified, contentDescription = "Verified", tint = BenchTheme.colors.success, modifier = Modifier.size(13.dp))
                }
            }
            Text(entry.soc, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
        Text(entry.region, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(10.dp))
        Text(entry.score.toString(), style = NumericSmall, color = bandColor(com.benchsuite.app.data.model.bandFor(entry.score)))
    }
}

/* ------------------------------ Badge ------------------------------ */

@Composable
fun BadgeTile(badge: Badge, modifier: Modifier = Modifier) {
    SurfaceCard(modifier = modifier, contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(34.dp)
                    .background(
                        if (badge.unlocked) MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
                        CircleShape,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                if (badge.unlocked) {
                    Icon(iconFor(badge.icon), contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                } else {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(15.dp))
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    badge.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (badge.unlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
                Text(
                    badge.description,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/* ----------------------------- Shortcut ---------------------------- */

@Composable
fun ShortcutRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(
            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
    }
}

/* --------------------------- Trend strip --------------------------- */

@Composable
fun TrendStrip(points: List<HistoryPoint>, modifier: Modifier = Modifier) {
    if (points.isEmpty()) {
        Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("No run history yet", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    val values = points.map { it.score.toFloat() }
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text("Last ${points.size} runs", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(points.last().score.toString(), style = NumericDisplay.copy(fontSize = 28.sp))
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "+${points.last().score - points.first().score} since Sep",
                    style = MaterialTheme.typography.labelSmall,
                    color = BenchTheme.colors.success,
                    modifier = Modifier.padding(bottom = 4.dp),
                )
            }
        }
        Sparkline(values, Modifier.width(120.dp).height(46.dp), color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun EmptyCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
) {
    SurfaceCard {
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(6.dp))
            Text(title, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}
