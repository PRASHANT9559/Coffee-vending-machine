package com.benchsuite.app.engine.stability

import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Feature 12.6: Frame Pacing Consistency Analyzer.
 *
 * Evaluates frame time smoothness and display delivery cadence:
 * - Frame time statistical distribution (mean, standard deviation, percentiles: p50, p90, p95, p99, p99.9)
 * - 1% Low and 0.1% Low Effective Frame Rates
 * - Jank Frame Classification (>8.33ms, >16.67ms, and >33.33ms presentation hitches)
 * - Shannon Frame Pacing Entropy Score (0–100 metric quantifying cadence regularity)
 * - Frame duration histogram binning for Compose canvas charts
 */
object FramePacingAnalyzer {

    data class HistogramBucket(
        val label: String,
        val minMs: Double,
        val maxMs: Double,
        val count: Int,
        val percentage: Double,
    )

    data class FramePacingReport(
        val totalFrames: Int,
        val targetFps: Int, // e.g. 60, 90, 120
        val targetFrameTimeMs: Double,
        val meanFrameTimeMs: Double,
        val medianFrameTimeMs: Double,
        val stdDevJitterMs: Double,
        val p90Ms: Double,
        val p95Ms: Double,
        val p99Ms: Double,
        val p99_9Ms: Double,
        val effectiveAverageFps: Double,
        val fps1PercentLow: Double,
        val fps0_1PercentLow: Double,
        val jankCount8ms: Int, // Frame missed 120Hz cadence (>12.5ms)
        val jankCount16ms: Int, // Frame missed 60Hz cadence (>25.0ms)
        val severeStutterCount33ms: Int, // Major hitch (>33.3ms)
        val jankPercentage: Double,
        val pacingEntropyScore: Int, // 0 - 100 (100 = perfectly uniform pacing)
        val histogram: List<HistogramBucket>,
        val verdict: String,
    )

    /**
     * Analyzes raw [frameDurationsMs] against a designated [targetRefreshHz] (e.g. 60, 90, 120).
     */
    fun analyze(
        frameDurationsMs: List<Double>,
        targetRefreshHz: Int = 120,
    ): FramePacingReport {
        if (frameDurationsMs.isEmpty()) {
            return emptyReport(targetRefreshHz)
        }

        val total = frameDurationsMs.size
        val sorted = frameDurationsMs.sorted()
        val targetMs = 1000.0 / targetRefreshHz

        val mean = frameDurationsMs.average()
        val variance = frameDurationsMs.map { (it - mean).pow(2) }.sum() / total
        val stdDev = sqrt(variance)

        // Percentiles
        val p50 = percentile(sorted, 50.0)
        val p90 = percentile(sorted, 90.0)
        val p95 = percentile(sorted, 95.0)
        val p99 = percentile(sorted, 99.0)
        val p99_9 = percentile(sorted, 99.9)

        // Effective FPS conversions
        val effAvgFps = if (mean > 0) 1000.0 / mean else 0.0
        val fps1Low = if (p99 > 0) 1000.0 / p99 else 0.0
        val fps0_1Low = if (p99_9 > 0) 1000.0 / p99_9 else 0.0

        // Jank counting
        val jank8ms = frameDurationsMs.count { it > 12.5 }
        val jank16ms = frameDurationsMs.count { it > 25.0 }
        val severeStutters = frameDurationsMs.count { it > 33.33 }

        val thresholdJank = if (targetRefreshHz >= 90) jank8ms else jank16ms
        val jankPct = (thresholdJank.toDouble() / total * 1000.0).roundToInt() / 10.0

        // Shannon Frame Pacing Entropy Score (0 - 100)
        val entropyScore = computeEntropyScore(frameDurationsMs, targetMs)

        // Histogram bucketing
        val histogram = buildHistogram(frameDurationsMs)

        val verdict = when {
            entropyScore >= 90 && jankPct <= 1.0 -> "Flawless Frame Pacing. Microsecond-level presentation cadence with virtually zero perceptible stutter."
            entropyScore >= 75 && jankPct <= 4.0 -> "Smooth Presentation. Minor frame time variances; 1% lows held at ${(fps1Low * 10).roundToInt() / 10.0} FPS."
            entropyScore >= 55 -> "Noticeable Jitter. Intermittent frame spikes ($jank16ms frames dropped >25ms); occasional micro-stutter observed."
            else -> "Erratic Frame Delivery. Pacing entropy is degraded ($entropyScore/100) with $severeStutters major stutter events."
        }

        return FramePacingReport(
            totalFrames = total,
            targetFps = targetRefreshHz,
            targetFrameTimeMs = (targetMs * 100.0).roundToInt() / 100.0,
            meanFrameTimeMs = (mean * 100.0).roundToInt() / 100.0,
            medianFrameTimeMs = (p50 * 100.0).roundToInt() / 100.0,
            stdDevJitterMs = (stdDev * 100.0).roundToInt() / 100.0,
            p90Ms = (p90 * 100.0).roundToInt() / 100.0,
            p95Ms = (p95 * 100.0).roundToInt() / 100.0,
            p99Ms = (p99 * 100.0).roundToInt() / 100.0,
            p99_9Ms = (p99_9 * 100.0).roundToInt() / 100.0,
            effectiveAverageFps = (effAvgFps * 10.0).roundToInt() / 10.0,
            fps1PercentLow = (fps1Low * 10.0).roundToInt() / 10.0,
            fps0_1PercentLow = (fps0_1Low * 10.0).roundToInt() / 10.0,
            jankCount8ms = jank8ms,
            jankCount16ms = jank16ms,
            severeStutterCount33ms = severeStutters,
            jankPercentage = jankPct,
            pacingEntropyScore = entropyScore,
            histogram = histogram,
            verdict = verdict,
        )
    }

    /**
     * Converts a stream of raw nanosecond presentation timestamps into frame durations in ms.
     */
    fun fromTimestampsNanos(timestampsNs: List<Long>, targetRefreshHz: Int = 120): FramePacingReport {
        if (timestampsNs.size < 2) return emptyReport(targetRefreshHz)
        val durations = mutableListOf<Double>()
        for (i in 1 until timestampsNs.size) {
            val deltaNs = timestampsNs[i] - timestampsNs[i - 1]
            durations.add(deltaNs / 1_000_000.0)
        }
        return analyze(durations, targetRefreshHz)
    }

    /**
     * Computes the normalized Shannon Entropy of inter-frame variations.
     * Uniform distribution concentrated around targetMs yields ~100.
     * Wide, chaotic dispersion across many bins yields low scores.
     */
    private fun computeEntropyScore(durations: List<Double>, targetMs: Double): Int {
        if (durations.size < 5) return 85

        // Bin deviations from target into 2ms bins [-10ms .. +20ms]
        val binCount = 16
        val binWidth = 2.0
        val counts = IntArray(binCount)
        var totalBinned = 0

        for (d in durations) {
            val delta = d - targetMs
            val binIdx = ((delta + 8.0) / binWidth).toInt().coerceIn(0, binCount - 1)
            counts[binIdx]++
            totalBinned++
        }

        var shannon = 0.0
        for (c in counts) {
            if (c > 0) {
                val p = c.toDouble() / totalBinned
                shannon -= p * (ln(p) / ln(2.0))
            }
        }

        // Theoretical maximum entropy: log2(binCount) = 4.0
        // A single spike has entropy 0. High entropy of deviations means chaos.
        // We invert: low deviation entropy = high pacing score.
        val maxEntropy = ln(binCount.toDouble()) / ln(2.0)
        val normalizedChaos = (shannon / maxEntropy).coerceIn(0.0, 1.0)

        // Also factor in standard deviation directly
        val mean = durations.average()
        val stdDev = sqrt(durations.map { (it - mean).pow(2) }.sum() / durations.size)
        val stdPenalty = (stdDev / targetMs * 30.0).coerceIn(0.0, 50.0)

        val score = (100.0 - (normalizedChaos * 45.0) - stdPenalty).roundToInt().coerceIn(10, 100)
        return score
    }

    private fun buildHistogram(durations: List<Double>): List<HistogramBucket> {
        val total = durations.size
        val definitions = listOf(
            Triple("< 8.3 ms", 0.0, 8.33),
            Triple("8.3–12.5 ms", 8.33, 12.5),
            Triple("12.5–16.7 ms", 12.5, 16.67),
            Triple("16.7–25 ms", 16.67, 25.0),
            Triple("25–33.3 ms", 25.0, 33.33),
            Triple("33.3–50 ms", 33.33, 50.0),
            Triple("> 50 ms", 50.0, Double.MAX_VALUE),
        )

        return definitions.map { (label, minVal, maxVal) ->
            val count = durations.count { it >= minVal && it < maxVal }
            val pct = (count.toDouble() / total * 1000.0).roundToInt() / 10.0
            HistogramBucket(
                label = label,
                minMs = minVal,
                maxMs = if (maxVal == Double.MAX_VALUE) 100.0 else maxVal,
                count = count,
                percentage = pct,
            )
        }
    }

    private fun percentile(sorted: List<Double>, p: Double): Double {
        if (sorted.isEmpty()) return 0.0
        val pos = (p / 100.0 * (sorted.size - 1))
        val lower = pos.toInt()
        val frac = pos - lower
        return if (lower + 1 < sorted.size) {
            sorted[lower] + frac * (sorted[lower + 1] - sorted[lower])
        } else {
            sorted[lower]
        }
    }

    private fun emptyReport(targetRefreshHz: Int) = FramePacingReport(
        totalFrames = 0,
        targetFps = targetRefreshHz,
        targetFrameTimeMs = 1000.0 / targetRefreshHz,
        meanFrameTimeMs = 0.0,
        medianFrameTimeMs = 0.0,
        stdDevJitterMs = 0.0,
        p90Ms = 0.0,
        p95Ms = 0.0,
        p99Ms = 0.0,
        p99_9Ms = 0.0,
        effectiveAverageFps = 0.0,
        fps1PercentLow = 0.0,
        fps0_1PercentLow = 0.0,
        jankCount8ms = 0,
        jankCount16ms = 0,
        severeStutterCount33ms = 0,
        jankPercentage = 0.0,
        pacingEntropyScore = 100,
        histogram = emptyList(),
        verdict = "No frame presentation samples recorded.",
    )
}
