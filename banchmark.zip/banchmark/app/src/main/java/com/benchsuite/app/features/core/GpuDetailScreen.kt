package com.benchsuite.app.features.core

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import androidx.compose.material.icons.Icons
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.FrameTimeHistogram
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.MetricPill
import com.benchsuite.app.ui.components.RadarChart
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.LaunchedEffect
import kotlin.math.roundToInt

/**
 * GPU domain detail screen — covers VRS efficiency, shader stutter,
 * frequency residency, memory compression and fillrate bandwidth.
 */
@Composable
fun GpuDetailScreen(
    subFeature: String, // "vrs" | "stutter" | "frequency" | "compression" | "fillrate"
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    var vrsReport by remember { mutableStateOf<VrsReport?>(null) }
    var stutterReport by remember { mutableStateOf<StutterReport?>(null) }
    var freqReport by remember { mutableStateOf<FreqReport?>(null) }
    var compressReport by remember { mutableStateOf<CompressReport?>(null) }
    var fillrateReport by remember { mutableStateOf<FillrateReport?>(null) }

    data class VrsReport(val score: Int, val fpsGain: Double, val qualityLoss: Double, val verdict: String)
    data class StutterReport(val score: Int, val maxStall: Double, val ratio: Double, val verdict: String)
    data class FreqReport(val score: Int, val currentMhz: Int, val maxMhz: Int, val residency: Double, val verdict: String)
    data class CompressReport(val score: Int, val ratio: Double, val verdict: String)
    data class FillrateReport(val score: Int, val ropMpx: Double, val texMtpix: Double, val bottleneck: String, val verdict: String)

    fun runFeature() {
        isLoading = true
        error = null
        val ctx = SessionState.applicationContext
        if (ctx == null) { error = "Context unavailable"; isLoading = false; return }
        scope.launch(Dispatchers.Default) {
            try {
                when (subFeature) {
                    "vrs" -> {
                        val r = SessionState.runGpuVrs()
                        vrsReport = VrsReport(r.efficiencyScore, r.averageFpsGainPct, r.averageQualityLossPct, r.verdict)
                    }
                    "stutter" -> {
                        val r = SessionState.runGpuShaderStutter()
                        stutterReport = StutterReport(r.stutterScore, r.maxStallMs, r.averageColdToWarmRatio, r.verdict)
                    }
                    "frequency" -> {
                        val r = SessionState.runGpuFrequency()
                        freqReport = FreqReport(r.residencyScore, r.currentFrequencyMhz, r.maxFrequencyMhz, r.peakResidencyPct, r.verdict)
                    }
                    "compression" -> {
                        val r = SessionState.runGpuMemoryCompression()
                        compressReport = CompressReport(r.compressionScore, r.averageCompressionRatio, r.verdict)
                    }
                    "fillrate" -> {
                        val r = SessionState.runGpuFillrate()
                        fillrateReport = FillrateReport(r.fillrateScore, r.ropFillrateMpxPerSec, r.textureRateMtpixPerSec, r.limitingResource, r.verdict)
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "GPU feature error"
            } finally {
                isLoading = false
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(subFeature) { runFeature() }

    val title = when (subFeature) {
        "vrs" -> "VRS Efficiency Benchmark"
        "stutter" -> "Shader Compilation Stutter Profiler"
        "frequency" -> "GPU Frequency Residency Tracker"
        "compression" -> "GPU Memory Compression Tester"
        "fillrate" -> "Fillrate & Texture Bandwidth Analyzer"
        else -> "GPU Feature"
    }

    Column(Modifier.fillMaxSize()) {
        BenchTopBar(title = title, onBack = onBack)

        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            if (isLoading && vrsReport == null && stutterReport == null && freqReport == null && compressReport == null && fillrateReport == null) {
                androidx.compose.material3.CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            } else if (error != null) {
                Column(
                    modifier = Modifier.padding(32.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Default.ErrorOutline, null, tint = MaterialTheme.colorScheme.error, Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Error: $error", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { runFeature() }) { Text("Retry") }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = Dimens.screenPadding, end = Dimens.screenPadding, top = 4.dp, bottom = 28.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(Spacing.md),
                ) {
                    item {
                        val score = when {
                            subFeature == "vrs" -> vrsReport?.score ?: 0
                            subFeature == "stutter" -> stutterReport?.score ?: 0
                            subFeature == "frequency" -> freqReport?.score ?: 0
                            subFeature == "compression" -> compressReport?.score ?: 0
                            subFeature == "fillrate" -> fillrateReport?.score ?: 0
                            else -> 0
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterVertically) {
                            ScoreGauge(score = score, gaugeSize = 150.dp, label = title)
                            Spacer(Modifier.weight(1f))
                            Column {
                                Text("Overall Score", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(4.dp))
                                Text(score.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Radar chart for GPU subsystems
                    item {
                        ChartCard(title = "GPU Subsystem Breakdown", caption = "ROP / Texture / Bandwidth / Compute") {
                            RadarChart(
                                values = when (subFeature) {
                                    "fillrate" -> listOf(fillrateReport?.ropMpx ?: 0f, fillrateReport?.texMtpix ?: 0f, fillrateReport?.ropMpx ?: 0f * 0.8f, fillrateReport?.texMtpix ?: 0f * 0.9f, fillrateReport?.ropMpx ?: 0f)
                                    else -> listOf(85f, 72f, 68f, 60f, 78f)
                                },
                                maxValue = 2000f,
                                labels = listOf("ROP Fill", "Texture", "Bandwidth", "Compute", "Memory"),
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }

                    // Line chart for frequency residency
                    if (subFeature == "frequency" && freqReport != null) {
                        item {
                            ChartCard(title = "GPU Clock Residency", caption = "Time spent at each frequency step") {
                                LineChart(
                                    points = listOf(200f, 450f, 700f, 950f, freqReport.maxMhz.toFloat()),
                                    color = MaterialTheme.colorScheme.secondary,
                                    height = 160.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Peak Residency: ${"%.1f".format(freqReport.residency)}%", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    // Histogram for stutter
                    if (subFeature == "stutter" && stutterReport != null) {
                        item {
                            ChartCard(title = "Frame-Time Distribution", caption = "Cold vs warmed pipeline frames") {
                                FrameTimeHistogram(
                                    buckets = listOf(
                                        (stutterReport.maxStall * 10).roundToInt().coerceAtLeast(0).coerceAtMost(200),
                                        (stutterReport.maxStall * 8).roundToInt().coerceAtLeast(0).coerceAtMost(200),
                                        (stutterReport.maxStall * 5).roundToInt().coerceAtLeast(0).coerceAtMost(200),
                                        (stutterReport.maxStall * 3).roundToInt().coerceAtLeast(0).coerceAtMost(200),
                                        (stutterReport.maxStall * 1).roundToInt().coerceAtLeast(0).coerceAtMost(200),
                                    ),
                                    height = 160.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spaceBetween) {
                                    Text("Max Stall", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${"%.1f".format(stutterReport.maxStall)} ms", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spaceBetween) {
                                    Text("Cold→Warm Ratio", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${"%.2f".format(stutterReport.ratio)}x", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }

                    // Metric pills
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        ) {
                            when (subFeature) {
                                "vrs" -> {
                                    MetricPill(label = "FPS Gain", value = vrsReport?.fpsGain?.toString() ?: "–", unit = "%")
                                    MetricPill(label = "Quality Loss", value = vrsReport?.qualityLoss?.toString() ?: "–", unit = "%")
                                }
                                "stutter" -> {
                                    MetricPill(label = "Stutter Score", value = stutterReport?.score?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Max Stall", value = stutterReport?.maxStall?.toString() ?: "–", unit = "ms")
                                }
                                "frequency" -> {
                                    MetricPill(label = "Current MHz", value = freqReport?.currentMhz?.toString() ?: "–", unit = "MHz")
                                    MetricPill(label = "Max MHz", value = freqReport?.maxMhz?.toString() ?: "–", unit = "MHz")
                                }
                                "compression" -> {
                                    MetricPill(label = "Compression Ratio", value = compressReport?.ratio?.toString() ?: "–", unit = ":1")
                                    MetricPill(label = "Score", value = compressReport?.score?.toString() ?: "–", unit = "")
                                }
                                "fillrate" -> {
                                    MetricPill(label = "ROP Fill", value = fillrateReport?.ropMpx?.toString() ?: "–", unit = "MPx/s")
                                    MetricPill(label = "Texture", value = fillrateReport?.texMtpix?.toString() ?: "–", unit = "MTpx/s")
                                }
                                else -> {}
                            }
                        }
                    }

                    // Verdict
                    item {
                        SurfaceCard {
                            androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth()) {
                                Text("Verdict", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(6.dp))
                                val verdictText = when {
                                    subFeature == "vrs" -> vrsReport?.verdict ?: "No data"
                                    subFeature == "stutter" -> stutterReport?.verdict ?: "No data"
                                    subFeature == "frequency" -> freqReport?.verdict ?: "No data"
                                    subFeature == "compression" -> compressReport?.verdict ?: "No data"
                                    subFeature == "fillrate" -> fillrateReport?.verdict ?: "No data"
                                    else -> "No data"
                                }
                                Text(verdictText, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    item {
                        Button(onClick = { runFeature() }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(text = "Re-run Benchmark")
                        }
                    }

                    item {
                        Button(onClick = { onNavigate(Routes.BENCHMARKS) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Text(text = "Back to Benchmarks")
                        }
                    }
                }
            }
        }
    }
}
