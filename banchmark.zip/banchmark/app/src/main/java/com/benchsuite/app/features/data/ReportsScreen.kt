package com.benchsuite.app.features.data

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.ReportItem
import com.benchsuite.app.data.model.ReportType
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.FilterPills
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.ReportRow
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

private val reportFilters = listOf("All", "Full", "Health", "Comparison", "Quick", "Custom")

@Composable
fun ReportsScreen(onNavigate: (String) -> Unit) {
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var exportMessage by remember { mutableStateOf<String?>(null) }

    val allReports: List<ReportItem> = SessionState.completedReportItems

    val reports: List<ReportItem> = when (filter) {
        1 -> allReports.filter { it.type == ReportType.FULL }
        2 -> allReports.filter { it.type == ReportType.HEALTH }
        3 -> allReports.filter { it.type == ReportType.COMPARISON }
        4 -> allReports.filter { it.type == ReportType.QUICK }
        5 -> allReports.filter { it.type == ReportType.CUSTOM }
        else -> allReports
    }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Reports",
            subtitle = "${allReports.size} documents · all local",
            actions = {
                IconAction(Icons.Outlined.Add, "New report") {
                    val targetId = SessionState.latestNativeRun?.id
                    if (targetId != null) onNavigate(Routes.report(targetId))
                    else onNavigate(Routes.preTest("full"))
                }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Documents you can defend",
                    title = "Reports, not screenshots.",
                    body = "Every report carries the conditions, methodology and signature behind the score.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Report library", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${SessionState.completedReportItems.size} report${if (SessionState.completedReportItems.size == 1) "" else "s"} from real runs",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        StatusChip("${SessionState.reportSharedIds.size} shared", tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        ReportStat("Total", SessionState.completedReportItems.size.toString(), Modifier.weight(1f))
                        ReportStat("Native", SessionState.completedReportItems.count { it.type == ReportType.FULL }.toString(), Modifier.weight(1f))
                        ReportStat("Signed", SessionState.completedReportItems.size.toString(), Modifier.weight(1f), BenchTheme.colors.success)
                    }
                }
            }

            item {
                FilterPills(
                    options = reportFilters,
                    selectedIndex = filter,
                    onSelect = { filter = it },
                )
            }

            item {
                SectionHeader(
                    title = if (filter == 0) "Recent reports" else reportFilters[filter],
                    actionLabel = "Compare",
                    onAction = { onNavigate(Routes.COMPARE) },
                )
            }

            if (reports.isEmpty()) {
                item {
                    SurfaceCard {
                        Text("No reports of this type yet.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Run a benchmark and export it to create the first one.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                items(reports.size) { index ->
                    val report = reports[index]
                    ReportRow(
                        report = report,
                        onClick = { onNavigate(Routes.report(report.id)) },
                        onShare = {
                            SessionState.markReportShared(report.id)
                            onNavigate(Routes.SHARE)
                        },
                    )
                }
            }

            item {
                SurfaceCard(
                    onClick = {
                        runCatching { SessionState.exportZip() }
                            .onSuccess { exportMessage = "Signed archive saved to Documents/ABS_Archive_*.zip" }
                            .onFailure { exportMessage = "Export failed: ${it.message}" }
                    }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.FolderZip, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Export everything", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        Icon(Icons.Outlined.FileDownload, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "One signed archive with PDF reports, JSON run records and CSV telemetry. Raw data is included; nothing is uploaded.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag("PDF")
                        Tag("JSON")
                        Tag("CSV")
                        Tag("ZIP")
                    }
                    if (exportMessage != null) {
                        Spacer(Modifier.height(Spacing.sm))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.CheckCircle, null, tint = BenchTheme.colors.success, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                exportMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = BenchTheme.colors.success,
                            )
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = {
                            val repId = SessionState.latestNativeRun?.id ?: reports.firstOrNull()?.id
                            if (repId != null) {
                                onNavigate(Routes.report(repId))
                            } else {
                                SessionState.preTest("full")
                                onNavigate(Routes.PRETEST)
                            }
                        },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Icon(Icons.Outlined.Add, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (SessionState.latestNativeRun != null) "View latest report" else "New full benchmark")
                    }
                    OutlinedButton(
                        onClick = { onNavigate(Routes.COMPARE) },
                        modifier = Modifier.height(50.dp),
                    ) {
                        Text("Compare")
                    }
                }
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Verified, null, tint = BenchTheme.colors.success, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Reports remain verifiable offline by signature.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun ReportStat(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = NumericSmall, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
