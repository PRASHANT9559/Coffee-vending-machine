package com.benchsuite.app.features.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.ScheduleItem
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun SchedulerScreen(onBack: () -> Unit) {
    val schedules = SessionState.schedules
    var counter by remember { mutableIntStateOf(0) }
    val enabled = schedules.count { it.enabled }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Scheduler queue",
            subtitle = "$enabled active · ${schedules.size} total",
            onBack = onBack,
            actions = {
                IconActionAdd {
                    counter += 1
                    SessionState.schedules = SessionState.schedules + ScheduleItem(
                        id = "sch.custom.$counter",
                        title = "Ad-hoc check $counter",
                        cadence = "One-off",
                        nextRun = "Queued · next idle window",
                        priority = "P1 · Suite",
                        enabled = true,
                    )
                }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Runs on your terms",
                    title = "Queue the boring checks.",
                    body = "Scheduled runs wait for an idle, cool, charged device. If conditions are wrong, they are postponed, never forced.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(42.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.Schedule, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(21.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Next queued run", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Weekly health check", style = MaterialTheme.typography.titleSmall)
                            Text("Monday, 16 Nov · 07:00", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        StatusChip("Waiting", tint = BenchTheme.colors.success)
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        QueueStat("Active", enabled.toString(), Modifier.weight(1f))
                        QueueStat("Disabled", (schedules.size - enabled).toString(), Modifier.weight(1f))
                        QueueStat("Next", "5 days", Modifier.weight(1f))
                    }
                }
            }

            item { SectionHeader(title = "Scheduled protocols", actionLabel = "Add", onAction = {
                counter += 1
                SessionState.schedules = SessionState.schedules + ScheduleItem(
                    id = "sch.custom.$counter",
                    title = "Ad-hoc check $counter",
                    cadence = "One-off",
                    nextRun = "Queued · next idle window",
                    priority = "P1 · Suite",
                    enabled = true,
                )
            }) }

            items(schedules.size) { index ->
                ScheduleCard(schedules[index])
            }

            item {
                OutlinedButton(
                    onClick = {
                        counter += 1
                        SessionState.schedules = SessionState.schedules + ScheduleItem(
                            id = "sch.custom.$counter",
                            title = "Ad-hoc check $counter",
                            cadence = "One-off",
                            nextRun = "Queued · next idle window",
                            priority = "P1 · Suite",
                            enabled = true,
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                ) {
                    Icon(Icons.Outlined.Add, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add a one-off run")
                }
            }

            item { SectionHeader(title = "Execution rules") }
            item {
                SurfaceCard {
                    RuleRow(
                        icon = Icons.Outlined.BatteryChargingFull,
                        title = "Battery above 50%",
                        body = "Runs below the threshold are postponed, not downgraded. Power measurement stays valid.",
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    RuleRow(
                        icon = Icons.Outlined.Thermostat,
                        title = "Device cooler than 35 °C",
                        body = "A hot device produces a lower, less comparable score. The queue waits for cool-down.",
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    RuleRow(
                        icon = Icons.Outlined.Schedule,
                        title = "Idle window and screen off",
                        body = "Android may delay exact timing. Runs start at the next suitable window with a notification.",
                    )
                }
            }

            item {
                SurfaceCard {
                    Text("Priority levels", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(6.dp))
                    PriorityRow("P1 · Suite", "Runs immediately when conditions allow.", BenchTheme.colors.danger)
                    PriorityRow("P2 · Scheduled", "Runs inside the requested window.", MaterialTheme.colorScheme.primary)
                    PriorityRow("P3 · Background", "Runs only when idle and charging.", MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Tag("Battery-aware")
                    Tag("Thermal-aware")
                    Tag("Local only")
                }
            }

            item {
                Text(
                    "Schedules are stored on this device. No server wakes your phone. Missed runs are rescheduled once with a note.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun IconActionAdd(onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(44.dp)) {
        Icon(Icons.Outlined.Add, contentDescription = "Add schedule", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun ScheduleCard(item: ScheduleItem) {
    val priorityColor = when {
        item.priority.startsWith("P1") -> BenchTheme.colors.danger
        item.priority.startsWith("P2") -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    SurfaceCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).background(priorityColor.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.Schedule, null, tint = priorityColor, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, style = MaterialTheme.typography.titleSmall)
                Text(item.cadence, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = item.enabled, onCheckedChange = { SessionState.toggleSchedule(item.id) })
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Tag(item.priority, priorityColor)
            Spacer(Modifier.width(6.dp))
            Text(
                if (item.enabled) item.nextRun else "Paused",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun QueueStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = NumericSmall, color = MaterialTheme.colorScheme.onSurface)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun RuleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(9.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PriorityRow(label: String, body: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            Modifier
                .padding(top = 5.dp)
                .size(6.dp)
                .background(color, CircleShape),
        )
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelMedium, color = color)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
