package com.benchsuite.app.nativecore

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import android.view.WindowManager
import com.benchsuite.app.data.model.RunConditions
import com.benchsuite.app.util.readTextOrNull
import java.io.File
import java.nio.charset.Charsets
import kotlin.math.abs
import kotlin.math.roundToInt

/** A cheap snapshot of the platform state around a native run. */
data class DeviceTelemetry(
    val batteryPct: Int,
    val charging: Boolean,
    val temperatureC: Double,
    val powerW: Double,
    val clockGhz: Double,
    val thermalStatus: String,
    val freeStorageGb: Double,
    // ---- Phase 5: real hardware detection (was hardcoded) ----
    val ramTotalMb: Long,
    val ramType: String,
    val storageTechnology: String,
    val displayWidthPx: Int,
    val displayHeightPx: Int,
    val batteryCapacityMah: Int,
)

/**
 * Reads battery/thermal/clock state without holding a receiver. The battery
 * intent is sticky, so a null-receiver query is enough and needs no permission
 * on API 29+.
 */
object DeviceTelemetryReader {

    fun read(context: Context): DeviceTelemetry {
        val battery = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val sticky = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
        )

        val level = sticky?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = sticky?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val capacity = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 0
        val percentage = when {
            level >= 0 && scale > 0 -> level * 100 / scale
            else -> capacity
        }.coerceIn(0, 100)

        val status = sticky?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val temperature = (sticky?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0

        val voltage = (sticky?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000.0
        val currentAmps = (battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0) / 1_000_000.0
        val power = if (voltage > 0.0) abs(currentAmps * voltage) else 0.0

        val cores = Runtime.getRuntime().availableProcessors()
        val clock = readMaxClockGhz(cores)
        val freeStorage = context.filesDir.usableSpace.coerceAtLeast(0L) / 1_073_741_824.0

        // Phase 5: real hardware detection
        val ramTotal = readRamTotalMb()
        val ramType = readRamType()
        val storageTech = readStorageTechnology()
        val display = readDisplaySize(context)
        val batteryCap = readBatteryCapacityMah(battery)

        return DeviceTelemetry(
            batteryPct = percentage,
            charging = charging,
            temperatureC = if (temperature > 0.0) temperature else 32.0,
            powerW = power,
            clockGhz = clock,
            thermalStatus = thermalStatus(context),
            freeStorageGb = freeStorage,
            ramTotalMb = ramTotal,
            ramType = ramType,
            storageTechnology = storageTech,
            displayWidthPx = display.first,
            displayHeightPx = display.second,
            batteryCapacityMah = batteryCap,
        )
    }

    fun conditions(context: Context, performanceMode: Boolean): RunConditions {
        val telemetry = read(context)
        return RunConditions(
            batteryPct = telemetry.batteryPct,
            charging = telemetry.charging,
            batteryTempC = telemetry.temperatureC,
            // Real ambient reading from thermal zones when exposed; otherwise the measured
            // battery temperature is used instead of a hardcoded 24.0 °C.
            ambientC = readAmbientTempC() ?: telemetry.temperatureC,
            // Real CPU non-idle load sampled over a short window instead of a hardcoded 3%.
            backgroundLoadPct = measureBackgroundLoadPct(),
            thermalStatus = telemetry.thermalStatus,
            freeStorageGb = (telemetry.freeStorageGb * 10).roundToInt() / 10.0,
            powerMode = if (performanceMode) "Performance" else "Balanced",
            // Phase 5: real hardware detection
            ramTotalMb = telemetry.ramTotalMb,
            ramType = telemetry.ramType,
            storageTechnology = telemetry.storageTechnology,
            displayWidthPx = telemetry.displayWidthPx,
            displayHeightPx = telemetry.displayHeightPx,
            batteryCapacityMah = telemetry.batteryCapacityMah,
        )
    }

    /**
     * Reads the ambient thermal zone temperature from sysfs. Returns null when the
     * device exposes no ambient zone; callers fall back to measured battery temperature.
     */
    private fun readAmbientTempC(): Double? {
        val zones = File("/sys/class/thermal").listFiles() ?: return null
        for (zone in zones.sortedBy { it.name }) {
            val type = File(zone, "type").readTextOrNull()?.trim()?.lowercase() ?: continue
            if (!type.contains("ambient")) continue
            val raw = File(zone, "temp").readTextOrNull()?.trim()?.toDoubleOrNull() ?: continue
            val celsius = if (raw > 1000.0) raw / 1000.0 else raw
            if (celsius in -40.0..85.0) return (celsius * 10).roundToInt() / 10.0
        }
        return null
    }

    /**
     * Samples /proc/stat over a short window and reports the CPU non-idle load percentage
     * as a proxy for background load. Returns 0 when /proc/stat is unreadable.
     */
    private fun measureBackgroundLoadPct(sampleMs: Long = 250): Int {
        fun cpuTimes(): Pair<Long, Long>? {
            val line = File("/proc/stat").readTextOrNull()
                ?.lineSequence()
                ?.firstOrNull { it.startsWith("cpu ") } ?: return null
            val parts = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (parts.size < 5) return null
            val idle = parts[3] + parts.getOrElse(4) { 0L }
            return idle to parts.sum()
        }
        val before = cpuTimes() ?: return 0
        try { Thread.sleep(sampleMs) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        val after = cpuTimes() ?: return 0
        val dTotal = after.second - before.second
        val dIdle = after.first - before.first
        if (dTotal <= 0) return 0
        return (((dTotal - dIdle) * 100.0) / dTotal).roundToInt().coerceIn(0, 100)
    }

    fun deviceModel(): String {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        return if (model.startsWith(manufacturer, ignoreCase = true)) model else "$manufacturer $model"
    }

    fun socModel(fallback: String): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.ifBlank { fallback }
        } else {
            fallback
        }

    private fun thermalStatus(context: Context): String {
        val manager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return "Unknown"
        return when (manager.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Nominal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "Unknown"
        }
    }

    fun readMaxClockGhz(cores: Int): Double {
        for (index in cores - 1 downTo 0) {
            val path = "/sys/devices/system/cpu/cpu$index/cpufreq/scaling_cur_freq"
            val khz = runCatching { File(path).readText().trim().toLong() }.getOrNull() ?: continue
            if (khz > 0) return khz / 1_000_000.0
        }
        return 0.0
    }

    /* ------------------------------------------------------------------ */
    /* Phase 5: Real hardware detection                                   */
    /* ------------------------------------------------------------------ */

    /** Total RAM in MB from /proc/meminfo. Returns 0 when unreadable. */
    private fun readRamTotalMb(): Long {
        File("/proc/meminfo").readTextOrNull()?.lineSequence()
            ?.firstOrNull { it.startsWith("MemTotal:") }
            ?.let { line ->
                val kb = line.substringAfter(":").trim().removeSuffix("kB").trim().toLongOrNull() ?: return 0L
                return kb / 1024
            }
        return 0L
    }

    /** Best-effort RAM type detection from kernel / device-tree strings. */
    private fun readRamType(): String {
        // Try common sysfs / device-tree hints for LPDDR generation
        val hints = listOf(
            "/sys/firmware/devicetree/base/memory/ddr-type",
            "/proc/device-tree/memory/ddr-type",
        )
        for (p in hints) {
            File(p).readTextOrNull()?.trim()?.takeIf { it.isNotBlank() }?.let { return it }
        }
        // Fallback: infer from total size (heuristic only, marked as estimate)
        val total = readRamTotalMb()
        return when {
            total >= 12000 -> "LPDDR5/LPDDR5X (est.)"
            total >= 6000 -> "LPDDR4/LPDDR4X (est.)"
            total > 0 -> "LPDDR3 (est.)"
            else -> "Unknown"
        }
    }

    /** Storage technology: UFS / eMMC / NVMe / Unknown from sysfs. */
    private fun readStorageTechnology(): String {
        // UFS devices expose ext_csd with device type
        val mmcPaths = File("/sys/block").listFiles()
            ?.filter { it.name.startsWith("mmcblk") }
            ?: return "Unknown"
        for (blk in mmcPaths) {
            val extCsd = File(blk, "device/ext_csd")
            if (extCsd.exists()) {
                val raw = extCsd.readTextOrNull() ?: continue
                // Byte 194 (decimal) of ext_csd = device type: 1 = UFS
                val bytes = raw.toByteArray(Charsets.ISO_8859_1)
                if (bytes.size > 194 && bytes[194].toInt() and 0xFF == 1) {
                    return "UFS"
                }
            }
            val type = File(blk, "device/type").readTextOrNull()?.trim()?.takeIf { it.isNotBlank() }
            if (type != null) return type
        }
        // NVMe check
        if (File("/sys/class/nvme").exists()) return "NVMe"
        // eMMC fallback
        if (mmcPaths.isNotEmpty()) return "eMMC (est.)"
        return "Unknown"
    }

    /** Display resolution (width, height) in pixels from WindowManager. */
    private fun readDisplaySize(context: Context): Pair<Int, Int> {
        return try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return Pair(0, 0)
            val display = wm.defaultDisplay
            val size = Display.Size()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                display.getSize(size)
                return Pair(size.width, size.height)
            }
            // Pre-API 30 fallback
            val point = android.graphics.Point()
            display.getSize(point)
            return Pair(point.x, point.y)
        } catch (_: Exception) {
            Pair(0, 0)
        }
    }

    /** Battery design capacity in mAh from BatteryManager. Returns 0 when unavailable. */
    private fun readBatteryCapacityMah(battery: BatteryManager?): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            battery?.run {
                val props = mutableListOf<Int>()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    props.add(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                }
                // design capacity is not directly exposed pre-API 23 reliably;
                // report 0 (unknown) rather than fabricating.
                0
            } ?: 0
        } else {
            0
        }
    }
}
