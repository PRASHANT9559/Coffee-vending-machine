package com.benchsuite.app.engine.productivity

import com.benchsuite.app.util.*

import android.content.Context
import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 13.7: Multi-Window & Desktop Mode Workload
 *
 * Run several apps in split-screen and desktop mode while measuring responsiveness. Phones and
 * tablets are used like laptops now.
 *
 * Data source: multi-window / desktop mode support detection + responsiveness model.
 * Limitations: No real multi-app window workload; responsiveness modeled from mode support,
 * not fabricated measured values.
 */
object MultiWindowDesktopModeWorkload {

    data class ModeResult(
        val mode: String,
        val supported: Boolean,
        val maxConcurrentApps: Int,
        val responsivenessScore: Int, // 0 - 100
    )

    data class MultiWindowReport(
        val splitScreenSupported: Boolean,
        val desktopModeSupported: Boolean,
        val modes: List<ModeResult>,
        val overallResponsiveness: Double,
        val multiWindowScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun supportsFreeform(context: Context): Boolean {
        return try {
            context.packageManager.hasSystemFeature("android.software.freeform_window_management")
        } catch (_: Exception) {
            false
        }
    }

    private fun supportsSplitScreen(context: Context): Boolean {
        return try {
            context.packageManager.hasSystemFeature("android.software.split_screen")
        } catch (_: Exception) {
            Build.VERSION.SDK_INT >= 24
        }
    }

    /**
     * Assesses multi-window and desktop mode workload capability.
     */
    fun assessMultiWindow(context: Context): MultiWindowReport {
        val splitScreen = supportsSplitScreen(context)
        val desktop = supportsFreeform(context)
        val isLargeScreen = Build.VERSION.SDK_INT >= 24 && Build.HARDWARE.lowercase().contains("sm8")

        val modes = mutableListOf<ModeResult>()
        modes.add(ModeResult("Split-screen", splitScreen, if (splitScreen) 2 else 0,
            if (splitScreen) 85 else 0))
        modes.add(ModeResult("Desktop / freeform", desktop, if (desktop) 4 else 0,
            if (desktop) 80 else 0))
        modes.add(ModeResult("Picture-in-picture", true, 1, 90))

        val overall = modes.filter { it.supported }.averageOf { it.responsivenessScore.toDouble() }
        val score = when {
            splitScreen && desktop -> 920
            splitScreen -> 760
            isLargeScreen -> 620
            else -> 440
        }

        val verdict = when {
            splitScreen && desktop -> "Excellent multi-window and desktop mode support."
            splitScreen -> "Split-screen supported; desktop mode limited."
            else -> "Limited multi-window productivity support."
        }

        return MultiWindowReport(
            splitScreenSupported = splitScreen,
            desktopModeSupported = desktop,
            modes = modes,
            overallResponsiveness = (overall.coerceIn(0.0, 100.0) * 100.0).roundToInt() / 100.0,
            multiWindowScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real multi-app window workload; responsiveness modeled from mode support flags.",
        )
    }
}
