package com.benchsuite.app.features.account

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.data.model.ChartStyle
import com.benchsuite.app.data.model.SettingsState
import com.benchsuite.app.data.model.ThemeMode
import com.benchsuite.app.data.model.UnitsMode
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.SegmentedControl
import com.benchsuite.app.ui.components.SettingRow
import com.benchsuite.app.ui.components.ShortcutRow
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun SettingsScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val settings = SessionState.settings

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Settings",
            subtitle = "Theme, data and run behavior",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Make it yours",
                    title = "Controls that stay out of the way.",
                    body = "Data colors never change with the theme, so screenshots and comparisons stay honest.",
                )
            }

            item { SectionHeader(title = "Appearance") }
            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Palette, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Theme", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    SegmentedControl(
                        options = listOf("System", "Dark", "Light"),
                        selectedIndex = ThemeMode.values().indexOf(settings.themeMode),
                        onSelect = { index ->
                            SessionState.updateSettings { it.copy(themeMode = ThemeMode.values()[index]) }
                        },
                    )
                    Spacer(Modifier.height(Spacing.xs))
                    SettingRow(
                        title = "Dynamic color",
                        subtitle = "Material You accents on non-data surfaces only",
                        trailing = {
                            Switch(
                                checked = settings.dynamicColor,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(dynamicColor = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Reduce motion",
                        subtitle = "Removes gauge and chart reveal animations",
                        trailing = {
                            Switch(
                                checked = settings.reduceMotion,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(reduceMotion = value) }
                                },
                            )
                        },
                    )
                }
            }

            item { SectionHeader(title = "Data and charts") }
            item {
                SurfaceCard {
                    Text("Chart style", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    SegmentedControl(
                        options = listOf("Line", "Area", "Bar"),
                        selectedIndex = ChartStyle.values().indexOf(settings.chartStyle),
                        onSelect = { index ->
                            SessionState.updateSettings { it.copy(chartStyle = ChartStyle.values()[index]) }
                        },
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Text("Units", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    SegmentedControl(
                        options = listOf("Metric", "Imperial"),
                        selectedIndex = UnitsMode.values().indexOf(settings.units),
                        onSelect = { index ->
                            SessionState.updateSettings { it.copy(units = UnitsMode.values()[index]) }
                        },
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Units affect display only. Scores and stored telemetry never change.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item { SectionHeader(title = "Run behavior") }
            item {
                SurfaceCard {
                    SettingRow(
                        title = "Keep screen on during runs",
                        subtitle = "Prevents display sleep from pausing UI updates",
                        trailing = {
                            Switch(
                                checked = settings.keepScreenOn,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(keepScreenOn = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Performance mode",
                        subtitle = "Requests the OEM performance profile for measurements",
                        trailing = {
                            Switch(
                                checked = settings.performanceMode,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(performanceMode = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Haptics",
                        subtitle = "Touch feedback for key actions",
                        trailing = {
                            Switch(
                                checked = settings.haptics,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(haptics = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Scheduled health checks",
                        subtitle = "Weekly health run when the device is idle",
                        trailing = {
                            Switch(
                                checked = settings.scheduledHealth,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(scheduledHealth = value) }
                                },
                            )
                        },
                    )
                }
            }

            item { SectionHeader(title = "Privacy and sharing") }
            item {
                SurfaceCard {
                    SettingRow(
                        title = "Anomaly alerts",
                        subtitle = "Notify when a run is invalidated by heat or load",
                        trailing = {
                            Switch(
                                checked = settings.anomalyAlerts,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(anomalyAlerts = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Crash reports",
                        subtitle = "Privacy-safe stack traces only",
                        trailing = {
                            Switch(
                                checked = settings.crashReports,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(crashReports = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Usage analytics",
                        subtitle = "Feature counters with no identifiers",
                        trailing = {
                            Switch(
                                checked = settings.analytics,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(analytics = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Leaderboard upload",
                        subtitle = "Submit signed scores and model-level hardware",
                        trailing = {
                            Switch(
                                checked = settings.leaderboardUpload,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(leaderboardUpload = value) }
                                },
                            )
                        },
                    )
                    SettingRow(
                        title = "Cloud sync",
                        subtitle = "Off by default. Not required for any feature",
                        trailing = {
                            Switch(
                                checked = settings.cloudSync,
                                onCheckedChange = { value ->
                                    SessionState.updateSettings { it.copy(cloudSync = value) }
                                },
                            )
                        },
                    )
                    Spacer(Modifier.height(Spacing.xs))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.CloudOff, null, tint = BenchTheme.colors.success, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "No account, advertising ID or cloud dependency.",
                            style = MaterialTheme.typography.labelSmall,
                            color = BenchTheme.colors.success,
                        )
                    }
                }
            }

            item { SectionHeader(title = "More") }
            item {
                SurfaceCard(contentPadding = PaddingValues(horizontal = Spacing.md, vertical = 4.dp)) {
                    ShortcutRow("Privacy and data", "Consent, export and delete everything", Icons.Outlined.Lock) { onNavigate(Routes.PRIVACY) }
                    ShortcutRow("Help and support", "FAQ, diagnostics and feedback", Icons.Outlined.SupportAgent) { onNavigate(Routes.HELP) }
                    ShortcutRow("About BenchSuite", "Version, methodology and licenses", Icons.Outlined.Info) { onNavigate(Routes.ABOUT) }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.BugReport, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Use Help to attach diagnostics before reporting a problem.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = { SessionState.settings = SettingsState() },
                    ) {
                        Text("Reset all settings")
                    }
                    Spacer(Modifier.weight(1f))
                    StatusChip("v1.0.0-ui", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            item {
                Text(
                    "Settings are stored locally and applied immediately. Methodology 2.4.1.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
