package com.benchsuite.app.engine.enterprise

import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 21.1: Custom Benchmark Builder
 *
 * Empowers developers and advanced users to author tailored benchmark suites: arbitrary sub-tests,
 * iteration counts, thermal cooldown gates, and custom pass/fail criteria.
 * ENGINE / DAG / PROTOCOL MODEL ONLY — no host-side execution, no Compose screen.
 *
 * Data source: in-memory DAG of test nodes with pass/fail criteria.
 * Limitations: No test execution engine or result persistence beyond the model; no fabricated values.
 */
object CustomBenchmarkBuilder {

    @Serializable
    enum class TestType(val label: String) {
        CPU("CPU compute"),
        GPU("GPU render"),
        MEMORY("Memory bandwidth"),
        STORAGE("Storage IOPS"),
        THERMAL("Thermal soak"),
        NETWORK("Network latency"),
        CUSTOM("Custom script");
    }

    @Serializable
    data class TestNode(
        val id: String,
        val name: String,
        val type: TestType,
        val iterations: Int,
        val thermalCooldownSec: Int,
        val passThresholdScore: Int,
        val dependsOn: List<String> = emptyList(),
    )

    @Serializable
    data class BenchmarkSuite(
        val id: String,
        val name: String,
        val nodes: List<TestNode>,
        val totalEstimatedSec: Int,
    )

    @Serializable
    data class ExecutionPlan(
        val suite: BenchmarkSuite,
        val executionOrder: List<String>,
        val totalCooldownSec: Int,
        val canExecute: Boolean,
        val cycleDetected: Boolean,
    )

    private val json = Json { ignoreUnknownKeys = true; isLenient = true; encodeDefaults = true }

    /**
     * Builds an execution plan (topological order) for a custom benchmark suite DAG.
     */
    fun buildExecutionPlan(suite: BenchmarkSuite): ExecutionPlan {
        val nodeMap = suite.nodes.associate { it.id to it }
        val order = mutableListOf<String>()
        val visited = mutableSetOf<String>()
        val inStack = mutableSetOf<String>()
        var cycle = false

        fun visit(id: String) {
            if (id in inStack) { cycle = true; return }
            if (id in visited) return
            visited.add(id)
            inStack.add(id)
            nodeMap[id]?.dependsOn?.forEach { visit(it) }
            inStack.remove(id)
            order.add(id)
        }

        suite.nodes.forEach { visit(it.id) }

        val totalCooldown = suite.nodes.sumOf { it.thermalCooldownSec }
        val canExecute = !cycle && suite.nodes.isNotEmpty()

        return ExecutionPlan(
            suite = suite,
            executionOrder = order,
            totalCooldownSec = totalCooldown,
            canExecute = canExecute,
            cycleDetected = cycle,
        )
    }

    /**
     * Validates a suite's pass/fail criteria consistency.
     */
    fun validateSuite(suite: BenchmarkSuite): List<String> {
        val issues = mutableListOf<String>()
        suite.nodes.forEach { node ->
            if (node.iterations <= 0) issues.add("${node.name}: iterations must be > 0")
            if (node.passThresholdScore < 0 || node.passThresholdScore > 1000) {
                issues.add("${node.name}: pass threshold must be 0-1000")
            }
            node.dependsOn.forEach { dep ->
                if (!suite.nodes.any { it.id == dep }) {
                    issues.add("${node.name}: depends on unknown node $dep")
                }
            }
        }
        return issues
    }

    /**
     * Serializes a suite to JSON for sharing/import.
     */
    fun suiteToJson(suite: BenchmarkSuite): String = json.encodeToString(suite)

    /**
     * Deserializes a suite from JSON.
     */
    fun suiteFromJson(jsonStr: String): BenchmarkSuite = json.decodeFromString(jsonStr)
}
