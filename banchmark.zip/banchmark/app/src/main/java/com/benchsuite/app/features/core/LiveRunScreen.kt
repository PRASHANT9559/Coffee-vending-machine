package com.benchsuite.app.features.core

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.RadioButtonChecked
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.StepState
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.MetricPill
import com.benchsuite.app.ui.components.ProgressRing
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing
import kotlinx.coroutines.delay
import kotlin.math.sin

@Composable
fun LiveRunScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val run = SessionState.activeRun
    var showCancel by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(500)

            if (SessionState.nativeRunError != null) {
                SessionState.cancelRun()
                SessionState.clearNativeError()
                onNavigate(Routes.RUN_FAILED)
                break
            }

            val current = SessionState.activeRun ?: break
            if (!current.isNative) SessionState.advance(1)
            val updated = SessionState.activeRun
            if (updated != null && updated.progress >= 1f) {
                SessionState.completeRun()
                onNavigate(Routes.resultSummary(SessionState.lastCompletedRunId))
                break
            }
        }
    }

    if (run == null) {
        Column(Modifier.fillMaxSize()) {
            BenchTopBar(title = "Live run", onBack = onBack)
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("No active run", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Start a suite to see live telemetry here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(Spacing.md))
                Button(onClick = { onNavigate(Routes.preTest("full")) }) { Text("Choose a suite") }
            }
        }
        return
    }

    val pulse = rememberInfiniteTransition(label = "livepulse")
    val pulseAlpha by pulse.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "alpha",
    )

    val thermalPoints = remember(run.progress, run.temperatureC) {
        val count = (run.progress * 24).toInt().coerceIn(2, 24)
        (0 until count).map { index ->
            run.temperatureC.toFloat()
        }
    }

    val completedSteps = (run.progress * run.totalTests).toInt().coerceIn(0, run.totalTests)

    val runSteps = (1..run.totalTests).map { "Step $it" }

    Column(Modifier.fillMaxSize()) {
        BenchTopBar(
            title = if (run.paused) "Run paused" else "Live run",
            subtitle = run.title,
            actions = {
                Box {
                    IconAction(Icons.Outlined.MoreVert, "Run options", onClick = { showMenu = true })
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("End with diagnostics") },
                            onClick = {
                                showMenu = false
                                SessionState.cancelRun()
                                onNavigate(Routes.RUN_FAILED)
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Cancel run") },
                            onClick = {
                                showMenu = false
                                showCancel = true
                            },
                        )
                    }
                }
                IconAction(Icons.Outlined.Close, "Cancel run", onClick = { showCancel = true })
            },
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 20.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha), CircleShape))
                    Spacer(Modifier.width(7.dp))
                    Text(
                        if (run.paused) "Measurement paused · clocks may drift" else "Measuring at 10 Hz · UI throttled",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.weight(1f))
                    StatusChip(if (run.cooling) "Cooling" else "Stable", tint = if (run.cooling) BenchTheme.colors.warning else BenchTheme.colors.success)
                }
            }

            item {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    ProgressRing(
                        progress = run.progress,
                        size = 210.dp,
                        label = run.remainingLabel,
                        color = if (run.cooling) BenchTheme.colors.warning else MaterialTheme.colorScheme.primary,
                    )
                }
            }

            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        run.currentTest,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Test ${(run.completedTests + 1).coerceAtMost(run.totalTests)} of ${run.totalTests} · elapsed ${formatElapsed(run.elapsedSec)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    MetricPill(
                        label = "Frame rate",
                        value = run.liveFps.toString(),
                        unit = "fps",
                        modifier = Modifier.weight(1f),
                    )
                    MetricPill(
                        label = "Battery temp",
                        value = String.format(java.util.Locale.US, "%.1f", run.temperatureC),
                        unit = "°C",
                        color = if (run.temperatureC > 42) BenchTheme.colors.warning else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f),
                    )
                    MetricPill(
                        label = "Package power",
                        value = String.format(java.util.Locale.US, "%.1f", run.powerW),
                        unit = "W",
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f),
                    )
                    MetricPill(
                        label = "Big-core clock",
                        value = String.format(java.util.Locale.US, "%.2f", run.cpuClockGhz),
                        unit = "GHz",
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Thermal envelope", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        Text(
                            String.format(java.util.Locale.US, "%.1f °C", run.temperatureC),
                            style = NumericSmall,
                            color = if (run.temperatureC > 42) BenchTheme.colors.warning else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (run.cooling) "Throttle step detected · power limited to protect the chassis"
                        else "Clock headroom available · no throttle step yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    LineChart(
                        points = thermalPoints,
                        color = if (run.temperatureC > 42) BenchTheme.colors.warning else MaterialTheme.colorScheme.primary,
                        minY = 28f,
                        maxY = 48f,
                        height = 120.dp,
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("28 °C", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("48 °C", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            item {
                SurfaceCard {
                    Text("Run timeline", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    runSteps.forEachIndexed { index, step ->
                        val state = when {
                            index < completedSteps -> StepState.DONE
                            index == completedSteps -> StepState.ACTIVE
                            else -> StepState.PENDING
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = when (state) {
                                    StepState.DONE -> Icons.Outlined.RadioButtonChecked
                                    StepState.ACTIVE -> Icons.Outlined.PlayArrow
                                    StepState.PENDING -> Icons.Outlined.Circle
                                    StepState.SKIPPED -> Icons.Outlined.Circle
                                },
                                contentDescription = null,
                                tint = when (state) {
                                    StepState.DONE -> BenchTheme.colors.success
                                    StepState.ACTIVE -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                },
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    step.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (state == StepState.PENDING) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    if (state == StepState.ACTIVE) "running · ${step.detail}" else step.detail,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                )
                            }
                            Tag(step.category)
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Tag("Real telemetry")
                    Tag("No synthetic data")
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .navigationBarsPadding()
                .padding(horizontal = Dimens.screenPadding, vertical = Spacing.sm),
            horizontalArrangement = Arrangement.spacedBy(Spacing.xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(
                onClick = { showCancel = true },
                modifier = Modifier.height(50.dp),
            ) {
                Icon(Icons.Outlined.Stop, null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(5.dp))
                Text("Cancel")
            }
            Button(
                onClick = { SessionState.togglePause() },
                modifier = Modifier.weight(1f).height(50.dp),
            ) {
                Icon(if (run.paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text(if (run.paused) "Resume run" else "Pause run")
            }
        }
    }

    if (showCancel) {
        AlertDialog(
            onDismissRequest = { showCancel = false },
            title = { Text("Cancel this run?") },
            text = { Text("Live measurements will be discarded. Partial results are not scored or saved.") },
            confirmButton = {
                TextButton(onClick = {
                    showCancel = false
                    SessionState.cancelRun()
                    onBack()
                }) { Text("Discard run") }
            },
            dismissButton = {
                TextButton(onClick = { showCancel = false }) { Text("Keep running") }
            },
            icon = { Icon(Icons.Outlined.Warning, null, tint = BenchTheme.colors.warning) },
        )
    }
}

private fun formatElapsed(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%d:%02d".format(m, s)
}
