package com.benchsuite.app.engine.security

import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 14.1: Biometric Unlock Latency & Accuracy Profiler
 *
 * Measures fingerprint/face unlock speed and false acceptance/rejection rates under various
 * conditions. "Fast" biometric unlock may be insecure; no benchmark tests the security/speed
 * tradeoff.
 *
 * Data source: BiometricManager availability + sensor strength detection.
 * Limitations: No real biometric template matching or unlock timing; latency/accuracy are modeled
 * per detected biometric hardware class, not fabricated measured values.
 */
object BiometricUnlockLatencyAccuracyProfiler {

    enum class BiometricType(val label: String) {
        FINGERPRINT("Fingerprint sensor"),
        FACE("Face unlock"),
        IRIS("Iris scanner"),
        NONE("No biometric sensor detected");
    }

    data class BiometricResult(
        val type: BiometricType,
        val available: Boolean,
        val strength: String,
        val unlockLatencyMs: Double,
        val falseAcceptanceRatePct: Double,
        val falseRejectionRatePct: Double,
        val securityScore: Int, // 0 - 1000
    )

    data class BiometricProfileReport(
        val fingerprint: BiometricResult,
        val face: BiometricResult,
        val overallSecurityScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun biometricStrength(context: Context): Int {
        val bm = context.getSystemService(Context.BIOMETRIC_SERVICE) as? BiometricManager
        return bm?.strongAuthenticatorCount?.let { it } ?: 0
    }

    /**
     * Profiles fingerprint and face unlock latency/accuracy via deterministic model.
     */
    fun profileBiometrics(context: Context): BiometricProfileReport {
        val bm = context.getSystemService(Context.BIOMETRIC_SERVICE) as? BiometricManager
        val fpAvailable = bm?.canAuthenticate(BiometricManager.BIOMETRIC_STRONG or BiometricManager.DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS
        val faceAvailable = bm?.canAuthenticate(BiometricManager.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        val strongCount = biometricStrength(context)

        val fingerprint = BiometricResult(
            type = BiometricType.FINGERPRINT,
            available = fpAvailable,
            strength = if (strongCount > 0) "Strong (TEE-backed)" else "Weak/Software",
            unlockLatencyMs = if (fpAvailable) 450.0 else -1.0,
            falseAcceptanceRatePct = if (fpAvailable) 0.002 else 0.0,
            falseRejectionRatePct = if (fpAvailable) 8.0 else 0.0,
            securityScore = if (fpAvailable && strongCount > 0) 920 else if (fpAvailable) 700 else 200,
        )

        val face = BiometricResult(
            type = BiometricType.FACE,
            available = faceAvailable,
            strength = if (faceAvailable && strongCount > 0) "Strong (depth/IR)" else "Weak (2D)",
            unlockLatencyMs = if (faceAvailable) 620.0 else -1.0,
            falseAcceptanceRatePct = if (faceAvailable && strongCount > 0) 0.001 else 0.1,
            falseRejectionRatePct = if (faceAvailable) 12.0 else 0.0,
            securityScore = if (faceAvailable && strongCount > 0) 850 else if (faceAvailable) 560 else 200,
        )

        val overall = ((fingerprint.securityScore + face.securityScore) / 2).coerceIn(0, 1000)

        val verdict = when {
            overall >= 800 -> "Strong biometric unlock with low false-acceptance rates."
            overall >= 600 -> "Usable biometrics; prefer fingerprint for security-sensitive apps."
            overall >= 350 -> "Basic biometrics; 2D face unlock has higher spoofing risk."
            else -> "No usable biometric unlock detected."
        }

        return BiometricProfileReport(
            fingerprint = fingerprint,
            face = face,
            overallSecurityScore = overall,
            verdict = verdict,
            limitations = "No real biometric template matching; latency and FAR/FRR modeled per detected biometric hardware class.",
        )
    }
}
