package com.benchsuite.app.features.core

import java.io.File

import com.benchsuite.app.util.*

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import androidx.compose.material.icons.Icons
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.FrameTimeHistogram
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.MetricPill
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.LaunchedEffect
import kotlin.math.roundToInt

/**
 * Storage domain detail screen — covers fragmentation, AI workload, ZRAM, UFS thermal,
 * endurance, app install, small-file metadata.
 */
@Composable
fun StorageDetailScreen(
    subFeature: String, // "fragmentation" | "ai_workload" | "zram" | "ufs_thermal" | "endurance" | "app_install" | "small_file"
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    var fragReport by remember { mutableStateOf<FragReport?>(null) }
    var aiWorkloadReport by remember { mutableStateOf<AiWorkloadReport?>(null) }
    var zramReport by remember { mutableStateOf<ZramReport?>(null) }
    var ufsReport by remember { mutableStateOf<UfsReport?>(null) }
    var enduranceReport by remember { mutableStateOf<EnduranceReport?>(null) }
    var appInstallReport by remember { mutableStateOf<AppInstallReport?>(null) }
    var smallFileReport by remember { mutableStateOf<SmallFileReport?>(null) }

    data class FragReport(val score: Int, val readIops: Double, val writeIops: Double, val penalty: Double, val verdict: String)
    data class AiWorkloadReport(val score: Int, val avgReadIops: Double, val bottleneck: String, val verdict: String)
    data class ZramReport(val score: Int, val ratio: Double, val decompressMs: Double, val verdict: String)
    data class UfsReport(val score: Int, val writeMbps: Double, val throttle: Boolean, val temp: Double, val verdict: String)
    data class EnduranceReport(val score: Int, val monthsRemaining: Int, val tbwUsed: Double, val verdict: String)
    data class AppInstallReport(val score: Int, val avgInstallMs: Double, val avgDexoptMs: Double, val verdict: String)
    data class SmallFileReport(val score: Int, val fileCount: Int, val avgOps: Double, val verdict: String)

    fun runFeature() {
        isLoading = true
        error = null
        val ctx = SessionState.applicationContext
        if (ctx == null) { error = "Context unavailable"; isLoading = false; return }
        scope.launch(Dispatchers.Default) {
            try {
                when (subFeature) {
                    "fragmentation" -> {
                        val r = SessionState.runStorageFragmentation()
                        fragReport = FragReport(r.storageScore, r.randomReadIops, r.randomWriteIops, r.fragmentationPenaltyPct, r.verdict)
                    }
                    "ai_workload" -> {
                        val r = SessionState.runStorageAiWorkload()
                        aiWorkloadReport = AiWorkloadReport(r.overallAiIoScore, r.workloads.averageOf { it.readIops }, r.bottleneck, r.verdict)
                    }
                    "zram" -> {
                        val r = SessionState.runStorageZram()
                        zramReport = ZramReport(r.swapEffectivenessScore, r.compressionRatio, r.decompressionLatencyMs, r.verdict)
                    }
                    "ufs_thermal" -> {
                        val r = SessionState.runStorageUfsThermal()
                        ufsReport = UfsReport(r.ufsThermalScore, r.sustainedWriteMbps, r.throttleDetected, r.peakTempCelsius, r.verdict)
                    }
                    "endurance" -> {
                        val r = SessionState.runStorageEndurance()
                        enduranceReport = EnduranceReport(r.enduranceScore, r.estimatedRemainingMonths, r.wearProbe.tbwUsedPct, r.verdict)
                    }
                    "app_install" -> {
                        val r = SessionState.runStorageAppInstall()
                        appInstallReport = AppInstallReport(r.installScore, r.averageInstallMs, r.averageDexoptMs, r.verdict)
                    }
                    "small_file" -> {
                        val r = SessionState.runStorageSmallFile()
                        smallFileReport = SmallFileReport(r.metadataScore, r.fileCount, r.results.averageOf { it.opsPerSecond }, r.verdict)
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "Storage feature error"
            } finally {
                isLoading = false
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(subFeature) { runFeature() }

    val title = when (subFeature) {
        "fragmentation" -> "Storage Fragmentation Simulator"
        "ai_workload" -> "AI Workload Storage Pattern"
        "zram" -> "ZRAM / Swap Efficiency"
        "ufs_thermal" -> "UFS Controller Thermal Throttle"
        "endurance" -> "Storage Endurance & Wear"
        "app_install" -> "App Install & DEX Optimization"
        "small_file" -> "Small-File Metadata Stress"
        else -> "Storage Feature"
    }

    Column(Modifier.fillMaxSize()) {
        BenchTopBar(title = title, onBack = onBack)

        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            val allNull = fragReport == null && aiWorkloadReport == null && zramReport == null && ufsReport == null &&
                enduranceReport == null && appInstallReport == null && smallFileReport == null
            if (isLoading && allNull) {
                androidx.compose.material3.CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            } else if (error != null) {
                Column(
                    modifier = Modifier.padding(32.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Default.ErrorOutline, null, tint = MaterialTheme.colorScheme.error, Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Error: $error", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { runFeature() }) { Text("Retry") }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = Dimens.screenPadding, end = Dimens.screenPadding, top = 4.dp, bottom = 28.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(Spacing.md),
                ) {
                    item {
                        val score = when {
                            subFeature == "fragmentation" -> fragReport?.score ?: 0
                            subFeature == "ai_workload" -> aiWorkloadReport?.score ?: 0
                            subFeature == "zram" -> zramReport?.score ?: 0
                            subFeature == "ufs_thermal" -> ufsReport?.score ?: 0
                            subFeature == "endurance" -> enduranceReport?.score ?: 0
                            subFeature == "app_install" -> appInstallReport?.score ?: 0
                            subFeature == "small_file" -> smallFileReport?.score ?: 0
                            else -> 0
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterVertically) {
                            ScoreGauge(score = score, gaugeSize = 150.dp, label = title)
                            Spacer(Modifier.weight(1f))
                            Column {
                                Text("Overall Score", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(4.dp))
                                Text(score.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Line chart for IOPS
                    if (subFeature == "fragmentation" && fragReport != null) {
                        item {
                            ChartCard(title = "Random IOPS After Churn", caption = "Simulated 2-year install/delete churn") {
                                LineChart(
                                    points = listOf(8000f, 6500f, 5200f, 4100f, fragReport.readIops.toFloat()),
                                    color = MaterialTheme.colorScheme.secondary,
                                    height = 160.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Fragmentation Penalty: ${"%.1f".format(fragReport.penalty)}%", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    // Histogram for ZRAM
                    if (subFeature == "zram" && zramReport != null) {
                        item {
                            ChartCard(title = "Compression Efficiency", caption = "ZRAM data store vs compressed") {
                                FrameTimeHistogram(
                                    buckets = listOf(
                                        (zramReport.ratio * 100).roundToInt().coerceAtLeast(0).coerceAtMost(300),
                                        (zramReport.ratio * 70).roundToInt().coerceAtLeast(0).coerceAtMost(300),
                                        (zramReport.ratio * 40).roundToInt().coerceAtLeast(0).coerceAtMost(300),
                                        (zramReport.ratio * 20).roundToInt().coerceAtLeast(0).coerceAtMost(300),
                                    ),
                                    height = 160.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spaceBetween) {
                                    Text("Compression Ratio", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${"%.2f".format(zramReport.ratio)}:1", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spaceBetween) {
                                    Text("Decompress Latency", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${"%.1f".format(zramReport.decompressMs)} ms", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }

                    // Metric pills
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        ) {
                            when (subFeature) {
                                "fragmentation" -> {
                                    MetricPill(label = "Read IOPS", value = fragReport?.readIops?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Write IOPS", value = fragReport?.writeIops?.toString() ?: "–", unit = "")
                                }
                                "ai_workload" -> {
                                    MetricPill(label = "Avg Read IOPS", value = aiWorkloadReport?.avgReadIops?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Bottleneck", value = aiWorkloadReport?.bottleneck ?: "–", unit = "")
                                }
                                "zram" -> {
                                    MetricPill(label = "Compression Ratio", value = zramReport?.ratio?.toString() ?: "–", unit = ":1")
                                    MetricPill(label = "Score", value = zramReport?.score?.toString() ?: "–", unit = "")
                                }
                                "ufs_thermal" -> {
                                    MetricPill(label = "Write MB/s", value = ufsReport?.writeMbps?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Peak Temp", value = ufsReport?.temp?.toString() ?: "–", unit = "°C")
                                }
                                "endurance" -> {
                                    MetricPill(label = "Months Remaining", value = enduranceReport?.monthsRemaining?.toString() ?: "–", unit = "")
                                    MetricPill(label = "TBW Used %", value = enduranceReport?.tbwUsed?.toString() ?: "–", unit = "%")
                                }
                                "app_install" -> {
                                    MetricPill(label = "Avg Install MS", value = appInstallReport?.avgInstallMs?.toString() ?: "–", unit = "ms")
                                    MetricPill(label = "Avg DEX MS", value = appInstallReport?.avgDexoptMs?.toString() ?: "–", unit = "ms")
                                }
                                "small_file" -> {
                                    MetricPill(label = "File Count", value = smallFileReport?.fileCount?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Avg Ops/Sec", value = smallFileReport?.avgOps?.toString() ?: "–", unit = "")
                                }
                                else -> {}
                            }
                        }
                    }

                    // Verdict
                    item {
                        SurfaceCard {
                            androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth()) {
                                Text("Verdict", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(6.dp))
                                val verdictText = when {
                                    subFeature == "fragmentation" -> fragReport?.verdict ?: "No data"
                                    subFeature == "ai_workload" -> aiWorkloadReport?.verdict ?: "No data"
                                    subFeature == "zram" -> zramReport?.verdict ?: "No data"
                                    subFeature == "ufs_thermal" -> ufsReport?.verdict ?: "No data"
                                    subFeature == "endurance" -> enduranceReport?.verdict ?: "No data"
                                    subFeature == "app_install" -> appInstallReport?.verdict ?: "No data"
                                    subFeature == "small_file" -> smallFileReport?.verdict ?: "No data"
                                    else -> "No data"
                                }
                                Text(verdictText, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    item {
                        Button(onClick = { runFeature() }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(text = "Re-run Benchmark")
                        }
                    }

                    item {
                        Button(onClick = { onNavigate(Routes.BENCHMARKS) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Text(text = "Back to Benchmarks")
                        }
                    }
                }
            }
        }
    }
}
