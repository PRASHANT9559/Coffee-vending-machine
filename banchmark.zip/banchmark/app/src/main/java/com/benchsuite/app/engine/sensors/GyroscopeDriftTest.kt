package com.benchsuite.app.engine.sensors

import com.benchsuite.app.util.*

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.SystemClock
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 11.5: Gyroscope Drift Test
 *
 * Hold the device still and measure bias and drift over time at multiple temperatures. Drift
 * breaks AR, VR and navigation experiences.
 *
 * Data source: SensorManager gyroscope samples averaged over a still window.
 * Limitations: No temperature control or ground-truth reference; drift modeled from sample
 * variance, not fabricated measured values.
 */
object GyroscopeDriftTest {

    data class GyroSample(
        val timestampMs: Long,
        val x: Double,
        val y: Double,
        val z: Double,
    )

    data class GyroResult(
        val sensorAvailable: Boolean,
        val samples: Int,
        val biasX: Double,
        val biasY: Double,
        val biasZ: Double,
        val driftDegreesPerHour: Double,
        val qualityScore: Int, // 0 - 1000
    )

    data class GyroReport(
        val result: GyroResult,
        val verdict: String,
        val limitations: String,
    )

    private fun collectGyro(context: Context, durationMs: Long): GyroResult {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        if (sensor == null) {
            return GyroResult(false, 0, 0.0, 0.0, 0.0, 0.0, 0)
        }
        val latch = CountDownLatch(1)
        val samples = mutableListOf<GyroSample>()
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                samples.add(GyroSample(System.currentTimeMillis(), event.values[0].toDouble(),
                    event.values[1].toDouble(), event.values[2].toDouble()))
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(listener, sensor, SensorManager.SENSOR_NORMAL)
        try { Thread.sleep(durationMs) } catch (e: InterruptedException) { Thread.currentThread().interrupt() } finally {
            sm.unregisterListener(listener)
        }
        val count = samples.size
        if (count == 0) return GyroResult(true, 0, 0.0, 0.0, 0.0, 0.0, 0)
        val biasX = samples.averageOf { it.x }
        val biasY = samples.averageOf { it.y }
        val biasZ = samples.averageOf { it.z }
        // Drift estimate: RMS bias magnitude converted to deg/hour (rad/s * 57.3 * 3600)
        val rmsBias = kotlin.math.sqrt(biasX * biasX + biasY * biasY + biasZ * biasZ)
        val driftDegPerHr = rmsBias * 57.296 * 3600.0
        val quality = when {
            driftDegPerHr <= 5.0 -> 950
            driftDegPerHr <= 15.0 -> 800
            driftDegPerHr <= 35.0 -> 650
            else -> 450
        }
        return GyroResult(true, count, biasX, biasY, biasZ,
            (driftDegPerHr * 100.0).roundToInt() / 100.0, quality)
    }

    /**
     * Measures gyroscope bias and drift over a still window.
     */
    fun testGyroscopeDrift(context: Context): GyroReport {
        val result = collectGyro(context, 800)
        val verdict = when {
            result.sensorAvailable && result.qualityScore >= 800 -> "Low gyro drift; AR/VR/navigation experiences remain stable."
            result.sensorAvailable -> "Moderate drift; AR may drift over extended sessions."
            else -> "No gyroscope sensor detected."
        }
        return GyroReport(result, verdict,
            "No temperature control or ground-truth reference; drift modeled from sample bias over a short still window.")
    }
}
