package com.benchsuite.app.engine.telemetry

import com.benchsuite.app.data.model.RunConditions
import com.benchsuite.app.data.model.RunRecord
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 17.3: Environment Normalization Score.
 *
 * Mathematically isolates raw silicon performance from external confounding factors
 * (ambient temperature, battery state-of-charge, charging state, and background CPU load)
 * by normalizing raw scores to standard laboratory baseline conditions:
 * - Reference Ambient: 25.0°C
 * - Reference Battery SoC: 80% (disconnected from charger)
 * - Reference Background Load: < 5%
 */
object EnvironmentNormalizer {

    const val REF_TEMPERATURE_C = 25.0
    const val REF_BATTERY_PCT = 80
    const val THERMAL_THROTTLE_THRESHOLD_C = 43.5

    data class NormalizationFactors(
        val thermalFactor: Double,
        val batterySocFactor: Double,
        val chargingFactor: Double,
        val backgroundLoadFactor: Double,
        val compositeMultiplier: Double,
    )

    data class NormalizationResult(
        val rawScore: Int,
        val normalizedScore: Int,
        val multiplier: Double,
        val thermalHeadroomC: Double,
        val environmentalPenaltyPct: Double,
        val factors: NormalizationFactors,
        val conditionNotes: List<String>,
    )

    /**
     * Calculates the normalization multiplier and normalized score for a given [rawScore] and [conditions].
     */
    fun normalize(rawScore: Int, conditions: RunConditions): NormalizationResult {
        // 1. Thermal normalization factor
        // Above 25°C, mobile chassis cooling efficiency drops ~0.8% per °C
        val tempDiff = conditions.batteryTempC - REF_TEMPERATURE_C
        val thermalFactor = if (tempDiff > 0) {
            1.0 + (tempDiff * 0.008) // Device was hotter than lab standard -> score was throttled -> upward correction
        } else {
            1.0 + (tempDiff * 0.004) // Device was chilled cooler than lab standard -> downward adjustment
        }.coerceIn(0.85, 1.25)

        // 2. Battery state-of-charge normalization
        // High battery internal resistance at low charge causes voltage sag and conservative DVFS governors
        val batterySocFactor = when {
            conditions.batteryPct < 15 -> 1.08 // +8% correction for extreme battery saver throttle
            conditions.batteryPct < 25 -> 1.04 // +4% correction for PMIC current capping
            conditions.batteryPct < 40 -> 1.02
            else -> 1.00
        }

        // 3. Charging status normalization
        // Charging delivers 5W-25W heat directly into chassis, inducing premature thermal throttling
        val chargingFactor = if (conditions.charging) {
            1.035 // +3.5% correction for internal Joule charging heat penalty
        } else {
            1.000
        }

        // 4. Background load normalization
        // Excess background threads (>5%) steal compute cycles from benchmark kernels
        val bgSurplus = (conditions.backgroundLoadPct - 5).coerceAtLeast(0)
        val bgFactor = (1.0 + (bgSurplus * 0.004)).coerceAtMost(1.10)

        // Composite Multiplier: M = F_thermal * F_battery * F_charging * F_bg
        val composite = (thermalFactor * batterySocFactor * chargingFactor * bgFactor)
            .coerceIn(0.80, 1.30)

        val normalized = (rawScore * composite).roundToInt().coerceIn(1, 1100)
        val penaltyPct = (((composite - 1.0) * 100.0) * 10.0).roundToInt() / 10.0
        val headroom = max(0.0, (THERMAL_THROTTLE_THRESHOLD_C - conditions.batteryTempC))

        val notes = mutableListOf<String>()
        if (tempDiff > 5.0) {
            notes.add("Elevated temperature (${conditions.batteryTempC}°C vs 25°C ref) imposed a ${(thermalFactor * 100 - 100).roundToInt()}% thermal penalty.")
        } else if (tempDiff < -5.0) {
            notes.add("Cooled environment (${conditions.batteryTempC}°C) provided artificial thermal headroom.")
        }
        if (conditions.charging) {
            notes.add("Active battery charging added internal chassis heat, accelerating DVFS step-down.")
        }
        if (conditions.batteryPct < 25) {
            notes.add("Low battery (${conditions.batteryPct}%) induced PMIC rail voltage-sag mitigation.")
        }
        if (bgSurplus > 10) {
            notes.add("Elevated background tasks (${conditions.backgroundLoadPct}% load) competed for CPU scheduling.")
        }
        if (notes.isEmpty()) {
            notes.add("Execution conditions were within 3% of standardized laboratory reference baselines.")
        }

        return NormalizationResult(
            rawScore = rawScore,
            normalizedScore = normalized,
            multiplier = (composite * 1000.0).roundToInt() / 1000.0,
            thermalHeadroomC = (headroom * 10.0).roundToInt() / 10.0,
            environmentalPenaltyPct = penaltyPct,
            factors = NormalizationFactors(
                thermalFactor = (thermalFactor * 1000.0).roundToInt() / 1000.0,
                batterySocFactor = batterySocFactor,
                chargingFactor = chargingFactor,
                backgroundLoadFactor = (bgFactor * 1000.0).roundToInt() / 1000.0,
                compositeMultiplier = (composite * 1000.0).roundToInt() / 1000.0,
            ),
            conditionNotes = notes,
        )
    }

    /**
     * Normalizes an entire [RunRecord], adjusting overall and subsystem scores while preserving raw values.
     */
    fun normalizeRecord(record: RunRecord): RunRecord {
        val norm = normalize(record.overall, record.conditions)
        val normalizedCategories = record.categories.map { cat ->
            val catNorm = (cat.score * norm.multiplier).roundToInt().coerceIn(1, 1100)
            val peakNorm = (cat.peak * norm.multiplier).roundToInt().coerceIn(catNorm, 1100)
            cat.copy(
                score = catNorm,
                peak = peakNorm,
                sustained = (cat.sustained * norm.multiplier).roundToInt().coerceIn(1, 1100),
            )
        }
        return record.copy(
            overall = norm.normalizedScore,
            peak = (record.peak * norm.multiplier).roundToInt().coerceIn(norm.normalizedScore, 1100),
            sustained = (record.sustained * norm.multiplier).roundToInt().coerceIn(1, 1100),
            categories = normalizedCategories,
            note = "${record.note} · Normalized (x${norm.multiplier} env factor)",
        )
    }
}
