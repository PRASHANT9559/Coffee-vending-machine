package com.benchsuite.app.engine.longevity

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 16.2: OS Update Regression Tracker
 *
 * Captures performance, thermal dissipation, and battery drain snapshots immediately prior to
 * system OTA updates, then automatically re-evaluates post-update to detect regressions.
 *
 * Data source: SharedPreferences snapshot + Build fingerprint/version comparison.
 * Limitations: Requires an actual OTA update between pre/post captures; without one, reports a
 * modeled baseline with documented limitations. No fabricated measured values.
 */
object OsUpdateRegressionTracker {

    private const val PREFS = "benchsuite_regression_tracker"
    private const val KEY_PRE_SCORE = "pre_score"
    private const val KEY_PRE_FINGERPRINT = "pre_fingerprint"
    private const val KEY_PRE_THERMAL = "pre_thermal"
    private const val KEY_PRE_BATTERY = "pre_battery"

    data class Snapshot(
        val fingerprint: String,
        val overallScore: Int,
        val thermalCelsius: Double,
        val batteryDrainMahPerHour: Double,
        val timestampMs: Long,
    )

    data class RegressionReport(
        val preSnapshot: Snapshot?,
        val postSnapshot: Snapshot?,
        val fingerprintChanged: Boolean,
        val scoreDelta: Int,
        val thermalDeltaCelsius: Double,
        val batteryDeltaMahPerHour: Double,
        val regressionDetected: Boolean,
        val regressionScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun saveSnapshot(prefs: SharedPreferences, keyPrefix: String, snapshot: Snapshot) {
        prefs.edit().putString("${keyPrefix}_fingerprint", snapshot.fingerprint)
            .putInt("${keyPrefix}_score", snapshot.overallScore)
            .putFloat("${keyPrefix}_thermal", snapshot.thermalCelsius.toFloat())
            .putFloat("${keyPrefix}_battery", snapshot.batteryDrainMahPerHour.toFloat())
            .putLong("${keyPrefix}_time", snapshot.timestampMs)
            .apply()
    }

    private fun loadSnapshot(prefs: SharedPreferences, keyPrefix: String): Snapshot? {
        val fp = prefs.getString("${keyPrefix}_fingerprint", null) ?: return null
        return Snapshot(
            fingerprint = fp,
            overallScore = prefs.getInt("${keyPrefix}_score", -1),
            thermalCelsius = prefs.getFloat("${keyPrefix}_thermal", 0f).toDouble(),
            batteryDrainMahPerHour = prefs.getFloat("${keyPrefix}_battery", 0f).toDouble(),
            timestampMs = prefs.getLong("${keyPrefix}_time", 0L),
        )
    }

    /**
     * Captures a pre-update baseline snapshot keyed to the current build fingerprint.
     */
    fun captureBaseline(context: Context, overallScore: Int, thermalCelsius: Double, batteryDrainMahPerHour: Double): Snapshot {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val snapshot = Snapshot(
            fingerprint = Build.FINGERPRINT,
            overallScore = overallScore,
            thermalCelsius = thermalCelsius,
            batteryDrainMahPerHour = batteryDrainMahPerHour,
            timestampMs = System.currentTimeMillis(),
        )
        saveSnapshot(prefs, KEY_PRE_SCORE, snapshot)
        return snapshot
    }

    /**
     * Compares the current post-update state against the captured pre-update baseline.
     */
    fun detectRegression(context: Context, currentScore: Int, currentThermalCelsius: Double, currentBatteryDrainMahPerHour: Double): RegressionReport {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pre = loadSnapshot(prefs, KEY_PRE_SCORE)
        val fingerprintChanged = pre == null || pre.fingerprint != Build.FINGERPRINT

        val post = Snapshot(
            fingerprint = Build.FINGERPRINT,
            overallScore = currentScore,
            thermalCelsius = currentThermalCelsius,
            batteryDrainMahPerHour = currentBatteryDrainMahPerHour,
            timestampMs = System.currentTimeMillis(),
        )
        saveSnapshot(prefs, KEY_PRE_SCORE, post) // refresh baseline for next run

        val scoreDelta = if (pre != null) pre.overallScore - currentScore else 0
        val thermalDelta = if (pre != null) currentThermalCelsius - pre.thermalCelsius else 0.0
        val batteryDelta = if (pre != null) currentBatteryDrainMahPerHour - pre.batteryDrainMahPerHour else 0.0
        val regression = scoreDelta >= 50 || thermalDelta >= 5.0 || batteryDelta >= 20.0

        val regressionScore = when {
            pre == null || !fingerprintChanged -> 500 // no baseline comparison possible
            regression -> 280
            scoreDelta >= 0 && thermalDelta < 3.0 -> 900
            else -> 720
        }

        val verdict = when {
            pre == null -> "No pre-update baseline captured yet; run captureBaseline before an OTA."
            !fingerprintChanged -> "Build fingerprint unchanged; no OS update detected between snapshots."
            regression -> "Regression detected post-update: score/thermal/battery degraded."
            else -> "No significant regression detected after OS update."
        }

        return RegressionReport(
            preSnapshot = pre,
            postSnapshot = post,
            fingerprintChanged = fingerprintChanged,
            scoreDelta = scoreDelta,
            thermalDeltaCelsius = (thermalDelta * 10.0).roundToInt() / 10.0,
            batteryDeltaMahPerHour = (batteryDelta * 100.0).roundToInt() / 100.0,
            regressionDetected = regression,
            regressionScore = regressionScore.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "Requires an actual OTA update between pre/post captures; without one, reports a modeled baseline with no regression comparison.",
        )
    }
}
