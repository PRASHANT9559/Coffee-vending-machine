package com.benchsuite.app.engine.stability

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 12.4: Long Gaming Session Stability Engine.
 *
 * Evaluates performance endurance across extended gaming sessions:
 * - Computes Peak FPS vs Sustained FPS and overall Stability Ratio
 * - Calculates 95% Low and 99% Low Frame Pacing
 * - Identifies discrete DVFS governor step-down events on the session timeline
 * - Correlates thermal ramp curves with frame-rate degradation
 */
object GamingStabilityEngine {

    enum class GamingStabilityTier(val label: String, val minRatioPct: Double) {
        ELITE("Elite Consistency (>90% Sustained)", 90.0),
        GOOD("Good Stability (80%–89%)", 80.0),
        MODERATE("Moderate Throttling (65%–79%)", 65.0),
        UNSTABLE("Severe Throttling (<65%)", 0.0),
    }

    data class GamingSample(
        val timestampSec: Int,
        val fps: Double,
        val frameTimeMs: Double,
        val temperatureC: Double,
        val powerW: Double = 0.0,
        val gpuClockMhz: Int = 0,
    )

    data class ThrottlingStepEvent(
        val timestampSec: Int,
        val previousFps: Double,
        val newFps: Double,
        val dropPct: Double,
        val temperatureC: Double,
        val note: String,
    )

    data class GamingStabilityReport(
        val totalSessionDurationSec: Int,
        val sampleCount: Int,
        val peakFps: Double,
        val sustainedFps: Double,
        val averageFps: Double,
        val stabilityRatioPct: Double,
        val fps95Low: Double,
        val fps99Low: Double,
        val stabilityTier: GamingStabilityTier,
        val throttlingEvents: List<ThrottlingStepEvent>,
        val timeToFirstThrottleSec: Int?,
        val peakTemperatureC: Double,
        val temperatureRampC: Double,
        val verdict: String,
        val recommendations: List<String>,
    )

    /**
     * Analyzes time-series [samples] recorded during an active gaming workload.
     */
    fun analyze(samples: List<GamingSample>): GamingStabilityReport {
        if (samples.isEmpty()) {
            return emptyReport()
        }

        val totalDuration = samples.last().timestampSec - samples.first().timestampSec
        val fpsValues = samples.map { it.fps }
        val sortedFps = fpsValues.sorted()

        // 1. Peak FPS: average of the top 10% highest stable frames
        val top10Count = max(1, (sortedFps.size * 0.10).roundToInt())
        val peakFps = sortedFps.takeLast(top10Count).average()

        // 2. Sustained FPS: average of the final 25% of the session
        val final25Count = max(1, (samples.size * 0.25).roundToInt())
        val sustainedFps = samples.takeLast(final25Count).map { it.fps }.average()

        // 3. Overall average FPS
        val avgFps = fpsValues.average()

        // 4. Stability Ratio: sustained / peak
        val stabilityRatio = if (peakFps > 0.0) {
            ((sustainedFps / peakFps) * 1000.0).roundToInt() / 10.0
        } else {
            100.0
        }

        // 5. Percentile Lows
        // 95% Low FPS = 5th percentile of frame rates
        // 99% Low FPS = 1st percentile of frame rates
        val fps95Low = percentile(sortedFps, 5.0)
        val fps99Low = percentile(sortedFps, 1.0)

        // 6. Thermals
        val peakTemp = samples.maxOfOrNull { it.temperatureC } ?: 30.0
        val initialTemp = samples.firstOrNull()?.temperatureC ?: 30.0
        val tempRamp = max(0.0, peakTemp - initialTemp)

        // 7. Throttling step-down timeline events
        val events = detectStepDownEvents(samples)
        val timeToFirstThrottle = events.firstOrNull()?.timestampSec

        val tier = when {
            stabilityRatio >= GamingStabilityTier.ELITE.minRatioPct -> GamingStabilityTier.ELITE
            stabilityRatio >= GamingStabilityTier.GOOD.minRatioPct -> GamingStabilityTier.GOOD
            stabilityRatio >= GamingStabilityTier.MODERATE.minRatioPct -> GamingStabilityTier.MODERATE
            else -> GamingStabilityTier.UNSTABLE
        }

        val verdict = when (tier) {
            GamingStabilityTier.ELITE -> "Elite gaming stability. Sustained frame rates held steady at ${stabilityRatio.roundToInt()}% of peak with zero meaningful thermal throttling."
            GamingStabilityTier.GOOD -> "Good gaming performance. Minor frame rate step-down observed after ${timeToFirstThrottle?.let { "${it / 60}m" } ?: "the initial phase"} as device warmed up."
            GamingStabilityTier.MODERATE -> "Moderate thermal throttling. Frame rates dropped by ${(100 - stabilityRatio).roundToInt()}% during extended play; 1% lows dipped to ${(fps99Low * 10).roundToInt() / 10.0} FPS."
            GamingStabilityTier.UNSTABLE -> "Severe thermal collapse. Sustained output declined to ${stabilityRatio.roundToInt()}% of peak. Expect noticeable stuttering in extended sessions."
        }

        val recs = mutableListOf<String>()
        if (stabilityRatio < 80.0) {
            recs.add("Lock game display refresh to 60Hz or enable in-game dynamic resolution scaling (FSR) to eliminate thermal step-downs.")
        }
        if (peakTemp > 42.0) {
            recs.add("Peak surface temperature reached ${(peakTemp * 10).roundToInt() / 10.0}°C. A magnetic Peltier phone cooler or removing thick phone cases will prevent DVFS throttling.")
        }
        if (fps99Low < 40.0 && avgFps >= 60.0) {
            recs.add("Noticeable frame pacing spikes detected (99% Low at ${(fps99Low * 10).roundToInt() / 10.0} FPS). Close background streaming or chat apps to reduce micro-stutters.")
        }
        if (recs.isEmpty()) {
            recs.add("Hardware thermal cooling is well-matched to continuous GPU gaming load.")
        }

        return GamingStabilityReport(
            totalSessionDurationSec = max(1, totalDuration),
            sampleCount = samples.size,
            peakFps = (peakFps * 10.0).roundToInt() / 10.0,
            sustainedFps = (sustainedFps * 10.0).roundToInt() / 10.0,
            averageFps = (avgFps * 10.0).roundToInt() / 10.0,
            stabilityRatioPct = stabilityRatio,
            fps95Low = (fps95Low * 10.0).roundToInt() / 10.0,
            fps99Low = (fps99Low * 10.0).roundToInt() / 10.0,
            stabilityTier = tier,
            throttlingEvents = events,
            timeToFirstThrottleSec = timeToFirstThrottle,
            peakTemperatureC = (peakTemp * 10.0).roundToInt() / 10.0,
            temperatureRampC = (tempRamp * 10.0).roundToInt() / 10.0,
            verdict = verdict,
            recommendations = recs,
        )
    }

    private fun detectStepDownEvents(samples: List<GamingSample>): List<ThrottlingStepEvent> {
        val events = mutableListOf<ThrottlingStepEvent>()
        if (samples.size < 12) return events

        // Use rolling 30-second windows (or ~6 samples) to detect steady downward steps
        val windowSize = max(3, samples.size / 15)
        var baselineFps = samples.take(windowSize).map { it.fps }.average()

        var i = windowSize
        while (i <= samples.size - windowSize) {
            val windowFps = samples.subList(i, i + windowSize).map { it.fps }.average()
            val dropPct = (baselineFps - windowFps) / baselineFps * 100.0

            if (dropPct >= 10.0) { // Significant 10%+ step-down detected
                val sampleAtEvent = samples[i]
                events.add(
                    ThrottlingStepEvent(
                        timestampSec = sampleAtEvent.timestampSec,
                        previousFps = (baselineFps * 10.0).roundToInt() / 10.0,
                        newFps = (windowFps * 10.0).roundToInt() / 10.0,
                        dropPct = (dropPct * 10.0).roundToInt() / 10.0,
                        temperatureC = sampleAtEvent.temperatureC,
                        note = "Governor step-down at t=${sampleAtEvent.timestampSec}s: ${(baselineFps).roundToInt()} → ${(windowFps).roundToInt()} FPS (-${dropPct.roundToInt()}%) as temperature reached ${sampleAtEvent.temperatureC}°C.",
                    )
                )
                // Reset baseline to new window level
                baselineFps = windowFps
                i += windowSize // skip past the transition
            } else {
                i++
            }
        }
        return events
    }

    private fun percentile(sorted: List<Double>, p: Double): Double {
        if (sorted.isEmpty()) return 0.0
        val idx = (p / 100.0 * (sorted.size - 1))
        val lower = idx.toInt()
        val frac = idx - lower
        return if (lower + 1 < sorted.size) {
            sorted[lower] + frac * (sorted[lower + 1] - sorted[lower])
        } else {
            sorted[lower]
        }
    }

    private fun emptyReport() = GamingStabilityReport(
        totalSessionDurationSec = 0,
        sampleCount = 0,
        peakFps = 0.0,
        sustainedFps = 0.0,
        averageFps = 0.0,
        stabilityRatioPct = 100.0,
        fps95Low = 0.0,
        fps99Low = 0.0,
        stabilityTier = GamingStabilityTier.GOOD,
        throttlingEvents = emptyList(),
        timeToFirstThrottleSec = null,
        peakTemperatureC = 0.0,
        temperatureRampC = 0.0,
        verdict = "No gaming session telemetry provided.",
        recommendations = emptyList(),
    )
}
