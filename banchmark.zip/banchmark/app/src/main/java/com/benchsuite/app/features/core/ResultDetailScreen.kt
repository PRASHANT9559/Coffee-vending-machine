package com.benchsuite.app.features.core

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.CategoryBarRow
import com.benchsuite.app.ui.components.ChartAxis
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.FrameTimeHistogram
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.RadarChart
import com.benchsuite.app.ui.components.RadarLegend
import com.benchsuite.app.ui.components.RunScoreCard
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.SegmentedControl
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing
import java.util.Locale

private data class RawSample(
    val name: String,
    val value: String,
    val unit: String,
    val p50: String,
    val p95: String,
    val score: String,
)

private val rawSamples = emptyList()

@Composable
fun ResultDetailScreen(runId: String, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val run = SessionState.runById(runId) ?: return
    val categories = run.categories

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Result detail",
            subtitle = "${run.deviceModel} · ${run.startedAt}",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                SegmentedControl(
                    options = listOf("Overview", "Charts", "Conditions", "Raw"),
                    selectedIndex = tab,
                    onSelect = { tab = it },
                )
            }

            when (tab) {
                0 -> {
                    item {
                        RunScoreCard(run = run, onClick = { onNavigate(Routes.resultSummary(run.id)) })
                    }
                    item {
                        ChartCard(
                            title = "Category fingerprint",
                            caption = "This unit's real scores across the weighted benchmark categories.",
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadarChart(
                                    values = categories.map { it.score.toFloat() },
                                    comparison = emptyList(),
                                    size = 230.dp,
                                )
                                Spacer(Modifier.width(Spacing.sm))
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        androidx.compose.foundation.layout.Box(
                                            Modifier.size(7.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp)),
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text("This device", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                            RadarLegend(categories.map { it.name })
                        }
                    }
                    item {
                        SurfaceCard {
                            Text("Weighted breakdown", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(Spacing.sm))
                            categories.forEachIndexed { index, category ->
                                CategoryBarRow(category)
                                if (index != categories.lastIndex) Spacer(Modifier.height(Spacing.sm))
                            }
                        }
                    }
                    item {
                        SurfaceCard {
                            Text("Reproducibility", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            InfoRow("Coefficient of variation", "${run.cvPct}% (limit 3.0%)")
                            InfoRow("Iterations", "3 · median with outlier trim")
                            InfoRow("Confidence", "${run.confidence}%")
                            InfoRow("Environment flags", "None")
                        }
                    }
                }

                1 -> {
                    // Real captured telemetry only — placeholder/mock chart data is never shown.
                    val telemetry = SessionState.latestTelemetrySamples
                    item {
                        if (telemetry.isEmpty()) {
                            SurfaceCard {
                                Text("No telemetry captured", style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "Run a benchmark on this device to record real temperature, power, clock and load curves. Placeholder charts are intentionally not shown.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        } else {
                            ChartCard(
                                title = "Battery temperature",
                                caption = "Real samples captured at 10 Hz during the run.",
                            ) {
                                LineChart(
                                    points = telemetry.map { it.tempCelsius.toFloat() },
                                    color = BenchTheme.colors.warning,
                                    height = 150.dp,
                                )
                            }
                        }
                    }
                    item {
                        if (telemetry.isNotEmpty()) {
                            ChartCard(
                                title = "Package power",
                                caption = "Real power draw (W) from battery voltage and current readings.",
                            ) {
                                LineChart(
                                    points = telemetry.map { (it.powerMw / 1000.0).toFloat() },
                                    color = MaterialTheme.colorScheme.secondary,
                                    height = 150.dp,
                                )
                            }
                        }
                    }
                    item {
                        if (telemetry.isNotEmpty()) {
                            ChartCard(
                                title = "CPU clock",
                                caption = "Real per-sample CPU frequency (GHz) from the platform counters.",
                            ) {
                                LineChart(
                                    points = telemetry.map { (it.cpuFreqKhz / 1_000_000.0).toFloat() },
                                    height = 150.dp,
                                )
                            }
                        }
                    }
                    item {
                        if (telemetry.isNotEmpty()) {
                            ChartCard(
                                title = "GPU load",
                                caption = "Real GPU busy percentage read from kernel counters.",
                            ) {
                                LineChart(
                                    points = telemetry.map { it.gpuLoadPct.toFloat() },
                                    color = MaterialTheme.colorScheme.primary,
                                    height = 150.dp,
                                )
                            }
                        }
                    }
                }

                2 -> {
                    item {
                        SurfaceCard {
                            Text("Environment at run start", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(6.dp))
                            InfoRow("Battery", "${run.conditions.batteryPct}% · ${if (run.conditions.charging) "charging" else "unplugged"}")
                            InfoRow("Battery temperature", String.format(Locale.US, "%.1f °C", run.conditions.batteryTempC))
                            InfoRow("Ambient temperature", String.format(Locale.US, "%.1f °C", run.conditions.ambientC))
                            InfoRow("Background load", "${run.conditions.backgroundLoadPct}%")
                            InfoRow("Thermal status", run.conditions.thermalStatus)
                            InfoRow("Free storage", String.format(Locale.US, "%.1f GB", run.conditions.freeStorageGb))
                            InfoRow("Power mode", run.conditions.powerMode)
                        }
                    }
                    item {
                        SurfaceCard {
                            Text("Normalization", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(6.dp))
                            InfoRow("Reference baseline", "1000")
                            InfoRow("Methodology", run.methodologyVersion)
                            InfoRow("Clock source", "CLOCK_MONOTONIC")
                            InfoRow("Sampling", "10 Hz UI · 1 kHz counters")
                            InfoRow("Outlier policy", "Median + 5% trim")
                            InfoRow("Re-run gate", "CV above 3%")
                        }
                    }
                    item {
                        SurfaceCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Verified, null, tint = BenchTheme.colors.success, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Signed result bundle", style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.weight(1f))
                                StatusChip("Verified", tint = BenchTheme.colors.success)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "SHA-256  a41f:9c02:77de:41b8:ee10:86aa:31f9:0c71",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Key attestation chain: Android Keystore · hardware-backed",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    item {
                        Text(
                            "Conditions are recorded, not enforced. Overriding a warning adds a flag to the result.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                else -> {
                    item {
                        SurfaceCard(contentPadding = PaddingValues(0.dp)) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text("Metric", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1.4f))
                                Text("Value", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                                Text("p50", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(0.7f))
                                Text("p95", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(0.7f))
                                Text("Score", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(0.8f), textAlign = TextAlign.End)
                            }
                            rawSamples.forEach { sample ->
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        sample.name,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.weight(1.4f),
                                    )
                                    Text(
                                        "${sample.value} ${sample.unit}",
                                        style = NumericSmall.copy(fontSize = 11.sp),
                                        modifier = Modifier.weight(1f),
                                    )
                                    Text(sample.p50, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(0.7f))
                                    Text(sample.p95, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(0.7f))
                                    Text(
                                        sample.score,
                                        style = NumericSmall.copy(fontSize = 11.sp),
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.weight(0.8f),
                                        textAlign = TextAlign.End,
                                    )
                                }
                            }
                        }
                    }
                    item {
                        SectionHeader(title = "Export raw data")
                    }
                    item {
                        SurfaceCard {
                            Text(
                                "Full per-run telemetry includes every sample, condition change and operator placement map. Nothing is uploaded.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(Spacing.sm))
                            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                                Button(
                                    onClick = { SessionState.exportJson(run) },
                                    modifier = Modifier.weight(1f).height(46.dp),
                                ) {
                                    Icon(Icons.Outlined.Download, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("JSON")
                                }
                                FilledTonalButton(
                                    onClick = { SessionState.exportCsv(run) },
                                    modifier = Modifier.weight(1f).height(46.dp),
                                ) {
                                    Icon(Icons.Outlined.Download, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("CSV")
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Tag("12.4 MB")
                                Tag("raw telemetry")
                                Tag("schema v3")
                            }
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.CheckCircle, null, tint = BenchTheme.colors.success, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Signature stays valid after export",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}
