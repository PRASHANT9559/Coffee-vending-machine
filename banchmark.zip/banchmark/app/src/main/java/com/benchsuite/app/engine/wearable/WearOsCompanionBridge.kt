package com.benchsuite.app.engine.wearable

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Feature 22.5: Wear OS Companion Bridge.
 *
 * Implements:
 * - Real-time telemetry streaming (battery temperature, charging rate, CPU clock throttling,
 *   active test phase, and progress 0–100%) to paired Wear OS smartwatches.
 * - High-priority wrist haptic vibration and notifications on thermal throttling triggers
 *   and benchmark completion.
 * - Bidirectional remote command dispatch: Start, Pause, Abort from wrist UI.
 * - Google Play Services Wearable Data Layer (`DataClient` / `MessageClient`) sync with
 *   dynamic runtime binding and offline telemetry queueing.
 * - Universal `NotificationCompat.WearableExtender` fallback for all smartwatches.
 */
object WearOsCompanionBridge {

    // Wear Data Layer URI Paths
    const val PATH_TELEMETRY_STREAM = "/benchsuite/telemetry/stream"
    const val PATH_THERMAL_ALERT = "/benchsuite/alert/thermal"
    const val PATH_COMPLETION_ALERT = "/benchsuite/alert/completion"
    const val PATH_REMOTE_COMMAND = "/benchsuite/command/control"

    private const val NOTIFICATION_CHANNEL_ID = "benchsuite_wearable_channel"
    private const val NOTIFICATION_ID_PROGRESS = 4401
    private const val NOTIFICATION_ID_ALERT = 4402

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    @Serializable
    data class TelemetryStreamPacket(
        val timestampMs: Long,
        val activeBenchmarkName: String,
        val progressPercentage: Int,
        val batteryTemperatureCelsius: Double,
        val junctionTemperatureCelsius: Double,
        val currentFps: Double,
        val batteryLevelPct: Int,
        val isThermalThrottling: Boolean,
        val estimatedRemainingSeconds: Int,
    )

    @Serializable
    enum class AlertSeverity {
        INFO,
        WARNING_THERMAL_THROTTLE,
        CRITICAL_OVERHEAT,
        COMPLETION,
    }

    @Serializable
    data class WristAlertPacket(
        val timestampMs: Long,
        val severity: AlertSeverity,
        val title: String,
        val message: String,
        val hapticPattern: String = "HEAVY_DOUBLE_PULSE",
        val deviceTempC: Double,
    )

    @Serializable
    enum class WearCommandType {
        START_QUICK_TEST,
        PAUSE_TEST,
        RESUME_TEST,
        ABORT_TEST,
        REQUEST_DEVICE_STATUS,
    }

    @Serializable
    data class WearCommandPacket(
        val commandId: String,
        val command: WearCommandType,
        val senderNodeId: String,
        val timestampMs: Long,
    )

    @Serializable
    data class BridgeConnectionStatus(
        val isPlayServicesWearableAvailable: Boolean,
        val connectedNodesCount: Int,
        val connectedNodeNames: List<String>,
        val queuedPacketsCount: Int,
        val lastSyncTimestampMs: Long,
    )

    // In-memory offline buffer for streaming packets when disconnected
    private val offlinePacketQueue = ConcurrentLinkedQueue<TelemetryStreamPacket>()
    private val isSyncing = AtomicBoolean(false)
    private var lastSyncTimeMs: Long = 0L

    // Remote command listener callback
    var onCommandReceivedListener: ((WearCommandPacket) -> Unit)? = null

    /**
     * Initializes notification channels and probes Google Play Services Wearable availability.
     */
    fun initialize(context: Context): BridgeConnectionStatus {
        createNotificationChannel(context)
        return checkConnectionStatus(context)
    }

    /**
     * Streams live telemetry to paired smartwatches.
     */
    fun streamTelemetry(context: Context, packet: TelemetryStreamPacket) {
        lastSyncTimeMs = System.currentTimeMillis()

        // 1. Try Google Play Services Wearable DataClient via reflection
        val gmsSent = sendGmsDataMap(context, PATH_TELEMETRY_STREAM, json.encodeToString(packet).toByteArray(Charsets.UTF_8))

        if (!gmsSent) {
            // Buffer in offline queue (up to 60 samples)
            offlinePacketQueue.add(packet)
            while (offlinePacketQueue.size > 60) {
                offlinePacketQueue.poll()
            }
        } else {
            // Drain offline queue upon successful link
            drainOfflineQueue(context)
        }

        // 2. Synchronize via ongoing Android WearableExtender Notification
        updateWearNotification(context, packet)
    }

    /**
     * Sends immediate wrist alert for thermal throttling or test completion.
     */
    fun sendWristAlert(context: Context, alert: WristAlertPacket) {
        val payload = json.encodeToString(alert).toByteArray(Charsets.UTF_8)
        val path = if (alert.severity == AlertSeverity.COMPLETION) PATH_COMPLETION_ALERT else PATH_THERMAL_ALERT

        // 1. Try GMS Wearable MessageClient
        sendGmsMessage(context, path, payload)

        // 2. Trigger local haptic pulse
        triggerLocalHapticAlert(context, alert.severity)

        // 3. Post high-priority alert notification with WearableExtender
        postWearAlertNotification(context, alert)
    }

    /**
     * Dispatches an incoming remote command from smartwatch to the active session.
     */
    fun handleIncomingRemoteCommand(rawJson: String) {
        try {
            val cmd = json.decodeFromString<WearCommandPacket>(rawJson)
            onCommandReceivedListener?.invoke(cmd)
        } catch (_: Exception) {}
    }

    /**
     * Probes wearable connection status.
     */
    fun checkConnectionStatus(context: Context): BridgeConnectionStatus {
        val hasGmsWearable = isGmsWearablePresent()
        val connectedNodes = if (hasGmsWearable) queryConnectedGmsNodes(context) else emptyList()

        return BridgeConnectionStatus(
            isPlayServicesWearableAvailable = hasGmsWearable,
            connectedNodesCount = connectedNodes.size,
            connectedNodeNames = connectedNodes,
            queuedPacketsCount = offlinePacketQueue.size,
            lastSyncTimestampMs = lastSyncTimeMs
        )
    }

    // ========================================================================
    // NOTIFICATION & WEARABLE EXTENDER INTEGRATION
    // ========================================================================

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "BenchSuite Wearable Sync",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Streams real-time benchmark progress and thermal status to Wear OS smartwatches"
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun updateWearNotification(context: Context, packet: TelemetryStreamPacket) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val wearExtender = NotificationCompat.WearableExtender()
            .setContentIcon(android.R.drawable.ic_dialog_info)
            .setHintHideIcon(false)

        val title = "BenchSuite: ${packet.activeBenchmarkName}"
        val content = "${packet.progressPercentage}% | ${"%.1f".format(packet.batteryTemperatureCelsius)}°C | ${"%.1f".format(packet.currentFps)} FPS"

        val notification = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(content)
            .setProgress(100, packet.progressPercentage, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .extend(wearExtender)
            .build()

        nm.notify(NOTIFICATION_ID_PROGRESS, notification)
    }

    private fun postWearAlertNotification(context: Context, alert: WristAlertPacket) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val wearExtender = NotificationCompat.WearableExtender()
            .setHintShowBackgroundOnly(false)

        val priority = if (alert.severity == AlertSeverity.CRITICAL_OVERHEAT) {
            NotificationCompat.PRIORITY_MAX
        } else {
            NotificationCompat.PRIORITY_HIGH
        }

        val notification = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(alert.title)
            .setContentText(alert.message)
            .setPriority(priority)
            .setAutoCancel(true)
            .extend(wearExtender)
            .build()

        nm.notify(NOTIFICATION_ID_ALERT, notification)
    }

    private fun triggerLocalHapticAlert(context: Context, severity: AlertSeverity) {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (!vibrator.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = when (severity) {
                    AlertSeverity.CRITICAL_OVERHEAT ->
                        VibrationEffect.createWaveform(longArrayOf(0, 300, 100, 300, 100, 600), -1)
                    AlertSeverity.WARNING_THERMAL_THROTTLE ->
                        VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1)
                    AlertSeverity.COMPLETION ->
                        VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE)
                    else -> null
                }
                if (effect != null) {
                    vibrator.vibrate(effect)
                }
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(250)
            }
        } catch (_: Exception) {}
    }

    // ========================================================================
    // GOOGLE PLAY SERVICES WEARABLE DYNAMIC BINDING
    // ========================================================================

    private fun isGmsWearablePresent(): Boolean {
        return try {
            Class.forName("com.google.android.gms.wearable.Wearable")
            true
        } catch (_: ClassNotFoundException) {
            false
        }
    }

    private fun sendGmsDataMap(context: Context, path: String, payload: ByteArray): Boolean {
        return try {
            val wearableClass = Class.forName("com.google.android.gms.wearable.Wearable")
            val getDataClientMethod = wearableClass.getMethod("getDataClient", Context::class.java)
            val dataClient = getDataClientMethod.invoke(null, context)

            val putDataMapReqClass = Class.forName("com.google.android.gms.wearable.PutDataMapRequest")
            val createMethod = putDataMapReqClass.getMethod("create", String::class.java)
            val putDataMapReq = createMethod.invoke(null, path)

            val getDataMapMethod = putDataMapReqClass.getMethod("getDataMap")
            val dataMap = getDataMapMethod.invoke(putDataMapReq)

            val putByteArrayMethod = dataMap.javaClass.getMethod("putByteArray", String::class.java, ByteArray::class.java)
            putByteArrayMethod.invoke(dataMap, "payload", payload)

            val asPutDataReqMethod = putDataMapReqClass.getMethod("asPutDataRequest")
            val putDataReq = asPutDataReqMethod.invoke(putDataMapReq)

            val setUrgentMethod = putDataReq.javaClass.getMethod("setUrgent")
            setUrgentMethod.invoke(putDataReq)

            val putDataItemMethod = dataClient.javaClass.getMethod("putDataItem", putDataReq.javaClass)
            putDataItemMethod.invoke(dataClient, putDataReq)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun sendGmsMessage(context: Context, path: String, payload: ByteArray): Boolean {
        return try {
            val wearableClass = Class.forName("com.google.android.gms.wearable.Wearable")
            val getMessageClientMethod = wearableClass.getMethod("getMessageClient", Context::class.java)
            val messageClient = getMessageClientMethod.invoke(null, context)

            // Broadcast to all nodes
            val sendMessageMethod = messageClient.javaClass.getMethod(
                "sendMessage",
                String::class.java,
                String::class.java,
                ByteArray::class.java
            )
            sendMessageMethod.invoke(messageClient, "*", path, payload)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun queryConnectedGmsNodes(context: Context): List<String> {
        val names = mutableListOf<String>()
        try {
            val wearableClass = Class.forName("com.google.android.gms.wearable.Wearable")
            val getNodeClientMethod = wearableClass.getMethod("getNodeClient", Context::class.java)
            val nodeClient = getNodeClientMethod.invoke(null, context)
            val getConnectedNodesMethod = nodeClient.javaClass.getMethod("getConnectedNodes")
            val task = getConnectedNodesMethod.invoke(nodeClient)
            // If completed, extract nodes
            val isCompleteMethod = task.javaClass.getMethod("isSuccessful")
            if (isCompleteMethod.invoke(task) == true) {
                val getResultMethod = task.javaClass.getMethod("getResult")
                val nodes = getResultMethod.invoke(task) as? Iterable<*>
                if (nodes != null) {
                    for (node in nodes) {
                        val getDisplayName = node?.javaClass?.getMethod("getDisplayName")
                        val name = getDisplayName?.invoke(node) as? String
                        if (name != null) names.add(name)
                    }
                }
            }
        } catch (_: Exception) {}
        return names
    }

    private fun drainOfflineQueue(context: Context) {
        while (!offlinePacketQueue.isEmpty()) {
            val p = offlinePacketQueue.poll() ?: break
            sendGmsDataMap(context, PATH_TELEMETRY_STREAM, json.encodeToString(p).toByteArray(Charsets.UTF_8))
        }
    }
}
