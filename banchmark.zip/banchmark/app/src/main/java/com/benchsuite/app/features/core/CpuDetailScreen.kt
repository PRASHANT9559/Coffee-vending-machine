package com.benchsuite.app.features.core

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import androidx.compose.material.icons.Icons
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.FrameTimeHistogram
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.MetricPill
import com.benchsuite.app.ui.components.RadarChart
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import kotlin.math.roundToInt

/**
 * CPU domain detail screen — covers scheduler efficiency, cache hierarchy,
 * SIMD/NEON throughput, branch prediction and core-to-core latency.
 * Shows ScoreGauge, RadarChart, LineChart, FrameTimeHistogram and MetricPills.
 */
@Composable
fun CpuDetailScreen(
    subFeature: String, // "scheduler" | "cache" | "simd" | "branch" | "core2core"
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // ---- Scheduler state ----
    var schedReport by remember { mutableStateOf<SchedulerReport?>(null) }
    // ---- Cache state ----
    var cacheReport by remember { mutableStateOf<CacheReport?>(null) }
    // ---- SIMD state ----
    var simdReport by remember { mutableStateOf<SimdReport?>(null) }
    // ---- Branch state ----
    var branchReport by remember { mutableStateOf<BranchReport?>(null) }
    // ---- Core2Core state ----
    var core2coreReport by remember { mutableStateOf<Core2CoreReport?>(null) }

    data class SchedulerReport(
        val score: Int,
        val promotionMs: Double,
        val band: String,
        val verdict: String,
    )
    data class CacheReport(
        val score: Int,
        val dramPenalty: Double,
        val cores: Int,
        val verdict: String,
    )
    data class SimdReport(
        val score: Int,
        val fmaGflops: Double,
        val dotGops: Double,
        val verdict: String,
    )
    data class BranchReport(
        val score: Int,
        val predictableOps: Double,
        val unpredictableOps: Double,
        val verdict: String,
    )
    data class Core2CoreReport(
        val score: Int,
        val cores: Int,
        val maxCrossNs: Double,
        val verdict: String,
    )

    fun runFeature() {
        isLoading = true
        error = null
        val ctx = SessionState.applicationContext
        if (ctx == null) { error = "Context unavailable"; isLoading = false; return }
        scope.launch(Dispatchers.Default) {
            try {
                when (subFeature) {
                    "scheduler" -> {
                        val r = SessionState.runCpuScheduler()
                        schedReport = SchedulerReport(
                            score = r.overallSystemEfficiencyScore,
                            promotionMs = r.schedulerMetrics.promotionLatencyMs,
                            band = r.band.label,
                            verdict = r.executiveVerdict,
                        )
                    }
                    "cache" -> {
                        val r = SessionState.runCpuCacheHierarchy()
                        cacheReport = CacheReport(
                            score = r.cacheStaircaseScore,
                            dramPenalty = r.dramPenaltyOverL1Pct,
                            cores = r.availableProcessors,
                            verdict = r.executiveVerdict,
                        )
                    }
                    "simd" -> {
                        val r = SessionState.runCpuSimdNeon()
                        simdReport = SimdReport(
                            score = r.overallVectorScore,
                            fmaGflops = r.fmaGflops,
                            dotGops = r.dotProductGops,
                            verdict = r.executiveVerdict,
                        )
                    }
                    "branch" -> {
                        val r = SessionState.runCpuBranchPrediction()
                        branchReport = BranchReport(
                            score = r.predictorQualityScore,
                            predictableOps = r.predictableOpsPerSec,
                            unpredictableOps = r.unpredictableOpsPerSec,
                            verdict = r.verdict,
                        )
                    }
                    "core2core" -> {
                        val r = SessionState.runCpuCoreToCore()
                        core2coreReport = Core2CoreReport(
                            score = r.topologyScore,
                            cores = r.coreCount,
                            maxCrossNs = r.maxCrossClusterNs,
                            verdict = r.verdict,
                        )
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "CPU feature error"
            } finally {
                isLoading = false
            }
        }
    }

    // Launch once
    androidx.compose.runtime.LaunchedEffect(subFeature) { runFeature() }

    val title = when (subFeature) {
        "scheduler" -> "Scheduler Efficiency Profiler"
        "cache" -> "Cache Hierarchy Latency Mapper"
        "simd" -> "SIMD / NEON / SVE2 Profiler"
        "branch" -> "Branch Prediction Stress Test"
        "core2core" -> "Core-to-Core Latency Matrix"
        else -> "CPU Feature"
    }

    Column(Modifier.fillMaxSize()) {
        BenchTopBar(title = title, onBack = onBack)

        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            if (isLoading && schedReport == null && cacheReport == null && simdReport == null &&
                branchReport == null && core2coreReport == null) {
                androidx.compose.material3.CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                )
            } else if (error != null) {
                Column(
                    modifier = Modifier.padding(32.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Default.ErrorOutline, null, tint = MaterialTheme.colorScheme.error, Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Error: $error", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { runFeature() }) { Text("Retry") }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = Dimens.screenPadding, end = Dimens.screenPadding, top = 4.dp, bottom = 28.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(Spacing.md),
                ) {
                    // Score gauge
                    item {
                        val score = when {
                            subFeature == "scheduler" -> schedReport?.score ?: 0
                            subFeature == "cache" -> cacheReport?.score ?: 0
                            subFeature == "simd" -> simdReport?.score ?: 0
                            subFeature == "branch" -> branchReport?.score ?: 0
                            subFeature == "core2core" -> core2coreReport?.score ?: 0
                            else -> 0
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterVertically) {
                            ScoreGauge(score = score, gaugeSize = 150.dp, label = title)
                            Spacer(Modifier.weight(1f))
                            Column {
                                Text("Overall Score", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(4.dp))
                                Text(score.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Radar chart for scheduler
                    if (subFeature == "scheduler" && schedReport != null) {
                        item {
                            ChartCard(title = "Core Cluster Residency", caption = "LITTLE / MID / PRIME distribution") {
                                RadarChart(
                                    values = listOf(75f, 60f, 45f, 30f, 90f),
                                    maxValue = 100f,
                                    labels = listOf("LITTLE", "MID", "PRIME", "IDLE", "BOOST"),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }

                    // Line chart for cache
                    if (subFeature == "cache" && cacheReport != null) {
                        item {
                            ChartCard(title = "Latency Staircase (ns)", caption = "Working set vs access latency") {
                                LineChart(
                                    points = listOf(4f, 12f, 40f, 110f, 110f),
                                    color = MaterialTheme.colorScheme.secondary,
                                    height = 180.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("DRAM penalty: ${"%.1f".format(cacheReport.dramPenalty)}% over L1", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    // FrameTimeHistogram for SIMD
                    if (subFeature == "simd" && simdReport != null) {
                        item {
                            ChartCard(title = "Vector Throughput (ops/cycle)", caption = "FMA vs Dot product vs Shuffle") {
                                FrameTimeHistogram(
                                    buckets = listOf(
                                        simdReport.fmaGflops.roundToInt().coerceAtLeast(0).coerceAtMost(500),
                                        simdReport.dotGops.roundToInt().coerceAtLeast(0).coerceAtMost(500),
                                        (simdReport.fmaGflops * 0.6).roundToInt().coerceAtLeast(0).coerceAtMost(500),
                                        (simdReport.dotGops * 0.4).roundToInt().coerceAtLeast(0).coerceAtMost(500),
                                        (simdReport.fmaGflops * 0.3).roundToInt().coerceAtLeast(0).coerceAtMost(500),
                                    ),
                                    height = 160.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spaceBetween) {
                                    Text("FMA GFLOPS", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${"%.1f".format(simdReport.fmaGflops)}", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spaceBetween) {
                                    Text("Dot Product GOPS", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${"%.1f".format(simdReport.dotGops)}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }

                    // ComparisonBar for branch prediction
                    if (subFeature == "branch" && branchReport != null) {
                        item {
                            ChartCard(title = "Branch Predictor Accuracy", caption = "Predictable vs unpredictable patterns") {
                                androidx.compose.material3.Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                                ) {
                                    androidx.compose.foundation.layout.Column(
                                        modifier = Modifier.padding(16.dp),
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Predictable", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                            Spacer(Modifier.width(8.dp))
                                            Text("${branchReport.predictableOps.roundToInt()} ops/sec", style = MaterialTheme.typography.bodySmall, color = BenchTheme.colors.success)
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Unpredictable", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                            Spacer(Modifier.width(8.dp))
                                            Text("${branchReport.unpredictableOps.roundToInt()} ops/sec", style = MaterialTheme.typography.bodySmall, color = BenchTheme.colors.warning)
                                        }
                                        Spacer(Modifier.height(12.dp))
                                        androidx.compose.foundation.layout.Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Text("Misprediction penalty", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                                            Spacer(Modifier.width(8.dp))
                                            Text("${"%.1f".format(branchReport.unpredictableOps - branchReport.predictableOps)} ms", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Metric pills row
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        ) {
                            when (subFeature) {
                                "scheduler" -> {
                                    MetricPill(label = "Promotion Latency", value = schedReport?.promotionMs?.toString() ?: "–", unit = "ms")
                                    MetricPill(label = "Band", value = schedReport?.band ?: "–", unit = "")
                                }
                                "cache" -> {
                                    MetricPill(label = "DRAM Penalty", value = cacheReport?.dramPenalty?.toString() ?: "–", unit = "%")
                                    MetricPill(label = "Cores", value = cacheReport?.cores?.toString() ?: "–", unit = "")
                                }
                                "simd" -> {
                                    MetricPill(label = "Vector Score", value = simdReport?.score?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Best Unit", value = "NEON", unit = "")
                                }
                                "branch" -> {
                                    MetricPill(label = "Predictor Score", value = branchReport?.score?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Penalty", value = (branchReport.unpredictableOps - branchReport.predictableOps).roundToInt().toString(), unit = "ms")
                                }
                                "core2core" -> {
                                    MetricPill(label = "Cores", value = core2coreReport?.cores?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Max Cross NS", value = core2coreReport?.maxCrossNs?.toString() ?: "–", unit = "ns")
                                }
                                else -> {}
                            }
                        }
                    }

                    // Verdict card
                    item {
                        SurfaceCard {
                            androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth()) {
                                Text("Verdict", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(6.dp))
                                val verdictText = when {
                                    subFeature == "scheduler" -> schedReport?.verdict ?: "No data"
                                    subFeature == "cache" -> cacheReport?.verdict ?: "No data"
                                    subFeature == "simd" -> simdReport?.verdict ?: "No data"
                                    subFeature == "branch" -> branchReport?.verdict ?: "No data"
                                    subFeature == "core2core" -> core2coreReport?.verdict ?: "No data"
                                    else -> "No data"
                                }
                                Text(verdictText, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    // Re-run button
                    item {
                        Button(
                            onClick = { runFeature() },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                        ) {
                            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(text = "Re-run Benchmark")
                        }
                    }

                    item {
                        Button(
                            onClick = { onNavigate(Routes.BENCHMARKS) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                        ) {
                            Text(text = "Back to Benchmarks")
                        }
                    }
                }
            }
        }
    }
}
