package com.benchsuite.app.engine.export

import android.os.Build
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.DeviceProfile
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.engine.analysis.UseCaseFitCalculator
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Feature 20.2: Production RFC 4180 CSV and Streaming JSON Exporter.
 *
 * Implements high-throughput, low-memory streaming exports for benchmark runs:
 * 1. Time-series Telemetry CSV: Polled at 10 Hz (100 ms) recording clocks, loads,
 *    thermals, rail power, battery percentage, and live FPS.
 * 2. Subsystem Metrics CSV: Detailed table of micro-benchmark metrics, units, and deltas.
 * 3. AbsReport OpenAPI JSON: Schema-validated, streaming JSON structure containing
 *    complete run metadata, execution conditions, subsystem breakdowns, persona fit scores,
 *    cryptographic hardware attestation signature, and time-series telemetry.
 */
object RawDataExporter {

    private const val SCHEMA_VERSION = "2.4.1"

    /* ------------------------------------------------------------------ */
    /* RFC 4180 CSV Export                                                */
    /* ------------------------------------------------------------------ */

    /**
     * Streams time-series telemetry samples to an [OutputStream] in strict RFC 4180 format.
     */
    fun exportTelemetryCsv(
        record: RunRecord,
        samples: List<TelemetrySample> = emptyList(),
        outputStream: OutputStream,
    ) {
        val effectiveSamples = if (samples.isNotEmpty()) samples else synthesizeTelemetrySamples(record)
        val writer = BufferedWriter(OutputStreamWriter(outputStream, StandardCharsets.UTF_8))

        // RFC 4180 Header
        writer.write("timestamp_ms,elapsed_sec,cpu_freq_khz,gpu_load_pct,temp_celsius,power_mw,battery_pct,fps\r\n")

        for (sample in effectiveSamples) {
            val line = String.format(
                Locale.US,
                "%d,%.2f,%d,%d,%.2f,%.2f,%d,%d\r\n",
                sample.timestampMs,
                sample.elapsedSec,
                sample.cpuFreqKhz,
                sample.gpuLoadPct,
                sample.tempCelsius,
                sample.powerMw,
                sample.batteryPct,
                sample.fps,
            )
            writer.write(line)
        }
        writer.flush()
    }

    fun exportTelemetryCsv(
        record: RunRecord,
        samples: List<TelemetrySample> = emptyList(),
        outputFile: File,
    ): File {
        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { out ->
            exportTelemetryCsv(record, samples, out)
        }
        return outputFile
    }

    /**
     * Exports subsystem scores and raw micro-benchmark metrics in RFC 4180 CSV format.
     */
    fun exportMetricsCsv(
        record: RunRecord,
        outputStream: OutputStream,
    ) {
        val writer = BufferedWriter(OutputStreamWriter(outputStream, StandardCharsets.UTF_8))
        writer.write("category_id,category_name,score,peak_score,sustained_score,delta_pct,band,summary\r\n")

        for (cat in record.categories) {
            val line = String.format(
                Locale.US,
                "%s,%s,%d,%d,%d,%.2f,%s,%s\r\n",
                escapeCsv(cat.id),
                escapeCsv(cat.name),
                cat.score,
                cat.peak,
                cat.sustained,
                cat.deltaPct,
                escapeCsv(cat.band.label),
                escapeCsv(cat.summary),
            )
            writer.write(line)
        }
        writer.flush()
    }

    fun exportMetricsCsv(
        record: RunRecord,
        outputFile: File,
    ): File {
        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { out ->
            exportMetricsCsv(record, out)
        }
        return outputFile
    }

    /* ------------------------------------------------------------------ */
    /* Streaming JSON Export (OpenAPI / AbsReport Specification)          */
    /* ------------------------------------------------------------------ */

    /**
     * Streams complete run record with attestation signature and telemetry to [outputStream].
     *
     * Written without building a massive monolithic string or in-memory tree, ensuring
     * O(1) heap allocation even with 100k+ time-series samples.
     */
    fun exportRunJson(
        record: RunRecord,
        samples: List<TelemetrySample> = emptyList(),
        deviceProfile: DeviceProfile? = null,
        signatureInfo: AttestationSignature? = null,
        outputStream: OutputStream,
    ) {
        val effectiveSamples = if (samples.isNotEmpty()) samples else synthesizeTelemetrySamples(record)
        val signature = signatureInfo ?: KeystoreSigner.signRunRecord(record)
        val dev = deviceProfile ?: com.benchsuite.app.ui.state.SessionState.currentDevice

        val writer = BufferedWriter(OutputStreamWriter(outputStream, StandardCharsets.UTF_8))

        val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date())

        writer.write("{\n")
        writer.write("  \"schema_version\": \"$SCHEMA_VERSION\",\n")
        writer.write("  \"report_id\": \"${escapeJson(record.id)}\",\n")
        writer.write("  \"generated_at\": \"$nowIso\",\n")

        // Device Info block
        writer.write("  \"device_info\": {\n")
        writer.write("    \"manufacturer\": \"${escapeJson(dev.manufacturer.ifBlank { Build.MANUFACTURER })}\",\n")
        writer.write("    \"model\": \"${escapeJson(record.deviceModel)}\",\n")
        writer.write("    \"soc\": \"${escapeJson(record.soc)}\",\n")
        writer.write("    \"cpu_topology\": \"${escapeJson(dev.cpuTopology)}\",\n")
        writer.write("    \"gpu\": \"${escapeJson(dev.gpu)}\",\n")
        writer.write("    \"npu\": \"${escapeJson(dev.npu)}\",\n")
        writer.write("    \"ram\": \"${escapeJson(dev.ram)}\",\n")
        writer.write("    \"storage\": \"${escapeJson(dev.storage)}\",\n")
        writer.write("    \"os\": \"${escapeJson(dev.os)}\",\n")
        writer.write("    \"security_patch\": \"${escapeJson(dev.securityPatch)}\",\n")
        writer.write("    \"kernel\": \"${escapeJson(dev.kernel)}\",\n")
        writer.write("    \"fingerprint\": \"${escapeJson(dev.fingerprint)}\"\n")
        writer.write("  },\n")

        // Run Metadata
        writer.write("  \"run_metadata\": {\n")
        writer.write("    \"started_at\": \"${escapeJson(record.startedAt)}\",\n")
        writer.write("    \"duration_label\": \"${escapeJson(record.durationLabel)}\",\n")
        writer.write("    \"methodology_version\": \"${escapeJson(record.methodologyVersion)}\",\n")
        writer.write("    \"verified\": ${record.verified},\n")
        writer.write("    \"note\": \"${escapeJson(record.note)}\"\n")
        writer.write("  },\n")

        // Overall Score Block
        writer.write("  \"overall_score\": {\n")
        writer.write("    \"composite\": ${record.overall},\n")
        writer.write("    \"peak\": ${record.peak},\n")
        writer.write("    \"sustained\": ${record.sustained},\n")
        writer.write("    \"band\": \"${escapeJson(record.band.label)}\",\n")
        writer.write("    \"confidence_pct\": ${record.confidence},\n")
        writer.write("    \"cv_pct\": ${String.format(Locale.US, "%.2f", record.cvPct)}\n")
        writer.write("  },\n")

        // Execution Conditions
        writer.write("  \"execution_conditions\": {\n")
        writer.write("    \"battery_pct\": ${record.conditions.batteryPct},\n")
        writer.write("    \"charging\": ${record.conditions.charging},\n")
        writer.write("    \"battery_temp_celsius\": ${String.format(Locale.US, "%.2f", record.conditions.batteryTempC)},\n")
        writer.write("    \"ambient_temp_celsius\": ${String.format(Locale.US, "%.2f", record.conditions.ambientC)},\n")
        writer.write("    \"background_load_pct\": ${record.conditions.backgroundLoadPct},\n")
        writer.write("    \"thermal_status\": \"${escapeJson(record.conditions.thermalStatus)}\",\n")
        writer.write("    \"free_storage_gb\": ${String.format(Locale.US, "%.2f", record.conditions.freeStorageGb)},\n")
        writer.write("    \"power_mode\": \"${escapeJson(record.conditions.powerMode)}\"\n")
        writer.write("  },\n")

        // Use-Case Fit Scores
        val fitReport = runCatching { UseCaseFitCalculator.calculate(record) }.getOrNull()
        writer.write("  \"use_case_fits\": [\n")
        val fits = fitReport?.toList() ?: emptyList()
        fits.forEachIndexed { idx, fit ->
            val comma = if (idx < fits.lastIndex) "," else ""
            writer.write("    {\n")
            writer.write("      \"name\": \"${escapeJson(fit.name)}\",\n")
            writer.write("      \"score\": ${fit.score},\n")
            writer.write("      \"band\": \"${escapeJson(fit.band.label)}\",\n")
            writer.write("      \"note\": \"${escapeJson(fit.note)}\"\n")
            writer.write("    }$comma\n")
        }
        writer.write("  ],\n")

        // Subsystems Array
        writer.write("  \"subsystems\": [\n")
        record.categories.forEachIndexed { idx, cat ->
            val comma = if (idx < record.categories.lastIndex) "," else ""
            writer.write("    {\n")
            writer.write("      \"id\": \"${escapeJson(cat.id)}\",\n")
            writer.write("      \"name\": \"${escapeJson(cat.name)}\",\n")
            writer.write("      \"score\": ${cat.score},\n")
            writer.write("      \"peak\": ${cat.peak},\n")
            writer.write("      \"sustained\": ${cat.sustained},\n")
            writer.write("      \"delta_pct\": ${String.format(Locale.US, "%.2f", cat.deltaPct)},\n")
            writer.write("      \"band\": \"${escapeJson(cat.band.label)}\",\n")
            writer.write("      \"summary\": \"${escapeJson(cat.summary)}\",\n")
            writer.write("      \"test_count\": ${cat.testCount}\n")
            writer.write("    }$comma\n")
        }
        writer.write("  ],\n")

        // Attestation Signature Block
        writer.write("  \"cryptographic_attestation\": {\n")
        writer.write("    \"sha256_digest\": \"${escapeJson(signature.sha256DigestHex)}\",\n")
        writer.write("    \"signature_ecdsa\": \"${escapeJson(signature.signatureHex)}\",\n")
        writer.write("    \"algorithm\": \"${escapeJson(signature.algorithm)}\",\n")
        writer.write("    \"key_alias\": \"${escapeJson(signature.keyAlias)}\",\n")
        writer.write("    \"keystore_type\": \"${escapeJson(signature.keystoreType)}\",\n")
        writer.write("    \"hardware_backed\": ${signature.hardwareBacked},\n")
        writer.write("    \"signature_timestamp\": \"${escapeJson(signature.signatureTimestamp)}\"\n")
        writer.write("  },\n")

        // Telemetry Samples Array (Streaming items)
        writer.write("  \"telemetry_samples\": [\n")
        for (i in effectiveSamples.indices) {
            val sample = effectiveSamples[i]
            val comma = if (i < effectiveSamples.lastIndex) "," else ""
            val sampleJson = String.format(
                Locale.US,
                "    {\"timestamp_ms\": %d, \"elapsed_sec\": %.2f, \"cpu_freq_khz\": %d, \"gpu_load_pct\": %d, \"temp_celsius\": %.2f, \"power_mw\": %.2f, \"battery_pct\": %d, \"fps\": %d}%s\n",
                sample.timestampMs,
                sample.elapsedSec,
                sample.cpuFreqKhz,
                sample.gpuLoadPct,
                sample.tempCelsius,
                sample.powerMw,
                sample.batteryPct,
                sample.fps,
                comma,
            )
            writer.write(sampleJson)
        }
        writer.write("  ]\n")

        writer.write("}\n")
        writer.flush()
    }

    fun exportRunJson(
        record: RunRecord,
        samples: List<TelemetrySample> = emptyList(),
        deviceProfile: DeviceProfile? = null,
        signatureInfo: AttestationSignature? = null,
        outputFile: File,
    ): File {
        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { out ->
            exportRunJson(record, samples, deviceProfile, signatureInfo, out)
        }
        return outputFile
    }

    /* ------------------------------------------------------------------ */
    /* Helpers                                                            */
    /* ------------------------------------------------------------------ */

    /**
     * Synthesizes 120-300 continuous 10 Hz telemetry samples based on run conditions
     * and duration, ensuring full export completeness when raw in-memory ring buffers
     * have already been recycled.
     */
    /**
     * DEPRECATED for production paths: previously fabricated a full synthetic telemetry
     * timeline (sine-wave temps/power/clock). Exporters now only ever export REAL captured
     * samples; this returns an empty list so nothing fabricated is written to files.
     */
    fun synthesizeTelemetrySamples(record: RunRecord, sampleCount: Int = 180): List<TelemetrySample> =
        emptyList()

    private fun escapeCsv(value: String): String {
        if (!value.contains(",") && !value.contains("\"") && !value.contains("\n") && !value.contains("\r")) {
            return value
        }
        return "\"" + value.replace("\"", "\"\"") + "\""
    }

    private fun escapeJson(value: String): String = buildString {
        for (c in value) {
            when (c) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\b' -> append("\\b")
                '\u000C' -> append("\\f")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> {
                    if (c.code in 0..0x1F) {
                        append(String.format(Locale.US, "\\u%04x", c.code))
                    } else {
                        append(c)
                    }
                }
            }
        }
    }
}
