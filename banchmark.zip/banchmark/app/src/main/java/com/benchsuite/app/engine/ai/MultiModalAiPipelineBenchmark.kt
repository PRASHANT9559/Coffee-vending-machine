package com.benchsuite.app.engine.ai

import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 3.2: Multi-Modal AI Pipeline Benchmark
 *
 * Runs vision-language-audio combined inference (e.g., describe a video clip in real time) and
 * measures end-to-end latency across NPU/GPU/CPU stages. Tests NPU-GPU-CPU coordination under
 * realistic AI workloads.
 *
 * Data source: simulated multi-stage inference pipeline keyed to detected accelerator class.
 * Limitations: No LiteRT/NPU runtime or real multi-modal model is loaded here; stage latencies are
 * modeled per accelerator class, not fabricated measured values.
 */
object MultiModalAiPipelineBenchmark {

    enum class Modality(val label: String) {
        VISION("Vision / image encoder"),
        LANGUAGE("Language / text decoder"),
        AUDIO("Audio / speech encoder"),
        FUSION("Cross-modal fusion"),
    }

    data class StageResult(
        val modality: Modality,
        val accelerator: String,
        val latencyMs: Double,
        val throughputItemsPerSec: Double,
        val isNpuAccelerated: Boolean,
    )

    data class PipelineReport(
        val modelName: String,
        val detectedAccelerator: String,
        val stageResults: List<StageResult>,
        val endToEndLatencyMs: Double,
        val framesPerSecond: Double,
        val npuUtilizationPct: Double,
        val bottleneckStage: Modality,
        val pipelineScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun detectAccelerator(): String {
        val soc = Build.HARDWARE.lowercase()
        val board = Build.BOARD.lowercase()
        return when {
            soc.contains("qcom") || soc.contains("sm8") || board.contains("lahaina") -> "Qualcomm QNN HTP (NPU)"
            soc.contains("mt") || soc.contains("dimensity") -> "MediaTek NeuroPilot APU (NPU)"
            soc.contains("exynos") -> "Samsung ENPU (NPU)"
            soc.contains("gs") || Build.MANUFACTURER.lowercase().contains("google") -> "Google Tensor TPU (NPU)"
            else -> "CPU SIMD fallback"
        }
    }

    private fun stageLatency(modality: Modality, accelerator: String): Double {
        val base = when (modality) {
            Modality.VISION -> 45.0
            Modality.LANGUAGE -> 60.0
            Modality.AUDIO -> 30.0
            Modality.FUSION -> 25.0
        }
        val multiplier = when {
            accelerator.contains("NPU") || accelerator.contains("TPU") || accelerator.contains("HTP") -> 0.35
            accelerator.contains("GPU") -> 0.75
            else -> 1.6
        }
        return (base * multiplier * 10.0).roundToInt() / 10.0
    }

    /**
     * Runs the multi-modal AI pipeline benchmark end-to-end.
     */
    fun runPipelineBenchmark(): PipelineReport {
        val accelerator = detectAccelerator()
        val modelName = "VLA-2B-INT4"
        val npuAccel = accelerator.contains("NPU") || accelerator.contains("TPU") || accelerator.contains("HTP")

        val stages = listOf(
            Modality.VISION,
            Modality.LANGUAGE,
            Modality.AUDIO,
            Modality.FUSION,
        ).map { modality ->
            val latency = stageLatency(modality, accelerator)
            StageResult(
                modality = modality,
                accelerator = accelerator,
                latencyMs = latency,
                throughputItemsPerSec = if (latency > 0) 1000.0 / latency else 0.0,
                isNpuAccelerated = npuAccel,
            )
        }

        val endToEnd = stages.sumOf { it.latencyMs }
        val fps = if (endToEnd > 0) 1000.0 / endToEnd else 0.0
        val npuPct = if (npuAccel) 85.0 else 15.0
        val bottleneck = stages.maxByOrNull { it.latencyMs }?.modality ?: Modality.FUSION

        val score = when {
            npuAccel && endToEnd <= 120.0 -> 920
            npuAccel -> 750
            endToEnd <= 250.0 -> 580
            else -> 380
        }

        val verdict = when {
            npuAccel && endToEnd <= 120.0 -> "Real-time multi-modal inference feasible on-device NPU."
            npuAccel -> "Multi-modal pipeline runs on NPU with usable latency."
            endToEnd <= 250.0 -> "Pipeline runs on CPU/GPU; real-time multi-modal is marginal."
            else -> "Pipeline is CPU-bound; multi-modal real-time inference is not practical."
        }

        return PipelineReport(
            modelName = modelName,
            detectedAccelerator = accelerator,
            stageResults = stages,
            endToEndLatencyMs = (endToEnd * 10.0).roundToInt() / 10.0,
            framesPerSecond = (fps * 100.0).roundToInt() / 100.0,
            npuUtilizationPct = (npuPct * 10.0).roundToInt() / 10.0,
            bottleneckStage = bottleneck,
            pipelineScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real multi-modal model or LiteRT NPU runtime loaded; stage latencies are modeled per detected accelerator class.",
        )
    }
}
