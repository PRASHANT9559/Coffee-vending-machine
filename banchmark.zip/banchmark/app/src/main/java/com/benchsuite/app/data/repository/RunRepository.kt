package com.benchsuite.app.data.persistence

import android.content.Context
import com.benchsuite.app.data.model.RunRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class RunRepository(private val dao: RunRecordDao) {

    suspend fun insertRun(record: RunRecord) {
        dao.insertRun(record)
    }

    suspend fun getAllRuns(): List<RunRecord> = dao.getAllRuns()

    suspend fun findRunById(id: String): RunRecord? = dao.findRunById(id)

    suspend fun getLatestRun(): RunRecord? = dao.getLatestRun()

    suspend fun count(): Int = dao.count()

    suspend fun deleteAll() = dao.deleteAll()

    fun getAllRunsFlow(): Flow<List<RunRecord>> = flow {
        emit(dao.getAllRuns())
    }
}
