package com.benchsuite.app.data.catalog

import com.benchsuite.app.data.model.BenchIcon
import com.benchsuite.app.data.model.CategorySpec
import com.benchsuite.app.data.model.TestAvailability
import com.benchsuite.app.data.model.TestDefinition

/**
 * Pure test/category catalog — metadata only, no measured scores, no fake results.
 *
 * Extracted from `Mock` during Phase 3-B (Mock Data Elimination). This is the single
 * source of truth for benchmark test definitions and category descriptors. Real run
 * results come from SessionState / Room, never from this file.
 */
object TestCatalog {

    private fun test(
        id: String,
        name: String,
        categoryId: String,
        minutes: Int,
        difficulty: String,
        innovation: Int,
        priority: String,
        description: String,
        availability: TestAvailability = TestAvailability.READY,
        note: String = "Ready",
    ) = TestDefinition(
        id = id, name = name, description = description, categoryId = categoryId,
        minutes = minutes, difficulty = difficulty, innovation = innovation,
        priority = priority, availability = availability, availabilityNote = note,
    )

    val tests: List<TestDefinition> = listOf(
        // CPU
        test("cpu.scheduler", "Scheduler Efficiency Profiler", "cpu", 3, "Hard", 9, "Must Have",
            "Threads across big, medium and little cores under a mixed burst workload.", note = "Ready · 8 threads"),
        test("cpu.context", "Context Switch Storm", "cpu", 2, "Medium", 8, "Must Have",
            "500 rapid task switches with frame-drop and input-latency capture."),
        test("cpu.cache", "Cache Hierarchy Latency Mapper", "cpu", 4, "Medium", 8, "Should Have",
            "Pointer-chasing staircase across L1, L2, L3, SLC and DRAM."),
        test("cpu.simd", "SIMD / NEON Throughput", "cpu", 2, "Medium", 8, "Should Have",
            "FMA, dot-product and shuffle kernels per core cluster."),
        test("cpu.corelat", "Core-to-Core Latency Matrix", "cpu", 5, "Hard", 9, "Nice to Have",
            "N × N cache-line ping-pong heatmap between every core pair."),
        test("cpu.decay", "Sustained Decay Curve", "cpu", 10, "Medium", 7, "Must Have",
            "Ten-minute all-core load plotted every five seconds."),

        // GPU
        test("gpu.vulkan", "Vulkan Feature Scanner", "gpu", 1, "Easy", 7, "Must Have",
            "Extensions, limits and driver readiness translated into a verdict."),
        test("gpu.fill", "Fillrate & Texture Bandwidth", "gpu", 3, "Medium", 7, "Nice to Have",
            "Separates ROP, texture and framebuffer limits."),
        test("gpu.shader", "Shader Compilation Stutter", "gpu", 4, "Medium", 8, "Should Have",
            "Cold vs warm pipeline cache frame-time spikes."),
        test("gpu.residency", "GPU Frequency Residency", "gpu", 3, "Medium", 7, "Should Have",
            "Histogram of time spent at each clock step."),
        test("gpu.async", "Async Compute Saturation", "gpu", 4, "Hard", 8, "Should Have",
            "Overlaps graphics and compute queues to expose idle bubbles."),
        test("gpu.vrs", "VRS Efficiency", "gpu", 3, "Medium", 8, "Should Have",
            "FPS gain vs quality loss on peripheral shading."),

        // Memory
        test("mem.pressure", "Memory Pressure Cascade", "memory", 5, "Medium", 8, "Must Have",
            "Raises pressure until swap thrash starts, then measures the cliff."),
        test("mem.zram", "ZRAM / Swap Efficiency", "memory", 3, "Medium", 8, "Should Have",
            "Compression ratio and decompression latency on real snapshots."),
        test("mem.bandwidth", "Tri-Load Bandwidth Battle", "memory", 4, "Hard", 9, "Must Have",
            "CPU + GPU + NPU together to expose bandwidth starvation.",
            availability = TestAvailability.LIMITED, note = "Limited · NPU delegate shared"),
        test("mem.latency", "Latency Staircase", "memory", 2, "Medium", 8, "Should Have",
            "Load-to-use latency across growing working sets."),

        // Storage
        test("sto.iops", "Random IOPS QD Scaling", "storage", 6, "Medium", 7, "Must Have",
            "4K random read/write from queue depth 1 to 32."),
        test("sto.frag", "Fragmentation Simulator", "storage", 8, "Hard", 9, "Must Have",
            "Ages the volume two years, then re-runs IOPS.",
            availability = TestAvailability.LIMITED, note = "Needs 8 GB free"),
        test("sto.ai", "AI I/O Pattern", "storage", 4, "Medium", 8, "Should Have",
            "4–128 KB random reads mixed with checkpoint writes."),
        test("sto.metadata", "Small-File Metadata Stress", "storage", 2, "Easy", 6, "Nice to Have",
            "Create, stat, rename and delete 20,000 files."),
        test("sto.thermal", "UFS Thermal Sustained", "storage", 10, "Hard", 8, "Should Have",
            "Sustained writes until the controller throttles."),
        test("sto.wear", "Endurance & Wear Estimate", "storage", 1, "Hard", 8, "Should Have",
            "Health registers plus write-amplification estimate."),

        // AI
        test("ai.llm", "LLM Context Window Curve", "ai", 12, "Hard", 10, "Must Have",
            "Prefill and decode across 512 to 32K tokens.",
            availability = TestAvailability.LIMITED, note = "Requires 4.2 GB model download"),
        test("ai.fallback", "NPU Delegate Fallback Detector", "ai", 5, "Hard", 9, "Must Have",
            "Per-operator placement map and silent fallback flags."),
        test("ai.energy", "AI Energy per Token", "ai", 6, "Hard", 10, "Must Have",
            "Joules per token and image step from power rails."),
        test("ai.diffusion", "Diffusion Consistency", "ai", 7, "Medium", 9, "Should Have",
            "Per-step latency variance during 20-step generation."),
        test("ai.speech", "Speech Real-Time Factor", "ai", 3, "Medium", 8, "Should Have",
            "Whisper-class model speed and word error rate."),
        test("ai.load", "Model Load Time", "ai", 2, "Easy", 7, "Should Have",
            "Hydration time for 1B to 12B models."),

        // Gaming
        test("game.pacing", "Frame Pacing Consistency", "gaming", 6, "Medium", 8, "Must Have",
            "1% and 0.1% lows, jitter and frame-time variance."),
        test("game.fps", "Predicted Gaming FPS", "gaming", 2, "Hard", 10, "Must Have",
            "Stable FPS prediction for 50+ titles with intervals."),
        test("game.long", "Long Session Stability", "gaming", 45, "Medium", 8, "Must Have",
            "Three-hour simulation with throttling and drain timeline."),
        test("game.touch", "Touch-to-Photon Latency", "gaming", 3, "Hard", 8, "Should Have",
            "Input-to-display latency in a competitive scene."),
        test("game.launch", "App Launch Consistency", "gaming", 5, "Easy", 7, "Should Have",
            "Cold starts of 50 reference apps, ten times each."),
        test("game.booster", "OEM Booster Honesty", "gaming", 4, "Hard", 9, "Must Have",
            "Normal mode vs detected benchmark-whitelist behavior."),

        // Thermal
        test("th.stress", "30-min CPU + GPU Soak", "thermal", 30, "Medium", 7, "Must Have",
            "Sustained mixed load with safety limits."),
        test("th.decay", "Thermal Decay Curve", "thermal", 20, "Medium", 7, "Must Have",
            "Performance plotted against temperature and time."),
        test("th.cooldown", "Cool-down Recovery", "thermal", 10, "Easy", 7, "Should Have",
            "Time to return to baseline clocks and skin temperature."),
        test("th.comfort", "Skin Temperature Comfort", "thermal", 15, "Medium", 7, "Should Have",
            "Hold-comfort index during gaming and charging."),
        test("th.battery", "Battery Drain Under Load", "thermal", 30, "Medium", 7, "Should Have",
            "mAh per minute at a fixed brightness and load."),

        // Health
        test("he.battery", "Battery Health Correlation", "health", 2, "Medium", 9, "Must Have",
            "Links degradation to CPU and GPU frequency capping."),
        test("he.sot", "Screen-On-Time Predictor", "health", 1, "Medium", 8, "Must Have",
            "Hours per charge across web, video, gaming and idle."),
        test("he.wear", "Storage Wear Estimate", "health", 1, "Hard", 8, "Should Have",
            "Remaining life from health registers and usage."),
        test("he.patch", "Patch Freshness", "health", 1, "Easy", 6, "Must Have",
            "Patch level against known vulnerability windows."),
        test("he.sensors", "Sensor Calibration", "health", 3, "Medium", 8, "Should Have",
            "IMU bias, noise floor and cross-axis sensitivity."),
        test("he.integrity", "Root & Integrity Posture", "health", 1, "Easy", 6, "Should Have",
            "Bootloader, verified boot and Play Integrity verdicts."),
    )

    fun testsFor(categoryId: String): List<TestDefinition> = tests.filter { it.categoryId == categoryId }

    /* --------------------------- Category UI ------------------------- */

    val cpuSpec = CategorySpec(
        id = "cpu",
        title = "CPU Benchmark",
        shortTitle = "CPU",
        icon = BenchIcon.CPU,
        tagline = "Scheduler behaviour, not just GHz.",
        description = "Measures how the OS feeds big cores, how quickly threads migrate, and what happens after ten minutes of load.",
        tests = testsFor("cpu"),
    )
    val gpuSpec = CategorySpec(
        id = "gpu",
        title = "GPU Benchmark",
        shortTitle = "GPU",
        icon = BenchIcon.GPU,
        tagline = "Peak is easy. Sustained is honest.",
        description = "Vulkan workloads covering fillrate, pipeline compilation, async compute and long-run clock residency.",
        tests = testsFor("gpu"),
    )
    val memorySpec = CategorySpec(
        id = "memory",
        title = "Memory",
        shortTitle = "Memory",
        icon = BenchIcon.MEMORY,
        tagline = "How many apps stay alive?",
        description = "Bandwidth, latency and the pressure point where Android starts swapping.",
        tests = testsFor("memory"),
    )
    val storageSpec = CategorySpec(
        id = "storage",
        title = "Storage",
        shortTitle = "Storage",
        icon = BenchIcon.STORAGE,
        tagline = "Fresh speed is not real speed.",
        description = "Random IOPS, fragmentation aging and AI-shaped I/O patterns on the actual volume.",
        tests = testsFor("storage"),
    )
    val aiSpec = CategorySpec(
        id = "ai",
        title = "AI",
        shortTitle = "AI",
        icon = BenchIcon.AI,
        tagline = "Tokens, not TOPS.",
        description = "LLM decode, NPU fallback, diffusion consistency and energy per token on real models.",
        tests = testsFor("ai"),
    )
    val gamingSpec = CategorySpec(
        id = "gaming",
        title = "Gaming",
        shortTitle = "Gaming",
        icon = BenchIcon.GAMING,
        tagline = "Frame pacing is the experience.",
        description = "Frame-time percentiles, predicted FPS for real titles, long-session stability and input latency.",
        tests = testsFor("gaming"),
    )
    val thermalSpec = CategorySpec(
        id = "thermal",
        title = "Stress Test",
        shortTitle = "Stress",
        icon = BenchIcon.THERMAL,
        tagline = "Where performance goes after 20 minutes.",
        description = "Sustained mixed load with temperature, power and throttling timeline, plus cool-down recovery.",
        tests = testsFor("thermal"),
    )
    val healthSpec = CategorySpec(
        id = "health",
        title = "Device Health",
        shortTitle = "Health",
        icon = BenchIcon.HEALTH,
        tagline = "The long game: battery, storage, security.",
        description = "Battery degradation, storage wear, thermal comfort and patch exposure in one 0-100 score.",
        tests = testsFor("health"),
    )

    val categorySpecs: List<CategorySpec> = listOf(
        cpuSpec, gpuSpec, memorySpec, storageSpec, aiSpec, gamingSpec, thermalSpec, healthSpec,
    )

    fun spec(id: String): CategorySpec = categorySpecs.first { it.id == id }
}
