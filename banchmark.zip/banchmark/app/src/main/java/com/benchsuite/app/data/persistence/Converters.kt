package com.benchsuite.app.data.persistence

import androidx.room.TypeConverter
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.RunConditions
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

class Converters {
    private val json = Json { ignoreUnknownKeys = true }

    @TypeConverter
    fun categoriesToJson(categories: List<CategoryScore>): String =
        json.encodeToString(CategoryScore.serializer(), categories)

    @TypeConverter
    fun categoriesFromJson(jsonString: String): List<CategoryScore> =
        json.decodeFromString(CategoryScore.serializer(), jsonString)

    @TypeConverter
    fun conditionsToJson(conditions: RunConditions): String =
        json.encodeToString(RunConditions.serializer(), conditions)

    @TypeConverter
    fun conditionsFromJson(jsonString: String): RunConditions =
        json.decodeFromString(RunConditions.serializer(), jsonString)
}
