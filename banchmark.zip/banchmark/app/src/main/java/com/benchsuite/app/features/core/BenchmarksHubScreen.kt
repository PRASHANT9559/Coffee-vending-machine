package com.benchsuite.app.features.core

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.data.model.CategorySpec
import com.benchsuite.app.data.model.TestDefinition
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.CategoryTile
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.InsightCard
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.components.TestRow
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun BenchmarksHubScreen(onNavigate: (String) -> Unit) {
    var query by remember { mutableStateOf("") }

    val specs: List<CategorySpec> = if (query.isBlank()) {
        TestCatalog.categorySpecs
    } else {
        TestCatalog.categorySpecs.filter {
            it.title.contains(query, true) || it.tagline.contains(query, true) || it.description.contains(query, true)
        }
    }
    val matchingTests: List<TestDefinition> = TestCatalog.tests.filter {
        it.name.contains(query, true) || it.description.contains(query, true)
    }
    val featuredTests = if (query.isBlank()) {
        TestCatalog.tests.filter { it.innovation >= 10 }.take(4)
    } else {
        matchingTests.take(8)
    }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Benchmarks",
            subtitle = "158 tests · 22 categories",
            actions = {
                IconAction(Icons.Outlined.Bolt, "Quick test", onClick = { onNavigate(Routes.preTest("quick")) })
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Measure · explain · act",
                    title = "Choose what to prove.",
                    body = "Run the full suite, a single category, or compose your own protocol.",
                )
            }

            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search tests, e.g. thermal or LLM", style = MaterialTheme.typography.bodyMedium) },
                    leadingIcon = { Icon(Icons.Outlined.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Outlined.Close, "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    textStyle = MaterialTheme.typography.bodyMedium,
                )
            }

            if (query.isBlank()) {
                item {
                    FullSuiteCard(
                        onStart = { onNavigate(Routes.preTest("full")) },
                        onCustom = { onNavigate(Routes.CUSTOM_BUILDER) },
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        MiniSuiteCard(
                            title = "Quick check",
                            subtitle = "Health + core · 3 min",
                            icon = Icons.Outlined.Bolt,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(Routes.preTest("health")) },
                        )
                        MiniSuiteCard(
                            title = "Reviewer mode",
                            subtitle = "Repeat protocol · 3×",
                            icon = Icons.Outlined.Speed,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(Routes.category("gaming")) },
                        )
                    }
                }
                item {
                    SectionHeader(
                        title = "Categories",
                        actionLabel = "All tests",
                        onAction = { onNavigate(Routes.SCHEDULER) },
                    )
                }
            }

            if (specs.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        val realScores = SessionState.latestRecordedRunOrNull
                            ?.categories?.associateBy { it.id } ?: emptyMap()
                        specs.chunked(2).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                                row.forEach { spec ->
                                    CategoryTile(
                                        spec = spec,
                                        realScore = realScores[spec.id],
                                        modifier = Modifier.weight(1f),
                                        onClick = { onNavigate(Routes.category(spec.id)) },
                                    )
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            if (query.isBlank()) {
                item {
                    SurfaceCard(onClick = { onNavigate(Routes.CUSTOM_BUILDER) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Outlined.Tune, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Custom suite builder", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Pick tests, set duration, save a protocol.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            if (query.isBlank()) {
                item {
                    SectionHeader(title = "Engine deep dives")
                }
                item {
                    EngineDeepDiveSection(onNavigate = onNavigate)
                }
                item {
                    NativeKernelSection(onNavigate = onNavigate)
                }
            }

            item {
                SectionHeader(
                    title = if (query.isBlank()) "High-innovation tests" else "Results for \"$query\"",
                    actionLabel = if (query.isBlank()) "See all 158" else null,
                    onAction = if (query.isBlank()) ({ onNavigate(Routes.MORE) }) else null,
                )
            }

            if (featuredTests.isEmpty()) {
                item {
                    SurfaceCard {
                        Text("No tests match that search.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Try \"thermal\", \"storage\", \"LLM\" or \"latency\".",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                items(featuredTests.size) { index ->
                    val test = featuredTests[index]
                    TestRow(
                        test = test,
                        onRun = { onNavigate(Routes.preTest(test.categoryId)) },
                    )
                }
            }

            item {
                val realInsights = SessionState.latestRecordedRunOrNull
                    ?.let { SessionState.getInsights(it) } ?: emptyList()
                if (realInsights.isNotEmpty()) {
                    InsightCard(insight = realInsights.first())
                } else {
                    SurfaceCard {
                        Text(
                            "Insights appear here after your first real benchmark run.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FullSuiteCard(onStart: () -> Unit, onCustom: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.20f),
                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.13f),
                    ),
                ),
                RoundedCornerShape(16.dp),
            )
            .padding(1.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)),
    ) {
        Column(Modifier.padding(Spacing.md)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusChip("Recommended", tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                Text("14 min", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            Text("Full benchmark suite", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(6.dp))
            Text(
                "22 tests across CPU, GPU, memory, storage, AI, gaming and thermal. Peak + sustained + confidence, with plain-language insights.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Tag("7 categories")
                Tag("3 iterations")
                Tag("Signed result")
            }
            Spacer(Modifier.height(Spacing.md))
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                Button(onClick = onStart, modifier = Modifier.weight(1f).height(48.dp)) {
                    Text("Start full suite")
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, modifier = Modifier.size(17.dp))
                }
                TextButton(onClick = onCustom, modifier = Modifier.height(48.dp)) {
                    Text("Customize")
                }
            }
        }
    }
}

@Composable
private fun MiniSuiteCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    SurfaceCard(modifier = modifier, onClick = onClick, contentPadding = PaddingValues(12.dp)) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}
