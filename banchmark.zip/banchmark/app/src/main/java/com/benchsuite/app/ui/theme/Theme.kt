package com.benchsuite.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.benchsuite.app.data.model.ThemeMode

private val BenchDarkScheme = darkColorScheme(
    primary = DarkTokens.primary,
    onPrimary = DarkTokens.onPrimary,
    primaryContainer = Color(0xFF0B3B44),
    onPrimaryContainer = Color(0xFFA5F3FC),
    secondary = DarkTokens.secondary,
    onSecondary = Color(0xFF1E1B4B),
    secondaryContainer = Color(0xFF2A2350),
    onSecondaryContainer = Color(0xFFEDE9FE),
    tertiary = DarkTokens.warning,
    onTertiary = Color(0xFF3B2A00),
    background = DarkTokens.background,
    onBackground = DarkTokens.textPrimary,
    surface = DarkTokens.surface,
    onSurface = DarkTokens.textPrimary,
    surfaceVariant = DarkTokens.surfaceVariant,
    onSurfaceVariant = DarkTokens.textSecondary,
    error = DarkTokens.danger,
    onError = Color(0xFF3B0A0A),
    outline = DarkTokens.outline,
    outlineVariant = DarkTokens.outlineSubtle,
)

private val BenchLightScheme = lightColorScheme(
    primary = LightTokens.primary,
    onPrimary = LightTokens.onPrimary,
    primaryContainer = Color(0xFFCFF3FA),
    onPrimaryContainer = Color(0xFF083344),
    secondary = LightTokens.secondary,
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEDE9FE),
    onSecondaryContainer = Color(0xFF2E1065),
    tertiary = LightTokens.warning,
    onTertiary = Color(0xFFFFFFFF),
    background = LightTokens.background,
    onBackground = LightTokens.textPrimary,
    surface = LightTokens.surface,
    onSurface = LightTokens.textPrimary,
    surfaceVariant = LightTokens.surfaceVariant,
    onSurfaceVariant = LightTokens.textSecondary,
    error = LightTokens.danger,
    onError = Color(0xFFFFFFFF),
    outline = LightTokens.outline,
    outlineVariant = LightTokens.outlineSubtle,
)

val LocalReduceMotion = staticCompositionLocalOf { false }

@Composable
fun BenchSuiteTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    dynamicColor: Boolean = false,
    reduceMotion: Boolean = false,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> systemDark
    }
    val context = LocalContext.current
    val useDynamic = dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val scheme = when {
        useDynamic && dark -> dynamicDarkColorScheme(context)
        useDynamic -> dynamicLightColorScheme(context)
        dark -> BenchDarkScheme
        else -> BenchLightScheme
    }
    val benchColors = if (dark) DarkBenchColors else LightBenchColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(
        LocalBenchColors provides benchColors,
        LocalReduceMotion provides reduceMotion,
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = BenchTypography,
            shapes = BenchShapes,
            content = content,
        )
    }
}

/** Shorthand for the extended, fixed data palette. */
object BenchTheme {
    val colors: BenchColors
        @Composable
        @ReadOnlyComposable
        get() = LocalBenchColors.current
}
