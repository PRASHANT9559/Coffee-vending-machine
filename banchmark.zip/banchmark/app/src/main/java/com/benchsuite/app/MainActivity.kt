package com.benchsuite.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchSuiteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SessionState.attach(applicationContext)
        enableEdgeToEdge()
        setContent {
            val settings = SessionState.settings
            BenchSuiteTheme(
                themeMode = settings.themeMode,
                dynamicColor = settings.dynamicColor,
                reduceMotion = settings.reduceMotion,
            ) {
                BenchSuiteApp()
            }
        }
    }
}
