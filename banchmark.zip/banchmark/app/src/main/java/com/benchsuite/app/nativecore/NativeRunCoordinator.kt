package com.benchsuite.app.nativecore

import android.content.Context
import android.os.Build
import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.data.model.BenchIcon
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.RunConditions
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.engine.benchmark.QuickTestEngine
import com.benchsuite.app.engine.export.TelemetrySample
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.util.readTextOrNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * Production Benchmark Orchestration Coordinator.
 *
 * Orchestrates real native and on-device compute probes across all categories:
 * - High-precision 10 Hz telemetry stream (thermals, mA power, clocks, live FPS)
 * - Thread-safe time-series recording of [TelemetrySample] instances
 * - Real mathematical calculation of composite geometric mean scores, confidence, and CoV
 * - Full integration with [QuickTestEngine] for 60s micro-benchmarks
 * - Native JNI execution with resilient direct-hardware fallback when native libs are absent
 */
object NativeRunCoordinator {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    val isRunning: Boolean
        get() = job?.isActive == true

    data class Probe(
        val component: String,
        val label: String,
        val durationMs: Int = 1_500,
        val frames: Int = 60,
        val sizeMb: Int = 16,
        val queueDepth: Int = 16,
        val targetMb: Int = 256,
        val threads: Int = NativeBridge.defaultThreads,
    )

    fun start(categoryId: String, selectedTestIds: Set<String>) {
        val context = SessionState.applicationContext ?: return
        job?.cancel()
        job = scope.launch {
            if (categoryId == "quick") {
                executeQuickTest(context)
            } else {
                execute(context, categoryId, selectedTestIds)
            }
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        QuickTestEngine.cancel()
    }

    private suspend fun executeQuickTest(context: Context) {
        try {
            val result = QuickTestEngine.execute(context)
            SessionState.publishNativeRun(result.record)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Throwable) {
            SessionState.failNativeRun(failure.message ?: "Quick test failed")
        }
    }

    private suspend fun execute(
        context: Context,
        categoryId: String,
        selectedTestIds: Set<String>,
    ) = coroutineScope {
        val probes = probesFor(categoryId, selectedTestIds)
        if (probes.isEmpty()) {
            SessionState.failNativeRun("No runnable probe in this suite.")
            return@coroutineScope
        }

        val startedAt = System.currentTimeMillis()
        val startedNanos = System.nanoTime()
        val results = mutableListOf<NativeComponentResult>()
        val recordedSamples = Collections.synchronizedList(mutableListOf<TelemetrySample>())

        // 10 Hz Telemetry Streaming loop (polled every 100 ms)
        val telemetry = launch {
            while (isActive) {
                val t = DeviceTelemetryReader.read(context)
                val now = System.currentTimeMillis()
                val elapsedSec = (now - startedAt) / 1000.0
                // Real GPU busy percentage from kernel counters; 0 when the device
                // exposes none (previously derived from simulated FPS values).
                val gpuLoad = readGpuLoadPct()

                val sample = TelemetrySample(
                    timestampMs = now,
                    elapsedSec = (elapsedSec * 10.0).roundToInt() / 10.0,
                    cpuFreqKhz = (t.clockGhz * 1_000_000).toLong(),
                    gpuLoadPct = gpuLoad,
                    tempCelsius = t.temperatureC,
                    // Measured power as-is; no fabricated 1200 mW floor.
                    powerMw = t.powerW * 1000.0,
                    batteryPct = t.batteryPct,
                    // FPS is not measured during native component probes; 0 = unmeasured.
                    fps = 0,
                )
                recordedSamples.add(sample)

                SessionState.updateNativeTelemetry(t)
                delay(100)
            }
        }

        try {
            SessionState.prepareNativeRun(probes.size)

            probes.forEachIndexed { index, probe ->
                awaitRunning()
                SessionState.nativeStep(
                    current = probe.label,
                    completed = index,
                    total = probes.size,
                    elapsedSec = elapsedSeconds(startedNanos),
                )

                val result = measure(context, probe)
                if (result != null && result.score > 0.0) {
                    results += result
                    if (result.component == "gpu") {
                        result.samples.lastOrNull()?.let {
                            SessionState.updateNativeFps(it.value.roundToInt().coerceIn(1, 240))
                        }
                    }
                }

                val next = probes.getOrNull(index + 1)?.label ?: "Finishing"
                SessionState.nativeStep(
                    current = next,
                    completed = index + 1,
                    total = probes.size,
                    elapsedSec = elapsedSeconds(startedNanos),
                )
            }

            awaitRunning()

            if (results.isEmpty()) {
                SessionState.failNativeRun("Native probes returned no score. Check system log for errors.")
                return@coroutineScope
            }

            // Real score calculation
            val scores = results.associate { it.component to it.score }
            val confidence = results.map { it.confidence }
                .average()
                .takeIf { !it.isNaN() }
                ?: 0.85
            val overall = NativeBridge.overallScore(scores, confidence)

            val conditions = DeviceTelemetryReader.conditions(
                context,
                SessionState.settings.performanceMode,
            )

            val elapsedMs = (System.nanoTime() - startedNanos) / 1_000_000L
            val record = buildProductionRecord(
                startedAtMillis = startedAt,
                elapsedMs = elapsedMs,
                results = results,
                overall = overall,
                conditions = conditions,
            )

            // Cache real recorded samples in SessionState
            SessionState.recordLatestTelemetrySamples(recordedSamples.toList())
            SessionState.publishNativeRun(record)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Throwable) {
            SessionState.failNativeRun(failure.message ?: "Benchmark run failed.")
        } finally {
            telemetry.cancel()
        }
    }

    private suspend fun awaitRunning() {
        while (true) {
            val run = SessionState.activeRun ?: throw CancellationException("Run cancelled")
            if (!run.paused) return
            delay(200)
        }
    }

    private suspend fun measure(context: Context, probe: Probe): NativeComponentResult? = withContext(Dispatchers.Default) {
        when (probe.component) {
            "cpu" -> {
                if (NativeBridge.isAvailable) NativeBridge.runCpu(probe.durationMs, probe.threads)
                else runFallbackCpu(probe.durationMs, probe.threads)
            }
            "context_switch" -> {
                if (NativeBridge.isAvailable) NativeBridge.runContextSwitch(probe.durationMs, probe.threads)
                else runFallbackContextSwitch(probe.durationMs, probe.threads)
            }
            "memory" -> {
                if (NativeBridge.isAvailable) NativeBridge.runMemory(probe.durationMs, bufferMb = 32)
                else runFallbackMemory(probe.durationMs)
            }
            "memory_cascade" -> {
                if (NativeBridge.isAvailable) NativeBridge.runMemoryCascade(probe.targetMb, stepMb = 32)
                else runFallbackMemory(probe.durationMs)
            }
            "storage" -> {
                if (NativeBridge.isAvailable) NativeBridge.runStorage(context.filesDir, probe.sizeMb)
                else runFallbackStorage(context.filesDir, probe.durationMs)
            }
            "storage_qd" -> {
                if (NativeBridge.isAvailable) NativeBridge.runStorageQueueDepth(context.filesDir, probe.queueDepth, probe.sizeMb)
                else runFallbackStorage(context.filesDir, probe.durationMs)
            }
            "gpu" -> {
                if (NativeBridge.isAvailable) NativeBridge.runGpu(probe.frames, readback = true)
                else runFallbackGpu(probe.frames)
            }
            "raytracing" -> {
                if (NativeBridge.isAvailable) NativeBridge.runRayTracing(probe.durationMs, triangles = 50_000)
                else runFallbackGpu(probe.frames)
            }
            "meshshader" -> {
                if (NativeBridge.isAvailable) NativeBridge.runMeshShader(probe.durationMs, meshletDensity = 64)
                else runFallbackGpu(probe.frames)
            }
            "async_compute" -> {
                if (NativeBridge.isAvailable) NativeBridge.runAsyncCompute(probe.durationMs, iterations = 100)
                else runFallbackGpu(probe.frames)
            }
            "cache" -> {
                if (NativeBridge.isAvailable) NativeBridge.runCache()
                else runFallbackMemory(probe.durationMs)
            }
            "pqc" -> {
                if (NativeBridge.isAvailable) NativeBridge.runPqc(probe.durationMs, iterations = 100)
                else runFallbackCpu(probe.durationMs, probe.threads)
            }
            "vulkan_scan" -> {
                val caps = NativeBridge.scanVulkanCapabilities()
                if (caps != null && caps.supported && caps.readinessScore > 0.0) {
                    NativeComponentResult(
                        component = "vulkan",
                        score = caps.readinessScore,
                        band = "Good",
                        confidence = 0.9,
                        cv = 0.01,
                        durationMs = 500,
                        notes = listOf(caps.deviceName),
                    )
                } else {
                    // Honest result: no fabricated floor when Vulkan is unsupported or the scan failed.
                    NativeComponentResult(
                        component = "vulkan",
                        score = 0.0,
                        band = "UNAVAILABLE",
                        confidence = 0.0,
                        cv = 0.0,
                        durationMs = 500,
                        notes = listOf(caps?.deviceName ?: "Vulkan scan failed on this device"),
                    )
                }
            }
            "ai" -> {
                if (NativeBridge.isAvailable) NativeBridge.runAi(probe.durationMs)
                else runFallbackAi(probe.durationMs)
            }
            "sustained" -> {
                if (NativeBridge.isAvailable) NativeBridge.runStress(probe.durationMs, probe.threads)
                else runFallbackSustained(probe.durationMs, probe.threads)
            }
            else -> null
        }
    }

    private fun probesFor(categoryId: String, selectedTestIds: Set<String>): List<Probe> {
        val cpu = Probe("cpu", "Integer, FP and multi-thread compute", durationMs = 2_000)
        val contextSwitch = Probe("context_switch", "Pthread context switch latency storm", durationMs = 1_500, threads = 16)
        val cache = Probe("cache", "Cache hierarchy & pointer-chase latency", durationMs = 1_200)
        val pqc = Probe("pqc", "Post-quantum cryptography (ML-KEM/DSA)", durationMs = 1_500)
        val memory = Probe("memory", "Memory bandwidth & latency probe", durationMs = 1_200)
        val memoryCascade = Probe("memory_cascade", "Memory allocation cascade & pressure", durationMs = 1_200, targetMb = 384)
        val storage = Probe("storage", "Sequential and direct I/O throughput", sizeMb = 16)
        val storageQd = Probe("storage_qd", "Random IOPS queue depth scaling (QD16)", sizeMb = 16, queueDepth = 16)
        val gpu = Probe("gpu", "Offscreen fragment & rasterization workload", frames = 60)
        val asyncCompute = Probe("async_compute", "GPU async compute saturation", durationMs = 1_500)
        val raytracing = Probe("raytracing", "Vulkan ray tracing BVH traversal", durationMs = 1_500)
        val meshshader = Probe("meshshader", "Mesh shader pipeline & culling", durationMs = 1_500)
        val ai = Probe("ai", "Int8 GEMM and decode proxy", durationMs = 1_500)
        val sustained = Probe("sustained", "Sustained all-core thermal load", durationMs = 5_000)

        return when (categoryId) {
            "cpu" -> listOf(cpu, contextSwitch, cache, pqc)
            "memory" -> listOf(memory, memoryCascade, cache)
            "storage" -> listOf(storage, storageQd)
            "gpu" -> listOf(gpu, asyncCompute, raytracing, meshshader)
            "ai" -> listOf(ai)
            "thermal" -> listOf(sustained)
            "gaming" -> listOf(gpu, asyncCompute, sustained.copy(durationMs = 3_500))
            "health" -> listOf(cpu.copy(durationMs = 1_000), memory.copy(durationMs = 800), storage.copy(sizeMb = 8))
            "full" -> listOf(
                cpu, contextSwitch, cache,
                memory, memoryCascade,
                storage, storageQd,
                gpu, asyncCompute, raytracing, meshshader,
                ai, sustained, pqc,
            )
            "custom" -> customProbes(
                selectedTestIds,
                cpu, contextSwitch, cache, pqc,
                memory, memoryCascade,
                storage, storageQd,
                gpu, asyncCompute, raytracing, meshshader,
                ai, sustained,
            )
            else -> listOf(cpu)
        }
    }

    private fun customProbes(
        selectedTestIds: Set<String>,
        cpu: Probe,
        contextSwitch: Probe,
        cache: Probe,
        pqc: Probe,
        memory: Probe,
        memoryCascade: Probe,
        storage: Probe,
        storageQd: Probe,
        gpu: Probe,
        asyncCompute: Probe,
        raytracing: Probe,
        meshshader: Probe,
        ai: Probe,
        sustained: Probe,
    ): List<Probe> {
        val categories = selectedTestIds.mapNotNull { id ->
            TestCatalog.tests.firstOrNull { it.id == id }?.categoryId
        }.toSet()

        val probes = buildList {
            if ("cpu" in categories) {
                add(cpu)
                add(contextSwitch)
                add(cache)
                add(pqc)
            }
            if ("memory" in categories) {
                add(memory)
                add(memoryCascade)
            }
            if ("storage" in categories) {
                add(storage)
                add(storageQd)
            }
            if ("gpu" in categories || "gaming" in categories) {
                add(gpu)
                add(asyncCompute)
                add(raytracing)
                add(meshshader)
            }
            if ("ai" in categories) add(ai)
            if ("thermal" in categories || "gaming" in categories) add(sustained)
        }
        return probes.ifEmpty { listOf(cpu) }
    }

    /* ------------------------------------------------------------------ */
    /* Production Result Calculation & Record Assembly                   */
    /* ------------------------------------------------------------------ */

    private fun buildProductionRecord(
        startedAtMillis: Long,
        elapsedMs: Long,
        results: List<NativeComponentResult>,
        overall: NativeOverallScore?,
        conditions: RunConditions,
    ): RunRecord {
        val valid = results.filter { it.score > 0.0 }
        val categories = valid.map { comp ->
            val mappedId = when (comp.component) {
                "sustained", "context_switch" -> "thermal"
                "raytracing", "meshshader", "async_compute", "vulkan" -> "gpu"
                "pqc", "cache" -> "cpu"
                "memory_cascade" -> "memory"
                "storage_qd" -> "storage"
                else -> comp.component
            }
            val spec = TestCatalog.categorySpecs.firstOrNull { it.id == mappedId }
            val score = comp.score.roundToInt().coerceIn(1, 1100)
            val peak = score.roundToInt().coerceIn(score, 1100)

            CategoryScore(
                id = mappedId,
                name = spec?.shortTitle ?: mappedId.replaceFirstChar { it.uppercase() },
                score = score,
                peak = peak,
                sustained = score,
                deltaPct = 0.0,
                icon = spec?.icon ?: BenchIcon.SPEED,
                summary = "${comp.component.replaceFirstChar { it.uppercase() }} verified throughput at $score score points.",
                testCount = comp.metrics.size.coerceAtLeast(1),
            )
        }

        // Real weighted geometric mean calculation
        val calculatedOverall = if (overall != null && overall.score > 0.0) {
            overall.score.roundToInt()
        } else {
            val logSum = valid.sumOf { ln(it.score.coerceAtLeast(1.0)) }
            val geoMean = exp(logSum / valid.size.coerceAtLeast(1))
            geoMean.roundToInt()
        }.coerceIn(0, 1100)

        val peakScore = categories.maxOfOrNull { it.peak } ?: calculatedOverall
        val sustainedScore = categories.firstOrNull { it.id == "thermal" }?.score ?: calculatedOverall

        val confidence = overall?.confidence?.times(100)?.roundToInt()
            ?: ((valid.map { it.confidence }.average().takeIf { !it.isNaN() } ?: 0.85) * 100).roundToInt()
        val cv = valid.map { it.cv }.average().takeIf { !it.isNaN() } ?: 0.02

        val date = SimpleDateFormat("d MMM yyyy · HH:mm", Locale.US).format(Date(startedAtMillis))
        val fallbackSoc = Build.HARDWARE.ifBlank { Build.BOARD }

        return RunRecord(
            id = "run_native_$startedAtMillis",
            startedAt = date,
            durationLabel = formatDuration(elapsedMs),
            deviceModel = DeviceTelemetryReader.deviceModel(),
            soc = DeviceTelemetryReader.socModel(fallbackSoc),
            overall = calculatedOverall,
            peak = peakScore.coerceAtMost(1100),
            sustained = sustainedScore.coerceAtMost(1100),
            confidence = confidence.coerceIn(0, 100),
            cvPct = (cv * 1000).roundToInt() / 10.0,
            categories = categories,
            conditions = conditions,
            methodologyVersion = "2.4.1-production",
            verified = false,
            note = "Production run · ${valid.size} probes measured on-device",
        )
    }

    private fun formatDuration(millis: Long): String {
        val totalSec = (millis / 1000L).coerceAtLeast(1)
        val m = totalSec / 60
        val s = totalSec % 60
        return if (m > 0) "${m}m ${s}s" else "${s}s"
    }

    private fun elapsedSeconds(startedNanos: Long): Int =
        ((System.nanoTime() - startedNanos) / 1_000_000_000L).toInt().coerceAtLeast(0)

    /* ------------------------------------------------------------------ */
    /* Resilient Fallbacks — HONEST, never fabricate scores.              */
    /* When the native bench-core library is unavailable, we report       */
    /* UNAVAILABLE (score 0.0) instead of inventing plausible numbers.    */
    /* NativeResultMapper filters out zero-score components, so the run   */
    /* simply reports fewer measured components rather than fake ones.    */
    /* ------------------------------------------------------------------ */

    /**
     * Reads the real GPU busy percentage from kernel counters.
     * Returns 0 (unmeasured) when the device exposes none — never a fabricated value.
     */
    private fun readGpuLoadPct(): Int {
        // Adreno (KGSL): gpubusy holds "<busy> <total>" counters
        File("/sys/class/kgsl/kgsl-3d0/gpubusy").readTextOrNull()?.trim()?.split(Regex("\\s+"))
            ?.takeIf { it.size >= 2 }
            ?.let { parts ->
                val busy = parts[0].toLongOrNull() ?: -1L
                val total = parts[1].toLongOrNull() ?: -1L
                if (busy >= 0 && total > 0) {
                    ((busy * 100.0) / total).toInt().coerceIn(0, 100)
                } else {
                    null
                }
            }
            ?.let { return it }
        // Mali and other vendors: percentage strings at varying sysfs paths
        for (path in listOf("/sys/kernel/gpu/gpu_busy", "/sys/kernel/fg_mali/gpu_busy")) {
            File(path).readTextOrNull()?.trim()?.removeSuffix("%")?.toIntOrNull()?.let { return it.coerceIn(0, 100) }
        }
        return 0
    }

    private fun unavailableResult(component: String, durationMs: Long): NativeComponentResult =
        NativeComponentResult(
            component = component,
            score = 0.0,
            band = "UNAVAILABLE",
            confidence = 0.0,
            cv = 0.0,
            durationMs = durationMs,
            notes = listOf("Native bench-core library unavailable; component not measured on this device"),
        )

    private fun runFallbackCpu(durationMs: Int, threads: Int): NativeComponentResult =
        unavailableResult("cpu", durationMs.toLong())

    private fun runFallbackContextSwitch(durationMs: Int, threads: Int): NativeComponentResult =
        unavailableResult("context_switch", durationMs.toLong())

    private fun runFallbackMemory(durationMs: Int): NativeComponentResult =
        unavailableResult("memory", durationMs.toLong())

    private fun runFallbackStorage(directory: File, durationMs: Int): NativeComponentResult =
        unavailableResult("storage", durationMs.toLong())

    private fun runFallbackGpu(frames: Int): NativeComponentResult =
        unavailableResult("gpu", frames * 16L)

    private fun runFallbackAi(durationMs: Int): NativeComponentResult =
        unavailableResult("ai", durationMs.toLong())

    private fun runFallbackSustained(durationMs: Int, threads: Int): NativeComponentResult =
        unavailableResult("sustained", durationMs.toLong())
}
