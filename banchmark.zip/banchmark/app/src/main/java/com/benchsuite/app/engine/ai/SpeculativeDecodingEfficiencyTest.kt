package com.benchsuite.app.engine.ai

import com.benchsuite.app.util.*

import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 3.7: Speculative Decoding Efficiency Test
 *
 * Benchmark draft model acceptance rates and end-to-end speedup when using speculative decoding
 * for LLM inference. Speculative decoding promises 2x speedup but acceptance rates vary.
 *
 * Data source: speculative decoding model per draft/target model pair and accelerator class.
 * Limitations: No real draft/target model pair; acceptance rate and speedup modeled per device
 * class, not fabricated measured values.
 */
object SpeculativeDecodingEfficiencyTest {

    data class SpeculativeResult(
        val draftModel: String,
        val targetModel: String,
        val acceptanceRatePct: Double,
        val tokensPerSecBaseline: Double,
        val tokensPerSecSpeculative: Double,
        val speedup: Double,
    )

    data class SpeculativeReport(
        val deviceClass: String,
        val results: List<SpeculativeResult>,
        val averageSpeedup: Double,
        val speculativeScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun deviceTier(): String {
        val hw = Build.HARDWARE.lowercase()
        return when {
            hw.contains("sm8") -> "Flagship"
            hw.contains("sm7") -> "Upper-midrange"
            hw.contains("sm6") -> "Mainstream"
            else -> "Entry-level"
        }
    }

    /**
     * Measures speculative decoding efficiency across model pairs.
     */
    fun runSpeculativeDecodingTest(): SpeculativeReport {
        val tier = deviceTier()
        val tierFactor = when (tier) {
            "Flagship" -> 1.0
            "Upper-midrange" -> 0.8
            "Mainstream" -> 0.6
            else -> 0.4
        }

        val pairs = listOf(
            Triple("TinyLlama-1.1B", "Llama-3-8B", 0.72),
            Triple("Llama-3.2-1B", "Llama-3-8B", 0.68),
            Triple("DistilBERT", "BERT-Large", 0.61),
        ).map { (draft, target, baseAccept) ->
            val accept = (baseAccept * tierFactor * 100.0).coerceIn(10.0, 95.0)
            val baselineTps = when (tier) {
                "Flagship" -> 38.0
                "Upper-midrange" -> 28.0
                "Mainstream" -> 18.0
                else -> 10.0
            }
            val speedup = 1.0 + (accept / 100.0) * 0.9 // max ~1.9x
            val speculativeTps = baselineTps * speedup
            SpeculativeResult(
                draftModel = draft,
                targetModel = target,
                acceptanceRatePct = (accept * 100.0).roundToInt() / 100.0,
                tokensPerSecBaseline = (baselineTps * 10.0).roundToInt() / 10.0,
                tokensPerSecSpeculative = (speculativeTps * 10.0).roundToInt() / 10.0,
                speedup = (speedup * 100.0).roundToInt() / 100.0,
            )
        }

        val avgSpeedup = pairs.averageOf { it.speedup }
        val score = when {
            avgSpeedup >= 1.6 -> 930
            avgSpeedup >= 1.3 -> 800
            avgSpeedup >= 1.1 -> 650
            else -> 480
        }

        val verdict = when {
            avgSpeedup >= 1.6 -> "Strong speculative decoding speedup; near 2x target."
            avgSpeedup >= 1.3 -> "Notable speedup from draft model acceptance."
            avgSpeedup >= 1.1 -> "Marginal speculative benefit."
            else -> "Little or no speculative decoding benefit on this device."
        }

        return SpeculativeReport(
            deviceClass = tier,
            results = pairs,
            averageSpeedup = (avgSpeedup * 100.0).roundToInt() / 100.0,
            speculativeScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real draft/target model pair; acceptance rate and speedup modeled per device tier.",
        )
    }
}
