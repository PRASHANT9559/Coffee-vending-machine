package com.benchsuite.app.data.mock

import java.io.File

import com.benchsuite.app.data.model.ActiveRun
import com.benchsuite.app.data.model.Badge
import com.benchsuite.app.data.model.BenchIcon
import com.benchsuite.app.data.model.CapabilityItem
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.CategorySpec
import com.benchsuite.app.data.model.ConsentItem
import com.benchsuite.app.data.model.DeviceProfile
import com.benchsuite.app.data.model.EnvironmentCheck
import com.benchsuite.app.data.model.FaqItem
import com.benchsuite.app.data.model.HistoryPoint
import com.benchsuite.app.data.model.Insight
import com.benchsuite.app.data.model.InsightSeverity
import com.benchsuite.app.data.model.LeaderboardEntry
import com.benchsuite.app.data.model.MetricValue
import com.benchsuite.app.data.model.NavigationShortcut
import com.benchsuite.app.data.model.PrivacyInventory
import com.benchsuite.app.data.model.Recommendation
import com.benchsuite.app.data.model.RecommendationArea
import com.benchsuite.app.data.model.ReportItem
import com.benchsuite.app.data.model.ReportType
import com.benchsuite.app.data.model.RunConditions
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.data.model.ScheduleItem
import com.benchsuite.app.data.model.StepState
import com.benchsuite.app.data.model.TestAvailability
import com.benchsuite.app.data.model.TestDefinition
import com.benchsuite.app.data.model.Trend
import com.benchsuite.app.data.model.UseCaseFit
import com.benchsuite.app.data.model.RunTestStep
import com.benchsuite.app.data.model.CheckStatus
import com.benchsuite.app.data.model.ChartSeries

/**
 * Local-first demo dataset for the UI milestone.
 * Every value is plausible for a 2026 flagship; the native engines will replace it.
 */
object Mock {

    /* ----------------------------- Device ---------------------------- */

    val device: DeviceProfile
        get() = com.benchsuite.app.nativecore.RealDeviceProfileProvider.build(null)

    /* --------------------------- Categories -------------------------- */

    val categories: List<CategoryScore> = listOf(
        CategoryScore(
            "cpu", "CPU", 1002, 1016, 942, 1.2, BenchIcon.CPU,
            "Scheduler keeps four big-core threads fed under mixed load.", 6,
        ),
        CategoryScore(
            "gpu", "GPU", 968, 1000, 871, -0.8, BenchIcon.GPU,
            "Class-leading peak, but sustained clocks settle 13% lower.", 6,
        ),
        CategoryScore(
            "memory", "Memory", 954, 972, 918, 0.4, BenchIcon.MEMORY,
            "LPDDR5X bandwidth is excellent; pressure cascade is average.", 4,
        ),
        CategoryScore(
            "storage", "Storage", 887, 912, 842, 2.1, BenchIcon.STORAGE,
            "Random IOPS are strong; metadata ops trail the class leader.", 6,
        ),
        CategoryScore(
            "ai", "AI", 912, 951, 803, 3.4, BenchIcon.AI,
            "NPU decode is fast, with a measurable thermal decay after 9 min.", 6,
        ),
        CategoryScore(
            "gaming", "Gaming", 923, 961, 848, 0.9, BenchIcon.GAMING,
            "Frame pacing is stable at 60 fps; 120 fps modes drop to 91%.", 6,
        ),
        CategoryScore(
            "thermal", "Thermal", 861, 1000, 861, -2.3, BenchIcon.THERMAL,
            "Skin temperature crosses 43 °C after 18 minutes of load.", 5,
        ),
        CategoryScore(
            "health", "Health", 92, 100, 92, 0.5, BenchIcon.HEALTH,
            "Battery and storage health are strong for 212 charge cycles.", 6,
        ),
    )

    /** Weighted categories shown in result screens (health is 0–100). */
    val scoreCategories: List<CategoryScore> = categories.filter { it.id != "health" }

    fun category(id: String): CategoryScore = categories.first { it.id == id }

    /* ---------------------------- Conditions ------------------------- */

    val conditions = RunConditions(
        batteryPct = 78,
        charging = false,
        batteryTempC = 31.4,
        ambientC = 24.0,
        backgroundLoadPct = 3,
        thermalStatus = "Light",
        freeStorageGb = 187.4,
        powerMode = "Performance",
    )

    /* ------------------------------ Runs ----------------------------- */

    private val demoScores = listOf(1002, 968, 954, 887, 912, 923, 861)

    val latestRun = RunRecord(
        id = "run_1042",
        startedAt = "11 Nov 2026 · 09:42",
        durationLabel = "14 min 08 s",
        deviceModel = device.model,
        soc = device.soc,
        overall = 942,
        peak = 1000,
        sustained = 861,
        confidence = 92,
        cvPct = 1.8,
        categories = categories,
        conditions = conditions,
        methodologyVersion = "2.4.1",
        verified = true,
        note = "Full suite · cool start",
    )

    val referenceRun = RunRecord(
        id = "run_0911",
        startedAt = "02 Nov 2026 · 18:10",
        durationLabel = "13 min 52 s",
        deviceModel = "Pixel 10 Pro",
        soc = "Tensor G6",
        overall = 871,
        peak = 934,
        sustained = 792,
        confidence = 89,
        cvPct = 2.6,
        categories = listOf(
            CategoryScore("cpu", "CPU", 921, 940, 874, -0.4, BenchIcon.CPU, "Broad stable scheduler.", 6),
            CategoryScore("gpu", "GPU", 884, 926, 801, 1.1, BenchIcon.GPU, "Efficient GPU, lower peak.", 6),
            CategoryScore("memory", "Memory", 870, 891, 842, 0.2, BenchIcon.MEMORY, "LPDDR5X at 8533 MT/s.", 4),
            CategoryScore("storage", "Storage", 812, 840, 780, 0.8, BenchIcon.STORAGE, "UFS 4.0, good random reads.", 6),
            CategoryScore("ai", "AI", 760, 812, 688, 4.2, BenchIcon.AI, "TPU strong on vision, slower decode.", 6),
            CategoryScore("gaming", "Gaming", 845, 902, 774, -1.0, BenchIcon.GAMING, "Stable 60 fps, warmer surface.", 6),
            CategoryScore("thermal", "Thermal", 790, 1000, 790, -3.1, BenchIcon.THERMAL, "Throttles earlier under soak.", 5),
        ),
        conditions = conditions.copy(batteryPct = 64, batteryTempC = 33.1, freeStorageGb = 91.2),
        methodologyVersion = "2.4.1",
        verified = true,
        note = "Reference device · same protocol",
    )

    val historyRuns: List<RunRecord> = emptyList()

    val historyPoints: List<HistoryPoint> = emptyList()

    /* ------------------------------ Tests ---------------------------- */

    // Test catalog has been extracted to data/catalog/TestCatalog.kt (Phase 3-B).
    // Use TestCatalog.tests / TestCatalog.categorySpecs instead of Mock.tests / Mock.categorySpecs.

    val insights: List<Insight> = listOf(
        Insight(
            "ins.thermal.primary",
            InsightSeverity.WARNING,
            "Thermals, not compute, set your ceiling",
            "Your CPU and GPU are fast enough for 120 fps, but the vapour chamber saturates after 18 minutes. Long sessions settle around 86% of peak.",
            "Peak 1.20 GHz → sustained 1.02 GHz · 44.6 °C skin",
            "Root cause",
        ),
        Insight(
            "ins.cpu.strength",
            InsightSeverity.STRENGTH,
            "Scheduler quality is top-tier",
            "Big-core promotion happens in 1.8 ms at p95, even with twelve background apps. This is why the phone feels fast in normal use.",
            "1,284 migrations · 0 dropped frames · 34 apps retained",
            "Strength",
        ),
        Insight(
            "ins.ai.fallback",
            InsightSeverity.CRITICAL,
            "Three AI operators run on the wrong unit",
            "Attention and rotary-embedding operators fall back from Hexagon to the GPU. Apps cannot see this, but it costs 18% decode speed.",
            "8 of 104 operators on GPU · 0.42 J/token",
            "AI",
        ),
        Insight(
            "ins.storage.metadata",
            InsightSeverity.WARNING,
            "Small-file I/O is the weak link",
            "Gallery indexing and large builds hit metadata operations 22% below the peer median, despite excellent sequential speeds.",
            "8,140 ops/s metadata · 22% behind median",
            "Storage",
        ),
        Insight(
            "ins.battery.strength",
            InsightSeverity.STRENGTH,
            "Battery health is holding up",
            "After 212 cycles the pack still delivers 94% of design capacity, with no voltage-sag shutdowns under load.",
            "94% capacity · 3.9% internal resistance rise",
            "Battery",
        ),
        Insight(
            "ins.confidence",
            InsightSeverity.INFO,
            "This result is easy to reproduce",
            "Coefficient of variation is 1.8% across three iterations, well inside the 3% quality gate. Conditions were recorded and normalized.",
            "Confidence 92% · CV 1.8% · methodology 2.4.1",
            "Trust",
        ),
    )

    /* ------------------------- Recommendations ----------------------- */

    val recommendations: List<Recommendation> = listOf(
        Recommendation(
            "rec.gaming.cap", RecommendationArea.GAMING,
            "Cap long sessions at 90 Hz",
            "120 Hz looks great for the first 12 minutes, but the governor then drops below 100 fps. A 90 Hz cap keeps frame pacing flat for the whole session.",
            "+12% consistency", "Low", "Apply for gaming",
        ),
        Recommendation(
            "rec.thermal.case", RecommendationArea.THERMAL,
            "Remove the case for long runs",
            "The back panel is the primary heat path. Removing the case cut skin temperature by 3.2 °C in our soak test and delayed throttling by four minutes.",
            "−3.2 °C skin", "Low", "Show cool-down tips",
        ),
        Recommendation(
            "rec.battery.charge", RecommendationArea.BATTERY,
            "Limit charging to 80%",
            "At 212 cycles you are on track for 2.8 years to 80% capacity. Capping daily charging at 80% typically adds 180–220 cycles.",
            "+180 cycles", "Low", "Open battery settings",
        ),
        Recommendation(
            "rec.ai.quant", RecommendationArea.AI,
            "Prefer INT8 models with vendor delegates",
            "Your decode speed is excellent but energy per token is average. INT8 builds with QNN coverage above 95% are 1.6× faster and use less power in our tests.",
            "1.6× tokens/s", "Medium", "See AI benchmark guide",
        ),
        Recommendation(
            "rec.storage.free", RecommendationArea.STORAGE,
            "Keep at least 20% storage free",
            "Random write IOPS fell 11% once free space dropped below 25% in the aging simulation. You are at 36%, which is healthy.",
            "+18% random write", "Low", "Manage storage",
        ),
        Recommendation(
            "rec.thermal.charge", RecommendationArea.THERMAL,
            "Do not game while fast charging",
            "Charging adds roughly 6 W of heat. Combined with a game, the first throttle step arrives nine minutes earlier.",
            "Delays throttle 9 min", "Low", "Set a charging reminder",
        ),
        Recommendation(
            "rec.ai.ctx", RecommendationArea.AI,
            "Keep local prompts under 8K context",
            "Decode speed is flat until 8K tokens, then falls 38% by 32K. Summarize or chunk long documents to stay in the fast region.",
            "2.1× faster answers", "Medium", "Read the context guide",
        ),
        Recommendation(
            "rec.upgrade", RecommendationArea.UPGRADE,
            "No upgrade needed this year",
            "Your unit ranks in the 82nd percentile for its model and beats the 2026 class median in six of seven categories. Upgrade only if you need 8K/120 fps recording.",
            "Save until 2028", "None", "Compare with new devices",
        ),
    )

    fun recommendationsFor(area: RecommendationArea?): List<Recommendation> =
        if (area == null) recommendations else recommendations.filter { it.area == area }

    /* ---------------------------- Use cases -------------------------- */

    val useCaseFits: List<UseCaseFit> = listOf(
        UseCaseFit("Gaming", 936, "120 fps for 12 min, stable 60 fps after.", BenchIcon.GAMING),
        UseCaseFit("Video editing", 901, "4K export finishes before thermal step-down.", BenchIcon.CAMERA),
        UseCaseFit("Offline AI", 928, "86 tok/s at 2K; 8K context is the sweet spot.", BenchIcon.AI),
        UseCaseFit("Battery life", 884, "Estimated 8 h 40 m screen-on time.", BenchIcon.BATTERY),
        UseCaseFit("Multitasking", 914, "34 apps retained; pressure cliff at 11.4 GB.", BenchIcon.MEMORY),
        UseCaseFit("Photography", 947, "Shutter-to-save 0.9 s, night mode 2.1 s.", BenchIcon.CAMERA),
    )

    /* ----------------------------- Charts ---------------------------- */

    val decayCurve: List<Float> = listOf(
        100f, 100f, 99.5f, 99f, 98.8f, 98.2f, 97.5f, 96.8f, 96f, 95.5f,
        94.2f, 93f, 91.5f, 90f, 89.2f, 88.4f, 87.6f, 86.8f, 86f, 85.2f,
        84.6f, 86.1f, 85.2f, 84.4f, 83.6f, 83f, 82.6f, 82.2f, 81.8f, 81.4f,
    )

    val frameTimeBuckets: List<Int> = listOf(
        1, 3, 9, 28, 61, 94, 118, 100, 72, 44, 26, 14, 7, 3, 1, 0,
    )

    val thermalSeries: List<Float> = listOf(
        28f, 29f, 30f, 31f, 32f, 33.5f, 35f, 36.2f, 37.4f, 38.1f,
        38.8f, 39.4f, 40f, 40.6f, 41.2f, 41.8f, 42.3f, 42.9f, 43.4f, 43.8f,
        44.1f, 44.4f, 44.6f, 44.5f, 44.4f, 44.2f, 44f, 43.8f, 43.6f, 43.4f,
    )

    val powerSeries: List<Float> = listOf(
        4.2f, 7.8f, 9.4f, 10.1f, 10.4f, 10.2f, 10.1f, 9.9f, 9.8f, 9.6f,
        9.5f, 9.3f, 9.2f, 9f, 8.9f, 8.7f, 8.6f, 8.5f, 8.3f, 8.2f,
    )

    val comparisonLatest: ChartSeries = ChartSeries("Galaxy S26 Ultra", scoreCategories.map { it.score.toFloat() }, 0)
    val comparisonReference: ChartSeries = ChartSeries("Pixel 10 Pro", referenceRun.categories.map { it.score.toFloat() }, 1)

    val radarLabels: List<String> = listOf("CPU", "GPU", "Memory", "Storage", "AI", "Gaming", "Thermal")

    /* ---------------------------- Reports ---------------------------- */

    val reports: List<ReportItem> = emptyList()

    val reportSections: List<String> = listOf(
        "Executive summary",
        "Score breakdown and confidence",
        "Peak vs sustained behaviour",
        "Thermal decay and throttle timeline",
        "AI insight and bottleneck analysis",
        "Use-case verdicts",
        "Device health and aging",
        "Conditions, methodology and signature",
    )

    /* --------------------------- Leaderboard ------------------------- */

    val leaderboard: List<LeaderboardEntry> = listOf(
        LeaderboardEntry(1, "RedMagic 11 Pro", "Snapdragon 8 Elite Gen 5", 1012, "Global", true, false, 0),
        LeaderboardEntry(2, "ROG Phone 10 Ultimate", "Snapdragon 8 Elite Gen 5", 1006, "Global", true, false, 1),
        LeaderboardEntry(3, "Galaxy S26 Ultra", "Snapdragon 8 Elite Gen 5", 942, "India", true, false, 2),
        LeaderboardEntry(4, "iQOO 15", "Snapdragon 8 Elite Gen 5", 938, "India", true, false, -1),
        LeaderboardEntry(5, "OnePlus 15", "Snapdragon 8 Elite Gen 5", 931, "Global", true, false, 0),
        LeaderboardEntry(6, "Xiaomi 17 Pro", "Snapdragon 8 Elite Gen 5", 927, "Global", true, false, 3),
        LeaderboardEntry(7, "Pixel 10 Pro", "Tensor G6", 871, "Global", true, false, -2),
        LeaderboardEntry(8, "Vivo X300 Pro", "Dimensity 9500", 864, "India", true, false, 0),
        LeaderboardEntry(9, "Galaxy S26+", "Exynos 2700", 842, "Global", true, false, 1),
        LeaderboardEntry(10, "OnePlus 13", "Snapdragon 8 Elite", 812, "India", true, false, -3),
        LeaderboardEntry(11, "Pixel 10", "Tensor G6", 786, "Global", true, false, 2),
        LeaderboardEntry(12, "Nothing Phone (4)", "Snapdragon 8s Gen 5", 742, "India", true, false, 0),
    )

    val peerPercentile: Int = 82
    val globalPercentile: Int = 74

    /* ----------------------------- Badges ---------------------------- */

    val badges: List<Badge> = listOf(
        Badge("b.first", "First run", "Completed a full benchmark suite.", true, BenchIcon.STAR),
        Badge("b.cool", "Cool head", "Finished a run under 35 °C.", true, BenchIcon.THERMAL),
        Badge("b.consistent", "Reproducible", "Three runs within 2% variance.", true, BenchIcon.SHIELD),
        Badge("b.ai", "Token master", "Benchmarked a local LLM above 50 tok/s.", true, BenchIcon.AI),
        Badge("b.storage", "Storage scientist", "Completed the fragmentation simulation.", true, BenchIcon.STORAGE),
        Badge("b.streak", "30-day streak", "Opened the app for 30 days.", false, BenchIcon.AGING),
        Badge("b.leader", "Top 100", "Reach the global top 100.", false, BenchIcon.LEADERBOARD),
        Badge("b.reviewer", "Reviewer mode", "Export a signed reviewer dataset.", false, BenchIcon.REPORT),
    )

    /* --------------------------- Schedules --------------------------- */

    val schedules: List<ScheduleItem> = listOf(
        ScheduleItem("sch.weekly", "Weekly health check", "Every Monday · 07:00", "Mon, 16 Nov · 07:00", "P2 · Scheduled", true),
        ScheduleItem("sch.monthly", "Monthly full suite", "First Sunday · 02:00", "Sun, 06 Dec · 02:00", "P2 · Scheduled", true),
        ScheduleItem("sch.aging", "Aging mini-suite", "Every 30 days", "Thu, 10 Dec · 03:30", "P3 · Background", true),
        ScheduleItem("sch.thermal", "Thermal soak", "One-off", "Queued · after next full run", "P1 · Suite", false),
    )

    /* ----------------------------- FAQ ------------------------------- */

    val faqs: List<FaqItem> = listOf(
        FaqItem(
            "Why do my scores differ between runs?",
            "Every score carries a confidence level based on variance. Run on a cool device, above 50% battery, with the case off and no heavy background apps. The app rejects runs above 3% coefficient of variation.",
        ),
        FaqItem(
            "What does sustained score mean?",
            "Peak is the best short burst. Sustained is what the device holds after 20–30 minutes. Long gaming, exports and AI sessions are governed by the sustained number.",
        ),
        FaqItem(
            "Is my data uploaded?",
            "No. Everything is local by default. Only signed results you explicitly submit appear on the leaderboard, and raw telemetry never leaves the device unless you export it.",
        ),
        FaqItem(
            "Why is a test marked limited?",
            "The capability check found a constraint, such as free storage, a missing vendor delegate, or a required on-demand model. The app explains the reason instead of failing.",
        ),
        FaqItem(
            "How is the overall score calculated?",
            "A weighted geometric mean of CPU, GPU, AI, sustained/thermal, memory, storage and real-world scores, normalized to a reference device where 1000 is the baseline.",
        ),
        FaqItem(
            "Can I trust a shared result?",
            "Every result bundle is signed with a hardware-backed key and includes conditions, methodology version and confidence. The app verifies signatures before showing a result as verified.",
        ),
    )

    /* -------------------------- Privacy ------------------------------ */

    val consents: List<ConsentItem> = listOf(
        ConsentItem("Local benchmark storage", "Scores, conditions and telemetry stay on this device.", true, true),
        ConsentItem("Leaderboard submission", "Upload signed scores and model-level hardware info.", false),
        ConsentItem("Peer percentiles", "Contribute anonymized scores to compute percentiles.", false),
        ConsentItem("Crash reports", "Privacy-safe stack traces to fix defects.", false),
        ConsentItem("Usage analytics", "Feature counters with no identifiers.", false),
    )

    val privacyInventory: List<PrivacyInventory> = listOf(
        PrivacyInventory("Run records", "Scores, conditions, device fingerprint, signature", "Kept until deleted"),
        PrivacyInventory("Raw telemetry", "Time series for temperature, clocks, power, frame time", "90 days"),
        PrivacyInventory("Reports", "Generated PDF, JSON and CSV files", "Until deleted"),
        PrivacyInventory("Install ID", "Random, resettable identifier for leaderboard submissions", "Until reset"),
    )

    /* ---------------------------- Helpers ---------------------------- */

    val environmentChecks: List<EnvironmentCheck> = listOf(
        EnvironmentCheck("Battery level", "78% · above the 50% threshold", CheckStatus.PASS),
        EnvironmentCheck("Charging", "Unplugged · required for power measurement", CheckStatus.PASS),
        EnvironmentCheck("Device temperature", "31.4 °C battery · 24 °C ambient", CheckStatus.PASS),
        EnvironmentCheck("Background load", "3% CPU · no heavy apps detected", CheckStatus.PASS),
        EnvironmentCheck("Free storage", "187.4 GB free · 36% of volume", CheckStatus.PASS),
        EnvironmentCheck("Thermal status", "Light · headroom available", CheckStatus.PASS),
        EnvironmentCheck("Power mode", "Performance mode enabled", CheckStatus.PASS),
    )

    val liveSteps: List<RunTestStep> = listOf(
        RunTestStep("Scheduler warmup", "CPU", StepState.DONE, "42 s · clocks stabilized"),
        RunTestStep("Context switch storm", "CPU", StepState.DONE, "2 min · 500 switches"),
        RunTestStep("Cache latency staircase", "CPU", StepState.ACTIVE, "sampling L1 → DRAM"),
        RunTestStep("Vulkan scene · 1440p", "GPU", StepState.PENDING, "3 min"),
        RunTestStep("Memory pressure cascade", "Memory", StepState.PENDING, "5 min"),
        RunTestStep("LLM decode · 2K context", "AI", StepState.PENDING, "6 min"),
        RunTestStep("30-minute thermal soak", "Thermal", StepState.PENDING, "30 min"),
        RunTestStep("Frame pacing scene", "Gaming", StepState.PENDING, "6 min"),
    )

    val activeRun = ActiveRun(
        categoryId = "full",
        title = "Full benchmark suite",
        totalTests = 22,
        completedTests = 9,
        currentTest = "Vulkan scene · 1440p",
        progress = 0.41f,
        elapsedSec = 348,
        etaSec = 500,
        liveFps = 112,
        temperatureC = 39.8,
        powerW = 8.6,
        cpuClockGhz = 3.42,
        paused = false,
        cooling = false,
    )

    val trendStats: List<com.benchsuite.app.data.model.TrendStat> = listOf(
        com.benchsuite.app.data.model.TrendStat("Overall", "942", "+14", Trend.UP),
        com.benchsuite.app.data.model.TrendStat("Sustained", "861", "−4", Trend.DOWN),
        com.benchsuite.app.data.model.TrendStat("Confidence", "92%", "+3", Trend.UP),
    )

    val shortcuts: List<NavigationShortcut> = listOf(
        NavigationShortcut("device", "Device info", "Full hardware and software map", BenchIcon.DEVICE),
        NavigationShortcut("leaderboard", "Leaderboard", "Verified global rankings", BenchIcon.LEADERBOARD),
        NavigationShortcut("compare", "Comparison", "Side-by-side runs and devices", BenchIcon.SPEED),
        NavigationShortcut("builder", "Custom builder", "Compose your own test suite", BenchIcon.TUNE),
        NavigationShortcut("scheduler", "Scheduler queue", "Priorities and background runs", BenchIcon.SETTINGS),
        NavigationShortcut("settings", "Settings", "Theme, units and run behavior", BenchIcon.SETTINGS),
        NavigationShortcut("about", "About", "Version, licenses and methodology", BenchIcon.INSIGHT),
    )
}
