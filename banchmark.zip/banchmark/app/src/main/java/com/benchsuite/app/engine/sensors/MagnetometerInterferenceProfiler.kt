package com.benchsuite.app.engine.sensors

import com.benchsuite.app.util.*

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.SystemClock
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 11.4: Magnetometer Interference Profiler
 *
 * Measure compass accuracy near speakers, wireless chargers, and metal objects. Compass errors
 * are common but unexplained; this identifies interference sources.
 *
 * Data source: SensorManager magnetometer samples averaged over a still window.
 * Limitations: No controlled interference source; accuracy inferred from field-vector variance,
 * not fabricated measured values.
 */
object MagnetometerInterferenceProfiler {

    data class FieldSample(
        val x: Double,
        val y: Double,
        val z: Double,
        val totalUtesla: Double,
    )

    data class MagnetometerResult(
        val sensorAvailable: Boolean,
        val samples: Int,
        val avgFieldUtesla: Double,
        val fieldVarianceUtesla: Double,
        val interferenceRisk: String,
        val accuracyScore: Int, // 0 - 100
    )

    data class MagnetometerReport(
        val result: MagnetometerResult,
        val verdict: String,
        val limitations: String,
    )

    private fun collectField(context: Context, durationMs: Long): MagnetometerResult {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        if (sensor == null) {
            return MagnetometerResult(false, 0, 0.0, 0.0, "No sensor", 0)
        }
        val latch = CountDownLatch(1)
        val samples = mutableListOf<FieldSample>()
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val x = event.values[0].toDouble()
                val y = event.values[1].toDouble()
                val z = event.values[2].toDouble()
                val total = kotlin.math.sqrt(x * x + y * y + z * z)
                samples.add(FieldSample(x, y, z, total))
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(listener, sensor, SensorManager.SENSOR_NORMAL)
        try { Thread.sleep(durationMs) } catch (e: InterruptedException) { Thread.currentThread().interrupt() } finally {
            sm.unregisterListener(listener)
        }
        val count = samples.size
        if (count == 0) return MagnetometerResult(true, 0, 0.0, 0.0, "No samples", 0)
        val avgField = samples.averageOf { it.totalUtesla }
        val variance = samples.map { (it.totalUtesla - avgField) * (it.totalUtesla - avgField) }.averageOrNull() ?: 0.0
        val stdDev = kotlin.math.sqrt(variance)
        val risk = when {
            stdDev <= 5.0 -> "Low interference"
            stdDev <= 15.0 -> "Moderate interference"
            else -> "High interference"
        }
        val accuracy = when {
            stdDev <= 5.0 -> 95
            stdDev <= 15.0 -> 75
            else -> 50
        }
        return MagnetometerResult(true, count, avgField, (stdDev * 100.0).roundToInt() / 100.0, risk, accuracy)
    }

    /**
     * Profiles magnetometer interference via magnetic-field variance sampling.
     */
    fun profileMagnetometer(context: Context): MagnetometerReport {
        val result = collectField(context, 800)
        val verdict = when {
            result.sensorAvailable && result.accuracyScore >= 80 -> "Low magnetic interference; compass is reliable for navigation."
            result.sensorAvailable -> "Moderate interference; compass may drift near metal or chargers."
            else -> "No magnetometer sensor detected."
        }
        return MagnetometerReport(result, verdict,
            "No controlled interference source; risk inferred from magnetic-field variance over a short window.")
    }
}
