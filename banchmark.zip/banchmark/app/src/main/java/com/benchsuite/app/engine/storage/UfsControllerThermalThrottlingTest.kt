package com.benchsuite.app.engine.storage

import com.benchsuite.app.util.*

import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 4.5: UFS Controller Thermal Throttling Test
 *
 * Runs sustained storage workloads and measures when the UFS controller throttles due to heat.
 * UFS 5.0 is fast but generates heat; sustained 8K recording can trigger storage throttling.
 *
 * Data source: sustained random write/read IOPS probe + /sys/class/power_supply thermal zone.
 * Limitations: Real UFS controller temperature is not directly exposed; thermal throttle is
 * inferred from sustained IOPS decay and battery temperature. No fabricated measured values.
 */
object UfsControllerThermalThrottlingTest {

    data class ThroughputPoint(
        val elapsedSec: Int,
        val writeMbps: Double,
        val readMbps: Double,
        val tempCelsius: Double,
    )

    data class UfsThermalReport(
        val storageType: String,
        val initialWriteMbps: Double,
        val sustainedWriteMbps: Double,
        val initialReadMbps: Double,
        val sustainedReadMbps: Double,
        val throttleDetected: Boolean,
        val throttleAfterSec: Int,
        val peakTempCelsius: Double,
        val points: List<ThroughputPoint>,
        val ufsThermalScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun readSysfsDouble(path: String, default: Double): Double =
        File(path).readTextOrNull()?.trim()?.toDoubleOrNull() ?: default

    private fun batteryTempCelsius(): Double {
        return readSysfsDouble("/sys/class/power_supply/battery/temp", 3000.0) / 10.0
    }

    private fun sustainedWriteProbe(durationSec: Int, blockSizeKb: Int): Double {
        val buffer = ByteArray(blockSizeKb * 1024)
        val file = File("/data/local/tmp/benchsuite_ufs_thermal_probe.bin")
        var bytes = 0L
        val startNs = SystemClock.elapsedRealtimeNanos()
        val endNs = startNs + durationSec.toLong() * 1_000_000_000L
        try {
            file.outputStream().use { out ->
                while (SystemClock.elapsedRealtimeNanos() < endNs) {
                    out.write(buffer)
                    bytes += buffer.size
                }
            }
        } catch (_: Exception) {}
        try { file.delete() } catch (_: Exception) {}
        val elapsedSec = max(1.0, (SystemClock.elapsedRealtimeNanos() - startNs) / 1_000_000_000.0)
        return (bytes / elapsedSec) / (1024.0 * 1024.0)
    }

    private fun sustainedReadProbe(durationSec: Int, blockSizeKb: Int): Double {
        val buffer = ByteArray(blockSizeKb * 1024)
        val file = File("/data/local/tmp/benchsuite_ufs_thermal_probe.bin")
        var bytes = 0L
        try {
            file.outputStream().use { out -> out.write(buffer) }
            val input = file.inputStream()
            val startNs = SystemClock.elapsedRealtimeNanos()
            val endNs = startNs + durationSec.toLong() * 1_000_000_000L
            while (SystemClock.elapsedRealtimeNanos() < endNs) {
                val n = input.read(buffer)
                if (n <= 0) break
                bytes += n
            }
            input.close()
        } catch (_: Exception) {}
        try { file.delete() } catch (_: Exception) {}
        val elapsedSec = max(1.0, (SystemClock.elapsedRealtimeNanos() - startNs) / 1_000_000_000.0)
        return (bytes / elapsedSec) / (1024.0 * 1024.0)
    }

    /**
     * Runs sustained UFS workload and detects controller thermal throttling.
     */
    fun runUfsThermalThrottleTest(): UfsThermalReport {
        val blockSizeKb = 128
        val phaseSec = 10
        val points = mutableListOf<ThroughputPoint>()
        var maxTemp = 0.0

        for (phase in 0 until 6) {
            val writeMbps = sustainedWriteProbe(phaseSec, blockSizeKb)
            val readMbps = sustainedReadProbe(phaseSec, blockSizeKb)
            val temp = batteryTempCelsius()
            maxTemp = max(maxTemp, temp)
            points.add(
                ThroughputPoint(
                    elapsedSec = (phase + 1) * phaseSec,
                    writeMbps = (writeMbps * 100.0).roundToInt() / 100.0,
                    readMbps = (readMbps * 100.0).roundToInt() / 100.0,
                    tempCelsius = (temp * 100.0).roundToInt() / 100.0,
                )
            )
            try { Thread.sleep(2000) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        }

        val initialWrite = points.first().writeMbps
        val sustainedWrite = points.last().writeMbps
        val initialRead = points.first().readMbps
        val sustainedRead = points.last().readMbps
        var throttleAfter = points.size * phaseSec
        var throttleDetected = false
        for (i in 1 until points.size) {
            if (points[i].writeMbps < points[i - 1].writeMbps * 0.75) {
                throttleDetected = true
                throttleAfter = points[i].elapsedSec
                break
            }
        }

        val score = when {
            !throttleDetected && sustainedWrite >= initialWrite * 0.9 -> 920
            !throttleDetected -> 780
            throttleAfter >= 40 -> 600
            throttleAfter >= 20 -> 450
            else -> 300
        }

        val verdict = when {
            !throttleDetected -> "UFS controller sustains peak bandwidth; no thermal throttle detected."
            throttleAfter >= 40 -> "Throttle detected after ${throttleAfter}s; acceptable for most workloads."
            else -> "Early UFS thermal throttle; sustained storage performance will degrade."
        }

        return UfsThermalReport(
            storageType = "UFS",
            initialWriteMbps = (initialWrite * 100.0).roundToInt() / 100.0,
            sustainedWriteMbps = (sustainedWrite * 100.0).roundToInt() / 100.0,
            initialReadMbps = (initialRead * 100.0).roundToInt() / 100.0,
            sustainedReadMbps = (sustainedRead * 100.0).roundToInt() / 100.0,
            throttleDetected = throttleDetected,
            throttleAfterSec = throttleAfter,
            peakTempCelsius = (maxTemp * 100.0).roundToInt() / 100.0,
            points = points,
            ufsThermalScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "Real UFS controller die temperature is not exposed; throttle inferred from sustained IOPS decay and battery temp.",
        )
    }
}
