package com.benchsuite.app.features.data

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Leaderboard
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.model.LeaderboardEntry
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.FilterPills
import com.benchsuite.app.ui.components.LeaderboardRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun LeaderboardScreen(onBack: () -> Unit) {
    var filter by rememberSaveable { mutableIntStateOf(0) }

    // Real leaderboard from signed runs recorded on this device — no fabricated peer data.
    val runs = SessionState.completedRuns
    val entries: List<LeaderboardEntry> = runs.sortedByDescending { it.overall }.withIndex().map { (i, r) ->
        LeaderboardEntry(
            rank = i + 1,
            model = r.deviceModel,
            soc = r.soc,
            score = r.overall,
            region = "—",
            verified = r.methodologyVersion.endsWith("-native"),
            isMine = r.id == SessionState.lastCompletedRunId,
            deltaRank = 0,
        )
    }
    val mine = entries.firstOrNull { it.isMine }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Leaderboard",
            subtitle = "Verified, signed runs only",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Community",
                    title = "Where you actually rank.",
                    body = "Every entry is a signed run with recorded conditions. Benchmark-whitelist detection rejects boosted scores.",
                )
            }

            if (mine != null) {
                item {
                    SurfaceCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.EmojiEvents, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Your position", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            StatusChip("Not ranked yet", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(Spacing.sm))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Column(Modifier.weight(1f)) {
                                Text("#${mine.rank}", style = NumericDisplay.copy(fontSize = 40.sp))
                                Text(
                                    "of ${entries.size} recorded runs on this device",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(mine.score.toString(), style = NumericSmall.copy(fontSize = 22.sp), color = MaterialTheme.colorScheme.primary)
                                Text(
                                    if (mine.deltaRank >= 0) "▲ ${mine.deltaRank} this week" else "▼ ${-mine.deltaRank} this week",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (mine.deltaRank >= 0) BenchTheme.colors.success else BenchTheme.colors.danger,
                                )
                            }
                        }
                        Spacer(Modifier.height(Spacing.sm))
                        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                            PercentileStat("Peer percentile", "—", Modifier.weight(1f))
                            PercentileStat("Global", "—", Modifier.weight(1f))
                            PercentileStat("Verified", "${entries.count { it.verified }}", Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                FilterPills(
                    options = listOf("Global", "India", "Verified"),
                    selectedIndex = filter,
                    onSelect = { filter = it },
                )
            }

            item {
                SectionHeader(
                    title = if (filter == 1) "India" else if (filter == 2) "Verified entries" else "Global ranking",
                )
            }

            item {
                SurfaceCard(contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) {
                    entries.forEachIndexed { index, entry ->
                        LeaderboardRow(entry)
                        if (index != entries.lastIndex) {
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                color = BenchTheme.colors.outlineSubtle,
                            )
                        }
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Verified, null, tint = BenchTheme.colors.success, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("How verification works", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "A score is accepted only if the result bundle signature validates, the methodology version is current, variance is under 3%, and the app detected no frequency-lock or benchmark-whitelist behavior.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusChip("Hardware-backed", tint = MaterialTheme.colorScheme.primary)
                        StatusChip("Anti-cheat", tint = MaterialTheme.colorScheme.secondary)
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Lock, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Leaderboard upload is off by default. Enable it in Privacy and data. Only the score and model-level hardware are uploaded.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Public, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Regions are coarse and self-declared. No location permission is used.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun PercentileStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = NumericSmall, color = MaterialTheme.colorScheme.onSurface)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
