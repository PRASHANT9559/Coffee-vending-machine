package com.benchsuite.app.nativecore

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import com.benchsuite.app.data.model.CapabilityItem
import com.benchsuite.app.data.model.DeviceProfile
import java.io.File
import kotlin.math.roundToInt

object RealDeviceProfileProvider {

    fun build(context: Context?): DeviceProfile {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = DeviceTelemetryReader.deviceModel()
        val soc = DeviceTelemetryReader.socModel(Build.HARDWARE.ifBlank { Build.BOARD })

        val cores = Runtime.getRuntime().availableProcessors()
        val maxGhz = DeviceTelemetryReader.readMaxClockGhz(cores)
        val cpuTopology = "$cores Cores · up to ${String.format(java.util.Locale.US, "%.2f", maxGhz)} GHz"

        val vulkanCaps = if (NativeBridge.isAvailable) NativeBridge.scanVulkanCapabilities() else null
        val gpu = if (vulkanCaps?.supported == true && vulkanCaps.deviceName.isNotBlank()) {
            "${vulkanCaps.deviceName} · Vulkan ${vulkanCaps.apiVersion}"
        } else {
            "${Build.HARDWARE} GPU · Hardware Accelerated"
        }

        val npu = if (Build.VERSION.SDK_INT >= 31) "Android NN / Hardware AI Delegate" else "CPU LiteRT Optimized"

        val ramTotalGb = readTotalRamGb()
        val ramStr = if (ramTotalGb > 0) "$ramTotalGb GB" else "System RAM"

        val storageTotalGb = readTotalStorageGb()
        val storageStr = if (storageTotalGb > 0) "$storageTotalGb GB" else "Flash Storage"

        val freeStorageGb = (context?.filesDir?.usableSpace ?: Environment.getDataDirectory().usableSpace)
            .coerceAtLeast(0L) / 1_073_741_824.0

        val thermalZones = countThermalZones()

        val pm = context?.packageManager

        val hasVulkan = vulkanCaps?.supported ?: (pm?.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL) == true)
        val hasRayTracing = vulkanCaps?.features?.get("rayTracing") == true || vulkanCaps?.extensions?.any { it.contains("ray_tracing", ignoreCase = true) } == true
        val hasMeshShaders = vulkanCaps?.extensions?.any { it.contains("mesh_shader", ignoreCase = true) } == true
        val hasWifi = pm?.hasSystemFeature(PackageManager.FEATURE_WIFI) ?: true
        val hasUwb = if (Build.VERSION.SDK_INT >= 31) pm?.hasSystemFeature("android.hardware.uwb") == true else false
        val hasAudioLe = if (Build.VERSION.SDK_INT >= 33) pm?.hasSystemFeature("android.hardware.bluetooth_le") == true else true

        val capabilities = listOf(
            CapabilityItem(
                title = "Vulkan Support",
                supported = hasVulkan,
                detail = vulkanCaps?.apiVersion?.let { "Vulkan $it" } ?: "Hardware GLES/Vulkan",
            ),
            CapabilityItem(
                title = "Hardware Ray Tracing",
                supported = hasRayTracing,
                detail = if (hasRayTracing) "Hardware BVH Traversal supported" else "Software / Compute fallback",
            ),
            CapabilityItem(
                title = "Mesh Shaders",
                supported = hasMeshShaders,
                detail = if (hasMeshShaders) "VK_EXT_mesh_shader supported" else "Standard Vertex/Fragment Pipeline",
            ),
            CapabilityItem(
                title = "Async Compute",
                supported = (vulkanCaps?.queueFamilies?.size ?: 0) > 1,
                detail = if ((vulkanCaps?.queueFamilies?.size ?: 0) > 1) "Dedicated compute queue available" else "Shared graphics queue",
            ),
            CapabilityItem(
                title = "AI / Neural Accelerator",
                supported = true,
                detail = if (Build.VERSION.SDK_INT >= 31) "LiteRT NPU / GPU Acceleration" else "Int8 CPU Accelerated",
            ),
            CapabilityItem(
                title = "High-Bandwidth Wi-Fi",
                supported = hasWifi,
                detail = if (hasWifi) "Wi-Fi MLO & Dual-Band capable" else "Cellular / Ethernet only",
            ),
            CapabilityItem(
                title = "Ultra-Wideband (UWB)",
                supported = hasUwb,
                detail = if (hasUwb) "Fine Ranging FiRa active" else "Not supported on this hardware",
            ),
            CapabilityItem(
                title = "Bluetooth LE Audio",
                supported = hasAudioLe,
                detail = if (hasAudioLe) "Low-latency LC3 codec" else "Standard Bluetooth Audio",
            ),
        )

        val osVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        val secPatch = if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "Unknown"
        val kernelVersion = System.getProperty("os.version") ?: "Linux"

        val telemetry = context?.let { DeviceTelemetryReader.read(it) }
        val batteryPct = telemetry?.batteryPct ?: 90
        val isCharging = telemetry?.charging ?: false

        return DeviceProfile(
            manufacturer = manufacturer,
            model = model,
            soc = soc,
            cpuTopology = cpuTopology,
            gpu = gpu,
            npu = npu,
            ram = ramStr,
            ramType = "Unknown",
            storage = storageStr,
            storageType = "Unknown",
            display = "Unknown",
            resolution = "Unknown",
            refresh = "Unknown",
            os = osVersion,
            securityPatch = secPatch,
            kernel = kernelVersion,
            battery = "Unknown",
            charging = if (isCharging) "Charging active" else "Discharging (Battery)",
            build = Build.DISPLAY.ifBlank { Build.ID },
            fingerprint = Build.FINGERPRINT,
            thermalZones = thermalZones,
            capabilities = capabilities,
            storageFreeGb = (freeStorageGb * 10.0).roundToInt() / 10.0,
            batteryHealthPct = batteryPct,
            batteryCycles = -1,
        )
    }

    private fun readTotalRamGb(): Int {
        return try {
            val memInfo = File("/proc/meminfo")
            if (memInfo.exists()) {
                val line = memInfo.useLines { lines -> lines.firstOrNull { it.startsWith("MemTotal:") } }
                val kb = line?.replace(Regex("[^0-9]"), "")?.toLongOrNull() ?: 0L
                if (kb > 0) {
                    val gb = kb.toDouble() / (1024 * 1024)
                    Math.round(gb).toInt().coerceAtLeast(1)
                } else 0
            } else 0
        } catch (_: Exception) {
            0
        }
    }

    private fun readTotalStorageGb(): Int {
        return try {
            val bytes = Environment.getDataDirectory().totalSpace
            if (bytes > 0) {
                val gb = bytes.toDouble() / (1000 * 1000 * 1000)
                when {
                    gb <= 36 -> 32
                    gb <= 70 -> 64
                    gb <= 140 -> 128
                    gb <= 280 -> 256
                    gb <= 560 -> 512
                    else -> Math.round(gb).toInt()
                }
            } else 0
        } catch (_: Exception) {
            0
        }
    }

    private fun countThermalZones(): Int {
        return try {
            val dir = File("/sys/class/thermal")
            if (dir.exists() && dir.isDirectory) {
                dir.listFiles { f -> f.name.startsWith("thermal_zone") }?.size ?: 0
            } else 0
        } catch (_: Exception) {
            0
        }
    }
}
