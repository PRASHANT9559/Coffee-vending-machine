package com.benchsuite.app.engine.network

import android.content.Context
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 5.5: eSIM Profile Switching Speed Test
 *
 * Measures time to download, activate, and handover data between eSIM profiles. Reality is often
 * 5+ minutes of friction; this benchmarks provisioning performance.
 *
 * Data source: eSIM capability detection via telephony + deterministic provisioning model.
 * Limitations: No real eSIM download/activation (EuiccManager) is invoked without carrier
 * entitlement; times are modeled per detected eSIM capability, not fabricated measured values.
 */
object EsimProfileSwitchingSpeedTest {

    enum class EsimCapability(val label: String) {
        SUPPORTED("eSIM profile download and switching supported"),
        LIMITED("eSIM present but carrier-locked or single profile"),
        NOT_SUPPORTED("No eSIM capability detected"),
        UNKNOWN("eSIM capability unknown"),
    }

    data class EsimStage(
        val stageName: String,
        val durationMs: Double,
        val description: String,
    )

    data class EsimReport(
        val capability: EsimCapability,
        val downloadMs: Double,
        val activateMs: Double,
        val handoverMs: Double,
        val totalSwitchMs: Double,
        val stages: List<EsimStage>,
        val esimScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun detectEsimCapability(context: Context?): EsimCapability {
        val tm = context?.getSystemService(Context.TELEPHONY_SERVICE) as? android.telephony.TelephonyManager
        val hasEuicc = try {
            context?.packageManager?.hasSystemFeature("android.hardware.telephony.euicc") ?: false
        } catch (_: Exception) {
            false
        }
        val phoneCount = tm?.phoneCount ?: 0
        return when {
            hasEuicc && phoneCount >= 2 -> EsimCapability.SUPPORTED
            hasEuicc -> EsimCapability.LIMITED
            Build.HARDWARE.lowercase().contains("qcom") || Build.HARDWARE.lowercase().contains("exynos") ->
                EsimCapability.UNKNOWN
            else -> EsimCapability.NOT_SUPPORTED
        }
    }

    /**
     * Measures eSIM profile download, activation, and handover time via deterministic model.
     */
    fun runEsimSwitchTest(context: Context?): EsimReport {
        val capability = detectEsimCapability(context)

        val (download, activate, handover) = when (capability) {
            EsimCapability.SUPPORTED -> Triple(45000.0, 18000.0, 8000.0)
            EsimCapability.LIMITED -> Triple(90000.0, 30000.0, 15000.0)
            EsimCapability.UNKNOWN -> Triple(120000.0, 45000.0, 20000.0)
            EsimCapability.NOT_SUPPORTED -> Triple(0.0, 0.0, 0.0)
        }

        val total = download + activate + handover
        val stages = listOf(
            EsimStage("Profile download (SM-DP+)", download, "Download eSIM profile from subscription manager"),
            EsimStage("Profile activation", activate, "Install and enable eSIM profile on modem"),
            EsimStage("Data handover", handover, "Handover data session to newly active profile"),
        )

        val score = when {
            capability == EsimCapability.SUPPORTED && total <= 90000.0 -> 920
            capability == EsimCapability.SUPPORTED -> 780
            capability == EsimCapability.LIMITED -> 560
            capability == EsimCapability.UNKNOWN -> 420
            else -> 200
        }

        val verdict = when {
            capability == EsimCapability.SUPPORTED -> "eSIM switching ~${"%.0f".format(total / 1000.0)}s; instant carrier switching feasible."
            capability == EsimCapability.LIMITED -> "eSIM present but switching is slow or carrier-limited."
            else -> "No usable eSIM profile switching capability detected."
        }

        return EsimReport(
            capability = capability,
            downloadMs = (download * 10.0).roundToInt() / 10.0,
            activateMs = (activate * 10.0).roundToInt() / 10.0,
            handoverMs = (handover * 10.0).roundToInt() / 10.0,
            totalSwitchMs = (total * 10.0).roundToInt() / 10.0,
            stages = stages,
            esimScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real eSIM download/activation invoked; times are modeled per detected eSIM capability class.",
        )
    }
}
