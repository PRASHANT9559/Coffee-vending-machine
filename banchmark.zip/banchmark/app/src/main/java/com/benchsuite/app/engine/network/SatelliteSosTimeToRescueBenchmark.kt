package com.benchsuite.app.engine.network

import android.content.Context
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 5.3: Satellite SOS Time-to-Rescue Benchmark
 *
 * Measures time from SOS initiation to message delivery via satellite, including sky-scan,
 * satellite acquisition, and transmission. Satellite emergency features are life-critical.
 *
 * Data source: satellite-capability detection via Build/telephony and a deterministic timing model.
 * Limitations: No real satellite modem or emergency SOS API is invoked; times are modeled per
 * detected satellite capability class, not fabricated measured values.
 */
object SatelliteSosTimeToRescueBenchmark {

    enum class SatelliteCapability(val label: String) {
        NONE("No satellite SOS capability detected"),
        EMERGENCY_ONLY("Emergency SOS text-only satellite"),
        FULL_MESSAGING("Satellite two-way messaging available"),
        UNKNOWN("Satellite capability unknown"),
    }

    data class SosPhase(
        val phaseName: String,
        val durationMs: Double,
        val description: String,
    )

    data class SosBenchmarkReport(
        val capability: SatelliteCapability,
        val skyScanMs: Double,
        val acquisitionMs: Double,
        val transmissionMs: Double,
        val totalTimeToRescueMs: Double,
        val phases: List<SosPhase>,
        val meetsEmergencyThreshold: Boolean,
        val sosScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun detectSatelliteCapability(context: Context?): SatelliteCapability {
        val hasFeature = context?.packageManager?.hasSystemFeature("android.hardware.satellite") ?: false
        val manufacturer = Build.MANUFACTURER.lowercase()
        val model = Build.MODEL.lowercase()
        // Satellite SOS is vendor-specific; only a few 2024+ flagships expose it
        if (hasFeature || manufacturer.contains("apple") || model.contains("satellite")) {
            return SatelliteCapability.FULL_MESSAGING
        }
        if (manufacturer.contains("samsung") || manufacturer.contains("google")) {
            return SatelliteCapability.EMERGENCY_ONLY
        }
        return SatelliteCapability.NONE
    }

    /**
     * Measures satellite SOS time-to-rescue stages via a deterministic model.
     */
    fun runSosBenchmark(context: Context?): SosBenchmarkReport {
        val capability = detectSatelliteCapability(context)

        // Stage timings modeled per capability class (not real satellite measurements)
        val (skyScan, acquisition, transmission) = when (capability) {
            SatelliteCapability.FULL_MESSAGING -> Triple(8500.0, 12000.0, 4500.0)
            SatelliteCapability.EMERGENCY_ONLY -> Triple(12000.0, 18000.0, 6000.0)
            SatelliteCapability.NONE -> Triple(0.0, 0.0, 0.0)
            SatelliteCapability.UNKNOWN -> Triple(15000.0, 25000.0, 8000.0)
        }

        val total = skyScan + acquisition + transmission
        val phases = listOf(
            SosPhase("Sky scan & obstruction check", skyScan, "Scanning for unobstructed satellite visibility"),
            SosPhase("Satellite acquisition", acquisition, "Acquiring LEO satellite link and handshake"),
            SosPhase("Message transmission", transmission, "Transmitting SOS payload to ground station"),
        )
        val emergencyThreshold = 60000.0 // 60 seconds considered acceptable for SOS

        val score = when {
            capability == SatelliteCapability.FULL_MESSAGING && total <= 30000.0 -> 950
            capability == SatelliteCapability.FULL_MESSAGING -> 800
            capability == SatelliteCapability.EMERGENCY_ONLY -> 650
            capability == SatelliteCapability.NONE -> 200
            else -> 450
        }

        val verdict = when {
            capability == SatelliteCapability.FULL_MESSAGING -> "Satellite SOS available; end-to-end ~${"%.0f".format(total / 1000.0)}s to rescue."
            capability == SatelliteCapability.EMERGENCY_ONLY -> "Emergency-only satellite texting detected."
            else -> "No satellite SOS capability detected on this device."
        }

        return SosBenchmarkReport(
            capability = capability,
            skyScanMs = (skyScan * 10.0).roundToInt() / 10.0,
            acquisitionMs = (acquisition * 10.0).roundToInt() / 10.0,
            transmissionMs = (transmission * 10.0).roundToInt() / 10.0,
            totalTimeToRescueMs = (total * 10.0).roundToInt() / 10.0,
            phases = phases,
            meetsEmergencyThreshold = total <= emergencyThreshold,
            sosScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real satellite modem/SOS API; stage timings are modeled per detected satellite capability class.",
        )
    }
}
