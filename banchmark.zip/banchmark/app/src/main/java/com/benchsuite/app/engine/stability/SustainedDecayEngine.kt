package com.benchsuite.app.engine.stability

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 1.5: Sustained Performance Decay Curve Engine.
 *
 * Models and characterizes compute degradation over continuous multi-minute stress runs:
 * - Samples compute throughput every 5–30 seconds
 * - Computes Peak vs Sustained Retention Percentage
 * - Identifies Time-to-Throttle (Initial 10% drop and Half-Life t1/2)
 * - Detects Knee / Inflection Points in the decay curve where thermal governors intervene
 * - Computes Throttling Slope Coefficient (Δscore / Δt)
 * - Emits time-series chart coordinates and plain-English thermal decay conclusions
 */
object SustainedDecayEngine {

    data class DecaySample(
        val elapsedSec: Int,
        val score: Double,
        val temperatureC: Double,
        val cpuClockGhz: Double = 0.0,
        val powerW: Double = 0.0,
    )

    data class InflectionPoint(
        val timestampSec: Int,
        val score: Double,
        val temperatureC: Double,
        val slopePtsPerSec: Double,
        val description: String,
    )

    data class DecayCurveReport(
        val durationSec: Int,
        val sampleCount: Int,
        val peakScore: Double,
        val sustainedScore: Double,
        val retentionPercentage: Double,
        val initialThrottleSec: Int?, // Time to first 10% decay from peak
        val halfLifeSec: Int?, // Time to 50% of the total thermal decay
        val throttlingSlopePtsPerSec: Double,
        val inflectionPoints: List<InflectionPoint>,
        val peakTemperatureC: Double,
        val temperatureRampC: Double,
        val normalizedCurvePoints: List<Float>, // 0 - 100% of peak for UI charts
        val decayVerdict: String,
        val thermalConclusions: List<String>,
    )

    /**
     * Evaluates a sequence of continuous stress workload [samples].
     */
    fun evaluate(samples: List<DecaySample>): DecayCurveReport {
        if (samples.isEmpty()) {
            return emptyReport()
        }

        val duration = samples.last().elapsedSec - samples.first().elapsedSec
        val count = samples.size

        // 1. Peak score: average of the initial 10% of samples (or first 3)
        val initialCount = max(2, min(5, (count * 0.15).roundToInt()))
        val peakScore = samples.take(initialCount).map { it.score }.average().coerceAtLeast(1.0)

        // 2. Sustained score: average of the final 25% steady-state plateau
        val finalCount = max(2, (count * 0.25).roundToInt())
        val sustainedScore = samples.takeLast(finalCount).map { it.score }.average().coerceAtLeast(1.0)

        // 3. Retention percentage: sustained / peak
        val retention = ((sustainedScore / peakScore) * 1000.0).roundToInt() / 10.0

        // 4. Time to initial throttle (first sample dropping >= 10% below peak)
        val initialThrottleSec = samples.firstOrNull { it.score <= (peakScore * 0.90) }?.elapsedSec

        // 5. Half-life (t1/2): time until performance drops halfway between peak and sustained floor
        val halfDropTarget = peakScore - (0.5 * (peakScore - sustainedScore))
        val halfLifeSec = if (peakScore - sustainedScore >= 15.0) {
            samples.firstOrNull { it.score <= halfDropTarget }?.elapsedSec
        } else {
            null
        }

        // 6. Inflection points (knee points in curvature)
        val inflections = detectInflections(samples, peakScore)

        // 7. Throttling slope during the active decay phase
        val slope = calculateDecaySlope(samples, peakScore, sustainedScore)

        // 8. Normalized curve points (0 - 100% of peak)
        val curvePoints = samples.map {
            ((it.score / peakScore) * 100f).coerceIn(0f, 120f)
        }

        val peakTemp = samples.maxOfOrNull { it.temperatureC } ?: 30.0
        val initialTemp = samples.firstOrNull()?.temperatureC ?: 30.0
        val tempRamp = max(0.0, peakTemp - initialTemp)

        val verdict = when {
            retention >= 92.0 -> "Exceptional Thermal Endurance. Sustained retention held at ${retention.roundToInt()}% of peak with minimal governor stepping."
            retention >= 80.0 -> "Good Sustained Output. Device retained ${retention.roundToInt()}% performance; mild throttle occurred at ${initialThrottleSec?.let { "${it}s" } ?: "mid-run"}."
            retention >= 65.0 -> "Moderate Thermal Throttling. Compute decayed by ${(100 - retention).roundToInt()}%; half-life reached in ${halfLifeSec?.let { "${it}s" } ?: "early phase"}."
            else -> "Severe Thermal Collapse. Performance declined to ${retention.roundToInt()}% of baseline as cooling solution reached heat saturation."
        }

        val conclusions = mutableListOf<String>()
        conclusions.add("Peak Initial Output: ${(peakScore * 10).roundToInt() / 10.0} pts | Sustained Plateau: ${(sustainedScore * 10).roundToInt() / 10.0} pts (${retention}% retention).")
        if (initialThrottleSec != null) {
            conclusions.add("Thermal Knee Event: First significant step-down occurred at t=${initialThrottleSec}s as battery reached ${(samples.firstOrNull { it.elapsedSec == initialThrottleSec }?.temperatureC ?: peakTemp)}°C.")
        }
        if (halfLifeSec != null) {
            conclusions.add("Throttling Half-Life: Performance reached halfway degradation point in ${halfLifeSec}s.")
        }
        conclusions.add("Cooling Thermal Ramp: Surface temperature climbed by +${(tempRamp * 10).roundToInt() / 10.0}°C to a maximum of ${(peakTemp * 10).roundToInt() / 10.0}°C.")

        return DecayCurveReport(
            durationSec = max(1, duration),
            sampleCount = count,
            peakScore = (peakScore * 10.0).roundToInt() / 10.0,
            sustainedScore = (sustainedScore * 10.0).roundToInt() / 10.0,
            retentionPercentage = retention,
            initialThrottleSec = initialThrottleSec,
            halfLifeSec = halfLifeSec,
            throttlingSlopePtsPerSec = (slope * 100.0).roundToInt() / 100.0,
            inflectionPoints = inflections,
            peakTemperatureC = (peakTemp * 10.0).roundToInt() / 10.0,
            temperatureRampC = (tempRamp * 10.0).roundToInt() / 10.0,
            normalizedCurvePoints = curvePoints,
            decayVerdict = verdict,
            thermalConclusions = conclusions,
        )
    }

    private fun detectInflections(samples: List<DecaySample>, peakScore: Double): List<InflectionPoint> {
        val points = mutableListOf<InflectionPoint>()
        if (samples.size < 6) return points

        for (i in 2 until samples.size - 2) {
            val prev = samples[i - 1]
            val curr = samples[i]
            val next = samples[i + 1]

            val dt1 = (curr.elapsedSec - prev.elapsedSec).coerceAtLeast(1)
            val dt2 = (next.elapsedSec - curr.elapsedSec).coerceAtLeast(1)

            val slope1 = (curr.score - prev.score) / dt1
            val slope2 = (next.score - curr.score) / dt2
            val curvature = slope2 - slope1

            // Knee point detected if curvature changes sharply and curr is below peak
            if (abs(curvature) > 1.2 && curr.score < peakScore * 0.95) {
                points.add(
                    InflectionPoint(
                        timestampSec = curr.elapsedSec,
                        score = (curr.score * 10.0).roundToInt() / 10.0,
                        temperatureC = curr.temperatureC,
                        slopePtsPerSec = (slope1 * 100.0).roundToInt() / 100.0,
                        description = "Governor step inflection at t=${curr.elapsedSec}s: rate changed from ${(slope1 * 10).roundToInt() / 10.0} to ${(slope2 * 10).roundToInt() / 10.0} pts/s at ${curr.temperatureC}°C.",
                    )
                )
            }
        }
        return points.take(4) // Report up to 4 primary knee points
    }

    private fun calculateDecaySlope(samples: List<DecaySample>, peak: Double, sustained: Double): Double {
        val startSample = samples.firstOrNull { it.score <= peak * 0.95 } ?: return 0.0
        val endSample = samples.firstOrNull { it.score <= sustained * 1.05 } ?: samples.last()
        val dt = (endSample.elapsedSec - startSample.elapsedSec).coerceAtLeast(1)
        val dScore = endSample.score - startSample.score
        return abs(dScore / dt)
    }

    private fun emptyReport() = DecayCurveReport(
        durationSec = 0,
        sampleCount = 0,
        peakScore = 0.0,
        sustainedScore = 0.0,
        retentionPercentage = 100.0,
        initialThrottleSec = null,
        halfLifeSec = null,
        throttlingSlopePtsPerSec = 0.0,
        inflectionPoints = emptyList(),
        peakTemperatureC = 0.0,
        temperatureRampC = 0.0,
        normalizedCurvePoints = emptyList(),
        decayVerdict = "No sustained decay samples available.",
        thermalConclusions = emptyList(),
    )
}
