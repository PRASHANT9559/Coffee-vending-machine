package com.benchsuite.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.LocalReduceMotion
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.NumericMedium
import com.benchsuite.app.ui.theme.NumericSmall
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/* ------------------------------ Gauge ------------------------------ */

@Composable
fun ScoreGauge(
    score: Int,
    modifier: Modifier = Modifier,
    maxScore: Int = 1100,
    gaugeSize: Dp = 190.dp,
    color: Color = MaterialTheme.colorScheme.primary,
    label: String = "",
    caption: String? = null,
    showScale: Boolean = true,
) {
    val target = (score.toFloat() / maxScore.toFloat()).coerceIn(0f, 1f)
    val reduce = LocalReduceMotion.current
    val animated by animateFloatAsState(
        targetValue = target,
        animationSpec = tween(durationMillis = if (reduce) 0 else 900, easing = FastOutSlowInEasing),
        label = "gauge",
    )

    Box(modifier = modifier.size(gaugeSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = gaugeSize.toPx() * 0.075f
            val inset = stroke / 2 + gaugeSize.toPx() * 0.05f
            val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
            val topLeft = Offset(inset, inset)
            val start = 140f
            val sweep = 260f

            // Ticks
            if (showScale) {
                val center = Offset(this.size.width / 2f, this.size.height / 2f)
                val radius = (this.size.minDimension / 2f) - inset
                for (i in 0..20) {
                    val angle = Math.toRadians((start + sweep * (i / 20f)).toDouble())
                    val outer = Offset(
                        center.x + cos(angle).toFloat() * radius,
                        center.y + sin(angle).toFloat() * radius,
                    )
                    val inner = Offset(
                        center.x + cos(angle).toFloat() * (radius - stroke * 0.34f),
                        center.y + sin(angle).toFloat() * (radius - stroke * 0.34f),
                    )
                    drawLine(
                        color = color.copy(alpha = 0.18f),
                        start = inner,
                        end = outer,
                        strokeWidth = 1.2f,
                    )
                }
            }

            drawArc(
                color = color.copy(alpha = 0.11f),
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke * 2.1f, cap = StrokeCap.Round),
            )
            drawArc(
                color = color.copy(alpha = 0.12f),
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            if (animated > 0.001f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(color.copy(alpha = 0.35f), color, color),
                    ),
                    startAngle = start,
                    sweepAngle = sweep * animated,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = score.toString(),
                style = NumericDisplay.copy(fontSize = (gaugeSize.value * 0.28f).sp),
                color = MaterialTheme.colorScheme.onSurface,
            )
            if (label.isNotEmpty()) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (caption != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = caption,
                    style = MaterialTheme.typography.labelSmall,
                    color = color,
                )
            }
        }
    }
}

/* --------------------------- Line chart ---------------------------- */

@Composable
fun LineChart(
    points: List<Float>,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    minY: Float? = null,
    maxY: Float? = null,
    showArea: Boolean = true,
    gridLines: Int = 3,
    secondaryPoints: List<Float>? = null,
    secondaryColor: Color = MaterialTheme.colorScheme.secondary,
    height: Dp = 160.dp,
) {
    if (points.size < 2) return
    val lo = minY ?: (points.minOrNull() ?: 0f)
    val hi = maxY ?: (points.maxOrNull() ?: 1f)
    val range = (hi - lo).takeIf { it > 0.0001f } ?: 1f
    val gridColor = BenchTheme.colors.outlineSubtle

    Canvas(modifier = modifier.fillMaxWidth().height(height)) {
        val topPad = 10.dp.toPx()
        val bottomPad = 10.dp.toPx()
        val usableH = size.height - topPad - bottomPad

        for (i in 0..gridLines) {
            val y = topPad + usableH * (i / gridLines.toFloat())
            drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
        }

        fun yOf(value: Float): Float {
            val t = ((value - lo) / range).coerceIn(0f, 1f)
            return topPad + usableH * (1f - t)
        }

        fun buildPath(values: List<Float>): Path {
            val path = Path()
            val step = size.width / (values.size - 1).toFloat()
            values.forEachIndexed { index, value ->
                val x = step * index
                val y = yOf(value)
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            return path
        }

        if (showArea) {
            val area = buildPath(points)
            area.lineTo(size.width, size.height)
            area.lineTo(0f, size.height)
            area.close()
            drawPath(
                path = area,
                brush = Brush.verticalGradient(
                    listOf(color.copy(alpha = 0.30f), color.copy(alpha = 0.02f)),
                ),
            )
        }

        if (secondaryPoints != null && secondaryPoints.size >= 2) {
            drawPath(
                path = buildPath(secondaryPoints),
                color = secondaryColor.copy(alpha = 0.85f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
            )
        }

        drawPath(
            path = buildPath(points),
            color = color,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
        )

        // Emphasize the final sample.
        val lastX = size.width
        val lastY = yOf(points.last())
        drawCircle(color.copy(alpha = 0.22f), radius = 7.dp.toPx(), center = Offset(lastX - 2.dp.toPx(), lastY))
        drawCircle(color, radius = 3.dp.toPx(), center = Offset(lastX - 2.dp.toPx(), lastY))
    }
}

@Composable
fun ChartAxis(minLabel: String, maxLabel: String, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(minLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(maxLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/* ----------------------------- Sparkline --------------------------- */

@Composable
fun Sparkline(
    points: List<Float>,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    fill: Boolean = true,
) {
    if (points.size < 2) return
    val lo = points.minOrNull() ?: 0f
    val hi = points.maxOrNull() ?: 1f
    val range = (hi - lo).takeIf { it > 0.0001f } ?: 1f
    Canvas(modifier = modifier) {
        val step = size.width / (points.size - 1).toFloat()
        val path = Path()
        points.forEachIndexed { i, v ->
            val x = step * i
            val y = size.height - ((v - lo) / range) * size.height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        if (fill) {
            val area = Path().apply {
                addPath(path)
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent)))
        }
        drawPath(path, color, style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round))
    }
}

/* ---------------------------- Histogram ---------------------------- */

@Composable
fun FrameTimeHistogram(
    buckets: List<Int>,
    modifier: Modifier = Modifier,
    height: Dp = 140.dp,
) {
    val maxValue = (buckets.maxOrNull() ?: 1).coerceAtLeast(1)
    Canvas(modifier = modifier.fillMaxWidth().height(height)) {
        val gap = 3.dp.toPx()
        val barWidth = (size.width - gap * (buckets.size - 1)) / buckets.size.toFloat()
        buckets.forEachIndexed { index, value ->
            val fraction = value / maxValue.toFloat()
            val barHeight = (size.height - 8.dp.toPx()) * fraction
            val color = when {
                index <= 3 -> BenchTheme.colors.success
                index <= 7 -> MaterialTheme.colorScheme.primary
                index <= 11 -> BenchTheme.colors.warning
                else -> BenchTheme.colors.danger
            }
            drawRoundRect(
                color = color.copy(alpha = 0.85f),
                topLeft = Offset(index * (barWidth + gap), size.height - barHeight),
                size = Size(barWidth, barHeight.coerceAtLeast(2f)),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()),
            )
        }
    }
}

/* ------------------------------ Radar ------------------------------ */

@Composable
fun RadarChart(
    values: List<Float>,
    modifier: Modifier = Modifier,
    maxValue: Float = 1100f,
    color: Color = MaterialTheme.colorScheme.primary,
    comparison: List<Float>? = null,
    comparisonColor: Color = MaterialTheme.colorScheme.secondary,
    size: Dp = 240.dp,
    labels: List<String> = emptyList(),
    showAxisLabels: Boolean = true,
    axisLabelColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    if (values.size < 3) return
    val reduce = LocalReduceMotion.current
    val reveal by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(if (reduce) 0 else 800),
        label = "radar",
    )
    val gridColor = BenchTheme.colors.outlineSubtle
    val measurer = rememberTextMeasurer()
    val labelStyle = MaterialTheme.typography.labelSmall.copy(
        color = axisLabelColor,
        fontSize = 10.sp,
    )
    val labelGap = with(LocalDensity.current) { 4.dp.toPx() }

    Canvas(modifier = modifier.size(size)) {
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val radius = this.size.minDimension * 0.34f
        val count = values.size

        fun pointAt(index: Int, fraction: Float): Offset {
            val angle = -PI / 2 + (2 * PI * index / count)
            return Offset(
                center.x + (cos(angle) * radius * fraction).toFloat(),
                center.y + (sin(angle) * radius * fraction).toFloat(),
            )
        }

        // Axis labels are drawn every time (not part of the reveal animation) so the
        // chart is readable even when motion is reduced.
        if (showAxisLabels && labels.size == count) {
            labels.forEachIndexed { index, label ->
                val anchor = pointAt(index, 1.16f)
                val layout = measurer.measure(AnnotatedString(label), labelStyle)
                val halfW = layout.size.width / 2f
                val halfH = layout.size.height / 2f
                val x = (anchor.x - halfW).coerceIn(0f, this.size.width - layout.size.width)
                val y = (anchor.y - halfH).coerceIn(0f, this.size.height - layout.size.height)
                drawText(layout, topLeft = Offset(x, y - labelGap))
            }
        }

        // Concentric grid
        for (ring in 1..4) {
            val fraction = ring / 4f
            val path = Path()
            for (i in 0 until count) {
                val p = pointAt(i, fraction)
                if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            path.close()
            drawPath(path, gridColor, style = Stroke(width = 1f))
        }
        // Spokes
        for (i in 0 until count) {
            drawLine(gridColor, center, pointAt(i, 1f), strokeWidth = 1f)
        }

        fun polygon(data: List<Float>): Path {
            val path = Path()
            data.forEachIndexed { i, value ->
                val p = pointAt(i, (value / maxValue).coerceIn(0.02f, 1f) * reveal)
                if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            path.close()
            return path
        }

        if (comparison != null && comparison.size == count) {
            drawPath(
                polygon(comparison),
                comparisonColor.copy(alpha = 0.10f),
            )
            drawPath(
                polygon(comparison),
                comparisonColor.copy(alpha = 0.75f),
                style = Stroke(width = 1.5.dp.toPx()),
            )
        }

        drawPath(polygon(values), color.copy(alpha = 0.18f))
        drawPath(polygon(values), color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
        values.forEachIndexed { i, value ->
            val p = pointAt(i, (value / maxValue).coerceIn(0.02f, 1f) * reveal)
            drawCircle(color, radius = 3.dp.toPx(), center = p)
        }
    }
}

@Composable
fun RadarLegend(labels: List<String>, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        labels.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { label ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(5.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                        Spacer(Modifier.width(5.dp))
                        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

/* --------------------------- Category bars ------------------------- */

@Composable
fun CategoryBarRow(
    category: CategoryScore,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    val max = 1100f
    val color = bandColor(category.band)
    Column(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = category.name,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            Text(text = category.score.toString(), style = NumericSmall, color = color)
            Spacer(Modifier.width(8.dp))
            Text(
                text = "${category.sustained} sust.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
        ) {
            Box(
                Modifier
                    .fillMaxWidth((category.sustained / max).coerceIn(0f, 1f))
                    .height(8.dp)
                    .background(color.copy(alpha = 0.35f), CircleShape),
            )
            Box(
                Modifier
                    .fillMaxWidth((category.score / max).coerceIn(0f, 1f))
                    .height(8.dp)
                    .background(color, CircleShape),
            )
        }
    }
}

@Composable
fun ComparisonBar(
    label: String,
    primaryValue: Int,
    secondaryValue: Int,
    primaryLabel: String,
    secondaryLabel: String,
    modifier: Modifier = Modifier,
) {
    val max = maxOf(primaryValue, secondaryValue, 1).toFloat()
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    Column(modifier = modifier.fillMaxWidth()) {
        Row {
            Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            DeltaText(((primaryValue - secondaryValue) * 100f / maxOf(secondaryValue, 1)))
        }
        Spacer(Modifier.height(7.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(primaryLabel, style = MaterialTheme.typography.labelSmall, color = primaryColor, modifier = Modifier.width(38.dp))
            Box(
                Modifier
                    .weight(1f)
                    .height(7.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth((primaryValue / max).coerceIn(0f, 1f))
                        .height(7.dp)
                        .background(primaryColor, CircleShape),
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(primaryValue.toString(), style = NumericSmall)
        }
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(secondaryLabel, style = MaterialTheme.typography.labelSmall, color = secondaryColor, modifier = Modifier.width(38.dp))
            Box(
                Modifier
                    .weight(1f)
                    .height(7.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth((secondaryValue / max).coerceIn(0f, 1f))
                        .height(7.dp)
                        .background(secondaryColor, CircleShape),
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(secondaryValue.toString(), style = NumericSmall)
        }
    }
}

/* ----------------------------- Heatmap ----------------------------- */

@Composable
fun Heatmap(
    rows: List<List<Float>>,
    modifier: Modifier = Modifier,
    animated: Boolean = true,
) {
    val ramp = BenchTheme.colors.thermalRamp
    Canvas(modifier = modifier.fillMaxWidth().height(180.dp)) {
        if (rows.isEmpty()) return@Canvas
        val cols = rows.maxOf { it.size }
        val gap = 3.dp.toPx()
        val cellW = (size.width - gap * (cols - 1)) / cols
        val cellH = (size.height - gap * (rows.size - 1)) / rows.size
        rows.forEachIndexed { r, row ->
            row.forEachIndexed { c, value ->
                val idx = (value.coerceIn(0f, 1f) * (ramp.size - 1)).toInt()
                drawRoundRect(
                    color = ramp[idx],
                    topLeft = Offset(c * (cellW + gap), r * (cellH + gap)),
                    size = Size(cellW, cellH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()),
                )
            }
        }
    }
}

@Composable
fun GradientLegend(lowLabel: String, highLabel: String, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(lowLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(8.dp))
        Canvas(Modifier.weight(1f).height(6.dp)) {
            drawRoundRect(
                brush = Brush.horizontalGradient(BenchTheme.colors.thermalRamp),
                size = size,
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()),
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(highLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/* ---------------------------- Big ring ----------------------------- */

@Composable
fun ProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    color: Color = MaterialTheme.colorScheme.primary,
    label: String = "",
) {
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 10.dp.toPx()
            val inset = stroke / 2 + 6.dp.toPx()
            val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
            drawArc(
                color = color.copy(alpha = 0.12f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "${(progress * 100).toInt()}%",
                style = NumericDisplay.copy(fontSize = 38.sp),
            )
            if (label.isNotEmpty()) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun MetricPill(
    label: String,
    value: String,
    unit: String,
    color: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(color.copy(alpha = 0.08f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, style = NumericMedium, color = MaterialTheme.colorScheme.onSurface)
            if (unit.isNotEmpty()) {
                Spacer(Modifier.width(2.dp))
                Text(unit, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}
