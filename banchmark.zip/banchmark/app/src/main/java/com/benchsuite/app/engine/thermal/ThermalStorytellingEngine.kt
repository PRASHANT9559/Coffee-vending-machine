package com.benchsuite.app.engine.thermal

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import java.io.File
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Thermal Dynamics & Ergonomic Storytelling Engine.
 *
 * Implements:
 * - Feature 10.1: Surface Temperature Heatmap & Skin vs. Junction Thermal Gradient.
 * - Feature 10.4: Skin Temperature Comfort Index (Ergonomic holdability & IEC 62368-1 touch limits).
 * - Feature 10.5: Cool-Down Recovery Time Calculator (Newtonian cooling model & thermal time constant τ).
 *
 * Translates raw kernel thermal zone measurements into intuitive human-centered insights:
 * how heat transfers from silicon to chassis, whether the phone is comfortable to hold,
 * and how quickly cooling assemblies dissipate trapped heat after intensive workloads.
 */
object ThermalStorytellingEngine {

    enum class ComfortTier(val label: String, val maxSkinTempC: Double, val scoreBand: ScoreBand) {
        COOL_COMFORTABLE("Cool & Comfortable (<38°C)", 38.0, ScoreBand.EXCELLENT),
        MODERATELY_WARM("Acceptably Warm (38°C - 42°C)", 42.0, ScoreBand.GOOD),
        UNCOMFORTABLY_HOT("Uncomfortably Hot (42°C - 45°C)", 45.0, ScoreBand.FAIR),
        THERMAL_PAIN_HAZARD("Hand Discomfort / Pain Threshold (>45°C)", 100.0, ScoreBand.POOR);
    }

    data class SurfaceHeatZone(
        val zoneId: String,
        val displayName: String,
        val relativeX: Float, // 0.0 to 1.0 (left to right)
        val relativeY: Float, // 0.0 to 1.0 (top to bottom)
        val temperatureCelsius: Double,
        val holdsErgonomicRisk: Boolean,
    )

    data class ThermalGradientProfile(
        val junctionTemperatureC: Double, // Silicon die (CPU/GPU/SoC)
        val skinTemperatureC: Double, // Exterior chassis contact surface
        val batteryTemperatureC: Double,
        val ambientBaselineC: Double,
        val deltaJunctionToSkinC: Double, // Tj - Tskin
        val thermalResistanceCelsiusPerWatt: Double, // R_th = ΔT / P
        val vaporChamberSpreadingEfficiencyPct: Double,
        val dissipationVerdict: String,
    )

    data class ErgonomicComfortIndex(
        val tier: ComfortTier,
        val comfortScore: Int, // 0 - 100
        val peakSurfaceTempC: Double,
        val gripZoneTempC: Double, // Temperature where hands touch in landscape/portrait
        val safeContinuousHoldingMinutes: Int,
        val iec62368TouchSafetyCompliant: Boolean,
        val ergonomicSummary: String,
    )

    data class CoolDownDynamics(
        val peakWorkloadTempC: Double,
        val targetRestingTempC: Double,
        val thermalTimeConstantTauSec: Double, // τ in seconds
        val halfLifeRecoveryTimeSec: Int, // t_1/2
        val timeToComfortThresholdSec: Int, // Time to reach 40°C
        val timeToFullAmbientRecoverySec: Int, // Time to reach ambient + 2°C
        val recoverySpeedRating: String, // Rapid, Normal, Sluggish
    )

    data class ThermalStorytellingReport(
        val gradient: ThermalGradientProfile,
        val comfort: ErgonomicComfortIndex,
        val coolDown: CoolDownDynamics,
        val surfaceHeatmap: List<SurfaceHeatZone>,
        val overallThermalScore: Int, // 0 - 100
        val band: ScoreBand,
        val executiveStoryVerdict: String,
        val actionableCoolingTips: List<String>,
    )

    /* ------------------------------------------------------------------ */
    /* 1. Feature 10.1: Skin vs. Junction Thermal Gradient                */
    /* ------------------------------------------------------------------ */

    /**
     * Measures the thermal gradient and thermal resistance from silicon core to chassis surface.
     */
    fun evaluateThermalGradient(
        activePowerWatts: Double = 6.5,
        ambientC: Double = 25.0,
    ): ThermalGradientProfile {
        val thermalMap = readAllThermalZones()

        val junctionTemp = thermalMap["cpu"]
            ?: (thermalMap["soc"] ?: (thermalMap["tsens"] ?: 68.0))

        val skinTemp = thermalMap["skin"]
            ?: (thermalMap["chassis"] ?: (thermalMap["battery"] ?: 39.5))

        val batteryTemp = thermalMap["battery"] ?: 38.0

        val deltaJunctionSkin = max(1.0, junctionTemp - skinTemp)

        // Thermal Resistance: R_th = ΔT / P_dissipated (°C / W)
        // High-end vapor chambers achieve R_th < 3.5 °C/W
        val rTh = deltaJunctionSkin / max(1.0, activePowerWatts)

        // Spreading efficiency: Ratio of surface heat spreading vs localized hotspot concentration
        // If skin temp rises smoothly across zones, vapor chamber is spreading efficiently
        val spreadingEfficiency = when {
            rTh <= 3.0 -> 94.0
            rTh <= 4.5 -> 84.0
            rTh <= 6.5 -> 72.0
            rTh <= 9.0 -> 58.0
            else -> 42.0
        }

        val verdict = when {
            rTh <= 3.5 -> "Flagship Vapor Chamber: Exceptional heat transfer from silicon to chassis with minimal localized throttling."
            rTh <= 5.5 -> "Balanced Thermal Spreader: Adequate dissipation; mild junction heat build-up under sustained sustained GPU/CPU load."
            else -> "High Thermal Impedance: Heat trapped at silicon junction. High ΔT indicates small cooling assembly or thick insulating case."
        }

        return ThermalGradientProfile(
            junctionTemperatureC = (junctionTemp * 10.0).roundToInt() / 10.0,
            skinTemperatureC = (skinTemp * 10.0).roundToInt() / 10.0,
            batteryTemperatureC = (batteryTemp * 10.0).roundToInt() / 10.0,
            ambientBaselineC = ambientC,
            deltaJunctionToSkinC = (deltaJunctionSkin * 10.0).roundToInt() / 10.0,
            thermalResistanceCelsiusPerWatt = (rTh * 100.0).roundToInt() / 100.0,
            vaporChamberSpreadingEfficiencyPct = spreadingEfficiency,
            dissipationVerdict = verdict,
        )
    }

    /**
     * Generates a 4-point surface temperature distribution for UI heatmap visualization.
     */
    fun generateSurfaceHeatmap(gradient: ThermalGradientProfile): List<SurfaceHeatZone> {
        val skin = gradient.skinTemperatureC
        val tj = gradient.junctionTemperatureC

        // 1. Top Hotspot (SoC / Camera bump area)
        val hotspotTemp = min(tj - 8.0, skin + 3.5)
        // 2. Center Back (Vapor chamber dissipation zone)
        val centerTemp = skin + 1.0
        // 3. Bottom Back (Battery & Charging port)
        val bottomTemp = max(gradient.batteryTemperatureC, skin - 2.0)
        // 4. Side Frame Grip (Where fingers rest in landscape gaming)
        val gripTemp = skin - 1.2

        return listOf(
            SurfaceHeatZone(
                zoneId = "ZONE_SOC_TOP",
                displayName = "Upper SoC & Camera Chamber",
                relativeX = 0.5f,
                relativeY = 0.22f,
                temperatureCelsius = (hotspotTemp * 10.0).roundToInt() / 10.0,
                holdsErgonomicRisk = hotspotTemp > 44.0,
            ),
            SurfaceHeatZone(
                zoneId = "ZONE_VAPOR_CHAMBER_MID",
                displayName = "Mid Chassis Dissipation Zone",
                relativeX = 0.5f,
                relativeY = 0.50f,
                temperatureCelsius = (centerTemp * 10.0).roundToInt() / 10.0,
                holdsErgonomicRisk = centerTemp > 43.0,
            ),
            SurfaceHeatZone(
                zoneId = "ZONE_BATTERY_LOWER",
                displayName = "Lower Battery & Sub-Board",
                relativeX = 0.5f,
                relativeY = 0.78f,
                temperatureCelsius = (bottomTemp * 10.0).roundToInt() / 10.0,
                holdsErgonomicRisk = bottomTemp > 42.0,
            ),
            SurfaceHeatZone(
                zoneId = "ZONE_FRAME_GRIP",
                displayName = "Lateral Frame Palm Grip",
                relativeX = 0.08f,
                relativeY = 0.65f,
                temperatureCelsius = (gripTemp * 10.0).roundToInt() / 10.0,
                holdsErgonomicRisk = gripTemp > 41.5,
            ),
        )
    }

    /* ------------------------------------------------------------------ */
    /* 2. Feature 10.4: Skin Temperature Comfort Index                    */
    /* ------------------------------------------------------------------ */

    /**
     * Evaluates hold comfort based on international touch temperature standards (IEC 62368-1).
     */
    fun computeSkinComfortIndex(
        gradient: ThermalGradientProfile,
        heatmap: List<SurfaceHeatZone>,
    ): ErgonomicComfortIndex {
        val peakTemp = heatmap.maxOf { it.temperatureCelsius }
        val gripTemp = heatmap.firstOrNull { it.zoneId == "ZONE_FRAME_GRIP" }?.temperatureCelsius ?: gradient.skinTemperatureC

        val tier = when {
            peakTemp <= 38.0 -> ComfortTier.COOL_COMFORTABLE
            peakTemp <= 42.0 -> ComfortTier.MODERATELY_WARM
            peakTemp <= 45.0 -> ComfortTier.UNCOMFORTABLY_HOT
            else -> ComfortTier.THERMAL_PAIN_HAZARD
        }

        // Score 0-100: 35°C is 100, 48°C is 10
        val score = when {
            peakTemp <= 36.0 -> 98
            peakTemp <= 39.0 -> 88
            peakTemp <= 42.0 -> 76
            peakTemp <= 45.0 -> 55
            peakTemp <= 48.0 -> 32
            else -> 12
        }

        // Continuous holding tolerance minutes
        val safeMinutes = when (tier) {
            ComfortTier.COOL_COMFORTABLE -> 180
            ComfortTier.MODERATELY_WARM -> 90
            ComfortTier.UNCOMFORTABLY_HOT -> 25
            ComfortTier.THERMAL_PAIN_HAZARD -> 5
        }

        val isIecCompliant = peakTemp <= 48.0 // IEC 62368-1 allows up to 48°C for bare metal touch contact

        val summary = when (tier) {
            ComfortTier.COOL_COMFORTABLE -> "Ergonomic Excellence: Device exterior remains comfortable for marathon gaming or streaming."
            ComfortTier.MODERATELY_WARM -> "Normal Gaming Warmth: Noticeable warmth around camera island, but lateral grip zones stay manageable."
            ComfortTier.UNCOMFORTABLY_HOT -> "Elevated Surface Heat: Chassis reaches ${peakTemp}°C; hand perspiration and grip fatigue likely after 25 minutes."
            ComfortTier.THERMAL_PAIN_HAZARD -> "Ergonomic Hazard: Frame temperature exceeds 45°C. Risk of thermal discomfort; external cooling accessory recommended."
        }

        return ErgonomicComfortIndex(
            tier = tier,
            comfortScore = score,
            peakSurfaceTempC = peakTemp,
            gripZoneTempC = gripTemp,
            safeContinuousHoldingMinutes = safeMinutes,
            iec62368TouchSafetyCompliant = isIecCompliant,
            ergonomicSummary = summary,
        )
    }

    /* ------------------------------------------------------------------ */
    /* 3. Feature 10.5: Cool-Down Recovery Time Calculator                */
    /* ------------------------------------------------------------------ */

    /**
     * Models post-stress exponential cool-down dynamics via Newton's law of cooling:
     * T(t) = T_ambient + (T_peak - T_ambient) * e^(-t / τ)
     */
    fun calculateCoolDownRecovery(
        peakTempC: Double,
        ambientC: Double = 25.0,
        thermalResistance: Double = 3.8,
    ): CoolDownDynamics {
        val peak = max(peakTempC, ambientC + 5.0)
        val initialDelta = peak - ambientC

        // Thermal time constant τ (seconds)
        // High-end vapor chambers cool down with τ between 120s and 220s
        // Thicker devices or insulated phone cases increase τ to 300s - 450s
        val tauSec = (thermalResistance * 45.0).coerceIn(110.0, 420.0)

        // Half-life: t_1/2 = τ * ln(2)
        val halfLifeSec = (tauSec * ln(2.0)).roundToInt()

        // Time to reach comfort threshold (40°C)
        // 40 = ambient + initialDelta * e^(-t / τ)
        val comfortTarget = 40.0
        val timeToComfortSec = if (peak > comfortTarget && initialDelta > 0) {
            val ratio = (comfortTarget - ambientC) / initialDelta
            if (ratio in 0.001..0.999) {
                (-tauSec * ln(ratio)).roundToInt()
            } else 0
        } else {
            0
        }

        // Time to ambient + 2°C baseline (e.g. 27°C)
        val baselineTarget = ambientC + 2.0
        val ratioBaseline = (baselineTarget - ambientC) / initialDelta
        val timeToAmbientSec = if (ratioBaseline in 0.001..0.999) {
            (-tauSec * ln(ratioBaseline)).roundToInt()
        } else {
            (tauSec * 3.5).roundToInt()
        }

        val rating = when {
            halfLifeSec <= 110 -> "Rapid Dissipation (High Conductance Vapor Chamber)"
            halfLifeSec <= 200 -> "Standard Recovery (Normal Thermal Dissipation Curve)"
            else -> "Sluggish Cool-Down (Insulated Chassis / Restricted Airflow)"
        }

        return CoolDownDynamics(
            peakWorkloadTempC = (peak * 10.0).roundToInt() / 10.0,
            targetRestingTempC = (ambientC * 10.0).roundToInt() / 10.0,
            thermalTimeConstantTauSec = (tauSec * 10.0).roundToInt() / 10.0,
            halfLifeRecoveryTimeSec = halfLifeSec,
            timeToComfortThresholdSec = timeToComfortSec,
            timeToFullAmbientRecoverySec = timeToAmbientSec,
            recoverySpeedRating = rating,
        )
    }

    /* ------------------------------------------------------------------ */
    /* 4. Complete Synthesis                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Executes the integrated Thermal Storytelling evaluation.
     */
    fun runThermalStoryEvaluation(context: Context): ThermalStorytellingReport {
        val gradient = evaluateThermalGradient()
        val heatmap = generateSurfaceHeatmap(gradient)
        val comfort = computeSkinComfortIndex(gradient, heatmap)
        val coolDown = calculateCoolDownRecovery(
            peakTempC = gradient.skinTemperatureC,
            thermalResistance = gradient.thermalResistanceCelsiusPerWatt,
        )

        val compositeScore = (
            (comfort.comfortScore * 0.45) +
            (gradient.vaporChamberSpreadingEfficiencyPct * 0.35) +
            (min(100.0, (240.0 / coolDown.halfLifeRecoveryTimeSec.toDouble()) * 100.0) * 0.20)
        ).roundToInt().coerceIn(0, 100)

        val verdict = when {
            compositeScore >= 85 -> "Outstanding Thermal Engineering: Generous heat dissipation with safe ergonomic touch levels."
            compositeScore >= 70 -> "Good Everyday Thermal Performance: Surface temperatures stay within acceptable handheld limits."
            compositeScore >= 55 -> "Noticeable Thermal Build-Up: Vapor chamber reaches saturation under sustained load; slow recovery."
            else -> "Thermal Dissipation Bottleneck: High skin temperature and long cool-down periods restrict sustained performance."
        }

        val tips = mutableListOf<String>()
        if (comfort.tier == ComfortTier.UNCOMFORTABLY_HOT || comfort.tier == ComfortTier.THERMAL_PAIN_HAZARD) {
            tips.add("Remove thick protective cases during high-performance gaming sessions to reduce thermal resistance by ~25%.")
        }
        if (coolDown.timeToComfortThresholdSec > 180) {
            tips.add("Rest device on a flat conductive surface (e.g. aluminum desk) for 2 minutes to accelerate post-test cool-down.")
        }
        if (gradient.deltaJunctionToSkinC > 28.0) {
            tips.add("High silicon-to-skin delta (${gradient.deltaJunctionToSkinC}°C) indicates thermal paste degradation or small internal heat pipe.")
        }

        // Wire native Rust thermal model if available
        var resolvedVerdict = verdict
        if (com.benchsuite.app.nativecore.NativeBridge.isAvailable) {
            val samplePoints = listOf(
                com.benchsuite.app.nativecore.NativeThermalPoint(0.0, gradient.ambientBaselineC, 2.5, 2.8),
                com.benchsuite.app.nativecore.NativeThermalPoint(30.0, gradient.skinTemperatureC, 6.0, 2.4),
                com.benchsuite.app.nativecore.NativeThermalPoint(60.0, gradient.junctionTemperatureC, 4.5, 2.0),
            )
            val nativeThermal = com.benchsuite.app.nativecore.NativeBridge.analyzeThermal(samplePoints, 42.0)
            if (nativeThermal != null) {
                if (nativeThermal.verdict.isNotBlank()) {
                    resolvedVerdict = "$verdict (${nativeThermal.verdict})"
                }
                nativeThermal.notes.forEach { note ->
                    if (note !in tips) tips.add(note)
                }
            }
        }

        return ThermalStorytellingReport(
            gradient = gradient,
            comfort = comfort,
            coolDown = coolDown,
            surfaceHeatmap = heatmap,
            overallThermalScore = compositeScore,
            band = bandFor(compositeScore * 10),
            executiveStoryVerdict = resolvedVerdict,
            actionableCoolingTips = tips,
        )
    }

    /* ------------------------------------------------------------------ */
    /* Sysfs Thermal Zone Discovery                                       */
    /* ------------------------------------------------------------------ */

    private fun readAllThermalZones(): Map<String, Double> {
        val map = mutableMapOf<String, Double>()
        val dir = File("/sys/class/thermal")
        if (dir.exists()) {
            val zones = dir.listFiles { f -> f.isDirectory && f.name.startsWith("thermal_zone") }
            zones?.forEach { zone ->
                val typeFile = File(zone, "type")
                val tempFile = File(zone, "temp")
                if (typeFile.exists() && tempFile.exists() && tempFile.canRead()) {
                    try {
                        val type = typeFile.readText().trim().lowercase()
                        val rawTemp = tempFile.readText().trim().toDoubleOrNull()
                        if (rawTemp != null) {
                            val tempC = if (rawTemp > 1000.0) rawTemp / 1000.0 else rawTemp
                            if (tempC in 0.0..120.0) {
                                when {
                                    type.contains("skin") || type.contains("chassis") -> map["skin"] = tempC
                                    type.contains("cpu") || type.contains("tsens") -> map["cpu"] = tempC
                                    type.contains("soc") -> map["soc"] = tempC
                                    type.contains("battery") -> map["battery"] = tempC
                                    else -> map[type] = tempC
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        }
        return map
    }
}
