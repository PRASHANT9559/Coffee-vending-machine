package com.benchsuite.app.features.core

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.CategoryTile
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.InsightCard
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.RecommendationCard
import com.benchsuite.app.ui.components.RunScoreCard
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.bandColor
import com.benchsuite.app.ui.components.HistoryRunRow
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.RadarChart

@Composable
fun DashboardScreen(onNavigate: (String) -> Unit) {
    val recentRuns = SessionState.allHistoryRuns.take(3)
    val device = SessionState.currentDevice
    val currentDateStr = remember {
        java.text.SimpleDateFormat("EEEE · d MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
    }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "BenchSuite",
            subtitle = device.model,
            brand = true,
            actions = {
                IconAction(Icons.Outlined.Devices, "Device info", onClick = { onNavigate(Routes.DEVICE_INFO) })
                IconAction(Icons.Outlined.MoreVert, "More", onClick = { onNavigate(Routes.MORE) })
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = currentDateStr,
                    title = "Your device, explained.",
                    body = if (SessionState.latestNativeRun != null)
                        "Last run completed on ${SessionState.latestNativeRun?.date}. Conditions were verified and reproducible."
                    else
                        "Run hardware benchmarks on your device to analyze performance, thermals, and stability.",
                )
            }

            item {
                val lastRun = SessionState.latestNativeRun
                if (lastRun != null) {
                    RunScoreCard(
                        run = lastRun,
                        onClick = { onNavigate(Routes.resultSummary(lastRun.id)) },
                    )
                } else {
                    SurfaceCard(onClick = { onNavigate(Routes.preTest("full")) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Speed, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Ready to Benchmark", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Measure CPU, GPU, memory, and thermals on ${device.model}.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Button(onClick = { onNavigate(Routes.preTest("full")) }) {
                                Text("Start")
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    QuickAction("Quick test", "60 sec", Icons.Outlined.Bolt, Modifier.weight(1f)) {
                        onNavigate(Routes.preTest("quick"))
                    }
                    QuickAction("Full suite", "14 min", Icons.Outlined.Speed, Modifier.weight(1f)) {
                        onNavigate(Routes.preTest("full"))
                    }
                    QuickAction("Custom", "Build", Icons.Outlined.Tune, Modifier.weight(1f)) {
                        onNavigate(Routes.CUSTOM_BUILDER)
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Device health",
                    actionLabel = "Details",
                    onAction = { onNavigate(Routes.category("health")) },
                )
            }
            item {
                HealthOverviewCard(onClick = { onNavigate(Routes.category("health")) })
            }

            item {
                // Real category scores from the latest recorded run — never a static placeholder.
                val shapeCats = SessionState.latestRecordedRunOrNull
                    ?.categories?.filter { it.id != "health" }?.take(6)
                    ?: emptyList()
                if (shapeCats.size >= 3) {
                    ChartCard(
                        title = "Performance shape",
                        caption = "Latest real scores against their recorded peaks",
                    ) {
                        RadarChart(
                            values = shapeCats.map { it.score.toFloat() },
                            comparison = shapeCats.map { it.peak.toFloat() },
                            maxValue = 1100f,
                            labels = shapeCats.map { it.name },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(Spacing.sm))
                        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.md)) {
                            LegendSwatch(MaterialTheme.colorScheme.primary, "Current")
                            LegendSwatch(MaterialTheme.colorScheme.secondary, "Peak")
                        }
                    }
                } else {
                    SurfaceCard {
                        Text("Performance shape", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Run a benchmark to see your real category fingerprint here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                val points = SessionState.allHistoryRuns.map { it.overall.toFloat() }
                if (points.isEmpty()) {
                    SurfaceCard {
                        Text("Score trend", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "No benchmark history on this device yet. Your real score trend appears after the first run.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    val average = points.average().toFloat()
                    ChartCard(
                        title = "Score trend",
                        caption = "Last ${points.size} recorded run${if (points.size == 1) "" else "s"}",
                    ) {
                        LineChart(
                            points = points,
                            secondaryPoints = List(points.size) { average },
                            height = 168.dp,
                        )
                        Spacer(Modifier.height(Spacing.sm))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            StatText("Best", (points.maxOrNull() ?: 0f).toInt().toString())
                            StatText("Average", average.toInt().toString())
                            StatText("Latest", (points.lastOrNull() ?: 0f).toInt().toString())
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Category scores",
                    actionLabel = "Compare",
                    onAction = { onNavigate(Routes.COMPARE) },
                )
            }
            item {
                // Real per-category scores from the latest run; "—" when a category is unmeasured.
                val realScores = SessionState.latestRecordedRunOrNull
                    ?.categories?.associateBy { it.id } ?: emptyMap()
                Column(verticalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    TestCatalog.categorySpecs.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                            row.forEach { spec ->
                                CategoryTile(
                                    spec = spec,
                                    realScore = realScores[spec.id],
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate(Routes.category(spec.id)) },
                                )
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "What stands out",
                    actionLabel = "All insights",
                    onAction = { onNavigate(Routes.INSIGHTS) },
                )
            }
            item {
                val runForInsights = SessionState.latestRecordedRunOrNull
                if (runForInsights != null) {
                    val dynamicInsights = SessionState.getInsights(runForInsights)
                    if (dynamicInsights.isEmpty()) {
                        SurfaceCard {
                            Text(
                                "No insights generated yet for the latest run.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                            dynamicInsights.take(2).forEach { insight ->
                                InsightCard(
                                    insight = insight,
                                    onClick = { onNavigate(Routes.INSIGHTS) },
                                )
                            }
                        }
                    }
                } else {
                    SurfaceCard {
                        Text(
                            "Insights appear here after your first real benchmark run.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                val hasRun = SessionState.latestRecordedRunOrNull != null
                if (hasRun) {
                    val fit = SessionState.latestRecordedRunOrNull
                        ?.let { SessionState.getUseCaseFits(it) }?.firstOrNull()
                    if (fit != null) {
                        RecommendationCard(
                            rec = Recommendation(
                                id = "fit.${fit.name}",
                                area = RecommendationArea.UPGRADE,
                                title = fit.name,
                                body = fit.note,
                                impact = "Score ${fit.score}",
                                effort = "Low",
                                action = "See all use cases",
                            ),
                            onAction = { onNavigate(Routes.RECOMMENDATIONS) },
                        )
                    }
                } else {
                    SurfaceCard {
                        Text(
                            "Personalized recommendations appear after your first real benchmark run.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Recent runs",
                    actionLabel = "History",
                    onAction = { onNavigate(Routes.HISTORY) },
                )
            }
            if (recentRuns.isEmpty()) {
                item {
                    SurfaceCard {
                        Text(
                            "No past runs recorded yet. Start a benchmark above to view verified results.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                items(recentRuns.size) { index ->
                    val run = recentRuns[index]
                    HistoryRunRow(run = run, onClick = { onNavigate(Routes.resultDetail(run.id)) })
                }
            }

            item {
                Text(
                    text = "All data local · methodology 2.4.1 · confidence 92%",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(top = Spacing.xs),
                )
            }
        }
    }
}

@Composable
private fun QuickAction(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    SurfaceCard(
        modifier = modifier,
        onClick = onClick,
        contentPadding = PaddingValues(12.dp),
    ) {
        Box(
            Modifier
                .size(30.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HealthOverviewCard(onClick: () -> Unit) {
    // Real device state only: battery level, temperature, charging and thermal status.
    // Fabricated health percentages/cycle counts are never shown.
    val context = androidx.compose.ui.platform.LocalContext.current
    val telemetry = remember {
        runCatching { com.benchsuite.app.nativecore.DeviceTelemetryReader.read(context) }.getOrNull()
    }
    val thermalLabel = telemetry?.thermalStatus ?: "Unknown"
    val thermalColor = when (telemetry?.thermalStatus) {
        "Nominal" -> BenchTheme.colors.success
        "Light", "Moderate" -> BenchTheme.colors.warning
        "Severe", "Critical", "Emergency", "Shutdown" -> BenchTheme.colors.danger
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    SurfaceCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Battery & thermal", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(2.dp))
                Text(
                    if (telemetry != null) "Live device readings" else "Device readings unavailable",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            StatusChip(thermalLabel, tint = thermalColor)
        }
        Spacer(Modifier.height(Spacing.sm))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScoreGauge(
                score = telemetry?.batteryPct ?: 0,
                maxScore = 100,
                gaugeSize = 116.dp,
                color = BenchTheme.colors.success,
                label = "% battery",
                showScale = false,
            )
            Spacer(Modifier.width(Spacing.md))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                HealthLine("Battery level", "${telemetry?.batteryPct ?: 0}%", MaterialTheme.colorScheme.onSurface)
                HealthLine(
                    "Temperature",
                    if (telemetry != null) String.format(java.util.Locale.US, "%.1f °C", telemetry.temperatureC) else "—",
                    thermalColor,
                )
                HealthLine("Charging", if (telemetry?.charging == true) "Yes" else "No", MaterialTheme.colorScheme.onSurface)
                HealthLine("Thermal status", thermalLabel, thermalColor)
            }
        }
    }
}

@Composable
private fun HealthLine(label: String, value: String, valueColor: Color) {    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Text(value, style = MaterialTheme.typography.labelMedium, color = valueColor)
    }
}

@Composable
private fun LegendSwatch(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .background(color, RoundedCornerShape(2.dp)),
        )
        Spacer(Modifier.width(5.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun StatText(label: String, value: String) {
    Column {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(value, style = MaterialTheme.typography.titleSmall)
    }
}
