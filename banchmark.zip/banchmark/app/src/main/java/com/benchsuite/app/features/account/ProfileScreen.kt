package com.benchsuite.app.features.account

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CompareArrows
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Leaderboard
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BadgeTile
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.ProfileStat
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.ShortcutRow
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun ProfileScreen(onNavigate: (String) -> Unit) {
    val runCount = SessionState.completedRuns.size
    val bestScore = SessionState.completedRuns.maxOfOrNull { it.overall }?.toString() ?: "—"

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Profile",
            subtitle = "Local profile · no account",
            actions = {
                IconAction(Icons.Outlined.Settings, "Settings") { onNavigate(Routes.SETTINGS) }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Your data, your device",
                    title = "A profile without an account.",
                    body = "Everything here lives on this phone. No email, no sign-in, no cloud dependency.",
                )
            }

            item {
                SurfaceCard(contentPadding = PaddingValues(0.dp)) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f),
                                    ),
                                ),
                            )
                            .padding(Spacing.md),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(64.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f), CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    "AM",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Spacer(Modifier.width(Spacing.md))
                            Column(Modifier.weight(1f)) {
                                Text("Local User", style = MaterialTheme.typography.titleLarge)
                                Text(
                                    "Local profile · since September 2026",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Spacer(Modifier.height(5.dp))
                                StatusChip("Not ranked yet", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Row(
                        Modifier.padding(horizontal = Spacing.md, vertical = Spacing.sm),
                        horizontalArrangement = Arrangement.spacedBy(Spacing.xs),
                    ) {
                        ProfileStat("$runCount", "Runs", Modifier.weight(1f))
                        ProfileStat("$bestScore", "Best score", Modifier.weight(1f), MaterialTheme.colorScheme.primary)
                        ProfileStat("0", "Badges", Modifier.weight(1f), BenchTheme.colors.success)
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.EmojiEvents, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Achievements", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        Text("Badges appear after your first real benchmark run.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    SurfaceCard {
                        Text(
                            "No badges earned yet. Complete a benchmark run to unlock your first achievement.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(Spacing.sm),
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Community",
                    actionLabel = "Rankings",
                    onAction = { onNavigate(Routes.LEADERBOARD) },
                )
            }
            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Verified global rank", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "—",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text("#3", style = NumericDisplay.copy(fontSize = 30.sp), color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Leaderboard upload is off by default. Turn it on in Privacy and data to submit signed scores.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item { SectionHeader(title = "Devices") }
            item {
                SurfaceCard {
                    val profile = com.benchsuite.app.ui.state.SessionState.currentDevice
                    DeviceRow(
                        model = profile.model,
                        detail = "${profile.soc} · current device",
                        current = true,
                    )
                    // Reference-device comparison only appears once a real run exists.
                    val lastRun = com.benchsuite.app.ui.state.SessionState.latestRecordedRunOrNull
                    if (lastRun != null) {
                        Spacer(Modifier.height(Spacing.sm))
                        DeviceRow(
                            model = lastRun.deviceModel,
                            detail = "${lastRun.soc} · last benchmarked run",
                            current = false,
                        )
                    }
                }
            }

            item { SectionHeader(title = "Shortcuts") }
            item {
                SurfaceCard(contentPadding = PaddingValues(horizontal = Spacing.md, vertical = 4.dp)) {
                    ShortcutRow("Comparison", "Side-by-side runs and devices", Icons.Outlined.CompareArrows) { onNavigate(Routes.COMPARE) }
                    ShortcutRow("Leaderboard", "Verified global and regional ranks", Icons.Outlined.Leaderboard) { onNavigate(Routes.LEADERBOARD) }
                    ShortcutRow("Privacy and data", "Consent, export and deletion", Icons.Outlined.Lock) { onNavigate(Routes.PRIVACY) }
                    ShortcutRow("Settings", "Theme, data style and run behavior", Icons.Outlined.Settings) { onNavigate(Routes.SETTINGS) }
                    ShortcutRow("Help and support", "FAQ, diagnostics and feedback", Icons.Outlined.SupportAgent) { onNavigate(Routes.HELP) }
                    ShortcutRow("About BenchSuite", "Version, methodology and licenses", Icons.Outlined.Info) { onNavigate(Routes.ABOUT) }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Devices, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Profiles are per-device. Moving to a new phone starts a clean history unless you export and restore it.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                Text(
                    "Signed runs: ${SessionState.reportSharedIds.size} shared · 0 uploaded without consent",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun ProfileStat(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = NumericSmall.copy(fontSize = 20.sp), color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DeviceRow(model: String, detail: String, current: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(34.dp).background(
                if (current) MaterialTheme.colorScheme.primary.copy(alpha = 0.13f) else MaterialTheme.colorScheme.surfaceVariant,
                CircleShape,
            ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Outlined.Devices,
                contentDescription = null,
                tint = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(17.dp),
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(model, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
        if (current) {
            StatusChip("This phone", tint = BenchTheme.colors.success)
        }
    }
}
