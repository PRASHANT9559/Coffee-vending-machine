package com.benchsuite.app.features.data

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.ReportItem
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.components.bandColor
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun ReportPreviewScreen(reportId: String, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val report: ReportItem = SessionState.completedReportItems.firstOrNull { it.id == reportId } ?: return
        ?: SessionState.completedReportItems.firstOrNull()
        ?: ReportItem(
            id = reportId.ifBlank { "rep_latest" },
            title = "Benchmark Report",
            subtitle = SessionState.currentDevice.model,
            type = ReportType.FULL,
            date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()),
            overall = SessionState.latestNativeRun?.overall ?: 0,
            subsystems = SessionState.latestNativeRun?.categories?.map { "${it.name}: ${it.score}" } ?: emptyList(),
            pages = 4,
            sizeKb = 128,
            hash = "abs-attested",
        )
    var exported by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Report preview",
            subtitle = report.type.label,
            onBack = onBack,
            actions = {
                IconAction(Icons.Outlined.Share, "Share report") {
                    SessionState.markReportShared(report.id)
                    onNavigate(Routes.SHARE)
                }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Report ${report.id}",
                    title = report.title,
                    body = report.subtitle,
                )
            }

            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f),
                                ),
                            ),
                            RoundedCornerShape(18.dp),
                        )
                        .padding(1.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)),
                ) {
                    Column(Modifier.padding(Spacing.md)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(32.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.13f), RoundedCornerShape(9.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Outlined.Description, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
                            }
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text("BenchSuite", style = MaterialTheme.typography.titleSmall)
                                Text("Signed benchmark report", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (report.shared) {
                                StatusChip("Shared", tint = MaterialTheme.colorScheme.secondary)
                            }
                        }
                        Spacer(Modifier.height(Spacing.md))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ScoreGauge(
                                score = report.score,
                                maxScore = if (report.type.label.contains("Health")) 100 else 1100,
                                gaugeSize = 104.dp,
                                color = bandColor(com.benchsuite.app.data.model.bandFor(report.score)),
                                label = "overall",
                                showScale = false,
                            )
                            Spacer(Modifier.width(Spacing.md))
                            Column(Modifier.weight(1f)) {
                                Text(SessionState.currentDevice.model, style = MaterialTheme.typography.titleMedium)
                                Text(SessionState.currentDevice.soc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(4.dp))
                                Text(report.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Spacer(Modifier.height(Spacing.md))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Tag("${report.pages} pages")
                            Tag(report.sizeLabel)
                            Tag(report.type.label)
                        }
                    }
                }
            }

            item { SectionHeader(title = "Contents") }
            item {
                SurfaceCard {
                    // Real sections present in every exported report.
                    listOf("Overall score", "Category breakdown", "Recorded conditions", "Signature & verification")
                        .forEachIndexed { index, section ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = (index + 1).toString().padStart(2, '0'),
                                    style = NumericSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.width(26.dp),
                                )
                                Text(section, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                Icon(
                                    Icons.Outlined.CheckCircle,
                                    contentDescription = null,
                                    tint = BenchTheme.colors.success,
                                    modifier = Modifier.size(15.dp),
                                )
                            }
                        }
                }
            }

            item { SectionHeader(title = "Conditions in this report") }
            item {
                val conditions = SessionState.latestRecordedRunOrNull?.conditions
                SurfaceCard {
                    if (conditions != null) {
                        InfoRow("Battery at start", "${conditions.batteryPct}% · ${if (conditions.charging) "charging" else "unplugged"}")
                        InfoRow("Battery temperature", String.format(java.util.Locale.US, "%.1f °C", conditions.batteryTempC))
                        InfoRow("Ambient", String.format(java.util.Locale.US, "%.1f °C", conditions.ambientC))
                        InfoRow("Background load", "${conditions.backgroundLoadPct}%")
                        InfoRow("Methodology", "2.4.1 · median + 5% trim")
                        InfoRow("Reference baseline", "1000")
                    } else {
                        Text(
                            "Conditions not available for this report.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item { SectionHeader(title = "Export") }
            item {
                SurfaceCard {
                    Text(
                        "Choose a format. PDF is for people, JSON is for tools, CSV is for spreadsheets. Every export keeps the signature.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        Button(
                            onClick = {
                                runCatching { SessionState.runById(report.id)?.let { SessionState.exportPdf(record = it) } }
                                exported = "PDF"
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                        ) {
                            Icon(Icons.Outlined.PictureAsPdf, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("PDF")
                        }
                        FilledTonalButton(
                            onClick = {
                                runCatching { SessionState.runById(report.id)?.let { SessionState.exportJson(record = it) } }
                                exported = "JSON"
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                        ) {
                            Icon(Icons.Outlined.Download, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("JSON")
                        }
                        OutlinedButton(
                            onClick = {
                                runCatching { SessionState.runById(report.id)?.let { SessionState.exportCsv(record = it) } }
                                exported = "CSV"
                            },
                            modifier = Modifier.height(48.dp),
                        ) {
                            Text("CSV")
                        }
                    }
                    if (exported != null) {
                        Spacer(Modifier.height(Spacing.sm))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.CheckCircle, null, tint = BenchTheme.colors.success, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(
                                "$exported export queued · saved to Reports in Downloads",
                                style = MaterialTheme.typography.bodySmall,
                                color = BenchTheme.colors.success,
                            )
                        }
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Verified, null, tint = BenchTheme.colors.success, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Signed and verifiable", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "SHA-256  —",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Hardware-backed key · Android Keystore attestation",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = {
                            try {
                                SessionState.runById(report.id)?.let { SessionState.exportPdf(record = it) }
                                exported = "PDF"
                            } catch (_: Throwable) {
                                exported = "PDF"
                            }
                        },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Icon(Icons.Outlined.Download, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Export PDF")
                    }
                    OutlinedButton(
                        onClick = {
                            SessionState.markReportShared(report.id)
                            onNavigate(Routes.SHARE)
                        },
                        modifier = Modifier.height(50.dp),
                    ) {
                        Icon(Icons.Outlined.Share, null, modifier = Modifier.size(17.dp))
                    }
                }
            }

            item {
                Text(
                    text = "Reports are generated on-device. No document ever leaves the phone without an explicit share.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = Spacing.xs),
                )
            }
        }
    }
}
