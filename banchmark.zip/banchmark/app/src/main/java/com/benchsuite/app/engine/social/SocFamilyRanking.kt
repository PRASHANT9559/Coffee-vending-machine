package com.benchsuite.app.engine.social

import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 19.3: SoC Family Ranking
 *
 * Aggregate and position devices within their architectural SoC silicon family (e.g. Snapdragon
 * 8 Gen-series, MediaTek Dimensity, Google Tensor, Apple A-series via cross-platform data).
 * Visualizes thermal and efficiency boundaries across an entire chip family.
 *
 * Data source: SoC family detection from Build properties + ranking model.
 * Limitations: No cross-platform data or live server; family position modeled per SoC class,
 * not fabricated measured values.
 */
object SocFamilyRanking {

    data class SocFamilyMember(
        val family: String,
        val generation: Int,
        val model: String,
        val score: Int,
        val percentile: Double,
    )

    data class SocRankReport(
        val deviceSoc: String,
        val family: String,
        val generation: Int,
        val familyMembers: List<SocFamilyMember>,
        val familyPercentile: Double,
        val rankScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun detectFamily(): Pair<String, Int> {
        val hw = Build.HARDWARE.lowercase()
        val model = Build.MODEL.lowercase()
        return when {
            hw.contains("sm8") -> Pair("Qualcomm Snapdragon 8-series", 8)
            hw.contains("sm7") -> Pair("Qualcomm Snapdragon 7-series", 7)
            hw.contains("sm6") -> Pair("Qualcomm Snapdragon 6-series", 6)
            hw.contains("mt") || hw.contains("dimensity") -> Pair("MediaTek Dimensity", 7)
            hw.contains("exynos") -> Pair("Samsung Exynos", 8)
            hw.contains("gs") || Build.MANUFACTURER.lowercase().contains("google") -> Pair("Google Tensor", 7)
            else -> Pair("Generic SoC family", 5)
        }
    }

    /**
     * Ranks the device SoC within its silicon family via model.
     */
    fun rankSocFamily(): SocRankReport {
        val (family, generation) = detectFamily()
        val soc = Build.HARDWARE
        val model = Build.MODEL

        // Simulated family members ranked by generation and tier
        val members = mutableListOf<SocFamilyMember>()
        for (gen in (generation - 2)..(generation + 1)) {
            for (tier in listOf("X Elite", "Plus", "Standard")) {
                val baseScore = when {
                    gen == generation && tier == "X Elite" -> 900
                    gen == generation -> 800
                    gen == generation - 1 -> 700
                    else -> 600
                }
                members.add(SocFamilyMember(family, gen, "${family} Gen $gen $tier", baseScore,
                    (baseScore / 10.0).coerceIn(0.0, 100.0)))
            }
        }

        val deviceScore = when {
            generation >= 8 -> 850
            generation == 7 -> 720
            generation == 6 -> 580
            else -> 450
        }
        val percentile = members.filter { it.score < deviceScore }.size.toDouble() / max(members.size, 1) * 100.0

        val score = when {
            percentile >= 80.0 -> 930
            percentile >= 60.0 -> 800
            percentile >= 40.0 -> 660
            else -> 500
        }

        val verdict = when {
            percentile >= 80.0 -> "$model ranks in the top tier of the $family family."
            percentile >= 50.0 -> "$model is mid-pack within the $family family."
            else -> "$model ranks below the family median; older SoC generation."
        }

        return SocRankReport(
            deviceSoc = soc,
            family = family,
            generation = generation,
            familyMembers = members,
            familyPercentile = (percentile.coerceIn(0.0, 100.0) * 100.0).roundToInt() / 100.0,
            rankScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No cross-platform data or live server; family position modeled per SoC class.",
        )
    }
}
