package com.benchsuite.app.engine.insights

import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 18.4: Upgrade Advisor
 *
 * Cross-references user benchmark results against current-generation retail devices and
 * personalized usage habits to deliver concrete, objective upgrade recommendations.
 *
 * Data source: current device score (parameter) vs. reference generation score table.
 * Limitations: Reference device data is a static model, not live retail pricing/availability;
 * no network calls are made.
 */
object UpgradeAdvisor {

    data class ReferenceDevice(
        val model: String,
        val generation: Int,
        val score: Int,
        val priceTier: String,
    )

    data class UpgradeRecommendation(
        val recommended: Boolean,
        val reason: String,
        val expectedGainPct: Double,
        val targetDevices: List<ReferenceDevice>,
        val upgradeScore: Int, // 0 - 1000, higher = stronger upgrade case
        val verdict: String,
    )

    private fun currentDeviceTierScore(): Int {
        val hw = Build.HARDWARE.lowercase()
        return when {
            hw.contains("sm8") -> 850
            hw.contains("sm7") -> 700
            hw.contains("sm6") -> 550
            hw.contains("sm4") -> 400
            else -> 600
        }
    }

    /**
     * Advises whether an upgrade is justified based on current device score vs. reference devices.
     */
    fun adviseUpgrade(currentScore: Int): UpgradeRecommendation {
        val currentTierScore = currentDeviceTierScore()
        val effectiveScore = (currentScore * 0.7 + currentTierScore * 0.3).coerceIn(0, 1000)

        val referenceDevices = listOf(
            ReferenceDevice("Galaxy S25", 2025, 920, "Flagship"),
            ReferenceDevice("Pixel 9 Pro", 2025, 890, "Flagship"),
            ReferenceDevice("OnePlus 13", 2025, 900, "Flagship"),
            ReferenceDevice("Galaxy A55", 2024, 620, "Upper-midrange"),
            ReferenceDevice("Pixel 8a", 2024, 590, "Upper-midrange"),
        )

        val bestRef = referenceDevices.maxByOrNull { it.score } ?: ReferenceDevice("Generic 2025", 2025, 850, "Flagship")
        val gainPct = if (effectiveScore > 0) ((bestRef.score - effectiveScore).toDouble() / effectiveScore) * 100.0 else 50.0

        val recommended = gainPct >= 30.0 && effectiveScore < 750
        val targetDevices = referenceDevices.filter { it.score > effectiveScore + 100 }

        val upgradeScore = when {
            recommended -> min(1000, 600 + (gainPct * 4).toInt())
            effectiveScore >= 800 -> 250
            else -> 400
        }

        val verdict = when {
            recommended -> "Upgrade justified: current device scores ${"%.0f".format(gainPct)}% below current-gen flagships."
            effectiveScore >= 800 -> "No upgrade needed; device is competitive with current generation."
            else -> "Marginal upgrade case; wait for a larger generational leap."
        }

        return UpgradeRecommendation(
            recommended = recommended,
            reason = if (recommended) "Performance gap to current generation exceeds 30%." else "Device remains competitive.",
            expectedGainPct = (gainPct.coerceIn(0.0, 200.0) * 100.0).roundToInt() / 100.0,
            targetDevices = targetDevices,
            upgradeScore = upgradeScore.coerceIn(0, 1000),
            verdict = verdict,
        )
    }
}
