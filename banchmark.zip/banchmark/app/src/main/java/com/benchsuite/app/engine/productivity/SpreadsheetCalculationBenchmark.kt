package com.benchsuite.app.engine.productivity

import com.benchsuite.app.util.*

import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 13.5: Spreadsheet Calculation Benchmark
 *
 * Run complex Monte Carlo simulations and pivot table operations in a sandboxed spreadsheet
 * engine. Business users need fast spreadsheet performance; no mobile benchmark exists.
 *
 * Data source: synthetic spreadsheet computation model per operation class.
 * Limitations: No real spreadsheet engine; calculation times modeled per operation, not
 * fabricated measured values.
 */
object SpreadsheetCalculationBenchmark {

    data class OperationResult(
        val operation: String,
        val cellCount: Int,
        val calcTimeMs: Double,
        val cellsPerSec: Double,
    )

    data class SpreadsheetReport(
        val results: List<OperationResult>,
        val averageCellsPerSec: Double,
        val spreadsheetScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun deviceTier(): String {
        val hw = Build.HARDWARE.lowercase()
        return when {
            hw.contains("sm8") -> "Flagship"
            hw.contains("sm7") -> "Upper-midrange"
            hw.contains("sm6") -> "Mainstream"
            else -> "Entry-level"
        }
    }

    /**
     * Benchmarks spreadsheet calculation operations via synthetic compute model.
     */
    fun runSpreadsheetBenchmark(): SpreadsheetReport {
        val tier = deviceTier()
        val tierFactor = when (tier) {
            "Flagship" -> 1.0
            "Upper-midrange" -> 1.5
            "Mainstream" -> 2.5
            else -> 4.0
        }

        val results = listOf(
            Triple("Monte Carlo (10k iterations)", 100_000, 800.0),
            Triple("Pivot table (50k cells)", 50_000, 300.0),
            Triple("VLOOKUP cross-ref (20k rows)", 20_000, 150.0),
        ).map { (op, cells, baseMs) ->
            val calcMs = baseMs * tierFactor
            OperationResult(op, cells, (calcMs * 10.0).roundToInt() / 10.0,
                (cells.toDouble() / max(calcMs, 1.0) * 1000.0 * 100.0).roundToInt() / 100.0)
        }

        val avgCellsPerSec = results.averageOf { it.cellsPerSec }
        val score = when {
            avgCellsPerSec >= 100_000.0 -> 920
            avgCellsPerSec >= 40_000.0 -> 780
            avgCellsPerSec >= 15_000.0 -> 620
            else -> 440
        }

        val verdict = when {
            avgCellsPerSec >= 100_000.0 -> "Fast spreadsheet calculation; business workloads are smooth."
            avgCellsPerSec >= 40_000.0 -> "Acceptable spreadsheet performance."
            else -> "Slow spreadsheet calculation; complex sheets will lag."
        }

        return SpreadsheetReport(
            results = results,
            averageCellsPerSec = (avgCellsPerSec * 100.0).roundToInt() / 100.0,
            spreadsheetScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real spreadsheet engine; calculation times modeled per operation and device tier.",
        )
    }
}
