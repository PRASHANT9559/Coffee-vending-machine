package com.benchsuite.app.engine.camera

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 8.5: RAW Processing Pipeline Benchmark
 *
 * Measure time to demosaic, apply lens corrections, and export a 48MP RAW file to JPEG. Pro
 * photographers need fast RAW workflows; no mobile benchmark tests this.
 *
 * Data source: Camera2 RAW capability + demosaic timing model per megapixel.
 * Limitations: No real RAW file or ISP pipeline; processing time modeled per resolution, not
 * fabricated measured values.
 */
object RawProcessingPipelineBenchmark {

    data class RawStage(
        val stage: String,
        val latencyMs: Double,
    )

    data class RawReport(
        val cameraId: String,
        val rawSupported: Boolean,
        val megapixels: Int,
        val stages: List<RawStage>,
        val totalExportMs: Double,
        val exportsPerMinute: Double,
        val rawScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun supportsRaw(context: Context): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_RAW) ||
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ADVANCED_PHOTO)
    }

    /**
     * Benchmarks RAW demosaic and export pipeline time per megapixel.
     */
    fun benchmarkRawPipeline(context: Context, cameraId: String = "0"): RawReport {
        val rawSupported = supportsRaw(context)
        val megapixels = 48
        val stages = mutableListOf<RawStage>()
        var total = 0.0

        if (rawSupported) {
            val perMpMs = when {
                Build.HARDWARE.lowercase().contains("sm8") -> 3.5
                Build.HARDWARE.lowercase().contains("sm7") -> 5.5
                Build.HARDWARE.lowercase().contains("sm6") -> 8.5
                else -> 12.0
            }
            val demosaicMs = megapixels * perMpMs
            val lensCorrectionMs = megapixels * 1.2
            val noiseReductionMs = megapixels * 4.0
            val encodeMs = megapixels * 2.0
            stages.add(RawStage("Demosaic", (demosaicMs * 10.0).roundToInt() / 10.0))
            stages.add(RawStage("Lens correction & distortion", (lensCorrectionMs * 10.0).roundToInt() / 10.0))
            stages.add(RawStage("Noise reduction & sharpening", (noiseReductionMs * 10.0).roundToInt() / 10.0))
            stages.add(RawStage("JPEG encode & export", (encodeMs * 10.0).roundToInt() / 10.0))
            total = demosaicMs + lensCorrectionMs + noiseReductionMs + encodeMs
        } else {
            stages.add(RawStage("No RAW support", 0.0))
        }

        val exportsPerMin = if (total > 0) 60000.0 / total else 0.0
        val score = when {
            rawSupported && total <= 400.0 -> 920
            rawSupported -> 760
            else -> 350
        }

        val verdict = when {
            rawSupported && total <= 400.0 -> "Fast RAW pipeline; ~${exportsPerMin.roundToInt()} 48MP exports per minute."
            rawSupported -> "RAW supported but export is slow for high-resolution bursts."
            else -> "No RAW processing capability detected on this camera."
        }

        return RawReport(
            cameraId = cameraId,
            rawSupported = rawSupported,
            megapixels = megapixels,
            stages = stages,
            totalExportMs = (total * 100.0).roundToInt() / 100.0,
            exportsPerMinute = (exportsPerMin * 100.0).roundToInt() / 100.0,
            rawScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real RAW file or ISP pipeline; time modeled per megapixel and device class.",
        )
    }
}
