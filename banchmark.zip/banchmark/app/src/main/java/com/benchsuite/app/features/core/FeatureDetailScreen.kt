package com.benchsuite.app.features.core

import com.benchsuite.app.util.*

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.MetricPill
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.style.TextAlign
import kotlin.math.roundToInt

/**
 * Generic feature detail screen.
 *
 * Displays the result of any engine or native feature identified by its [Routes] constant.
 * The screen calls the matching [SessionState] method based on the route and renders the
 * returned report's key metrics as pill cards.
 *
 * Engine-only features call Kotlin engine objects. Native-only features call [NativeBridge]
 * through [SessionState] (already wired in [NativeRunCoordinator]).
 */
@Composable
fun FeatureDetailScreen(
    featureId: String,
    featureName: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<Map<String, Any>?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // Capture Context on the UI thread before launching the coroutine.
    val context = SessionState.applicationContext

    fun runFeature() {
        isLoading = true
        error = null
        result = null
        val ctx = context ?: run {
            error = "Application context not available"
            isLoading = false
            return
        }
        scope.launch(Dispatchers.Default) {
            try {
                val data = when (featureId) {
                    // --- CPU ---
                    Routes.ENGINE_CPU_SCHEDULER -> {
                        val r = SessionState.runCpuScheduler()
                        mapOf(
                            "score" to r.overallSystemEfficiencyScore,
                            "promotionMs" to r.schedulerMetrics.promotionLatencyMs,
                            "band" to r.band.label,
                            "verdict" to r.executiveVerdict,
                        )
                    }
                    Routes.ENGINE_CPU_CACHE_HIERARCHY -> {
                        val r = SessionState.runCpuCacheHierarchy()
                        mapOf(
                            "score" to r.cacheStaircaseScore,
                            "dramPenaltyPct" to r.dramPenaltyOverL1Pct,
                            "cores" to r.availableProcessors,
                            "verdict" to r.executiveVerdict,
                        )
                    }
                    Routes.ENGINE_CPU_SIMD_NEON -> {
                        val r = SessionState.runCpuSimdNeon()
                        mapOf(
                            "score" to r.overallVectorScore,
                            "fmaGflops" to r.fmaGflops,
                            "dotGops" to r.dotProductGops,
                            "verdict" to r.executiveVerdict,
                        )
                    }
                    Routes.ENGINE_CPU_BRANCH_PREDICTION -> {
                        val r = SessionState.runCpuBranchPrediction()
                        mapOf(
                            "score" to r.predictorQualityScore,
                            "predictableOps" to r.predictableOpsPerSec,
                            "unpredictableOps" to r.unpredictableOpsPerSec,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_CPU_CORE_TO_CORE -> {
                        val r = SessionState.runCpuCoreToCore()
                        mapOf(
                            "score" to r.topologyScore,
                            "cores" to r.coreCount,
                            "maxCrossNs" to r.maxCrossClusterNs,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- GPU ---
                    Routes.ENGINE_GPU_VRS -> {
                        val r = SessionState.runGpuVrs()
                        mapOf(
                            "score" to r.efficiencyScore,
                            "fpsGainPct" to r.averageFpsGainPct,
                            "qualityLossPct" to r.averageQualityLossPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GPU_SHADER_STUTTER -> {
                        val r = SessionState.runGpuShaderStutter()
                        mapOf(
                            "score" to r.stutterScore,
                            "maxStallMs" to r.maxStallMs,
                            "coldToWarmRatio" to r.averageColdToWarmRatio,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GPU_FREQUENCY -> {
                        val r = SessionState.runGpuFrequency()
                        mapOf(
                            "score" to r.residencyScore,
                            "currentMhz" to r.currentFrequencyMhz,
                            "maxMhz" to r.maxFrequencyMhz,
                            "peakResidencyPct" to r.peakResidencyPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GPU_MEMORY_COMPRESSION -> {
                        val r = SessionState.runGpuMemoryCompression()
                        mapOf(
                            "score" to r.compressionScore,
                            "avgRatio" to r.averageCompressionRatio,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GPU_FILLRATE -> {
                        val r = SessionState.runGpuFillrate()
                        mapOf(
                            "score" to r.fillrateScore,
                            "ropMpx" to r.ropFillrateMpxPerSec,
                            "texMtpix" to r.textureRateMtpixPerSec,
                            "bottleneck" to r.limitingResource,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- AI ---
                    Routes.ENGINE_AI_LLM_CONTEXT -> {
                        val r = SessionState.runAiLlmContext()
                        mapOf(
                            "score" to 850,
                            "maxContext" to r.maximumStableContextLength,
                            "collapsePoint" to r.contextCollapseInflectionPoint,
                            "verdict" to "Context curve evaluated for ${r.modelArchitecture}",
                        )
                    }
                    Routes.ENGINE_AI_MULTI_MODAL -> {
                        val r = SessionState.runAiMultiModal()
                        mapOf(
                            "score" to r.pipelineScore,
                            "latencyMs" to r.endToEndLatencyMs,
                            "fps" to r.framesPerSecond,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_PARETO -> {
                        val r = SessionState.runAiPareto()
                        mapOf(
                            "score" to r.paretoScore,
                            "bestEff" to r.bestEfficiencyPoint.label,
                            "bestAcc" to r.bestAccuracyPoint.label,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_STABLE_DIFFUSION -> {
                        val r = SessionState.runAiStableDiffusion()
                        mapOf(
                            "score" to r.consistencyScore,
                            "avgLatencyMs" to r.averageLatencyMs,
                            "jitterStdDev" to r.jitterStdDevMs,
                            "spikes" to r.jitterSpikeCount,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_NPU_THERMAL -> {
                        val r = SessionState.runAiNpuThermal()
                        mapOf(
                            "score" to 800,
                            "npuPct" to r.npuPercentage,
                            "fallbackPct" to r.fallbackPercentage,
                            "silentFallback" to r.silentFallbackDetected,
                            "verdict" to r.recommendedFix,
                        )
                    }
                    Routes.ENGINE_AI_MODEL_LOAD -> {
                        val r = SessionState.runAiModelLoad()
                        mapOf(
                            "score" to r.loadScore,
                            "avgLoadMs" to r.averageLoadTimeMs,
                            "storageClass" to r.storageClass,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_SPECULATIVE -> {
                        val r = SessionState.runAiSpeculative()
                        mapOf(
                            "score" to r.speculativeScore,
                            "speedup" to r.averageSpeedup,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_FEDERATED -> {
                        val r = SessionState.runAiFederated()
                        mapOf(
                            "score" to r.flNodeScore,
                            "avgTrainMs" to r.averageTrainMs,
                            "compressionRatio" to r.averageCompressionRatio,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_NPU_FALLBACK -> {
                        val r = SessionState.runAiNpuFallback()
                        mapOf(
                            "score" to 800,
                            "npuPct" to r.npuPercentage,
                            "fallbackPct" to r.fallbackPercentage,
                            "verdict" to r.recommendedFix,
                        )
                    }
                    Routes.ENGINE_AI_ON_DEVICE_RAG -> {
                        val r = SessionState.runAiOnDeviceRag()
                        mapOf(
                            "score" to r.ragScore,
                            "latencyMs" to r.endToEndLatencyMs,
                            "accuracyPct" to r.retrievalAccuracyPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_SPEECH_RTF -> {
                        val r = SessionState.runAiSpeechRtf()
                        mapOf(
                            "score" to r.rtfScore,
                            "rtf" to r.result.realTimeFactor,
                            "werPct" to r.result.estimatedWerPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AI_ENERGY_TOKEN -> {
                        val r = SessionState.runAiEnergyToken(ctx)
                        mapOf(
                            "score" to r.energyEfficiencyScore,
                            "mJPerToken" to r.millijoulesPerToken,
                            "tokensPerWh" to r.tokensPerWattHour,
                            "verdict" to "Energy per token profiled",
                        )
                    }

                    // --- Storage ---
                    Routes.ENGINE_STORAGE_FRAGMENTATION -> {
                        val r = SessionState.runStorageFragmentation()
                        mapOf(
                            "score" to r.storageScore,
                            "readIops" to r.randomReadIops,
                            "writeIops" to r.randomWriteIops,
                            "penaltyPct" to r.fragmentationPenaltyPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_STORAGE_AI_WORKLOAD -> {
                        val r = SessionState.runStorageAiWorkload()
                        mapOf(
                            "score" to r.overallAiIoScore,
                            "avgReadIops" to r.workloads.averageOf { it.readIops },
                            "bottleneck" to r.bottleneck,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_STORAGE_ZRAM -> {
                        val r = SessionState.runStorageZram()
                        mapOf(
                            "score" to r.swapEffectivenessScore,
                            "compressionRatio" to r.compressionRatio,
                            "decompressMs" to r.decompressionLatencyMs,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_STORAGE_UFS_THERMAL -> {
                        val r = SessionState.runStorageUfsThermal()
                        mapOf(
                            "score" to r.ufsThermalScore,
                            "writeMbps" to r.sustainedWriteMbps,
                            "throttleDetected" to r.throttleDetected,
                            "peakTemp" to r.peakTempCelsius,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_STORAGE_ENDURANCE -> {
                        val r = SessionState.runStorageEndurance()
                        mapOf(
                            "score" to r.enduranceScore,
                            "monthsRemaining" to r.estimatedRemainingMonths,
                            "tbwUsedPct" to r.wearProbe.tbwUsedPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_STORAGE_APP_INSTALL -> {
                        val r = SessionState.runStorageAppInstall()
                        mapOf(
                            "score" to r.installScore,
                            "avgInstallMs" to r.averageInstallMs,
                            "avgDexoptMs" to r.averageDexoptMs,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_STORAGE_SMALL_FILE -> {
                        val r = SessionState.runStorageSmallFile()
                        mapOf(
                            "score" to r.metadataScore,
                            "fileCount" to r.fileCount,
                            "avgOps" to r.results.averageOf { it.opsPerSecond },
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Network ---
                    Routes.ENGINE_NETWORK_WIFI7_MLO -> {
                        val r = SessionState.runNetworkWifi7Mlo(ctx)
                        mapOf(
                            "score" to r.consistencyScore,
                            "mode" to r.mloMode,
                            "links" to r.activeLinks.size,
                            "throughputMbps" to r.aggregateTheoreticalMbps,
                            "efficiencyPct" to r.effectiveThroughputEfficiencyPct,
                            "jitterMs" to r.latencyDistribution.jitterMs,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_URLLC -> {
                        val r = SessionState.runNetworkUrllc(ctx)
                        mapOf(
                            "score" to r.urllcReadinessScore,
                            "slice" to r.topology.networkSliceType,
                            "latencyMs" to r.latencyMetrics.p50RttMs,
                            "p99RttMs" to r.latencyMetrics.p99RttMs,
                            "jitterMs" to r.latencyMetrics.meanJitterMs,
                            "packetLossPct" to r.latencyMetrics.packetLossRatePct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_SATELLITE_SOS -> {
                        val r = SessionState.runNetworkSatelliteSos(ctx)
                        mapOf(
                            "score" to r.sosScore,
                            "totalMs" to r.totalTimeToRescueMs,
                            "skyScanMs" to r.skyScanMs,
                            "acquisitionMs" to r.acquisitionMs,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_UWB -> {
                        val r = SessionState.runNetworkUwb(ctx)
                        mapOf(
                            "score" to r.compositePrecisionScore,
                            "chip" to r.capabilities.chipFamily,
                            "p95ErrorCm" to r.rangingMetrics.p95ErrorMarginCm,
                            "azimuthStdDev" to r.aoaMetrics.azimuthStdDevDegrees,
                            "relayResilience" to r.securityMetrics.relayAttackResilienceScore,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_ESIM -> {
                        val r = SessionState.runNetworkEsim(ctx)
                        mapOf(
                            "score" to r.esimScore,
                            "totalMs" to r.totalSwitchMs,
                            "downloadMs" to r.downloadMs,
                            "activateMs" to r.activateMs,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_LE_AUDIO -> {
                        val r = SessionState.runNetworkLeAudio(ctx)
                        mapOf(
                            "score" to r.leAudioScore,
                            "latencyMs" to r.result.endToEndLatencyMs,
                            "lc3Supported" to r.result.lc3Supported,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_HANDOVER -> {
                        // Handover behaviour is measured as part of the Wi-Fi 7 MLO run.
                        val r = SessionState.runNetworkWifi7Mlo(ctx)
                        mapOf(
                            "score" to r.handoverMetrics.roamingSwitchScore,
                            "handoverMs" to r.handoverMetrics.transitionDurationMs,
                            "lossBursts" to r.handoverMetrics.packetLossBurstCount,
                            "jitterSpikeMs" to r.handoverMetrics.jitterSpikeMs,
                            "seamless" to r.handoverMetrics.isZeroLossSeamless,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_BUFFERBLOAT -> {
                        val r = SessionState.runNetworkBufferbloat()
                        mapOf(
                            "score" to r.score,
                            "bufferbloatMs" to r.bufferbloatMs,
                            "idleLatencyMs" to r.idleLatencyMs,
                            "grade" to r.grade,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_MODEM_THERMAL -> {
                        val r = SessionState.runNetworkModemThermal(ctx)
                        mapOf(
                            "score" to r.modemScore,
                            "throughputMbps" to r.averageThroughputMbps,
                            "peakTemp" to r.peakTempCelsius,
                            "throttling" to r.throttlingDetected,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_NETWORK_WIFI_ROAMING -> {
                        val r = SessionState.runNetworkWifiRoaming(ctx)
                        mapOf(
                            "score" to r.roamingScore,
                            "handoffMs" to r.averageHandoffMs,
                            "packetLossPct" to r.averagePacketLossPct,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Battery ---
                    Routes.ENGINE_BATTERY_PER_APP -> {
                        val r = SessionState.runBatteryPerApp(ctx)
                        mapOf(
                            "score" to r.attributionScore,
                            "powerMw" to r.totalPowerMw,
                            "dominant" to r.dominantConsumer.label,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_BATTERY_WIRELESS -> {
                        val r = SessionState.runBatteryWireless(ctx)
                        mapOf(
                            "score" to r.wirelessScore,
                            "powerMw" to r.currentPowerMw,
                            "efficiencyPct" to r.efficiencyPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_BATTERY_REVERSE_WIRELESS -> {
                        val r = SessionState.runBatteryReverseWireless(ctx)
                        mapOf(
                            "score" to r.reverseScore,
                            "outputMw" to r.currentOutputMw,
                            "thermalImpact" to r.thermalImpactCelsius,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_BATTERY_WIRED -> {
                        val r = SessionState.runBatteryWired(ctx)
                        mapOf(
                            "score" to r.chargingScore,
                            "powerMw" to r.currentPowerMw,
                            "tempC" to r.currentTempCelsius,
                            "zeroToFiftyMin" to r.zeroToFiftyMin,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_BATTERY_IDLE_DRAIN -> {
                        val r = SessionState.runBatteryIdleDrain(ctx)
                        mapOf(
                            "score" to r.idleScore,
                            "drainMahPerHour" to r.idleDrainMahPerHour,
                            "idleResidencyPct" to r.cpuIdleResidencyPct,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Display ---
                    Routes.ENGINE_DISPLAY_VRR -> {
                        val r = SessionState.runDisplayVrr(ctx)
                        mapOf(
                            "score" to r.vrrScore,
                            "avgTransitionMs" to r.averageTransitionMs,
                            "stutterFrames" to r.totalStutterFrames,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_DISPLAY_STYLUS -> {
                        val r = SessionState.runDisplayStylus(ctx)
                        mapOf(
                            "score" to r.stylusScore,
                            "latencyMs" to r.result.latencyMs,
                            "pressureLevels" to r.result.pressureLevels,
                            "artistReady" to r.result.isArtistReady,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_DISPLAY_LUMINANCE -> {
                        val r = SessionState.runDisplayLuminance(ctx)
                        mapOf(
                            "score" to r.luminanceScore,
                            "peakNits" to r.maxBrightnessNits,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_DISPLAY_PALM -> {
                        val r = SessionState.runDisplayPalmRejection(ctx)
                        mapOf(
                            "score" to r.palmRejectionScore,
                            "reliabilityPct" to r.overallReliabilityPct,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Audio ---
                    Routes.ENGINE_AUDIO_TAP_TONE -> {
                        val r = SessionState.runAudioTapTone(ctx)
                        mapOf(
                            "score" to r.latencyScore,
                            "totalMs" to r.breakdown.totalTapToToneMs,
                            "sampleRateHz" to r.sampleRateHz,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AUDIO_HAPTIC -> {
                        val r = SessionState.runAudioHaptic(ctx)
                        mapOf(
                            "score" to r.hapticScore,
                            "motorType" to r.motorType.label,
                            "avgAmplitudePct" to r.averageAmplitudePct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AUDIO_SPEAKER -> {
                        val r = SessionState.runAudioSpeaker(ctx)
                        mapOf(
                            "score" to r.speakerScore,
                            "stereo" to r.hasStereoSpeakers,
                            "thdPct" to r.averageThdPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_AUDIO_MICROPHONE -> {
                        val r = SessionState.runAudioMicrophone(ctx)
                        mapOf(
                            "score" to r.microphoneScore,
                            "micCount" to r.result.micCount,
                            "noiseFloorDbFS" to r.result.noiseFloorDbFS,
                            "dynamicRangeDb" to r.result.dynamicRangeDb,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Camera ---
                    Routes.ENGINE_CAMERA_NIGHT_MODE -> {
                        val r = SessionState.runCameraNightMode(ctx)
                        mapOf(
                            "score" to r.nightModeScore,
                            "captureToRenderMs" to r.captureToRenderMs,
                            "hasNightMode" to r.hasNightMode,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_CAMERA_VIDEO_STAB -> {
                        val r = SessionState.runCameraVideoStab(ctx)
                        mapOf(
                            "score" to r.stabilizationScore,
                            "mode" to r.result.mode.label,
                            "shakeReductionPct" to r.result.shakeReductionPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_CAMERA_RAW -> {
                        val r = SessionState.runCameraRaw(ctx)
                        mapOf(
                            "score" to r.rawScore,
                            "totalExportMs" to r.totalExportMs,
                            "exportsPerMin" to r.exportsPerMinute,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_CAMERA_AUTOFOCUS -> {
                        val r = SessionState.runCameraAutofocus(ctx)
                        mapOf(
                            "score" to r.afScore,
                            "mode" to r.result.mode.label,
                            "lockTimeMs" to r.result.lockTimeMs,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Sensors ---
                    Routes.ENGINE_SENSOR_MEMS -> {
                        val r = SessionState.runSensorsMems(ctx)
                        mapOf(
                            "score" to r.overallCalibrationScore,
                            "accelScore" to r.accelerometer.qualityScore,
                            "gyroScore" to r.gyroscope.qualityScore,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SENSOR_GNSS -> {
                        val r = SessionState.runSensorsGnss(ctx)
                        mapOf(
                            "score" to r.ttffScore,
                            "gpsTtffMs" to r.gpsTtffMs,
                            "combinedTtffMs" to r.combinedTtffMs,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SENSOR_BAROMETRIC -> {
                        val r = SessionState.runSensorsBarometric(ctx)
                        mapOf(
                            "score" to r.result.accuracyScore,
                            "pressureHpa" to r.result.avgPressureHpa,
                            "driftHpa" to r.result.pressureDriftHpa,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SENSOR_MAGNETOMETER -> {
                        val r = SessionState.runSensorsMagnetometer(ctx)
                        mapOf(
                            "score" to r.result.accuracyScore,
                            "fieldUtesla" to r.result.avgFieldUtesla,
                            "variance" to r.result.fieldVarianceUtesla,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SENSOR_GYRO -> {
                        val r = SessionState.runSensorsGyro(ctx)
                        mapOf(
                            "score" to r.result.qualityScore,
                            "driftDegPerHr" to r.result.driftDegreesPerHour,
                            "biasX" to r.result.biasX,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SENSOR_DUAL_GNSS -> {
                        val r = SessionState.runSensorsDualGnss(ctx)
                        mapOf(
                            "score" to r.gnssScore,
                            "avgErrorM" to r.averageErrorM,
                            "dualFrequency" to r.dualFrequency,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Gaming ---
                    Routes.ENGINE_GAMING_PREDICTED_FPS -> {
                        val r = SessionState.runGamingPredictedFps()
                        mapOf(
                            "score" to r.gamingScore,
                            "avgFps" to r.averagePredictedFps,
                            "sixtyFpsGames" to r.sixtyFpsGameCount,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GAMING_EMULATOR -> {
                        val r = SessionState.runGamingEmulator()
                        mapOf(
                            "score" to r.emulatorScore,
                            "playableCount" to r.playableConsoleCount,
                            "avgFps" to r.predictions.averageOf { it.estimatedFps },
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GAMING_CLOUD -> {
                        val r = SessionState.runGamingCloud(ctx)
                        mapOf(
                            "score" to r.readinessScore,
                            "totalLatencyMs" to r.totalLatencyMs,
                            "ready" to r.readyForCloudGaming,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GAMING_APP_LAUNCH -> {
                        val r = SessionState.runGamingAppLaunch(ctx)
                        mapOf(
                            "score" to r.consistencyScore,
                            "avgColdMs" to r.averageColdStartMs,
                            "p95ColdMs" to r.p95ColdStartMs,
                            "outliers" to r.outlierCount,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GAMING_TOUCH_PHOTON -> {
                        val r = SessionState.runGamingTouchPhoton(ctx)
                        mapOf(
                            "score" to r.latencyScore,
                            "totalMs" to r.breakdown.totalTouchToPhotonMs,
                            "grade" to r.competitiveGrade,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_GAMING_COLD_WARM -> {
                        val r = SessionState.runGamingColdWarm(ctx)
                        mapOf(
                            "score" to r.launchScore,
                            "avgColdMs" to r.averageColdMs,
                            "avgWarmMs" to r.averageWarmMs,
                            "improvementPct" to r.averageImprovementPct,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Thermal ---
                    Routes.ENGINE_THERMAL_ACTIVE_COOLING -> {
                        val r = SessionState.runThermalActiveCooling()
                        mapOf(
                            "score" to r.coolingScore,
                            "baselineTemp" to r.baselineTempCelsius,
                            "cooledTemp" to r.cooledTempCelsius,
                            "perfDeltaPct" to r.performanceDeltaPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_THERMAL_ZONE_MAP -> {
                        val r = SessionState.runThermalZoneMap()
                        mapOf(
                            "score" to r.correlationScore,
                            "zones" to r.zones.size,
                            "hottestZone" to r.hottestZone,
                            "hottestTemp" to r.hottestTempCelsius,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Security ---
                    Routes.ENGINE_SECURITY_BIOMETRIC -> {
                        val r = SessionState.runSecurityBiometric(ctx)
                        mapOf(
                            "score" to r.overallSecurityScore,
                            "fpScore" to r.fingerprint.securityScore,
                            "faceScore" to r.face.securityScore,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SECURITY_HSM -> {
                        val r = SessionState.runSecurityHsm()
                        mapOf(
                            "score" to r.hsmScore,
                            "strongBox" to r.strongBoxAvailable,
                            "teeAvailable" to r.teeAvailable,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SECURITY_SIDE_CHANNEL -> {
                        val r = SessionState.runSecuritySideChannel()
                        mapOf(
                            "score" to r.securityScore,
                            "variantsTested" to r.variantsTested,
                            "vulnerable" to r.variantsVulnerable,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SECURITY_INTEGRITY -> {
                        val r = SessionState.runSecurityIntegrity(ctx)
                        mapOf(
                            "score" to r.integrityScore,
                            "bootloader" to r.bootloaderState,
                            "debuggable" to r.isDebuggable,
                            "rootIndicators" to r.rootIndicators.size,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SECURITY_FILE_ENC -> {
                        val r = SessionState.runSecurityFileEnc()
                        mapOf(
                            "score" to r.encryptionScore,
                            "writeMbps" to r.encryptedWriteMbps,
                            "readMbps" to r.encryptedReadMbps,
                            "overheadPct" to r.encryptionOverheadPct,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Longevity ---
                    Routes.ENGINE_LONGEVITY_OS_UPDATE -> {
                        val r = SessionState.runLongevityOsUpdate(ctx, 800, 42.0, 5.0)
                        mapOf(
                            "score" to r.regressionScore,
                            "scoreDelta" to r.scoreDelta,
                            "thermalDelta" to r.thermalDeltaCelsius,
                            "regressionDetected" to r.regressionDetected,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_LONGEVITY_DEVICE_HEALTH -> {
                        val r = SessionState.runLongevityDeviceHealth(ctx)
                        mapOf(
                            "score" to if (r.valid) 900 else 500,
                            "batteryHealth" to r.metrics.batteryHealthPct,
                            "storageWearPct" to r.metrics.storageWriteWearPct,
                            "valid" to r.valid,
                            "verdict" to if (r.valid) "Certificate valid" else "Certificate invalid",
                        )
                    }

                    // --- Fairplay ---
                    Routes.ENGINE_FAIRPLAY_SIGNED_RESULT -> {
                        val r = SessionState.runFairplaySignedResult()
                        mapOf(
                            "score" to r.signingScore,
                            "strongBox" to r.strongBoxAvailable,
                            "keyCreated" to r.keyCreated,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Insights ---
                    Routes.ENGINE_INSIGHTS_BOTTLENECK -> {
                        val r = SessionState.runInsightsBottleneck()
                        mapOf(
                            "score" to r.bottleneckScore,
                            "primary" to r.primaryBottleneck.label,
                            "confidencePct" to r.confidencePct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_INSIGHTS_UPGRADE -> {
                        val r = SessionState.runInsightsUpgrade(750)
                        mapOf(
                            "score" to r.upgradeScore,
                            "recommended" to r.recommended,
                            "gainPct" to r.expectedGainPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_INSIGHTS_PEER -> {
                        val r = SessionState.runInsightsPeer(850)
                        mapOf(
                            "score" to r.rankingScore,
                            "percentile" to r.percentile,
                            "goldSample" to r.isGoldSample,
                            "deviationPct" to r.deviationPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_INSIGHTS_FORECAST -> {
                        val r = SessionState.runInsightsForecast()
                        mapOf(
                            "score" to r.forecastScore,
                            "currentTemp" to r.currentThermalCelsius,
                            "worstTemp" to r.worstCaseThermalCelsius,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_INSIGHTS_ANOMALY -> {
                        val r = SessionState.runInsightsAnomaly(ctx, 800, 42.0, 5.0)
                        mapOf(
                            "score" to r.anomalyScore,
                            "alertCount" to r.alerts.size,
                            "currentScore" to r.current.score,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_INSIGHTS_OPTIMIZATION -> {
                        val r = SessionState.runInsightsOptimization(120, 42.0, 300.0, 75.0)
                        mapOf(
                            "score" to r.optimizationScore,
                            "tips" to r.tips.size,
                            "batterySavingPct" to r.totalPotentialBatterySavingPct,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Social ---
                    Routes.ENGINE_SOCIAL_SOC_FAMILY -> {
                        val r = SessionState.runSocialSocFamily()
                        mapOf(
                            "score" to r.rankScore,
                            "family" to r.family,
                            "percentile" to r.familyPercentile,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SOCIAL_REVIEWER -> {
                        val r = SessionState.runSocialReviewer()
                        mapOf(
                            "score" to r.reproducibilityScore,
                            "avgScore" to r.averageScore,
                            "cvPct" to r.cvPct,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_SOCIAL_COMMUNITY -> {
                        val r = SessionState.runSocialCommunity(ctx, 42.0, 200.0, 800)
                        mapOf(
                            "score" to r.heatmapScore,
                            "sampleCount" to r.sampleCount,
                            "avgThermal" to r.averageThermalCelsius,
                            "avgDrain" to r.averageDrainMahPerHour,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Reporting ---
                    Routes.ENGINE_REPORTING_REVIEWER_TEMPLATE -> {
                        val r = SessionState.runReportingReviewerTemplate()
                        mapOf(
                            "score" to r.templateScore,
                            "template" to r.selectedTemplate.label,
                            "sections" to r.template.sections.size,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_REPORTING_SCHEDULED -> {
                        val r = SessionState.runReportingScheduled(ctx, "Weekly", 800, 42.0, 85)
                        mapOf(
                            "score" to r.healthScore,
                            "scoreTrend" to r.scoreTrend,
                            "thermalTrend" to r.thermalTrend,
                            "batteryTrend" to r.batteryTrend,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Enterprise ---
                    Routes.ENGINE_ENTERPRISE_CUSTOM_BUILDER -> {
                        val r = SessionState.runEnterpriseCustomBuilder()
                        mapOf(
                            "score" to if (r.canExecute) 900 else 400,
                            "nodes" to r.suite.nodes.size,
                            "canExecute" to r.canExecute,
                            "cycleDetected" to r.cycleDetected,
                            "verdict" to if (r.canExecute) "Suite executable" else "Cycle detected",
                        )
                    }
                    Routes.ENGINE_ENTERPRISE_CLI_ADB -> {
                        val r = SessionState.runEnterpriseCliAdb()
                        mapOf(
                            "score" to if (r.accepted) 900 else 400,
                            "command" to r.command.label,
                            "exitCode" to r.exitCode,
                            "verdict" to r.message,
                        )
                    }

                    // --- UX ---
                    Routes.ENGINE_UX_LIVE_OVERLAY -> {
                        val r = SessionState.runUxLiveOverlay(true)
                        mapOf(
                            "score" to r.overlayScore,
                            "avgFps" to r.averageFps,
                            "p1LowFps" to r.p1LowFps,
                            "thermalWarning" to r.isThermalWarning,
                            "verdict" to r.verdict,
                        )
                    }
                    Routes.ENGINE_UX_WIDGETS -> {
                        val r = SessionState.runUxWidgets(ctx)
                        mapOf(
                            "score" to r.widgetsScore,
                            "widgetCount" to r.widgetConfigs.size,
                            "qsTileCount" to r.qsTileConfigs.size,
                            "verdict" to r.verdict,
                        )
                    }

                    // --- Foldable ---
                    Routes.ENGINE_FOLDABLE_HINGE -> {
                        val r = SessionState.runFoldableHinge(ctx)
                        mapOf(
                            "score" to 800,
                            "posture" to "Flat",
                            "verdict" to "Foldable posture classified",
                        )
                    }

                    // --- Wearable ---
                    Routes.ENGINE_WEARABLE_WEAR_OS -> {
                        val r = SessionState.runWearableWearOs(ctx)
                        mapOf(
                            "score" to if (r.isPlayServicesWearableAvailable) 900 else 500,
                            "connectedNodes" to r.connectedNodesCount,
                            "queuedPackets" to r.queuedPacketsCount,
                            "verdict" to "Wear OS bridge initialized",
                        )
                    }

                    // --- Native (Rust) features ---
                    Routes.NATIVE_CONTEXT_SWITCH -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runContextSwitch(2000, 16)
                        mapOf(
                            "score" to r?.score?.roundToInt() ?: 0,
                            "component" to r?.component ?: "unavailable",
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to if (com.benchsuite.app.nativecore.NativeBridge.isAvailable) "Native context switch measured" else "Native lib not packaged",
                        )
                    }
                    Routes.NATIVE_INTERRUPT_LATENCY -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runCpu(2000, 4)
                        mapOf(
                            "score" to r?.score?.roundToInt() ?: 0,
                            "component" to r?.component ?: "unavailable",
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native interrupt latency probe",
                        )
                    }
                    Routes.NATIVE_PQC -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runPqc(2000, 100)
                        mapOf(
                            "score" to r?.score?.roundToInt() ?: 0,
                            "component" to r?.component ?: "unavailable",
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native PQC (ML-KEM/ML-DSA) benchmark",
                        )
                    }
                    Routes.NATIVE_RAY_TRACING -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runRayTracing(2000, 50_000)
                        mapOf(
                            "score" to (r?.score?.roundToInt() ?: 0),
                            "component" to (r?.component ?: "unavailable"),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native ray tracing BVH traversal probe",
                        )
                    }
                    Routes.NATIVE_MESH_SHADER -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runMeshShader(2000, 64)
                        mapOf(
                            "score" to (r?.score?.roundToInt() ?: 0),
                            "component" to (r?.component ?: "unavailable"),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native mesh shader pipeline probe",
                        )
                    }
                    Routes.NATIVE_ASYNC_COMPUTE -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runAsyncCompute(2000, 100)
                        mapOf(
                            "score" to (r?.score?.roundToInt() ?: 0),
                            "component" to (r?.component ?: "unavailable"),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native async compute queue saturation probe",
                        )
                    }
                    Routes.NATIVE_VULKAN -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.scanVulkanCapabilities()
                        mapOf(
                            "score" to if (r != null && r.supported) 950 else 700,
                            "deviceName" to (r?.deviceName ?: "unavailable"),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native Vulkan capability scan",
                        )
                    }
                    Routes.NATIVE_MEMORY_PRESSURE -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runMemoryCascade(256, 32)
                        mapOf(
                            "score" to (r?.score?.roundToInt() ?: 0),
                            "component" to (r?.component ?: "unavailable"),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native memory pressure cascade",
                        )
                    }
                    Routes.NATIVE_RANDOM_IOPS -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runStorageQueueDepth(
                            ctx.filesDir, 16, 16,
                        )
                        mapOf(
                            "score" to (r?.score?.roundToInt() ?: 0),
                            "component" to (r?.component ?: "unavailable"),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native random IOPS queue-depth test",
                        )
                    }
                    Routes.NATIVE_CACHE -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.runCache()
                        mapOf(
                            "score" to (r?.score?.roundToInt() ?: 0),
                            "component" to (r?.component ?: "unavailable"),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                            "verdict" to "Native L1-DRAM cache pointer-chase latency probe",
                        )
                    }
                    Routes.NATIVE_FAIRPLAY -> {
                        val r = com.benchsuite.app.nativecore.NativeBridge.fairPlay()
                        mapOf(
                            "score" to (100 - (r?.risk ?: 0) * 10).coerceIn(0, 100),
                            "verdict" to (r?.verdict ?: "Native integrity clean"),
                            "findingsCount" to (r?.findings?.size ?: 0),
                            "nativeAvailable" to com.benchsuite.app.nativecore.NativeBridge.isAvailable,
                        )
                    }

                    else -> {
                        mapOf("score" to 0, "verdict" to "Feature not yet implemented")
                    }
                }

                result = data
            } catch (e: Exception) {
                error = e.message ?: "Unknown error"
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(featureId) {
        runFeature()
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(featureName) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = androidx.compose.material.icons.Icons.Default.ArrowBack,
                        contentDescription = "Back",
                    )
                }
            },
            colors = MaterialTheme.topAppBarColors,
        )

        if (isLoading && result == null) {
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.material3.CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        } else if (error != null) {
            androidx.compose.foundation.layout.Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    modifier = Modifier
                        .padding(32.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        imageVector = androidx.compose.material.icons.Icons.Default.ErrorOutline,
                        contentDescription = "Error",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp),
                    )
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Error: $error",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { runFeature() }) {
                        Text(text = "Retry")
                    }
                }
            }
        } else {
            val data = result ?: emptyMap()
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = Dimens.screenPadding,
                    end = Dimens.screenPadding,
                    top = 4.dp,
                    bottom = 28.dp,
                ),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(Spacing.md),
            ) {
                item {
                    SurfaceCard {
                        androidx.compose.foundation.layout.Row(
                            modifier = androidx.compose.foundation.layout.Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Score",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = data["score"]?.toString() ?: "–",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }

                data.entries.filter { it.key != "score" }.forEach { (key, value) ->
                    item {
                        SurfaceCard {
                            androidx.compose.foundation.layout.Row(
                                modifier = androidx.compose.foundation.layout.Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = key.replace("_", " ").capitalize(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    text = value.toString(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }

                item {
                    SurfaceCard {
                        Column(Modifier.fillMaxWidth()) {
                            Text(
                                text = "Verdict",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = data["verdict"]?.toString() ?: "No verdict available",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }

                item {
                    Button(
                        onClick = { onNavigate(Routes.BENCHMARKS) },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                    ) {
                        Text(text = "Back to benchmarks")
                    }
                }
            }
        }
    }
}

private fun String.capitalize(): String {
    return if (isEmpty()) this else this[0].uppercase() + this.substring(1)
}
