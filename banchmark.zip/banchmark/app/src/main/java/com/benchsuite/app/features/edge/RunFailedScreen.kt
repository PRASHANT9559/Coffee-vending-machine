package com.benchsuite.app.features.edge

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.model.CheckStatus
import com.benchsuite.app.data.model.EnvironmentCheck
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChecklistRow
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.Spacing

private val failureChecks = emptyList()

@Composable
fun RunFailedScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var exported by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Run failed",
            subtitle = "Diagnosis and retry",
            onBack = onBack,
            actions = {
                IconActionText("Help") { onNavigate(Routes.HELP) }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                SurfaceCard {
                    Column(
                        Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(
                            Modifier.size(64.dp).background(BenchTheme.colors.danger.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.Warning, null, tint = BenchTheme.colors.danger, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.height(Spacing.sm))
                        Text("No score was produced.", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "The run was stopped safely when the thermal ceiling was reached. Partial data was kept for diagnosis, not scoring.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(Spacing.sm))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusChip("THM-204", tint = BenchTheme.colors.danger)
                            StatusChip("Not saved", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                PageHeader(
                    eyebrow = "Run #1043 · 11 Nov 2026 · 10:06",
                    title = "What went wrong.",
                    body = "The device crossed the skin-temperature safety limit at 18 minutes 40 seconds, before the required sustained window completed.",
                )
            }

            item { SectionHeader(title = "Timeline") }
            item {
                SurfaceCard {
                    Text(
                        "रन टाइमलाइन वास्तविक रन डेटा से जनरेट की जाएगी।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item { SectionHeader(title = "Diagnosis") }
            item {
                SurfaceCard {
                    failureChecks.forEach { check ->
                        ChecklistRow(check = check)
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Thermostat, null, tint = BenchTheme.colors.warning, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Recommended next step", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Let the device cool for at least 8 minutes, remove the case and close the pending update. Then retry the same protocol so the result is comparable.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag("Cool down 8 min")
                        Tag("Case off")
                        Tag("No charging")
                    }
                }
            }

            item { SectionHeader(title = "Preserved data") }
            item {
                SurfaceCard {
                    InfoRow("Partial telemetry", "14 min 22 s · 1 Hz sampling")
                    InfoRow("Conditions", "Recorded at start and aborted")
                    InfoRow("Raw samples", "8,612 points · 184 KB")
                    InfoRow("Retention", "24 hours, then deleted automatically")
                    InfoRow("Score", "None · deliberately not extrapolated")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "A failed run is never converted into a score. Extrapolating the missing sustained window would misrepresent the device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Diagnostic bundle", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusChip(if (exported) "Ready" else "Local", tint = if (exported) BenchTheme.colors.success else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "SHA-256  —",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    OutlinedButton(
                        onClick = {
                            val context = SessionState.applicationContext
                            val baseDir = context?.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS) ?: context?.filesDir
                            val file = java.io.File(baseDir, "ABS_CrashDump_${System.currentTimeMillis()}.txt")
                            runCatching {
                                file.writeText("BenchSuite Failure Diagnostics\nDevice: ${SessionState.currentDevice.model}\nOS: ${SessionState.currentDevice.os}\nError: ${SessionState.nativeRunError ?: "Thermal limit reached"}")
                            }
                            exported = true
                        },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                    ) {
                        Icon(Icons.Outlined.Description, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (exported) "Diagnostics ready in Downloads" else "Export diagnostics")
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = {
                            SessionState.startRun("full", "Full benchmark suite · retry")
                            onNavigate(Routes.LIVE_RUN)
                        },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Retry after cooling")
                    }
                    OutlinedButton(
                        onClick = { onNavigate(Routes.BENCHMARKS) },
                        modifier = Modifier.height(50.dp),
                    ) {
                        Text("Choose a test")
                    }
                }
            }

            item {
                TextButton(onClick = { onNavigate(Routes.HELP) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Why was the run aborted? Read thermal safety")
                }
            }

            item {
                Text(
                    "Safety limits exist to protect the battery and your hands. A failed run is a valid outcome, not a bug.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun TimelineRow(time: String, title: String, detail: String, color: androidx.compose.ui.graphics.Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(time, style = NumericDisplay.copy(fontSize = 12.sp), color = color, modifier = Modifier.width(48.dp))
        Box(
            Modifier
                .padding(top = 5.dp)
                .size(6.dp)
                .background(color, CircleShape),
        )
        Spacer(Modifier.width(9.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun IconActionText(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
