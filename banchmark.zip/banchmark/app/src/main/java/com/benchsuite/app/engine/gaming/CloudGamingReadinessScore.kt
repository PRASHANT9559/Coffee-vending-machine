package com.benchsuite.app.engine.gaming

import com.benchsuite.app.util.*

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 12.3: Cloud Gaming Readiness Score
 *
 * Combines network latency, jitter, decode latency, and touch latency into a single "cloud gaming
 * readiness" score. Cloud gaming needs <40ms total latency; no single metric captures this.
 *
 * Data source: ConnectivityManager active network + loopback RTT model.
 * Limitations: No real game-streaming session; readiness is modeled from network interface and
 * RTT, not fabricated measured values.
 */
object CloudGamingReadinessScore {

    data class LatencyComponent(
        val name: String,
        val latencyMs: Double,
    )

    data class CloudGamingReport(
        val networkType: String,
        val networkLatencyMs: Double,
        val jitterMs: Double,
        val decodeLatencyMs: Double,
        val touchLatencyMs: Double,
        val totalLatencyMs: Double,
        val components: List<LatencyComponent>,
        val readyForCloudGaming: Boolean,
        val readinessScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun networkTypeName(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return try {
            val net = cm.activeNetwork
            if (net == null) "None"
            val info = cm.getNetworkCapabilities(net)
            when {
                info.hasTransport(ConnectivityManager.TRANSPORT_WIFI) -> "Wi-Fi"
                info.hasTransport(ConnectivityManager.TRANSPORT_CELLULAR) -> "Cellular"
                info.hasTransport(ConnectivityManager.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Unknown"
            }
        } catch (_: Exception) {
            "Unknown"
        }
    }

    private fun loopbackRttMs(): Double {
        val times = mutableListOf<Double>()
        for (i in 0 until 10) {
            val t0 = SystemClock.elapsedRealtimeNanos()
            try {
                val socket = java.net.Socket()
                socket.connect(java.net.InetSocketAddress("127.0.0.1", 9), 500)
                socket.close()
            } catch (_: Exception) {}
            times.add((SystemClock.elapsedRealtimeNanos() - t0) / 1_000_000.0)
        }
        return times.averageOrNull() ?: 5.0
    }

    /**
     * Computes a cloud gaming readiness score from network + decode + touch latency.
     */
    fun measureReadiness(context: Context): CloudGamingReport {
        val netType = networkTypeName(context)
        val rtt = loopbackRttMs()
        // Model network latency added on top of loopback RTT by connection class
        val networkLatency = when (netType) {
            "Wi-Fi" -> rtt + 8.0
            "Cellular" -> rtt + 35.0
            else -> rtt + 20.0
        }
        val jitter = max(2.0, networkLatency * 0.25)
        val decodeLatency = 14.0 // H.264/AV1 decode ~14ms on modern phone
        val touchLatency = 18.0 // touch pipeline ~18ms
        val total = networkLatency + jitter + decodeLatency + touchLatency

        val components = listOf(
            LatencyComponent("Network", networkLatency),
            LatencyComponent("Jitter", jitter),
            LatencyComponent("Video decode", decodeLatency),
            LatencyComponent("Touch input", touchLatency),
        )

        val ready = total <= 40.0
        val score = when {
            total <= 35.0 -> 940
            total <= 40.0 -> 820
            total <= 55.0 -> 680
            total <= 75.0 -> 520
            else -> 360
        }

        val verdict = when {
            ready -> "Cloud gaming ready; total latency ~${"%.0f".format(total)}ms (<40ms threshold)."
            total <= 60.0 -> "Marginal cloud gaming; occasional input lag possible."
            else -> "Not cloud gaming ready; total latency too high for responsive play."
        }

        return CloudGamingReport(
            networkType = netType,
            networkLatencyMs = (networkLatency * 100.0).roundToInt() / 100.0,
            jitterMs = (jitter * 100.0).roundToInt() / 100.0,
            decodeLatencyMs = decodeLatency,
            touchLatencyMs = touchLatency,
            totalLatencyMs = (total * 100.0).roundToInt() / 100.0,
            components = components,
            readyForCloudGaming = ready,
            readinessScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real game-streaming session; readiness modeled from network interface and loopback RTT rather than streamed-frame measurements.",
        )
    }
}
