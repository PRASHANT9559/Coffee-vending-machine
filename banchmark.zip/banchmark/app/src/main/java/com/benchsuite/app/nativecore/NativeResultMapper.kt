package com.benchsuite.app.nativecore

import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.data.model.BenchIcon
import com.benchsuite.app.data.model.CategoryScore
import com.benchsuite.app.data.model.RunConditions
import com.benchsuite.app.data.model.RunRecord
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Turns native component payloads into the domain [RunRecord] the existing
 * result screens already understand. Scores are clamped to the app's 1,100
 * ceiling; nothing here invents measurements that were not run.
 */
object NativeResultMapper {

    fun buildRecord(
        startedAtMillis: Long,
        elapsedMs: Long,
        results: List<NativeComponentResult>,
        overall: NativeOverallScore?,
        conditions: RunConditions,
        fallbackSoc: String,
    ): RunRecord {
        val valid = results.filter { it.score > 0.0 }
        val categories = valid.map(::toCategory)

        val averaged = valid.map { it.score }.average().takeIf { !it.isNaN() } ?: 0.0
        val overallScore = (overall?.score?.takeIf { it > 0.0 } ?: averaged)
            .roundToInt()
            .coerceIn(0, 1100)

        val peak = categories.maxOfOrNull { it.peak }?.coerceAtMost(1100) ?: overallScore
        val sustained = categories.firstOrNull { it.id == "thermal" }?.score ?: overallScore

        val confidence = overall?.confidence?.times(100)?.roundToInt()
            ?: ((valid.map { it.confidence }.average().takeIf { !it.isNaN() } ?: 0.0) * 100).roundToInt()
        val cv = valid.map { it.cv }.average().takeIf { !it.isNaN() } ?: 0.0

        val date = SimpleDateFormat("d MMM yyyy · HH:mm", Locale.US)
            .format(Date(startedAtMillis))

        return RunRecord(
            id = "run_native_$startedAtMillis",
            startedAt = date,
            durationLabel = formatDuration(elapsedMs),
            deviceModel = DeviceTelemetryReader.deviceModel(),
            soc = DeviceTelemetryReader.socModel(fallbackSoc),
            overall = overallScore,
            peak = peak,
            sustained = sustained.coerceAtMost(1100),
            confidence = confidence.coerceIn(0, 100),
            cvPct = (cv * 1000).roundToInt() / 10.0,
            categories = categories,
            conditions = conditions,
            methodologyVersion = "2.4.1-native",
            verified = false,
            note = "Native bench-core · ${valid.size} component${if (valid.size == 1) "" else "s"} measured on-device",
        )
    }

    private fun toCategory(component: NativeComponentResult): CategoryScore {
        val mappedId = if (component.component == "sustained") "thermal" else component.component
        val spec = TestCatalog.categorySpecs.firstOrNull { it.id == mappedId }
        val score = component.score.roundToInt().coerceIn(1, 1100)
        // No fabricated peak multiplier: peak equals the measured score because no
        // per-sample peak data is available at this mapping layer.
        val peak = score

        return CategoryScore(
            id = mappedId,
            name = spec?.shortTitle ?: mappedId.replaceFirstChar { it.uppercase() },
            score = score,
            peak = peak,
            sustained = score,
            deltaPct = 0.0,
            icon = spec?.icon ?: BenchIcon.SPEED,
            summary = summaryFor(component.component, score),
            testCount = component.metrics.size,
        )
    }

    private fun summaryFor(component: String, score: Int): String {
        val band = when {
            score >= 1_000 -> "excellent"
            score >= 850 -> "strong"
            score >= 600 -> "fair"
            else -> "limited"
        }
        return when (component) {
            "sustained" -> "Sustained throughput is $band after the load soak."
            "gpu" -> "GLES offscreen throughput is $band for this device class."
            "ai" -> "Int8 AI proxy throughput is $band on the CPU path."
            "memory" -> "Memory bandwidth and latency are $band against the reference."
            "storage" -> "Storage throughput is $band; page-cache effects are noted."
            else -> "Native CPU throughput is $band against the reference device."
        }
    }

    private fun formatDuration(milliseconds: Long): String {
        val totalSeconds = (milliseconds / 1000).coerceAtLeast(0)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return if (minutes > 0) "$minutes min ${seconds.toString().padStart(2, '0')} s" else "$seconds s"
    }
}
