package com.benchsuite.app.features.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.benchsuite.app.ui.state.SessionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Battery domain deep-dive.
 *
 * Sub-features: per_app, wireless, reverse_wireless, wired, idle_drain.
 */
@Composable
fun BatteryDetailScreen(
    subFeature: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<DomainDetailResult?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        val ctx = SessionState.applicationContext
        if (ctx == null) {
            error = "Application context unavailable"
            return
        }
        isLoading = true
        error = null
        scope.launch(Dispatchers.Default) {
            runCatching { measure(subFeature, ctx) }
                .onSuccess { result = it }
                .onFailure { error = it.message ?: "Battery feature failed" }
            isLoading = false
        }
    }

    LaunchedEffect(subFeature) { load() }

    DomainDetailScaffold(
        title = titleFor(subFeature),
        subtitle = "Battery · measured on this device",
        result = result,
        isLoading = isLoading,
        error = error,
        onRetry = { load() },
        onBack = onBack,
        onNavigate = onNavigate,
    )
}

private fun titleFor(subFeature: String): String = when (subFeature) {
    "per_app" -> "Per-app power attribution"
    "wireless" -> "Wireless charging efficiency"
    "reverse_wireless" -> "Reverse wireless charging"
    "wired" -> "Wired charging curve & thermals"
    "idle_drain" -> "Idle drain & deep sleep"
    else -> "Battery feature"
}

private fun measure(subFeature: String, ctx: android.content.Context): DomainDetailResult =
    when (subFeature) {
        "per_app" -> {
            val r = SessionState.runBatteryPerApp(ctx)
            DomainDetailResult(
                score = r.attributionScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Total power", fmt(r.totalPowerMw, 0), "mW"),
                    DetailMetric("Battery", "${r.estimatedBatteryMah}", "mAh"),
                    DetailMetric("Dominant", r.dominantConsumer.label),
                    DetailMetric("Subsystems", r.subsystemPowers.size.toString()),
                ),
                radar = listOf(
                    r.attributionScore / 10f,
                    (r.subsystemPowers.maxOfOrNull { it.sharePct }?.toFloat() ?: 0f).coerceIn(0f, 100f),
                    (100f - r.totalPowerMw.toFloat() / 100f).coerceIn(0f, 100f),
                    (r.subsystemPowers.size * 16f).coerceIn(0f, 100f),
                    if (r.subsystemPowers.any { it.subsystem.name == "OTHER" && it.sharePct > 30 }) 40f else 90f,
                ),
                radarLabels = listOf("Score", "Top share", "Efficiency", "Coverage", "Attribution"),
                radarMax = 100f,
                radarTitle = "Subsystem power split",
                radarCaption = "Which block dominates the power budget",
                chartTitle = "Power by subsystem",
                chartCaption = "Average milliwatts attributed to each block",
                chartSeries = r.subsystemPowers.map { it.averagePowerMw.toFloat() },
                chartUnit = "mW",
                distributionTitle = "Share of total",
                distributionCaption = "Relative energy share per subsystem",
                distribution = r.subsystemPowers.map { it.sharePct.toInt().coerceIn(0, 500) },
                distributionFooter = r.subsystemPowers.map {
                    it.subsystem.label to "${fmt(it.sharePct)} % · ${fmt(it.energyMah, 1)} mAh"
                },
            )
        }

        "wireless" -> {
            val r = SessionState.runBatteryWireless(ctx)
            DomainDetailResult(
                score = r.wirelessScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Type", r.chargeType.name),
                    DetailMetric("Charging", if (r.isWirelessCharging) "Yes" else "No"),
                    DetailMetric("Power", fmt(r.currentPowerMw, 0), "mW"),
                    DetailMetric("Efficiency", fmt(r.efficiencyPct), "%"),
                ),
                radar = listOf(
                    r.wirelessScore / 10f,
                    r.efficiencyPct.toFloat().coerceIn(0f, 100f),
                    (r.currentPowerMw.toFloat() / 100f).coerceIn(0f, 100f),
                    if (r.isWirelessCharging) 100f else 30f,
                    (r.points.size * 15f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Efficiency", "Power", "Active", "Samples"),
                radarMax = 100f,
                radarTitle = "Wireless charging quality",
                radarCaption = "Efficiency, delivered power and thermal behaviour",
                chartTitle = "Power received over time",
                chartCaption = "Samples recorded during the wireless session",
                chartSeries = r.points.map { it.powerReceivedMw.toFloat() },
                chartUnit = "mW",
                distributionTitle = "Efficiency per sample",
                distributionCaption = "Efficiency percentage for each sample window",
                distribution = r.points.map { it.efficiencyPct.toInt().coerceIn(0, 500) },
                distributionFooter = r.points.takeLast(4).map {
                    "Min ${it.elapsedMin}" to "${fmt(it.efficiencyPct)} % · ${fmt(it.tempCelsius)} °C"
                },
            )
        }

        "reverse_wireless" -> {
            val r = SessionState.runBatteryReverseWireless(ctx)
            DomainDetailResult(
                score = r.reverseScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Supported", if (r.supported) "Yes" else "No"),
                    DetailMetric("Active", if (r.isActive) "Yes" else "No"),
                    DetailMetric("Output", fmt(r.currentOutputMw, 0), "mW"),
                    DetailMetric("Energy", fmt(r.estimatedWattHours, 2), "Wh"),
                    DetailMetric("Thermal impact", fmt(r.thermalImpactCelsius), "°C"),
                ),
                radar = listOf(
                    r.reverseScore / 10f,
                    (r.currentOutputMw.toFloat() / 100f).coerceIn(0f, 100f),
                    (100f - r.thermalImpactCelsius.toFloat() * 10f).coerceIn(0f, 100f),
                    if (r.supported) 100f else 20f,
                    if (r.isActive) 100f else 40f,
                ),
                radarLabels = listOf("Score", "Output", "Thermals", "Support", "Active"),
                radarMax = 100f,
                radarTitle = "Reverse charging profile",
                radarCaption = "Output power against heat generated on the host",
                chartTitle = "Output over time",
                chartCaption = "Milliwatts delivered to the guest device",
                chartSeries = r.samples.map { it.outputMw.toFloat() },
                chartUnit = "mW",
                distributionTitle = "Host temperature",
                distributionCaption = "Host temperature buckets during the stress test",
                distribution = r.samples.map { (it.hostTempCelsius * 10).toInt().coerceIn(0, 600) },
                distributionFooter = r.samples.takeLast(4).map {
                    "Min ${it.elapsedMin}" to "${fmt(it.hostTempCelsius)} °C · −${fmt(it.batteryDropMah, 0)} mAh"
                },
            )
        }

        "wired" -> {
            val r = SessionState.runBatteryWired(ctx)
            DomainDetailResult(
                score = r.chargingScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Charging", if (r.isCharging) "Yes" else "No"),
                    DetailMetric("Battery", "${r.currentPercent}%"),
                    DetailMetric("Power", fmt(r.currentPowerMw, 0), "mW"),
                    DetailMetric("Temp", fmt(r.currentTempCelsius), "°C"),
                    DetailMetric("0→50", fmt(r.zeroToFiftyMin, 0), "min"),
                    DetailMetric("50→100", fmt(r.fiftyToHundredMin, 0), "min"),
                ),
                radar = listOf(
                    r.chargingScore / 10f,
                    (r.currentPowerMw.toFloat() / 200f).coerceIn(0f, 100f),
                    (100f - r.currentTempCelsius.toFloat()).coerceIn(0f, 100f),
                    if (r.thermalThrottlingDetected) 40f else 100f,
                    (r.chargingCurve.size * 10f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Power", "Thermals", "Sustained", "Samples"),
                radarMax = 100f,
                radarTitle = "Charging behaviour",
                radarCaption = "Power delivery, thermal headroom and throttling",
                chartTitle = "Charging power curve",
                chartCaption = "Delivered power as the battery fills",
                chartSeries = r.chargingCurve.map { it.powerMw.toFloat() },
                chartUnit = "mW",
                distributionTitle = "Time per charge stage",
                distributionCaption = "Estimated minutes to full at each sampled percent",
                distribution = r.chargingCurve.map { it.estMinutesToFull.toInt().coerceIn(0, 600) },
                distributionFooter = r.chargingCurve.takeLast(4).map {
                    "${it.percent}%" to "${fmt(it.tempCelsius)} °C"
                },
            )
        }

        "idle_drain" -> {
            val r = SessionState.runBatteryIdleDrain(ctx)
            DomainDetailResult(
                score = r.idleScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Battery", "${r.batteryPercent}%"),
                    DetailMetric("Drain", fmt(r.idleDrainMahPerHour, 2), "mAh/h"),
                    DetailMetric("Current", fmt(r.currentUa.toDouble() / 1000.0, 2), "mA"),
                    DetailMetric("CPU idle", fmt(r.cpuIdleResidencyPct), "%"),
                    DetailMetric("Deep sleep", if (r.deepSleepSupported) "Yes" else "No"),
                    DetailMetric("Top wakelock", r.topWakelock ?: "None"),
                ),
                radar = listOf(
                    r.idleScore / 10f,
                    (100f - r.idleDrainMahPerHour.toFloat() * 5f).coerceIn(0f, 100f),
                    r.cpuIdleResidencyPct.toFloat().coerceIn(0f, 100f),
                    if (r.deepSleepSupported) 100f else 35f,
                    (100f - r.wakelocks.size.toFloat() * 10f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Drain", "CPU idle", "Deep sleep", "Wakelocks"),
                radarMax = 100f,
                radarTitle = "Idle efficiency",
                radarCaption = "How well the device sleeps when it is not in use",
                chartTitle = "Idle drain profile",
                chartCaption = "Drain rate against CPU idle residency and wakelock pressure",
                chartSeries = listOf(
                    r.idleDrainMahPerHour.toFloat(),
                    r.cpuIdleResidencyPct.toFloat() / 10f,
                    r.wakelocks.size.toFloat(),
                ),
                chartUnit = "mAh/h",
                distributionTitle = "Wakelock weight",
                distributionCaption = "Relative time held by each wakelock",
                distribution = r.wakelocks.take(8).map {
                    (it.holdTimeMs / 60_000).toInt().coerceIn(0, 600)
                },
                distributionFooter = r.wakelocks.take(4).map {
                    it.name to "${it.holdTimeMs / 60_000} min"
                },
            )
        }

        else -> DomainDetailResult(score = 0, verdict = "Unknown battery sub-feature: $subFeature")
    }
