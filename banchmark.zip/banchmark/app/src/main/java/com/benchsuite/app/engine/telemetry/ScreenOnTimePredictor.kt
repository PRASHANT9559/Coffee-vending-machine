package com.benchsuite.app.engine.telemetry

import kotlin.math.roundToInt

/**
 * Feature 9.6: Screen-On-Time (SOT) Predictor.
 *
 * Models and projects real-world battery endurance across four distinct user scenarios:
 * 1. 3D Gaming (High GPU/CPU saturation, 120Hz refresh, haptics)
 * 2. Video Streaming (Hardware AV1/HEVC decoding, 60Hz display, audio DSP)
 * 3. Web & Social Browsing (Burst CPU, Wi-Fi/5G data transfer, adaptive LTPO scrolling)
 * 4. Static Reading / Idle (Minimum screen brightness, low SoC clocks)
 *
 * Extrapolates measured active power consumption (mW) against effective pack capacity (mWh).
 */
object ScreenOnTimePredictor {

    const val DEFAULT_NOMINAL_VOLTAGE_V = 3.88 // Standard for modern high-energy 4.45V peak cells

    data class ScenarioPrediction(
        val scenarioName: String,
        val iconLabel: String,
        val averagePowerMw: Double,
        val projectedMinutes: Int,
        val formattedDuration: String,
        val scenarioDescription: String,
    )

    data class ScreenOnTimeReport(
        val batteryCapacityMah: Int,
        val nominalVoltageV: Double,
        val totalEnergyMwh: Double,
        val usableEnergyMwh: Double,
        val gaming: ScenarioPrediction,
        val videoStreaming: ScenarioPrediction,
        val webBrowsing: ScenarioPrediction,
        val staticIdle: ScenarioPrediction,
        val mixedDaily: ScenarioPrediction,
        val efficiencyVerdict: String,
        val optimizationTips: List<String>,
    )

    /**
     * Calculates projected screen-on time durations for a given [batteryCapacityMah].
     * [measuredActivePowerMw] can be supplied from real benchmark telemetry to calibrate the profile.
     * [currentBatteryPct] defaults to 100 for a full charge projection, or takes current charge state.
     */
    fun predict(
        batteryCapacityMah: Int = 5000,
        measuredActivePowerMw: Double? = null,
        nominalVoltageV: Double = DEFAULT_NOMINAL_VOLTAGE_V,
        currentBatteryPct: Int = 100,
    ): ScreenOnTimeReport {
        val totalMwh = batteryCapacityMah * nominalVoltageV
        val stateRatio = (currentBatteryPct / 100.0).coerceIn(0.05, 1.0)
        // 96% usable energy down to kernel low-voltage cutoff
        val usableMwh = totalMwh * stateRatio * 0.96

        // Calibrate baseline scenario power draws
        // Scale with measured active power if available
        val powerScale = if (measuredActivePowerMw != null && measuredActivePowerMw > 500.0) {
            (measuredActivePowerMw / 4500.0).coerceIn(0.75, 1.35)
        } else {
            1.00
        }

        val gamingPower = (5200.0 * powerScale).coerceIn(3500.0, 8500.0)
        val videoPower = (1650.0 * powerScale).coerceIn(1100.0, 2600.0)
        val webPower = (2400.0 * powerScale).coerceIn(1600.0, 3800.0)
        val idlePower = (850.0 * powerScale).coerceIn(550.0, 1400.0)

        // Mixed daily workload: 35% Web + 30% Video + 20% Gaming + 15% Idle
        val mixedPower = (webPower * 0.35) + (videoPower * 0.30) + (gamingPower * 0.20) + (idlePower * 0.15)

        val gamingMin = ((usableMwh / gamingPower) * 60.0).roundToInt().coerceAtLeast(1)
        val videoMin = ((usableMwh / videoPower) * 60.0).roundToInt().coerceAtLeast(1)
        val webMin = ((usableMwh / webPower) * 60.0).roundToInt().coerceAtLeast(1)
        val idleMin = ((usableMwh / idlePower) * 60.0).roundToInt().coerceAtLeast(1)
        val mixedMin = ((usableMwh / mixedPower) * 60.0).roundToInt().coerceAtLeast(1)

        val gamingScenario = ScenarioPrediction(
            scenarioName = "Sustained 3D Gaming",
            iconLabel = "GAMING",
            averagePowerMw = (gamingPower * 10.0).roundToInt() / 10.0,
            projectedMinutes = gamingMin,
            formattedDuration = formatMinutes(gamingMin),
            scenarioDescription = "Demanding 3D graphics, Vulkan shaders, 120Hz display, and peak thermal load.",
        )

        val videoScenario = ScenarioPrediction(
            scenarioName = "4K / HDR Video Streaming",
            iconLabel = "VIDEO",
            averagePowerMw = (videoPower * 10.0).roundToInt() / 10.0,
            projectedMinutes = videoMin,
            formattedDuration = formatMinutes(videoMin),
            scenarioDescription = "Hardware-accelerated AV1/HEVC decode, stereo audio, 60Hz display.",
        )

        val webScenario = ScenarioPrediction(
            scenarioName = "Web & Social Browsing",
            iconLabel = "WEB",
            averagePowerMw = (webPower * 10.0).roundToInt() / 10.0,
            projectedMinutes = webMin,
            formattedDuration = formatMinutes(webMin),
            scenarioDescription = "Interactive web page rendering, cellular data transfers, 120Hz touch scrolling.",
        )

        val idleScenario = ScenarioPrediction(
            scenarioName = "Reading & Light Standby",
            iconLabel = "IDLE",
            averagePowerMw = (idlePower * 10.0).roundToInt() / 10.0,
            projectedMinutes = idleMin,
            formattedDuration = formatMinutes(idleMin),
            scenarioDescription = "E-book reader or document viewing at 30% brightness with minimal CPU activity.",
        )

        val mixedScenario = ScenarioPrediction(
            scenarioName = "Mixed Daily Use",
            iconLabel = "MIXED",
            averagePowerMw = (mixedPower * 10.0).roundToInt() / 10.0,
            projectedMinutes = mixedMin,
            formattedDuration = formatMinutes(mixedMin),
            scenarioDescription = "Balanced real-world routine (35% web, 30% video, 20% gaming, 15% standby).",
        )

        val efficiencyVerdict = when {
            mixedMin >= 600 -> "Flagship All-Day Endurance (${formatMinutes(mixedMin)} projected mixed SOT). Highly power-efficient platform."
            mixedMin >= 480 -> "Strong Daily Endurance (${formatMinutes(mixedMin)} mixed SOT). Easily lasts a full workday of active usage."
            mixedMin >= 360 -> "Moderate Battery Life (${formatMinutes(mixedMin)} mixed SOT). May require top-up charge during heavy gaming or travel."
            else -> "High Power Consumption (${formatMinutes(mixedMin)} mixed SOT). Power rail draw is elevated under active workloads."
        }

        val tips = mutableListOf<String>()
        if (gamingPower > 5500.0) {
            tips.add("Capping gaming frame rates to 60 FPS in non-competitive games extends gaming endurance by up to 40%.")
        }
        tips.add("Enabling adaptive LTPO display refresh allows the panel to downclock to 10Hz or 1Hz during static reading, saving up to 400 mW.")
        tips.add("Dark mode on AMOLED displays saves approximately 200–350 mW when viewing dark backgrounds.")

        return ScreenOnTimeReport(
            batteryCapacityMah = batteryCapacityMah,
            nominalVoltageV = nominalVoltageV,
            totalEnergyMwh = (totalMwh * 10.0).roundToInt() / 10.0,
            usableEnergyMwh = (usableMwh * 10.0).roundToInt() / 10.0,
            gaming = gamingScenario,
            videoStreaming = videoScenario,
            webBrowsing = webScenario,
            staticIdle = idleScenario,
            mixedDaily = mixedScenario,
            efficiencyVerdict = efficiencyVerdict,
            optimizationTips = tips,
        )
    }

    private fun formatMinutes(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}
