package com.benchsuite.app.util

import java.io.File

/**
 * Shared collection and file extensions used across benchmark engines.
 *
 * These were previously duplicated as private copies in many engine files (or missing entirely),
 * causing ~25 files to fail compilation. This is the single shared source of truth.
 */
fun <T> List<T>.averageOf(selector: (T) -> Double): Double {
    if (isEmpty()) return 0.0
    var sum = 0.0
    for (item in this) sum += selector(item)
    return sum / size
}

fun List<Double>.averageOrNull(): Double? {
    if (isEmpty()) return null
    var sum = 0.0
    for (item in this) sum += item
    return sum / size
}

fun <T> List<T>.firstOrNotNull(fallback: T): T = firstOrNull() ?: fallback

fun File.readTextOrNull(): String? = try {
    if (exists()) readText() else null
} catch (_: Exception) {
    null
}
