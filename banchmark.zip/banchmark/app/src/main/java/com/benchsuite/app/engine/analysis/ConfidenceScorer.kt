package com.benchsuite.app.engine.analysis

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Feature 17.4: Reproducibility Confidence Scorer.
 *
 * Implements rigorous statistical rigor for benchmark iterations:
 * - Mean (μ) and Sample Standard Deviation (σ)
 * - Coefficient of Variation (CoV = σ / μ * 100%)
 * - 95% Confidence Interval via Student's t-distribution
 * - Reproducibility Grades (Grade A, B, C, D)
 * - Outlier trimming (IQR filter)
 */
object ConfidenceScorer {

    enum class ReproducibilityGrade(
        val letter: String,
        val label: String,
        val maxCvPct: Double,
        val description: String,
    ) {
        GRADE_A(
            letter = "A",
            label = "Lab-Grade Reproducibility",
            maxCvPct = 2.0,
            description = "Ultra-low variance (<2.0% CoV). Benchmark is deterministic and free from thermal/background perturbation.",
        ),
        GRADE_B(
            letter = "B",
            label = "Reliable Benchmark Run",
            maxCvPct = 5.0,
            description = "Normal operational variance (2.0%–5.0% CoV). Valid for comparative ranking and reporting.",
        ),
        GRADE_C(
            letter = "C",
            label = "Elevated System Noise",
            maxCvPct = 10.0,
            description = "Moderate variance (5.0%–10.0% CoV). Fluctuations observed due to background processes or thermal stepping.",
        ),
        GRADE_D(
            letter = "D",
            label = "Unreliable / Inconclusive",
            maxCvPct = Double.MAX_VALUE,
            description = "High variance (>10.0% CoV). Score is compromised by active throttling, power capping, or system interference.",
        ),
    }

    data class StatisticalSummary(
        val count: Int,
        val mean: Double,
        val standardDeviation: Double,
        val cvPct: Double,
        val standardError: Double,
        val marginOfError95: Double,
        val ciLower95: Double,
        val ciUpper95: Double,
        val confidenceScore: Int, // 0 - 100 integer
        val grade: ReproducibilityGrade,
        val outliersDetected: Int,
        val trimmedMean: Double,
        val isVerifiedReady: Boolean,
        val diagnosticAdvice: String,
    )

    /**
     * Calculates the statistical distribution, CoV, and confidence grade from a series of [samples].
     */
    fun score(samples: List<Double>): StatisticalSummary {
        if (samples.isEmpty()) {
            return StatisticalSummary(
                count = 0,
                mean = 0.0,
                standardDeviation = 0.0,
                cvPct = 0.0,
                standardError = 0.0,
                marginOfError95 = 0.0,
                ciLower95 = 0.0,
                ciUpper95 = 0.0,
                confidenceScore = 0,
                grade = ReproducibilityGrade.GRADE_D,
                outliersDetected = 0,
                trimmedMean = 0.0,
                isVerifiedReady = false,
                diagnosticAdvice = "No samples provided for statistical evaluation.",
            )
        }

        if (samples.size == 1) {
            val single = samples.first()
            return StatisticalSummary(
                count = 1,
                mean = single,
                standardDeviation = 0.0,
                cvPct = 0.0,
                standardError = 0.0,
                marginOfError95 = 0.0,
                ciLower95 = single,
                ciUpper95 = single,
                confidenceScore = 70, // Baseline single-iteration confidence
                grade = ReproducibilityGrade.GRADE_B,
                outliersDetected = 0,
                trimmedMean = single,
                isVerifiedReady = false,
                diagnosticAdvice = "Single iteration benchmark. Multi-trial execution recommended for verified leaderboard admission.",
            )
        }

        // Outlier detection via IQR
        val sorted = samples.sorted()
        val n = sorted.size
        val q1 = percentile(sorted, 25.0)
        val q3 = percentile(sorted, 75.0)
        val iqr = q3 - q1
        val lowerBound = q1 - 1.5 * iqr
        val upperBound = q3 + 1.5 * iqr
        val validSamples = sorted.filter { it in lowerBound..upperBound }
        val outlierCount = n - validSamples.size

        // Calculate statistics on the dataset
        val dataset = if (validSamples.size >= 3) validSamples else sorted
        val count = dataset.size
        val mean = dataset.average()
        val variance = dataset.map { (it - mean).pow(2) }.sum() / (count - 1).coerceAtLeast(1)
        val stdDev = sqrt(variance)

        val cvPct = if (mean > 0.0) {
            ((stdDev / mean) * 1000.0).roundToInt() / 10.0
        } else {
            0.0
        }

        val standardError = stdDev / sqrt(count.toDouble())
        val tCrit = studentTCritical95(count - 1)
        val moe = tCrit * standardError
        val ciLower = max(0.0, mean - moe)
        val ciUpper = mean + moe

        val grade = when {
            cvPct <= ReproducibilityGrade.GRADE_A.maxCvPct -> ReproducibilityGrade.GRADE_A
            cvPct <= ReproducibilityGrade.GRADE_B.maxCvPct -> ReproducibilityGrade.GRADE_B
            cvPct <= ReproducibilityGrade.GRADE_C.maxCvPct -> ReproducibilityGrade.GRADE_C
            else -> ReproducibilityGrade.GRADE_D
        }

        // Map CoV directly to 0-100 confidence integer
        val rawScore = 100.0 - (cvPct * 3.5) - (outlierCount * 4.0)
        val confidenceScore = rawScore.roundToInt().coerceIn(10, 100)

        val advice = when (grade) {
            ReproducibilityGrade.GRADE_A -> "Laboratory precision achieved. Results have high repeatability and minimal thermal jitter."
            ReproducibilityGrade.GRADE_B -> "Reliable measurement. Variance is well within standard testing tolerances."
            ReproducibilityGrade.GRADE_C -> "Moderate variance detected. Ensure background downloads and cloud backups are paused before retesting."
            ReproducibilityGrade.GRADE_D -> "Severe test instability. Allow device to cool down completely to avoid thermal throttling oscillations."
        }

        return StatisticalSummary(
            count = samples.size,
            mean = (mean * 10.0).roundToInt() / 10.0,
            standardDeviation = (stdDev * 100.0).roundToInt() / 100.0,
            cvPct = cvPct,
            standardError = (standardError * 100.0).roundToInt() / 100.0,
            marginOfError95 = (moe * 10.0).roundToInt() / 10.0,
            ciLower95 = (ciLower * 10.0).roundToInt() / 10.0,
            ciUpper95 = (ciUpper * 10.0).roundToInt() / 10.0,
            confidenceScore = confidenceScore,
            grade = grade,
            outliersDetected = outlierCount,
            trimmedMean = (dataset.average() * 10.0).roundToInt() / 10.0,
            isVerifiedReady = grade in listOf(ReproducibilityGrade.GRADE_A, ReproducibilityGrade.GRADE_B) && samples.size >= 3,
            diagnosticAdvice = advice,
        )
    }

    /**
     * Approximates Student's t critical value for a two-tailed 95% confidence interval
     * given degrees of freedom [df].
     */
    private fun studentTCritical95(df: Int): Double = when (df) {
        1 -> 12.706
        2 -> 4.303
        3 -> 3.182
        4 -> 2.776
        5 -> 2.571
        6 -> 2.447
        7 -> 2.365
        8 -> 2.306
        9 -> 2.262
        10 -> 2.228
        in 11..15 -> 2.145
        in 16..20 -> 2.086
        in 21..30 -> 2.042
        in 31..60 -> 2.000
        else -> 1.960
    }

    private fun percentile(sorted: List<Double>, p: Double): Double {
        if (sorted.isEmpty()) return 0.0
        val pos = (p / 100.0) * (sorted.size - 1)
        val lower = pos.toInt()
        val fraction = pos - lower
        return if (lower + 1 < sorted.size) {
            sorted[lower] + fraction * (sorted[lower + 1] - sorted[lower])
        } else {
            sorted[lower]
        }
    }
}
