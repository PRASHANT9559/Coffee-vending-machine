package com.benchsuite.app.navigation

/** String routes keep deep links readable and the graph easy to test. */
object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val PERMISSIONS = "permissions"
    const val HARDWARE = "hardware"

    const val DASHBOARD = "dashboard"
    const val BENCHMARKS = "benchmarks"
    const val HISTORY = "history"
    const val REPORTS = "reports"
    const val PROFILE = "profile"
    const val MORE = "more"

    const val CATEGORY = "category/{categoryId}"
    const val PRE_TEST = "pretest/{categoryId}"
    const val LIVE_RUN = "live"
    const val RESULT_SUMMARY = "result/summary/{runId}"
    const val RESULT_DETAIL = "result/detail/{runId}"
    const val INSIGHTS = "insights"
    const val RECOMMENDATIONS = "recommendations"
    const val COMPARE = "compare"
    const val REPORT_PREVIEW = "report/{reportId}"
    const val LEADERBOARD = "leaderboard"
    const val DEVICE_INFO = "device-info"
    const val CUSTOM_BUILDER = "custom-builder"
    const val SCHEDULER = "scheduler"
    const val SETTINGS = "settings"
    const val PRIVACY = "privacy"
    const val ABOUT = "about"
    const val HELP = "help"
    const val RUN_FAILED = "run-failed"
    const val SHARE = "share"

    /* ------------------------------------------------------------------ */
    /*  Engine feature routes (Phase 2/3/4 — wired to SessionState)       */
    /*  Organised by domain, not by phase number (real-life naming).      */
    /* ------------------------------------------------------------------ */

    // CPU
    const val ENGINE_CPU_SCHEDULER = "engine/cpu/scheduler-efficiency"
    const val ENGINE_CPU_MEMORY_BANDWIDTH = "engine/cpu/memory-bandwidth"
    const val ENGINE_CPU_BRANCH_PREDICTION = "engine/cpu/branch-prediction"
    const val ENGINE_CPU_CORE_TO_CORE = "engine/cpu/core-to-core-latency"
    const val ENGINE_CPU_CACHE_HIERARCHY = "engine/cpu/cache-hierarchy-latency"
    const val ENGINE_CPU_SIMD_NEON = "engine/cpu/simd-neon-sve2"

    // GPU
    const val ENGINE_GPU_VRS = "engine/gpu/vrs-efficiency"
    const val ENGINE_GPU_SHADER_STUTTER = "engine/gpu/shader-compilation-stutter"
    const val ENGINE_GPU_FREQUENCY = "engine/gpu/frequency-residency"
    const val ENGINE_GPU_MEMORY_COMPRESSION = "engine/gpu/memory-compression"
    const val ENGINE_GPU_FILLRATE = "engine/gpu/fillrate-bandwidth"

    // AI
    const val ENGINE_AI_LLM_CONTEXT = "engine/ai/llm-context-window"
    const val ENGINE_AI_MULTI_MODAL = "engine/ai/multi-modal-pipeline"
    const val ENGINE_AI_PARETO = "engine/ai/accuracy-pareto-frontier"
    const val ENGINE_AI_STABLE_DIFFUSION = "engine/ai/stable-diffusion-consistency"
    const val ENGINE_AI_NPU_THERMAL = "engine/ai/npu-thermal-throttling"
    const val ENGINE_AI_MODEL_LOAD = "engine/ai/model-load-time"
    const val ENGINE_AI_SPECULATIVE = "engine/ai/speculative-decoding"
    const val ENGINE_AI_FEDERATED = "engine/ai/federated-learning"
    const val ENGINE_AI_NPU_FALLBACK = "engine/ai/npu-fallback-detector"
    const val ENGINE_AI_ON_DEVICE_RAG = "engine/ai/on-device-rag"
    const val ENGINE_AI_SPEECH_RTF = "engine/ai/speech-rtf"
    const val ENGINE_AI_ENERGY_TOKEN = "engine/ai/energy-per-token"

    // Storage
    const val ENGINE_STORAGE_FRAGMENTATION = "engine/storage/fragmentation-simulator"
    const val ENGINE_STORAGE_AI_WORKLOAD = "engine/storage/ai-workload-pattern"
    const val ENGINE_STORAGE_ZRAM = "engine/storage/zram-swap"
    const val ENGINE_STORAGE_UFS_THERMAL = "engine/storage/ufs-thermal-throttling"
    const val ENGINE_STORAGE_ENDURANCE = "engine/storage/endurance-wear"
    const val ENGINE_STORAGE_APP_INSTALL = "engine/storage/app-install-dex"
    const val ENGINE_STORAGE_SMALL_FILE = "engine/storage/small-file-metadata"

    // Network
    const val ENGINE_NETWORK_WIFI7_MLO = "engine/network/wifi-7-mlo"
    const val ENGINE_NETWORK_URLLC = "engine/network/5g-urllc"
    const val ENGINE_NETWORK_SATELLITE_SOS = "engine/network/satellite-sos"
    const val ENGINE_NETWORK_UWB = "engine/network/uwb-precision"
    const val ENGINE_NETWORK_ESIM = "engine/network/esim-switching"
    const val ENGINE_NETWORK_LE_AUDIO = "engine/network/le-audio-latency"
    const val ENGINE_NETWORK_HANDOVER = "engine/network/handover-latency"
    const val ENGINE_NETWORK_BUFFERBLOAT = "engine/network/bufferbloat"
    const val ENGINE_NETWORK_MODEM_THERMAL = "engine/network/modem-thermal"
    const val ENGINE_NETWORK_WIFI_ROAMING = "engine/network/wifi-roaming"

    // Battery
    const val ENGINE_BATTERY_PER_APP = "engine/battery/per-app-power"
    const val ENGINE_BATTERY_WIRELESS = "engine/battery/wireless-charging"
    const val ENGINE_BATTERY_REVERSE_WIRELESS = "engine/battery/reverse-wireless"
    const val ENGINE_BATTERY_WIRED = "engine/battery/wired-charging"
    const val ENGINE_BATTERY_IDLE_DRAIN = "engine/battery/idle-drain"

    // Display
    const val ENGINE_DISPLAY_VRR = "engine/display/vrr-transition"
    const val ENGINE_DISPLAY_STYLUS = "engine/display/stylus-latency"
    const val ENGINE_DISPLAY_LUMINANCE = "engine/display/peak-sustained-luminance"
    const val ENGINE_DISPLAY_PALM = "engine/display/palm-rejection"

    // Audio
    const val ENGINE_AUDIO_TAP_TONE = "engine/audio/tap-to-tone"
    const val ENGINE_AUDIO_HAPTIC = "engine/audio/haptic-frequency"
    const val ENGINE_AUDIO_SPEAKER = "engine/audio/speaker-response"
    const val ENGINE_AUDIO_MICROPHONE = "engine/audio/microphone-noise"

    // Camera
    const val ENGINE_CAMERA_NIGHT_MODE = "engine/camera/night-mode"
    const val ENGINE_CAMERA_VIDEO_STAB = "engine/camera/video-stabilization"
    const val ENGINE_CAMERA_RAW = "engine/camera/raw-processing"
    const val ENGINE_CAMERA_AUTOFOCUS = "engine/camera/autofocus"

    // Sensors
    const val ENGINE_SENSOR_MEMS = "engine/sensors/mems-calibration"
    const val ENGINE_SENSOR_GNSS = "engine/sensors/gnss-ttff"
    const val ENGINE_SENSOR_BAROMETRIC = "engine/sensors/barometric-altimeter"
    const val ENGINE_SENSOR_MAGNETOMETER = "engine/sensors/magnetometer-interference"
    const val ENGINE_SENSOR_GYRO = "engine/sensors/gyroscope-drift"
    const val ENGINE_SENSOR_DUAL_GNSS = "engine/sensors/dual-frequency-gnss"

    // Gaming
    const val ENGINE_GAMING_PREDICTED_FPS = "engine/gaming/predicted-fps"
    const val ENGINE_GAMING_EMULATOR = "engine/gaming/emulator-predictor"
    const val ENGINE_GAMING_CLOUD = "engine/gaming/cloud-gaming-readiness"
    const val ENGINE_GAMING_APP_LAUNCH = "engine/gaming/app-launch-consistency"
    const val ENGINE_GAMING_TOUCH_PHOTON = "engine/gaming/touch-to-photon"
    const val ENGINE_GAMING_COLD_WARM = "engine/gaming/cold-warm-launch"

    // Thermal
    const val ENGINE_THERMAL_ACTIVE_COOLING = "engine/thermal/active-cooling"
    const val ENGINE_THERMAL_ZONE_MAP = "engine/thermal/zone-correlation"

    // Security
    const val ENGINE_SECURITY_BIOMETRIC = "engine/security/biometric-unlock"
    const val ENGINE_SECURITY_HSM = "engine/security/hsm-throughput"
    const val ENGINE_SECURITY_SIDE_CHANNEL = "engine/security/side-channel"
    const val ENGINE_SECURITY_INTEGRITY = "engine/security/integrity-root"
    const val ENGINE_SECURITY_FILE_ENC = "engine/security/file-encryption"

    // Longevity
    const val ENGINE_LONGEVITY_OS_UPDATE = "engine/longevity/os-update-regression"
    const val ENGINE_LONGEVITY_DEVICE_HEALTH = "engine/longevity/device-health"

    // Fairplay
    const val ENGINE_FAIRPLAY_SIGNED_RESULT = "engine/fairplay/signed-result"

    // Insights
    const val ENGINE_INSIGHTS_BOTTLENECK = "engine/insights/bottleneck-root-cause"
    const val ENGINE_INSIGHTS_UPGRADE = "engine/insights/upgrade-advisor"
    const val ENGINE_INSIGHTS_PEER = "engine/insights/peer-percentile"
    const val ENGINE_INSIGHTS_FORECAST = "engine/insights/performance-forecast"
    const val ENGINE_INSIGHTS_ANOMALY = "engine/insights/anomaly-alerts"
    const val ENGINE_INSIGHTS_OPTIMIZATION = "engine/insights/optimization-tips"

    // Social
    const val ENGINE_SOCIAL_SOC_FAMILY = "engine/social/soc-family"
    const val ENGINE_SOCIAL_REVIEWER = "engine/social/reviewer-mode"
    const val ENGINE_SOCIAL_COMMUNITY = "engine/social/community-heatmap"

    // Reporting
    const val ENGINE_REPORTING_REVIEWER_TEMPLATE = "engine/reporting/reviewer-template"
    const val ENGINE_REPORTING_SCHEDULED = "engine/reporting/scheduled-health"

    // Enterprise
    const val ENGINE_ENTERPRISE_CUSTOM_BUILDER = "engine/enterprise/custom-builder"
    const val ENGINE_ENTERPRISE_CLI_ADB = "engine/enterprise/cli-adb"

    // UX
    const val ENGINE_UX_LIVE_OVERLAY = "engine/ux/live-overlay"
    const val ENGINE_UX_WIDGETS = "engine/ux/widgets-quick-settings"

    // Foldable
    const val ENGINE_FOLDABLE_HINGE = "engine/foldable/hinge-durability"

    // Wearable
    const val ENGINE_WEARABLE_WEAR_OS = "engine/wearable/wear-os"

    // Native (Rust) — JNI routes
    const val NATIVE_CONTEXT_SWITCH = "native/context-switch"
    const val NATIVE_INTERRUPT_LATENCY = "native/interrupt-latency"
    const val NATIVE_PQC = "native/pqc-benchmark"
    const val NATIVE_RAY_TRACING = "native/ray-tracing"
    const val NATIVE_MESH_SHADER = "native/mesh-shader"
    const val NATIVE_ASYNC_COMPUTE = "native/async-compute"
    const val NATIVE_VULKAN = "native/vulkan-scanner"
    const val NATIVE_MEMORY_PRESSURE = "native/memory-pressure"
    const val NATIVE_RANDOM_IOPS = "native/random-iops"
    const val NATIVE_CACHE = "native/cache-hierarchy"
    const val NATIVE_FAIRPLAY = "native/fairplay-check"

    /* ------------------------------------------------------------------ */
    /*  Detail screen routes — parameterised by sub-feature id            */
    /*  Format: engine/<domain>/detail/{subFeature}                       */
    /* ------------------------------------------------------------------ */

    // CPU detail
    const val DETAIL_CPU = "engine/cpu/detail/{subFeature}"

    // GPU detail
    const val DETAIL_GPU = "engine/gpu/detail/{subFeature}"

    // AI detail
    const val DETAIL_AI = "engine/ai/detail/{subFeature}"

    // Storage detail
    const val DETAIL_STORAGE = "engine/storage/detail/{subFeature}"

    // Network detail
    const val DETAIL_NETWORK = "engine/network/detail/{subFeature}"

    // Battery detail
    const val DETAIL_BATTERY = "engine/battery/detail/{subFeature}"

    // Gaming detail
    const val DETAIL_GAMING = "engine/gaming/detail/{subFeature}"

    // Thermal detail
    const val DETAIL_THERMAL = "engine/thermal/detail/{subFeature}"

    // Security detail
    const val DETAIL_SECURITY = "engine/security/detail/{subFeature}"

    // Longevity detail
    const val DETAIL_LONGEVITY = "engine/longevity/detail/{subFeature}"

    // Fairplay detail
    const val DETAIL_FAIRPLAY = "engine/fairplay/detail/{subFeature}"

    // Insights detail
    const val DETAIL_INSIGHTS = "engine/insights/detail/{subFeature}"

    // Social detail
    const val DETAIL_SOCIAL = "engine/social/detail/{subFeature}"

    // Reporting detail
    const val DETAIL_REPORTING = "engine/reporting/detail/{subFeature}"

    // Enterprise detail
    const val DETAIL_ENTERPRISE = "engine/enterprise/detail/{subFeature}"

    // UX detail
    const val DETAIL_UX = "engine/ux/detail/{subFeature}"

    // Foldable detail
    const val DETAIL_FOLDABLE = "engine/foldable/detail/{subFeature}"

    // Wearable detail
    const val DETAIL_WEARABLE = "engine/wearable/detail/{subFeature}"

    /** Deep-dive screen for one sub-feature of a domain. */
    fun detail(domain: String, subFeature: String) = "engine/$domain/detail/$subFeature"

    /** Generic engine feature screen (feature id matches an ENGINE_* constant). */
    fun engineFeature(domain: String, featureId: String) = "engine/$domain/$featureId"

    fun category(id: String) = "category/$id"
    fun preTest(id: String) = "pretest/$id"
    fun resultSummary(runId: String = "latest") = "result/summary/$runId"
    fun resultDetail(runId: String = "latest") = "result/detail/$runId"
    fun report(id: String) = "report/$id"

    val bottomTabs = listOf(DASHBOARD, BENCHMARKS, HISTORY, REPORTS, PROFILE)
}
