package com.benchsuite.app.engine.analysis

import com.benchsuite.app.data.model.DeviceProfile
import com.benchsuite.app.data.model.RunRecord
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 16.1: Device Aging Index Calculator.
 *
 * Computes a unified 0–100 hardware longevity and retention index by evaluating
 * multi-year degradation across four physical hardware pillars:
 * 1. Battery Electrochemical Wear (cycles, capacity retention, internal impedance)
 * 2. Flash Storage NAND Degradation (random IOPS decay, block wear, capacity headroom)
 * 3. Thermal Dissipation Impedance (thermal conductivity decay, heat pipe / paste degradation)
 * 4. Compute DVFS Throttling (sustained clock retention vs nominal factory maximum)
 */
object AgingIndexCalculator {

    enum class AgingFactor(val displayName: String) {
        BATTERY_WEAR("Battery Electrochemical Aging"),
        STORAGE_DEGRADATION("Flash Storage NAND Wear"),
        THERMAL_DISSIPATION("Thermal Interface / Dissipation Drop"),
        COMPUTE_THROTTLING("SoC Silicon Sustained Throttling"),
        NONE("Nominal Day-1 Condition (Pristine)"),
    }

    data class AgingAssessment(
        val agingIndex: Int, // 0 - 100 where 100 is pristine Day-1 condition
        val wearPercentage: Double, // 100.0 - agingIndex
        val batteryHealthScore: Int, // 0 - 100
        val storageHealthScore: Int, // 0 - 100
        val thermalHealthScore: Int, // 0 - 100
        val computeRetentionScore: Int, // 0 - 100
        val primaryDegradationFactor: AgingFactor,
        val estimatedAgeMonths: Int,
        val longevityVerdict: String,
        val actionableAdvice: List<String>,
    )

    data class AgingInput(
        val batteryCycles: Int = 0,
        val batteryHealthPct: Int = 100,
        val storageFreeGb: Double = 64.0,
        val storageTotalGb: Double = 256.0,
        val randomWriteIopsRetainedPct: Double = 100.0,
        val thermalRampDegPerSec: Double = 0.15, // Nominal: ~0.15 °C/s under load
        val sustainedClockRetainedPct: Double = 100.0,
        val deviceAgeMonths: Int = 0,
    )

    /**
     * Computes the unified [AgingAssessment] from structured [AgingInput].
     */
    fun calculate(input: AgingInput): AgingAssessment {
        // 1. Battery Health Score (Weight: 35%)
        // Cycle decay curve: Standard Li-ion retains ~80% at 500-800 cycles; Si-C retains ~80% at 800-1000 cycles.
        val cyclePenalty = (input.batteryCycles / 1000.0 * 25.0).coerceIn(0.0, 30.0)
        val reportedHealth = input.batteryHealthPct.toDouble().coerceIn(40.0, 100.0)
        val batteryScore = (reportedHealth - cyclePenalty * 0.5).roundToInt().coerceIn(0, 100)

        // 2. Storage Health Score (Weight: 25%)
        // Evaluates free space headroom (<10% free severely degrades SLC caching) and retained random write IOPS
        val freePct = if (input.storageTotalGb > 0.0) {
            (input.storageFreeGb / input.storageTotalGb * 100.0).coerceIn(0.0, 100.0)
        } else {
            50.0
        }
        val fullnessPenalty = when {
            freePct < 5.0 -> 35.0
            freePct < 15.0 -> 20.0
            freePct < 25.0 -> 8.0
            else -> 0.0
        }
        val iopsRetention = input.randomWriteIopsRetainedPct.coerceIn(30.0, 100.0)
        val storageScore = (iopsRetention - fullnessPenalty).roundToInt().coerceIn(0, 100)

        // 3. Thermal Health Score (Weight: 25%)
        // Fresh thermal paste + clean vapor chamber heats up smoothly (0.10 - 0.18 °C/s).
        // Dried thermal paste or dust-clogged vents heat up rapidly (>0.30 °C/s).
        val rampOverhead = (input.thermalRampDegPerSec - 0.15).coerceAtLeast(0.0)
        val thermalDeduction = (rampOverhead / 0.20 * 40.0).coerceIn(0.0, 50.0)
        val thermalScore = (100.0 - thermalDeduction).roundToInt().coerceIn(0, 100)

        // 4. Compute Sustained Retention Score (Weight: 15%)
        val computeScore = input.sustainedClockRetainedPct.roundToInt().coerceIn(0, 100)

        // Unified Composite Aging Index (Weighted Average)
        val composite = (batteryScore * 0.35) +
            (storageScore * 0.25) +
            (thermalScore * 0.25) +
            (computeScore * 0.15)
        val agingIndex = composite.roundToInt().coerceIn(0, 100)
        val wearPercentage = ((100.0 - agingIndex) * 10.0).roundToInt() / 10.0

        // Identify primary degradation factor
        val minScore = minOf(batteryScore, storageScore, thermalScore, computeScore)
        val primaryFactor = when {
            agingIndex >= 92 -> AgingFactor.NONE
            minScore == batteryScore -> AgingFactor.BATTERY_WEAR
            minScore == storageScore -> AgingFactor.STORAGE_DEGRADATION
            minScore == thermalScore -> AgingFactor.THERMAL_DISSIPATION
            else -> AgingFactor.COMPUTE_THROTTLING
        }

        // Actionable advice
        val advice = mutableListOf<String>()
        if (batteryScore < 75) {
            advice.add("Battery capacity retention is down to $batteryScore%. Consider an OEM battery replacement to restore original peak boost frequencies.")
        }
        if (freePct < 15.0) {
            advice.add("Storage capacity is ${freePct.roundToInt()}% free. Flash controller TRIM and garbage collection require at least 15% free space to maintain write speed.")
        }
        if (thermalScore < 70) {
            advice.add("Thermal dissipation ramp is elevated (${input.thermalRampDegPerSec}°C/s). Chassis heat sink efficiency has dropped; inspect vents and avoid hot charging environments.")
        }
        if (advice.isEmpty()) {
            advice.add("Device physical components are operating in optimal Day-1 baseline health.")
        }

        val verdict = when {
            agingIndex >= 90 -> "Like New / Pristine condition (90–100 index). Negligible hardware degradation."
            agingIndex >= 78 -> "Good condition (78–89 index). Normal expected wear for active daily usage."
            agingIndex >= 65 -> "Moderate wear (65–77 index). Noticeable battery capacity or storage slowdown."
            else -> "Heavy degradation (<65 index). Hardware replacement or maintenance advised."
        }

        return AgingAssessment(
            agingIndex = agingIndex,
            wearPercentage = wearPercentage,
            batteryHealthScore = batteryScore,
            storageHealthScore = storageScore,
            thermalHealthScore = thermalScore,
            computeRetentionScore = computeScore,
            primaryDegradationFactor = primaryFactor,
            estimatedAgeMonths = input.deviceAgeMonths,
            longevityVerdict = verdict,
            actionableAdvice = advice,
        )
    }

    /**
     * Derives an [AgingAssessment] from a [DeviceProfile] and optional [RunRecord].
     */
    fun evaluate(profile: DeviceProfile, record: RunRecord?): AgingAssessment {
        val peak = record?.peak?.toDouble() ?: 1000.0
        val sustained = record?.sustained?.toDouble() ?: 900.0
        val retention = if (peak > 0) (sustained / peak * 100.0).coerceIn(40.0, 100.0) else 90.0

        val freeStorage = profile.storageFreeGb
        val totalStorageStr = profile.storage.filter { it.isDigit() }
        val totalStorage = totalStorageStr.toDoubleOrNull() ?: 256.0

        val input = AgingInput(
            batteryCycles = profile.batteryCycles,
            batteryHealthPct = profile.batteryHealthPct,
            storageFreeGb = freeStorage,
            storageTotalGb = totalStorage,
            randomWriteIopsRetainedPct = if (freeStorage < 20.0) 78.0 else 94.0,
            thermalRampDegPerSec = if (record != null && record.conditions.batteryTempC > 38.0) 0.26 else 0.16,
            sustainedClockRetainedPct = retention,
            deviceAgeMonths = max(1, (profile.batteryCycles / 25).coerceAtLeast(1)),
        )

        return calculate(input)
    }
}
