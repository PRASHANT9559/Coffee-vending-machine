package com.benchsuite.app.features.data

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CompareArrows
import androidx.compose.material.icons.outlined.EventNote
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChartAxis
import com.benchsuite.app.ui.components.HistoryRunRow
import com.benchsuite.app.ui.components.IconAction
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.SegmentedControl
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.TrendStrip
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

@Composable
fun HistoryScreen(onNavigate: (String) -> Unit) {
    var filter by rememberSaveable { mutableIntStateOf(0) }

    val allRuns: List<RunRecord> = SessionState.allHistoryRuns

    val runs: List<RunRecord> = when (filter) {
        1 -> allRuns.filter {
            !it.note.contains("Low battery") && !it.note.contains("Background load")
        }
        2 -> allRuns.filter {
            it.note.contains("Low battery") || it.note.contains("Background load")
        }
        else -> allRuns
    }

    val best = allRuns.maxOfOrNull { it.overall } ?: 0
    val average = if (allRuns.isNotEmpty()) allRuns.map { it.overall }.average().toInt() else 0
    val trend = if (allRuns.size >= 2) allRuns.first().overall - allRuns.last().overall else 0

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "History",
            subtitle = "${allRuns.size} runs · ${SessionState.currentDevice.model}",
            actions = {
                IconAction(Icons.Outlined.CompareArrows, "Compare runs") { onNavigate(Routes.COMPARE) }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Your record",
                    title = "Ten runs, one story.",
                    body = "Scores drift with heat, battery and background load. These are the conditions that explain each result.",
                )
            }

            if (allRuns.isEmpty()) {
                item {
                    SurfaceCard {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(Icons.Outlined.EventNote, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("No Benchmark Runs Yet", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "No verified runs have been recorded on this device yet. Start your first benchmark to record performance trends.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { onNavigate(Routes.preTest("full")) }) {
                                Text("Start First Benchmark")
                            }
                        }
                    }
                }
            } else {
                item {
                    SurfaceCard {
                        val historyPoints = allRuns.map { com.benchsuite.app.data.model.HistoryPoint(it.date, it.overall, it.id) }
                        TrendStrip(historyPoints)
                        Spacer(Modifier.height(Spacing.sm))
                        LineChart(
                            points = historyPoints.map { it.score.toFloat() },
                            color = MaterialTheme.colorScheme.primary,
                            minY = (best * 0.8f),
                            maxY = (best * 1.1f),
                            height = 130.dp,
                        )
                        ChartAxis(allRuns.last().date, allRuns.first().date)
                        Spacer(Modifier.height(Spacing.sm))
                        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                            HistoryStat("Best", best.toString(), Modifier.weight(1f), BenchTheme.colors.success)
                            HistoryStat("Average", average.toString(), Modifier.weight(1f))
                            HistoryStat("Change", if (trend >= 0) "+$trend" else "$trend", Modifier.weight(1f), if (trend >= 0) BenchTheme.colors.success else BenchTheme.colors.danger)
                        }
                    }
                }
            }

            item {
                SegmentedControl(
                    options = listOf("All runs", "Clean", "Flagged"),
                    selectedIndex = filter,
                    onSelect = { filter = it },
                )
            }

            item {
                SectionHeader(
                    title = if (filter == 0) "All runs" else if (filter == 1) "Clean conditions" else "Flagged conditions",
                    actionLabel = "Compare",
                    onAction = { onNavigate(Routes.COMPARE) },
                )
            }

            items(runs.size) { index ->
                val run = runs[index]
                HistoryRunRow(
                    run = run,
                    onClick = { onNavigate(Routes.resultDetail(run.id)) },
                )
            }

            if (runs.isEmpty()) {
                item {
                    SurfaceCard {
                        Text("No runs match this filter.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Flagged runs carry a recorded condition change such as low battery or high background load.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.EventNote, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Run cadence", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "रन हिस्ट्री आपके पहले बेंचमार्क रन के बाद दिखाई देगी।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = { onNavigate(Routes.preTest("full")) },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Text("Start a new run")
                    }
                    OutlinedButton(
                        onClick = { onNavigate(Routes.COMPARE) },
                        modifier = Modifier.height(50.dp),
                    ) {
                        Text("Compare")
                    }
                }
            }

            item {
                Text(
                    "History is stored locally and survives app updates. Export it any time from Privacy and data.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(top = Spacing.xs),
                )
            }
        }
    }
}

@Composable
private fun HistoryStat(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = NumericSmall.copy(fontSize = 19.sp), color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
