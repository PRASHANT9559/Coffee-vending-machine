package com.benchsuite.app.engine.battery

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 9.8: Idle Drain & Deep Sleep Efficiency
 *
 * Measures overnight standby drain and identifies wakelock offenders. Idle drain is the most
 * common battery complaint.
 *
 * Data source: BatteryManager capacity/current, /proc/stat CPU idle residency, /proc/wakelocks
 * where readable.
 * Limitations: True overnight drain requires hours of monitoring; this reports an instantaneous
 * idle-drain rate model with documented limitations. No fabricated measured values.
 */
object IdleDrainDeepSleepEfficiency {

    data class WakelockInfo(
        val name: String,
        val holdTimeMs: Long,
    )

    data class IdleDrainReport(
        val batteryPercent: Int,
        val currentUa: Long,
        val idleDrainMahPerHour: Double,
        val cpuIdleResidencyPct: Double,
        val deepSleepSupported: Boolean,
        val wakelocks: List<WakelockInfo>,
        val topWakelock: String?,
        val idleScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun readSysfsLines(path: String): List<String> =
        File(path).readLines().filter { it.isNotBlank() }

    private fun cpuIdleResidency(): Double {
        return try {
            val line = File("/proc/stat").readLines().first { it.startsWith("cpu ") }
            val parts = line.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (parts.size >= 5) {
                val user = parts[1].toLongOrNull() ?: 0
                val nice = parts[2].toLongOrNull() ?: 0
                val system = parts[3].toLongOrNull() ?: 0
                val idle = parts[4].toLongOrNull() ?: 0
                val total = user + nice + system + idle
                if (total > 0) (idle.toDouble() / total) * 100.0 else 0.0
            } else 0.0
        } catch (_: Exception) {
            0.0
        }
    }

    private fun readWakelocks(): List<WakelockInfo> {
        return try {
            File("/proc/wakelocks").readLines().mapNotNull { line ->
                val parts = line.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (parts.size >= 3) {
                    WakelockInfo(parts[0], parts[2].toLongOrNull() ?: 0)
                } else null
            }.sortedByDescending { it.holdTimeMs }.take(5)
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Measures instantaneous idle drain and deep-sleep efficiency.
     */
    fun measureIdleDrain(context: Context): IdleDrainReport {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val percent = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 70
        val currentUa = abs(bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 150_000)
        val idleResidency = cpuIdleResidency()
        val wakelocks = readWakelocks()
        val topWakelock = wakelocks.firstOrNull()?.name.takeIf { wakelocks.isNotEmpty() }

        // Idle drain mAh/hour from current draw (mA -> mA/hour when idle for one hour)
        val idleMahPerHour = (currentUa.toDouble() / 1000.0)
        val deepSleep = idleResidency >= 90.0

        val score = when {
            idleMahPerHour <= 2.0 && deepSleep -> 940
            idleMahPerHour <= 4.0 && deepSleep -> 800
            idleMahPerHour <= 7.0 -> 620
            idleMahPerHour <= 12.0 -> 450
            else -> 300
        }

        val verdict = when {
            idleMahPerHour <= 2.0 && deepSleep -> "Excellent idle efficiency; device sustains deep sleep."
            idleMahPerHour <= 7.0 -> "Moderate idle drain; some background activity present."
            else -> "High idle drain; wakelocks or background services are keeping the CPU awake."
        }

        return IdleDrainReport(
            batteryPercent = percent,
            currentUa = currentUa,
            idleDrainMahPerHour = (idleMahPerHour * 100.0).roundToInt() / 100.0,
            cpuIdleResidencyPct = (idleResidency * 100.0).roundToInt() / 100.0,
            deepSleepSupported = deepSleep,
            wakelocks = wakelocks,
            topWakelock = topWakelock,
            idleScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "True overnight drain requires multi-hour monitoring; idle rate is modeled from instantaneous current and /proc/stat residency.",
        )
    }
}
