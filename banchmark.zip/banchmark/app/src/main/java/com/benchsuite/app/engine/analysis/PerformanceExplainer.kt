package com.benchsuite.app.engine.analysis

import com.benchsuite.app.data.model.BenchIcon
import com.benchsuite.app.data.model.Insight
import com.benchsuite.app.data.model.InsightSeverity
import com.benchsuite.app.data.model.RunRecord
import com.benchsuite.app.data.model.ScoreBand
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Feature 18.1: Natural-Language Performance Explainer.
 *
 * Synthesizes multi-dimensional telemetry, subsystem category scores, and environmental
 * conditions from a [RunRecord] into plain-English executive verdicts, root-cause
 * bottleneck identification, and thermal throttling summaries.
 */
object PerformanceExplainer {

    enum class BottleneckType(val displayName: String) {
        THERMAL_THROTTLING("Thermal Dissipation Limit"),
        MEMORY_BANDWIDTH("Memory Bandwidth Saturation"),
        STORAGE_IOPS("Storage Random I/O Latency"),
        GPU_COMPUTE("GPU Compute / Fillrate Cap"),
        CPU_SCHEDULING("CPU Governor / Scheduling Cap"),
        BATTERY_POWER_LIMIT("Battery Power Rail Throttling"),
        NONE("Balanced Architecture (No Severe Bottleneck)"),
    }

    data class BottleneckSummary(
        val type: BottleneckType,
        val severity: InsightSeverity,
        val headline: String,
        val detailedExplanation: String,
        val limitingSubsystem: String,
        val impactedWorkloads: List<String>,
        val mitigationAdvice: String,
    )

    data class ThermalThrottlingSummary(
        val throttlingDetected: Boolean,
        val peakToSustainedDropPct: Double,
        val peakScore: Int,
        val sustainedScore: Int,
        val thermalStatus: String,
        val batteryTempC: Double,
        val plainEnglishVerdict: String,
    )

    data class SubsystemVerdict(
        val categoryId: String,
        val categoryName: String,
        val score: Int,
        val band: ScoreBand,
        val verdictSentence: String,
        val isStrengths: Boolean,
    )

    data class ExplanationResult(
        val headlineVerdict: String,
        val executiveSummary: String,
        val tierClassification: String,
        val primaryBottleneck: BottleneckSummary,
        val thermalSummary: ThermalThrottlingSummary,
        val subsystemVerdicts: List<SubsystemVerdict>,
        val standoutStrengths: List<String>,
        val criticalWeaknesses: List<String>,
        val actionableRecommendations: List<String>,
    )

    /**
     * Synthesizes a comprehensive plain-English performance explanation for [record].
     */
    fun explain(record: RunRecord): ExplanationResult {
        val peak = record.peak.coerceAtLeast(1)
        val sustained = record.sustained.coerceAtLeast(1)
        val dropPct = ((peak - sustained).toDouble() / peak * 100.0).coerceAtLeast(0.0)

        // Classify performance tier
        val tier = when {
            record.overall >= 950 -> "Flagship Ultra Tier"
            record.overall >= 800 -> "High-Performance Premium Tier"
            record.overall >= 650 -> "Upper Mid-Range Tier"
            record.overall >= 500 -> "Mainstream Consumer Tier"
            else -> "Entry-Level / Constrained Tier"
        }

        // Subsystem inspection
        val subsystemVerdicts = record.categories.map { cat ->
            val isStrength = cat.score >= (record.overall * 1.05).toInt()
            val verdict = buildSubsystemSentence(cat.id, cat.score, cat.deltaPct, cat.band)
            SubsystemVerdict(
                categoryId = cat.id,
                categoryName = cat.name,
                score = cat.score,
                band = cat.band,
                verdictSentence = verdict,
                isStrengths = isStrength,
            )
        }

        // Identify primary bottleneck
        val bottleneck = identifyBottleneck(record, dropPct)

        // Thermal throttling summary
        val thermalVerdict = when {
            dropPct >= 25.0 -> "Severe thermal throttling detected. The SoC experienced an aggressive ${dropPct.roundToInt()}% performance decay as temperatures escalated to ${record.conditions.batteryTempC}°C."
            dropPct >= 12.0 -> "Moderate thermal throttling observed. Sustained performance dipped by ${dropPct.roundToInt()}% under prolonged compute saturation."
            dropPct >= 5.0 -> "Mild thermal step-down detected (${dropPct.roundToInt()}% drop). The cooling solution largely maintained stability under standard test loads."
            else -> "Exceptional thermal dissipation. The device maintained 95%+ of its peak output with zero meaningful thermal degradation."
        }

        val thermalSummary = ThermalThrottlingSummary(
            throttlingDetected = dropPct >= 10.0,
            peakToSustainedDropPct = (dropPct * 10.0).roundToInt() / 10.0,
            peakScore = record.peak,
            sustainedScore = record.sustained,
            thermalStatus = record.conditions.thermalStatus,
            batteryTempC = record.conditions.batteryTempC,
            plainEnglishVerdict = thermalVerdict,
        )

        // Standout strengths and weaknesses
        val strengths = mutableListOf<String>()
        val weaknesses = mutableListOf<String>()

        record.categories.forEach { cat ->
            if (cat.score >= 850) {
                strengths.add("${cat.name} (${cat.score} pts): Demonstrates robust execution headroom, ideal for intensive workloads.")
            } else if (cat.score < 550) {
                weaknesses.add("${cat.name} (${cat.score} pts): Falls below expected responsiveness benchmarks for modern multi-tasking.")
            }
        }
        if (dropPct < 8.0 && record.sustained >= 700) {
            strengths.add("Chassis Thermal Dissipation: High stability ratio (${(100 - dropPct).roundToInt()}%) ensures smooth continuous gaming.")
        }
        if (dropPct >= 20.0) {
            weaknesses.add("Chassis Thermal Dissipation: High thermal decay (${dropPct.roundToInt()}%) will cause noticeable frame drops during extended gaming.")
        }
        if (record.conditions.batteryPct < 25) {
            weaknesses.add("Low Battery State: Run initiated at ${record.conditions.batteryPct}% charge; low battery voltage limits SoC peak boost states.")
        }

        // Headline & Executive summary
        val headline = "${record.deviceModel} ($tier): ${record.band.label} Overall (${record.overall} pts)"
        val execSummary = buildString {
            append("The ${record.deviceModel} powered by ${record.soc} achieved a composite benchmark score of ${record.overall} points ")
            append("(${record.band.label} band) with a peak output of ${record.peak} and a sustained score of ${record.sustained}. ")
            if (dropPct >= 15.0) {
                append("While initial burst speeds are strong, extended workloads trigger a ${dropPct.roundToInt()}% performance step-down primarily driven by ${bottleneck.limitingSubsystem}. ")
            } else {
                append("The device exhibits balanced sustained output across compute clusters with minimal thermal throttling. ")
            }
            append(bottleneck.headline)
        }

        // Recommendations
        val recs = mutableListOf<String>()
        if (dropPct >= 15.0) {
            recs.add("For sustained 3D gaming or 4K video export, remove protective phone cases to improve heat transfer across the frame.")
        }
        if (bottleneck.type == BottleneckType.STORAGE_IOPS) {
            recs.add("Storage random I/O latency is elevated. Ensure at least 15% free internal storage to enable UFS background TRIM routines.")
        }
        if (record.conditions.batteryTempC > 40.0) {
            recs.add("Battery temperature exceeded 40°C during execution. Avoid intensive benchmarking while fast charging.")
        }
        if (recs.isEmpty()) {
            recs.add("Hardware parameters are operating within optimal operating limits. No system configuration changes required.")
        }

        return ExplanationResult(
            headlineVerdict = headline,
            executiveSummary = execSummary,
            tierClassification = tier,
            primaryBottleneck = bottleneck,
            thermalSummary = thermalSummary,
            subsystemVerdicts = subsystemVerdicts,
            standoutStrengths = strengths.ifEmpty { listOf("Consistent baseline performance across standard productivity tasks.") },
            criticalWeaknesses = weaknesses.ifEmpty { listOf("No critical hardware bottlenecks detected.") },
            actionableRecommendations = recs,
        )
    }

    /**
     * Converts a [RunRecord] into a list of structured [Insight] entities for the UI layer.
     */
    fun generateInsights(record: RunRecord): List<Insight> {
        val explanation = explain(record)
        val list = mutableListOf<Insight>()

        // Bottleneck Insight
        list.add(
            Insight(
                id = "ins_bottleneck_${record.id}",
                severity = explanation.primaryBottleneck.severity,
                title = explanation.primaryBottleneck.headline,
                body = explanation.primaryBottleneck.detailedExplanation,
                evidence = "Limiting Subsystem: ${explanation.primaryBottleneck.limitingSubsystem} | Drop: ${explanation.thermalSummary.peakToSustainedDropPct}%",
                tag = explanation.primaryBottleneck.type.displayName,
            )
        )

        // Thermal Insight
        if (explanation.thermalSummary.throttlingDetected) {
            list.add(
                Insight(
                    id = "ins_thermal_${record.id}",
                    severity = if (explanation.thermalSummary.peakToSustainedDropPct >= 20.0) InsightSeverity.CRITICAL else InsightSeverity.WARNING,
                    title = "Thermal Decay: ${explanation.thermalSummary.peakToSustainedDropPct}% Drop Under Load",
                    body = explanation.thermalSummary.plainEnglishVerdict,
                    evidence = "Peak: ${explanation.thermalSummary.peakScore} → Sustained: ${explanation.thermalSummary.sustainedScore} | Temp: ${explanation.thermalSummary.batteryTempC}°C",
                    tag = "Thermals",
                )
            )
        } else {
            list.add(
                Insight(
                    id = "ins_thermal_${record.id}",
                    severity = InsightSeverity.STRENGTH,
                    title = "Thermal Headroom Maintained",
                    body = "Chassis cooling kept temperatures stable under heavy computation with under 10% performance decay.",
                    evidence = "Stability Ratio: ${(100 - explanation.thermalSummary.peakToSustainedDropPct).roundToInt()}% | Final Temp: ${explanation.thermalSummary.batteryTempC}°C",
                    tag = "Thermals",
                )
            )
        }

        // Reliability / Confidence Insight
        if (record.cvPct > 6.0) {
            list.add(
                Insight(
                    id = "ins_confidence_${record.id}",
                    severity = InsightSeverity.INFO,
                    title = "Elevated Measurement Variance (CV ${record.cvPct}%)",
                    body = "Inter-run variance exceeded 6%, likely influenced by active background synchronization or ambient thermal fluctuation.",
                    evidence = "Confidence: ${record.confidence}% | CoV: ${record.cvPct}%",
                    tag = "Integrity",
                )
            )
        }

        return list
    }

    private fun identifyBottleneck(record: RunRecord, dropPct: Double): BottleneckSummary {
        val cpuScore = record.categories.firstOrNull { it.id == "cpu" }?.score ?: record.overall
        val gpuScore = record.categories.firstOrNull { it.id == "gpu" }?.score ?: record.overall
        val memScore = record.categories.firstOrNull { it.id == "memory" }?.score ?: record.overall
        val storageScore = record.categories.firstOrNull { it.id == "storage" }?.score ?: record.overall
        val sustainedScore = record.categories.firstOrNull { it.id == "thermal" || it.id == "sustained" }?.score ?: record.sustained

        return when {
            dropPct >= 20.0 || (record.conditions.thermalStatus in listOf("Severe", "Critical", "Emergency")) -> {
                BottleneckSummary(
                    type = BottleneckType.THERMAL_THROTTLING,
                    severity = InsightSeverity.CRITICAL,
                    headline = "Thermal Throttling is Constraining Peak Silicon Throughput",
                    detailedExplanation = "Chassis heat dissipation limits sustained performance. Once junction temperature climbed past thermal thresholds, DVFS governors dropped core frequencies, reducing performance by ${dropPct.roundToInt()}%.",
                    limitingSubsystem = "Chassis Thermal Envelope & DVFS Governor",
                    impactedWorkloads = listOf("3D Gaming", "8K/4K Video Export", "Long-form AI Inference"),
                    mitigationAdvice = "Avoid heavy computation while fast-charging or in direct sunlight. Use conductive cooling or un-case the device for extended sessions.",
                )
            }
            storageScore < 500 && (cpuScore > 750 || gpuScore > 750) -> {
                BottleneckSummary(
                    type = BottleneckType.STORAGE_IOPS,
                    severity = InsightSeverity.WARNING,
                    headline = "Storage I/O Subsystem Lagging Behind Compute",
                    detailedExplanation = "High compute capacity is bottlenecked by flash storage latency. Heavy random write queues or background filesystem operations delay application launch and asset hydration.",
                    limitingSubsystem = "Flash Storage & UFS Controller",
                    impactedWorkloads = listOf("App Launch Times", "Large Game Asset Loading", "Multi-file Unzipping"),
                    mitigationAdvice = "Free at least 15-20% internal flash storage capacity to allow flash controller garbage collection and wear leveling.",
                )
            }
            memScore < 600 && cpuScore > 800 -> {
                BottleneckSummary(
                    type = BottleneckType.MEMORY_BANDWIDTH,
                    severity = InsightSeverity.WARNING,
                    headline = "Memory Bus Latency Limiting CPU Pipeline Saturation",
                    detailedExplanation = "The CPU clusters are periodically starved waiting for memory operand fetches. DRAM bandwidth saturation caps peak IPC during dense matrix operations.",
                    limitingSubsystem = "LPDDR Memory Controller",
                    impactedWorkloads = listOf("Multi-tasking App Switching", "Camera Computational RAW Stacking", "On-Device LLM Decoding"),
                    mitigationAdvice = "Close memory-heavy background applications before running demanding creative apps.",
                )
            }
            gpuScore < 550 && cpuScore > 800 -> {
                BottleneckSummary(
                    type = BottleneckType.GPU_COMPUTE,
                    severity = InsightSeverity.INFO,
                    headline = "Graphics Rasterization Capacity Constrained",
                    detailedExplanation = "While general CPU processing is robust, the GPU shader core count and raster fillrate define the ceiling for visual fidelity.",
                    limitingSubsystem = "GPU Shader Core Array",
                    impactedWorkloads = listOf("High-refresh 3D Gaming", "Vulkan Compute Shaders", "Ray Tracing"),
                    mitigationAdvice = "Configure games to render at 1080p or enable Dynamic Resolution Scaling (FSR/VRS) to preserve 60+ FPS.",
                )
            }
            record.conditions.batteryPct < 20 -> {
                BottleneckSummary(
                    type = BottleneckType.BATTERY_POWER_LIMIT,
                    severity = InsightSeverity.WARNING,
                    headline = "Battery State of Charge Limiting Peak Power Rails",
                    detailedExplanation = "Battery charge is at ${record.conditions.batteryPct}%. Android power governors throttle peak boost frequencies to prevent sudden brownout shutdowns under high current draw.",
                    limitingSubsystem = "Battery Fuel Gauge & PMIC Rail",
                    impactedWorkloads = listOf("All Peak Burst Workloads"),
                    mitigationAdvice = "Charge device to 50%+ battery before executing performance-sensitive tasks.",
                )
            }
            else -> {
                BottleneckSummary(
                    type = BottleneckType.NONE,
                    severity = InsightSeverity.STRENGTH,
                    headline = "Well-Balanced Subsystem Synergy",
                    detailedExplanation = "Compute, memory, storage, and thermal cooling subsystems exhibit harmonious balance without isolated choke points.",
                    limitingSubsystem = "None (Cohesive Architecture)",
                    impactedWorkloads = emptyList(),
                    mitigationAdvice = "Device is operating at intended peak architectural efficiency.",
                )
            }
        }
    }

    private fun buildSubsystemSentence(id: String, score: Int, deltaPct: Double, band: ScoreBand): String =
        when (id) {
            "cpu" -> "CPU compute achieved $score pts (${band.label}), delivering responsive thread scheduling and integer execution."
            "gpu" -> "Graphics subsystem achieved $score pts (${band.label}), handling modern 3D geometry and fragment pipelines."
            "memory" -> "Memory subsystem posted $score pts (${band.label}), measuring sequential throughput and random latency."
            "storage" -> "Storage subsystem reached $score pts (${band.label}), handling random 4KB IOPS and sequential I/O."
            "ai" -> "On-device AI engine scored $score pts (${band.label}), benchmarking neural inference and quantized tensor ops."
            "thermal", "sustained" -> "Sustained stability scored $score pts (${band.label}), reflecting endurance under sustained thermal soak."
            else -> "$id subsystem recorded $score points (${band.label})."
        }
}
