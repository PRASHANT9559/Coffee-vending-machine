package com.benchsuite.app.features.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.benchsuite.app.ui.state.SessionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Gaming domain deep-dive.
 *
 * Sub-features: predicted_fps, emulator, cloud_gaming, app_launch,
 * touch_photon, cold_warm.
 */
@Composable
fun GamingDetailScreen(
    subFeature: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<DomainDetailResult?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        val ctx = SessionState.applicationContext
        if (ctx == null) {
            error = "Application context unavailable"
            return
        }
        isLoading = true
        error = null
        scope.launch(Dispatchers.Default) {
            runCatching { measure(subFeature, ctx) }
                .onSuccess { result = it }
                .onFailure { error = it.message ?: "Gaming feature failed" }
            isLoading = false
        }
    }

    LaunchedEffect(subFeature) { load() }

    DomainDetailScaffold(
        title = titleFor(subFeature),
        subtitle = "Gaming · measured on this device",
        result = result,
        isLoading = isLoading,
        error = error,
        onRetry = { load() },
        onBack = onBack,
        onNavigate = onNavigate,
    )
}

private fun titleFor(subFeature: String): String = when (subFeature) {
    "predicted_fps" -> "Predicted gaming FPS"
    "emulator" -> "Emulator performance predictor"
    "cloud_gaming" -> "Cloud gaming readiness"
    "app_launch" -> "App launch consistency"
    "touch_photon" -> "Touch-to-photon latency"
    "cold_warm" -> "Cold vs warm game launch"
    else -> "Gaming feature"
}

private fun measure(subFeature: String, ctx: android.content.Context): DomainDetailResult =
    when (subFeature) {
        "predicted_fps" -> {
            val r = SessionState.runGamingPredictedFps()
            DomainDetailResult(
                score = r.gamingScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Device class", r.deviceClass),
                    DetailMetric("GPU", r.gpu),
                    DetailMetric("Avg FPS", fmt(r.averagePredictedFps, 0)),
                    DetailMetric("60 FPS games", "${r.sixtyFpsGameCount}/${r.predictions.size}"),
                ),
                radar = listOf(
                    r.gamingScore / 10f,
                    (r.averagePredictedFps.toFloat() / 1.2f).coerceIn(0f, 100f),
                    (r.sixtyFpsGameCount.toFloat() / r.predictions.size.coerceAtLeast(1) * 100f),
                    (r.predictions.map { it.confidencePct }.averageOrZero().toFloat()).coerceIn(0f, 100f),
                    (r.predictions.size * 10f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Avg FPS", "60 FPS", "Confidence", "Coverage"),
                radarMax = 100f,
                radarTitle = "Gaming headroom",
                radarCaption = "Predicted frame rate across the reference game set",
                chartTitle = "Predicted FPS per title",
                chartCaption = "Higher is better; the 60 FPS line is the playable target",
                chartSeries = r.predictions.map { it.predictedFps.toFloat() },
                chartSeries2 = List(r.predictions.size) { 60f },
                chartUnit = "fps",
                distributionTitle = "FPS bands",
                distributionCaption = "How many titles land in each frame-rate band",
                distribution = fpsBands(r.predictions.map { it.predictedFps }),
                distributionFooter = r.predictions.take(4).map {
                    it.gameName to "${fmt(it.predictedFps, 0)} fps · ${it.bottleneck}"
                },
            )
        }

        "emulator" -> {
            val r = SessionState.runGamingEmulator()
            DomainDetailResult(
                score = r.emulatorScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Device class", r.deviceClass),
                    DetailMetric("Playable consoles", "${r.playableConsoleCount}/${r.predictions.size}"),
                    DetailMetric("Avg FPS", fmt(r.predictions.map { it.estimatedFps }.averageOrZero(), 0)),
                    DetailMetric("Avg compatibility", fmt(r.predictions.map { it.compatibilityPct }.averageOrZero()), "%"),
                ),
                radar = listOf(
                    r.emulatorScore / 10f,
                    (r.playableConsoleCount.toFloat() / r.predictions.size.coerceAtLeast(1) * 100f),
                    (r.predictions.map { it.estimatedFps }.averageOrZero().toFloat() / 1.2f).coerceIn(0f, 100f),
                    (r.predictions.map { it.compatibilityPct }.averageOrZero().toFloat()).coerceIn(0f, 100f),
                    (r.predictions.size * 15f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Playable", "FPS", "Compat", "Consoles"),
                radarMax = 100f,
                radarTitle = "Emulation capability",
                radarCaption = "Playability, frame rate and compatibility per console",
                chartTitle = "Estimated FPS per console",
                chartCaption = "Predicted frame rate for each emulated console",
                chartSeries = r.predictions.map { it.estimatedFps.toFloat() },
                chartUnit = "fps",
                distributionTitle = "Compatibility bands",
                distributionCaption = "Compatibility percentage per console",
                distribution = r.predictions.map { it.compatibilityPct.toInt().coerceIn(0, 500) },
                distributionFooter = r.predictions.map {
                    it.console.name to (if (it.playable) "Playable" else "Not playable")
                },
            )
        }

        "cloud_gaming" -> {
            val r = SessionState.runGamingCloud(ctx)
            DomainDetailResult(
                score = r.readinessScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Network", r.networkType),
                    DetailMetric("Network RTT", fmt(r.networkLatencyMs), "ms"),
                    DetailMetric("Jitter", fmt(r.jitterMs, 2), "ms"),
                    DetailMetric("Decode", fmt(r.decodeLatencyMs), "ms"),
                    DetailMetric("Touch", fmt(r.touchLatencyMs), "ms"),
                    DetailMetric("Total", fmt(r.totalLatencyMs), "ms"),
                ),
                radar = listOf(
                    r.readinessScore / 10f,
                    (100f - r.networkLatencyMs.toFloat()).coerceIn(0f, 100f),
                    (100f - r.jitterMs.toFloat() * 10f).coerceIn(0f, 100f),
                    (100f - r.decodeLatencyMs.toFloat() * 2f).coerceIn(0f, 100f),
                    if (r.readyForCloudGaming) 100f else 45f,
                ),
                radarLabels = listOf("Score", "Network", "Jitter", "Decode", "Ready"),
                radarMax = 100f,
                radarTitle = "Streaming readiness",
                radarCaption = "Where latency is added between input and screen",
                chartTitle = "Latency budget",
                chartCaption = "Each stage of the cloud gaming pipeline",
                chartSeries = r.components.map { it.latencyMs.toFloat() },
                chartUnit = "ms",
                distributionTitle = "Stage contribution",
                distributionCaption = "Relative latency contribution per stage",
                distribution = r.components.map { it.latencyMs.toInt().coerceIn(0, 500) },
                distributionFooter = r.components.map {
                    it.name to "${fmt(it.latencyMs)} ms"
                },
            )
        }

        "app_launch" -> {
            val r = SessionState.runGamingAppLaunch(ctx)
            DomainDetailResult(
                score = r.consistencyScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Apps", r.appsTested.toString()),
                    DetailMetric("Runs/app", r.runsPerApp.toString()),
                    DetailMetric("Avg cold", fmt(r.averageColdStartMs, 0), "ms"),
                    DetailMetric("P95 cold", fmt(r.p95ColdStartMs, 0), "ms"),
                    DetailMetric("Outliers", r.outlierCount.toString()),
                ),
                radar = listOf(
                    r.consistencyScore / 10f,
                    (100f - r.averageColdStartMs.toFloat() / 20f).coerceIn(0f, 100f),
                    (100f - r.p95ColdStartMs.toFloat() / 20f).coerceIn(0f, 100f),
                    (100f - r.outlierCount.toFloat() * 20f).coerceIn(0f, 100f),
                    (r.results.size * 10f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Avg cold", "P95", "Outliers", "Coverage"),
                radarMax = 100f,
                radarTitle = "Launch stability",
                radarCaption = "Cold start spread across the tested app set",
                chartTitle = "Cold vs warm start",
                chartCaption = "Per-app cold start compared with the warm path",
                chartSeries = r.results.map { it.coldStartMs.toFloat() },
                chartSeries2 = r.results.map { it.warmStartMs.toFloat() },
                chartUnit = "ms",
                distributionTitle = "Consistency per app",
                distributionCaption = "Higher percentages mean tighter run-to-run times",
                distribution = r.results.map { it.consistencyPct.toInt().coerceIn(0, 500) },
                distributionFooter = r.results.take(4).map {
                    it.appLabel to "${fmt(it.consistencyPct, 0)} %${if (it.isOutlier) " · outlier" else ""}"
                },
            )
        }

        "touch_photon" -> {
            val r = SessionState.runGamingTouchPhoton(ctx)
            val b = r.breakdown
            DomainDetailResult(
                score = r.latencyScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Refresh rate", "${r.refreshRateHz}", "Hz"),
                    DetailMetric("Touch scanout", fmt(b.touchScanoutMs, 2), "ms"),
                    DetailMetric("App", fmt(b.appProcessingMs, 2), "ms"),
                    DetailMetric("GPU", fmt(b.gpuRenderMs, 2), "ms"),
                    DetailMetric("Display", fmt(b.displayScanoutMs, 2), "ms"),
                    DetailMetric("Total", fmt(b.totalTouchToPhotonMs, 2), "ms"),
                    DetailMetric("Grade", r.competitiveGrade),
                ),
                radar = listOf(
                    r.latencyScore / 10f,
                    (100f - b.totalTouchToPhotonMs.toFloat() * 2f).coerceIn(0f, 100f),
                    (100f - b.gpuRenderMs.toFloat() * 2f).coerceIn(0f, 100f),
                    (100f - b.displayScanoutMs.toFloat() * 2f).coerceIn(0f, 100f),
                    (r.refreshRateHz.toFloat() / 1.65f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Total", "GPU", "Display", "Refresh"),
                radarMax = 100f,
                radarTitle = "Input pipeline",
                radarCaption = "Touch → app → GPU → display handoff",
                chartTitle = "Latency breakdown",
                chartCaption = "Milliseconds spent in each pipeline stage",
                chartSeries = listOf(
                    b.touchScanoutMs.toFloat(),
                    b.appProcessingMs.toFloat(),
                    b.gpuRenderMs.toFloat(),
                    b.displayScanoutMs.toFloat(),
                ),
                chartUnit = "ms",
                distributionTitle = "Stage weight",
                distributionCaption = "Relative contribution of each stage",
                distribution = listOf(
                    b.touchScanoutMs,
                    b.appProcessingMs,
                    b.gpuRenderMs,
                    b.displayScanoutMs,
                ).map { (it * 10).toInt().coerceIn(0, 500) },
                distributionFooter = listOf(
                    "Touch scanout" to "${fmt(b.touchScanoutMs, 2)} ms",
                    "App processing" to "${fmt(b.appProcessingMs, 2)} ms",
                    "GPU render" to "${fmt(b.gpuRenderMs, 2)} ms",
                    "Display scanout" to "${fmt(b.displayScanoutMs, 2)} ms",
                ),
            )
        }

        "cold_warm" -> {
            val r = SessionState.runGamingColdWarm(ctx)
            DomainDetailResult(
                score = r.launchScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Games", r.gamesTested.toString()),
                    DetailMetric("Avg cold", fmt(r.averageColdMs, 0), "ms"),
                    DetailMetric("Avg warm", fmt(r.averageWarmMs, 0), "ms"),
                    DetailMetric("Improvement", fmt(r.averageImprovementPct), "%"),
                ),
                radar = listOf(
                    r.launchScore / 10f,
                    (100f - r.averageColdMs.toFloat() / 30f).coerceIn(0f, 100f),
                    (100f - r.averageWarmMs.toFloat() / 10f).coerceIn(0f, 100f),
                    r.averageImprovementPct.toFloat().coerceIn(0f, 100f),
                    (r.results.size * 20f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Cold", "Warm", "Gain", "Games"),
                radarMax = 100f,
                radarTitle = "Launch caching benefit",
                radarCaption = "How much warm launches improve on cold starts",
                chartTitle = "Cold vs warm per game",
                chartCaption = "Launch-to-interactive time in milliseconds",
                chartSeries = r.results.map { it.coldLaunchMs.toFloat() },
                chartSeries2 = r.results.map { it.warmLaunchMs.toFloat() },
                chartUnit = "ms",
                distributionTitle = "Improvement per game",
                distributionCaption = "Percentage faster when the game is already cached",
                distribution = r.results.map { it.improvementPct.toInt().coerceIn(0, 500) },
                distributionFooter = r.results.take(4).map {
                    it.gameName to "${fmt(it.coldLaunchMs, 0)} → ${fmt(it.warmLaunchMs, 0)} ms"
                },
            )
        }

        else -> DomainDetailResult(score = 0, verdict = "Unknown gaming sub-feature: $subFeature")
    }

private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()

/** Groups predicted frame rates into display-friendly bands. */
private fun fpsBands(values: List<Double>): List<Int> {
    val bands = mutableListOf(0, 0, 0, 0, 0, 0)
    values.forEach { fps ->
        val index = when {
            fps < 30 -> 0
            fps < 45 -> 1
            fps < 60 -> 2
            fps < 90 -> 3
            fps < 120 -> 4
            else -> 5
        }
        bands[index] = bands[index] + 1
    }
    return bands
}
