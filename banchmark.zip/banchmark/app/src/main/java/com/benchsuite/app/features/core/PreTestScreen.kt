package com.benchsuite.app.features.core

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.catalog.TestCatalog
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChecklistRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.ProgressLine
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing
import com.benchsuite.app.ui.state.SessionState

@Composable
fun PreTestScreen(categoryId: String, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val isFull = categoryId == "full"
    val isQuick = categoryId == "quick"
    val spec = TestCatalog.categorySpecs.firstOrNull { it.id == categoryId }
    val title = when {
        isQuick -> "60s One-Tap Quick Test"
        isFull -> "Full benchmark suite"
        else -> spec?.title ?: "Benchmark"
    }
    val planTests = when {
        isQuick -> listOf(
            com.benchsuite.app.data.model.TestDefinition("quick_cpu", "CPU Burst (Integer + Multi-thread)", "15s compute burst", "cpu", 1, "Easy", 8, "Must Have"),
            com.benchsuite.app.data.model.TestDefinition("quick_mem", "Memory Bandwidth & Latency Probe", "10s DRAM probe", "memory", 1, "Easy", 8, "Must Have"),
            com.benchsuite.app.data.model.TestDefinition("quick_gpu", "Vulkan / GLES Offscreen Fragment", "15s graphics rendering", "gpu", 1, "Easy", 8, "Must Have"),
            com.benchsuite.app.data.model.TestDefinition("quick_storage", "Storage Random IOPS Probe", "10s random I/O", "storage", 1, "Easy", 8, "Must Have"),
            com.benchsuite.app.data.model.TestDefinition("quick_thermal", "Thermal & Battery Drain Delta", "10s delta check", "thermal", 1, "Easy", 8, "Must Have"),
        )
        isFull -> TestCatalog.tests.filter { it.priority == "Must Have" }.take(8)
        else -> spec?.tests ?: emptyList()
    }
    val minutes = if (isQuick) 1 else if (isFull) 14 else ((planTests.sumOf { it.minutes } * 0.62).toInt() + 1).coerceAtLeast(2)

    Column(Modifier.fillMaxSize()) {
        BenchTopBar(
            title = "Pre-test checklist",
            subtitle = title,
            onBack = onBack,
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Environment validation",
                    title = "Ready to measure?",
                    body = "A clean environment is what makes the result reproducible. Nothing here is mandatory, but flags are recorded.",
                )
            }

            item {
                SurfaceCard {
                    val checks = SessionState.preTestChecks
                    val passedCount = checks.count { it.status == com.benchsuite.app.data.model.CheckStatus.PASS }
                    val allPass = SessionState.canProceedWithRun
                    val envScore = if (checks.isNotEmpty()) (passedCount * 100 / checks.size) else 100
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .background(
                                    (if (allPass) BenchTheme.colors.success else BenchTheme.colors.warning).copy(alpha = 0.12f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (allPass) Icons.Outlined.CheckCircle else Icons.Outlined.Warning,
                                null,
                                tint = if (allPass) BenchTheme.colors.success else BenchTheme.colors.warning,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Environment score", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "$passedCount of ${checks.size} checks passed",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text("$envScore", style = NumericSmall.copy(fontSize = 24.sp), color = if (allPass) BenchTheme.colors.success else BenchTheme.colors.warning)
                    }
                    Spacer(Modifier.height(12.dp))
                    ProgressLine((envScore / 100f).coerceIn(0f, 1f), color = if (allPass) BenchTheme.colors.success else BenchTheme.colors.warning)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        EnvironmentStat(Icons.Outlined.BatteryChargingFull, "--%", "Battery", Modifier.weight(1f))
                        EnvironmentStat(Icons.Outlined.Thermostat, "--°C", "Battery temp", Modifier.weight(1f))
                        EnvironmentStat(Icons.Outlined.CheckCircle, "--%", "Background", Modifier.weight(1f))
                    }
                }
            }

            item {
                SurfaceCard(contentPadding = PaddingValues(horizontal = Spacing.md, vertical = 6.dp)) {
                    Text(
                        "Checklist",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp),
                    )
                    SessionState.preTestChecks.forEach { check ->
                        ChecklistRow(check = check)
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Test plan", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusChip("$minutes min", tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.height(8.dp))
                    planTests.take(6).forEach { test ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(5.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                test.name,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                "${test.minutes} min",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    if (planTests.size > 6) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "+ ${planTests.size - 6} more tests",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag("Peak + sustained")
                        Tag("3 iterations")
                        Tag("Median + outlier trim")
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Outlined.Warning, null, tint = BenchTheme.colors.warning, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("For the cleanest result", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(3.dp))
                            Text(
                                "Remove the case, keep the screen off where possible, and do not fast-charge during the run. The app will flag conditions if they change.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            item {
                TextButton(onClick = { onNavigate(Routes.CUSTOM_BUILDER) }) {
                    Text("Edit this plan in the custom builder")
                }
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .navigationBarsPadding()
                .padding(horizontal = Dimens.screenPadding, vertical = Spacing.sm),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Estimated", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$minutes min · $title", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Button(
                    onClick = {
                        SessionState.startRun(categoryId, title)
                        onNavigate(Routes.LIVE_RUN)
                    },
                    modifier = Modifier.height(50.dp),
                ) {
                    Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Start run")
                }
            }
        }
    }
}

@Composable
private fun EnvironmentStat(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    label: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .padding(10.dp),
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
        Spacer(Modifier.height(6.dp))
        Text(value, style = MaterialTheme.typography.labelLarge)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
