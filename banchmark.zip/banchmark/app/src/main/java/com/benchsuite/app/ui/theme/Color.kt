package com.benchsuite.app.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/* ------------------------------------------------------------------ */
/* Raw design tokens (README section 6)                               */
/* ------------------------------------------------------------------ */

object DarkTokens {
    val background = Color(0xFF05070A)
    val surface = Color(0xFF10141A)
    val surfaceVariant = Color(0xFF1A2029)
    val surfaceElevated = Color(0xFF151B23)
    val outline = Color(0xFF2A3340)
    val outlineSubtle = Color(0xFF1E2630)
    val primary = Color(0xFF22D3EE)
    val onPrimary = Color(0xFF00363D)
    val secondary = Color(0xFFA78BFA)
    val textPrimary = Color(0xFFE6EAF0)
    val textSecondary = Color(0xFF9AA4B2)
    val success = Color(0xFF34D399)
    val warning = Color(0xFFFBBF24)
    val danger = Color(0xFFF87171)
}

object LightTokens {
    val background = Color(0xFFF6F8FB)
    val surface = Color(0xFFFFFFFF)
    val surfaceVariant = Color(0xFFEEF2F7)
    val surfaceElevated = Color(0xFFFFFFFF)
    val outline = Color(0xFFD5DDE7)
    val outlineSubtle = Color(0xFFE5EBF2)
    val primary = Color(0xFF0E7490)
    val onPrimary = Color(0xFFFFFFFF)
    val secondary = Color(0xFF6D28D9)
    val textPrimary = Color(0xFF0F172A)
    val textSecondary = Color(0xFF475569)
    val success = Color(0xFF047857)
    val warning = Color(0xFFB45309)
    val danger = Color(0xFFB91C1C)
}

@Immutable
data class BenchColors(
    val success: Color,
    val warning: Color,
    val danger: Color,
    val chartSeries: List<Color>,
    val thermalRamp: List<Color>,
    val surfaceElevated: Color,
    val outlineSubtle: Color,
    val isDark: Boolean,
) {
    fun bandColor(band: String): Color = when (band) {
        "Excellent" -> success
        "Good" -> chartSeries.first()
        "Fair" -> warning
        else -> danger
    }
}

internal val DarkBenchColors = BenchColors(
    success = DarkTokens.success,
    warning = DarkTokens.warning,
    danger = DarkTokens.danger,
    chartSeries = listOf(DarkTokens.primary, DarkTokens.secondary, DarkTokens.warning, DarkTokens.success),
    thermalRamp = listOf(
        Color(0xFF4FC3F7),
        Color(0xFF34D399),
        Color(0xFFFBBF24),
        Color(0xFFFB923C),
        Color(0xFFF87171),
    ),
    surfaceElevated = DarkTokens.surfaceElevated,
    outlineSubtle = DarkTokens.outlineSubtle,
    isDark = true,
)

internal val LightBenchColors = BenchColors(
    success = LightTokens.success,
    warning = LightTokens.warning,
    danger = LightTokens.danger,
    chartSeries = listOf(LightTokens.primary, LightTokens.secondary, LightTokens.warning, LightTokens.success),
    thermalRamp = listOf(
        Color(0xFF0284C7),
        Color(0xFF059669),
        Color(0xFFB45309),
        Color(0xFFEA580C),
        Color(0xFFB91C1C),
    ),
    surfaceElevated = LightTokens.surfaceElevated,
    outlineSubtle = LightTokens.outlineSubtle,
    isDark = false,
)

val LocalBenchColors = staticCompositionLocalOf { DarkBenchColors }
