package com.benchsuite.app.features.account

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.nativecore.NativeBridge
import com.benchsuite.app.ui.components.BrandMark
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.Tag
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing

private val credits = listOf(
    "Kotlin 2.1",
    "Jetpack Compose",
    "Material 3",
    "Rust core",
    "Vulkan 1.4",
    "LiteRT / QNN",
    "Open source fonts",
    "SQLite / Room",
)

private val changelog = listOf(
    "1.0.0 · first public UI milestone" to "All 35 screens, custom chart system and the full design token set.",
    "0.9.0 · insight engine" to "Bottleneck rules, use-case verdicts and recommendation ranking.",
    "0.8.0 · thermal model" to "Sustained decay curves, throttle timeline and cool-down recovery.",
)

@Composable
fun AboutScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var showLicensesDialog by remember { mutableStateOf(false) }

    if (showLicensesDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showLicensesDialog = false },
            title = { Text("Open-Source Licenses", style = MaterialTheme.typography.titleMedium) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("• Android Jetpack Compose (Apache 2.0)", style = MaterialTheme.typography.bodySmall)
                    Text("• Kotlin Coroutines & Serialization (Apache 2.0)", style = MaterialTheme.typography.bodySmall)
                    Text("• Rust bench-core engine (MIT / Apache 2.0)", style = MaterialTheme.typography.bodySmall)
                    Text("• Ash Vulkan Rust bindings (MIT / Apache 2.0)", style = MaterialTheme.typography.bodySmall)
                    Text("• Serde JSON Serialization (MIT / Apache 2.0)", style = MaterialTheme.typography.bodySmall)
                    Text("• AndroidX Architecture Components (Apache 2.0)", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = { showLicensesDialog = false }) {
                    Text("Close")
                }
            },
        )
    }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "About",
            subtitle = "BenchSuite 1.0.0-ui",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Why this exists",
                    title = "Benchmarks that tell the truth.",
                    body = "One score hides the interesting part. BenchSuite reports peak, sustained and confidence together, then explains what it means for you.",
                )
            }

            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f),
                                ),
                            ),
                            RoundedCornerShape(18.dp),
                        )
                        .padding(1.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)),
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(Spacing.lg),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        BrandMark(64.dp)
                        Spacer(Modifier.height(Spacing.sm))
                        Text("BenchSuite", style = MaterialTheme.typography.displaySmall)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "Understand why your device performs.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(Spacing.sm))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusChip("v1.0.0-ui", tint = MaterialTheme.colorScheme.primary)
                            StatusChip("Methodology 2.4.1", tint = BenchTheme.colors.success, icon = Icons.Outlined.Verified)
                        }
                    }
                }
            }

            item { SectionHeader(title = "Build") }
            item {
                SurfaceCard {
                    InfoRow("Version", "1.0.0-ui")
                    InfoRow("Build", "2026.11.11 · debug")
                    InfoRow("Channel", "UI milestone")
                    InfoRow("Methodology", "2.4.1 · median + 5% trim")
                    InfoRow("Reference baseline", "1000 (reference device)")
                    InfoRow("Score ceiling", "1,100")
                    InfoRow("Test catalog", "158 tests · 22 categories")
                    InfoRow("Minimum Android", "10 (API 29)")
                    InfoRow(
                        label = "Native core",
                        value = NativeBridge.statusLabel,
                        valueColor = if (NativeBridge.isAvailable) {
                            BenchTheme.colors.success
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                }
            }

            item { SectionHeader(title = "The method") }
            item {
                SurfaceCard {
                    MethodRow(
                        icon = Icons.Outlined.Speed,
                        title = "Peak and sustained, always",
                        body = "A short burst is easy. The sustained number is what long gaming, exports and AI sessions actually get.",
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    MethodRow(
                        icon = Icons.Outlined.Info,
                        title = "Confidence on every result",
                        body = "Three iterations, coefficient of variation under 3%, and an explicit confidence percentage. Bad runs are rejected, not averaged in.",
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    MethodRow(
                        icon = Icons.Outlined.Lock,
                        title = "Signed and local",
                        body = "Results are signed with a hardware-backed key and verified on-device. Nothing uploads unless you opt in.",
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    MethodRow(
                        icon = Icons.Outlined.School,
                        title = "Built to be checked",
                        body = "The methodology, normalization and outlier policy are visible in every result. No black-box multipliers.",
                    )
                }
            }

            item { SectionHeader(title = "Changelog") }
            item {
                SurfaceCard {
                    changelog.forEachIndexed { index, (title, body) ->
                        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            body,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (index != changelog.lastIndex) Spacer(Modifier.height(Spacing.sm))
                    }
                }
            }

            item { SectionHeader(title = "Built with") }
            item {
                SurfaceCard {
                    credits.chunked(2).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            row.forEach { credit ->
                                Tag(credit)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Code, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Open-source licenses are bundled with the app.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item { SectionHeader(title = "Legal and support") }
            item {
                SurfaceCard {
                    LinkRow("Privacy and data", Icons.Outlined.Lock) { onNavigate(Routes.PRIVACY) }
                    LinkRow("Help and support", Icons.Outlined.MenuBook) { onNavigate(Routes.HELP) }
                    LinkRow("Open-source licenses", Icons.Outlined.Code) { showLicensesDialog = true }
                }
            }

            item {
                Text(
                    "BenchSuite is an independent project. Device and vendor names are trademarks of their respective owners and are used only for identification.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            item {
                TextButton(onClick = { onNavigate(Routes.HELP) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Something looks wrong? Open support")
                }
            }
        }
    }
}

@Composable
private fun MethodRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(9.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LinkRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 0.dp, vertical = 4.dp),
    ) {
        Icon(icon, null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text("Open", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
}
