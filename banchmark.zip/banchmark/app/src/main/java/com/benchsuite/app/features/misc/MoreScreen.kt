package com.benchsuite.app.features.misc

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.ShortcutRow
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.iconFor
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing

/**
 * Overflow destination for everything that does not fit the five bottom tabs.
 * Mirrors the "More menu" row of README section 5.1.
 */
@Composable
fun MoreScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val destinations = mapOf(
        "device" to Routes.DEVICE_INFO,
        "leaderboard" to Routes.LEADERBOARD,
        "compare" to Routes.COMPARE,
        "builder" to Routes.CUSTOM_BUILDER,
        "scheduler" to Routes.SCHEDULER,
        "settings" to Routes.SETTINGS,
        "about" to Routes.ABOUT,
    )

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "More",
            subtitle = "Tools, data and account",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Everything else",
                    title = "The whole toolkit.",
                    body = "Deep hardware data, community rankings, scheduling and the controls behind every score.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("AI insights", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Six explanations generated from your last full run.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.width(Spacing.sm))
                        StatusDot()
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        MiniLink("Open insights", Icons.Outlined.Insights) { onNavigate(Routes.INSIGHTS) }
                        MiniLink("Recommendations", Icons.Outlined.Insights) { onNavigate(Routes.RECOMMENDATIONS) }
                    }
                }
            }

            item { SectionHeader(title = "Explore") }
            item {
                SurfaceCard(contentPadding = PaddingValues(horizontal = Spacing.md, vertical = 4.dp)) {
                    Text(
                        "शॉर्टकट रन रिकॉर्ड से जनरेट किए जाएंगे।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item { SectionHeader(title = "Trust and support") }
            item {
                SurfaceCard(contentPadding = PaddingValues(horizontal = Spacing.md, vertical = 4.dp)) {
                    ShortcutRow(
                        title = "Privacy and data",
                        subtitle = "Consent, retention and deletion",
                        icon = Icons.Outlined.Lock,
                        onClick = { onNavigate(Routes.PRIVACY) },
                    )
                    ShortcutRow(
                        title = "Help and support",
                        subtitle = "FAQ, diagnostics and feedback",
                        icon = Icons.Outlined.SupportAgent,
                        onClick = { onNavigate(Routes.HELP) },
                    )
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Outlined.Lock,
                            contentDescription = null,
                            tint = BenchTheme.colors.success,
                            modifier = Modifier.size(17.dp),
                        )
                        Spacer(Modifier.width(9.dp))
                        Text(
                            "Everything runs on this device. Uploads are opt-in and signed.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                Text(
                    text = "BenchSuite 1.0.0-ui · methodology 2.4.1",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(top = Spacing.xs),
                )
            }
        }
    }
}

@Composable
private fun MiniLink(label: String, icon: ImageVector, onClick: () -> Unit) {
    androidx.compose.material3.TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 8.dp)) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun StatusDot() {
    Row(
        modifier = Modifier
            .background(BenchTheme.colors.success.copy(alpha = 0.12f), RoundedCornerShape(50))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        androidx.compose.foundation.layout.Box(
            Modifier
                .size(6.dp)
                .background(BenchTheme.colors.success, RoundedCornerShape(50)),
        )
        Spacer(Modifier.width(5.dp))
        Text("Local", style = MaterialTheme.typography.labelSmall, color = BenchTheme.colors.success)
    }
}
