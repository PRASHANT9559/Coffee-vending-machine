package com.benchsuite.app.engine.telemetry

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import com.benchsuite.app.data.model.CheckStatus
import com.benchsuite.app.data.model.EnvironmentCheck
import kotlin.math.roundToInt

/**
 * Feature 22.2: Guided Pre-Test Checklist.
 *
 * Performs hardware and platform sensor verification before initiating benchmark runs:
 * 1. Battery State-of-Charge (>= 50% for optimal, >= 20% required)
 * 2. Chassis Thermal Baseline (< 35°C nominal)
 * 3. Charging Status (Charger disconnect to avoid internal Joule heating)
 * 4. Background RAM Headroom (Checks available memory via ActivityManager)
 * 5. Network / Airplane Mode Stability (Prevents background push/sync spikes)
 * 6. Internal Storage Scratch Space (>= 2 GB required for temp buffers)
 * 7. System PowerManager Thermal Status
 */
object GuidedPreTestChecklist {

    data class ChecklistResult(
        val checks: List<EnvironmentCheck>,
        val canProceed: Boolean,
        val allPassed: Boolean,
        val recommendedActions: List<String>,
    )

    /**
     * Executes real platform sensor checks using the given Android [context].
     */
    fun check(context: Context): ChecklistResult {
        val checks = mutableListOf<EnvironmentCheck>()
        val actions = mutableListOf<String>()

        // 1. Battery Level Check
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawLevel = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (rawLevel >= 0 && scale > 0) (rawLevel * 100 / scale) else 75

        when {
            batteryPct >= 50 -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Battery Level",
                        detail = "$batteryPct% — Optimal SoC boost capacity.",
                        status = CheckStatus.PASS,
                    )
                )
            }
            batteryPct >= 20 -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Battery Level",
                        detail = "$batteryPct% — Adequate, but 50%+ is recommended to prevent voltage sag.",
                        status = CheckStatus.WARN,
                        fixLabel = "Charge",
                    )
                )
                actions.add("Charge battery to at least 50% for peak benchmark consistency.")
            }
            else -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Battery Level",
                        detail = "$batteryPct% — Critical low battery. Android power governors will throttle cores.",
                        status = CheckStatus.FAIL,
                        fixLabel = "Charge",
                    )
                )
                actions.add("Battery is below 20%. Please connect charger and recharge before running.")
            }
        }

        // 2. Battery / Chassis Temperature Check
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = if (tempTenths > 0) tempTenths / 10.0 else 28.0

        when {
            tempC < 35.0 -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Device Temperature",
                        detail = "${(tempC * 10).roundToInt() / 10.0}°C — Cool baseline with maximum thermal headroom.",
                        status = CheckStatus.PASS,
                    )
                )
            }
            tempC < 40.0 -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Device Temperature",
                        detail = "${(tempC * 10).roundToInt() / 10.0}°C — Warm chassis. May enter thermal throttling earlier.",
                        status = CheckStatus.WARN,
                        fixLabel = "Cool down",
                    )
                )
                actions.add("Allow the device to rest at room temperature for 3 minutes to cool below 35°C.")
            }
            else -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Device Temperature",
                        detail = "${(tempC * 10).roundToInt() / 10.0}°C — Overheating. DVFS governors will throttle immediately.",
                        status = CheckStatus.FAIL,
                        fixLabel = "Cool down",
                    )
                )
                actions.add("Device temperature is above 40°C. Cool down the device before starting.")
            }
        }

        // 3. Charger Disconnect Check
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        if (!isCharging) {
            checks.add(
                EnvironmentCheck(
                    title = "Power Cable",
                    detail = "Disconnected — Pure battery discharge without charging heat.",
                    status = CheckStatus.PASS,
                )
            )
        } else {
            checks.add(
                EnvironmentCheck(
                    title = "Power Cable",
                    detail = "Charging active — Generates internal heat that limits sustained performance.",
                    status = CheckStatus.WARN,
                    fixLabel = "Unplug",
                )
            )
            actions.add("Unplug charger to prevent internal charging wattage from heating the chassis.")
        }

        // 4. Background RAM Headroom Check
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)
        val freeRamMb = memInfo.availMem / (1024 * 1024)

        when {
            freeRamMb >= 1500 && !memInfo.lowMemory -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Available Memory",
                        detail = "${freeRamMb / 1024.0.let { (it * 10).roundToInt() / 10.0 }} GB free — Ample headroom for heavy memory matrices.",
                        status = CheckStatus.PASS,
                    )
                )
            }
            freeRamMb >= 750 && !memInfo.lowMemory -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Available Memory",
                        detail = "$freeRamMb MB free — Moderate RAM headroom. Large apps may swap to ZRAM.",
                        status = CheckStatus.WARN,
                        fixLabel = "Close apps",
                    )
                )
                actions.add("Close unused background applications to free at least 1.5 GB of RAM.")
            }
            else -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Available Memory",
                        detail = "$freeRamMb MB free — Low memory condition reported by kernel.",
                        status = CheckStatus.FAIL,
                        fixLabel = "Close apps",
                    )
                )
                actions.add("Kernel memory is under severe pressure. Close background tasks before testing.")
            }
        }

        // 5. Airplane Mode / Network Advice
        val isAirplaneMode = runCatching {
            Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) != 0
        }.getOrDefault(false)

        if (isAirplaneMode) {
            checks.add(
                EnvironmentCheck(
                    title = "Network Distraction",
                    detail = "Airplane mode on — Eliminates push notification and background sync jitter.",
                    status = CheckStatus.PASS,
                )
            )
        } else {
            checks.add(
                EnvironmentCheck(
                    title = "Network Distraction",
                    detail = "Active radios — Incoming notifications or sync spikes may cause minor frame jitter.",
                    status = CheckStatus.WARN,
                    fixLabel = "Airplane",
                )
            )
            actions.add("Enabling Airplane Mode prevents background synchronization during measurement.")
        }

        // 6. Free Storage Headroom
        val freeStorageGb = context.filesDir.usableSpace.coerceAtLeast(0L) / 1_073_741_824.0
        when {
            freeStorageGb >= 4.0 -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Storage Headroom",
                        detail = "${(freeStorageGb * 10).roundToInt() / 10.0} GB available — Sufficient for scratch buffers and trace dumps.",
                        status = CheckStatus.PASS,
                    )
                )
            }
            freeStorageGb >= 2.0 -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Storage Headroom",
                        detail = "${(freeStorageGb * 10).roundToInt() / 10.0} GB available — Adequate, but near minimum threshold.",
                        status = CheckStatus.WARN,
                        fixLabel = "Free space",
                    )
                )
            }
            else -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Storage Headroom",
                        detail = "${(freeStorageGb * 10).roundToInt() / 10.0} GB available — Less than 2 GB free space remaining.",
                        status = CheckStatus.FAIL,
                        fixLabel = "Free space",
                    )
                )
                actions.add("Free at least 2 GB of internal storage before running I/O and shader tests.")
            }
        }

        // 7. System PowerManager Thermal Status
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val thermalStatus = powerManager?.currentThermalStatus ?: PowerManager.THERMAL_STATUS_NONE
        when (thermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Platform Thermal Status",
                        detail = "Nominal — Android framework reports zero hardware thermal constraints.",
                        status = CheckStatus.PASS,
                    )
                )
            }
            PowerManager.THERMAL_STATUS_LIGHT -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Platform Thermal Status",
                        detail = "Light Throttle — Framework has begun minor power modulation.",
                        status = CheckStatus.WARN,
                        fixLabel = "Cool down",
                    )
                )
            }
            else -> {
                checks.add(
                    EnvironmentCheck(
                        title = "Platform Thermal Status",
                        detail = "Severe Throttle — Kernel is clamping frequencies to protect hardware.",
                        status = CheckStatus.FAIL,
                        fixLabel = "Cool down",
                    )
                )
                actions.add("Operating system thermal status is throttled. Please pause and let device cool.")
            }
        }

        val hasFails = checks.any { it.status == CheckStatus.FAIL }
        val allPassed = checks.all { it.status == CheckStatus.PASS }

        return ChecklistResult(
            checks = checks,
            canProceed = !hasFails,
            allPassed = allPassed,
            recommendedActions = actions,
        )
    }
}
