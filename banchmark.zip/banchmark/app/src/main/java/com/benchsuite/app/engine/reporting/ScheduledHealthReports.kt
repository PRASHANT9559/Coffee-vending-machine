package com.benchsuite.app.engine.reporting

import com.benchsuite.app.util.*

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 20.4: Scheduled Health Reports
 *
 * Leverages Android WorkManager to run lightweight periodic background diagnostic routines weekly
 * or monthly, generating longitudinal health trend summaries and early wear warnings.
 * ENGINE/STATE ONLY — no WorkManager request is enqueued here; no manifest changes.
 *
 * Data source: SharedPreferences stored trend samples + current health telemetry.
 * Limitations: No WorkManager dependency or periodic worker is registered by this file; trends
 * are modeled from stored samples. No fabricated measured values.
 */
object ScheduledHealthReports {

    private const val PREFS = "benchsuite_health_trends"
    private const val KEY_TREND_SCORES = "trend_scores"
    private const val KEY_TREND_THERMAL = "trend_thermal"
    private const val KEY_TREND_BATTERY = "trend_battery"
    private const val KEY_TREND_TIMES = "trend_times"
    private const val MAX_TRENDS = 12

    data class TrendPoint(
        val label: String,
        val score: Int,
        val thermalCelsius: Double,
        val batteryHealthPct: Int,
        val timestampMs: Long,
    )

    data class HealthTrendReport(
        val trendPoints: List<TrendPoint>,
        val scoreTrend: String, // IMPROVING / STABLE / DECLINING
        val thermalTrend: String,
        val batteryTrend: String,
        val earlyWarning: String?,
        val healthScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun loadTrends(prefs: SharedPreferences): List<TrendPoint> {
        return try {
            val json = prefs.getString(KEY_TREND_SCORES, null) ?: return emptyList()
            // Simple CSV-ish storage: score|thermal|battery|time per line, newline separated
            json.split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
                val parts = line.split("\\|".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                if (parts.size >= 4) {
                    TrendPoint(
                        label = parts[0],
                        score = parts[1].toIntOrNull() ?: 0,
                        thermalCelsius = parts[2].toDoubleOrNull() ?: 0.0,
                        batteryHealthPct = parts[3].toIntOrNull() ?: 0,
                        timestampMs = parts.getOrNull(4)?.toLongOrNull() ?: System.currentTimeMillis(),
                    )
                } else null
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveTrends(prefs: SharedPreferences, trends: List<TrendPoint>) {
        val csv = trends.map { "${it.label}|${it.score}|${it.thermalCelsius}|${it.batteryHealthPct}|${it.timestampMs}" }
            .joinToString("\n")
        prefs.edit().putString(KEY_TREND_SCORES, csv).apply()
    }

    /**
     * Appends a health trend point and computes longitudinal direction + early warnings.
     */
    fun recordHealthTrend(
        context: Context,
        label: String,
        score: Int,
        thermalCelsius: Double,
        batteryHealthPct: Int,
    ): HealthTrendReport {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val trends = loadTrends(prefs).toMutableList()
        trends.add(TrendPoint(label, score, thermalCelsius, batteryHealthPct, System.currentTimeMillis()))
        if (trends.size > MAX_TRENDS) trends.removeAt(0)
        saveTrends(prefs, trends)

        val scoreTrend = trendDirection(trends.map { it.score.toDouble() })
        val thermalTrend = trendDirection(trends.map { it.thermalCelsius })
        val batteryTrend = trendDirection(trends.map { it.batteryHealthPct.toDouble() })

        val earlyWarning = when {
            batteryTrend == "DECLINING" && trends.lastOrNull()?.batteryHealthPct ?: 100 < 80 ->
                "Battery health is declining and below 80%; consider replacement."
            thermalTrend == "IMPROVING" == false && thermalTrend == "STABLE" == false && trends.lastOrNull()?.thermalCelsius ?: 0 > 50 ->
                "Thermal trend is rising; sustained heat may accelerate wear."
            scoreTrend == "DECLINING" -> "Overall performance score is trending downward."
            else -> null
        }

        val recent = trends.takeLast(3)
        val healthScore = when {
            scoreTrend == "IMPROVING" && batteryTrend != "DECLINING" -> 900
            scoreTrend == "STABLE" -> 800
            scoreTrend == "DECLINING" -> 550
            else -> 650
        }

        val verdict = when {
            scoreTrend == "DECLINING" -> "Device health is trending downward; investigate wear or regressions."
            scoreTrend == "STABLE" -> "Device health is stable across recorded intervals."
            else -> "Device health is improving or insufficient data."
        }

        return HealthTrendReport(
            trendPoints = trends,
            scoreTrend = scoreTrend,
            thermalTrend = thermalTrend,
            batteryTrend = batteryTrend,
            earlyWarning = earlyWarning,
            healthScore = healthScore.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "Trends are stored in SharedPreferences; no WorkManager worker or periodic scheduling is registered by this file.",
        )
    }

    private fun trendDirection(values: List<Double>): String {
        if (values.size < 2) return "STABLE"
        val first = values.take(values.size / 2).averageOrNull() ?: 0.0
        val last = values.takeLast(values.size / 2).averageOrNull() ?: 0.0
        val delta = last - first
        return when {
            delta > 2.0 -> "IMPROVING"
            delta < -2.0 -> "DECLINING"
            else -> "STABLE"
        }
    }
}
