package com.benchsuite.app

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.benchsuite.app.features.account.AboutScreen
import com.benchsuite.app.features.account.HelpScreen
import com.benchsuite.app.features.account.PrivacyScreen
import com.benchsuite.app.features.account.ProfileScreen
import com.benchsuite.app.features.account.SettingsScreen
import com.benchsuite.app.features.category.CategoryScreen
import com.benchsuite.app.features.core.BenchmarksHubScreen
import com.benchsuite.app.features.core.BatteryDetailScreen
import com.benchsuite.app.features.core.AiDetailScreen
import com.benchsuite.app.features.core.CpuDetailScreen
import com.benchsuite.app.features.core.DashboardScreen
import com.benchsuite.app.features.core.FeatureDetailScreen
import com.benchsuite.app.features.core.GamingDetailScreen
import com.benchsuite.app.features.core.GpuDetailScreen
import com.benchsuite.app.features.core.LiveRunScreen
import com.benchsuite.app.features.core.NetworkDetailScreen
import com.benchsuite.app.features.core.PreTestScreen
import com.benchsuite.app.features.core.ResultDetailScreen
import com.benchsuite.app.features.core.ResultSummaryScreen
import com.benchsuite.app.features.core.StorageDetailScreen
import com.benchsuite.app.features.core.ThermalDetailScreen
import com.benchsuite.app.features.data.CompareScreen
import com.benchsuite.app.features.data.DeviceInfoScreen
import com.benchsuite.app.features.data.HistoryScreen
import com.benchsuite.app.features.data.LeaderboardScreen
import com.benchsuite.app.features.data.ReportPreviewScreen
import com.benchsuite.app.features.data.ReportsScreen
import com.benchsuite.app.features.edge.RunFailedScreen
import com.benchsuite.app.features.edge.ShareCardScreen
import com.benchsuite.app.features.entry.HardwareDetectionScreen
import com.benchsuite.app.features.entry.OnboardingScreen
import com.benchsuite.app.features.entry.PermissionsScreen
import com.benchsuite.app.features.entry.SplashScreen
import com.benchsuite.app.features.insight.InsightsScreen
import com.benchsuite.app.features.insight.RecommendationsScreen
import com.benchsuite.app.features.misc.MoreScreen
import com.benchsuite.app.features.tools.CustomBuilderScreen
import com.benchsuite.app.features.tools.SchedulerScreen
import com.benchsuite.app.navigation.BenchBottomBar
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.RunBanner
import com.benchsuite.app.ui.state.SessionState

@Composable
fun BenchSuiteApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    var showCancelDialog by rememberSaveable { mutableStateOf(false) }

    fun navigateTab(target: String) {
        navController.navigate(target) {
            popUpTo(Routes.DASHBOARD) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (route in Routes.bottomTabs) {
                Column {
                    val active = SessionState.activeRun
                    if (active != null) {
                        RunBanner(
                            run = active,
                            onClick = { navController.navigate(Routes.LIVE_RUN) },
                            onStop = { showCancelDialog = true },
                        )
                    }
                    BenchBottomBar(
                        currentRoute = route,
                        onNavigate = { navigateTab(it) },
                    )
                }
            }
        },
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = Routes.SPLASH,
                modifier = Modifier.fillMaxSize(),
            ) {
                composable(Routes.SPLASH) {
                    SplashScreen(
                        onFinished = {
                            val target = if (SessionState.onboarded) Routes.DASHBOARD else Routes.ONBOARDING
                            navController.navigate(target) {
                                popUpTo(Routes.SPLASH) { inclusive = true }
                            }
                        },
                    )
                }
                composable(Routes.ONBOARDING) {
                    OnboardingScreen(
                        onFinished = {
                            SessionState.onboarded = true
                            navController.navigate(Routes.PERMISSIONS) {
                                popUpTo(Routes.ONBOARDING) { inclusive = true }
                            }
                        },
                    )
                }
                composable(Routes.PERMISSIONS) {
                    PermissionsScreen(
                        onBack = { navController.popBackStack() },
                        onContinue = {
                            navController.navigate(Routes.HARDWARE)
                        },
                    )
                }
                composable(Routes.HARDWARE) {
                    HardwareDetectionScreen(
                        onBack = { navController.popBackStack() },
                        onContinue = {
                            SessionState.hardwareScanned = true
                            navController.navigate(Routes.DASHBOARD) {
                                popUpTo(Routes.PERMISSIONS) { inclusive = true }
                            }
                        },
                    )
                }

                composable(Routes.DASHBOARD) {
                    DashboardScreen(onNavigate = { navController.navigate(it) })
                }
                composable(Routes.BENCHMARKS) {
                    BenchmarksHubScreen(onNavigate = { navController.navigate(it) })
                }
                composable(Routes.HISTORY) {
                    HistoryScreen(onNavigate = { navController.navigate(it) })
                }
                composable(Routes.REPORTS) {
                    ReportsScreen(onNavigate = { navController.navigate(it) })
                }
                composable(Routes.PROFILE) {
                    ProfileScreen(onNavigate = { navController.navigate(it) })
                }
                composable(Routes.MORE) {
                    MoreScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                composable(
                    route = Routes.CATEGORY,
                    arguments = listOf(navArgument("categoryId") { type = NavType.StringType }),
                ) { entry ->
                    CategoryScreen(
                        categoryId = entry.arguments?.getString("categoryId") ?: "cpu",
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(
                    route = Routes.PRE_TEST,
                    arguments = listOf(navArgument("categoryId") { type = NavType.StringType }),
                ) { entry ->
                    PreTestScreen(
                        categoryId = entry.arguments?.getString("categoryId") ?: "full",
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.LIVE_RUN) {
                    LiveRunScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { target ->
                            if (target.startsWith("result/summary") || target == Routes.RUN_FAILED) {
                                navController.navigate(target) {
                                    popUpTo(Routes.DASHBOARD)
                                }
                            } else {
                                navController.navigate(target)
                            }
                        },
                    )
                }
                composable(
                    route = Routes.RESULT_SUMMARY,
                    arguments = listOf(navArgument("runId") { type = NavType.StringType; defaultValue = "latest" }),
                    deepLinks = listOf(navDeepLink { uriPattern = "benchsuite://result/{runId}" }),
                ) { entry ->
                    ResultSummaryScreen(
                        runId = entry.arguments?.getString("runId") ?: "latest",
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(
                    route = Routes.RESULT_DETAIL,
                    arguments = listOf(navArgument("runId") { type = NavType.StringType; defaultValue = "latest" }),
                ) { entry ->
                    ResultDetailScreen(
                        runId = entry.arguments?.getString("runId") ?: "latest",
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.INSIGHTS) {
                    InsightsScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.RECOMMENDATIONS) {
                    RecommendationsScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.COMPARE) {
                    CompareScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(
                    route = Routes.REPORT_PREVIEW,
                    arguments = listOf(navArgument("reportId") { type = NavType.StringType }),
                ) { entry ->
                    ReportPreviewScreen(
                        reportId = entry.arguments?.getString("reportId") ?: "rep_1042",
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.LEADERBOARD) {
                    LeaderboardScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.DEVICE_INFO) {
                    DeviceInfoScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.CUSTOM_BUILDER) {
                    CustomBuilderScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.SCHEDULER) {
                    SchedulerScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.PRIVACY) {
                    PrivacyScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.ABOUT) {
                    AboutScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.HELP) {
                    HelpScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.RUN_FAILED) {
                    RunFailedScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
                composable(Routes.SHARE) {
                    ShareCardScreen(
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                /* ------------------------------------------------------------------ */
                /*  Detail screen routes — parameterised by domain + subFeature       */
                /* ------------------------------------------------------------------ */

                // CPU detail
                composable(
                    route = Routes.DETAIL_CPU,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    CpuDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                // GPU detail
                composable(
                    route = Routes.DETAIL_GPU,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    GpuDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                // AI detail
                composable(
                    route = Routes.DETAIL_AI,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    AiDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                // Storage detail
                composable(
                    route = Routes.DETAIL_STORAGE,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    StorageDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                /* ------------------------------------------------------------------ */
                /*  Generic engine feature route — handles all engine features through  */
                /*  one composable. Route format: engine/<domain>/<feature-id>          */
                /*  e.g. engine/cpu/scheduler-efficiency                               */
                /* ------------------------------------------------------------------ */
                composable(
                    route = "engine/{domain}/{featureId}",
                    arguments = listOf(
                        navArgument("domain") { type = NavType.StringType },
                        navArgument("featureId") { type = NavType.StringType },
                    ),
                ) { entry ->
                    val domain = entry.arguments?.getString("domain") ?: ""
                    val featureId = entry.arguments?.getString("featureId") ?: ""
                    FeatureDetailScreen(
                        featureId = "engine/$domain/$featureId",
                        featureName = featureId
                            .replace("-", " ")
                            .split(" ")
                            .joinToString(" ") { it.capitalize() },
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                /* ------------------------------------------------------------------ */
                /*  Generic native (Rust) feature route                               */
                /*  Route format: native/<feature-id>  e.g. native/context-switch     */
                /* ------------------------------------------------------------------ */
                composable(
                    route = "native/{featureId}",
                    arguments = listOf(navArgument("featureId") { type = NavType.StringType }),
                ) { entry ->
                    val featureId = entry.arguments?.getString("featureId") ?: ""
                    val friendlyName = featureId
                        .replace("-", " ")
                        .split(" ")
                        .joinToString(" ") { it.capitalize() }
                    FeatureDetailScreen(
                        featureId = "native/$featureId",
                        featureName = friendlyName,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                /* ------------------------------------------------------------------ */
                /*  Domain detail screen routes                                       */
                /* ------------------------------------------------------------------ */
                composable(
                    route = Routes.DETAIL_NETWORK,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    NetworkDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                composable(
                    route = Routes.DETAIL_BATTERY,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    BatteryDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                composable(
                    route = Routes.DETAIL_GAMING,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    GamingDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }

                composable(
                    route = Routes.DETAIL_THERMAL,
                    arguments = listOf(navArgument("subFeature") { type = NavType.StringType }),
                ) { entry ->
                    val subFeature = entry.arguments?.getString("subFeature") ?: ""
                    ThermalDetailScreen(
                        subFeature = subFeature,
                        onBack = { navController.popBackStack() },
                        onNavigate = { navController.navigate(it) },
                    )
                }
            }
        }
    }

    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = { Text("Cancel this run?") },
            text = { Text("Live measurements will be discarded. Partial results are not scored.") },
            confirmButton = {
                TextButton(onClick = {
                    SessionState.cancelRun()
                    showCancelDialog = false
                }) { Text("Discard run") }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) { Text("Keep running") }
            },
        )
    }
}
