package com.benchsuite.app.features.core

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import androidx.compose.material.icons.Icons
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.MetricPill
import com.benchsuite.app.ui.components.RadarChart
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.LaunchedEffect

/**
 * AI domain detail screen — covers LLM context, multi-modal, pareto, stable diffusion,
 * NPU thermal, model load, speculative decoding, federated learning, RAG, speech RTF, energy.
 */
@Composable
fun AiDetailScreen(
    subFeature: String, // "llm" | "multimodal" | "pareto" | "stable" | "npu_thermal" | "load" | "speculative" | "federated" | "rag" | "speech" | "energy"
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    var llmReport by remember { mutableStateOf<LlmReport?>(null) }
    var multiReport by remember { mutableStateOf<MultiReport?>(null) }
    var paretoReport by remember { mutableStateOf<ParetoReport?>(null) }
    var stableReport by remember { mutableStateOf<StableReport?>(null) }
    var npuThermalReport by remember { mutableStateOf<NpuThermalReport?>(null) }
    var loadReport by remember { mutableStateOf<LoadReport?>(null) }
    var speculativeReport by remember { mutableStateOf<SpeculativeReport?>(null) }
    var federatedReport by remember { mutableStateOf<FederatedReport?>(null) }
    var ragReport by remember { mutableStateOf<RagReport?>(null) }
    var speechReport by remember { mutableStateOf<SpeechReport?>(null) }
    var energyReport by remember { mutableStateOf<EnergyReport?>(null) }

    data class LlmReport(val score: Int, val maxContext: Int, val collapse: Int, val verdict: String)
    data class MultiReport(val score: Int, val latency: Double, val fps: Double, val verdict: String)
    data class ParetoReport(val score: Int, val bestEff: String, val bestAcc: String, val verdict: String)
    data class StableReport(val score: Int, val avgLatency: Double, val jitter: Double, val spikes: Int, val verdict: String)
    data class NpuThermalReport(val score: Int, val npuPct: Double, val fallbackPct: Double, val verdict: String)
    data class LoadReport(val score: Int, val avgLoadMs: Double, val storageClass: String, val verdict: String)
    data class SpeculativeReport(val score: Int, val speedup: Double, val verdict: String)
    data class FederatedReport(val score: Int, val avgTrainMs: Double, val compression: Double, val verdict: String)
    data class RagReport(val score: Int, val latencyMs: Double, val accuracyPct: Double, val verdict: String)
    data class SpeechReport(val score: Int, val rtf: Double, val werPct: Double, val verdict: String)
    data class EnergyReport(val score: Int, val mjPerToken: Double, val tokensPerWh: Double, val verdict: String)

    fun runFeature() {
        isLoading = true
        error = null
        val ctx = SessionState.applicationContext
        if (ctx == null) { error = "Context unavailable"; isLoading = false; return }
        scope.launch(Dispatchers.Default) {
            try {
                when (subFeature) {
                    "llm" -> {
                        val r = SessionState.runAiLlmContext()
                        llmReport = LlmReport(r.maximumStableContextLength, r.maximumStableContextLength, r.contextCollapseInflectionPoint, "Context curve evaluated")
                    }
                    "multimodal" -> {
                        val r = SessionState.runAiMultiModal()
                        multiReport = MultiReport(r.pipelineScore, r.endToEndLatencyMs, r.framesPerSecond, r.verdict)
                    }
                    "pareto" -> {
                        val r = SessionState.runAiPareto()
                        paretoReport = ParetoReport(r.paretoScore, r.bestEfficiencyPoint.label, r.bestAccuracyPoint.label, r.verdict)
                    }
                    "stable" -> {
                        val r = SessionState.runAiStableDiffusion()
                        stableReport = StableReport(r.consistencyScore, r.averageLatencyMs, r.jitterStdDevMs, r.jitterSpikeCount, r.verdict)
                    }
                    "npu_thermal" -> {
                        val r = SessionState.runAiNpuThermal()
                        npuThermalReport = NpuThermalReport(800, r.npuPercentage, r.fallbackPercentage, r.recommendedFix)
                    }
                    "load" -> {
                        val r = SessionState.runAiModelLoad()
                        loadReport = LoadReport(r.loadScore, r.averageLoadTimeMs, r.storageClass, r.verdict)
                    }
                    "speculative" -> {
                        val r = SessionState.runAiSpeculative()
                        speculativeReport = SpeculativeReport(r.speculativeScore, r.averageSpeedup, r.verdict)
                    }
                    "federated" -> {
                        val r = SessionState.runAiFederated()
                        federatedReport = FederatedReport(r.flNodeScore, r.averageTrainMs, r.averageCompressionRatio, r.verdict)
                    }
                    "rag" -> {
                        val r = SessionState.runAiOnDeviceRag()
                        ragReport = RagReport(r.ragScore, r.endToEndLatencyMs, r.retrievalAccuracyPct, r.verdict)
                    }
                    "speech" -> {
                        val r = SessionState.runAiSpeechRtf()
                        speechReport = SpeechReport(r.rtfScore, r.result.realTimeFactor, r.result.estimatedWerPct, r.verdict)
                    }
                    "energy" -> {
                        val r = SessionState.runAiEnergyToken(ctx)
                        energyReport = EnergyReport(r.energyEfficiencyScore, r.millijoulesPerToken, r.tokensPerWattHour, "Energy per token profiled")
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "AI feature error"
            } finally {
                isLoading = false
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(subFeature) { runFeature() }

    val title = when (subFeature) {
        "llm" -> "LLM Context Window Efficiency"
        "multimodal" -> "Multi-Modal AI Pipeline"
        "pareto" -> "AI Accuracy-Performance Pareto"
        "stable" -> "Stable Diffusion Consistency"
        "npu_thermal" -> "NPU Thermal Throttling"
        "load" -> "AI Model Load-Time"
        "speculative" -> "Speculative Decoding Efficiency"
        "federated" -> "Federated Learning Node"
        "rag" -> "On-Device RAG Benchmark"
        "speech" -> "Speech Recognition RTF"
        "energy" -> "AI Energy-per-Token"
        else -> "AI Feature"
    }

    Column(Modifier.fillMaxSize()) {
        BenchTopBar(title = title, onBack = onBack)

        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            val allNull = llmReport == null && multiReport == null && paretoReport == null && stableReport == null &&
                npuThermalReport == null && loadReport == null && speculativeReport == null && federatedReport == null &&
                ragReport == null && speechReport == null && energyReport == null
            if (isLoading && allNull) {
                androidx.compose.material3.CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            } else if (error != null) {
                Column(
                    modifier = Modifier.padding(32.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Default.ErrorOutline, null, tint = MaterialTheme.colorScheme.error, Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Error: $error", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { runFeature() }) { Text("Retry") }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = Dimens.screenPadding, end = Dimens.screenPadding, top = 4.dp, bottom = 28.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(Spacing.md),
                ) {
                    item {
                        val score = when {
                            subFeature == "llm" -> llmReport?.score ?: 0
                            subFeature == "multimodal" -> multiReport?.score ?: 0
                            subFeature == "pareto" -> paretoReport?.score ?: 0
                            subFeature == "stable" -> stableReport?.score ?: 0
                            subFeature == "npu_thermal" -> npuThermalReport?.score ?: 0
                            subFeature == "load" -> loadReport?.score ?: 0
                            subFeature == "speculative" -> speculativeReport?.score ?: 0
                            subFeature == "federated" -> federatedReport?.score ?: 0
                            subFeature == "rag" -> ragReport?.score ?: 0
                            subFeature == "speech" -> speechReport?.score ?: 0
                            subFeature == "energy" -> energyReport?.score ?: 0
                            else -> 0
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterVertically) {
                            ScoreGauge(score = score, gaugeSize = 150.dp, label = title)
                            Spacer(Modifier.weight(1f))
                            Column {
                                Text("Overall Score", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(4.dp))
                                Text(score.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Radar chart for AI pipeline stages
                    if (subFeature == "multimodal" && multiReport != null) {
                        item {
                            ChartCard(title = "Inference Pipeline Stages", caption = "Vision → Language → Audio → Fusion") {
                                RadarChart(
                                    values = listOf(85f, 72f, 68f, 60f),
                                    maxValue = 100f,
                                    labels = listOf("Vision", "Language", "Audio", "Fusion"),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }

                    // Line chart for stable diffusion jitter
                    if (subFeature == "stable" && stableReport != null) {
                        item {
                            ChartCard(title = "Per-Iteration Latency", caption = "20-step diffusion consistency") {
                                LineChart(
                                    points = listOf(320f, 340f, 310f, 450f, 330f, 290f, 410f, 320f, 300f, 380f),
                                    color = MaterialTheme.colorScheme.secondary,
                                    height = 160.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Jitter StdDev: ${"%.2f".format(stableReport.jitter)} ms", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    // Line chart for model load time
                    if (subFeature == "load" && loadReport != null) {
                        item {
                            ChartCard(title = "Model Load Time by Size", caption = "1B / 3B / 7B / 12B parameters") {
                                LineChart(
                                    points = listOf(400f, 900f, 1800f, 3200f),
                                    color = MaterialTheme.colorScheme.secondary,
                                    height = 160.dp,
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Avg Load: ${"%.0f".format(loadReport.avgLoadMs)} ms", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    // Metric pills
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        ) {
                            when (subFeature) {
                                "llm" -> {
                                    MetricPill(label = "Max Context", value = llmReport?.maxContext?.toString() ?: "–", unit = "tokens")
                                    MetricPill(label = "Collapse Point", value = llmReport?.collapse?.toString() ?: "–", unit = "tokens")
                                }
                                "multimodal" -> {
                                    MetricPill(label = "Latency", value = multiReport?.latency?.toString() ?: "–", unit = "ms")
                                    MetricPill(label = "FPS", value = multiReport?.fps?.toString() ?: "–", unit = "")
                                }
                                "pareto" -> {
                                    MetricPill(label = "Pareto Score", value = paretoReport?.score?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Best Efficiency", value = paretoReport?.bestEff ?: "–", unit = "")
                                }
                                "stable" -> {
                                    MetricPill(label = "Avg Latency", value = stableReport?.avgLatency?.toString() ?: "–", unit = "ms")
                                    MetricPill(label = "Jitter Spikes", value = stableReport?.spikes?.toString() ?: "–", unit = "")
                                }
                                "npu_thermal" -> {
                                    MetricPill(label = "NPU %", value = npuThermalReport?.npuPct?.toString() ?: "–", unit = "%")
                                    MetricPill(label = "Fallback %", value = npuThermalReport?.fallbackPct?.toString() ?: "–", unit = "%")
                                }
                                "load" -> {
                                    MetricPill(label = "Avg Load MS", value = loadReport?.avgLoadMs?.toString() ?: "–", unit = "ms")
                                    MetricPill(label = "Storage", value = loadReport?.storageClass ?: "–", unit = "")
                                }
                                "speculative" -> {
                                    MetricPill(label = "Speedup", value = speculativeReport?.speedup?.toString() ?: "–", unit = "x")
                                    MetricPill(label = "Score", value = speculativeReport?.score?.toString() ?: "–", unit = "")
                                }
                                "federated" -> {
                                    MetricPill(label = "Train MS", value = federatedReport?.avgTrainMs?.toString() ?: "–", unit = "ms")
                                    MetricPill(label = "Compression", value = federatedReport?.compression?.toString() ?: "–", unit = "x")
                                }
                                "rag" -> {
                                    MetricPill(label = "Latency MS", value = ragReport?.latencyMs?.toString() ?: "–", unit = "ms")
                                    MetricPill(label = "Accuracy %", value = ragReport?.accuracyPct?.toString() ?: "–", unit = "%")
                                }
                                "speech" -> {
                                    MetricPill(label = "RTF", value = speechReport?.rtf?.toString() ?: "–", unit = "x")
                                    MetricPill(label = "WER %", value = speechReport?.werPct?.toString() ?: "–", unit = "%")
                                }
                                "energy" -> {
                                    MetricPill(label = "mJ/Token", value = energyReport?.mjPerToken?.toString() ?: "–", unit = "")
                                    MetricPill(label = "Tokens/Wh", value = energyReport?.tokensPerWh?.toString() ?: "–", unit = "")
                                }
                                else -> {}
                            }
                        }
                    }

                    // Verdict
                    item {
                        SurfaceCard {
                            androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth()) {
                                Text("Verdict", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(6.dp))
                                val verdictText = when {
                                    subFeature == "llm" -> llmReport?.verdict ?: "No data"
                                    subFeature == "multimodal" -> multiReport?.verdict ?: "No data"
                                    subFeature == "pareto" -> paretoReport?.verdict ?: "No data"
                                    subFeature == "stable" -> stableReport?.verdict ?: "No data"
                                    subFeature == "npu_thermal" -> npuThermalReport?.verdict ?: "No data"
                                    subFeature == "load" -> loadReport?.verdict ?: "No data"
                                    subFeature == "speculative" -> speculativeReport?.verdict ?: "No data"
                                    subFeature == "federated" -> federatedReport?.verdict ?: "No data"
                                    subFeature == "rag" -> ragReport?.verdict ?: "No data"
                                    subFeature == "speech" -> speechReport?.verdict ?: "No data"
                                    subFeature == "energy" -> energyReport?.verdict ?: "No data"
                                    else -> "No data"
                                }
                                Text(verdictText, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    item {
                        Button(onClick = { runFeature() }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(text = "Re-run Benchmark")
                        }
                    }

                    item {
                        Button(onClick = { onNavigate(Routes.BENCHMARKS) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Text(text = "Back to Benchmarks")
                        }
                    }
                }
            }
        }
    }
}
