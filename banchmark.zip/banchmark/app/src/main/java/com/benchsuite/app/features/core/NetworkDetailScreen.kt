package com.benchsuite.app.features.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.benchsuite.app.ui.state.SessionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Network domain deep-dive.
 *
 * Sub-features: wifi7_mlo, urllc, satellite_sos, uwb, esim, le_audio,
 * handover, bufferbloat, modem_thermal, wifi_roaming.
 */
@Composable
fun NetworkDetailScreen(
    subFeature: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<DomainDetailResult?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        val ctx = SessionState.applicationContext
        if (ctx == null) {
            error = "Application context unavailable"
            return
        }
        isLoading = true
        error = null
        scope.launch(Dispatchers.Default) {
            runCatching { measure(subFeature, ctx) }
                .onSuccess { result = it }
                .onFailure { error = it.message ?: "Network feature failed" }
            isLoading = false
        }
    }

    LaunchedEffect(subFeature) { load() }

    DomainDetailScaffold(
        title = titleFor(subFeature),
        subtitle = "Network · measured on this device",
        result = result,
        isLoading = isLoading,
        error = error,
        onRetry = { load() },
        onBack = onBack,
        onNavigate = onNavigate,
    )
}

private fun titleFor(subFeature: String): String = when (subFeature) {
    "wifi7_mlo" -> "Wi-Fi 7 MLO consistency"
    "urllc" -> "5G Advanced URLLC latency"
    "satellite_sos" -> "Satellite SOS time-to-rescue"
    "uwb" -> "UWB precision & security"
    "esim" -> "eSIM profile switching"
    "le_audio" -> "Bluetooth LE Audio latency"
    "handover" -> "Network handover behaviour"
    "bufferbloat" -> "Bufferbloat & loaded latency"
    "modem_thermal" -> "Cellular modem thermal & power"
    "wifi_roaming" -> "Wi-Fi roaming stability"
    else -> "Network feature"
}

private fun measure(subFeature: String, ctx: android.content.Context): DomainDetailResult =
    when (subFeature) {
        "wifi7_mlo" -> {
            val r = SessionState.runNetworkWifi7Mlo(ctx)
            DomainDetailResult(
                score = r.consistencyScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Mode", r.mloMode),
                    DetailMetric("Active links", r.activeLinks.size.toString()),
                    DetailMetric("Aggregate", r.aggregateTheoreticalMbps.toString(), "Mbps"),
                    DetailMetric("Efficiency", fmt(r.effectiveThroughputEfficiencyPct), "%"),
                    DetailMetric("P99 latency", fmt(r.latencyDistribution.p99Ms), "ms"),
                    DetailMetric("Jitter", fmt(r.latencyDistribution.jitterMs, 2), "ms"),
                ),
                radar = listOf(
                    r.consistencyScore.toFloat(),
                    r.handoverMetrics.roamingSwitchScore.toFloat(),
                    r.effectiveThroughputEfficiencyPct.toFloat().coerceIn(0f, 100f),
                    (100f - r.latencyDistribution.jitterMs.toFloat() * 5f).coerceIn(0f, 100f),
                    (r.activeLinks.size * 20f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Consistency", "Roaming", "Efficiency", "Latency", "Links"),
                radarMax = 100f,
                radarTitle = "MLO link quality",
                radarCaption = "Consistency, roaming, efficiency, latency stability, link count",
                chartTitle = "Per-link throughput",
                chartCaption = "Tx throughput reported per active MLO link",
                chartSeries = r.activeLinks.map { it.txSpeedMbps.toFloat() }.ifEmpty { listOf(0f) },
                chartSeries2 = r.activeLinks.map { it.rxSpeedMbps.toFloat() },
                chartUnit = "Mbps",
                distributionTitle = "Latency distribution",
                distributionCaption = "Min → P99 buckets from the MLO probe",
                distribution = r.latencyDistribution.asBuckets(),
                distributionFooter = listOf(
                    "P50" to "${fmt(r.latencyDistribution.p50Ms)} ms",
                    "P90" to "${fmt(r.latencyDistribution.p90Ms)} ms",
                    "Max" to "${fmt(r.latencyDistribution.maxMs)} ms",
                ),
            )
        }

        "urllc" -> {
            val r = SessionState.runNetworkUrllc(ctx)
            DomainDetailResult(
                score = r.urllcReadinessScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Slice", r.topology.networkSliceType),
                    DetailMetric("5QI", r.topology.fiveQiCategory.toString()),
                    DetailMetric("Slot", fmt(r.topology.slotDurationMs, 3), "ms"),
                    DetailMetric("P50 RTT", fmt(r.latencyMetrics.p50RttMs, 2), "ms"),
                    DetailMetric("P99 RTT", fmt(r.latencyMetrics.p99RttMs, 2), "ms"),
                    DetailMetric("Loss", fmt(r.latencyMetrics.packetLossRatePct, 3), "%"),
                ),
                radar = listOf(
                    r.urllcReadinessScore.toFloat(),
                    (100f - r.latencyMetrics.p99RttMs.toFloat()).coerceIn(0f, 100f),
                    (100f - r.latencyMetrics.meanJitterMs.toFloat() * 5f).coerceIn(0f, 100f),
                    (100f - r.latencyMetrics.packetLossRatePct.toFloat() * 1000f).coerceIn(0f, 100f),
                    if (r.latencyMetrics.isFiveNinesReliable) 100f else 55f,
                ),
                radarLabels = listOf("Readiness", "P99 RTT", "Jitter", "Reliability", "5NINES"),
                radarMax = 100f,
                radarTitle = "URLLC characteristics",
                radarCaption = "Deterministic latency and reliability profile",
                chartTitle = "RTT curve",
                chartCaption = "Min → P99.9 round-trip latency",
                chartSeries = listOf(
                    r.latencyMetrics.minRttMs.toFloat(),
                    r.latencyMetrics.p50RttMs.toFloat(),
                    r.latencyMetrics.p90RttMs.toFloat(),
                    r.latencyMetrics.p99RttMs.toFloat(),
                    r.latencyMetrics.p999RttMs.toFloat(),
                ),
                chartUnit = "ms",
                distributionTitle = "Reliability buckets",
                distributionCaption = "Relative weight of each RTT percentile",
                distribution = listOf(
                    r.latencyMetrics.minRttMs,
                    r.latencyMetrics.p50RttMs,
                    r.latencyMetrics.p90RttMs,
                    r.latencyMetrics.p99RttMs,
                ).map { (it * 10).toInt().coerceIn(0, 500) },
                distributionFooter = listOf(
                    "Loss" to "${fmt(r.latencyMetrics.packetLossRatePct, 3)} %",
                    "Jitter" to "${fmt(r.latencyMetrics.meanJitterMs, 2)} ms",
                ),
            )
        }

        "satellite_sos" -> {
            val r = SessionState.runNetworkSatelliteSos(ctx)
            DomainDetailResult(
                score = r.sosScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Capability", r.capability.name),
                    DetailMetric("Total", fmt(r.totalTimeToRescueMs, 0), "ms"),
                    DetailMetric("Sky scan", fmt(r.skyScanMs, 0), "ms"),
                    DetailMetric("Acquisition", fmt(r.acquisitionMs, 0), "ms"),
                    DetailMetric("Transmission", fmt(r.transmissionMs, 0), "ms"),
                    DetailMetric("Threshold", if (r.meetsEmergencyThreshold) "Met" else "Missed"),
                ),
                radar = listOf(
                    r.sosScore / 10f,
                    (100f - r.skyScanMs.toFloat() / 100f).coerceIn(0f, 100f),
                    (100f - r.acquisitionMs.toFloat() / 100f).coerceIn(0f, 100f),
                    if (r.meetsEmergencyThreshold) 100f else 40f,
                    (r.phases.size * 20f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Sky scan", "Acquire", "Threshold", "Phases"),
                radarMax = 100f,
                radarTitle = "Rescue path readiness",
                radarCaption = "Where time is spent before a message can leave the device",
                chartTitle = "Phase timing",
                chartCaption = "Duration of every SOS phase",
                chartSeries = r.phases.map { it.durationMs.toFloat() },
                chartUnit = "ms",
                distributionTitle = "Phase duration distribution",
                distributionCaption = "Longest phases first",
                distribution = r.phases.sortedByDescending { it.durationMs }
                    .map { (it.durationMs / 10).toInt().coerceIn(0, 500) },
                distributionFooter = r.phases.map { it.phaseName to "${fmt(it.durationMs, 0)} ms" },
            )
        }

        "uwb" -> {
            val r = SessionState.runNetworkUwb(ctx)
            DomainDetailResult(
                score = r.compositePrecisionScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Chip", r.capabilities.chipFamily),
                    DetailMetric("Channels", r.capabilities.supportedChannels.joinToString("/")),
                    DetailMetric("P95 error", fmt(r.rangingMetrics.p95ErrorMarginCm, 1), "cm"),
                    DetailMetric("σ distance", fmt(r.rangingMetrics.standardDeviationCm, 1), "cm"),
                    DetailMetric("Azimuth σ", fmt(r.aoaMetrics.azimuthStdDevDegrees, 2), "°"),
                    DetailMetric("STS", r.securityMetrics.stsModeActive),
                ),
                radar = listOf(
                    r.compositePrecisionScore.toFloat(),
                    (100f - r.rangingMetrics.p95ErrorMarginCm.toFloat()).coerceIn(0f, 100f),
                    r.securityMetrics.relayAttackResilienceScore.toFloat(),
                    (r.aoaMetrics.pdoaPhaseCoherenceScore * 100f).coerceIn(0f, 100f),
                    (100f - r.aoaMetrics.azimuthStdDevDegrees.toFloat() * 10f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Precision", "Error", "Security", "Coherence", "AoA"),
                radarMax = 100f,
                radarTitle = "Ranging quality",
                radarCaption = "Distance accuracy, angle stability and relay-attack resistance",
                chartTitle = "Distance error profile",
                chartCaption = "Reported ranging statistics",
                chartSeries = listOf(
                    r.rangingMetrics.meanDistanceMeters.toFloat(),
                    r.rangingMetrics.standardDeviationCm.toFloat(),
                    r.rangingMetrics.p95ErrorMarginCm.toFloat(),
                ),
                chartUnit = "cm",
                distributionTitle = "Error margin buckets",
                distributionCaption = "σ, P95 and multipath rejection scaled for comparison",
                distribution = listOf(
                    r.rangingMetrics.standardDeviationCm,
                    r.rangingMetrics.p95ErrorMarginCm,
                    r.rangingMetrics.multiPathRejectionRatioDb,
                    r.aoaMetrics.azimuthStdDevDegrees,
                ).map { (it * 10).toInt().coerceIn(0, 500) },
                distributionFooter = listOf(
                    "Multipath rejection" to "${fmt(r.rangingMetrics.multiPathRejectionRatioDb)} dB",
                    "Timestamp tamper" to if (r.securityMetrics.timestampTamperDetected) "Detected" else "None",
                ),
            )
        }

        "esim" -> {
            val r = SessionState.runNetworkEsim(ctx)
            DomainDetailResult(
                score = r.esimScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Capability", r.capability.name),
                    DetailMetric("Total switch", fmt(r.totalSwitchMs, 0), "ms"),
                    DetailMetric("Download", fmt(r.downloadMs, 0), "ms"),
                    DetailMetric("Activate", fmt(r.activateMs, 0), "ms"),
                    DetailMetric("Handover", fmt(r.handoverMs, 0), "ms"),
                ),
                radar = listOf(
                    r.esimScore / 10f,
                    (100f - r.downloadMs.toFloat() / 100f).coerceIn(0f, 100f),
                    (100f - r.activateMs.toFloat() / 100f).coerceIn(0f, 100f),
                    (100f - r.handoverMs.toFloat() / 100f).coerceIn(0f, 100f),
                    (r.stages.size * 20f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Download", "Activate", "Handover", "Stages"),
                radarMax = 100f,
                radarTitle = "Profile switch quality",
                radarCaption = "How each eSIM stage contributes to the final score",
                chartTitle = "Stage timing",
                chartCaption = "Download → activation → network handover",
                chartSeries = r.stages.map { it.durationMs.toFloat() },
                chartUnit = "ms",
                distributionTitle = "Stage distribution",
                distributionCaption = "Each stage scaled to a comparable bucket",
                distribution = r.stages.map { (it.durationMs / 10).toInt().coerceIn(0, 500) },
                distributionFooter = r.stages.map { it.stageName to "${fmt(it.durationMs, 0)} ms" },
            )
        }

        "le_audio" -> {
            val r = SessionState.runNetworkLeAudio(ctx)
            DomainDetailResult(
                score = r.leAudioScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Device", r.deviceName),
                    DetailMetric("Codec", if (r.result.lc3Supported) "LC3" else "Legacy"),
                    DetailMetric("Latency", fmt(r.result.endToEndLatencyMs, 0), "ms"),
                    DetailMetric("Auracast", if (r.result.auracastSupported) "Yes" else "No"),
                    DetailMetric("Concealment", fmt(r.result.packetLossConcealment, 2)),
                    DetailMetric("Gaming ready", if (r.result.isGamingReady) "Yes" else "No"),
                ),
                radar = listOf(
                    r.leAudioScore / 10f,
                    (100f - r.result.endToEndLatencyMs.toFloat()).coerceIn(0f, 100f),
                    if (r.result.lc3Supported) 100f else 40f,
                    if (r.result.auracastSupported) 100f else 40f,
                    (r.result.packetLossConcealment * 100f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Latency", "LC3", "Auracast", "Concealment"),
                radarMax = 100f,
                radarTitle = "Audio pipeline quality",
                radarCaption = "Codec, latency and broadcast support",
                chartTitle = "Latency comparison",
                chartCaption = "End-to-end LE Audio latency against the classic A2DP baseline",
                chartSeries = listOf(r.result.endToEndLatencyMs.toFloat(), 140f),
                chartUnit = "ms",
            )
        }

        "handover" -> {
            val r = SessionState.runNetworkWifi7Mlo(ctx)
            val h = r.handoverMetrics
            DomainDetailResult(
                score = h.roamingSwitchScore,
                verdict = if (h.isZeroLossSeamless) {
                    "Seamless zero-loss handover detected during the MLO run."
                } else {
                    "Handover completed with ${h.packetLossBurstCount} loss burst(s)."
                },
                metrics = listOf(
                    DetailMetric("Transition", fmt(h.transitionDurationMs, 0), "ms"),
                    DetailMetric("Loss bursts", h.packetLossBurstCount.toString()),
                    DetailMetric("Jitter spike", fmt(h.jitterSpikeMs, 2), "ms"),
                    DetailMetric("Seamless", if (h.isZeroLossSeamless) "Yes" else "No"),
                ),
                radar = listOf(
                    h.roamingSwitchScore.toFloat(),
                    (100f - h.transitionDurationMs.toFloat()).coerceIn(0f, 100f),
                    (100f - h.jitterSpikeMs.toFloat()).coerceIn(0f, 100f),
                    if (h.isZeroLossSeamless) 100f else 45f,
                    r.consistencyScore.toFloat(),
                ),
                radarLabels = listOf("Switch score", "Duration", "Jitter", "Zero-loss", "Consistency"),
                radarMax = 100f,
                radarTitle = "Handover quality",
                radarCaption = "Derived from the Wi-Fi 7 MLO handover probe",
                chartTitle = "Handover cost",
                chartCaption = "Transition time vs jitter spike",
                chartSeries = listOf(h.transitionDurationMs.toFloat(), h.jitterSpikeMs.toFloat()),
                chartUnit = "ms",
            )
        }

        "bufferbloat" -> {
            val r = SessionState.runNetworkBufferbloat()
            DomainDetailResult(
                score = r.score,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Idle latency", fmt(r.idleLatencyMs), "ms"),
                    DetailMetric("Download loaded", fmt(r.loadedDownloadLatencyMs), "ms"),
                    DetailMetric("Upload loaded", fmt(r.loadedUploadLatencyMs), "ms"),
                    DetailMetric("Bufferbloat", fmt(r.bufferbloatMs), "ms"),
                    DetailMetric("Grade", r.grade),
                ),
                radar = listOf(
                    r.score / 10f,
                    (100f - r.idleLatencyMs.toFloat()).coerceIn(0f, 100f),
                    (100f - r.loadedDownloadLatencyMs.toFloat() / 2f).coerceIn(0f, 100f),
                    (100f - r.loadedUploadLatencyMs.toFloat() / 2f).coerceIn(0f, 100f),
                    (100f - r.bufferbloatMs.toFloat()).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Idle", "Download", "Upload", "Bloat"),
                radarMax = 100f,
                radarTitle = "Latency under load",
                radarCaption = "Idle vs saturated download and upload",
                chartTitle = "Latency per sample",
                chartCaption = "Average latency recorded for each load state",
                chartSeries = r.samples.map { it.avgMs.toFloat() },
                chartSeries2 = r.samples.map { it.p99Ms.toFloat() },
                chartUnit = "ms",
                distributionTitle = "P99 spread",
                distributionCaption = "Tail latency per load state",
                distribution = r.samples.map { it.p99Ms.toInt().coerceIn(0, 500) },
                distributionFooter = r.samples.map { it.label to "${fmt(it.p99Ms)} ms P99" },
            )
        }

        "modem_thermal" -> {
            val r = SessionState.runNetworkModemThermal(ctx)
            DomainDetailResult(
                score = r.modemScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Network", r.networkType),
                    DetailMetric("Avg throughput", fmt(r.averageThroughputMbps), "Mbps"),
                    DetailMetric("Peak temp", fmt(r.peakTempCelsius), "°C"),
                    DetailMetric("Avg current", fmt(r.averageCurrentMa, 0), "mA"),
                    DetailMetric("Throttling", if (r.throttlingDetected) "Detected" else "None"),
                ),
                radar = listOf(
                    r.modemScore / 10f,
                    (r.averageThroughputMbps.toFloat() / 5f).coerceIn(0f, 100f),
                    (100f - r.peakTempCelsius.toFloat()).coerceIn(0f, 100f),
                    if (r.throttlingDetected) 40f else 100f,
                    (100f - r.averageCurrentMa.toFloat() / 20f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Throughput", "Thermals", "Sustained", "Power"),
                radarMax = 100f,
                radarTitle = "Modem behaviour under load",
                radarCaption = "Throughput, thermal headroom, throttling and current draw",
                chartTitle = "Throughput over time",
                chartCaption = "Sustained transfer samples",
                chartSeries = r.samples.map { it.throughputMbps.toFloat() },
                chartUnit = "Mbps",
                distributionTitle = "Temperature buckets",
                distributionCaption = "Each sample bucket in °C × 10",
                distribution = r.samples.map { (it.tempCelsius * 10).toInt().coerceIn(0, 500) },
                distributionFooter = listOf(
                    "Signal" to "${r.samples.lastOrNull()?.signalDbm ?: 0} dBm",
                    "Peak" to "${fmt(r.peakTempCelsius)} °C",
                ),
            )
        }

        "wifi_roaming" -> {
            val r = SessionState.runNetworkWifiRoaming(ctx)
            DomainDetailResult(
                score = r.roamingScore,
                verdict = r.verdict,
                metrics = listOf(
                    DetailMetric("Wi-Fi", if (r.wifiSupported) "Supported" else "Unavailable"),
                    DetailMetric("Fast roaming", if (r.fastRoamingSupported) "802.11k/v/r" else "Not detected"),
                    DetailMetric("Avg handoff", fmt(r.averageHandoffMs, 0), "ms"),
                    DetailMetric("Avg loss", fmt(r.averagePacketLossPct, 2), "%"),
                    DetailMetric("APs seen", r.samples.size.toString()),
                ),
                radar = listOf(
                    r.roamingScore / 10f,
                    (100f - r.averageHandoffMs.toFloat()).coerceIn(0f, 100f),
                    (100f - r.averagePacketLossPct.toFloat() * 10f).coerceIn(0f, 100f),
                    if (r.fastRoamingSupported) 100f else 45f,
                    (r.samples.size * 25f).coerceIn(0f, 100f),
                ),
                radarLabels = listOf("Score", "Handoff", "Loss", "Fast roam", "Coverage"),
                radarMax = 100f,
                radarTitle = "Roaming stability",
                radarCaption = "Handoff time, packet loss and 802.11k/v/r support",
                chartTitle = "Handoff time per AP",
                chartCaption = "How long each access-point transition takes",
                chartSeries = r.samples.map { it.handoffMs.toFloat() },
                chartUnit = "ms",
                distributionTitle = "RSSI per access point",
                distributionCaption = "Signal strength buckets measured during the roam",
                distribution = r.samples.map { (it.rssiDbm + 100).coerceIn(0, 500) },
                distributionFooter = r.samples.map { it.apName to "${it.rssiDbm} dBm" },
            )
        }

        else -> DomainDetailResult(
            score = 0,
            verdict = "Unknown network sub-feature: $subFeature",
        )
    }

/** Turns a latency distribution into histogram buckets, clamped for display. */
private fun com.benchsuite.app.engine.network.Wifi7MloBenchmark.LatencyDistribution.asBuckets(): List<Int> =
    listOf(minMs, p50Ms, p90Ms, p99Ms, p999Ms, maxMs)
        .map { (it * 10).toInt().coerceIn(0, 500) }
