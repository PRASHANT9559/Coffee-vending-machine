package com.benchsuite.app.features.insight

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Recommend
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.Insight
import com.benchsuite.app.data.model.InsightSeverity
import com.benchsuite.app.data.model.bandFor
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.CategoryBarRow
import com.benchsuite.app.ui.components.FilterPills
import com.benchsuite.app.ui.components.InsightCard
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.severityColor
import com.benchsuite.app.ui.components.severityIcon
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing

private val insightFilters = listOf("All", "Strengths", "Warnings", "Critical", "Info")

@Composable
fun InsightsScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var filter by rememberSaveable { mutableIntStateOf(0) }

    val runInsights: List<Insight> = SessionState.latestRecordedRunOrNull
        ?.let { SessionState.getInsights(it) } ?: emptyList()
    val filtered: List<Insight> = when (filter) {
        1 -> runInsights.filter { it.severity == InsightSeverity.STRENGTH }
        2 -> runInsights.filter { it.severity == InsightSeverity.WARNING }
        3 -> runInsights.filter { it.severity == InsightSeverity.CRITICAL }
        4 -> runInsights.filter { it.severity == InsightSeverity.INFO }
        else -> runInsights
    }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "AI insights",
            subtitle = SessionState.latestRecordedRunOrNull?.let { "Generated from run ${it.id}" } ?: "Run a benchmark first",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Explain, don't just score",
                    title = "What the numbers mean.",
                    body = "Every observation is tied to a measurement. No generic advice, no guesses.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(42.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(21.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${filtered.size} findings", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${filtered.count { it.severity == InsightSeverity.STRENGTH }} strengths · ${filtered.count { it.severity == InsightSeverity.WARNING }} warnings · ${filtered.count { it.severity == InsightSeverity.CRITICAL }} critical · ${filtered.count { it.severity == InsightSeverity.INFO }} info",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusChip("2 strengths", tint = BenchTheme.colors.success)
                        StatusChip("2 warnings", tint = BenchTheme.colors.warning)
                        StatusChip("1 critical", tint = BenchTheme.colors.danger)
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Text(
                        "Headline: insights are computed from your real measurements. Run a benchmark to see findings for this device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                SurfaceCard {
                    Text("Primary bottleneck", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    val runForBottleneck = SessionState.latestRecordedRunOrNull
                    if (runForBottleneck != null) {
                        Text(
                            "Thermal envelope · sustained performance",
                            style = MaterialTheme.typography.headlineSmall,
                            color = BenchTheme.colors.warning,
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Peak ${runForBottleneck.categories.maxOfOrNull { it.score }?.toString() ?: "—"} → sustained ${runForBottleneck.sustained}. Conditions: ${runForBottleneck.conditions.thermalStatus}.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(Spacing.sm))
                        runForBottleneck.categories.forEachIndexed { index, category ->
                            CategoryBarRow(category)
                            if (index != runForBottleneck.categories.lastIndex) Spacer(Modifier.height(Spacing.sm))
                        }
                    } else {
                        Text(
                            "Run a benchmark to see the primary bottleneck for this device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                FilterPills(
                    options = insightFilters,
                    selectedIndex = filter,
                    onSelect = { filter = it },
                )
            }

            if (filtered.isEmpty()) {
                item {
                    SurfaceCard {
                        Text("No findings in this category.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Switch the filter to see all insights.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                items(filtered.size) { index ->
                    InsightCard(insight = filtered[index])
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Lightbulb, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("How insights are produced", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Rules compare your measurements with the class median, the reference device and your own history. A finding is promoted only when the gap exceeds the run's confidence interval.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusChip("Evidence linked", tint = BenchTheme.colors.success)
                        StatusChip("Confidence 92%", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            item {
                Button(
                    onClick = { onNavigate(Routes.RECOMMENDATIONS) },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                ) {
                    Icon(Icons.Outlined.Recommend, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("See recommended actions")
                }
            }

            item {
                Text(
                    "Insights are generated locally. Nothing is sent to a model server.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
