package com.benchsuite.app.features.core

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.ChartCard
import com.benchsuite.app.ui.components.FrameTimeHistogram
import com.benchsuite.app.ui.components.LineChart
import com.benchsuite.app.ui.components.MetricPill
import com.benchsuite.app.ui.components.RadarChart
import com.benchsuite.app.ui.components.ScoreGauge
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.Spacing

/** One number shown as a pill on a domain detail screen. */
data class DetailMetric(
    val label: String,
    val value: String,
    val unit: String = "",
    val color: Color? = null,
)

/**
 * Everything a domain detail screen needs to render.
 *
 * Engine reports use a 0..1000 sub-score scale, so [score] is displayed against
 * [maxScore] and never rescaled by hand.
 */
data class DomainDetailResult(
    val score: Int,
    val verdict: String,
    val metrics: List<DetailMetric> = emptyList(),
    val maxScore: Int = 1000,
    val radar: List<Float> = emptyList(),
    val radarLabels: List<String> = emptyList(),
    val radarTitle: String = "Subsystem breakdown",
    val radarCaption: String? = null,
    val radarMax: Float = 1000f,
    val chartTitle: String? = null,
    val chartCaption: String? = null,
    val chartSeries: List<Float> = emptyList(),
    val chartSeries2: List<Float> = emptyList(),
    val chartUnit: String = "",
    val distributionTitle: String? = null,
    val distributionCaption: String? = null,
    val distribution: List<Int> = emptyList(),
    val distributionFooter: List<Pair<String, String>> = emptyList(),
)

/** Locale-stable number formatting so charts and pills never show "1,5". */
fun fmt(value: Double, decimals: Int = 1): String =
    String.format(java.util.Locale.US, "%.${decimals}f", value)

fun fmt(value: Float, decimals: Int = 1): String = fmt(value.toDouble(), decimals)

/**
 * Shared layout for every domain deep-dive screen: score gauge, radar, one
 * optional trend chart, one optional distribution, metric pills and a verdict.
 */
@Composable
fun DomainDetailScaffold(
    title: String,
    subtitle: String?,
    result: DomainDetailResult?,
    isLoading: Boolean,
    error: String?,
    onRetry: () -> Unit,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        BenchTopBar(title = title, subtitle = subtitle, onBack = onBack)

        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            when {
                error != null -> DetailErrorState(error = error, onRetry = onRetry)

                result == null && isLoading -> CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                )

                result == null -> DetailErrorState(
                    error = "No measurements returned for this feature yet.",
                    onRetry = onRetry,
                )

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = Dimens.screenPadding,
                        end = Dimens.screenPadding,
                        top = 4.dp,
                        bottom = 28.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(Spacing.md),
                ) {
                    item { ScoreHeader(result) }

                    if (result.radar.size >= 3 && result.radarLabels.size == result.radar.size) {
                        item {
                            ChartCard(title = result.radarTitle, caption = result.radarCaption) {
                                RadarChart(
                                    values = result.radar,
                                    maxValue = result.radarMax,
                                    labels = result.radarLabels,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        }
                    }

                    if (result.chartSeries.size >= 2) {
                        item {
                            ChartCard(
                                title = result.chartTitle ?: "Measurement trend",
                                caption = result.chartCaption,
                            ) {
                                LineChart(
                                    points = result.chartSeries,
                                    secondaryPoints = result.chartSeries2.takeIf { it.size >= 2 },
                                    height = 168.dp,
                                )
                                Spacer(Modifier.height(Spacing.sm))
                                ChartFooter(result)
                            }
                        }
                    }

                    if (result.distribution.isNotEmpty()) {
                        item {
                            ChartCard(
                                title = result.distributionTitle ?: "Distribution",
                                caption = result.distributionCaption,
                            ) {
                                FrameTimeHistogram(buckets = result.distribution, height = 148.dp)
                                Spacer(Modifier.height(Spacing.sm))
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    result.distributionFooter.forEach { (label, value) ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                        ) {
                                            Text(
                                                label,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                            Text(value, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (result.metrics.isNotEmpty()) {
                        item { MetricStrip(result.metrics) }
                    }

                    item { VerdictCard(result.verdict) }

                    item {
                        Button(
                            onClick = onRetry,
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Re-run benchmark")
                        }
                    }

                    item {
                        OutlinedButton(
                            onClick = { onNavigate(Routes.BENCHMARKS) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                        ) {
                            Text("Back to benchmarks")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScoreHeader(result: DomainDetailResult) {
    SurfaceCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScoreGauge(
                score = result.score,
                maxScore = result.maxScore,
                gaugeSize = 148.dp,
                label = "of ${result.maxScore}",
            )
            Spacer(Modifier.width(Spacing.md))
            Column(Modifier.weight(1f)) {
                Text(
                    "${result.score}",
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    "sub-score on a ${result.maxScore}-point scale",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (result.metrics.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "${result.metrics.size} measurements captured",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricStrip(metrics: List<DetailMetric>) {
    Column {
        Text(
            "Key measurements",
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.padding(start = 2.dp),
        )
        Spacer(Modifier.height(Spacing.xs))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(Spacing.xs),
        ) {
            metrics.forEach { metric ->
                MetricPill(
                    label = metric.label,
                    value = metric.value,
                    unit = metric.unit,
                    color = metric.color ?: MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

@Composable
private fun ChartFooter(result: DomainDetailResult) {
    val first = result.chartSeries.firstOrNull() ?: 0f
    val last = result.chartSeries.lastOrNull() ?: 0f
    val delta = last - first
    fun withUnit(value: Float): String =
        if (result.chartUnit.isEmpty()) fmt(value) else "${fmt(value)} ${result.chartUnit}"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            "Start ${withUnit(first)}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "Now ${withUnit(last)}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            (if (delta >= 0) "+" else "") + withUnit(delta),
            style = MaterialTheme.typography.bodySmall,
            color = if (delta >= 0) BenchTheme.colors.success else BenchTheme.colors.danger,
        )
    }
}

@Composable
private fun VerdictCard(verdict: String) {
    SurfaceCard {
        Text(
            "Verdict",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            verdict.ifBlank { "No verdict available." },
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun DetailErrorState(error: String, onRetry: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            Icons.Filled.ErrorOutline,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(44.dp),
        )
        Spacer(Modifier.height(Spacing.sm))
        Text(
            error,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.error,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(Spacing.md))
        Button(onClick = onRetry) { Text("Retry") }
    }
}
