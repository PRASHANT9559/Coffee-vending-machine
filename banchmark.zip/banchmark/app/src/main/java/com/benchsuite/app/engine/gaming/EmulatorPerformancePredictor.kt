package com.benchsuite.app.engine.gaming

import com.benchsuite.app.util.*

import android.os.Build
import com.benchsuite.app.data.model.ScoreBand
import com.benchsuite.app.data.model.bandFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 12.2: Emulator Performance Predictor
 *
 * Predicts Nintendo Switch, PS2, and retro console emulation performance based on compute and
 * driver characteristics. Emulation is CPU/GPU/driver-sensitive; compatibility lists are outdated.
 *
 * Data source: hardware class detection (Build) + per-emulator performance model.
 * Limitations: No real emulator is run; predictions are a per-tier model, not fabricated measured
 * values.
 */
object EmulatorPerformancePredictor {

    enum class Console(val label: String) {
        NINTENDO_SWITCH("Nintendo Switch"),
        PLAYSTATION_2("Sony PlayStation 2"),
        GAMECUBE_WII("Nintendo GameCube / Wii"),
        NINTENDO_64("Nintendo 64"),
        PLAYSTATION_1("Sony PlayStation 1"),
        RETRO_ARCADE("Retro Arcade / MAME");
    }

    data class EmulatorPrediction(
        val console: Console,
        val playable: Boolean,
        val estimatedFps: Double,
        val compatibilityPct: Double,
        val bottleneck: String,
    )

    data class EmulatorReport(
        val deviceClass: String,
        val predictions: List<EmulatorPrediction>,
        val playableConsoleCount: Int,
        val emulatorScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun deviceTier(): String {
        val hw = Build.HARDWARE.lowercase()
        val model = Build.MODEL.lowercase()
        return when {
            hw.contains("sm8") || model.contains("galaxy s2") || model.contains("pixel 8") ||
            model.contains("pixel 9") -> "Flagship"
            hw.contains("sm7") || model.contains("galaxy a") || model.contains("pixel 7") -> "Upper-midrange"
            hw.contains("sm6") -> "Mainstream"
            else -> "Entry-level"
        }
    }

    /**
     * Predicts emulation performance per console by device tier.
     */
    fun predictEmulatorPerformance(): EmulatorReport {
        val tier = deviceTier()
        val consoles = listOf(
            Console.RETRO_ARCADE to Pair(30.0, 95.0),
            Console.PLAYSTATION_1 to Pair(30.0, 92.0),
            Console.NINTENDO_64 to Pair(30.0, 85.0),
            Console.GAMECUBE_WII to Pair(30.0, 70.0),
            Console.PLAYSTATION_2 to Pair(30.0, 60.0),
            Console.NINTENDO_SWITCH to Pair(30.0, 40.0),
        ).map { (console, (targetFps, baseCompat)) ->
            val tierFactor = when (tier) {
                "Flagship" -> 1.0
                "Upper-midrange" -> 0.7
                "Mainstream" -> 0.45
                else -> 0.25
            }
            val fps = (targetFps * tierFactor * 10.0).roundToInt() / 10.0
            val compatibility = baseCompat * tierFactor
            val playable = fps >= 20.0 && compatibility >= 50.0
            EmulatorPrediction(
                console = console,
                playable = playable,
                estimatedFps = fps.coerceAtLeast(5.0),
                compatibilityPct = (compatibility.coerceIn(0.0, 100.0) * 100.0).roundToInt() / 100.0,
                bottleneck = if (fps < 20.0) "CPU/driver bound" else "Balanced",
            )
        }

        val playableCount = predictions.count { it.playable }
        val avgFps = predictions.averageOf { it.estimatedFps }
        val score = when {
            playableCount >= 5 -> 920
            playableCount >= 4 -> 800
            playableCount >= 3 -> 660
            playableCount >= 2 -> 520
            else -> 380
        }

        val verdict = when {
            playableCount >= 5 -> "Most consoles playable; strong emulation headroom."
            playableCount >= 3 -> "Several consoles playable; Switch marginal."
            playableCount >= 1 -> "Only lightweight consoles playable."
            else -> "No console emulation playable at acceptable frame rates."
        }

        return EmulatorReport(
            deviceClass = tier,
            predictions = predictions,
            playableConsoleCount = playableCount,
            emulatorScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "No real emulator execution; predictions modeled per device tier, not measured values.",
        )
    }
}
