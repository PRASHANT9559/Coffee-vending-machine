package com.benchsuite.app.features.data

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeveloperBoard
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Smartphone
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.data.model.CapabilityItem
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.InfoRow
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.ProgressLine
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.state.SessionState
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing
import java.util.Locale

@Composable
fun DeviceInfoScreen(onBack: () -> Unit) {
    val device = SessionState.currentDevice
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Device info",
            subtitle = "${device.manufacturer} · ${device.model}",
            onBack = onBack,
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "Full hardware map",
                    title = "Know exactly what you own.",
                    body = "Detected from system properties, Vulkan queries and vendor delegates. No estimates.",
                )
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(54.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.Smartphone, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(device.model, style = MaterialTheme.typography.titleLarge)
                            Text(device.soc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(device.os, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        StatusChip("Current", tint = BenchTheme.colors.success, icon = Icons.Outlined.Verified)
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        HeroStat("RAM", device.ram, Modifier.weight(1f))
                        HeroStat("Storage", device.storage, Modifier.weight(1f))
                        HeroStat("Battery", "—", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusChip("—", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        StatusChip("—", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        StatusChip("—", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            item { SectionHeader(title = "Processor and graphics") }
            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.DeveloperBoard, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Compute", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(4.dp))
                    InfoRow("SoC", device.soc)
                    InfoRow("CPU topology", device.cpuTopology)
                    InfoRow("GPU", device.gpu)
                    InfoRow("NPU", device.npu)
                    InfoRow("Thermal zones", "${device.thermalZones} zones")
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Memory, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Memory and storage", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(4.dp))
                    InfoRow("RAM", "${device.ram} · ${device.ramType}")
                    InfoRow("Storage", "${device.storage} · ${device.storageType}")
                    InfoRow("Free space", String.format(Locale.US, "%.1f GB · 36%% of volume", device.storageFreeGb))
                    Spacer(Modifier.height(4.dp))
                    ProgressLine((device.storageFreeGb / 512.0).toFloat(), color = MaterialTheme.colorScheme.secondary, height = 5.dp)
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Smartphone, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Display", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(4.dp))
                    InfoRow("Panel", device.display)
                    InfoRow("Resolution", device.resolution)
                    InfoRow("Refresh", device.refresh)
                    InfoRow("HDR", "—")
                }
            }

            item {
                SurfaceCard {
                    Text("Battery", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    InfoRow("Capacity", device.battery)
                    InfoRow("Charging", device.charging)
                    InfoRow("Health", "${device.batteryHealthPct}% of design capacity")
                    InfoRow("Cycles", "${device.batteryCycles} charge cycles")
                    Spacer(Modifier.height(4.dp))
                    ProgressLine(device.batteryHealthPct / 100f, color = BenchTheme.colors.success, height = 5.dp)
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Shield, null, tint = BenchTheme.colors.success, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Software and security", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(4.dp))
                    InfoRow("OS", device.os)
                    InfoRow("Security patch", device.securityPatch)
                    InfoRow("Kernel", device.kernel)
                    InfoRow("Build", device.build)
                    InfoRow("Verified boot", "—")
                    InfoRow("Play Integrity", "—")
                }
            }

            item { SectionHeader(title = "Capability map", actionLabel = "${device.capabilities.count { it.supported }} of ${device.capabilities.size}") }
            item {
                SurfaceCard {
                    device.capabilities.forEachIndexed { index, capability ->
                        CapabilityRow(capability)
                        if (index != device.capabilities.lastIndex) {
                            Spacer(Modifier.height(2.dp))
                        }
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Device fingerprint", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusChip("Local only", tint = BenchTheme.colors.success)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        device.fingerprint,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                        OutlinedButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(device.fingerprint))
                                copied = true
                            },
                            modifier = Modifier.weight(1f).height(46.dp),
                        ) {
                            Icon(Icons.Outlined.ContentCopy, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(if (copied) "Copied" else "Copy fingerprint")
                        }
                        Button(
                            onClick = { SessionState.refreshHardware() },
                            modifier = Modifier.height(46.dp),
                        ) {
                            Text("Re-scan")
                        }
                    }
                }
            }

            item {
                Text(
                    "Hardware detection runs once and refreshes when the OS build changes. No IMEI, serial or advertising identifier is read.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun CapabilityRow(capability: CapabilityItem) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = if (capability.supported) Icons.Outlined.CheckCircle else Icons.Outlined.Block,
            contentDescription = null,
            tint = if (capability.supported) BenchTheme.colors.success else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(capability.name, style = MaterialTheme.typography.bodyMedium)
            Text(
                capability.detail,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(
            if (capability.supported) "Yes" else "No",
            style = MaterialTheme.typography.labelSmall,
            color = if (capability.supported) BenchTheme.colors.success else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun HeroStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .padding(10.dp),
    ) {
        Text(value, style = NumericSmall)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
