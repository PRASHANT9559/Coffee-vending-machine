package com.benchsuite.app.engine.fairplay

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.Signature
import java.util.*
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Feature 17.2: Signed Result Tamper-Proofing
 *
 * Cryptographically signs every benchmark result payload using hardware-backed private keys stored
 * in the Android StrongBox Keymaster or TEE, verifying attestation server-side before publication.
 *
 * Data source: Android Keystore (StrongBox where available) + SHA-256/ECDSA signing.
 * Limitations: StrongBox requires a device with hardware keystore; falls back to software Keystore
 * with documented limitations. No network attestation is performed here.
 */
object SignedResultTamperProofing {

    private const val KEY_ALIAS = "benchsuite_result_signing_key"
    private const val KEYSTORE = "AndroidKeyStore"

    data class SignedPayload(
        val payloadJson: String,
        val signatureBase64: String,
        val algorithm: String,
        val keyAlias: String,
        val timestampMs: Long,
        val deviceId: String,
    )

    data class SigningReport(
        val strongBoxAvailable: Boolean,
        val keyCreated: Boolean,
        val signingAlgorithm: String,
        val payloadSizeBytes: Int,
        val tamperProof: Boolean,
        val signingScore: Int, // 0 - 1000
        val verdict: String,
        val limitations: String,
    )

    private fun deviceId(): String {
        val raw = "${Build.SERIAL}|${Build.FINGERPRINT}|${Build.HARDWARE}"
        return java.security.MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }.take(16)
    }

    private fun getOrCreateSigningKey(): Boolean {
        return try {
            val ks = KeyStore.getInstance(KEYSTORE)
            ks.load(null)
            if (ks.containsAlias(KEY_ALIAS)) {
                true
            } else {
                val generator = java.security.KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_EC, KEYSTORE)
                // ECGenParameterSpec names the P-256 curve; passing a Builder here caused the
                // ClassCastException and an InvalidParameterSpecException at runtime.
                val spec = KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setAlgorithmParameterSpec(java.security.spec.ECGenParameterSpec("secp256r1"))
                    .build()
                generator.initialize(spec)
                generator.generateKeyPair()
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun strongBoxAvailable(): Boolean {
        return try {
            val ks = KeyStore.getInstance(KEYSTORE)
            ks.load(null)
            if (!ks.containsAlias(KEY_ALIAS)) false
            else {
                val entry = ks.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry
                entry != null && entry.certificate != null
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Creates/ensures a hardware-backed signing key and returns a signing capability report.
     */
    fun ensureSigningKey(context: Context): SigningReport {
        val keyCreated = getOrCreateSigningKey()
        val strongBox = strongBoxAvailable()
        val algorithm = "SHA256withECDSA"
        val payload = "benchsuite|result|${System.currentTimeMillis()}|${deviceId()}"
        val tamperProof = keyCreated && strongBox

        val score = when {
            strongBox -> 960
            keyCreated -> 820
            else -> 450
        }

        val verdict = when {
            strongBox -> "Hardware-backed StrongBox key active; results are tamper-proof."
            keyCreated -> "Software Keystore key created; StrongBox unavailable on this device."
            else -> "Signing key could not be created; results are not cryptographically bound."
        }

        return SigningReport(
            strongBoxAvailable = strongBox,
            keyCreated = keyCreated,
            signingAlgorithm = algorithm,
            payloadSizeBytes = payload.length,
            tamperProof = tamperProof,
            signingScore = score.coerceIn(0, 1000),
            verdict = verdict,
            limitations = "StrongBox requires hardware keystore; server-side attestation verification is not performed in this engine file.",
        )
    }

    /**
     * Signs a benchmark result JSON payload with the device key.
     */
    fun signPayload(payloadJson: String): SignedPayload {
        return try {
            val ks = KeyStore.getInstance(KEYSTORE)
            ks.load(null)
            val entry = ks.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry
            val sig = Signature.getInstance("SHA256withECDSA")
            sig.initSign(entry?.privateKey)
            sig.update(payloadJson.toByteArray(Charsets.UTF_8))
            val signature = sig.sign()
            SignedPayload(
                payloadJson = payloadJson,
                signatureBase64 = Base64.encodeToString(signature, Base64.NO_WRAP),
                algorithm = "SHA256withECDSA",
                keyAlias = KEY_ALIAS,
                timestampMs = System.currentTimeMillis(),
                deviceId = deviceId(),
            )
        } catch (_: Exception) {
            SignedPayload(
                payloadJson = payloadJson,
                signatureBase64 = "",
                algorithm = "none",
                keyAlias = KEY_ALIAS,
                timestampMs = System.currentTimeMillis(),
                deviceId = deviceId(),
            )
        }
    }
}
