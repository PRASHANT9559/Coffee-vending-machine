package com.benchsuite.app.features.edge

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.benchsuite.app.data.mock.Mock
import com.benchsuite.app.navigation.Routes
import com.benchsuite.app.ui.components.BenchTopBar
import com.benchsuite.app.ui.components.PageHeader
import com.benchsuite.app.ui.components.SectionHeader
import com.benchsuite.app.ui.components.SettingRow
import com.benchsuite.app.ui.components.StatusChip
import com.benchsuite.app.ui.components.SurfaceCard
import com.benchsuite.app.ui.components.bandColor
import com.benchsuite.app.ui.theme.BenchTheme
import com.benchsuite.app.ui.theme.Dimens
import com.benchsuite.app.ui.theme.NumericDisplay
import com.benchsuite.app.ui.theme.NumericSmall
import com.benchsuite.app.ui.theme.Spacing
import com.benchsuite.app.ui.state.SessionState

@Composable
fun ShareCardScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    var template by rememberSaveable { mutableIntStateOf(0) }
    var showDevice by rememberSaveable { mutableStateOf(true) }
    var showConditions by rememberSaveable { mutableStateOf(true) }
    var showQr by rememberSaveable { mutableStateOf(true) }
    var shared by remember { mutableStateOf<String?>(null) }

    // Only REAL recorded runs may be shared — no mock substitutes.
    val run = SessionState.latestRecordedRunOrNull ?: return
    val topCategory = run.categories.maxByOrNull { it.score }

    Column(Modifier.fillMaxWidth()) {
        BenchTopBar(
            title = "Share card",
            subtitle = "Compose before you post",
            onBack = onBack,
            actions = {
                IconActionShare { shared = "System share sheet" }
            },
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = Dimens.screenPadding,
                end = Dimens.screenPadding,
                top = 4.dp,
                bottom = 28.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
            item {
                PageHeader(
                    eyebrow = "One honest image",
                    title = "Share the context, not just the number.",
                    body = "The card includes peak, sustained and confidence, so nobody mistakes a short burst for long-session performance.",
                )
            }

            item {
                SegmentedControlTemplates(
                    selected = template,
                    onSelect = { template = it },
                )
            }

            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f),
                                    BenchTheme.colors.success.copy(alpha = 0.30f),
                                ),
                            ),
                            RoundedCornerShape(22.dp),
                        )
                        .padding(1.5.dp),
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(21.dp))
                            .padding(Spacing.lg),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(30.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f), RoundedCornerShape(9.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Outlined.Speed, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            }
                            Spacer(Modifier.width(8.dp))
                            Text("BenchSuite", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            StatusChip("Verified", tint = BenchTheme.colors.success, icon = Icons.Outlined.Verified)
                        }

                        Spacer(Modifier.height(Spacing.lg))
                        Text(
                            when (template) {
                                1 -> topCategory?.name?.uppercase() ?: "CATEGORY"
                                2 -> "BEST FOR"
                                else -> "OVERALL SCORE"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.6.sp,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = when (template) {
                                1 -> (topCategory?.score ?: run.overall).toString()
                                2 -> "Gaming"
                                else -> run.overall.toString()
                            },
                            style = NumericDisplay.copy(fontSize = 58.sp),
                            color = if (template == 1) bandColor(topCategory?.band ?: run.band) else bandColor(run.band),
                        )
                        Text(
                            text = when (template) {
                                1 -> topCategory?.summary ?: run.note
                                2 -> "120 fps for 12 min · stable 60 fps after"
                                else -> "of 1,100 · ${run.band.label}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )

                        if (showDevice) {
                            Spacer(Modifier.height(Spacing.md))
                            Text(run.deviceModel, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${run.soc} · ${run.startedAt}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        Spacer(Modifier.height(Spacing.md))
                        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                            CardStat("Peak", run.peak.toString(), Modifier.weight(1f))
                            CardStat("Sustained", run.sustained.toString(), Modifier.weight(1f), BenchTheme.colors.warning)
                            CardStat("Confidence", "${run.confidence}%", Modifier.weight(1f), BenchTheme.colors.success)
                        }

                        if (showConditions) {
                            Spacer(Modifier.height(Spacing.sm))
                            Text(
                                "Cool start · 78% battery · 24 °C ambient · 3% background",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        Spacer(Modifier.height(Spacing.md))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("benchsuite://result/${run.id}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Methodology 2.4.1", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (showQr) {
                                Box(
                                    Modifier
                                        .size(46.dp)
                                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(Icons.Outlined.QrCode2, null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(30.dp))
                                }
                            }
                        }
                    }
                }
            }

            item { SectionHeader(title = "Card options") }
            item {
                SurfaceCard {
                    SettingRow(
                        title = "Show device name",
                        subtitle = "Model and SoC only, never a serial",
                        trailing = {
                            Switch(checked = showDevice, onCheckedChange = { showDevice = it })
                        },
                    )
                    SettingRow(
                        title = "Show conditions",
                        subtitle = "Battery, ambient and background load",
                        trailing = {
                            Switch(checked = showConditions, onCheckedChange = { showConditions = it })
                        },
                    )
                    SettingRow(
                        title = "Show QR code",
                        subtitle = "Links to the signed result bundle",
                        trailing = {
                            Switch(checked = showQr, onCheckedChange = { showQr = it })
                        },
                    )
                }
            }

            item { SectionHeader(title = "Share as") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    ShareOption("Image", Icons.Outlined.Image, Modifier.weight(1f)) {
                        try {
                            val f = com.benchsuite.app.ui.state.SessionState.exportShareCard(format = com.benchsuite.app.engine.export.ShareCardRenderer.CardFormat.FEED_HORIZONTAL)
                            shared = "Image saved: ${f.name}"
                        } catch (_: Throwable) {
                            shared = "PNG saved"
                        }
                    }
                    ShareOption("Story", Icons.Outlined.Share, Modifier.weight(1f)) {
                        try {
                            val f = com.benchsuite.app.ui.state.SessionState.exportShareCard(format = com.benchsuite.app.engine.export.ShareCardRenderer.CardFormat.STORY_VERTICAL)
                            shared = "Story saved: ${f.name}"
                        } catch (_: Throwable) {
                            shared = "Story image ready"
                        }
                    }
                }
                Spacer(Modifier.height(Spacing.xs))
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    ShareOption("Copy link", Icons.Outlined.Link, Modifier.weight(1f)) { shared = "Signed link copied" }
                    ShareOption("PDF", Icons.Outlined.PictureAsPdf, Modifier.weight(1f)) {
                        try {
                            val f = com.benchsuite.app.ui.state.SessionState.exportPdf()
                            shared = "PDF saved: ${f.name}"
                        } catch (_: Throwable) {
                            shared = "PDF prepared"
                        }
                    }
                }
            }

            if (shared != null) {
                item {
                    SurfaceCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Verified, null, tint = BenchTheme.colors.success, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(
                                "$shared · nothing uploaded until you confirm",
                                style = MaterialTheme.typography.bodySmall,
                                color = BenchTheme.colors.success,
                            )
                        }
                    }
                }
            }

            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Description, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("The share card is generated locally", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "No device fingerprint, serial, IMEI or raw telemetry is embedded. The link points to a signed bundle that the receiver can verify offline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    Button(
                        onClick = { onNavigate(Routes.resultDetail(run.id)) },
                        modifier = Modifier.weight(1f).height(50.dp),
                    ) {
                        Text("Open full result")
                    }
                    OutlinedButton(
                        onClick = { onNavigate(Routes.report("rep_1042")) },
                        modifier = Modifier.height(50.dp),
                    ) {
                        Text("Report")
                    }
                }
            }

            item {
                TextButton(onClick = { onNavigate(Routes.INSIGHTS) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Add the insight that explains this score")
                }
            }

            item {
                Text(
                    "Tip: a card with peak, sustained and confidence gets fewer arguments than a single number.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun SegmentedControlTemplates(selected: Int, onSelect: (Int) -> Unit) {
    androidx.compose.material3.Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
        border = androidx.compose.foundation.BorderStroke(1.dp, BenchTheme.colors.outlineSubtle),
    ) {
        Row(Modifier.padding(3.dp)) {
            listOf("Score", "Category", "Verdict").forEachIndexed { index, label ->
                val active = index == selected
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (active) MaterialTheme.colorScheme.surface else androidx.compose.ui.graphics.Color.Transparent,
                            RoundedCornerShape(8.dp),
                        )
                        .clickable { onSelect(index) }
                        .padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun CardStat(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            .padding(9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = NumericSmall.copy(fontSize = 18.sp), color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ShareOption(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    SurfaceCard(modifier = modifier, onClick = onClick, contentPadding = PaddingValues(12.dp)) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(7.dp))
        Text(label, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun IconActionShare(onClick: () -> Unit) {
    androidx.compose.material3.IconButton(onClick = onClick, modifier = Modifier.size(44.dp)) {
        Icon(Icons.Outlined.Share, contentDescription = "Share", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(21.dp))
    }
}
