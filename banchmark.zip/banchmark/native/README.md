# bench-core (Rust)

Native measurement kernels for BenchSuite, exposed to Kotlin over JNI.

This is the first native milestone: CPU, memory, storage and sustained-load
probes, shared statistics, normalization/scoring and the JNI surface. GPU
(Vulkan) and AI (LiteRT) adapters are deliberately not here yet — see
[Not yet implemented](#not-yet-implemented).

---

## Layout

```
native/bench-core/
├── Cargo.toml
└── src/
    ├── lib.rs
    ├── jni_bridge.rs          JNI symbols, JSON in/out, error payloads
    └── engine/
        ├── mod.rs             version, capabilities, page size
        ├── stats.rs           median, trimmed mean, CV, confidence, geomean
        ├── scoring.rs         baseline-1000 normalization, bands, overall score
        ├── measure.rs         shared timed-loop harness (monotonic clock)
        ├── cpu.rs             integer, f64 matmul, multi-thread scaling
        ├── memory.rs          read/write/copy bandwidth, pointer-chase latency
        ├── storage.rs         sequential + random 4K file IO
        ├── stress.rs          sustained all-core load with a timeline
        ├── ai.rs              int8 GEMM + matrix-vector decode proxy
        ├── gpu.rs             headless EGL/GLES offscreen fragment workload
        └── result.rs          JSON result types (camelCase)
```

Host tests cover statistics, scoring, the pointer-chase permutation, and short
runs of every kernel (storage uses a temp directory and cleans up).

---

## Toolchain

One-time setup:

```bash
rustup target add aarch64-linux-android
cargo install cargo-ndk
```

Install NDK 27+ from Android Studio → SDK Manager → SDK Tools → NDK (Side by
side). Point cargo-ndk at it:

```bash
export ANDROID_NDK_HOME="$HOME/Android/Sdk/ndk/27.0.12077973"
# Linux/macOS; on Windows use the .zip/.cmd equivalent paths
```

The NDK version in the path is whatever Studio installed.

## Build options

UI-only build (no Rust, app falls back to mock data):

```bash
./gradlew :app:assembleDebug
```

Native build (compiles `libbench_core.so` into `app/src/main/jniLibs/arm64-v8a`):

```bash
./gradlew :app:assembleDebug -Pnative=true
```

or run the crate directly:

```bash
cd native/bench-core
cargo test                 # host logic tests
cargo ndk -t arm64-v8a -o ../../app/src/main/jniLibs build --release
```

`-Pnative=true` makes `preBuild` depend on the `cargoNdkBuild` task. Without the
property, Gradle never touches Rust, so a normal Studio sync still works.

Only `arm64-v8a` is wired for now. Add `armeabi-v7a` (target
`armv7-linux-androideabi`) when the limited-test path is ready.

---

## JNI contract

Kotlin side: `com.benchsuite.app.nativecore.NativeBridge`.

| Kotlin method | Native symbol | Returns |
| --- | --- | --- |
| `nativeVersion()` | `...NativeBridge_nativeVersion` | plain string |
| `nativeCapabilities()` | `...NativeBridge_nativeCapabilities` | JSON |
| `nativeRunCpu(ms, threads)` | `...NativeBridge_nativeRunCpu` | `ComponentResult` JSON |
| `nativeRunMemory(ms, mb)` | `...NativeBridge_nativeRunMemory` | `ComponentResult` JSON |
| `nativeRunStorage(dir, mb)` | `...NativeBridge_nativeRunStorage` | `ComponentResult` JSON |
| `nativeRunStress(ms, threads)` | `...NativeBridge_nativeRunStress` | `ComponentResult` JSON |
| `nativeRunAi(ms)` | `...NativeBridge_nativeRunAi` | `ComponentResult` JSON |
| `nativeRunGpu(frames, readback)` | `...NativeBridge_nativeRunGpu` | `ComponentResult` JSON |
| `nativeOverallScore(json, conf)` | `...NativeBridge_nativeOverallScore` | `OverallScore` JSON |

All payloads use camelCase. A failure is a normal `ComponentResult` with
`score = 0` and the reason in `notes`, so the UI never crashes on a null string.

Result shape:

```json
{
  "component": "cpu",
  "score": 1043.2,
  "band": "Good",
  "confidence": 0.91,
  "cv": 0.035,
  "durationMs": 2500,
  "metrics": [
    { "id": "cpu.integer", "label": "Integer throughput", "value": 712.4,
      "unit": "Mops/s", "score": 1187.3, "reference": 600.0 }
  ],
  "samples": [ { "tMs": 28.0, "value": 703.1 } ],
  "notes": ["6 worker threads; warmup before every timed loop"]
}
```

`NativeBridge` loads the library lazily; `isAvailable` is false when the `.so`
is missing and all wrappers return null. The About screen shows the status.

---

## Scoring

Reference device = 1000, matching README §3.4.

| Component | Reference (1000) |
| --- | --- |
| CPU integer | 600 Mops/s |
| CPU floating point | 1.6 GFLOP/s |
| CPU multi-thread | 3.0 Gops/s |
| Memory read | 12 GB/s |
| Memory write | 8 GB/s |
| Memory copy | 10 GB/s |
| Memory latency | 110 ns (lower is better) |
| Storage sequential write | 350 MiB/s |
| Storage sequential read | 700 MiB/s |
| Storage random write | 800 IOPS |
| Storage random read | 2500 IOPS |
| Sustained | 3.0 Gops/s |
| AI int8 | 8 GOPS |
| AI decode proxy | 1500 tok/s |
| GPU fragment | 24 Mpix/s |

CPU and memory components use the geometric mean of their metrics. The overall
score uses the README weights (CPU 20, GPU 20, AI 15, sustained 15, memory 10,
storage 10, real-world 10), renormalized over whatever categories are present.

Bands: Excellent ≥ 1200, Good ≥ 900, Fair ≥ 600, otherwise Poor.

Confidence comes from the coefficient of variation of the sampling timeline:
`1 − 2.5 × CV`, clamped to 0.05–0.99. Short single-pass probes report lower
confidence honestly.

Measurement hygiene implemented here:

- Monotonic `Instant` only.
- Buffers and matrices allocated before the timed loop.
- Zero allocation inside timed loops.
- One clock read per work chunk, never per operation.
- Warmup before every measurement.
- `black_box` on results so the optimizer cannot delete the workload.
- Barrier-aligned worker start for the multi-thread number.

---

## Not yet implemented

- **Vulkan GPU** — the current GPU probe is headless EGL/GLES 3.0. Vulkan via
  `ash`, SPIR-V shaders, ray tracing/mesh shader capability gates and frame-time
  histograms are the next GPU step.
- **LiteRT AI** — the AI probe is an int8 CPU proxy. Real model loading, vendor
  delegates, NPU fallback detection and energy per token are pending.
- **Result signing** — Keystore-backed signatures and integrity bundles.
- **Persistence** — native records live in `SessionState`; Room/DataStore wiring
  comes with the application layer.
- **Scoring calibration** — reference values are reasonable starting points from
  the methodology doc; they still need device-lab calibration before public
  scores are comparable.

Until then the UI can run in two modes: simulated (no `.so`) or real CPU/memory/
storage/sustained/AI/GPU probes (`-Pnative=true`).

---

## Device notes

- Run benchmarks on a physical device, not an emulator.
- Storage numbers are only meaningful with the screen off/no background sync.
- Random reads may hit the page cache after the write phase; treat them as an
  upper bound. The payload says so in `notes`.
- The storage probe writes up to 128 MiB into app-private storage and always
  removes the file (also on error).
- Rust release builds use `panic = "abort"`; panics cannot unwind across JNI.
