#!/usr/bin/env bash
# Builds libbench_core.so for arm64-v8a into app/src/main/jniLibs.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

if [[ -z "${ANDROID_NDK_HOME:-}" ]]; then
  echo "ANDROID_NDK_HOME is not set. Example:" >&2
  echo "  export ANDROID_NDK_HOME=\"\$HOME/Android/Sdk/ndk/27.0.12077973\"" >&2
  exit 1
fi

if ! command -v cargo-ndk >/dev/null 2>&1; then
  echo "cargo-ndk not found. Install it with:" >&2
  echo "  cargo install cargo-ndk" >&2
  exit 1
fi

cd "$ROOT/native/bench-core"
cargo ndk -t arm64-v8a -o "$ROOT/app/src/main/jniLibs" build --release
echo "Built $ROOT/app/src/main/jniLibs/arm64-v8a/libbench_core.so"
