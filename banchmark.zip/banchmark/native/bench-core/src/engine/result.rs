use serde::Serialize;
use std::collections::BTreeMap;

use super::scoring;

/// One point on a live metric timeline.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Sample {
    pub t_ms: f64,
    pub value: f64,
}

/// A single measured metric and its normalized score.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct MetricResult {
    pub id: String,
    pub label: String,
    pub value: f64,
    pub unit: String,
    pub score: f64,
    pub reference: f64,
}

impl MetricResult {
    pub fn new(
        id: &str,
        label: &str,
        value: f64,
        unit: &str,
        score: f64,
        reference: f64,
    ) -> Self {
        Self {
            id: id.to_string(),
            label: label.to_string(),
            value: round2(value),
            unit: unit.to_string(),
            score: round1(score),
            reference: round2(reference),
        }
    }
}

/// Result of one native benchmark component (CPU, memory, storage, sustained).
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ComponentResult {
    pub component: String,
    pub score: f64,
    pub band: String,
    pub confidence: f64,
    pub cv: f64,
    pub duration_ms: u64,
    pub metrics: Vec<MetricResult>,
    pub samples: Vec<Sample>,
    pub notes: Vec<String>,
}

impl ComponentResult {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        component: &str,
        score: f64,
        confidence: f64,
        cv: f64,
        duration_ms: u64,
        metrics: Vec<MetricResult>,
        samples: Vec<Sample>,
        notes: Vec<String>,
    ) -> Self {
        Self {
            component: component.to_string(),
            score: round1(score),
            band: scoring::band(score).to_string(),
            confidence: round3(confidence.clamp(0.0, 1.0)),
            cv: round3(cv.max(0.0)),
            duration_ms,
            metrics,
            samples: downsample(&samples, 80),
            notes,
        }
    }
}

/// Result of a failed probe. Kept as a normal payload so the UI can show the
/// reason instead of crashing on a null JNI string.
pub fn error_component(component: &str, message: String) -> ComponentResult {
    ComponentResult {
        component: component.to_string(),
        score: 0.0,
        band: "UNAVAILABLE".to_string(),
        confidence: 0.0,
        cv: 0.0,
        duration_ms: 0,
        metrics: Vec::new(),
        samples: Vec::new(),
        notes: vec![message],
    }
}

/// Weighted geometric mean of the available component scores.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverallScore {
    pub score: f64,
    pub band: String,
    pub confidence: f64,
    pub categories: usize,
    pub weights: BTreeMap<String, f64>,
}

/// Device capabilities reported by the native core.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Capabilities {
    pub engine_version: String,
    pub abi: String,
    pub cores: u32,
    pub page_size_bytes: u64,
    pub has_neon: bool,
    pub pointer_bits: u32,
}

/// Cap the number of timeline points sent across JNI and stored in a result.
pub fn downsample(samples: &[Sample], max: usize) -> Vec<Sample> {
    if max == 0 || samples.is_empty() {
        return Vec::new();
    }
    if samples.len() <= max {
        return samples.to_vec();
    }
    let step = samples.len() as f64 / max as f64;
    (0..max)
        .map(|index| samples[(index as f64 * step) as usize].clone())
        .collect()
}

pub fn round1(value: f64) -> f64 {
    if value.is_finite() {
        (value * 10.0).round() / 10.0
    } else {
        0.0
    }
}

pub fn round2(value: f64) -> f64 {
    if value.is_finite() {
        (value * 100.0).round() / 100.0
    } else {
        0.0
    }
}

pub fn round3(value: f64) -> f64 {
    if value.is_finite() {
        (value * 1000.0).round() / 1000.0
    } else {
        0.0
    }
}
