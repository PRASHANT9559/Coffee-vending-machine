//! Normalization against the reference device (baseline = 1000) and the
//! weighted geometric mean used for the overall score.

use std::collections::BTreeMap;

use super::result::{round1, OverallScore};

pub use super::stats::geometric_mean;

/// Initial weights from README §3.4. Configuration, not code: tune from data.
pub const WEIGHTS: [(&str, f64); 7] = [
    ("cpu", 0.20),
    ("gpu", 0.20),
    ("ai", 0.15),
    ("sustained", 0.15),
    ("memory", 0.10),
    ("storage", 0.10),
    ("realWorld", 0.10),
];

pub const EXCELLENT: f64 = 1200.0;
pub const GOOD: f64 = 900.0;
pub const FAIR: f64 = 600.0;

/// Higher is better. Reference device scores exactly 1000.
pub fn normalize(measured: f64, reference: f64) -> f64 {
    if !measured.is_finite() || !reference.is_finite() || measured <= 0.0 || reference <= 0.0 {
        return 0.0;
    }
    (measured / reference * 1000.0).clamp(1.0, 20_000.0)
}

/// Lower is better (latency, decay). Reference device scores exactly 1000.
pub fn inverse_normalize(measured: f64, reference: f64) -> f64 {
    if !measured.is_finite() || !reference.is_finite() || measured <= 0.0 || reference <= 0.0 {
        return 0.0;
    }
    (reference / measured * 1000.0).clamp(1.0, 20_000.0)
}

pub fn band(score: f64) -> &'static str {
    if score >= EXCELLENT {
        "Excellent"
    } else if score >= GOOD {
        "Good"
    } else if score >= FAIR {
        "Fair"
    } else {
        "Poor"
    }
}

fn canonical(key: &str) -> Option<&'static str> {
    let normalized: String = key
        .chars()
        .filter(|character| !matches!(character, '_' | '-' | ' '))
        .flat_map(|character| character.to_lowercase())
        .collect();
    match normalized.as_str() {
        "cpu" => Some("cpu"),
        "gpu" => Some("gpu"),
        "ai" => Some("ai"),
        "sustained" | "thermal" | "stress" => Some("sustained"),
        "memory" | "mem" => Some("memory"),
        "storage" | "io" | "disk" => Some("storage"),
        "realworld" | "real" | "everyday" => Some("realWorld"),
        _ => None,
    }
}

/// Merge partial component scores into one overall score.
///
/// Missing categories are simply excluded and the remaining weights are
/// renormalized, so a device without a GPU score still gets an honest result.
pub fn overall(scores: &BTreeMap<String, f64>, confidence: f64) -> OverallScore {
    let mut values: BTreeMap<&'static str, f64> = BTreeMap::new();
    for (key, value) in scores {
        if let Some(name) = canonical(key) {
            if value.is_finite() && *value > 0.0 {
                values.insert(name, *value);
            }
        }
    }

    let mut sum_ln = 0.0f64;
    let mut sum_weight = 0.0f64;
    let mut used: BTreeMap<String, f64> = BTreeMap::new();
    for (name, weight) in WEIGHTS {
        if let Some(score) = values.get(name) {
            sum_ln += score.ln() * weight;
            sum_weight += weight;
            used.insert(name.to_string(), weight);
        }
    }

    let score = if sum_weight > 0.0 {
        (sum_ln / sum_weight).exp()
    } else {
        0.0
    };

    OverallScore {
        score: round1(score),
        band: band(score).to_string(),
        confidence: round1(confidence.clamp(0.0, 1.0)),
        categories: used.len(),
        weights: used,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reference_scores_map_to_1000() {
        assert!((normalize(500.0, 500.0) - 1000.0).abs() < 0.001);
        assert!((inverse_normalize(80.0, 80.0) - 1000.0).abs() < 0.001);
        assert_eq!(band(1000.0), "Good");
        assert_eq!(band(1300.0), "Excellent");
        assert_eq!(band(100.0), "Poor");
    }

    #[test]
    fn overall_renormalizes_missing_categories() {
        let mut scores = BTreeMap::new();
        scores.insert("cpu".to_string(), 1000.0);
        scores.insert("memory".to_string(), 1000.0);
        let result = overall(&scores, 0.9);
        assert!((result.score - 1000.0).abs() < 0.1);
        assert_eq!(result.categories, 2);
        assert!((result.weights.values().sum::<f64>() - 0.30).abs() < 0.001);
    }

    #[test]
    fn aliases_are_accepted() {
        let mut scores = BTreeMap::new();
        scores.insert("Thermal".to_string(), 800.0);
        scores.insert("real_world".to_string(), 900.0);
        let result = overall(&scores, 0.8);
        assert_eq!(result.categories, 2);
    }
}
