//! AI kernel proxy.
//!
//! A real LiteRT run needs a model, a delegate and NPU capability negotiation.
//! Until that lands, this measures the same arithmetic an LLM/AI workload leans
//! on: int8 matrix multiply (prefill proxy) and int8 matrix-vector (decode
//! proxy). It works on every device and is honest about being a CPU proxy.

use std::hint::black_box;
use std::time::Duration;

use crate::engine::measure;
use crate::engine::result::{ComponentResult, MetricResult};
use crate::engine::scoring;

const MATRIX_SIZE: usize = 192;
const VECTOR_SIZE: usize = 512;
const REF_GOPS: f64 = 8.0;
const REF_TOKENS_PER_SEC: f64 = 1_500.0;

struct Gemm {
    n: usize,
    left: Vec<i8>,
    right: Vec<i8>,
    output: Vec<i32>,
}

impl Gemm {
    fn new(n: usize) -> Self {
        let mut left = vec![0i8; n * n];
        let mut right = vec![0i8; n * n];
        for index in 0..n * n {
            left[index] = (((index * 31 + 7) % 251) as i32 - 125) as i8;
            right[index] = (((index * 17 + 3) % 239) as i32 - 119) as i8;
        }
        Self {
            n,
            left,
            right,
            output: vec![0i32; n * n],
        }
    }

    fn run(&mut self) -> u64 {
        self.output.fill(0);
        let n = self.n;
        for row in 0..n {
            for inner in 0..n {
                let factor = self.left[row * n + inner] as i32;
                if factor == 0 {
                    continue;
                }
                let right_row = &self.right[inner * n..inner * n + n];
                let output_row = &mut self.output[row * n..row * n + n];
                for column in 0..n {
                    output_row[column] = output_row[column]
                        .wrapping_add(factor.wrapping_mul(right_row[column] as i32));
                }
            }
        }
        black_box(self.output[n * n - 1]);
        (2 * n * n * n) as u64
    }
}

struct MatVec {
    n: usize,
    weights: Vec<i8>,
    input: Vec<i8>,
    output: Vec<i32>,
}

impl MatVec {
    fn new(n: usize) -> Self {
        let mut weights = vec![0i8; n * n];
        let mut input = vec![0i8; n];
        for index in 0..n * n {
            weights[index] = (((index * 13 + 5) % 127) as i32 - 63) as i8;
        }
        for index in 0..n {
            input[index] = (((index * 7 + 11) % 127) as i32 - 63) as i8;
        }
        Self {
            n,
            weights,
            input,
            output: vec![0i32; n],
        }
    }

    fn run(&mut self) -> u64 {
        self.output.fill(0);
        let n = self.n;
        for row in 0..n {
            let mut accumulator = 0i32;
            let weight_row = &self.weights[row * n..row * n + n];
            for column in 0..n {
                accumulator = accumulator
                    .wrapping_add((weight_row[column] as i32).wrapping_mul(self.input[column] as i32));
            }
            self.output[row] = accumulator;
        }
        black_box(self.output[n - 1]);
        (2 * n * n) as u64
    }
}

pub fn run(duration_ms: u64) -> ComponentResult {
    let duration = Duration::from_millis(duration_ms.clamp(500, 10_000));

    black_box(Gemm::new(32).run());
    black_box(MatVec::new(128).run());

    let mut gemm = Gemm::new(MATRIX_SIZE);
    let prefill = measure::run(duration, || gemm.run());

    let mut matvec = MatVec::new(VECTOR_SIZE);
    let decode = measure::run(duration, || matvec.run());

    let gemm_gops = prefill.rate() / 1e9;
    let token_rate = decode.rate();
    let gemm_score = scoring::normalize(gemm_gops, REF_GOPS);
    let token_score = scoring::normalize(token_rate, REF_TOKENS_PER_SEC);
    let score = scoring::geometric_mean(&[gemm_score, token_score]);
    let (cv, confidence) = measure::sample_confidence(&prefill.samples);

    let mut timeline = prefill.samples.clone();
    for sample in &mut timeline {
        sample.value /= 1e9;
    }

    let metrics = vec![
        MetricResult::new(
            "ai.int8",
            "Int8 throughput",
            gemm_gops,
            "GOPS",
            gemm_score,
            REF_GOPS,
        ),
        MetricResult::new(
            "ai.decode",
            "Decode proxy",
            token_rate,
            "tok/s",
            token_score,
            REF_TOKENS_PER_SEC,
        ),
    ];

    ComponentResult::new(
        "ai",
        score,
        confidence,
        cv,
        duration.as_millis() as u64,
        metrics,
        timeline,
        vec![
            format!(
                "Int8 {n}×{n} GEMM (prefill proxy) and {v}×{v} matrix-vector (decode proxy)",
                n = MATRIX_SIZE,
                v = VECTOR_SIZE
            ),
            "CPU integer proxy. LiteRT vendor delegates and NPU fallback detection are pending"
                .to_string(),
            "Decode tok/s measures one synthetic layer, not a real model".to_string(),
        ],
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ai_proxy_produces_both_metrics() {
        let result = run(500);
        assert_eq!(result.component, "ai");
        assert_eq!(result.metrics.len(), 2);
        assert!(result.score > 0.0);
        assert!(!result.samples.is_empty());
    }
}
