//! CPU kernels: integer ALU, floating point matrix multiply, and multi-thread
//! scaling. Scores normalize to the reference device (see README §3.4).

use std::hint::black_box;
use std::sync::{Arc, Barrier};
use std::thread;
use std::time::Duration;

use crate::engine::measure::{self, Measurement};
use crate::engine::result::{ComponentResult, MetricResult};
use crate::engine::scoring;

const REF_INT_OPS: f64 = 600_000_000.0;
const REF_FLOAT_FLOPS: f64 = 1_600_000_000.0;
const REF_MULTI_OPS: f64 = 3_000_000_000.0;

const INT_CHUNK: u64 = 4_000_000;
const MATRIX_SIZE: usize = 112;

#[inline]
fn integer_work(iterations: u64) -> u64 {
    let mut state = 0x9E37_79B9_7F4A_7C15u64;
    for _ in 0..iterations {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        state = state.wrapping_mul(0x2545_F491_4F6C_DD1D);
    }
    black_box(state);
    iterations
}

/// Dense f64 matrix multiplication. Using field-disjoint slices keeps the
/// compiler from turning this into a calloc-only loop and measures real FMA
/// throughput. Ops = 2 * n^3.
struct MatMul {
    n: usize,
    a: Vec<f64>,
    b: Vec<f64>,
    c: Vec<f64>,
}

impl MatMul {
    fn new(n: usize) -> Self {
        let mut a = vec![0.0f64; n * n];
        let mut b = vec![0.0f64; n * n];
        for index in 0..n {
            a[index * n + index] = 1.0 + index as f64 * 0.001;
            b[index * n + index] = 1.0;
            a[index] = 0.5 + index as f64 * 0.0001;
        }
        Self {
            n,
            a,
            b,
            c: vec![0.0f64; n * n],
        }
    }

    fn run(&mut self) -> u64 {
        self.c.fill(0.0);
        let n = self.n;
        for row in 0..n {
            for inner in 0..n {
                let factor = self.a[row * n + inner];
                if factor == 0.0 {
                    continue;
                }
                let b_row = &self.b[inner * n..inner * n + n];
                let c_row = &mut self.c[row * n..row * n + n];
                for column in 0..n {
                    c_row[column] += factor * b_row[column];
                }
            }
        }
        black_box(self.c[n * n - 1]);
        (2 * n * n * n) as u64
    }
}

/// Run one integer workload per thread behind a barrier so every thread starts
/// on the same wall-clock edge.
fn measure_parallel(duration: Duration, threads: usize) -> (f64, Vec<crate::engine::result::Sample>) {
    let barrier = Arc::new(Barrier::new(threads + 1));
    let mut handles = Vec::with_capacity(threads);

    for _ in 0..threads {
        let barrier = Arc::clone(&barrier);
        handles.push(thread::spawn(move || {
            barrier.wait();
            measure::run(duration, || integer_work(INT_CHUNK))
        }));
    }

    barrier.wait();
    let wall_start = std::time::Instant::now();
    let mut total_ops = 0.0;
    let mut timeline = Vec::new();
    for handle in handles {
        match handle.join() {
            Ok(measurement) => {
                total_ops += measurement.ops;
                if timeline.is_empty() {
                    timeline = measurement.samples;
                }
            }
            Err(_) => {
                return (0.0, timeline);
            }
        }
    }
    let elapsed = wall_start.elapsed().as_secs_f64().max(1e-6);
    (total_ops / elapsed, timeline)
}

pub fn run(duration_ms: u64, requested_threads: usize) -> ComponentResult {
    let duration = Duration::from_millis(duration_ms.clamp(250, 15_000));
    let cores = std::thread::available_parallelism()
        .map(|value| value.get())
        .unwrap_or(4);
    let threads = requested_threads.clamp(1, cores.max(1));

    // Warm up clocks, caches and the allocator before any timed loop.
    black_box(integer_work(8_000_000));
    let mut warm_matrix = MatMul::new(64);
    black_box(warm_matrix.run());

    let integer: Measurement = measure::run(duration, || integer_work(INT_CHUNK));
    let mut matrix = MatMul::new(MATRIX_SIZE);
    let floating: Measurement = measure::run(duration, || matrix.run());
    let (multi_rate, multi_timeline) = measure_parallel(duration, threads);

    let integer_rate = integer.rate();
    let floating_rate = floating.rate();
    let (cv, confidence) = measure::sample_confidence(&integer.samples);

    let integer_score = scoring::normalize(integer_rate, REF_INT_OPS);
    let floating_score = scoring::normalize(floating_rate, REF_FLOAT_FLOPS);
    let multi_score = scoring::normalize(multi_rate, REF_MULTI_OPS);
    let score = scoring::geometric_mean(&[integer_score, floating_score, multi_score]);

    let mut timeline = if integer.samples.len() >= 3 {
        integer.samples.clone()
    } else {
        multi_timeline
    };
    if timeline.is_empty() {
        timeline = floating.samples.clone();
    }

    let metrics = vec![
        MetricResult::new(
            "cpu.integer",
            "Integer throughput",
            integer_rate / 1e6,
            "Mops/s",
            integer_score,
            REF_INT_OPS / 1e6,
        ),
        MetricResult::new(
            "cpu.float",
            "Floating point",
            floating_rate / 1e9,
            "GFLOP/s",
            floating_score,
            REF_FLOAT_FLOPS / 1e9,
        ),
        MetricResult::new(
            "cpu.multithread",
            "Multi-thread scaling",
            multi_rate / 1e6,
            "Mops/s",
            multi_score,
            REF_MULTI_OPS / 1e6,
        ),
    ];

    ComponentResult::new(
        "cpu",
        score,
        confidence,
        cv,
        duration.as_millis() as u64,
        metrics,
        timeline,
        vec![
            format!(
                "{} worker thread{}; warmup before every timed loop",
                threads,
                if threads == 1 { "" } else { "s" }
            ),
            "Monotonic clock; cumulative throughput sampled about every 25 ms".to_string(),
            "Reference device = 1000 (integer 600 Mops/s, FP 1.6 GFLOP/s, 8-thread 3 Gops/s)"
                .to_string(),
        ],
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cpu_run_returns_a_scored_component() {
        let result = run(300, 2);
        assert_eq!(result.component, "cpu");
        assert!(result.score > 0.0);
        assert_eq!(result.metrics.len(), 3);
        assert!(!result.samples.is_empty());
        assert!(result.confidence > 0.0);
        assert!(result.samples.len() <= 80);
    }
}
