//! Vulkan capability probe (Phase 3).
//!
//! Enumerates the loader, physical device, extensions and memory heaps, and
//! reports whether the device exposes the ray-tracing and mesh-shader paths the
//! deep-tech benchmarks need. It does not submit work: a capability report is
//! useful on its own, and it lets the UI gate the heavier tests instead of
//! failing at dispatch time.
//!
//! Ray-tracing pipeline execution via `VK_KHR_ray_tracing_pipeline` and mesh
//! shader dispatch via `VK_EXT_mesh_shader` are the follow-up once SPIR-V
//! shader assets are bundled. The probe already tells us which devices can run
//! them, which is the part that cannot be discovered from the Android API level.

use std::ffi::CStr;

use ash::vk;
use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VulkanReport {
    pub available: bool,
    pub api_version: String,
    pub driver_version: String,
    pub device_name: String,
    pub device_type: String,
    pub queue_families: u32,
    pub extensions: Vec<String>,
    pub ray_tracing: bool,
    pub ray_query: bool,
    pub mesh_shaders: bool,
    pub acceleration_structure: bool,
    pub descriptor_indexing: bool,
    pub geometry_shader: bool,
    pub tessellation: bool,
    pub memory_heaps_gb: f64,
    pub note: String,
}

impl VulkanReport {
    fn unavailable(message: impl Into<String>) -> Self {
        Self {
            available: false,
            api_version: String::new(),
            driver_version: String::new(),
            device_name: String::new(),
            device_type: String::new(),
            queue_families: 0,
            extensions: Vec::new(),
            ray_tracing: false,
            ray_query: false,
            mesh_shaders: false,
            acceleration_structure: false,
            descriptor_indexing: false,
            geometry_shader: false,
            tessellation: false,
            memory_heaps_gb: 0.0,
            note: message.into(),
        }
    }
}

pub fn probe() -> VulkanReport {
    match probe_inner() {
        Ok(report) => report,
        Err(message) => VulkanReport::unavailable(message),
    }
}

fn probe_inner() -> Result<VulkanReport, String> {
    let entry = unsafe { ash::Entry::load() }
        .map_err(|error| format!("Vulkan loader is not available: {error}"))?;

    let application = vk::ApplicationInfo::default()
        .application_name(c"BenchSuite")
        .application_version(vk::make_api_version(0, 1, 0, 0))
        .api_version(vk::make_api_version(0, 1, 0, 0));

    let create_info = vk::InstanceCreateInfo::default().application_info(&application);
    let instance = unsafe { entry.create_instance(&create_info, None) }
        .map_err(|error| format!("vkCreateInstance failed: {error}"))?;

    let result = inspect_device(&instance);

    unsafe { instance.destroy_instance(None) };
    result
}

fn inspect_device(instance: &ash::Instance) -> Result<VulkanReport, String> {
    let devices = unsafe { instance.enumerate_physical_devices() }
        .map_err(|error| format!("vkEnumeratePhysicalDevices failed: {error}"))?;
    if devices.is_empty() {
        return Err("No Vulkan physical device was reported.".to_string());
    }

    let physical = devices[0];
    let properties = unsafe { instance.get_physical_device_properties(physical) };
    let features = unsafe { instance.get_physical_device_features(physical) };
    let memory = unsafe { instance.get_physical_device_memory_properties(physical) };
    let queues = unsafe { instance.get_physical_device_queue_family_properties(physical) };

    let extensions = unsafe { instance.enumerate_device_extension_properties(physical) }
        .map_err(|error| format!("vkEnumerateDeviceExtensionProperties failed: {error}"))?
        .iter()
        .map(|property| {
            unsafe { CStr::from_ptr(property.extension_name.as_ptr()) }
                .to_string_lossy()
                .into_owned()
        })
        .collect::<Vec<_>>();

    let has = |name: &str| extensions.iter().any(|extension| extension == name);
    let memory_heaps_gb = (0..memory.memory_heap_count as usize)
        .map(|index| memory.memory_heaps[index].size)
        .sum::<u64>() as f64
        / 1_073_741_824.0;

    let name = unsafe { CStr::from_ptr(properties.device_name.as_ptr()) }
        .to_string_lossy()
        .into_owned();

    let device_type = match properties.device_type {
        vk::PhysicalDeviceType::DISCRETE_GPU => "Discrete GPU",
        vk::PhysicalDeviceType::INTEGRATED_GPU => "Integrated GPU",
        vk::PhysicalDeviceType::VIRTUAL_GPU => "Virtual GPU",
        vk::PhysicalDeviceType::CPU => "CPU",
        _ => "Other",
    };

    let api_version = format!(
        "{}.{}.{}",
        vk::api_version_major(properties.api_version),
        vk::api_version_minor(properties.api_version),
        vk::api_version_patch(properties.api_version)
    );
    let driver_version = format!("{}", properties.driver_version);

    let mut note = format!(
        "Vulkan {api_version} on {name}. {} extension(s).",
        extensions.len()
    );
    if !has("VK_KHR_ray_tracing_pipeline") {
        note.push_str(" Ray-tracing pipeline extension is absent on this driver.");
    }
    if !has("VK_EXT_mesh_shader") {
        note.push_str(" Mesh-shader extension is absent on this driver.");
    }



    let ray_tracing = has("VK_KHR_ray_tracing_pipeline");
    let ray_query = has("VK_KHR_ray_query");
    let mesh_shaders = has("VK_EXT_mesh_shader");
    let acceleration_structure = has("VK_KHR_acceleration_structure");
    let descriptor_indexing = has("VK_EXT_descriptor_indexing");

    Ok(VulkanReport {
        available: true,
        api_version,
        driver_version,
        device_name: name,
        device_type: device_type.to_string(),
        queue_families: queues.len() as u32,
        extensions,
        ray_tracing,
        ray_query,
        mesh_shaders,
        acceleration_structure,
        descriptor_indexing,
        geometry_shader: features.geometry_shader == vk::TRUE,
        tessellation: features.tessellation_shader == vk::TRUE,
        memory_heaps_gb: (memory_heaps_gb * 100.0).round() / 100.0,
        note,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn probe_never_panics_without_a_gpu() {
        let report = probe();
        if !report.available {
            assert!(!report.note.is_empty());
        }
    }
}
