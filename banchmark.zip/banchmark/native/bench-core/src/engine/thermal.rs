//! Thermal storytelling.
//!
//! Takes the platform temperature/clock/power series captured by Kotlin during a
//! load soak and turns it into a phase-by-phase story: how fast the device heats
//! up, when it crosses the comfort threshold, how much sustained clock it keeps
//! and whether the drop is thermal or budget driven.
//!
//! This is analysis, not measurement. The data source is the platform telemetry
//! sampled by `DeviceTelemetryReader`; everything below is deterministic.

use serde::{Deserialize, Serialize};

/// One platform sample. Values come from battery/thermal/clock sysfs.
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ThermalPoint {
    pub t_sec: f64,
    pub temp_c: f64,
    pub power_w: f64,
    pub clock_ghz: f64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ThermalPhase {
    pub name: String,
    pub start_s: f64,
    pub end_s: f64,
    pub avg_temp_c: f64,
    pub avg_clock_ghz: f64,
    pub note: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ThermalReport {
    pub start_temp_c: f64,
    pub peak_temp_c: f64,
    pub end_temp_c: f64,
    pub throttle_at_s: Option<f64>,
    pub peak_clock_ghz: f64,
    pub sustained_clock_ghz: f64,
    pub sustained_clock_ratio: f64,
    pub clock_drop_pct: f64,
    pub peak_power_w: f64,
    pub sustained_power_w: f64,
    pub power_drop_pct: f64,
    pub verdict: String,
    pub phases: Vec<ThermalPhase>,
    pub notes: Vec<String>,
}

impl ThermalReport {
    fn empty(verdict: &str) -> Self {
        Self {
            start_temp_c: 0.0,
            peak_temp_c: 0.0,
            end_temp_c: 0.0,
            throttle_at_s: None,
            peak_clock_ghz: 0.0,
            sustained_clock_ghz: 0.0,
            sustained_clock_ratio: 0.0,
            clock_drop_pct: 0.0,
            peak_power_w: 0.0,
            sustained_power_w: 0.0,
            power_drop_pct: 0.0,
            verdict: verdict.to_string(),
            phases: Vec::new(),
            notes: Vec::new(),
        }
    }
}

pub fn analyze(mut points: Vec<ThermalPoint>, threshold_c: f64) -> ThermalReport {
    points.retain(|point| point.t_sec.is_finite() && point.temp_c.is_finite());
    points.sort_by(|a, b| a.t_sec.partial_cmp(&b.t_sec).unwrap_or(std::cmp::Ordering::Equal));

    if points.len() < 3 {
        let mut report = ThermalReport::empty("Not enough samples for a thermal story.");
        report.notes.push(format!(
            "{} samples received; at least 3 are required.",
            points.len()
        ));
        return report;
    }

    let threshold = threshold_c.clamp(30.0, 60.0);
    let count = points.len();
    let head = (count / 10).max(1);
    let tail = (count / 5).max(1);

    let start_temp = median(points[..head].iter().map(|point| point.temp_c));
    let peak_temp = points
        .iter()
        .map(|point| point.temp_c)
        .fold(f64::NEG_INFINITY, f64::max);
    let end_temp = median(
        points[count - tail..]
            .iter()
            .map(|point| point.temp_c),
    );

    let throttle_at = points
        .iter()
        .find(|point| point.temp_c >= threshold)
        .map(|point| point.t_sec);

    let peak_clock = points
        .iter()
        .map(|point| point.clock_ghz)
        .fold(0.0_f64, f64::max);
    let sustained_clock = median(
        points[count - tail..]
            .iter()
            .map(|point| point.clock_ghz),
    );
    let peak_power = points
        .iter()
        .map(|point| point.power_w)
        .fold(0.0_f64, f64::max);
    let sustained_power = median(
        points[count - tail..]
            .iter()
            .map(|point| point.power_w),
    );

    let sustained_clock_ratio = if peak_clock > 0.0 {
        (sustained_clock / peak_clock).clamp(0.0, 1.0)
    } else {
        0.0
    };
    let clock_drop_pct = (1.0 - sustained_clock_ratio) * 100.0;
    let power_drop_pct = if peak_power > 0.0 {
        ((1.0 - sustained_power / peak_power) * 100.0).clamp(0.0, 100.0)
    } else {
        0.0
    };

    let total = points[count - 1].t_sec - points[0].t_sec;
    let warmup_end = (total * 0.15).clamp(5.0, 60.0);
    let ramp_end = (total * 0.45).max(warmup_end + 1.0);
    let phases = vec![
        phase(&points, "Warm-up", 0.0, warmup_end, "Heat is building before the load fully settles."),
        phase(
            &points,
            "Ramp",
            warmup_end,
            ramp_end,
            "Power draw and temperature climb toward the steady state.",
        ),
        phase(
            &points,
            "Plateau",
            ramp_end,
            total,
            "Sustained window. Clock headroom here is the number that matters.",
        ),
    ];

    let verdict = if throttle_at.is_some() && sustained_clock_ratio < 0.75 {
        "Throttles early and gives back a quarter of peak clock under sustained load."
            .to_string()
    } else if throttle_at.is_some() {
        "Crosses the comfort threshold, but keeps most of its clock. Short bursts are safe."
            .to_string()
    } else if sustained_clock_ratio >= 0.9 {
        "Excellent thermal headroom: clock is stable across the whole soak.".to_string()
    } else {
        "No comfort-threshold crossing, with a modest sustained clock drop.".to_string()
    };

    let mut notes = vec![format!(
        "Comfort threshold set to {:.1} °C; skin temperature is estimated from the battery sensor.",
        threshold
    )];
    if let Some(seconds) = throttle_at {
        notes.push(format!("Threshold crossed at {:.0} s into the load.", seconds));
    } else {
        notes.push("The soak never crossed the comfort threshold.".to_string());
    }
    notes.push(
        "Verdicts use clock retention, not temperature alone; a hot device that keeps clock is not throttling."
            .to_string(),
    );

    ThermalReport {
        start_temp_c: round1(start_temp),
        peak_temp_c: round1(peak_temp),
        end_temp_c: round1(end_temp),
        throttle_at_s: throttle_at.map(round1),
        peak_clock_ghz: round2(peak_clock),
        sustained_clock_ghz: round2(sustained_clock),
        sustained_clock_ratio: round3(sustained_clock_ratio),
        clock_drop_pct: round1(clock_drop_pct),
        peak_power_w: round2(peak_power),
        sustained_power_w: round2(sustained_power),
        power_drop_pct: round1(power_drop_pct),
        verdict,
        phases,
        notes,
    }
}

fn phase(
    points: &[ThermalPoint],
    name: &str,
    start: f64,
    end: f64,
    note: &str,
) -> ThermalPhase {
    let window: Vec<&ThermalPoint> = points
        .iter()
        .filter(|point| point.t_sec >= start - 0.001 && point.t_sec <= end + 0.001)
        .collect();
    let avg_temp = if window.is_empty() {
        0.0
    } else {
        window.iter().map(|point| point.temp_c).sum::<f64>() / window.len() as f64
    };
    let avg_clock = if window.is_empty() {
        0.0
    } else {
        window.iter().map(|point| point.clock_ghz).sum::<f64>() / window.len() as f64
    };
    ThermalPhase {
        name: name.to_string(),
        start_s: round1(start),
        end_s: round1(end),
        avg_temp_c: round1(avg_temp),
        avg_clock_ghz: round2(avg_clock),
        note: note.to_string(),
    }
}

fn median(values: impl Iterator<Item = f64>) -> f64 {
    let mut sorted: Vec<f64> = values.filter(|value| value.is_finite()).collect();
    if sorted.is_empty() {
        return 0.0;
    }
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let middle = sorted.len() / 2;
    if sorted.len() % 2 == 0 {
        (sorted[middle - 1] + sorted[middle]) / 2.0
    } else {
        sorted[middle]
    }
}

fn round1(value: f64) -> f64 {
    if value.is_finite() {
        (value * 10.0).round() / 10.0
    } else {
        0.0
    }
}

fn round2(value: f64) -> f64 {
    if value.is_finite() {
        (value * 100.0).round() / 100.0
    } else {
        0.0
    }
}

fn round3(value: f64) -> f64 {
    if value.is_finite() {
        (value * 1000.0).round() / 1000.0
    } else {
        0.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn series(count: usize, base: f64, peak: f64, clock_peak: f64, clock_end: f64) -> Vec<ThermalPoint> {
        (0..count)
            .map(|index| {
                let progress = index as f64 / (count.max(2) - 1) as f64;
                ThermalPoint {
                    t_sec: index as f64,
                    temp_c: base + (peak - base) * progress,
                    power_w: 4.0 + 4.0 * progress,
                    clock_ghz: clock_peak + (clock_end - clock_peak) * progress,
                }
            })
            .collect()
    }

    #[test]
    fn healthy_device_keeps_clock() {
        let report = analyze(series(30, 30.0, 39.0, 3.2, 3.1), 43.0);
        assert!(report.throttle_at_s.is_none());
        assert!(report.sustained_clock_ratio > 0.9);
        assert_eq!(report.phases.len(), 3);
    }

    #[test]
    fn throttling_device_reports_crossing() {
        let report = analyze(series(40, 31.0, 46.0, 3.4, 2.1), 43.0);
        assert!(report.throttle_at_s.is_some());
        assert!(report.clock_drop_pct > 30.0);
        assert!(report.verdict.contains("Throttles") || report.verdict.contains("comfort"));
    }

    #[test]
    fn short_series_is_handled() {
        let report = analyze(vec![ThermalPoint { t_sec: 0.0, temp_c: 31.0, power_w: 1.0, clock_ghz: 2.0 }], 43.0);
        assert!(report.notes[0].contains("at least 3"));
    }
}
