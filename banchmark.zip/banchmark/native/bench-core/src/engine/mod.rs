pub mod ai;
pub mod cache;
pub mod context_switch;
pub mod cpu;
pub mod fairplay;
pub mod gpu;
pub mod measure;
pub mod memory;
pub mod result;
pub mod scoring;
pub mod stats;
pub mod storage;
pub mod stress;
pub mod thermal;
pub mod vulkan;
pub mod vulkan_scan;
pub mod phase3_async_compute;
pub mod phase3_meshshader;
pub mod phase3_raytracing;
pub mod phase4_pqc;

use result::Capabilities;

pub const METHODOLOGY: &str = "2.4.1";

/// Full engine identity returned to the Kotlin bridge.
pub fn version() -> String {
    format!(
        "{} ({}; methodology {})",
        env!("CARGO_PKG_VERSION"),
        std::env::consts::ARCH,
        METHODOLOGY
    )
}

fn page_size() -> u64 {
    #[cfg(unix)]
    {
        // SAFETY: sysconf has no preconditions and only reads a system constant.
        let value = unsafe { libc::sysconf(libc::_SC_PAGESIZE) };
        if value > 0 {
            return value as u64;
        }
    }
    4096
}

pub fn capabilities() -> Capabilities {
    let cores = std::thread::available_parallelism()
        .map(|value| value.get())
        .unwrap_or(1);

    Capabilities {
        engine_version: version(),
        abi: std::env::consts::ARCH.to_string(),
        cores: cores as u32,
        page_size_bytes: page_size(),
        has_neon: cfg!(target_arch = "aarch64") || cfg!(target_arch = "arm"),
        pointer_bits: usize::BITS,
    }
}
