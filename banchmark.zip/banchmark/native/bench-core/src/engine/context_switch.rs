//! Feature 1.2: Context Switch Storm Benchmark.
//!
//! Measures thread context switch latency and throughput using POSIX pipes under
//! thread storms (2 to 64 threads).
//!
//! A token is passed in a ring of N threads connected by N unidirectional pipes.
//! Each hop forces the kernel scheduler to perform a voluntary/involuntary context
//! switch as the reader thread wakes up from being blocked in read(2).
//! We measure median switch latency, tail latency (P95, P99), throughput, and
//! scheduler jitter under storm conditions.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::engine::result::{ComponentResult, MetricResult, Sample};
use crate::engine::{scoring, stats};

const REF_SWITCH_LATENCY_US: f64 = 1.8;
const REF_THROUGHPUT_SWITCHES_SEC: f64 = 550_000.0;

/// RAII wrapper for raw POSIX pipe file descriptors.
#[cfg(unix)]
struct RawPipe {
    read_fd: libc::c_int,
    write_fd: libc::c_int,
}

#[cfg(unix)]
impl RawPipe {
    fn new() -> Result<Self, String> {
        let mut fds = [-1 as libc::c_int; 2];
        let res = unsafe { libc::pipe(fds.as_mut_ptr()) };
        if res != 0 {
            return Err(format!(
                "libc::pipe failed: {}",
                std::io::Error::last_os_error()
            ));
        }
        Ok(Self {
            read_fd: fds[0],
            write_fd: fds[1],
        })
    }
}

/// Executes the context switch ring benchmark across `num_threads`.
pub fn run(duration_ms: u64, requested_threads: usize) -> ComponentResult {
    let threads = requested_threads.clamp(2, 64);
    let duration = Duration::from_millis(duration_ms.clamp(200, 10_000));

    #[cfg(unix)]
    {
        match run_posix_pipe_storm(duration, threads) {
            Ok(result) => result,
            Err(err) => crate::engine::result::error_component(
                "context_switch",
                format!("POSIX pipe context switch failed: {err}"),
            ),
        }
    }

    #[cfg(not(unix))]
    {
        run_condvar_storm(duration, threads)
    }
}

#[cfg(unix)]
fn run_posix_pipe_storm(duration: Duration, num_threads: usize) -> Result<ComponentResult, String> {
    let mut pipes = Vec::with_capacity(num_threads);
    for _ in 0..num_threads {
        pipes.push(RawPipe::new()?);
    }

    let running = Arc::new(AtomicBool::new(true));
    let mut handles = Vec::with_capacity(num_threads - 1);

    // Spawn worker threads 1..(num_threads - 1)
    // Thread i reads from pipe[i] and writes to pipe[(i + 1) % num_threads].
    for i in 1..num_threads {
        let in_fd = pipes[i].read_fd;
        let out_fd = pipes[(i + 1) % num_threads].write_fd;
        let running_clone = Arc::clone(&running);

        let handle = std::thread::Builder::new()
            .name(format!("cs-storm-{i}"))
            .spawn(move || {
                let mut token = 0u64;
                while running_clone.load(Ordering::Relaxed) {
                    let bytes_read = unsafe {
                        libc::read(
                            in_fd,
                            &mut token as *mut u64 as *mut libc::c_void,
                            std::mem::size_of::<u64>(),
                        )
                    };
                    if bytes_read <= 0 {
                        break;
                    }
                    if token == u64::MAX {
                        // Termination sentinel: pass along and terminate
                        unsafe {
                            libc::write(
                                out_fd,
                                &token as *const u64 as *const libc::c_void,
                                std::mem::size_of::<u64>(),
                            );
                        }
                        break;
                    }
                    token = token.wrapping_add(1);
                    let bytes_written = unsafe {
                        libc::write(
                            out_fd,
                            &token as *const u64 as *const libc::c_void,
                            std::mem::size_of::<u64>(),
                        )
                    };
                    if bytes_written <= 0 {
                        break;
                    }
                }
            })
            .map_err(|e| format!("failed to spawn storm thread: {e}"))?;
        handles.push(handle);
    }

    // Thread 0 runs on the calling thread: drives the ring and measures latency.
    let in_fd = pipes[0].read_fd;
    let out_fd = pipes[1 % num_threads].write_fd;

    let start = Instant::now();
    let mut last_sample = start;
    let mut samples = Vec::new();
    let mut batch_latencies_us = Vec::new();

    let mut token = 1u64;
    let mut total_switches = 0u64;
    let batch_cycles = 64usize;
    let switches_per_cycle = num_threads as u64;

    while start.elapsed() < duration {
        let cycle_start = Instant::now();
        for _ in 0..batch_cycles {
            unsafe {
                libc::write(
                    out_fd,
                    &token as *const u64 as *const libc::c_void,
                    std::mem::size_of::<u64>(),
                );
            }
            let bytes_read = unsafe {
                libc::read(
                    in_fd,
                    &mut token as *mut u64 as *mut libc::c_void,
                    std::mem::size_of::<u64>(),
                )
            };
            if bytes_read <= 0 {
                break;
            }
        }
        let cycle_elapsed = cycle_start.elapsed();
        let cycle_switches = (batch_cycles as u64) * switches_per_cycle;
        total_switches += cycle_switches;

        let per_switch_us =
            (cycle_elapsed.as_nanos() as f64 / 1_000.0) / (cycle_switches as f64);
        batch_latencies_us.push(per_switch_us);

        let now = Instant::now();
        if now.duration_since(last_sample).as_millis() >= 25 {
            let elapsed_sec = now.duration_since(start).as_secs_f64();
            if elapsed_sec > 0.0 {
                let current_rate = total_switches as f64 / elapsed_sec;
                samples.push(Sample {
                    t_ms: elapsed_sec * 1000.0,
                    value: current_rate,
                });
            }
            last_sample = now;
        }
    }

    // Shut down worker threads cleanly using sentinel
    running.store(false, Ordering::Relaxed);
    let sentinel = u64::MAX;
    unsafe {
        libc::write(
            out_fd,
            &sentinel as *const u64 as *const libc::c_void,
            std::mem::size_of::<u64>(),
        );
    }

    for handle in handles {
        let _ = handle.join();
    }

    // Explicitly close all pipes to avoid leaks
    for pipe in pipes {
        unsafe {
            libc::close(pipe.read_fd);
            libc::close(pipe.write_fd);
        }
    }

    let elapsed_sec = start.elapsed().as_secs_f64().max(1e-6);
    let throughput = total_switches as f64 / elapsed_sec;

    let median_latency_us = stats::median(&batch_latencies_us).max(0.1);
    let p95_latency_us = stats::percentile(&batch_latencies_us, 95.0).max(median_latency_us);
    let p99_latency_us = stats::percentile(&batch_latencies_us, 99.0).max(p95_latency_us);
    let jitter_ratio = if median_latency_us > 0.0 {
        p99_latency_us / median_latency_us
    } else {
        1.0
    };

    let latency_score = scoring::inverse_normalize(median_latency_us, REF_SWITCH_LATENCY_US);
    let throughput_score = scoring::normalize(throughput, REF_THROUGHPUT_SWITCHES_SEC);
    let score = scoring::geometric_mean(&[latency_score, throughput_score]);

    let cv = stats::coefficient_of_variation(&batch_latencies_us);
    let confidence = stats::confidence_from_cv(cv);

    let metrics = vec![
        MetricResult::new(
            "context_switch.latency_us",
            "Median switch latency",
            median_latency_us,
            "µs",
            latency_score,
            REF_SWITCH_LATENCY_US,
        ),
        MetricResult::new(
            "context_switch.throughput",
            "Context switches / sec",
            throughput,
            "switches/s",
            throughput_score,
            REF_THROUGHPUT_SWITCHES_SEC,
        ),
        MetricResult::new(
            "context_switch.p95_latency_us",
            "P95 tail latency",
            p95_latency_us,
            "µs",
            scoring::inverse_normalize(p95_latency_us, REF_SWITCH_LATENCY_US * 1.5),
            REF_SWITCH_LATENCY_US * 1.5,
        ),
        MetricResult::new(
            "context_switch.p99_latency_us",
            "P99 tail latency",
            p99_latency_us,
            "µs",
            scoring::inverse_normalize(p99_latency_us, REF_SWITCH_LATENCY_US * 2.5),
            REF_SWITCH_LATENCY_US * 2.5,
        ),
        MetricResult::new(
            "context_switch.threads",
            "Storm thread count",
            num_threads as f64,
            "threads",
            1000.0,
            num_threads as f64,
        ),
    ];

    let notes = vec![
        format!(
            "Storm ring of {num_threads} threads synchronized via POSIX pipe round-trips."
        ),
        format!(
            "P99/Median latency jitter ratio: {:.2}x (scheduling storm tail overhead).",
            jitter_ratio
        ),
        format!(
            "Total voluntary context switches observed: {total_switches} over {:.2}s.",
            elapsed_sec
        ),
    ];

    Ok(ComponentResult::new(
        "context_switch",
        score,
        confidence,
        cv,
        start.elapsed().as_millis() as u64,
        metrics,
        samples,
        notes,
    ))
}

#[cfg(not(unix))]
fn run_condvar_storm(duration: Duration, num_threads: usize) -> ComponentResult {
    use std::sync::{Condvar, Mutex};

    let start = Instant::now();
    let state = Arc::new((Mutex::new(0usize), Condvar::new()));
    let running = Arc::new(AtomicBool::new(true));
    let mut handles = Vec::with_capacity(num_threads - 1);

    for i in 1..num_threads {
        let state_clone = Arc::clone(&state);
        let running_clone = Arc::clone(&running);
        let handle = thread::spawn(move || {
            let (lock, cvar) = &*state_clone;
            while running_clone.load(Ordering::Relaxed) {
                let mut turn = lock.lock().unwrap();
                while *turn != i && running_clone.load(Ordering::Relaxed) {
                    turn = cvar.wait(turn).unwrap();
                }
                if !running_clone.load(Ordering::Relaxed) {
                    break;
                }
                *turn = (i + 1) % num_threads;
                cvar.notify_all();
            }
        });
        handles.push(handle);
    }

    let mut switches = 0u64;
    let (lock, cvar) = &*state;
    while start.elapsed() < duration {
        {
            let mut turn = lock.lock().unwrap();
            while *turn != 0 && start.elapsed() < duration {
                turn = cvar.wait(turn).unwrap();
            }
            *turn = 1;
            switches += num_threads as u64;
            cvar.notify_all();
        }
    }

    running.store(false, Ordering::Relaxed);
    cvar.notify_all();
    for h in handles {
        let _ = h.join();
    }

    let elapsed = start.elapsed().as_secs_f64().max(1e-6);
    let throughput = switches as f64 / elapsed;
    let latency_us = if throughput > 0.0 {
        1_000_000.0 / throughput
    } else {
        100.0
    };

    let latency_score = scoring::inverse_normalize(latency_us, REF_SWITCH_LATENCY_US);
    let throughput_score = scoring::normalize(throughput, REF_THROUGHPUT_SWITCHES_SEC);
    let score = scoring::geometric_mean(&[latency_score, throughput_score]);

    ComponentResult::new(
        "context_switch",
        score,
        0.85,
        0.05,
        start.elapsed().as_millis() as u64,
        vec![
            MetricResult::new(
                "context_switch.latency_us",
                "Switch latency (condvar)",
                latency_us,
                "µs",
                latency_score,
                REF_SWITCH_LATENCY_US,
            ),
            MetricResult::new(
                "context_switch.throughput",
                "Switches/sec (condvar)",
                throughput,
                "switches/s",
                throughput_score,
                REF_THROUGHPUT_SWITCHES_SEC,
            ),
        ],
        Vec::new(),
        vec![format!("Condvar fallback for {num_threads} threads.")],
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn context_switch_storm_runs_at_scale() {
        let res = run(150, 4);
        assert_eq!(res.component, "context_switch");
        assert!(res.score > 0.0);
        assert!(res.metrics.len() >= 2);
    }
}
