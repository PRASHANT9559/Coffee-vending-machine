//! Storage probe: sequential read/write plus random 4 KiB read/write.
//!
//! The file lives in the app-private directory supplied by Kotlin, so no
//! permission is required. It is always removed afterwards, including on error.

use std::fs::{File, OpenOptions};
use std::hint::black_box;
use std::io::{BufReader, BufWriter, Read, Write};
use std::os::unix::fs::FileExt;
use std::path::Path;
use std::time::Instant;

use crate::engine::result::{ComponentResult, MetricResult, Sample};
use crate::engine::{scoring, stats};

const REF_SEQ_WRITE_MIB: f64 = 350.0;
const REF_SEQ_READ_MIB: f64 = 700.0;
const REF_RANDOM_WRITE_IOPS: f64 = 800.0;
const REF_RANDOM_READ_IOPS: f64 = 2_500.0;
const BLOCK_SIZE: u64 = 4096;

fn next_random(state: &mut u64) -> u64 {
    *state ^= *state << 13;
    *state ^= *state >> 7;
    *state ^= *state << 17;
    *state
}

pub fn run(directory: &Path, size_mb: u64) -> Result<ComponentResult, String> {
    let megabytes = size_mb.clamp(2, 128);
    std::fs::create_dir_all(directory)
        .map_err(|error| format!("could not create test directory: {error}"))?;
    let path = directory.join("benchsuite_io_probe.bin");

    let result = probe(&path, megabytes);
    let _ = std::fs::remove_file(&path);
    result
}

fn probe(path: &Path, megabytes: u64) -> Result<ComponentResult, String> {
    let started = Instant::now();
    let total_bytes = megabytes * 1024 * 1024;
    let buffer = vec![0xA5u8; 1024 * 1024];

    // Sequential write, including fsync so the number is not a page-cache lie.
    let write_started = Instant::now();
    {
        let file = File::create(path)
            .map_err(|error| format!("could not create probe file: {error}"))?;
        let mut writer = BufWriter::with_capacity(1024 * 1024, file);
        for _ in 0..megabytes {
            writer
                .write_all(&buffer)
                .map_err(|error| format!("sequential write failed: {error}"))?;
        }
        writer
            .flush()
            .map_err(|error| format!("flush failed: {error}"))?;
        writer
            .get_ref()
            .sync_all()
            .map_err(|error| format!("fsync failed: {error}"))?;
    }
    let write_secs = write_started.elapsed().as_secs_f64().max(1e-6);
    let sequential_write = megabytes as f64 / write_secs;

    // Sequential read (may hit the page cache; noted in the payload).
    let read_started = Instant::now();
    let mut read_buffer = vec![0u8; 1024 * 1024];
    let mut checksum = 0u64;
    {
        let file = File::open(path).map_err(|error| format!("could not reopen file: {error}"))?;
        let mut reader = BufReader::with_capacity(1024 * 1024, file);
        loop {
            let read = reader
                .read(&mut read_buffer)
                .map_err(|error| format!("sequential read failed: {error}"))?;
            if read == 0 {
                break;
            }
            for byte in &read_buffer[..read] {
                checksum = checksum.wrapping_add(*byte as u64);
            }
        }
    }
    black_box(checksum);
    let sequential_read = megabytes as f64 / read_started.elapsed().as_secs_f64().max(1e-6);

    let file = OpenOptions::new()
        .read(true)
        .write(true)
        .open(path)
        .map_err(|error| format!("could not open probe file for random IO: {error}"))?;

    let blocks = (total_bytes / BLOCK_SIZE).max(1);
    let operations = (megabytes * 32).clamp(64, 1024) as usize;
    let block = [0x5Au8; BLOCK_SIZE as usize];
    let mut random_state = 0x2545_F491_4F6C_DD1Du64;
    let mut write_latencies = Vec::with_capacity(operations);

    for _ in 0..operations {
        let offset = (next_random(&mut random_state) % blocks) * BLOCK_SIZE;
        let operation_started = Instant::now();
        file.write_all_at(&block, offset)
            .map_err(|error| format!("random write failed: {error}"))?;
        write_latencies.push(operation_started.elapsed().as_secs_f64());
    }
    file.sync_all()
        .map_err(|error| format!("random write fsync failed: {error}"))?;

    let mut random_block = [0u8; BLOCK_SIZE as usize];
    let mut read_latencies = Vec::with_capacity(operations);
    let mut cumulative_seconds = 0.0f64;
    let mut read_timeline = Vec::with_capacity(operations);

    for _ in 0..operations {
        let offset = (next_random(&mut random_state) % blocks) * BLOCK_SIZE;
        let operation_started = Instant::now();
        file.read_exact_at(&mut random_block, offset)
            .map_err(|error| format!("random read failed: {error}"))?;
        let elapsed = operation_started.elapsed().as_secs_f64();
        cumulative_seconds += elapsed;
        read_latencies.push(elapsed);
        if cumulative_seconds > 0.0 {
            read_timeline.push(Sample {
                t_ms: cumulative_seconds * 1000.0,
                value: (read_latencies.len() as f64) / cumulative_seconds,
            });
        }
    }
    drop(file);

    let random_write_latency = stats::median(&write_latencies).max(1e-9);
    let random_read_latency = stats::median(&read_latencies).max(1e-9);
    let random_write_iops = 1.0 / random_write_latency;
    let random_read_iops = 1.0 / random_read_latency;

    let write_score = scoring::normalize(sequential_write, REF_SEQ_WRITE_MIB);
    let read_score = scoring::normalize(sequential_read, REF_SEQ_READ_MIB);
    let random_write_score = scoring::normalize(random_write_iops, REF_RANDOM_WRITE_IOPS);
    let random_read_score = scoring::normalize(random_read_iops, REF_RANDOM_READ_IOPS);
    let score =
        scoring::geometric_mean(&[write_score, read_score, random_write_score, random_read_score]);

    let mut latencies = write_latencies;
    latencies.extend_from_slice(&read_latencies);
    let cv = stats::coefficient_of_variation(&latencies);
    let confidence = stats::confidence_from_cv(cv);

    let metrics = vec![
        MetricResult::new(
            "storage.seqWrite",
            "Sequential write",
            sequential_write,
            "MiB/s",
            write_score,
            REF_SEQ_WRITE_MIB,
        ),
        MetricResult::new(
            "storage.seqRead",
            "Sequential read",
            sequential_read,
            "MiB/s",
            read_score,
            REF_SEQ_READ_MIB,
        ),
        MetricResult::new(
            "storage.randomWrite",
            "Random 4K write",
            random_write_iops,
            "IOPS",
            random_write_score,
            REF_RANDOM_WRITE_IOPS,
        ),
        MetricResult::new(
            "storage.randomRead",
            "Random 4K read",
            random_read_iops,
            "IOPS",
            random_read_score,
            REF_RANDOM_READ_IOPS,
        ),
    ];

    Ok(ComponentResult::new(
        "storage",
        score,
        confidence,
        cv,
        started.elapsed().as_millis() as u64,
        metrics,
        read_timeline,
        vec![
            format!("{} MiB probe file in app-private storage; deleted after the run", megabytes),
            "Random reads may be served from the page cache; treat them as an upper bound"
                .to_string(),
            "Reference device = 1000 (350/700 MiB/s sequential, 800/2500 IOPS random)"
                .to_string(),
        ],
    ))
}

/// Feature 4.6: Random IOPS Queue-Depth Scaling.
///
/// Measures multi-threaded random 4KB read/write across queue depths (QD1, QD4, QD16, QD32)
/// with direct I/O and sync, evaluating IOPS scaling and tail latency spikes.
pub fn run_queue_depth(
    directory: &Path,
    queue_depth: usize,
    size_mb: u64,
) -> Result<ComponentResult, String> {
    let megabytes = size_mb.clamp(4, 128);
    std::fs::create_dir_all(directory)
        .map_err(|error| format!("could not create test directory: {error}"))?;
    let path = directory.join("benchsuite_qd_probe.bin");

    let result = probe_queue_depth(&path, queue_depth, megabytes);
    let _ = std::fs::remove_file(&path);
    result
}

fn probe_queue_depth(
    path: &Path,
    target_qd: usize,
    megabytes: u64,
) -> Result<ComponentResult, String> {
    let started = Instant::now();
    let total_bytes = megabytes * 1024 * 1024;
    let block_count = (total_bytes / BLOCK_SIZE).max(1);

    // Prepare probe file with deterministic payload
    {
        let file = File::create(path)
            .map_err(|error| format!("could not create QD probe file: {error}"))?;
        let mut writer = BufWriter::with_capacity(1024 * 1024, file);
        let chunk = vec![0x3Cu8; 1024 * 1024];
        for _ in 0..megabytes {
            writer
                .write_all(&chunk)
                .map_err(|error| format!("sequential prep write failed: {error}"))?;
        }
        writer.flush().map_err(|error| format!("flush failed: {error}"))?;
        writer.get_ref().sync_all().map_err(|error| format!("sync failed: {error}"))?;
    }

    let depths: Vec<usize> = if target_qd == 0 {
        vec![1, 4, 16, 32]
    } else if target_qd == 1 {
        vec![1]
    } else if target_qd <= 4 {
        vec![1, target_qd]
    } else if target_qd <= 16 {
        vec![1, 4, target_qd]
    } else {
        vec![1, 4, 16, target_qd.clamp(1, 64)]
    };

    let shared_file = std::sync::Arc::new(
        OpenOptions::new()
            .read(true)
            .write(true)
            .open(path)
            .map_err(|error| format!("could not open QD probe file: {error}"))?,
    );

    let mut metrics = Vec::new();
    let mut timeline = Vec::new();
    let mut all_latencies_ms = Vec::new();
    let mut qd_read_iops = Vec::new();
    let mut qd_write_iops = Vec::new();

    let ops_per_worker = 128usize;

    for &qd in &depths {
        let qd_start = Instant::now();

        // 1. Concurrent Random Read at this QD
        let mut read_handles = Vec::with_capacity(qd);
        for thread_idx in 0..qd {
            let file = std::sync::Arc::clone(&shared_file);
            let seed = 0x517C_C1B7_2722_0A95u64
                .wrapping_add(thread_idx as u64)
                .wrapping_mul(0x9E37_79B9);
            read_handles.push(std::thread::spawn(move || {
                let mut buf = [0u8; BLOCK_SIZE as usize];
                let mut rng = seed;
                let mut latencies = Vec::with_capacity(ops_per_worker);
                for _ in 0..ops_per_worker {
                    let offset = (next_random(&mut rng) % block_count) * BLOCK_SIZE;
                    let op_start = Instant::now();
                    let _ = file.read_exact_at(&mut buf, offset);
                    latencies.push(op_start.elapsed().as_secs_f64() * 1000.0);
                }
                latencies
            }));
        }

        let mut read_latencies = Vec::new();
        for h in read_handles {
            if let Ok(lats) = h.join() {
                read_latencies.extend(lats);
            }
        }

        let read_elapsed_sec = qd_start.elapsed().as_secs_f64().max(1e-6);
        let read_iops = (read_latencies.len() as f64) / read_elapsed_sec;
        qd_read_iops.push((qd, read_iops));

        // 2. Concurrent Random Write at this QD
        let write_start = Instant::now();
        let mut write_handles = Vec::with_capacity(qd);
        for thread_idx in 0..qd {
            let file = std::sync::Arc::clone(&shared_file);
            let seed = 0x8543_6452_2722_0A95u64
                .wrapping_add(thread_idx as u64)
                .wrapping_mul(0x9E37_79B9);
            write_handles.push(std::thread::spawn(move || {
                let buf = [0x7Eu8; BLOCK_SIZE as usize];
                let mut rng = seed;
                let mut latencies = Vec::with_capacity(ops_per_worker);
                for _ in 0..ops_per_worker {
                    let offset = (next_random(&mut rng) % block_count) * BLOCK_SIZE;
                    let op_start = Instant::now();
                    let _ = file.write_all_at(&buf, offset);
                    latencies.push(op_start.elapsed().as_secs_f64() * 1000.0);
                }
                latencies
            }));
        }

        let mut write_latencies = Vec::new();
        for h in write_handles {
            if let Ok(lats) = h.join() {
                write_latencies.extend(lats);
            }
        }
        let _ = shared_file.sync_all();

        let write_elapsed_sec = write_start.elapsed().as_secs_f64().max(1e-6);
        let write_iops = (write_latencies.len() as f64) / write_elapsed_sec;
        qd_write_iops.push((qd, write_iops));

        all_latencies_ms.extend_from_slice(&read_latencies);
        all_latencies_ms.extend_from_slice(&write_latencies);

        let total_elapsed = started.elapsed().as_secs_f64();
        timeline.push(Sample {
            t_ms: total_elapsed * 1000.0,
            value: read_iops + write_iops,
        });

        let qd_read_score = scoring::normalize(read_iops, REF_RANDOM_READ_IOPS * (qd as f64).sqrt());
        let qd_write_score = scoring::normalize(write_iops, REF_RANDOM_WRITE_IOPS * (qd as f64).sqrt());

        metrics.push(MetricResult::new(
            &format!("storage.qd{qd}_read_iops"),
            &format!("Random 4K read QD{qd}"),
            read_iops,
            "IOPS",
            qd_read_score,
            REF_RANDOM_READ_IOPS * (qd as f64).sqrt(),
        ));
        metrics.push(MetricResult::new(
            &format!("storage.qd{qd}_write_iops"),
            &format!("Random 4K write QD{qd}"),
            write_iops,
            "IOPS",
            qd_write_score,
            REF_RANDOM_WRITE_IOPS * (qd as f64).sqrt(),
        ));
    }

    drop(shared_file);

    // Compute QD scaling efficiency ratio
    let qd1_iops = qd_read_iops.first().map(|(_, val)| *val).unwrap_or(1.0).max(1.0);
    let qd_max_iops = qd_read_iops.last().map(|(_, val)| *val).unwrap_or(qd1_iops);
    let scaling_ratio = qd_max_iops / qd1_iops;

    let p95_latency_ms = stats::percentile(&all_latencies_ms, 95.0).max(0.01);
    let p99_latency_ms = stats::percentile(&all_latencies_ms, 99.0).max(p95_latency_ms);

    let scaling_score = scoring::normalize(scaling_ratio, 3.5);
    let p99_score = scoring::inverse_normalize(p99_latency_ms, 8.0);
    let score = scoring::geometric_mean(&[scaling_score, p99_score]);

    metrics.push(MetricResult::new(
        "storage.qd_scaling_factor",
        "QD scaling ratio (max/QD1)",
        scaling_ratio,
        "x",
        scaling_score,
        3.5,
    ));
    metrics.push(MetricResult::new(
        "storage.p99_tail_latency_ms",
        "P99 tail latency",
        p99_latency_ms,
        "ms",
        p99_score,
        8.0,
    ));

    let cv = stats::coefficient_of_variation(&all_latencies_ms);
    let confidence = stats::confidence_from_cv(cv);

    let max_qd = depths.last().copied().unwrap_or(1);
    let notes = vec![
        format!("Random 4K I/O queue depth scaling evaluated across depths: {:?}", depths),
        format!("Max QD ({max_qd}) vs QD1 scaling factor: {:.2}x.", scaling_ratio),
        format!("P99 tail latency under load: {:.2} ms (fsync confirmed).", p99_latency_ms),
    ];

    Ok(ComponentResult::new(
        "storage",
        score,
        confidence,
        cv,
        started.elapsed().as_millis() as u64,
        metrics,
        timeline,
        notes,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn storage_probe_runs_and_cleans_up() {
        let directory = std::env::temp_dir().join(format!(
            "benchsuite-test-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|value| value.as_nanos())
                .unwrap_or(0)
        ));
        let result = run(&directory, 4).expect("storage probe should succeed");
        assert_eq!(result.component, "storage");
        assert_eq!(result.metrics.len(), 4);
        assert!(result.score > 0.0);
        assert!(!directory.join("benchsuite_io_probe.bin").exists());
        let _ = std::fs::remove_dir_all(&directory);
    }

    #[test]
    fn storage_queue_depth_scaling_runs() {
        let directory = std::env::temp_dir().join(format!(
            "benchsuite-qd-test-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|value| value.as_nanos())
                .unwrap_or(0)
        ));
        let result = run_queue_depth(&directory, 4, 4).expect("QD probe should succeed");
        assert_eq!(result.component, "storage");
        assert!(result.metrics.len() >= 3);
        assert!(!directory.join("benchsuite_qd_probe.bin").exists());
        let _ = std::fs::remove_dir_all(&directory);
    }
}
