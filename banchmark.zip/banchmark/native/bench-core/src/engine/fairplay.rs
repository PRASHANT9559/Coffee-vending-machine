//! Fair-play / environment integrity checks.
//!
//! Benchmark cheating is usually one of a few things: an emulator, a hooking
//! framework, a debuggable build, a spoofed device fingerprint or a background
//! process that changes governor behaviour. This module looks for the first
//! four from native land; Kotlin adds build-property and package checks.
//!
//! Nothing here can prove a device is clean. It produces findings with evidence
//! so a reviewer can judge, which is more honest than a single "trusted" badge.

use std::fs;
use std::path::Path;

use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Finding {
    pub id: String,
    pub severity: String,
    pub detail: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct FairPlayReport {
    pub risk: u32,
    pub verdict: String,
    pub findings: Vec<Finding>,
    pub notes: Vec<String>,
}

const HOOK_TOKENS: [(&str, &str); 7] = [
    ("frida", "Frida instrumentation library is mapped into the process."),
    ("gadget", "A Frida gadget-style library is mapped into the process."),
    ("xposed", "Xposed/LSPosed artefacts are visible."),
    ("substrate", "Cydia Substrate is present."),
    ("magisk", "Magisk paths are visible."),
    ("libhoudini", "Translation layer (libhoudini) is active."),
    ("libnb", "A known emulator translation library is active."),
];

pub fn inspect() -> FairPlayReport {
    let mut findings = Vec::new();
    let mut risk: u32 = 0;

    add(
        &mut findings,
        &mut risk,
        "hooks",
        "Critical",
        hook_evidence(),
        35,
    );

    if let Some(tracer) = tracer_pid() {
        add(
            &mut findings,
            &mut risk,
            "debugger",
            "Warning",
            format!("TracerPid is {tracer}; a debugger or tracer is attached."),
            20,
        );
    }

    if let Some(path) = first_existing(&[
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/data/local/su",
        "/data/local/bin/su",
        "/system/sd/xbin/su",
    ]) {
        add(
            &mut findings,
            &mut risk,
            "su-binary",
            "Warning",
            format!("A root shell binary exists at {path}."),
            20,
        );
    }

    if let Some(marker) = mount_marker() {
        add(
            &mut findings,
            &mut risk,
            "mounts",
            "Warning",
            format!("Suspicious mount marker: {marker}."),
            15,
        );
    }

    if let Some(cpu) = emulator_cpu_marker() {
        add(
            &mut findings,
            &mut risk,
            "emulator-cpu",
            "Critical",
            format!("/proc/cpuinfo reports an emulator core ({cpu})."),
            40,
        );
    }

    let risk = risk.min(100);
    let verdict = if risk >= 60 {
        "Environment is likely modified; treat this score as non-comparable.".to_string()
    } else if risk >= 30 {
        "Some integrity signals are present. Review the findings before publishing.".to_string()
    } else if findings.is_empty() {
        "No common tampering signals were found in native land.".to_string()
    } else {
        "Low-risk signals only. The device looks like a normal retail build.".to_string()
    };

    let notes = vec![
        "Native checks cover process maps, tracer state, root binaries, mounts and CPU identity."
            .to_string(),
        "Absence of findings is not proof of a clean device; it means the common paths were not hit."
            .to_string(),
        "Kotlin adds Build.* checks, debuggable state and known root/emulator packages on top."
            .to_string(),
    ];

    FairPlayReport {
        risk,
        verdict,
        findings,
        notes,
    }
}

fn add(
    findings: &mut Vec<Finding>,
    risk: &mut u32,
    id: &str,
    severity: &str,
    detail: String,
    weight: u32,
) {
    if detail.is_empty() {
        return;
    }
    *risk = risk.saturating_add(weight);
    findings.push(Finding {
        id: id.to_string(),
        severity: severity.to_string(),
        detail,
    });
}

fn hook_evidence() -> String {
    let maps = match fs::read_to_string("/proc/self/maps") {
        Ok(text) => text.to_lowercase(),
        Err(_) => return String::new(),
    };
    let hits: Vec<&str> = HOOK_TOKENS
        .iter()
        .filter(|(token, _)| maps.contains(token))
        .map(|(_, detail)| *detail)
        .collect();
    hits.join(" ")
}

fn tracer_pid() -> Option<u32> {
    let status = fs::read_to_string("/proc/self/status").ok()?;
    for line in status.lines() {
        if let Some(value) = line.strip_prefix("TracerPid:") {
            let pid: u32 = value.trim().parse().ok()?;
            if pid != 0 {
                return Some(pid);
            }
        }
    }
    None
}

fn first_existing(paths: &[&str]) -> Option<String> {
    paths
        .iter()
        .find(|path| Path::new(path).exists())
        .map(|path| path.to_string())
}

fn mount_marker() -> Option<String> {
    let mounts = fs::read_to_string("/proc/mounts").ok()?;
    for line in mounts.lines() {
        let lower = line.to_lowercase();
        if lower.contains("magisk") || lower.contains("overlayfs") || lower.contains("frida") {
            return Some(line.chars().take(80).collect());
        }
    }
    None
}

fn emulator_cpu_marker() -> Option<String> {
    let cpuinfo = fs::read_to_string("/proc/cpuinfo").ok()?.to_lowercase();
    for marker in ["goldfish", "ranchu", "qemu", "android emulator"] {
        if cpuinfo.contains(marker) {
            return Some(marker.to_string());
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn report_is_bounded_and_serializable() {
        let report = inspect();
        assert!(report.risk <= 100);
        assert!(!report.verdict.is_empty());
        let json = serde_json::to_string(&report).expect("serialize");
        assert!(json.contains("\"risk\""));
    }
}
