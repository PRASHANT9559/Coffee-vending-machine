//! Small statistics helpers used by every component.
//!
//! All functions filter non-finite values first so a single bad sample cannot
//! poison a score. The methodology follows README §3.4: median with outlier
//! trimming and a coefficient-of-variation quality gate.

use std::cmp::Ordering;

fn clean(values: &[f64]) -> Vec<f64> {
    values
        .iter()
        .copied()
        .filter(|value| value.is_finite())
        .collect()
}

pub fn mean(values: &[f64]) -> f64 {
    let values = clean(values);
    if values.is_empty() {
        return 0.0;
    }
    values.iter().sum::<f64>() / values.len() as f64
}

pub fn median(values: &[f64]) -> f64 {
    let mut values = clean(values);
    if values.is_empty() {
        return 0.0;
    }
    values.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
    let middle = values.len() / 2;
    if values.len() % 2 == 0 {
        (values[middle - 1] + values[middle]) / 2.0
    } else {
        values[middle]
    }
}

/// Mean after dropping `trim` fraction from each end (clamped to 45%).
pub fn trimmed_mean(values: &[f64], trim: f64) -> f64 {
    let mut values = clean(values);
    if values.is_empty() {
        return 0.0;
    }
    values.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
    let fraction = trim.clamp(0.0, 0.45);
    let cut = ((values.len() as f64) * fraction) as usize;
    let cut = cut.min(values.len() / 2);
    let slice = &values[cut..values.len() - cut];
    if slice.is_empty() {
        return values[values.len() / 2];
    }
    slice.iter().sum::<f64>() / slice.len() as f64
}

/// Linear-interpolated percentile where `p` is in the 0..100 range.
/// Used by the latency probes for p95/p99 tail reporting.
pub fn percentile(values: &[f64], p: f64) -> f64 {
    let mut values = clean(values);
    if values.is_empty() {
        return 0.0;
    }
    values.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
    let rank = (p.clamp(0.0, 100.0) / 100.0) * (values.len() - 1) as f64;
    let low = rank.floor() as usize;
    let high = rank.ceil() as usize;
    if low == high {
        values[low]
    } else {
        let weight = rank - low as f64;
        values[low] * (1.0 - weight) + values[high] * weight
    }
}

/// Round to two decimals, guarding against non-finite input.
pub fn round2(value: f64) -> f64 {
    if value.is_finite() {
        (value * 100.0).round() / 100.0
    } else {
        0.0
    }
}

pub fn stddev(values: &[f64]) -> f64 {
    let values = clean(values);
    if values.len() < 2 {
        return 0.0;
    }
    let average = values.iter().sum::<f64>() / values.len() as f64;
    let variance = values
        .iter()
        .map(|value| {
            let delta = value - average;
            delta * delta
        })
        .sum::<f64>()
        / values.len() as f64;
    variance.sqrt()
}

pub fn coefficient_of_variation(values: &[f64]) -> f64 {
    let average = trimmed_mean(values, 0.1).abs();
    if average < 1e-9 {
        return 0.0;
    }
    (stddev(values) / average).clamp(0.0, 5.0)
}

/// Convert a coefficient of variation into a 0..1 confidence figure.
/// A 4% spread is close to the methodology target; 40% is rejected.
pub fn confidence_from_cv(cv: f64) -> f64 {
    (1.0 - cv.clamp(0.0, 1.0) * 2.5).clamp(0.05, 0.99)
}

/// Geometric mean, ignoring zero and negative entries.
pub fn geometric_mean(values: &[f64]) -> f64 {
    let mut count = 0u32;
    let mut sum_ln = 0.0f64;
    for value in values {
        if value.is_finite() && *value > 0.0 {
            sum_ln += value.ln();
            count += 1;
        }
    }
    if count == 0 {
        0.0
    } else {
        (sum_ln / count as f64).exp()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn median_handles_odd_and_even() {
        assert_eq!(median(&[3.0, 1.0, 2.0]), 2.0);
        assert_eq!(median(&[4.0, 1.0, 3.0, 2.0]), 2.5);
        assert_eq!(median(&[f64::NAN, 5.0]), 5.0);
    }

    #[test]
    fn trimming_removes_extremes() {
        let value = trimmed_mean(&[1.0, 2.0, 100.0, 3.0, 4.0], 0.2);
        assert!((value - 3.0).abs() < 1.0);
    }

    #[test]
    fn geometric_mean_is_stable() {
        let value = geometric_mean(&[1000.0, 1000.0, 1000.0]);
        assert!((value - 1000.0).abs() < 0.001);
        assert_eq!(geometric_mean(&[0.0, -1.0]), 0.0);
    }
}
