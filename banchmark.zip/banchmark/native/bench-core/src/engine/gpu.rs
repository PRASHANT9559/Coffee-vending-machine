//! GPU probe using a headless EGL + OpenGL ES 3.0 context.
//!
//! A 1024×1024 offscreen fragment workload is rendered and read back every
//! frame, so the number reflects actual shader execution and memory traffic,
//! not just command submission. It is deliberately driver-facing: no vendor
//! detection, no upscaling tricks.
//!
//! Vulkan compute, ray tracing and mesh shaders are the next GPU milestone;
//! this GLES path is the portable baseline that works on every API 29 device.

use std::hint::black_box;
use std::time::Instant;

use glow::HasContext;
use khronos_egl as egl;

use crate::engine::result::{ComponentResult, MetricResult};
use crate::engine::{scoring, stats};

const WIDTH: i32 = 1024;
const HEIGHT: i32 = 1024;
const REF_MPIX_PER_SEC: f64 = 24.0;

const VERTEX_SOURCE: &str = r#"#version 300 es
layout(location = 0) in vec2 position;
out vec2 uv;
void main() {
    uv = position * 0.5 + 0.5;
    gl_Position = vec4(position, 0.0, 1.0);
}
"#;

// 48 dependent trig steps per pixel. The dependency chain keeps the compiler
// from turning the loop into a constant, and the loop trip count is fixed so
// the work per pixel is identical across drivers.
const FRAGMENT_SOURCE: &str = r#"#version 300 es
precision highp float;
in vec2 uv;
out vec4 color;
uniform float uTime;
void main() {
    vec2 p = uv * 8.0 - 4.0;
    float accumulator = 0.0;
    for (int i = 0; i < 48; i++) {
        p = p + vec2(sin(p.y * 1.7 + uTime), cos(p.x * 1.3 - uTime)) * 0.05;
        accumulator += sin(p.x * p.y) * cos(p.x + p.y);
    }
    color = vec4(accumulator * 0.01, uv, 1.0);
}
"#;

struct EglContext {
    instance: egl::DynamicInstance<egl::EGL1_4>,
    display: egl::Display,
    surface: egl::Surface,
    context: egl::Context,
}

impl EglContext {
    fn create() -> Result<Self, String> {
        let instance = unsafe { egl::DynamicInstance::<egl::EGL1_4>::load_required() }
            .map_err(|error| format!("could not load EGL: {error}"))?;

        let display = unsafe { instance.get_display(egl::DEFAULT_DISPLAY) }
            .ok_or_else(|| "no EGL display available".to_string())?;

        instance
            .initialize(display)
            .map_err(|error| format!("EGL initialize failed: {error}"))?;

        let config_attributes = [
            egl::SURFACE_TYPE,
            egl::PBUFFER_BIT,
            egl::RENDERABLE_TYPE,
            egl::OPENGL_ES3_BIT,
            egl::RED_SIZE,
            8,
            egl::GREEN_SIZE,
            8,
            egl::BLUE_SIZE,
            8,
            egl::ALPHA_SIZE,
            8,
            egl::NONE,
        ];
        let config = instance
            .choose_first_config(display, &config_attributes)
            .map_err(|error| format!("EGL config selection failed: {error}"))?
            .ok_or_else(|| "no EGL config supports ES 3.0 pbuffers".to_string())?;

        let context_attributes = [
            egl::CONTEXT_MAJOR_VERSION,
            3,
            egl::CONTEXT_MINOR_VERSION,
            0,
            egl::NONE,
        ];
        let context = instance
            .create_context(display, config, None, &context_attributes)
            .map_err(|error| format!("EGL context creation failed: {error}"))?;

        let surface_attributes = [egl::WIDTH, WIDTH, egl::HEIGHT, HEIGHT, egl::NONE];
        let surface = instance
            .create_pbuffer_surface(display, config, &surface_attributes)
            .map_err(|error| format!("EGL pbuffer creation failed: {error}"))?;

        instance
            .make_current(display, Some(surface), Some(surface), Some(context))
            .map_err(|error| format!("EGL make_current failed: {error}"))?;

        Ok(Self {
            instance,
            display,
            surface,
            context,
        })
    }

    fn swap(&self) {
        let _ = self.instance.swap_buffers(self.display, self.surface);
    }
}

impl Drop for EglContext {
    fn drop(&mut self) {
        let _ = self.instance.make_current(self.display, None, None, None);
        let _ = self.instance.destroy_context(self.display, self.context);
        let _ = self.instance.destroy_surface(self.display, self.surface);
        let _ = self.instance.terminate(self.display);
    }
}

unsafe fn compile_shader(
    gl: &glow::Context,
    kind: u32,
    source: &str,
) -> Result<glow::Shader, String> {
    let shader = gl
        .create_shader(kind)
        .map_err(|error| format!("create_shader failed: {error}"))?;
    gl.shader_source(shader, source);
    gl.compile_shader(shader);
    if !gl.get_shader_compile_status(shader) {
        let log = gl.get_shader_info_log(shader);
        gl.delete_shader(shader);
        return Err(format!("shader compile failed: {log}"));
    }
    Ok(shader)
}

unsafe fn create_program(gl: &glow::Context) -> Result<glow::Program, String> {
    let vertex = compile_shader(gl, glow::VERTEX_SHADER, VERTEX_SOURCE)?;
    let fragment = compile_shader(gl, glow::FRAGMENT_SHADER, FRAGMENT_SOURCE)?;
    let program = gl
        .create_program()
        .map_err(|error| format!("create_program failed: {error}"))?;
    gl.attach_shader(program, vertex);
    gl.attach_shader(program, fragment);
    gl.link_program(program);
    gl.detach_shader(program, vertex);
    gl.detach_shader(program, fragment);
    gl.delete_shader(vertex);
    gl.delete_shader(fragment);
    if !gl.get_program_link_status(program) {
        let log = gl.get_program_info_log(program);
        gl.delete_program(program);
        return Err(format!("program link failed: {log}"));
    }
    Ok(program)
}

pub fn run(frames: u32, readback: bool) -> ComponentResult {
    match run_inner(frames.clamp(8, 240), readback) {
        Ok(result) => result,
        Err(error) => crate::engine::result::error_component("gpu", error),
    }
}

fn run_inner(frames: u32, readback: bool) -> Result<ComponentResult, String> {
    let egl_context = EglContext::create()?;
    let instance = &egl_context.instance;

    let gl = unsafe {
        glow::Context::from_loader_function(|symbol| {
            match instance.get_proc_address(symbol) {
                Some(function) => function as *const std::ffi::c_void,
                None => std::ptr::null(),
            }
        })
    };

    unsafe {
        let program = create_program(&gl)?;

        let vao = gl
            .create_vertex_array()
            .map_err(|error| format!("create_vertex_array failed: {error}"))?;
        gl.bind_vertex_array(Some(vao));

        let buffer = gl
            .create_buffer()
            .map_err(|error| format!("create_buffer failed: {error}"))?;
        gl.bind_buffer(glow::ARRAY_BUFFER, Some(buffer));
        let vertices: [f32; 6] = [-1.0, -1.0, 3.0, -1.0, -1.0, 3.0];
        let vertex_bytes = std::slice::from_raw_parts(
            vertices.as_ptr() as *const u8,
            vertices.len() * std::mem::size_of::<f32>(),
        );
        gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, vertex_bytes, glow::STATIC_DRAW);
        gl.enable_vertex_attrib_array(0);
        gl.vertex_attrib_pointer_f32(0, 2, glow::FLOAT, false, 8, 0);

        gl.use_program(Some(program));
        gl.viewport(0, 0, WIDTH, HEIGHT);
        let time_uniform = gl.get_uniform_location(program, "uTime");

        let pixel_count = (WIDTH * HEIGHT) as usize;
        let mut pixels = if readback {
            vec![0u8; pixel_count * 4]
        } else {
            Vec::new()
        };

        // Warm up compilation, clocks and the surface.
        for _ in 0..2 {
            gl.clear(glow::COLOR_BUFFER_BIT);
            gl.draw_arrays(glow::TRIANGLES, 0, 3);
        }
        gl.finish();
        egl_context.swap();

        let started = Instant::now();
        let mut checksum = 0u8;
        let mut frame_rates = Vec::with_capacity(frames as usize);
        let mut previous = Instant::now();
        for frame in 0..frames {
            if let Some(location) = time_uniform.as_ref() {
                gl.uniform_1_f32(Some(location), frame as f32 * 0.01);
            }
            gl.clear_color(0.0, 0.0, 0.0, 1.0);
            gl.clear(glow::COLOR_BUFFER_BIT);
            gl.draw_arrays(glow::TRIANGLES, 0, 3);
            if readback {
                gl.read_pixels(
                    0,
                    0,
                    WIDTH,
                    HEIGHT,
                    glow::RGBA,
                    glow::UNSIGNED_BYTE,
                    glow::PixelPackData::Slice(Some(&mut pixels)),
                );
                checksum = checksum.wrapping_add(pixels[0]);
            }
            egl_context.swap();
            let now = Instant::now();
            let delta = now.duration_since(previous).as_secs_f64().max(1e-6);
            frame_rates.push(1.0 / delta);
            previous = now;
        }
        gl.finish();
        black_box(checksum);

        let seconds = started.elapsed().as_secs_f64().max(1e-6);
        let frames_per_second = frames as f64 / seconds;
        let megapixels_per_second =
            (frames as f64 * WIDTH as f64 * HEIGHT as f64) / 1_000_000.0 / seconds;

        gl.delete_buffer(buffer);
        gl.bind_vertex_array(None);
        gl.delete_vertex_array(vao);
        gl.delete_program(program);

        let score = scoring::normalize(megapixels_per_second, REF_MPIX_PER_SEC);
        let timeline = frame_rates
            .iter()
            .enumerate()
            .take(60)
            .map(|(index, rate)| crate::engine::result::Sample {
                t_ms: (index as f64 + 1.0) / frames_per_second * 1000.0,
                value: *rate,
            })
            .collect::<Vec<_>>();

        let metrics = vec![
            MetricResult::new(
                "gpu.fill",
                "Fragment throughput",
                megapixels_per_second,
                "Mpix/s",
                score,
                REF_MPIX_PER_SEC,
            ),
            MetricResult::new(
                "gpu.fps",
                "Offscreen frame rate",
                frames_per_second,
                "fps",
                scoring::normalize(frames_per_second, REF_MPIX_PER_SEC / (WIDTH as f64 * HEIGHT as f64) * 1_000_000.0),
                REF_MPIX_PER_SEC / (WIDTH as f64 * HEIGHT as f64) * 1_000_000.0,
            ),
        ];

        // GLES work per frame is deterministic, so frame-to-frame fps variance
        // is the honest variance signal (readback shows up in the first frame).
        let cv = stats::coefficient_of_variation(&frame_rates);
        Ok(ComponentResult::new(
            "gpu",
            score,
            stats::confidence_from_cv(cv).min(0.85),
            cv,
            (seconds * 1000.0).round() as u64,
            metrics,
            timeline,
            vec![
                format!("{} × {} offscreen, {} frames, 48-step fragment workload", WIDTH, HEIGHT, frames),
                if readback {
                    "Readback enabled, so the result includes GPU→CPU transfer cost".to_string()
                } else {
                    "Readback disabled; measures raster only".to_string()
                },
                "GLES 3.0 baseline. Vulkan compute and ray tracing are pending".to_string(),
            ],
        ))
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn gpu_failure_is_reported_not_panicked() {
        // Headless CI hosts usually have no EGL display; the contract is that
        // this returns a normal component with a note rather than aborting.
        let result = super::run(8, false);
        assert_eq!(result.component, "gpu");
        if result.score == 0.0 {
            assert!(!result.notes.is_empty());
        }
    }
}
