//! Feature 2.8: Vulkan Feature & Extension Scanner.
//!
//! Enumerates Vulkan instance and driver version, physical devices, features,
//! extensions, memory heaps, and queue families. Translates low-level driver
//! capabilities into a hardware readiness score and plain-English verdict
//! for modern game engines and emulators.

use std::collections::BTreeMap;
use std::ffi::CStr;

use ash::vk;
use serde::Serialize;

use crate::engine::result::{ComponentResult, MetricResult};
use crate::engine::scoring;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VulkanQueueFamilyInfo {
    pub index: u32,
    pub queue_count: u32,
    pub supports_graphics: bool,
    pub supports_compute: bool,
    pub supports_transfer: bool,
    pub timestamp_valid_bits: u32,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VulkanCapabilities {
    pub supported: bool,
    pub api_version: String,
    pub driver_version: String,
    pub device_name: String,
    pub device_type: String,
    pub vendor_id: u32,
    pub device_id: u32,
    pub extensions: Vec<String>,
    pub features: BTreeMap<String, bool>,
    pub queue_families: Vec<VulkanQueueFamilyInfo>,
    pub memory_heaps_mb: f64,
    pub readiness_score: f64,
    pub verdict: String,
    pub notes: Vec<String>,
}

impl VulkanCapabilities {
    pub fn unavailable(reason: impl Into<String>) -> Self {
        let msg = reason.into();
        Self {
            supported: false,
            api_version: "0.0.0".to_string(),
            driver_version: "unavailable".to_string(),
            device_name: "Unavailable".to_string(),
            device_type: "None".to_string(),
            vendor_id: 0,
            device_id: 0,
            extensions: Vec::new(),
            features: BTreeMap::new(),
            queue_families: Vec::new(),
            memory_heaps_mb: 0.0,
            readiness_score: 0.0,
            verdict: "Vulkan Not Supported: Software / GLES fallback only".to_string(),
            notes: vec![msg],
        }
    }
}

/// Executes the full Vulkan feature and extension scan.
pub fn scan() -> VulkanCapabilities {
    match scan_inner() {
        Ok(caps) => caps,
        Err(err) => VulkanCapabilities::unavailable(err),
    }
}

/// Converts Vulkan scan result into a standard ComponentResult.
pub fn scan_as_component() -> ComponentResult {
    let caps = scan();
    let score = caps.readiness_score;

    let mut metrics = vec![
        MetricResult::new(
            "vulkan.readiness_score",
            "Vulkan Engine Readiness",
            caps.readiness_score,
            "pts",
            caps.readiness_score,
            1000.0,
        ),
        MetricResult::new(
            "vulkan.extensions_count",
            "Available Extensions",
            caps.extensions.len() as f64,
            "ext",
            scoring::normalize(caps.extensions.len() as f64, 120.0),
            120.0,
        ),
        MetricResult::new(
            "vulkan.queue_families",
            "Queue Families",
            caps.queue_families.len() as f64,
            "queues",
            scoring::normalize(caps.queue_families.len() as f64, 3.0),
            3.0,
        ),
        MetricResult::new(
            "vulkan.memory_mb",
            "Video Memory Heaps",
            caps.memory_heaps_mb,
            "MB",
            scoring::normalize(caps.memory_heaps_mb, 4096.0),
            4096.0,
        ),
    ];

    if caps.supported {
        let rt_val = if caps.features.get("ray_tracing").copied().unwrap_or(false) {
            1.0
        } else {
            0.0
        };
        let mesh_val = if caps.features.get("mesh_shaders").copied().unwrap_or(false) {
            1.0
        } else {
            0.0
        };
        metrics.push(MetricResult::new(
            "vulkan.ray_tracing",
            "Hardware Ray Tracing",
            rt_val,
            "flag",
            rt_val * 1000.0,
            1.0,
        ));
        metrics.push(MetricResult::new(
            "vulkan.mesh_shaders",
            "Mesh Shaders",
            mesh_val,
            "flag",
            mesh_val * 1000.0,
            1.0,
        ));
    }

    ComponentResult::new(
        "vulkan_scan",
        score,
        if caps.supported { 1.0 } else { 0.0 },
        0.0,
        15,
        metrics,
        Vec::new(),
        caps.notes,
    )
}

fn scan_inner() -> Result<VulkanCapabilities, String> {
    let entry = unsafe { ash::Entry::load() }
        .map_err(|error| format!("Vulkan loader (libvulkan.so) is unavailable: {error}"))?;

    let app_info = vk::ApplicationInfo::default()
        .application_name(c"BenchSuite")
        .application_version(vk::make_api_version(0, 1, 0, 0))
        .api_version(vk::make_api_version(0, 1, 3, 0));

    let create_info = vk::InstanceCreateInfo::default().application_info(&app_info);

    let instance = match unsafe { entry.create_instance(&create_info, None) } {
        Ok(inst) => inst,
        Err(_) => {
            // Fallback to Vulkan 1.0 instance if 1.3 is rejected by older drivers
            let legacy_info = vk::ApplicationInfo::default()
                .application_name(c"BenchSuite")
                .api_version(vk::make_api_version(0, 1, 0, 0));
            let legacy_create = vk::InstanceCreateInfo::default().application_info(&legacy_info);
            unsafe { entry.create_instance(&legacy_create, None) }
                .map_err(|e| format!("Failed to create Vulkan instance: {e}"))?
        }
    };

    let result = inspect_vulkan_device(&instance);
    unsafe { instance.destroy_instance(None) };
    result
}

fn inspect_vulkan_device(instance: &ash::Instance) -> Result<VulkanCapabilities, String> {
    let physical_devices = unsafe { instance.enumerate_physical_devices() }
        .map_err(|e| format!("Failed to enumerate physical devices: {e}"))?;

    if physical_devices.is_empty() {
        return Err("No Vulkan physical devices reported by driver.".to_string());
    }

    let pdevice = physical_devices[0];
    let properties = unsafe { instance.get_physical_device_properties(pdevice) };
    let core_features = unsafe { instance.get_physical_device_features(pdevice) };
    let mem_properties = unsafe { instance.get_physical_device_memory_properties(pdevice) };
    let queue_properties =
        unsafe { instance.get_physical_device_queue_family_properties(pdevice) };

    let extension_props = unsafe { instance.enumerate_device_extension_properties(pdevice) }
        .map_err(|e| format!("Failed to enumerate device extensions: {e}"))?;

    let extensions: Vec<String> = extension_props
        .iter()
        .map(|ext| {
            unsafe { CStr::from_ptr(ext.extension_name.as_ptr()) }
                .to_string_lossy()
                .into_owned()
        })
        .collect();

    let has_ext = |name: &str| extensions.iter().any(|ext| ext == name);

    let device_name = unsafe { CStr::from_ptr(properties.device_name.as_ptr()) }
        .to_string_lossy()
        .into_owned();

    let device_type = match properties.device_type {
        vk::PhysicalDeviceType::DISCRETE_GPU => "Discrete GPU",
        vk::PhysicalDeviceType::INTEGRATED_GPU => "Integrated GPU",
        vk::PhysicalDeviceType::VIRTUAL_GPU => "Virtual GPU",
        vk::PhysicalDeviceType::CPU => "CPU",
        _ => "Other",
    }
    .to_string();

    let api_major = vk::api_version_major(properties.api_version);
    let api_minor = vk::api_version_minor(properties.api_version);
    let api_patch = vk::api_version_patch(properties.api_version);
    let api_version = format!("{api_major}.{api_minor}.{api_patch}");
    let driver_version = format!("{}", properties.driver_version);

    let mut queue_families = Vec::new();
    for (index, q) in queue_properties.iter().enumerate() {
        queue_families.push(VulkanQueueFamilyInfo {
            index: index as u32,
            queue_count: q.queue_count,
            supports_graphics: q.queue_flags.contains(vk::QueueFlags::GRAPHICS),
            supports_compute: q.queue_flags.contains(vk::QueueFlags::COMPUTE),
            supports_transfer: q.queue_flags.contains(vk::QueueFlags::TRANSFER),
            timestamp_valid_bits: q.timestamp_valid_bits,
        });
    }

    let mut total_mem_bytes = 0u64;
    for i in 0..mem_properties.memory_heap_count as usize {
        total_mem_bytes += mem_properties.memory_heaps[i].size;
    }
    let memory_heaps_mb = (total_mem_bytes as f64) / (1024.0 * 1024.0);

    // Build features dictionary
    let mut features = BTreeMap::new();
    features.insert(
        "geometry_shader".to_string(),
        core_features.geometry_shader == vk::TRUE,
    );
    features.insert(
        "tessellation_shader".to_string(),
        core_features.tessellation_shader == vk::TRUE,
    );
    features.insert(
        "multi_draw_indirect".to_string(),
        core_features.multi_draw_indirect == vk::TRUE,
    );
    features.insert(
        "sampler_anisotropy".to_string(),
        core_features.sampler_anisotropy == vk::TRUE,
    );
    features.insert(
        "texture_compression_etc2".to_string(),
        core_features.texture_compression_etc2 == vk::TRUE,
    );
    features.insert(
        "texture_compression_astc_ldr".to_string(),
        core_features.texture_compression_astc_ldr == vk::TRUE,
    );
    features.insert(
        "shader_float64".to_string(),
        core_features.shader_float64 == vk::TRUE,
    );
    features.insert(
        "shader_int64".to_string(),
        core_features.shader_int64 == vk::TRUE,
    );
    features.insert(
        "shader_int16".to_string(),
        core_features.shader_int16 == vk::TRUE,
    );

    // Advanced & modern pipeline features
    let ray_tracing = has_ext("VK_KHR_ray_tracing_pipeline");
    let ray_query = has_ext("VK_KHR_ray_query");
    let mesh_shaders = has_ext("VK_EXT_mesh_shader");
    let acceleration_structure = has_ext("VK_KHR_acceleration_structure");
    let timeline_semaphores = has_ext("VK_KHR_timeline_semaphore") || (api_major >= 1 && api_minor >= 2);
    let dynamic_rendering = has_ext("VK_KHR_dynamic_rendering") || (api_major >= 1 && api_minor >= 3);
    let synchronization2 = has_ext("VK_KHR_synchronization2") || (api_major >= 1 && api_minor >= 3);
    let descriptor_indexing = has_ext("VK_EXT_descriptor_indexing") || (api_major >= 1 && api_minor >= 2);

    features.insert("ray_tracing".to_string(), ray_tracing);
    features.insert("ray_query".to_string(), ray_query);
    features.insert("mesh_shaders".to_string(), mesh_shaders);
    features.insert("acceleration_structure".to_string(), acceleration_structure);
    features.insert("timeline_semaphores".to_string(), timeline_semaphores);
    features.insert("dynamic_rendering".to_string(), dynamic_rendering);
    features.insert("synchronization2".to_string(), synchronization2);
    features.insert("descriptor_indexing".to_string(), descriptor_indexing);

    // Calculate Engine Readiness Score (0 to 1000)
    let mut score: f64 = 400.0; // Base Vulkan presence
    if api_minor >= 1 || api_major > 1 {
        score += 150.0;
    }
    if api_minor >= 2 || api_major > 1 {
        score += 150.0;
    }
    if api_minor >= 3 || api_major > 1 {
        score += 100.0;
    }
    if timeline_semaphores {
        score += 50.0;
    }
    if dynamic_rendering {
        score += 50.0;
    }
    if synchronization2 {
        score += 50.0;
    }
    if descriptor_indexing {
        score += 50.0;
    }
    if ray_tracing {
        score += 50.0;
    }
    if mesh_shaders {
        score += 50.0;
    }
    score = score.clamp(0.0, 1000.0);

    let verdict = if api_major >= 1 && api_minor >= 3 && dynamic_rendering && synchronization2 {
        "Vulkan 1.3 Modern Ready: Full AAA Engine & Emulator Pipeline Supported".to_string()
    } else if api_major >= 1 && api_minor >= 2 && timeline_semaphores {
        "Vulkan 1.2 Ready: Modern Graphics & Compute Pipeline Supported".to_string()
    } else if api_major >= 1 && api_minor >= 1 {
        "Vulkan 1.1 Baseline: Standard Mobile Shaders Supported".to_string()
    } else {
        "Vulkan 1.0 Legacy: Minimal Feature Set".to_string()
    };

    let mut notes = vec![
        format!("Vulkan {api_version} on {device_name} ({device_type})."),
        format!("Driver version: {driver_version}. Device ID: 0x{:04x}, Vendor: 0x{:04x}.", properties.device_id, properties.vendor_id),
        format!("Total {} device extensions and {} queue families exposed.", extensions.len(), queue_families.len()),
        format!("Verdict: {verdict}"),
    ];

    if ray_tracing {
        notes.push("Hardware Ray Tracing (VK_KHR_ray_tracing_pipeline) is supported.".to_string());
    } else {
        notes.push("Hardware Ray Tracing is not supported on this driver.".to_string());
    }

    if mesh_shaders {
        notes.push("Mesh Shaders (VK_EXT_mesh_shader) are supported.".to_string());
    }

    Ok(VulkanCapabilities {
        supported: true,
        api_version,
        driver_version,
        device_name,
        device_type,
        vendor_id: properties.vendor_id,
        device_id: properties.device_id,
        extensions,
        features,
        queue_families,
        memory_heaps_mb: (memory_heaps_mb * 10.0).round() / 10.0,
        readiness_score: score,
        verdict,
        notes,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scan_never_panics_even_without_gpu() {
        let caps = scan();
        if !caps.supported {
            assert_eq!(caps.api_version, "0.0.0");
            assert!(!caps.notes.is_empty());
        } else {
            assert!(caps.readiness_score > 0.0);
            assert!(!caps.device_name.is_empty());
        }
    }

    #[test]
    fn scan_as_component_returns_valid_structure() {
        let comp = scan_as_component();
        assert_eq!(comp.component, "vulkan_scan");
        assert!(comp.metrics.len() >= 3);
    }
}
