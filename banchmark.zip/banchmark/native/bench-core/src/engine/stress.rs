//! Sustained-load probe for the Stress Test screen.
//!
//! Workers hammer every core while the parent samples aggregate throughput.
//! Real thermal throttling shows up as a falling timeline; the score is based on
//! sustained throughput, never the peak.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

use crate::engine::result::{ComponentResult, MetricResult, Sample};
use crate::engine::{scoring, stats};

const REF_SUSTAINED_OPS: f64 = 3_000_000_000.0;
const WORK_CHUNK: u64 = 2_000_000;
const SAMPLE_INTERVAL_MS: u64 = 250;

#[inline]
fn integer_work(iterations: u64) -> u64 {
    let mut state = 0x9E37_79B9_7F4A_7C15u64;
    for _ in 0..iterations {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        state = state.wrapping_mul(0x2545_F491_4F6C_DD1D);
    }
    std::hint::black_box(state);
    iterations
}

pub fn run(duration_ms: u64, requested_threads: usize) -> ComponentResult {
    let duration = Duration::from_millis(duration_ms.clamp(1_000, 60_000));
    let cores = thread::available_parallelism()
        .map(|value| value.get())
        .unwrap_or(4);
    let threads = requested_threads.clamp(1, cores.max(1));

    let stop = Arc::new(AtomicBool::new(false));
    let counter = Arc::new(AtomicU64::new(0));
    let mut handles = Vec::with_capacity(threads);

    for _ in 0..threads {
        let stop = Arc::clone(&stop);
        let counter = Arc::clone(&counter);
        handles.push(thread::spawn(move || {
            while !stop.load(Ordering::Relaxed) {
                counter.fetch_add(integer_work(WORK_CHUNK), Ordering::Relaxed);
            }
        }));
    }

    let started = Instant::now();
    let mut previous = 0u64;
    let mut previous_at = started;
    let mut samples: Vec<Sample> = Vec::new();

    while started.elapsed() < duration {
        let remaining = duration.saturating_sub(started.elapsed());
        let sleep_for = Duration::from_millis(SAMPLE_INTERVAL_MS).min(remaining);
        if sleep_for > Duration::from_millis(0) {
            thread::sleep(sleep_for);
        }

        let total = counter.load(Ordering::Relaxed);
        let now = Instant::now();
        let seconds = now.duration_since(previous_at).as_secs_f64().max(1e-6);
        let delta = total.saturating_sub(previous);
        previous = total;
        previous_at = now;
        samples.push(Sample {
            t_ms: now.duration_since(started).as_secs_f64() * 1000.0,
            value: delta as f64 / seconds,
        });
    }

    stop.store(true, Ordering::Relaxed);
    for handle in handles {
        let _ = handle.join();
    }

    if samples.is_empty() {
        let elapsed = started.elapsed().as_secs_f64().max(1e-6);
        samples.push(Sample {
            t_ms: elapsed * 1000.0,
            value: previous as f64 / elapsed,
        });
    }

    let values: Vec<f64> = samples.iter().map(|sample| sample.value).collect();
    let early_count = values.len().min(3).max(1);
    let late_count = values.len().min(3);
    let peak = stats::median(&values[..early_count]);
    let sustained = stats::median(&values[values.len() - late_count..]);
    let decay_percent = if peak > 0.0 {
        ((1.0 - sustained / peak) * 100.0).clamp(0.0, 100.0)
    } else {
        0.0
    };

    let score = scoring::normalize(sustained, REF_SUSTAINED_OPS);
    let tail = &values[values.len() / 2..];
    let cv = stats::coefficient_of_variation(tail);
    let confidence = stats::confidence_from_cv(cv);
    let decay_score = (1000.0 - decay_percent * 10.0).clamp(0.0, 1000.0);

    let mut timeline = samples.clone();
    for sample in &mut timeline {
        sample.value /= 1e6;
    }

    let metrics = vec![
        MetricResult::new(
            "stress.peak",
            "Peak throughput",
            peak / 1e6,
            "Mops/s",
            scoring::normalize(peak, REF_SUSTAINED_OPS),
            REF_SUSTAINED_OPS / 1e6,
        ),
        MetricResult::new(
            "stress.sustained",
            "Sustained throughput",
            sustained / 1e6,
            "Mops/s",
            score,
            REF_SUSTAINED_OPS / 1e6,
        ),
        MetricResult::new(
            "stress.decay",
            "Throughput decay",
            decay_percent,
            "%",
            decay_score,
            0.0,
        ),
    ];

    ComponentResult::new(
        "sustained",
        score,
        confidence,
        cv,
        duration.as_millis() as u64,
        metrics,
        timeline,
        vec![
            format!("{} worker threads held at 100% for {} s", threads, duration.as_secs()),
            "Aggregate throughput sampled every 250 ms; score uses the sustained tail".to_string(),
            "Temperature and power are sampled by Kotlin and correlated on the device".to_string(),
        ],
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sustained_run_produces_a_timeline() {
        let result = run(1_100, 2);
        assert_eq!(result.component, "sustained");
        assert_eq!(result.metrics.len(), 3);
        assert!(result.samples.len() >= 2);
        assert!(result.score > 0.0);
    }
}
