//! Memory kernels: sequential read/write/copy bandwidth and random-access
//! latency. Buffers are allocated once, before timing.

use std::hint::black_box;
use std::time::Duration;

use crate::engine::measure;
use crate::engine::result::{ComponentResult, MetricResult, Sample};
use crate::engine::{scoring, stats};

const REF_READ_BPS: f64 = 12.0e9;
const REF_WRITE_BPS: f64 = 8.0e9;
const REF_COPY_BPS: f64 = 10.0e9;
const REF_LATENCY_NS: f64 = 110.0;

const CHASE_ENTRIES: usize = 1 << 20;
const CHASE_ACCESSES: u64 = 131_072;

#[inline]
fn checksum(values: &[u64]) -> u64 {
    let mut sum = 0u64;
    for &value in values {
        sum = sum.wrapping_add(value);
    }
    black_box(sum)
}

/// Build a random permutation used as a pointer-chase map. Walking it defeats
/// the hardware prefetcher, which is what makes latency meaningful.
fn build_chase_map(entries: usize) -> Vec<u32> {
    let mut map: Vec<u32> = (0..entries as u32).collect();
    let mut state = 0x2545_F491_4F6C_DD1Du64;
    for index in (1..entries).rev() {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        let swap_with = (state % (index as u64 + 1)) as usize;
        map.swap(index, swap_with);
    }
    map
}

#[inline]
fn chase(map: &[u32], accesses: usize) -> u32 {
    let mut cursor = 0usize;
    for _ in 0..accesses {
        cursor = map[cursor] as usize;
    }
    cursor as u32
}

pub fn run(duration_ms: u64, buffer_mb: u64) -> ComponentResult {
    let duration = Duration::from_millis(duration_ms.clamp(200, 10_000));
    let megabytes = buffer_mb.clamp(4, 128);
    let words = (megabytes as usize * 1024 * 1024 / 8).max(1024);
    let bytes = (words * 8) as f64;

    let mut source = vec![0u64; words];
    for (index, value) in source.iter_mut().enumerate() {
        *value = (index as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
    }
    let mut destination = vec![0u64; words];

    // Warm the allocator, page tables and caches.
    black_box(checksum(&source));
    destination.copy_from_slice(&source);

    let read = measure::run(duration, || {
        black_box(checksum(&source));
        bytes as u64
    });

    let mut seed = 0x1234_5678_9ABC_DEF0u64;
    let write = measure::run(duration, || {
        seed = seed.wrapping_add(0x9E37_79B9_7F4A_7C15);
        destination.fill(seed);
        bytes as u64
    });

    let copy = measure::run(duration, || {
        destination.copy_from_slice(&source);
        bytes as u64
    });

    let chase_map = build_chase_map(CHASE_ENTRIES);
    let latency = measure::run(duration, || {
        black_box(chase(&chase_map, CHASE_ACCESSES as usize));
        CHASE_ACCESSES
    });

    let read_rate = read.rate();
    let write_rate = write.rate();
    let copy_rate = copy.rate();
    let latency_ns = if latency.rate() > 0.0 {
        1e9 / latency.rate()
    } else {
        f64::INFINITY
    };

    let read_score = scoring::normalize(read_rate, REF_READ_BPS);
    let write_score = scoring::normalize(write_rate, REF_WRITE_BPS);
    let copy_score = scoring::normalize(copy_rate, REF_COPY_BPS);
    let latency_score = scoring::inverse_normalize(latency_ns, REF_LATENCY_NS);
    let score = scoring::geometric_mean(&[read_score, write_score, copy_score, latency_score]);

    let (cv, confidence) = measure::sample_confidence(&read.samples);
    let mut timeline = read.samples.clone();
    for sample in &mut timeline {
        sample.value /= 1e9;
    }

    let metrics = vec![
        MetricResult::new(
            "memory.read",
            "Sequential read",
            read_rate / 1e9,
            "GB/s",
            read_score,
            REF_READ_BPS / 1e9,
        ),
        MetricResult::new(
            "memory.write",
            "Sequential write",
            write_rate / 1e9,
            "GB/s",
            write_score,
            REF_WRITE_BPS / 1e9,
        ),
        MetricResult::new(
            "memory.copy",
            "Copy bandwidth",
            copy_rate / 1e9,
            "GB/s",
            copy_score,
            REF_COPY_BPS / 1e9,
        ),
        MetricResult::new(
            "memory.latency",
            "Random latency",
            latency_ns,
            "ns",
            latency_score,
            REF_LATENCY_NS,
        ),
    ];

    ComponentResult::new(
        "memory",
        score,
        confidence,
        cv,
        duration.as_millis() as u64,
        metrics,
        timeline,
        vec![
            format!("{} MiB working set; pointer chase over 1M entries", megabytes),
            "Read timeline is sequential bandwidth in GB/s".to_string(),
            "Reference device = 1000 (12 GB/s read, 8 GB/s write, 110 ns latency)".to_string(),
        ],
    )
}

/// Reads MemAvailable from /proc/meminfo in MiB.
fn get_available_memory_mb() -> Option<u64> {
    #[cfg(unix)]
    {
        if let Ok(content) = std::fs::read_to_string("/proc/meminfo") {
            for line in content.lines() {
                if line.starts_with("MemAvailable:") {
                    let parts: Vec<&str> = line.split_whitespace().collect();
                    if parts.len() >= 2 {
                        if let Ok(kb) = parts[1].parse::<u64>() {
                            return Some(kb / 1024);
                        }
                    }
                }
            }
        }
    }
    None
}

/// Feature 4.3: Memory Pressure Cascade Test.
///
/// Gradually increases memory pressure by allocating and dirtying page-aligned chunks,
/// measuring step allocation latency, physical page commit throughput, latency spikes
/// (swapping / page reclaim inflection points), and safely terminates before OOM.
pub fn run_cascade(target_mb: u64, step_mb: u64) -> ComponentResult {
    let target = target_mb.clamp(64, 4096);
    let step = step_mb.clamp(16, 128);
    let page_size = crate::engine::page_size().max(4096) as usize;
    let chunk_bytes = (step as usize) * 1024 * 1024;

    let start = std::time::Instant::now();
    let mut chunks: Vec<Vec<u8>> = Vec::new();
    let mut step_latencies_ms = Vec::new();
    let mut samples = Vec::new();

    let mut committed_mb = 0u64;
    let mut inflection_mb = target;
    let mut inflection_detected = false;
    let mut baseline_latency_ms = 0.0f64;
    let mut termination_reason = "Target capacity reached successfully";

    let safe_headroom_mb = 128u64;

    while committed_mb < target {
        // Safe check: verify kernel MemAvailable before allocating next chunk
        if let Some(available_mb) = get_available_memory_mb() {
            if available_mb <= safe_headroom_mb {
                termination_reason = "Safe termination: kernel MemAvailable dropped to threshold (<128MB) before OOM";
                break;
            }
        }

        let step_start = std::time::Instant::now();

        // Attempt allocation safely
        let mut chunk = match std::panic::catch_unwind(|| vec![0u8; chunk_bytes]) {
            Ok(buf) => buf,
            Err(_) => {
                termination_reason = "Safe termination: memory allocation failed, OOM avoided";
                break;
            }
        };

        // Touch every page to force physical RSS backing and observe swap latency
        let mut tag = 0xAAu8;
        for offset in (0..chunk_bytes).step_by(page_size) {
            chunk[offset] = tag;
            tag = tag.wrapping_add(1);
        }
        std::hint::black_box(&chunk[0]);

        let step_duration_ms = step_start.elapsed().as_secs_f64() * 1000.0;
        step_latencies_ms.push(step_duration_ms);
        committed_mb += step;
        chunks.push(chunk);

        let elapsed_total_ms = start.elapsed().as_secs_f64() * 1000.0;
        samples.push(Sample {
            t_ms: elapsed_total_ms,
            value: committed_mb as f64,
        });

        // Compute baseline latency from initial 3 steps
        if step_latencies_ms.len() <= 3 {
            baseline_latency_ms = stats::mean(&step_latencies_ms);
        } else if !inflection_detected && baseline_latency_ms > 0.0 {
            // Latency jump > 3.0x indicates swapping / kswapd memory reclaim thrashing
            if step_duration_ms > baseline_latency_ms * 3.0 && step_duration_ms > 15.0 {
                inflection_mb = committed_mb;
                inflection_detected = true;
            }
        }

        // Severe latency spike guard (>1500ms on a single chunk step)
        if step_duration_ms > 1500.0 {
            termination_reason = "Inflection limit: step latency exceeded 1500ms under heavy memory reclaim";
            break;
        }
    }

    let total_elapsed_sec = start.elapsed().as_secs_f64().max(1e-6);
    let throughput_mb_s = (committed_mb as f64) / total_elapsed_sec;

    let median_step_ms = stats::median(&step_latencies_ms).max(0.1);
    let p99_step_ms = stats::percentile(&step_latencies_ms, 99.0).max(median_step_ms);

    // Free all chunks now so memory is returned immediately
    drop(chunks);

    let capacity_score = scoring::normalize(committed_mb as f64, 2048.0);
    let throughput_score = scoring::normalize(throughput_mb_s, 1500.0);
    let latency_score = scoring::inverse_normalize(p99_step_ms, 25.0);
    let score = scoring::geometric_mean(&[capacity_score, throughput_score, latency_score]);

    let cv = stats::coefficient_of_variation(&step_latencies_ms);
    let confidence = stats::confidence_from_cv(cv);

    let metrics = vec![
        MetricResult::new(
            "memory.cascade_peak_mb",
            "Committed physical RAM",
            committed_mb as f64,
            "MB",
            capacity_score,
            2048.0,
        ),
        MetricResult::new(
            "memory.cascade_throughput",
            "Allocation throughput",
            throughput_mb_s,
            "MB/s",
            throughput_score,
            1500.0,
        ),
        MetricResult::new(
            "memory.cascade_p99_latency_ms",
            "P99 step latency",
            p99_step_ms,
            "ms",
            latency_score,
            25.0,
        ),
        MetricResult::new(
            "memory.cascade_inflection_mb",
            "Pressure inflection point",
            inflection_mb as f64,
            "MB",
            scoring::normalize(inflection_mb as f64, 2048.0),
            2048.0,
        ),
    ];

    let notes = vec![
        format!("Committed {} MiB across {} steps ({} MiB/step).", committed_mb, step_latencies_ms.len(), step),
        format!("Inflection point detected at {} MiB (latency spiked from {:.1}ms to {:.1}ms).", inflection_mb, baseline_latency_ms, p99_step_ms),
        format!("Cascade status: {}.", termination_reason),
    ];

    ComponentResult::new(
        "memory_cascade",
        score,
        confidence,
        cv,
        start.elapsed().as_millis() as u64,
        metrics,
        samples,
        notes,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn chase_map_is_a_permutation() {
        let map = build_chase_map(1024);
        let mut sorted = map.clone();
        sorted.sort_unstable();
        assert_eq!(sorted, (0..1024u32).collect::<Vec<_>>());
    }

    #[test]
    fn memory_run_measures_all_four_metrics() {
        let result = run(250, 8);
        assert_eq!(result.component, "memory");
        assert_eq!(result.metrics.len(), 4);
        assert!(result.score > 0.0);
        assert!(!result.samples.is_empty());
        for metric in &result.metrics {
            assert!(metric.value.is_finite());
        }
    }

    #[test]
    fn memory_cascade_runs_safely() {
        let result = run_cascade(64, 16);
        assert_eq!(result.component, "memory_cascade");
        assert!(result.score > 0.0);
        assert_eq!(result.metrics.len(), 4);
    }
}
