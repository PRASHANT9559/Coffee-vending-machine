//! Shared timed-loop harness.
//!
//! The work closure returns the number of operations performed by that chunk.
//! We accumulate ops and sample cumulative throughput; the loop checks the
//! monotonic clock only once per chunk, never inside the hot operation.

use std::time::{Duration, Instant};

use super::result::Sample;
use super::stats;

pub struct Measurement {
    pub ops: f64,
    pub elapsed: f64,
    pub samples: Vec<Sample>,
}

impl Measurement {
    pub fn rate(&self) -> f64 {
        if self.elapsed <= 1e-9 {
            0.0
        } else {
            self.ops / self.elapsed
        }
    }

    pub fn values(&self) -> Vec<f64> {
        self.samples.iter().map(|sample| sample.value).collect()
    }
}

pub fn run<F>(duration: Duration, mut work: F) -> Measurement
where
    F: FnMut() -> u64,
{
    let start = Instant::now();
    let mut ops = 0u64;
    let mut samples = Vec::new();
    let mut last_sample = start;

    while start.elapsed() < duration {
        ops = ops.saturating_add(work());
        let now = Instant::now();
        if now.duration_since(last_sample).as_millis() >= 25 {
            let elapsed = now.duration_since(start).as_secs_f64();
            if elapsed > 0.0 {
                samples.push(Sample {
                    t_ms: elapsed * 1000.0,
                    value: ops as f64 / elapsed,
                });
            }
            last_sample = now;
        }
    }

    let elapsed = start.elapsed().as_secs_f64().max(1e-6);
    if samples.len() < 2 {
        samples.push(Sample {
            t_ms: elapsed * 1000.0,
            value: ops as f64 / elapsed,
        });
    }

    Measurement {
        ops: ops as f64,
        elapsed,
        samples,
    }
}

/// CV and confidence from a timeline, skipping the first (warmup) sample.
pub fn sample_confidence(samples: &[Sample]) -> (f64, f64) {
    let values: Vec<f64> = samples.iter().skip(1).map(|sample| sample.value).collect();
    if values.len() < 3 {
        return (0.0, 0.65);
    }
    let cv = stats::coefficient_of_variation(&values);
    (cv, stats::confidence_from_cv(cv))
}
