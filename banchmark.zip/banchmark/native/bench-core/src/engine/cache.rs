//! Cache-hierarchy probe.
//!
//! Builds a pointer-chasing chain whose working set grows from 16 KiB to
//! 16 MiB. The dependent loads cannot be prefetched, so the latency curve shows
//! where L1, L2 and L3 stop helping and DRAM takes over. This is the same
//! technique CPU reviewers use; it needs no perf counters or root.
//!
//! The reported "size" is the first working set whose latency crosses a
//! multiple of the L1 latency, which is an estimate, not a datasheet value.

use std::hint::black_box;
use std::time::Instant;

use crate::engine::result::{ComponentResult, MetricResult, Sample};
use crate::engine::{scoring, stats};

const SIZES: [usize; 11] = [
    16 * 1024,
    32 * 1024,
    64 * 1024,
    128 * 1024,
    256 * 1024,
    512 * 1024,
    1024 * 1024,
    2 * 1024 * 1024,
    4 * 1024 * 1024,
    8 * 1024 * 1024,
    16 * 1024 * 1024,
];

const REF_L1_NS: f64 = 2.0;
const REF_L2_NS: f64 = 6.0;
const REF_L3_NS: f64 = 20.0;
const REF_DRAM_NS: f64 = 90.0;

struct Chain {
    next: Vec<u32>,
    data: Vec<u64>,
    steps: usize,
}

impl Chain {
    fn build(size_bytes: usize, seed: u64) -> Self {
        let length = (size_bytes / 8).max(256);
        let mut order: Vec<u32> = (0..length as u32).collect();
        let mut state = seed | 1;

        // Fisher–Yates with an LCG: deterministic across runs and devices.
        for index in (1..order.len()).rev() {
            state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            let swap = (state >> 33) as usize % (index + 1);
            order.swap(index, swap);
        }

        let mut next = vec![0u32; length];
        for index in 0..order.len() {
            next[order[index] as usize] = order[(index + 1) % order.len()];
        }
        let data = (0..length as u64).collect();
        let steps = if size_bytes <= 1024 * 1024 { 120_000 } else { 25_000 };

        Self { next, data, steps }
    }

    /// Dependent-load walk. Returns elapsed nanoseconds per access.
    fn measure(&self) -> f64 {
        let mut index = 0u32;
        let mut accumulator = 0u64;
        let started = Instant::now();
        for _ in 0..self.steps {
            index = self.next[index as usize];
            accumulator = accumulator.wrapping_add(self.data[index as usize]);
        }
        let elapsed = started.elapsed().as_nanos() as f64;
        black_box(accumulator);
        elapsed / self.steps as f64
    }
}

pub fn run() -> ComponentResult {
    let mut curve: Vec<(usize, f64)> = Vec::with_capacity(SIZES.len());

    for (index, size) in SIZES.iter().enumerate() {
        let chain = Chain::build(*size, 0xB3E7_5A11_u64.wrapping_add(index as u64 * 97));
        // Warm the TLB and the cache level under test.
        black_box(chain.measure());

        let mut samples: Vec<f64> = (0..5).map(|_| chain.measure()).collect();
        samples.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        curve.push((*size, samples[samples.len() / 2]));
    }

    let l1 = curve[0].1.max(0.1);
    let dram = curve[curve.len() - 1].1.max(l1);
    let l2 = curve
        .iter()
        .find(|(_, latency)| latency > &(l1 * 2.2))
        .map(|(_, latency)| *latency)
        .unwrap_or(l1 * 2.2);
    let l3 = curve
        .iter()
        .find(|(_, latency)| latency > &(l1 * 5.0))
        .map(|(_, latency)| *latency)
        .unwrap_or(l1 * 5.0);

    let l1_size = first_over(&curve, l1 * 1.6);
    let l2_size = first_over(&curve, l1 * 2.2);
    let l3_size = first_over(&curve, l1 * 5.0);

    let scores = [
        scoring::inverse_normalize(l1, REF_L1_NS),
        scoring::inverse_normalize(l2, REF_L2_NS),
        scoring::inverse_normalize(l3, REF_L3_NS),
        scoring::inverse_normalize(dram, REF_DRAM_NS),
    ];
    let score = scoring::geometric_mean(&scores);

    let last_chain = Chain::build(SIZES[SIZES.len() - 1], 0xB3E7_5A11_u64.wrapping_add(970));
    let reps: Vec<f64> = (0..5).map(|_| last_chain.measure()).collect();
    let cv = stats::coefficient_of_variation(&reps);
    let confidence = stats::confidence_from_cv(cv);

    let metrics = vec![
        MetricResult::new(
            "cache.l1",
            "L1 latency",
            l1,
            "ns",
            scores[0],
            REF_L1_NS,
        ),
        MetricResult::new(
            "cache.l2",
            "L2 latency",
            l2,
            "ns",
            scores[1],
            REF_L2_NS,
        ),
        MetricResult::new(
            "cache.l3",
            "L3 latency",
            l3,
            "ns",
            scores[2],
            REF_L3_NS,
        ),
        MetricResult::new(
            "cache.dram",
            "DRAM latency",
            dram,
            "ns",
            scores[3],
            REF_DRAM_NS,
        ),
    ];

    let curve_samples = curve
        .iter()
        .map(|(size, latency)| Sample {
            t_ms: (*size as f64) / 1024.0,
            value: *latency,
        })
        .collect();

    let mut notes = vec![
        format!(
            "Estimated L1 ≤ {} · L2 ≤ {} · L3 ≤ {} KB",
            l1_size / 1024,
            l2_size / 1024,
            l3_size / 1024
        ),
        "Dependent-load pointer chase; latency in ns per access, lower is better".to_string(),
        "Working sets are built per run, so shared-cache interference from other apps can shift the curve"
            .to_string(),
    ];
    notes.push(format!(
        "DRAM latency {:.0} ns against a {:.0} ns reference",
        dram, REF_DRAM_NS
    ));

    ComponentResult::new(
        "cache",
        score,
        confidence.min(0.9),
        cv,
        0,
        metrics,
        curve_samples,
        notes,
    )
}

fn first_over(curve: &[(usize, f64)], threshold: f64) -> usize {
    curve
        .iter()
        .find(|(_, latency)| latency > &threshold)
        .map(|(size, _)| *size)
        .unwrap_or_else(|| curve[curve.len() - 1].0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cache_probe_returns_four_levels() {
        let result = run();
        assert_eq!(result.component, "cache");
        assert_eq!(result.metrics.len(), 4);
        assert!(result.score > 0.0);
        assert!(result.samples.len() >= 2);
        assert!(result.metrics[3].value >= result.metrics[0].value);
    }
}
