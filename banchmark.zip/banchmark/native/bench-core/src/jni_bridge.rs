//! JNI surface. One symbol per Kotlin external method on
//! `com.benchsuite.app.nativecore.NativeBridge`.
//!
//! Every method returns a JSON string so the contract can grow without changing
//! JNI signatures. Errors are returned as a scored component with a note instead
//! of throwing across the FFI boundary.

use std::collections::BTreeMap;
use std::path::Path;

use jni::objects::{JObject, JString};
use jni::sys::{jboolean, jdouble, jint, jstring};
use jni::JNIEnv;
use serde::Serialize;

use crate::engine::result::{error_component, ComponentResult};
use crate::engine::{
    self, ai, cache, context_switch, cpu, fairplay, gpu, memory, phase3_async_compute,
    phase3_meshshader, phase3_raytracing, phase4_pqc, scoring, storage, stress, thermal, vulkan,
    vulkan_scan,
};

fn to_jstring(env: &mut JNIEnv, value: String) -> jstring {
    match env.new_string(value) {
        Ok(text) => text.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

fn json_to_jstring<T: Serialize>(mut env: JNIEnv, value: &T) -> jstring {
    match serde_json::to_string(value) {
        Ok(text) => to_jstring(&mut env, text),
        Err(_) => std::ptr::null_mut(),
    }
}

fn read_java_string(env: &mut JNIEnv, value: &JString) -> Option<String> {
    env.get_string(value).ok().map(|text| text.into())
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeVersion<'local>(
    mut env: JNIEnv<'local>,
    _receiver: JObject<'local>,
) -> jstring {
    let result = std::panic::catch_unwind(|| engine::version())
        .unwrap_or_else(|_| "panic inside nativeVersion".to_string());
    to_jstring(&mut env, result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeCapabilities<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
) -> jstring {
    let result = std::panic::catch_unwind(|| engine::capabilities())
        .unwrap_or_else(|_| error_component("capabilities", "panic inside nativeCapabilities".to_string()));
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunCpu<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    threads: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        cpu::run(duration_ms.max(0) as u64, threads.max(0) as usize)
    })
    .unwrap_or_else(|_| {
        error_component("cpu", "panic inside nativeRunCpu".to_string())
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunMemory<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    buffer_mb: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        memory::run(duration_ms.max(0) as u64, buffer_mb.max(0) as u64)
    })
    .unwrap_or_else(|_| {
        error_component("memory", "panic inside nativeRunMemory".to_string())
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunStorage<'local>(
    mut env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    directory: JString<'local>,
    size_mb: jint,
) -> jstring {
    let path = read_java_string(&mut env, &directory);
    let result: ComponentResult = match path {
        Some(path) => std::panic::catch_unwind(|| {
            storage::run(Path::new(&path), size_mb.max(0) as u64)
        })
        .unwrap_or_else(|_| {
            error_component("storage", "panic inside nativeRunStorage".to_string())
        })
        .unwrap_or_else(|error| error_component("storage", error)),
        None => error_component("storage", "storage directory was null".to_string()),
    };
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunStress<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    threads: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        stress::run(duration_ms.max(0) as u64, threads.max(0) as usize)
    })
    .unwrap_or_else(|_| {
        error_component("stress", "panic inside nativeRunStress".to_string())
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunAi<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| ai::run(duration_ms.max(0) as u64))
        .unwrap_or_else(|_| {
            error_component("ai", "panic inside nativeRunAi".to_string())
        });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunGpu<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    frames: jint,
    readback: jboolean,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        gpu::run(frames.max(0) as u32, readback != 0)
    })
    .unwrap_or_else(|_| {
        error_component("gpu", "panic inside nativeRunGpu".to_string())
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeOverallScore<'local>(
    mut env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    scores_json: JString<'local>,
    confidence: jdouble,
) -> jstring {
    let text = match read_java_string(&mut env, &scores_json) {
        Some(text) => text,
        None => return std::ptr::null_mut(),
    };
    let scores: BTreeMap<String, f64> = serde_json::from_str(&text).unwrap_or_default();
    let overall = scoring::overall(&scores, confidence);
    json_to_jstring(env, &overall)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunCache<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
) -> jstring {
    let result = std::panic::catch_unwind(|| cache::run())
        .unwrap_or_else(|_| {
            error_component("cache", "panic inside nativeRunCache".to_string())
        });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeFairPlay<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
) -> jstring {
    let report = std::panic::catch_unwind(|| fairplay::inspect())
        .unwrap_or_else(|_| {
            error_component("fairplay", "panic inside nativeFairPlay".to_string())
        });
    json_to_jstring(env, &report)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeVulkanCaps<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
) -> jstring {
    let report = std::panic::catch_unwind(|| vulkan::probe())
        .unwrap_or_else(|_| {
            error_component("vulkan", "panic inside nativeVulkanCaps".to_string())
        });
    json_to_jstring(env, &report)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeAnalyzeThermal<'local>(
    mut env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    samples_json: JString<'local>,
    threshold_c: jdouble,
) -> jstring {
    let text = match read_java_string(&mut env, &samples_json) {
        Some(text) => text,
        None => return std::ptr::null_mut(),
    };
    let points: Vec<thermal::ThermalPoint> = serde_json::from_str(&text).unwrap_or_default();
    let report = thermal::analyze(points, threshold_c);
    json_to_jstring(env, &report)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunContextSwitch<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    threads: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        context_switch::run(duration_ms.max(0) as u64, threads.max(0) as usize)
    })
    .unwrap_or_else(|_| {
        error_component(
            "context_switch",
            "panic inside context_switch::run".to_string(),
        )
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunStorageQueueDepth<'local>(
    mut env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    directory: JString<'local>,
    queue_depth: jint,
    size_mb: jint,
) -> jstring {
    let path = read_java_string(&mut env, &directory);
    let result: ComponentResult = match path {
        Some(path_str) => std::panic::catch_unwind(|| {
            storage::run_queue_depth(
                Path::new(&path_str),
                queue_depth.max(0) as usize,
                size_mb.max(0) as u64,
            )
            .unwrap_or_else(|err| error_component("storage", err))
        })
        .unwrap_or_else(|_| {
            error_component(
                "storage",
                "panic inside storage::run_queue_depth".to_string(),
            )
        }),
        None => error_component("storage", "storage directory was null".to_string()),
    };
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunMemoryCascade<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    target_mb: jint,
    step_mb: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        memory::run_cascade(target_mb.max(0) as u64, step_mb.max(0) as u64)
    })
    .unwrap_or_else(|_| {
        error_component(
            "memory_cascade",
            "panic inside memory::run_cascade".to_string(),
        )
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeScanVulkanCapabilities<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
) -> jstring {
    let result = std::panic::catch_unwind(vulkan_scan::scan).unwrap_or_else(|_| {
        vulkan_scan::VulkanCapabilities::unavailable("panic inside vulkan_scan::scan")
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunPqc<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    iterations: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        phase4_pqc::run(duration_ms.max(0) as u64, iterations.max(0) as u32)
    })
    .unwrap_or_else(|_| {
        error_component(
            "pqc_crypto",
            "panic inside phase4_pqc::run".to_string(),
        )
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunRayTracing<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    triangles: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        phase3_raytracing::run(duration_ms.max(0) as u64, triangles.max(0) as u32)
    })
    .unwrap_or_else(|_| {
        error_component(
            "raytracing",
            "panic inside phase3_raytracing::run".to_string(),
        )
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunMeshShader<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    meshlet_density: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        phase3_meshshader::run(duration_ms.max(0) as u64, meshlet_density.max(0) as u32)
    })
    .unwrap_or_else(|_| {
        error_component(
            "meshshader",
            "panic inside phase3_meshshader::run".to_string(),
        )
    });
    json_to_jstring(env, &result)
}

#[no_mangle]
pub extern "system" fn Java_com_benchsuite_app_nativecore_NativeBridge_nativeRunAsyncCompute<'local>(
    env: JNIEnv<'local>,
    _receiver: JObject<'local>,
    duration_ms: jint,
    iterations: jint,
) -> jstring {
    let result = std::panic::catch_unwind(|| {
        phase3_async_compute::run(duration_ms.max(0) as u64, iterations.max(0) as u32)
    })
    .unwrap_or_else(|_| {
        error_component(
            "async_compute",
            "panic inside phase3_async_compute::run".to_string(),
        )
    });
    json_to_jstring(env, &result)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_payload_is_camel_case_json() {
        let component = error_component("cpu", "boom".to_string());
        let text = serde_json::to_string(&component).expect("serialize");
        assert!(text.contains("\"durationMs\""));
        assert!(text.contains("\"confidence\""));
        assert!(text.contains("\"notes\""));
        assert!(!text.contains("duration_ms"));
    }

    #[test]
    fn vulkan_scan_payload_is_camel_case_json() {
        let caps = vulkan_scan::scan();
        let text = serde_json::to_string(&caps).expect("serialize");
        assert!(text.contains("\"apiVersion\""));
        assert!(text.contains("\"deviceName\""));
        assert!(text.contains("\"queueFamilies\""));
        assert!(text.contains("\"readinessScore\""));
        assert!(!text.contains("api_version"));
        assert!(!text.contains("device_name"));
    }
}
