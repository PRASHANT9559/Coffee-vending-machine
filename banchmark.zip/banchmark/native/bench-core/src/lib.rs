//! BenchSuite native core.
//!
//! Timing-critical kernels live here so the Kotlin layer never has to run a
//! measurement loop on the JVM heap. Everything is synchronous and allocation
//! free inside the timed loops; buffers are prepared during warmup.

pub mod engine;
mod jni_bridge;

pub use engine::result::{Capabilities, ComponentResult, MetricResult, OverallScore, Sample};
pub use engine::vulkan_scan::VulkanCapabilities;
