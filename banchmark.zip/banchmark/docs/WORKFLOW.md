# Android Benchmark Suite — Architecture & Production Workflow Specifications

Production-grade Mermaid diagrams and detailed specifications covering the complete lifecycle from application launch and hardware capability scanning to real-time execution, thermal throttling mitigation, AI bottleneck attribution, and cryptographic attestation.

Every diagram is validated for strict syntactic compatibility with GitHub Flavored Markdown and Mermaid Live Editor.

---

### Specification Metadata

| Dimension | Specification |
| --- | --- |
| **Platform Target** | Android 10+ (API 29) to Android 16 (API 36) |
| **Core Architecture** | Clean Architecture + Unidirectional Data Flow (UDF) + Multi-Module Gradle |
| **Native Engine** | Rust NDK (JNI via UniFFI), Vulkan 1.3 (`ash`), LiteRT with Vendor NPU Delegates |
| **Telemetry & Timing** | Monotonic Clocks (`CLOCK_MONOTONIC`), 10 Hz StateFlow Telemetry, ADPF Performance Hints |
| **Storage & Security** | Room SQLite (WAL Mode), Android Keystore (ECDSA P-256 Hardware Key Attestation) |
| **Diagram Count** | 15 Production-Grade Diagrams (Flowcharts, State Machines, Sequence, Component, Data Flow) |

---

### Comprehensive Notation & Legend

| Shape / Syntax | Visual Representation | Semantic Meaning |
| --- | --- | --- |
| Rounded `([ ... ])` | `([ Start / Finish ])` | Application entry point, user trigger, or terminal completion state |
| Rectangle `[ ... ]` | `[ Process / Module ]` | Deterministic execution unit, functional module, or Compose screen |
| Diamond `{ ... }` | `{ Decision Gate }` | Conditional branch, validation check, or safety evaluation |
| Cylinder `[( ... )]` | `[( Data Store )]` | Persistent storage (Room SQLite WAL, Android Keystore, Cloud Cache) |
| Solid Arrow `-->` | `A --> B` | Synchronous, blocking, or deterministic sequential control transition |
| Dashed Arrow `-.->` | `A -.-> B` | Asynchronous event stream, reactive Kotlin StateFlow, or optional network sync |

---

### Table of Contents

1. [Overall Application Workflow](#1-overall-application-workflow)
2. [Complete Screen Navigation Graph (35 Screens)](#2-complete-screen-navigation-graph-35-screens)
3. [Benchmark Engine Pipeline & Test Contract](#3-benchmark-engine-pipeline--test-contract)
4. [WorkManager Benchmark Scheduler & Priority Queue](#4-workmanager-benchmark-scheduler--priority-queue)
5. [Smart Recommendation & Bottleneck Attribution Workflow](#5-smart-recommendation--bottleneck-attribution-workflow)
6. [Device Health Scoring & Degradation Analysis Workflow](#6-device-health-scoring--degradation-analysis-workflow)
7. [Thermal Stress Test & Sustained Stability Workflow](#7-thermal-stress-test--sustained-stability-workflow)
8. [AI Analysis & On-Device ML Inference Engine](#8-ai-analysis--on-device-ml-inference-engine)
9. [Multiformat Report Generation & Cryptographic Attestation](#9-multiformat-report-generation--cryptographic-attestation)
10. [High-Level Clean Architecture & Layered Boundaries](#10-high-level-clean-architecture--layered-boundaries)
11. [Comprehensive Feature Dependency Graph](#11-comprehensive-feature-dependency-graph)
12. [Benchmark Run State Machine & Thermal Fault Handling](#12-benchmark-run-state-machine--thermal-fault-handling)
13. [End-to-End Benchmark Execution Sequence](#13-end-to-end-benchmark-execution-sequence)
14. [Unidirectional Data Flow (UDF) & Telemetry Pipeline](#14-unidirectional-data-flow-udf--telemetry-pipeline)
15. [Modular Component Architecture & Native NDK Boundaries](#15-modular-component-architecture--native-ndk-boundaries)

---

<a id="1-overall-application-workflow"></a>
## 1. Overall Application Workflow

The overall application workflow orchestrates the four primary lifecycle phases of the Android Benchmark Suite: **Boot Phase**, **Core Benchmark Journey**, **Intelligence & Analytics Layer**, and **Persistence & Export Layer**. The architecture enforces strict pre-flight hardware capability detection before entering the core journey, guarantees that measurement workloads remain isolated from UI overhead, and feeds verified telemetry into on-device AI for actionable interpretation.

```mermaid
---
title: "1. Overall Application Workflow"
---
flowchart TD
    %% ---------- Boot phase ----------
    subgraph BOOT["Boot Phase & Hardware Detection"]
        direction TB
        S1(["Screen 1: Splash"]) --> S2["Screen 2: Onboarding Flow"]
        S2 --> S3{"Permissions Granted?"}
        S3 -- "No" --> S4["Screen 3: Permission Rationale"]
        S4 --> S3
        S3 -- "Yes" --> S5["Screen 4: Hardware Detection & Capability Scan"]
    end

    %% ---------- Core journey ----------
    subgraph JOURNEY["Core Benchmark Journey"]
        direction TB
        D1["Screen 5: Dashboard"] --> D2["Screen 6: Benchmarks Hub"]
        D2 --> D3["Screen 7: Pre-Test Checklist"]
        D3 --> D4["Screen 8: Live Run Execution"]
        D4 --> D5["Real-time Telemetry & Monitoring (10 Hz)"]
        D5 --> D6["Result Validation & Metric Normalization"]
        D6 --> D7["Screen 9: Result Summary"]
        D7 --> D8["Screen 10: Result Detail"]
    end

    %% ---------- Intelligence ----------
    subgraph INTEL["Intelligence & Analytics Layer"]
        direction TB
        I1["Screen 19: AI Insights (Bottleneck Analysis)"] --> I2["Screen 20: Smart Recommendations"]
        I2 --> I3["Screen 22: Comparison Engine"]
    end

    %% ---------- Output ----------
    subgraph OUT["Persistence & Export Layer"]
        direction TB
        O1["Screen 23-24: Report Preview & Multiformat Export"] --> O2["Screen 21: Local History (Room WAL)"]
        O2 --> O3["Screen 25: Optional Cloud Leaderboard (Signed)"]
    end

    %% ---------- Error & edge paths ----------
    subgraph FAILS["Exception & Recovery Paths"]
        direction TB
        E1["Thermal / Battery Safety Abort"]
        E2["Screen 34: Run Failed & Retry Diagnostics"]
    end

    S5 --> D1
    D8 --> I1
    I3 --> O1
    O2 -. "Re-run or compare baseline" .-> D1
    D4 -. "Safety cutoff" .-> E1
    E1 --> E2
    E2 -. "Retry run" .-> D3
```

### Workflow Execution Stages
1. **Boot & Capability Profiling:** Inspects SoC architecture (CPU cluster topology, Vulkan 1.3 support, NPU vendor delegates) and requests runtime permissions (`POST_NOTIFICATIONS`, `BATTERY_STATS`).
2. **Deterministic Pre-Flight Checklist:** Assesses battery status ($\ge 20\%$ or charging), thermal headroom, and background load ($< 15\%$) to eliminate measurement contamination.
3. **Execution & Real-Time Isolation:** Throttles UI rendering to 10 Hz while high-priority native worker threads execute the test contract using monotonic clocks.
4. **Insight Synthesis & Signing:** Sanitizes raw telemetry, extracts variance metrics, signs the bundle with hardware Key Attestation, and forwards results to the on-device AI engine.

---

<a id="2-navigation-flow"></a>
<a id="2-complete-screen-navigation-graph-35-screens"></a>
## 2. Complete Screen Navigation Graph (35 Screens)

The navigation architecture implements a strict single-activity structure utilizing Navigation Compose with typed routes. It maps all **35 dedicated screens** across 8 functional subgraphs, maintaining independent back-stacks for each bottom-navigation destination and providing clear recovery flows for run failures, user cancellations, and background task resumption.

```mermaid
---
title: "2. Complete Screen Navigation Graph (35 Screens)"
---
flowchart TD
    %% ---------- Entry flow ----------
    subgraph ENTRY["Entry & Setup Flow"]
        direction TB
        S01(["01. Splash"]) --> S02["02. Onboarding"]
        S02 --> S03["03. Permission Rationale"]
        S03 --> S04["04. Hardware Detection"]
    end

    %% ---------- Bottom navigation tabs ----------
    subgraph TABS["Primary Destinations (Bottom Navigation)"]
        direction LR
        S05["05. Dashboard"]
        S06["06. Benchmarks Hub"]
        S21["21. History"]
        S23["23. Reports"]
        S29["29. Profile"]
    end

    %% ---------- Benchmark categories ----------
    subgraph CATS["Benchmark Suite Categories"]
        direction TB
        S11["11. CPU Benchmark"]
        S12["12. GPU Benchmark"]
        S13["13. Memory"]
        S14["14. Storage"]
        S15["15. AI Benchmark"]
        S16["16. Gaming"]
        S17["17. Stress Test"]
        S18["18. Device Health"]
    end

    %% ---------- Execution journey ----------
    subgraph EXEC["Core Run Flow"]
        direction TB
        S07["07. Pre-Test Checklist"]
        S08["08. Live Run Screen"]
        S09["09. Result Summary"]
        S10["10. Result Detail"]
    end

    %% ---------- Insights & actions ----------
    subgraph INSIGHT["Intelligence & Sharing"]
        direction TB
        S19["19. AI Insights"]
        S20["20. Recommendations"]
        S35["35. Share Card"]
    end

    %% ---------- Data & comparison ----------
    subgraph DATA_DEST["Data & Library"]
        direction TB
        S22["22. Comparison"]
        S24["24. Report Preview and Export"]
        S25["25. Leaderboard"]
        S26["26. Device Info"]
    end

    %% ---------- Tools & scheduler ----------
    subgraph TOOLS["Advanced Tools"]
        direction TB
        S27["27. Custom Builder"]
        S28["28. Scheduler Queue"]
    end

    %% ---------- Settings & account ----------
    subgraph SETTINGS["Account & System"]
        direction TB
        S30["30. Settings"]
        S31["31. Privacy and Data"]
        S32["32. About"]
        S33["33. Help and Support"]
    end

    %% ---------- Edge states ----------
    subgraph EDGE["Edge & Recovery States"]
        direction TB
        S34["34. Run Failed and Retry"]
        DIALOG_CANCEL{"Cancel Run Dialog"}
        BANNER["Persistent Run Banner"]
    end

    %% Connections
    S04 --> S05
    S05 --> S06
    S06 --> S11 & S12 & S13 & S14 & S15 & S16 & S17
    S06 --> S18
    S11 & S12 & S13 & S14 & S15 & S16 & S17 --> S07
    S07 --> S08
    S08 --> S09
    S08 -. "Execution error / abort" .-> S34
    S34 -. "Retry with adjusted profile" .-> S07
    S08 -. "Background / navigate away" .-> BANNER
    BANNER -. "Tap to resume HUD" .-> S08
    S08 -. "Back key pressed" .-> DIALOG_CANCEL
    DIALOG_CANCEL -- "Confirm abort" --> S06
    DIALOG_CANCEL -- "Dismiss" --> S08
    S09 --> S10
    S09 --> S35
    S10 --> S19
    S19 --> S20
    S18 --> S20

    %% Navigation destinations
    S05 --> S25
    S05 --> S26
    S21 --> S10
    S21 --> S22
    S23 --> S24
    S06 --> S27
    S27 --> S28
    S29 --> S30
    S30 --> S31
    S30 --> S32
    S30 --> S33
```

### Screen Hierarchy & Deep Linking
- **Bottom Tabs:** Independent navigation stacks for Dashboard (5), Hub (6), History (21), Reports (23), and Profile (29).
- **Persistent Run Banner:** If the user backgrounds the application or navigates to settings during an active run, a persistent banner maintains a direct gateway back to Live Run (8).
- **Protected Run Boundary:** Pressing system back during Live Run triggers the `Cancel Run Dialog` to prevent accidental loss of benchmark state.

---

<a id="3-benchmark-engine-workflow"></a>
<a id="3-benchmark-engine-pipeline--test-contract"></a>
## 3. Benchmark Engine Pipeline & Test Contract

Every benchmark suite implements a strict six-stage lifecycle contract: **Describe**, **Prepare**, **Validate**, **Warmup**, **Run**, and **Score / Verify**. Unsupported hardware features are bypassed cleanly without failure, and runs that exhibit excessive variance ($\text{CoV} > 5\%$) or thermal saturation trigger controlled cool-down intervals.

```mermaid
---
title: "3. Benchmark Engine Workflow & Test Contract"
---
flowchart TD
    START(["Benchmark Invocation Request"]) --> PREP["1. Prepare: Allocate Buffers & Load Assets"]

    subgraph VALID["2. Environment & Capability Validation"]
        direction TB
        V_CAP{"Hardware Capability Supported?"}
        V1{"Battery >= 20% or Charging?"}
        V2{"Thermal Headroom OK (Temp < 40°C)?"}
        V3{"Background CPU Load < 15%?"}
        
        V_CAP -- "Yes" --> V1
        V1 -- "Yes" --> V2
        V2 -- "Yes" --> V3
    end

    PREP --> V_CAP
    V_CAP -- "No" --> SKIP(["Gracefully Skip: Log Unsupported Feature"])
    
    V1 -- "No" --> W1["Warning: Low Battery May Skew Clocks"]
    V2 -- "No" --> W2["Warning: Thermal Saturation Detected"]
    V3 -- "No" --> W3["Warning: Heavy Background Tasks Active"]
    
    W1 --> DECIDE{"User Override or Abort?"}
    W2 --> DECIDE
    W3 --> DECIDE
    
    DECIDE -- "User Abort" --> ABORT(["Benchmark Aborted"])
    DECIDE -- "Forced Run" --> WARM["3. Warmup: Stabilize Frequencies & Prime Caches"]
    V3 -- "Yes" --> WARM

    subgraph EXEC["4. Native Workload & Telemetry Loop"]
        direction TB
        RUNT["Native Rust / Vulkan / LiteRT Kernels"]
        MON["Hardware Monitor (10 Hz Telemetry Flow)"]
        CLOCKS["Monotonic Clocks & ADPF Performance Hints"]
        RUNT -. "Real-time Telemetry" .-> MON
        CLOCKS -. "Thread Priority" .-> RUNT
    end

    WARM --> RUNT

    subgraph VERIFY["5. Scoring, Statistics & Integrity"]
        direction TB
        SCORE["Compute Raw Throughput / Latency / FPS"]
        TRIM["Trimmed Median & Variance Analysis"]
        COV{"CoV < 5% & No Cheat Signature?"}
        SIGN["Sign Bundle with Keystore (ECDSA P-256)"]
        
        SCORE --> TRIM --> COV
        COV -- "Pass" --> SIGN
    end

    RUNT --> SCORE
    
    COV -- "Fail (High Variance / Anomalies)" --> RETRY{"Retry Budget Remaining (Max 2)?"}
    RETRY -- "Yes" --> COOL1["Enforce Cool-down Wait (60s)"] --> WARM
    RETRY -- "No" --> FAILED(["Flagged: Inconclusive / High Variance"])

    subgraph CLEAN["6. Cleanup & Cooldown"]
        direction TB
        RELEASE["Free Native Buffers & Destroy GPU Queues"]
        SOAK["Thermal Soak & Cool-down Interval"]
        RELEASE --> SOAK
    end

    SIGN --> RELEASE
    SOAK --> STORE[("Local Room DB (WAL Mode)")]
    STORE --> AIA["AI Bottleneck & Insight Analysis"]
    AIA --> DONE(["Result Finalized & Ready"])
```

### Test Contract Execution Rules
- **Warmup Phase:** Excites CPU and GPU governors to reach steady-state frequencies, discarding initial cold-cache outliers.
- **Statistical Quality Gate:** Calculates median and interquartile range (IQR). If the Coefficient of Variation ($\text{CoV} = \frac{\sigma}{\mu}$) exceeds $0.05$, the run is flagged or automatically retried after thermal dissipation.
- **Cool-Down Enforcement:** Guarantees a mandatory soak delay between heavy sustained workloads to prevent thermal carry-over skewing subsequent sub-benchmarks.

---

<a id="4-benchmark-scheduler"></a>
<a id="4-workmanager-benchmark-scheduler--priority-queue"></a>
## 4. WorkManager Benchmark Scheduler & Priority Queue

The scheduler provides a reliable background and foreground execution coordinator using Android Jetpack `WorkManager`. It manages admission control via hardware constraints (`BatteryNotLow`, `DeviceIdle`, `StorageNotLow`), enforces a strict 4-tier priority queue, and ensures mutual exclusion so that background diagnostics never execute concurrently with user-initiated benchmarks.

```mermaid
---
title: "4. WorkManager Benchmark Scheduler & Priority Queue"
---
flowchart TD
    subgraph SOURCES["Benchmark Job Sources"]
        direction TB
        M1["Manual Suite (Foreground Tap)"]
        M2["Quick Run / Full Suite Run"]
        M3["Custom Suite Builder Request"]
        M4["WorkManager Scheduled Periodic Health Run"]
        M5["Fleet / Enterprise Automated Trigger"]
    end

    subgraph ADMISSION["Admission Controller & System Constraints"]
        direction TB
        C1{"Device Constraints Check"}
        C_BAT["BatteryNotLow Constraint"]
        C_IDLE["DeviceIdle Constraint"]
        C_THERM["Thermal Headroom Check"]
        C1 --- C_BAT & C_IDLE & C_THERM
    end

    SOURCES --> ADMISSION

    subgraph QUEUE["Deterministic Priority Queue"]
        direction TB
        P0["P0: User Foreground Interactive (Immediate)"]
        P1["P1: Standard Quick & Full Suites"]
        P2["P2: Scheduled & Custom Runs"]
        P3["P3: Opportunistic Background Diagnostic"]
        PQ[("In-Memory Priority Queue & Room Job Table")]
        P0 & P1 & P2 & P3 -.-> PQ
    end

    ADMISSION -- "Admitted" --> PQ
    ADMISSION -- "Constraint Violated" --> DEFER["Defer Execution to WorkManager Constraints"]

    subgraph DISPATCH["Concurrency-Safe Dispatcher"]
        direction TB
        LOCK{"Execution Mutex Free?"}
        DIS["Single-Threaded Task Dispatcher"]
        LOCK -- "Lock Acquired" --> DIS
    end

    PQ --> LOCK
    LOCK -- "Busy" --> WAIT["Queue In-Memory Pending Job"]

    subgraph EXEC["Engine Execution Pipeline"]
        direction TB
        ENG["Benchmark Engine Pipeline"]
        STATUS{"Execution Outcome"}
        ENG --> STATUS
    end

    DIS --> ENG

    STATUS -- "Success" --> NOTIFY["Notify UI / WorkManager Success & Pop Next"]
    STATUS -- "Transient Error / Thermal Cutoff" --> RETRY_CHECK{"Retry Attempts Left?"}
    
    RETRY_CHECK -- "Yes" --> EXP_BACK["Exponential Backoff & Reschedule"] --> PQ
    RETRY_CHECK -- "No" --> DEAD["Mark Job Failed & Emit Notification"]
    
    NOTIFY --> PQ

    %% Cancellation and Interrupt Handlers
    USER_CANCEL(["User Abort Request"]) --> CANCEL_ROUTER["Cancellation Router"]
    CANCEL_ROUTER -. "Cancel Running Workload" .-> ENG
    CANCEL_ROUTER -. "Evict from Queue" .-> PQ
    
    SYS_INTERRUPT(["System Interrupt: Call / Thermal / Battery Critical"]) -. "Pause / Defer Job" .-> DIS
```

### Priority Tiers & Dispatch Rules
| Priority | Category | Preemption Policy | Typical Workload |
| --- | --- | --- | --- |
| **P0** | Foreground User Interactive | Immediate execution; preempts background jobs | Manual tap on CPU, GPU, or Full Suite |
| **P1** | Quick / Full Automated Suites | High priority; queued behind active P0 | Pre-scheduled full verification |
| **P2** | Scheduled / Custom Suites | Medium priority; yields to P0/P1 | User-composed multi-category batches |
| **P3** | Opportunistic Background | Lowest priority; requires `DeviceIdle` | Nightly battery and storage health scans |

---

<a id="5-smart-recommendation-workflow"></a>
<a id="5-smart-recommendation--bottleneck-attribution-workflow"></a>
## 5. Smart Recommendation & Bottleneck Attribution Workflow

The Smart Recommendation engine converts multi-dimensional benchmark telemetry into concrete, plain-language insights and actionable device optimizations across six core operational domains: **Gaming**, **Content Creation**, **Offline AI**, **Battery Efficiency**, **Thermal Management**, and **Device Lifecycle**.

```mermaid
---
title: "5. Smart Recommendation & Bottleneck Attribution Workflow"
---
flowchart TD
    subgraph INPUTS["Multi-Modal Telemetry & Context Inputs"]
        direction LR
        IN1["Normalized Scores (Peak vs Sustained)"]
        IN2["Hardware Capability Map (SoC, NPU TOPS, RAM, Storage)"]
        IN3["Runtime Telemetry (Decay Curves, Temp Delta, Power mW)"]
        IN4["Peer Percentile Distribution (Local Baseline / Cloud)"]
    end

    subgraph CORRELATION["AI Attribution & Bottleneck Detection"]
        direction TB
        ENG_AI["AI Analysis Engine (LiteRT / Rules)"]
        BOT_CPU["CPU Bound / IPC Bottleneck"]
        BOT_GPU["GPU Fillrate / Shader Compute Bound"]
        BOT_THERM["Thermal Headroom / Governor Throttling"]
        BOT_MEM["Memory Bandwidth / Page Eviction"]
        ENG_AI --> BOT_CPU & BOT_GPU & BOT_THERM & BOT_MEM
    end

    INPUTS --> ENG_AI

    subgraph DOMAINS["Targeted Recommendation Modules"]
        direction TB
        R1["1. Gaming Recommendation: Target FPS & Graphics Presets"]
        R2["2. Video Creation: Codec Acceleration & Export Estimates"]
        R3["3. Offline AI: LLM Token Rate & Delegate Compatibility"]
        R4["4. Battery & Power: Energy per Test & App Drain Audit"]
        R5["5. Thermal Management: Cooler Needs & Throttling Limits"]
        R6["6. Device Lifecycle: Hardware Longevity & Upgrade Advice"]
    end

    BOT_CPU & BOT_GPU & BOT_THERM & BOT_MEM --> R1 & R2 & R3 & R4 & R5 & R6

    subgraph SYNTHESIS["Ranking, Deduplication & Delivery"]
        direction TB
        DEDUP["Deduplicate Rules & Filter Low Confidence"]
        RANK["Rank Actions by Estimated Performance Impact"]
        ACTIONS["Attach System Intents (Settings / Power Mode / Cleaner)"]
        DEDUP --> RANK --> ACTIONS
    end

    R1 & R2 & R3 & R4 & R5 & R6 --> DEDUP
    ACTIONS --> OUT(["Screen 20: Recommendations UI"])
```

### Recommendation Domain Logic
1. **Gaming:** Maps sustained FPS and 99th percentile frame times to recommended presets (e.g. 60 FPS Stable at Medium settings).
2. **Content Creation:** Evaluates hardware media encoders (HEVC, AV1, ProRes) and estimates 4K video export durations.
3. **Offline AI:** Predicts token generation speeds for 1B-3B parameter LLMs based on INT8/FP16 NPU delegate throughput.
4. **Thermal & Battery:** Quantifies milliwatts per score point and recommends specific system power modes or cooling accessories.

---

<a id="6-device-health-workflow"></a>
<a id="6-device-health-scoring--degradation-analysis-workflow"></a>
## 6. Device Health Scoring & Degradation Analysis Workflow

The Device Health engine continuously ingests telemetry across six primary hardware subsystems, normalizes the signals against factory calibration baselines, and computes a composite **Health Score (0 to 100)** mapped to four standardized score bands in strict alignment with README Section 6.5.

```mermaid
---
title: "6. Device Health Scoring & Degradation Analysis Workflow"
---
flowchart TD
    subgraph TELEMETRY["Continuous Health Telemetry Signals"]
        direction TB
        H1["Battery: Cycles, Estimated Capacity, Internal Impedance"]
        H2["Storage: UFS Health Wear %, Random IOPS, Trim State"]
        H3["Memory: Available RAM, zRAM Ratio, Pressure Events"]
        H4["CPU: Core Frequency Scaling & Voltage Stability"]
        H5["GPU: Driver Fault Frequency & Pipeline Latency"]
        H6["Thermals: Ambient-to-Core Delta & Dissipation Rate"]
    end

    subgraph NORMALIZATION["Normalization & Scoring Matrix"]
        direction TB
        WEIGHTS["Weighted Heuristics & Sensor Calibration"]
        AGG["Geometric Aggregator & Anomaly Filter"]
        SCORE["Composite Health Score: 0 to 100"]
        WEIGHTS --> AGG --> SCORE
    end

    TELEMETRY --> WEIGHTS

    subgraph BANDS["Score Band Evaluation (README Section 6.5)"]
        direction TB
        EVAL{"Score Band Evaluation"}
        BAND_EXC["Excellent (90-100): Optimal Condition"]
        BAND_GOOD["Good (75-89): Normal Operating Aging"]
        BAND_FAIR["Fair (50-74): Degradation or Thermal Wear"]
        BAND_POOR["Poor (< 50): Critical Fault or Severe Wear"]
        
        SCORE --> EVAL
        EVAL -- "90-100" --> BAND_EXC
        EVAL -- "75-89" --> BAND_GOOD
        EVAL -- "50-74" --> BAND_FAIR
        EVAL -- "< 50" --> BAND_POOR
    end

    subgraph ACTIONS["Actionable Prescription & Maintenance"]
        direction TB
        T1["Maintenance Tips & Battery Preservation Practices"]
        T2["Routine Optimization & Background App Management"]
        T3["Storage Trim, Cache Purge & Thermal Cleaning Advice"]
        T4["Battery Replacement, Repair or Device Upgrade Advisory"]
        
        BAND_EXC --> T1
        BAND_GOOD --> T2
        BAND_FAIR --> T3
        BAND_POOR --> T4
    end

    T1 & T2 & T3 & T4 --> REC_OUT(["Prescriptive Recommendations"])
    SCORE --> HISTORY[("Room HealthTrend Table (Historical Tracking)")]
```

### Health Score Bands & Actions
| Score Range | Band | Color Token | System Diagnostic Verdict |
| --- | --- | --- | --- |
| **90 – 100** | **Excellent** | `success` (`#34D399`) | Subsystems operating at peak factory efficiency; preventive care tips. |
| **75 – 89** | **Good** | `primary` (`#22D3EE`) | Normal degradation; background app hygiene and storage trim recommended. |
| **50 – 74** | **Fair** | `warning` (`#FBBF24`) | Measurable thermal/battery wear; aggressive caching and throttling mitigation. |
| **< 50** | **Poor** | `danger` (`#F87171`) | Severe degradation; battery replacement or hardware service advisory. |

---

<a id="7-stress-test-workflow"></a>
<a id="7-thermal-stress-test--sustained-stability-workflow"></a>
## 7. Thermal Stress Test & Sustained Stability Workflow

The stress test subjects the SoC and thermal dissipation assembly to sustained compute and graphics saturation (15, 20, or 30 minutes) to extract the **Performance Decay Curve**, identify governor step-down thresholds, and calculate the **Stability Score %** while actively enforcing emergency thermal cutoffs.

```mermaid
---
title: "7. Thermal Stress Test & Sustained Stability Workflow"
---
flowchart TD
    INIT(["User Triggers Stress Test (15 / 20 / 30 min)"]) --> SAFE{"Pre-Test Safety Checks"}

    subgraph PRECOND["Safety Pre-conditions"]
        direction TB
        P_BAT{"Battery Level >= 50% or Charging?"}
        P_TEMP{"Chassis Temperature <= 38°C?"}
        P_BG{"Background CPU Workload Idle?"}
        P_BAT --- P_TEMP --- P_BG
    end

    SAFE -- "Evaluate" --> PRECOND
    PRECOND -- "Conditions Violated" --> BLOCK(["Blocked: Unsafe Starting Conditions"])
    PRECOND -- "Conditions Met" --> WARM["Warmup: Prime Workloads & Allocate Framebuffers"]

    subgraph LOOP["High-Frequency Monitoring Loop (10 Hz Telemetry)"]
        direction TB
        L1["Sustained Load: Vulkan Compute & CPU Saturation"]
        L2["Real-time FPS & Frame-time Jitter Measurement"]
        L3["SoC Junction & Battery Thermal Sampling"]
        L4["Battery Drain Current (mA) & Power Draw (mW)"]
        L5["Governor Throttling Detection (Frequency Steps)"]
        
        L1 --> L2 --> L3 --> L4 --> L5
    end

    WARM --> L1

    subgraph GATES["Real-time Safety & Exit Evaluation"]
        direction TB
        EXIT_CHK{"Loop Exit Condition Met?"}
        T_RUNAWAY{"Thermal Runaway: Battery > 48°C or SoC > 85°C?"}
        B_CRIT{"Battery Depleted (< 15%)?"}
        TIME_EXP{"Configured Test Duration Reached?"}
        
        L5 --> EXIT_CHK
        EXIT_CHK --> T_RUNAWAY
        EXIT_CHK --> B_CRIT
        EXIT_CHK --> TIME_EXP
    end

    T_RUNAWAY -- "Critical Heat" --> EMERG["Emergency Stop & Thermal Soak Delay"]
    B_CRIT -- "Low Battery" --> SAFE_STOP["Premature Stop: Preserve Device State"]
    TIME_EXP -- "No (Test Ongoing)" --> L1
    TIME_EXP -- "Yes (Target Complete)" --> FINAL_CALC["Calculate Stability Metrics"]

    EMERG --> FINAL_CALC
    SAFE_STOP --> FINAL_CALC

    subgraph METRICS["Final Stability Analytics"]
        direction TB
        STAB["Stability Score % = (Sustained Score / Peak Score) * 100"]
        DECAY["Fit Thermal Performance Decay Curve"]
        THROTTLE_LOG["Construct Frequency Throttling Timeline"]
        DISSIPATE["Measure Heat Dissipation Rate (Cool-down)"]
        
        FINAL_CALC --> STAB --> DECAY --> THROTTLE_LOG --> DISSIPATE
    end

    DISSIPATE --> OUT(["Screen 17: Stress Test & Stability Report"])
```

### Safety Intercepts & Mathematical Formulations
- **Stability Ratio:** $\text{Stability Score} = \left(\frac{\text{Score}_{\text{sustained}}}{\text{Score}_{\text{peak}}}\right) \times 100\%$
- **Emergency Abort Thresholds:** If battery temperature exceeds $48^\circ\text{C}$ or estimated SoC junction temperature exceeds $85^\circ\text{C}$, the engine executes an immediate emergency stop to protect battery chemistry and display layers.
- **Cool-Down Tracking:** Monitors the rate of heat dissipation ($^\circ\text{C} / \text{min}$) after workload termination until ambient equilibrium is restored.

---

<a id="8-ai-analysis-engine-workflow"></a>
<a id="8-ai-analysis--on-device-ml-inference-engine"></a>
## 8. AI Analysis & On-Device ML Inference Engine

The AI Analysis Engine executes entirely on-device using Google **LiteRT** (formerly TensorFlow Lite) with vendor-specific NPU delegate acceleration. It cleans raw sample series, normalizes results against a standardized reference baseline ($1000$), correlates telemetry against known SoC profiles, and generates structured explanations of architectural bottlenecks.

```mermaid
---
title: "8. AI Analysis & On-Device ML Inference Engine"
---
flowchart TD
    RAW(["Raw Benchmark Telemetry Bundle"]) --> CLEAN["Data Cleaning & Outlier Rejection (IQR)"]
    CLEAN --> NORM["Normalization Against Reference Device (Base=1000)"]
    NORM --> CORR["Hardware Topology Correlation (SoC / Memory / NPU)"]

    subgraph ML_ENGINE["LiteRT On-Device Inference Runtime"]
        direction TB
        DELEGATE{"Delegate Selection & Capability Check"}
        NPU_EXEC["NPU Acceleration (QNN / MediaTek / Tensor)"]
        GPU_EXEC["GPU Fallback (Vulkan / OpenCL Compute)"]
        CPU_EXEC["CPU Fallback (LiteRT XNNPACK)"]
        PRED_MODEL["Inference: Bottleneck & Performance Estimation"]
        
        DELEGATE -- "NPU Available" --> NPU_EXEC
        DELEGATE -- "NPU Fallback" --> GPU_EXEC
        DELEGATE -- "GPU Unavailable" --> CPU_EXEC
        NPU_EXEC & GPU_EXEC & CPU_EXEC --> PRED_MODEL
    end

    CORR --> DELEGATE

    subgraph STORES["Contextual Data Repositories"]
        direction TB
        HW_LIB[("Hardware Topology Profile Library")]
        HIST_DB[("Personal Run History (Room WAL)")]
        PEER_DATA[("Anonymized Peer Percentiles Dataset")]
    end

    HW_LIB -.-> CORR
    HIST_DB -.-> PRED_MODEL
    PEER_DATA -.-> PRED_MODEL

    subgraph SYNTHESIS["Insight Synthesis & Explanations"]
        direction TB
        BOTTLENECK["Subsystem Bottleneck Identification"]
        FPS_EST["Real-World Gaming FPS Prediction"]
        AI_EST["LLM & Vision Generation Rate Estimation"]
        NARRATIVE["Natural Language Insight Generation"]
        
        PRED_MODEL --> BOTTLENECK --> FPS_EST --> AI_EST --> NARRATIVE
    end

    NARRATIVE --> ACTION["Rule-Based Actionable Prescriptions"]
    ACTION --> OUT(["Screen 19: AI Insights & Screen 20: Recommendations"])
```

### Inference Pipeline & Delegate Hierarchy
1. **NPU Direct Delegation:** Attempts binding to Qualcomm QNN, MediaTek NeuroPilot, or Google Tensor TPU delegates.
2. **GPU / Compute Fallback:** If NPU compilation fails or operators are unsupported, shifts to Vulkan Compute / OpenCL.
3. **CPU XNNPACK Fallback:** Guarantees deterministic inference execution on multi-core ARM NEON even if vendor drivers are absent.

---

<a id="9-report-generation-workflow"></a>
<a id="9-multiformat-report-generation--cryptographic-attestation"></a>
## 9. Multiformat Report Generation & Cryptographic Attestation

To establish verifiable trust for reviewers and enterprise fleets, results are compiled into multiple export formats (vector PDF, raw streaming CSV, schema-validated JSON, and AMOLED share cards) and digitally signed using hardware-backed private keys stored in the **Android Keystore**.

```mermaid
---
title: "9. Multiformat Report Generation & Cryptographic Attestation"
---
flowchart TD
    INPUT(["Final Score Bundle & Telemetry Data"]) --> COMPILE["Aggregate Subsystem Scores & Confidence Levels"]

    subgraph ASSEMBLE["Report Composition Engine"]
        direction TB
        CHARTS["Render Custom Compose Canvas Visualizations"]
        DECAY_CHART["Plot Thermal Decay Curves & Histograms"]
        HEALTH_MOD["Embed Device Health & Gaming Profiles"]
        INSIGHT_MOD["Embed AI Verdicts & Plain-Language Explanations"]
        MODEL_BUILD["Assemble Unified Report Document Model"]
        
        CHARTS --> DECAY_CHART --> HEALTH_MOD --> INSIGHT_MOD --> MODEL_BUILD
    end

    COMPILE --> CHARTS

    subgraph ATTESTATION["Cryptographic Integrity Layer"]
        direction TB
        HASH["Compute SHA-256 Digest of Benchmark Payload"]
        KEYSTORE["Android Keystore Hardware-Backed Private Key"]
        SIGN["Generate ECDSA P-256 Digital Signature"]
        ATTEST["Embed Hardware Key Attestation Certificate"]
        
        HASH --> KEYSTORE --> SIGN --> ATTEST
    end

    MODEL_BUILD --> HASH

    subgraph EXPORT["Multiformat Exporters"]
        direction TB
        PDF["Vector PDF Exporter (android.graphics.pdf.PdfDocument)"]
        CSV_JSON["Streaming Exporter (Raw 10 Hz CSV & Schema-Validated JSON)"]
        SHARE_CARD["AMOLED Share Card Image (Custom Canvas Bitmap + QR Code)"]
    end

    ATTEST --> PDF & CSV_JSON & SHARE_CARD

    subgraph DISTRIBUTION["Sharing & Archival Dispatcher"]
        direction TB
        SYS_SHARE["Android System Sharesheet (Intent.ACTION_SEND)"]
        LOCAL_FILE["Scoped Storage / MediaStore (Local Downloads)"]
        CLOUD_SYNC["Optional Opt-in Ingestion API (Axum Backend)"]
    end

    PDF --> SYS_SHARE & LOCAL_FILE
    CSV_JSON --> LOCAL_FILE
    SHARE_CARD --> SYS_SHARE
    ATTEST -. "Verified Submission" .-> CLOUD_SYNC
    CLOUD_SYNC --> WEB_LINK(["Public Verifiable Report URL"])
```

### Integrity & Attestation Specifications
- **Digital Signature:** ECDSA over NIST curve P-256 using SHA-256 digests. Keys are generated inside the device Trusted Execution Environment (TEE) or StrongBox Keymaster.
- **Hardware Attestation:** Binds the benchmark result to verified boot state, application package UID, and device serial hash.
- **Distribution:** Exports via standard Android `ACTION_SEND` Sharesheet, saves to `MediaStore.Downloads`, or uploads to the optional Axum backend.

---

<a id="10-system-architecture"></a>
<a id="10-high-level-clean-architecture--layered-boundaries"></a>
## 10. High-Level Clean Architecture & Layered Boundaries

The architecture enforces strict **Clean Architecture** boundaries with Unidirectional Data Flow (UDF). Higher layers depend strictly on domain interfaces, native NDK routines are encapsulated behind UniFFI bridges, and telemetry flows upward via non-blocking Kotlin Coroutine StateFlows.

```mermaid
---
title: "10. High-Level Clean Architecture & Layered Boundaries"
---
flowchart TB
    subgraph PRESENTATION["Presentation Layer (Jetpack Compose & Material 3)"]
        direction LR
        UI_SCREENS["35 Compose Screens"]
        UI_VM["MVI State ViewModels"]
        UI_THEME["AMOLED & Light Design System Tokens"]
        UI_NAV["Navigation Compose (Typed Routes)"]
    end

    subgraph APPLICATION["Application Layer (Orchestration & Use Cases)"]
        direction LR
        APP_CTRL["Benchmark Controller"]
        APP_SCHED["Scheduler Service (WorkManager)"]
        APP_STATE["Run State Machine Holder"]
    end

    subgraph DOMAIN["Domain Layer (Pure Business Logic)"]
        direction LR
        DOM_SCORE["Scoring & Normalization Rules"]
        DOM_HEALTH["Device Health Evaluator"]
        DOM_REC["Recommendation Engine"]
        DOM_COMP["Comparison & Forecast Model"]
        DOM_TRUST["Cheat & Anomaly Detector"]
    end

    subgraph ENGINES["Heavy Execution Engines"]
        direction LR
        ENG_BENCH["Benchmark Engine Coordinator"]
        ENG_AI["AI Analysis Engine"]
        ENG_REP["Report Generator (Canvas & PDF)"]
        ENG_EXP["Multiformat Exporter (JSON / CSV / Card)"]
    end

    subgraph MONITORING["Monitoring & Telemetry Services"]
        direction LR
        MON_HW["Hardware Monitor"]
        MON_THERM["Thermal Headroom Monitor (API 29-36)"]
        MON_BAT["Battery & Power Monitor"]
        MON_FLOW["10 Hz Metric Stream (Kotlin Flow)"]
    end

    subgraph NATIVE_CORE["Native Core Layer (Rust NDK via UniFFI)"]
        direction LR
        NAT_CPU["CPU Kernels (FP, INT, Crypto, Matrix)"]
        NAT_GPU["Vulkan ash Renderer (SPIR-V Shaders)"]
        NAT_MEM["Memory & Storage Probes (Direct I/O)"]
        NAT_AI["LiteRT Adapter (Vendor NPU / GPU)"]
        NAT_CLOCK["Monotonic Timer & Thread Pinning"]
    end

    subgraph PLATFORM["Android Platform & Hardware Abstraction"]
        direction LR
        PLAT_ADPF["Performance Hint Manager (ADPF)"]
        PLAT_THERM["Thermal Headroom API & sysfs"]
        PLAT_VULKAN["Vulkan 1.3 Driver Loader"]
        PLAT_NPU["Qualcomm QNN / MediaTek / Tensor Delegates"]
        PLAT_KS["Android Keystore Hardware Key"]
    end

    subgraph DATA_PERSISTENCE["Persistence & Sync Layer"]
        direction LR
        DATA_ROOM[("Room SQLite DB (WAL Mode)")]
        DATA_DS["Encrypted DataStore Preferences"]
        DATA_CLOUD["Axum Backend Client (Optional TLS 1.3)"]
    end

    %% Layer interactions
    PRESENTATION --> APPLICATION
    APPLICATION --> DOMAIN
    APPLICATION --> ENGINES
    ENGINES --> DOMAIN
    ENGINES --> MONITORING
    ENGINES --> NATIVE_CORE
    MONITORING --> PLATFORM
    NATIVE_CORE --> PLATFORM
    ENGINES --> DATA_PERSISTENCE
    DOMAIN --> DATA_PERSISTENCE
    DATA_PERSISTENCE -. "Reactive Flow" .-> PRESENTATION
    MON_FLOW -. "10 Hz Telemetry Flow" .-> PRESENTATION
```

---

<a id="11-feature-dependency-graph"></a>
<a id="11-comprehensive-feature-dependency-graph"></a>
## 11. Comprehensive Feature Dependency Graph

This directed acyclic graph maps the structural dependencies across all 22 feature categories defined in `FEATURES.md`, tracing how hardware foundations feed execution suites, data integrity verifications, AI analysis, and public reporting.

```mermaid
---
title: "11. Comprehensive Feature Dependency Graph"
---
flowchart LR
    subgraph FOUNDATION["1. System Foundation & Capabilities"]
        F1["Permissions & System Consent"]
        F2["Hardware Detection & CPU Topology Scan"]
        F3["Capability Matrix (Vulkan 1.3, Ray Tracing, NPU)"]
        F4["Telemetry Probes (Thermal Headroom, Battery, Sysfs)"]
        F1 --> F2 --> F3 --> F4
    end

    subgraph EXECUTION["2. Workload Orchestration & Execution"]
        E1["Pre-Test Environment Validation"]
        E2["Scheduler & Concurrency Mutex"]
        E3["Native Benchmark Engine (Rust UniFFI)"]
        E4["Subsystem Suites (CPU, GPU, MEM, STO, AI)"]
        E5["Thermal Stress Test & Soak Runner"]
        E1 --> E2 --> E3 --> E4 --> E5
    end

    subgraph DATA_INTEG["3. Integrity, Scoring & Persistence"]
        D1["Score Aggregation (Geometric Mean)"]
        D2["Cheat Detection & Variance Filter (CoV < 5%)"]
        D3["Cryptographic Result Signing (Android Keystore)"]
        D4["Persistence Layer (Room DB WAL Mode)"]
        D1 --> D2 --> D3 --> D4
    end

    subgraph INTELLIGENCE["4. Intelligence & Diagnostic Analytics"]
        I1["LiteRT On-Device ML Analysis"]
        I2["Bottleneck Attribution Engine"]
        I3["Device Health Scoring (0-100)"]
        I4["Prescriptive Recommendations"]
        I5["Comparison & Trend Forecasting"]
        I1 --> I2 --> I4
        I3 --> I4
        I1 --> I5
    end

    subgraph DISTRIBUTION["5. Presentation, Export & Community"]
        O1["Canvas Data Visualizations"]
        O2["Vector PDF & Multiformat Exporter"]
        O3["AMOLED Share Card Generator"]
        O4["Verified Cloud Leaderboard (Opt-in)"]
        O1 --> O2 & O3
        O2 & O3 --> O4
    end

    %% Inter-tier dependency edges
    F4 --> E1
    F3 --> E4
    E4 --> D1
    E5 --> D1
    D4 --> I1
    F4 --> I3
    D4 --> I3
    D4 --> I5
    I4 --> O1
    I5 --> O1
    D3 --> O4
```

---

<a id="12-benchmark-state-diagram"></a>
<a id="12-benchmark-run-state-machine--thermal-fault-handling"></a>
## 12. Benchmark Run State Machine & Thermal Fault Handling

The benchmark run engine functions as a deterministic state machine managing the transitions between preparation, warmup, execution, telemetry sampling, safety interruption, and cryptographic persistence.

```mermaid
---
title: "12. Benchmark Run State Machine & Thermal Fault Handling"
---
stateDiagram-v2
    state "Idle / Ready" as Idle
    state "Pre-Flight Validation" as Validating
    state "Condition Warning / User Override" as WarningGate
    state "Warmup & Cache Priming" as Warmup
    state "Executing Benchmark Workload" as Running
    state "Paused (App Backgrounded / Interrupted)" as Paused
    state "Throttling Mitigation (Frequency Clamped)" as ThrottlingMitigation
    state "Safety Abort (Thermal Runaway / Low Battery)" as SafetyAborted
    state "Forced Thermal Soak / Cooldown" as Cooldown
    state "Scoring & Anomaly Inspection" as ScoringValidation
    state "Anomaly Detected (High Variance / Cheat)" as AnomalyHandling
    state "Cryptographic Signing & DB Persistence" as Persisting
    state "Benchmark Completed Successfully" as Completed
    state "Terminal Run Failure" as TerminatedFailed

    [*] --> Idle
    Idle --> Validating: User taps Start Benchmark
    
    Validating --> WarningGate: Environmental condition out of spec
    WarningGate --> Validating: Condition cleared or user override
    WarningGate --> Idle: User aborts test
    Validating --> Warmup: All preconditions validated

    Warmup --> Running: Clocks stabilized & cache primed
    
    Running --> Paused: User pause or incoming system call
    Paused --> Running: User resumes session
    Paused --> Idle: User cancels run

    Running --> ThrottlingMitigation: Thermal Headroom indicates throttling
    ThrottlingMitigation --> Running: Temperature stabilized within limits
    
    Running --> SafetyAborted: Critical limit breached (Temp > 48°C or Battery < 15%)
    ThrottlingMitigation --> SafetyAborted: Runaway heating sustained
    
    SafetyAborted --> Cooldown: Trigger emergency stop
    Cooldown --> TerminatedFailed: Cooldown elapsed, flag run aborted
    
    Running --> ScoringValidation: Workload iterations complete
    
    ScoringValidation --> AnomalyHandling: CoV > 5% or cheat signature identified
    AnomalyHandling --> Warmup: Retry budget remaining (Re-run test)
    AnomalyHandling --> TerminatedFailed: Retries exhausted, mark inconclusive
    
    ScoringValidation --> Persisting: Variance valid & integrity confirmed
    Persisting --> Completed: Saved to Room WAL & signed with Keystore
    
    Completed --> Idle: Return to Dashboard / History
    TerminatedFailed --> Idle: User dismisses error diagnosis
    Completed --> [*]
```

---

<a id="13-sequence-diagram"></a>
<a id="13-end-to-end-benchmark-execution-sequence"></a>
## 13. End-to-End Benchmark Execution Sequence

This sequence diagram depicts the chronological message interchange between the Compose UI layer, ViewModel state holders, native Rust engine, platform monitors, cryptographic keystore, Room database, and intelligence engines during an end-to-end run.

```mermaid
---
title: "13. End-to-End Benchmark Execution Sequence"
---
sequenceDiagram
    autonumber
    actor User as User
    participant UI as Compose UI Layer
    participant VM as BenchmarkViewModel
    participant BC as BenchmarkController
    participant HM as HardwareMonitor
    participant BE as Native BenchmarkEngine (Rust)
    participant RT as Vulkan / LiteRT Runtime
    participant KS as Android Keystore
    participant DB as Room Database (WAL)
    participant AI as AI Analysis Engine
    participant RE as Report Engine

    User->>UI: Select Benchmark Suite & Tap Start
    UI->>VM: dispatch(StartBenchmarkEvent)
    VM->>BC: executeBenchmark(suiteConfig)
    
    BC->>HM: checkPreconditions()
    HM->>HM: Query ThermalManager.getThermalHeadroom() & BatteryManager
    HM-->>BC: Preconditions OK (Headroom safe, Battery > 20%)
    
    BC->>BE: initializeEngine(nativeConfig)
    BE->>RT: allocateBuffers & compileShaders()
    RT-->>BE: Buffers allocated
    
    BC->>BE: executeWarmup()
    BE-->>BC: Warmup complete (clocks stabilized)
    
    BC->>BE: startWorkload()
    
    par Asynchronous 10 Hz Telemetry Streaming
        loop Every 100ms Sampling Interval
            HM->>HM: Sample CPU freq, Temp, Power (mW), Frame time
            HM-->>VM: emit LiveTelemetry(metrics)
            VM-->>UI: renderGaugesAndCurves(metrics)
        end
    and Native Workload Execution
        BE->>RT: dispatchVulkanCompute() / runLiteRTInference()
        RT-->>BE: executionSamplesEmitted()
    end
    
    BE-->>BC: WorkloadCompleted(rawSamples)
    
    BC->>BC: computeTrimmedScores & checkVariance()
    
    BC->>KS: signPayload(SHA256(rawResults))
    KS-->>BC: ecdsaSignatureCertificate
    
    BC->>DB: insertRunRecord(signedResultBundle)
    DB-->>BC: recordIdCreated
    
    BC->>AI: analyzeResults(recordId, rawSamples)
    AI->>AI: classifyBottlenecks & generateInsights()
    AI-->>BC: aiInsightsAndRecommendations
    
    BC->>RE: compileReport(recordId, aiInsights)
    RE-->>BC: reportModelReady
    
    BC-->>VM: BenchmarkFinished(summaryData)
    VM-->>UI: displayResultSummary(Screen 09)
    UI-->>User: Present Final Scores, Confidence & Insights
```

---

<a id="14-data-flow-diagram"></a>
<a id="14-unidirectional-data-flow-udf--telemetry-pipeline"></a>
## 14. Unidirectional Data Flow (UDF) & Telemetry Pipeline

The data pipeline connects native hardware sampling to user-facing Compose components. Raw telemetry from hardware sensors and Linux `/proc` and `/sys` interfaces is sampled, buffered, normalized, and emitted as immutable Kotlin `StateFlow` structures, decoupling hot native loops from UI allocations.

```mermaid
---
title: "14. Unidirectional Data Flow (UDF) & Telemetry Pipeline"
---
flowchart LR
    subgraph SENSORS["Platform Telemetry Sources"]
        direction TB
        S1["ThermalManager API (Headroom)"]
        S2["BatteryManager (mA, mV, °C)"]
        S3["Linux sysfs (/proc/stat, CPU freq)"]
        S4["Choreographer (Frame Times & Jitter)"]
    end

    subgraph ENGINE_CORE["Native Core Execution (Rust UniFFI)"]
        direction TB
        K1["CPU Stress Kernels"]
        K2["Vulkan Ash Compute Shaders"]
        K3["LiteRT Vendor NPU Delegates"]
        K4["Storage Direct I/O Probes"]
    end

    subgraph INGESTION["Telemetry Ingestion & Processing"]
        direction TB
        FLOW["Kotlin Coroutine Flow (10 Hz Throttle)"]
        AGG["Rolling Buffer & Metric Normalizer"]
        FLOW --> AGG
    end

    SENSORS -. "Sampled at 100ms" .-> FLOW
    ENGINE_CORE -. "Raw Timings & Ops" .-> AGG

    subgraph SCORING["Scoring & Cryptographic Attestation"]
        direction TB
        TRIM["Outlier Trim & Median Calculation"]
        GEO["Geometric Mean Weighting"]
        SIGN["Keystore ECDSA P-256 Signing"]
        TRIM --> GEO --> SIGN
    end

    AGG --> TRIM

    subgraph STORAGE["Local Persistence"]
        direction TB
        ROOM[("Room SQLite DB (WAL Mode)")]
        PREFS[("Encrypted DataStore")]
    end

    SIGN --> ROOM

    subgraph INTELLIGENCE["On-Device Intelligence Layer"]
        direction TB
        AI_ENG["AI Analysis Engine (LiteRT)"]
        REC_ENG["Prescriptive Recommendation Engine"]
        AI_ENG --> REC_ENG
    end

    ROOM --> AI_ENG

    subgraph UI_PRESENTATION["UI Presentation Layer (MVI Architecture)"]
        direction TB
        HUD["Screen 08: Live Run HUD (Gauges & Heatmap)"]
        SUMMARY["Screen 09: Result Summary"]
        DETAIL["Screen 10: Result Diagnostics & Charts"]
        RECS_UI["Screen 20: Recommendations"]
    end

    FLOW -. "Real-time State Flow" .-> HUD
    SIGN --> SUMMARY
    ROOM --> DETAIL
    REC_ENG --> RECS_UI

    subgraph CLOUD_OPTIN["Optional Cloud Aggregation (Opt-In)"]
        direction TB
        API["Axum Ingestion Gateway (TLS 1.3)"]
        PG[("PostgreSQL Results DB")]
        REDIS[("Redis Leaderboard Cache")]
        API --> PG & REDIS
    end

    ROOM -. "Signed Payload Upload" .-> API
    REDIS -. "Peer Percentile Baselines" .-> AI_ENG
```

---

<a id="15-component-diagram"></a>
<a id="15-modular-component-architecture--native-ndk-boundaries"></a>
## 15. Modular Component Architecture & Native NDK Boundaries

The codebase is organized into isolated Gradle modules and native Rust Cargo crates connected via UniFFI. Feature modules depend exclusively on core domain abstractions, and large optional assets (such as ray tracing scene geometries and on-device AI weights) are packaged into dynamic feature modules downloaded on demand.

```mermaid
---
title: "15. Modular Component Architecture & Native NDK Boundaries"
---
flowchart TB
    subgraph UI_MODULES[":feature-* UI Modules (Jetpack Compose)"]
        direction LR
        UI_DASH[":feature-dashboard"]
        UI_HUB[":feature-benchmarks"]
        UI_RUN[":feature-liverun"]
        UI_DIAG[":feature-diagnostics"]
        UI_HIST[":feature-history"]
        UI_REP[":feature-reports"]
    end

    subgraph CORE_MODULES[":core-* Common Infrastructure"]
        direction LR
        CORE_DS[":core-designsystem (Material 3 AMOLED Tokens)"]
        CORE_MODEL[":core-model (Domain Entities & Value Objects)"]
        CORE_COMMON[":core-common (Coroutines, Dispatchers, Result)"]
        CORE_NAV[":core-navigation (Typed Routes & Backstack)"]
    end

    subgraph ENGINE_MODULES[":engine-* Kotlin Services"]
        direction LR
        ENG_CTRL[":engine-benchmark (BenchmarkController)"]
        ENG_MON[":engine-monitor (Hardware & Thermal Headroom)"]
        ENG_SCHED[":engine-scheduler (WorkManager Queue)"]
        ENG_AI_SRV[":engine-ai (LiteRT Analyzer)"]
        ENG_DOC[":engine-report (PdfDocument & Canvas Exporters)"]
    end

    subgraph DYNAMIC_MODULES[":dynamic-* On-Demand Feature Modules"]
        direction LR
        DYN_RT[":dynamic-raytracing (Vulkan RT & Mesh Shaders)"]
        DYN_AI[":dynamic-ai-models (Large Language Model Weights)"]
        DYN_CAM[":dynamic-camera (CameraX Raw Video Processing)"]
    end

    subgraph NDK_BRIDGE["Native Interop Layer (UniFFI Binding Bridge)"]
        direction TB
        JNI_GLUE["Rust UniFFI Auto-Generated C/JNI Stubs"]
        SAFE_WRAPPER["libbenchmark_core.so (Safe Rust Facade)"]
        JNI_GLUE --- SAFE_WRAPPER
    end

    subgraph RUST_CRATES["Native Rust Crates (Cargo Workspace)"]
        direction LR
        CRATE_CPU["crate: benchmark-cpu (Multi-core, NEON SIMD)"]
        CRATE_GPU["crate: benchmark-gpu (ash Vulkan 1.3, SPIR-V)"]
        CRATE_MEM["crate: benchmark-memory (Bandwidth, Pointer Chasing)"]
        CRATE_STO["crate: benchmark-storage (Direct I/O, POSIX AIO)"]
        CRATE_SAMPLER["crate: telemetry-sampler (sysfs, CLOCK_MONOTONIC)"]
    end

    subgraph PLATFORM_NDK["Android Platform NDK APIs"]
        direction LR
        NDK_LIBVULKAN["libvulkan.so (Vulkan 1.3 Driver Loader)"]
        NDK_ADPF["libandroid.so (PerformanceHintManager / ADPF)"]
        NDK_THERMAL["libthermal.so (AThermalManager Headroom)"]
        NDK_LITERT["liblitert.so (Vendor NPU C Delegates)"]
    end

    subgraph DATA_STORAGE[":core-database & Security"]
        direction LR
        ROOM_DB["Room SQLite Database (WAL Mode)"]
        KEYSTORE["Android Keystore (Hardware TEE / StrongBox)"]
        DATASTORE["Encrypted DataStore Preferences"]
    end

    %% Dependency wiring
    UI_MODULES --> CORE_MODULES
    UI_MODULES --> ENGINE_MODULES
    DYNAMIC_MODULES -. "On-Demand Download" .-> ENG_CTRL
    ENGINE_MODULES --> CORE_MODULES
    ENGINE_MODULES --> NDK_BRIDGE
    NDK_BRIDGE --> RUST_CRATES
    RUST_CRATES --> PLATFORM_NDK
    ENGINE_MODULES --> DATA_STORAGE
```
