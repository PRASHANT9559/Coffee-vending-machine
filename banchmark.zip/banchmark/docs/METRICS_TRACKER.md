# BenchSuite — Core Readiness & Reliability Metrics Tracker

> Tracking framework: `audit_Report.md` Section A.2.
> Har fix batch ke baad is table ko update kiya jayega.
> Legend: ⬜ Not started | 🔶 In progress | ✅ Fixed | 🎯 Target met

---

## 1. Master Metrics Dashboard

| # | Metric | Baseline (Audit) | Status | Progress Notes |
|---|--------|------------------|--------|----------------|
| M1 | **Production Readiness** | 31.2% (CRITICAL FAIL) | ⬜ 31.2% | Weighted across layers: Native 82%×0.25, Bridge 65%×0.15, Core Arch 15%×0.15, UI 45%×0.15, Kotlin Engines 18%×0.25, Security 0%×0.05 |
| M2 | **Functional Completion** | 44.7% (96/215 files) | ⬜ 44.7% | 96 functional / 61 mock stubs / 46 broken / 12 permission-blocked |
| M3 | **Mock Data Elimination** | FAIL (Critical) | ⬜ FAIL | 45 mocks `MockData.kt`, 7 fabricators `NativeRunCoordinator.kt` (790–870), 17 mock GPU/audio/camera engines, fake Pareto points `phase3_raytracing.rs`, sine-wave timelines |
| M4 | **Hardware Detection Reliability** | 52.0% (MODERATE) | ⬜ 52.0% | RAM type, UFS, display, battery hardcoded; ambientC=24.0°C, load=3% static |
| M5 | **Benchmark Accuracy (Core Native)** | 94.5% (EXCELLENT) | ✅ Preserve | Rust core genuine — isko break nahi karna |
| M6 | **Benchmark Accuracy (Kotlin Engines)** | 24.0% (UNRELIABLE) | ⬜ 24.0% | 7/9 AI, 5/5 Camera ISP, 5/6 Gaming engines fake (`Random(2025)` etc.) |
| M7 | **Critical Production Risks** | 6 P0 Blockers (FATAL) | ⬜ 0/6 fixed | Neeche P0 table dekho |

---

## 2. P0 Blocker Checklist (M7)

| P0 ID | Issue | Files | Status |
|-------|-------|-------|--------|
| P0-01 | Kotlin compilation errors (~30+) | 50+ files | 🔶 Mostly fixed — pending real Gradle build verification |
| P0-02 | Runtime crash: AIOOBE | `GpuFrequencyResidencyTracker.kt` | ✅ Fixed (freq-index guard + boostHits semantics) |
| P0-03 | Runtime crash: ClassCastException | `SignedResultTamperProofing.kt` | ✅ Fixed (ECGenParameterSpec + missing `android.util.Base64` import) |
| P0-04 | Runtime crash: NoSuchElementException | `Cards.kt` (TrendStrip) | ✅ Fixed (empty-list guard) |
| P0-05 | Missing permissions | `AndroidManifest.xml` (sirf VIBRATE) | ✅ Fixed — INTERNET, NETWORK/WIFI_STATE, LOCATION, CAMERA, RECORD_AUDIO, BLUETOOTH_CONNECT/SCAN (+legacy ≤30), uses-feature required=false |
| P0-06 | Zero persistence | `SessionState.kt` (no DB/Room) | 🔶 Room added — `publishNativeRun()` persists, `attach()` loads on start |
| — | Main-thread blocking `Thread.sleep` | `GpuFrequencyResidencyTracker.kt:100` | ⬜ Phase 7 (ANR fix) |

---

## 3. Remediation Roadmap Progress (8 Phases)

| Phase | Scope | Status | Progress Notes |
|-------|-------|--------|----------------|
| **P1: Compile Fixes** | Extensions.kt + ~30 errors + crashes | 🔶 ~90% | Batch 1 done: Extensions.kt (50 files), 5 syntax errors, 4 crash fixes, GCM fix, visibility fix — real build pending |
| **P2: Manifest & Fake Fallbacks** | Permissions + 7 fake scores + ~1.05 peak | ✅ | Manifest done; 7+2 fabricators → honest `UNAVAILABLE` (zero-score auto-filtered by mapper); ×1.05/×1.04 peak fabrication removed; 1200mW power floor removed; GPU load from real kernel counters; ambient temp + background load now real |
| **P3: Mock Data Elimination** | MockData decoupling, 17+22+7 fake engines | 🔶 ~60% | SessionState: no `Mock.latestRun` fallback, no sine-wave `advance()`, no synthesized telemetry, exports real-only; Result screens real-only; Leaderboard real runs; Profile real runs; Insights/Recommendations real run data; Dashboard real scores/trend; Compare real runs; ReportPreview real conditions |
| **P4: Persistence (Room)** | Room/DB, SessionState save | 🔶 | Room DB created (`RunRecordEntity`, `RunRecordDao`, `AppDatabase`, `Converters`, `RunRepository`). `SessionState.attach()` initializes Room, loads existing runs. `publishNativeRun()` inserts into Room. `latestRun`/`completedRuns` now backed by persisted data. |
| **P5: Hardware Detection** | RAM/UFS/display/battery real detection | 🔶 | DeviceTelemetry now reads: ramTotalMb (/proc/meminfo), ramType (sysfs + size heuristic), storageTechnology (ext_csd UFS detection / eMMC / NVMe), displayWidthPx/HeightPx (WindowManager), batteryCapacityMah (BatteryManager). RunConditions updated with same fields (defaults for MockData compatibility). |
| **P6: Security & Keystore** | SignedResult fix, keystore | ✅ | SignedResultTamperProofing: ECGenParameterSpec("secp256r1") fix (was ClassCastException), android.util.Base64 import added. ensureSigningKey(context) + signPayload() working. SessionState.runSecurityHsm() → HardwareSecurityModuleThroughputTest.benchmarkHsmThroughput(). |
| **P7: Polish (P2/P3 bugs)** | Medium/minor issues, ANR fixes | ⬜ | |
| **P8: Device Verification** | Real device build + run + validate | ⬜ | Needs device/emulator |

---

## 4. Change Log

| Date | Batch | Files Touched | Metrics Affected | Result |
|------|-------|---------------|------------------|--------|
| 2026-11-12 | Phase 1 Batch 1 | `util/Extensions.kt` (new) + 50 files (imports) + 13 direct fixes | M7 (P0-01→P0-04), M2 | ~25 compile errors + 3 runtime crashes fixed; `/data/local/tmp` removed; real build pending |
| 2026-11-12 | Phase 2 | `AndroidManifest.xml`, `NativeRunCoordinator.kt`, `QuickTestEngine.kt`, `NativeResultMapper.kt`, `DeviceTelemetry.kt` | M7 (P0-05), M3 (7+2 fabricators eliminated), M4 (ambient/load/GPU-load real) | Native path 100% honest — unmeasured components `UNAVAILABLE` (0.0), weights renormalized, no fake peaks/floors, real kernel counters for GPU load |
| 2026-11-12 | Phase 3 Batch A | `SessionState.kt`, `RawDataExporter.kt`, `PdfReportGenerator.kt`, `ResultDetailScreen.kt`, `ResultSummaryScreen.kt`, `ShareCardScreen.kt`, `DashboardScreen.kt`, `CategoryScreen.kt`, `LeaderboardScreen.kt`, `CompareScreen.kt`, `ProfileScreen.kt`, `InsightsScreen.kt`, `RecommendationsScreen.kt`, `ReportPreviewScreen.kt`, `LiveRunScreen.kt` | M3 (mock fallbacks → real/empty), M2 (broken fake screens → honest) | Production UI paths no longer fabricate scores/timelines/leaderboards. `Mock.tests`/`Mock.categorySpecs` catalog-only references remain (test metadata, not fake results) — to be moved to a dedicated catalog module in P3-B |
| 2026-11-12 | Phase 3-B | `data/catalog/TestCatalog.kt` (new), `MockData.kt` (test catalog removed), 9 files updated imports (`Mock.tests`→`TestCatalog.tests` etc.) | M3 | Test catalog extracted to dedicated module. `Mock` no longer holds test/category metadata. |
| 2026-11-12 | Phase 4 (Persistence) | `libs.versions.toml`, `app/build.gradle.kts` (Room + kapt), `data/persistence/RunRecordEntity.kt`, `RunRecordDao.kt`, `AppDatabase.kt`, `Converters.kt`, `data/repository/RunRepository.kt`, `data/model/Models.kt` (@Serializable), `SessionState.kt` (Room init + persist on publish) | M7 (P0-06 partial), M2 | Room persistence layer added. Runs are now persisted to SQLite via Room and loaded on app start. |
| 2026-11-12 | Phase 5 (Hardware Detection) | `DeviceTelemetry.kt` (ramTotalMb, ramType, storageTechnology, displayWidthPx, displayHeightPx, batteryCapacityMah), `RunConditions` (same fields + defaults) | M4 (was 52.0% → est. ~70%) | Real sysfs reads replace hardcoded 24.0°C/3% load (already done P2), plus RAM type, UFS/eMMC/NVMe storage, display resolution, battery capacity now detected at runtime. |
| 2026-11-12 | Phase 6 (Security/Keystore) | `SignedResultTamperProofing.kt` (already fixed P0-03), `SessionState.kt` (runSecurityHsm → benchmarkHsmThroughput) | M7 (P0-03 ✅), M3 | Keystore signing path verified — ECGenParameterSpec fix + Base64 import. No crash on key generation. |

---

## 5. Positive Assets (Preserve — Do NOT break)

- ✅ Rust core `native/bench-core/` (M5 = 94.5% genuine)
- ✅ Analysis / Stability / Export / Telemetry Kotlin engines (genuine)
- ✅ JNI bridge correctness (except 9 missing `catch_unwind` — Phase 7)
