# BenchSuite — UI Milestone (v1.0.0-ui)

The complete 35-screen Compose UI described in [`README.md`](README.md), [`WORKFLOW.md`](WORKFLOW.md),
and [`FEATURES.md`](FEATURES.md), plus the first Rust/JNI benchmark engine. Every screen is
implemented and wired into the navigation graph; data comes from the native core when it is
packaged, and from realistic in-memory mock data otherwise.

---

## 1. Status

| Area | State |
| --- | --- |
| Design system (tokens, type, shape, theme) | Complete |
| 35 documented screens | Complete |
| Bottom navigation + More menu | Complete |
| Run flow (pre-test → live → results → insights) | Complete, simulated and native |
| Charts (all custom Canvas) | Complete |
| Dark / light / dynamic color | Complete |
| Mock data set | Complete |
| Native core (CPU/memory/storage/stress/AI/GLES GPU) | Complete, host-tested |
| Vulkan / LiteRT runtime | Next milestone |

The app builds to a single `:app` module. Without the native library the UI runs
on mock data; with `-Pnative=true` the run flow measures the device.

---

## 2. Build

Requirements:

- JDK 17
- Android SDK Platform 36 (`compileSdk = 36`, `targetSdk = 36`, `minSdk = 29`)
- Android Studio Ladybug or newer (recommended), or the command line

From the project root:

```bash
# The wrapper JAR is not committed; generate it once with a local Gradle 8.11.1 install
gradle wrapper --gradle-version 8.11.1

./gradlew :app:assembleDebug
```

Alternatively, open the folder in Android Studio and let it sync — Studio supplies its own
Gradle distribution and the wrapper.

Output: `app/build/outputs/apk/debug/app-debug.apk`
(package `com.benchsuite.app.debug`).

### Native engine build (optional)

Requirements: Rust stable, `cargo-ndk`, NDK 27+, and the Android target.

```bash
rustup target add aarch64-linux-android
cargo install cargo-ndk
export ANDROID_NDK_HOME="$HOME/Android/Sdk/ndk/27.0.12077973"

./gradlew :app:assembleDebug -Pnative=true
```

Without `-Pnative=true`, Gradle never invokes Rust and the app runs in simulated
mode. See [`native/README.md`](native/README.md) for the kernel and JNI contract.

Versions: AGP 8.9.1, Kotlin 2.1.10, Gradle 8.11.1, Compose BOM 2025.03.00,
Navigation Compose 2.8.9.

---

## 3. Screen map

All source paths are under
`app/src/main/java/com/benchsuite/app/`.

| # | Screen | Route | Source |
| --- | --- | --- | --- |
| 1 | Splash | `splash` | `features/entry/EntryScreens.kt` |
| 2 | Onboarding | `onboarding` | `features/entry/EntryScreens.kt` |
| 3 | Permission Rationale | `permissions` | `features/entry/EntryScreens.kt` |
| 4 | Hardware Detection | `hardware` | `features/entry/EntryScreens.kt` |
| 5 | Dashboard | `dashboard` | `features/core/DashboardScreen.kt` |
| 6 | Benchmarks Hub | `benchmarks` | `features/core/BenchmarksHubScreen.kt` |
| 7 | Pre-Test Checklist | `pretest/{categoryId}` | `features/core/PreTestScreen.kt` |
| 8 | Live Run | `live` | `features/core/LiveRunScreen.kt` |
| 9 | Result Summary | `result/summary/{runId}` | `features/core/ResultSummaryScreen.kt` |
| 10 | Result Detail | `result/detail/{runId}` | `features/core/ResultDetailScreen.kt` |
| 11 | CPU Benchmark | `category/cpu` | `features/category/CategoryScreen.kt` |
| 12 | GPU Benchmark | `category/gpu` | `features/category/CategoryScreen.kt` |
| 13 | Memory | `category/memory` | `features/category/CategoryScreen.kt` |
| 14 | Storage | `category/storage` | `features/category/CategoryScreen.kt` |
| 15 | AI | `category/ai` | `features/category/CategoryScreen.kt` |
| 16 | Gaming | `category/gaming` | `features/category/CategoryScreen.kt` |
| 17 | Stress Test | `category/thermal` | `features/category/CategoryScreen.kt` |
| 18 | Device Health | `category/health` | `features/category/CategoryScreen.kt` |
| 19 | AI Insights | `insights` | `features/insight/InsightsScreen.kt` |
| 20 | Recommendations | `recommendations` | `features/insight/RecommendationsScreen.kt` |
| 21 | History | `history` | `features/data/HistoryScreen.kt` |
| 22 | Comparison | `compare` | `features/data/CompareScreen.kt` |
| 23 | Reports | `reports` | `features/data/ReportsScreen.kt` |
| 24 | Report Preview & Export | `report/{reportId}` | `features/data/ReportPreviewScreen.kt` |
| 25 | Leaderboard | `leaderboard` | `features/data/LeaderboardScreen.kt` |
| 26 | Device Info | `device-info` | `features/data/DeviceInfoScreen.kt` |
| 27 | Custom Builder | `custom-builder` | `features/tools/CustomBuilderScreen.kt` |
| 28 | Scheduler Queue | `scheduler` | `features/tools/SchedulerScreen.kt` |
| 29 | Profile | `profile` | `features/account/ProfileScreen.kt` |
| 30 | Settings | `settings` | `features/account/SettingsScreen.kt` |
| 31 | Privacy & Data | `privacy` | `features/account/PrivacyScreen.kt` |
| 32 | About | `about` | `features/account/AboutScreen.kt` |
| 33 | Help & Support | `help` | `features/account/HelpScreen.kt` |
| 34 | Run Failed & Retry | `run-failed` | `features/edge/RunFailedScreen.kt` |
| 35 | Share Card | `share` | `features/edge/ShareCardScreen.kt` |

Extra destinations: `more` (`features/misc/MoreScreen.kt`) hosts the overflow menu entries from
README §5.1. The eight category screens share one data-driven `CategoryScreen`, parameterized by
`Mock.categorySpecs`.

---

## 4. Package layout

```
com.benchsuite.app
├── MainActivity.kt              setContent + BenchSuiteTheme
├── BenchSuiteApp.kt             Scaffold, bottom bar, run banner, NavHost, cancel dialog
├── navigation/
│   ├── Routes.kt                string routes + bottom tabs
│   └── BottomBar.kt             5-tab Material 3 navigation bar
├── data/
│   ├── model/Models.kt          domain models, enums, verdicts, bands
│   └── mock/MockData.kt         full realistic mock dataset
├── ui/
│   ├── theme/                   Color, Type, Shape, Theme (dark/light/dynamic)
│   ├── components/              AppIcons, Common, Cards, Charts
│   └── state/SessionState.kt    settings, consents, schedules, custom tests, live run
└── features/
    ├── entry/ core/ category/   entry, run flow, 8 category screens
    ├── insight/ data/ tools/    insights, history/reports, builder/scheduler
    ├── account/ edge/ misc/     settings/privacy, failure/share, More menu
```

---

## 5. Design system

- **Dark-first.** Background `#05070A`, surface `#10141A`, primary cyan `#22D3EE`,
  secondary violet `#A78BFA`. A full light palette is also defined.
- **Data colors are fixed.** `LocalBenchColors` supplies success/warning/danger, the chart series,
  and the thermal ramp. Material You dynamic color (optional, in Settings) only tints non-data
  surfaces, so screenshots and result cards stay comparable.
- **Typography** is a compact technical scale (display through label) with tabular figures for
  metrics; **shapes** are 4/8/12/20/28 radii, matching README §6.
- **Charts** (`ui/components/Charts.kt`) are hand-drawn with Compose `Canvas`: line/area trends,
  bar and grouped bars, radar, gauge, thermal ramp, distribution and comparison bars — no chart
  library.
- **Motion** is 150–300 ms ease-out; reduced-motion is honored via the theme.
- **Chrome** (`ui/components/Common.kt`) provides the shared screen scaffold, top bars, chips,
  metric tiles, section headers, and list rows.

---

## 6. State and mock data

- `SessionState` is a process-wide singleton holding onboarding/hardware flags, theme and unit
  settings, consent toggles, scheduled runs, selected custom tests, the live run, and the latest
  native result.
- `SessionState.startRun(categoryId, title)` starts a native run when `libbench_core.so` is
  packaged, or a timed simulation otherwise. `LiveRunScreen` renders progress, FPS, temperature,
  and power, then navigates to `Routes.resultSummary(runId)`.
- `MockData.kt` contains devices, runs, results, category specs, tests, insights,
  recommendations, reports, leaderboard entries, device info, badges, schedules, and FAQs.
  Every screen renders from this data, so swapping in real repositories later is a matter of
  replacing the `Mock` object references.
- Deep links: `benchsuite://result/{runId}` opens Result Summary.

---

## 7. Navigation

- **Bottom bar (5):** Dashboard, Benchmarks, History, Reports, Profile.
- **More menu:** Device Info, Leaderboard, Comparison, Custom Builder, Scheduler, Settings, About,
  Privacy, Help.
- **Run flow:** Category → Pre-Test → Live Run → Result Summary → Result Detail → Insights →
  Recommendations.
- **Edge flow:** Live Run → Run Failed → Pre-Test.
- A persistent run banner returns to Live Run from any tab, with a cancel confirmation dialog.

---

## 8. Native engine

The first engine milestone lives in `native/bench-core` and is compiled to
`libbench_core.so` by `cargo-ndk` when `-Pnative=true` is set.

- **Kernels:** CPU integer/FP/multi-thread, memory bandwidth/latency, storage
  sequential/random IO, sustained stress, int8 AI proxy, headless GLES GPU.
- **Scoring:** baseline-1000 normalization, weighted geometric mean, band and
  confidence — the same methodology constants as the UI.
- **Bridge:** `com.benchsuite.app.nativecore.NativeBridge` returns typed JSON
  payloads; missing libraries are handled without crashing.
- **Run wiring:** `NativeRunCoordinator` runs the probes for the selected
  category, samples battery/thermal state, builds a `RunRecord` and feeds the
  existing result screens. Without the library, the original simulation is used.
- **About:** shows the live engine version when the library is packaged.

Next: Vulkan compute/ray tracing, LiteRT vendor delegates, result signing, and
Room-backed history.
