# Android Benchmark Suite

A next-generation, local-first Android benchmarking platform engineered to diagnose **why** hardware behaves the way it does, rather than simply measuring execution speed. The suite evaluates CPU, GPU, NPU/AI, memory, storage, gaming stability, thermals, battery efficiency, and hardware security across Android devices, transforming granular hardware telemetry into actionable diagnostics, comparative percentiles, and verifiable reports.

| Metric | Specification |
| :--- | :--- |
| **Platform Compatibility** | Android 10.0+ (API level 29) through Android 16 (API level 36) |
| **Architecture Target** | 64-bit ARM (`arm64-v8a`, `arm64-v8.2-a+`, `arm64-v9-a`), optional `armeabi-v7a` legacy fallback |
| **Scale Target** | Single-device offline telemetry; cloud aggregation supporting millions of verified runs |
| **Screen Architecture** | 35 Jetpack Compose screens structured across 7 functional navigation flows |
| **Feature Coverage** | 158 distinct benchmarks and diagnostics across 22 categories (see [FEATURES.md](FEATURES.md)) |
| **Architectural Diagrams** | 15 production-grade Mermaid specifications (see [WORKFLOW.md](WORKFLOW.md)) |

## Documentation Map

| Specification Document | Scope & Contents |
| :--- | :--- |
| [`README.md`](README.md) | Architectural foundations, technology decisions, native engine design, database schema, design system, screen catalog, and delivery engineering. |
| [`WORKFLOW.md`](WORKFLOW.md) | End-to-end Mermaid diagrams: application lifecycle, state machines, sequence diagrams, engine pipelines, and component relationships. |
| [`FEATURES.md`](FEATURES.md) | Comprehensive 158-feature specification catalog detailing implementation difficulty, innovation indices, API levels, and rollout phases. |

---

## 1. Product Vision & Principles

### 1.1 Market Problems & Strategic Solutions

Commercial benchmarking tools frequently produce opaque single-score composites that reward aggressive thermal cheating while obscuring real-world behavior. This platform solves four industry-wide limitations:

1. **Composite Score Blindness:** Traditional benchmarks mask sustained thermal collapse behind brief peak bursts. This suite measures and visualizes both instantaneous peak capacity and sustained performance over time, computing throttling slope coefficients and stability indices.
2. **Thermal & Throttling Reality:** Clocks drop as junction temperatures climb. The engine maps real-time thermal zones, skin temperatures, and SoC power draw to isolate whether performance decay is induced by passive chassis limits, aggressive DVFS throttling, or power rail capping.
3. **Actionable Insight Layer:** Raw IOPS and FLOP counts fail to explain real-world app sluggishness. The suite maps micro-benchmarks directly to user experiences: gaming frame drops, 4K/8K video rendering delays, on-device LLM token latency, and camera shutter-to-storage lag.
4. **Verifiable Result Integrity:** Uncontrolled background processes and vendor benchmark-whitelisting skew comparisons. The suite enforces strict pre-test environment normalization, detects artificial boosting heuristics, and cryptographically signs every result payload via hardware-backed Key Attestation.

### 1.2 Architectural Principles

- **Deterministic Measurement over Speed:** If a measurement is non-reproducible, it is invalid. Tests execute fixed algorithmic kernels with pre-allocated working sets, reporting sample variance ($\sigma^2$) and coefficient of variation ($CV$).
- **Zero Observer Interference:** The measurement harness must not perturb the system under test. The UI thread throttles to 10 Hz during active workloads; telemetry collection runs on low-overhead lockless native buffers; all dynamic memory allocations are banned within measurement loops.
- **Local-First Autonomy:** The core engine, analysis pipelines, report generation, and diagnostic databases operate completely offline. Cloud synchronizations and leaderboard submissions remain strictly opt-in.
- **Uncompromised Transparency:** When a device fails to run a hardware acceleration path (such as NPU delegates), the runtime explicitly logs the fallback cause rather than silently substituting CPU emulation.
- **Modular Kernel Isolation:** Tests are compiled as decoupled native units adhering to a strict execution contract, enabling continuous integration of modern instruction sets (e.g., SVE2, SME, Post-Quantum crypto).

### 1.3 Target Personas & Value Delivery

| Target Persona | Core Requirements | Delivered Capabilities |
| :--- | :--- | :--- |
| **Everyday Consumers** | Understand device degradation, battery health, and real-world responsiveness. | One-tap health check, plain-language diagnostic summaries, actionable battery/storage optimization recommendations. |
| **Competitive Gamers** | Evaluate 1% low frame times, sustained FPS, and touch-to-photon latency. | Frame pacing consistency histograms, 30-minute thermal endurance runs, thermal throttling alerts. |
| **Digital Content Creators** | Predict video export durations, RAW photo batch editing, and storage bus saturation. | Real-world media pipeline simulations, UFS sequential write decay curves, memory bandwidth pressure profiles. |
| **AI Engineers & Enthusiasts** | Measure local LLM inference speed, quantization fidelity, and NPU acceleration. | Tokens-per-second profiling, energy-per-token metering, explicit LiteRT NPU vs. CPU fallback diagnostics. |
| **Hardware Reviewers** | Obtain transparent, tamper-proof, and reproducible comparative figures. | Standardized pre-run soak protocols, CSV/JSON raw telemetry exports, hardware-signed verification proofs. |
| **OEMs & System Engineers** | Identify kernel scheduling inefficiencies, DVFS governor quirks, and driver anomalies. | Perfetto trace triggers, core-to-core latency matrices, interrupt latency profilers, headless CLI automation. |

---

## 2. Technology Stack & Deep Technical Implementation

### 2.1 Technology Selection Matrix

```
+---------------------------------------------------------------------------------------+
|                                Presentation & UI Layer                                |
|             Jetpack Compose + Material 3 Design System (Tabular Figures, AMOLED)      |
+---------------------------------------------------------------------------------------+
|                                Application & Domain                                  |
|         Kotlin Coroutines 1.9+ & Flow | Hilt DI 2.52+ | Architecture Components       |
+---------------------------------------------------------------------------------------+
|                             Data Persistence & Telemetry                              |
|           Room Database 2.6+ (SQLite WAL Mode) | Jetpack Proto DataStore             |
+---------------------------------------------------------------------------------------+
|                                Native Bridge Boundary                                 |
|         UniFFI (Mozilla) Code-Generated FFI | Direct ByteBuffer Zero-Copy Passing     |
+---------------------------------------------------------------------------------------+
|                                Native Core Engine (Rust)                              |
|        Deterministic Kernels | SIMD (NEON/SVE2) | Ash Vulkan 1.3 | LiteRT C-API       |
+---------------------------------------------------------------------------------------+
```

| Layer / Subsystem | Technology Selection | Architectural Rationale |
| :--- | :--- | :--- |
| **Application UI** | **Jetpack Compose + Material 3** | Declarative state-driven UI; zero XML view hierarchy overhead; hardware-accelerated canvas rendering for real-time charts at up to 120 Hz. |
| **Language Runtime** | **Kotlin 2.0+** | First-class coroutine concurrency, structured lifecycle management, direct bindings to modern Android Jetpack libraries. |
| **Native Core Engine** | **Rust 1.82+ (NDK r27+)** | Guarantees memory safety and zero garbage-collection pauses during microsecond-sensitive telemetry loops; exposes bare-metal CPU instruction intrinsic control. |
| **Native FFI Bridge** | **Mozilla UniFFI (UDL & Proc Macros)** | Generates thread-safe, strongly typed Kotlin/Rust bindings; eliminates fragile handwritten JNI boilerplate; provides structured panic handling. |
| **GPU Graphics / Compute** | **Vulkan 1.1 / 1.2 / 1.3 (`ash` crate)** | Direct low-overhead access to mobile GPU command queues, timeline semaphores, ray tracing pipelines, and asynchronous compute queues without driver abstraction overhead. |
| **On-Device AI Runtime** | **Google LiteRT (C API & Vendor Delegates)** | Official high-performance successor to TensorFlow Lite; provides direct vendor NPU delegate bindings (QNN, NeuroPilot, ENPU, edgetpu) replacing deprecated Android NNAPI. |
| **Asynchronous Streaming** | **Kotlin Coroutines + Flow** | Non-blocking reactive telemetry pipelines; backpressure-aware time-series data routing from native producers to Compose consumers. |
| **Dependency Injection** | **Dagger Hilt** | Compile-time dependency verification, standardized lifecycle scopes (`@Singleton`, `@ViewModelScoped`), frictionless unit test substitution. |
| **Local Relational DB** | **Room (SQLite, WAL Mode)** | Strongly typed persistence, indexed historical lookups, zero main-thread disk access, asynchronous paging support. |
| **Structured Preferences** | **Jetpack Proto DataStore** | Replaces thread-blocking, type-unsafe `SharedPreferences` with transactional, asynchronous Protocol Buffer schemas. |
| **Background Scheduling** | **Android Jetpack WorkManager** | Battery- and constraint-aware execution for scheduled health diagnostics and maintenance runs. |
| **Security & Attestation** | **Play Integrity + Android KeyStore** | Hardware-backed cryptographic ECDSA/HMAC signing of benchmark results; verifies device boot state and APK signature authenticity. |

---

### 2.2 Native Core: Rust NDK & UniFFI Bridge Architecture

Timing-sensitive benchmark loops and direct hardware probes are compiled in native Rust to avoid JVM garbage collection interrupts and runtime JIT variability.

```
+-----------------------------------+             +------------------------------------+
|          Kotlin Domain            |             |             Rust Core              |
|                                   |             |                                    |
| [BenchmarkEngineRepository]       |             | [NativeBenchmarkCoordinator]       |
|                 |                 |             |                 |                  |
|                 v                 |             |                 v                  |
| [UniFFI Auto-Generated Bindings]  | <--- FFI -> | [UniFFI Export Interface]          |
|                 |                 |             |                 |                  |
|                 v                 |             |                 v                  |
| DirectByteBuffer / AHardwareBuffer| < Zero-Copy | Raw Pointer &[u8] / Raw Slice      |
+-----------------------------------+             +------------------------------------+
```

#### 2.2.1 UniFFI Interface Definition & Safe Rust Exports

The bridge between Kotlin and the Rust core is built using Mozilla's UniFFI tooling, employing procedural macros (`uniffi::export`, `uniffi::Record`, `uniffi::Enum`) to generate type-safe bindings across the JNI boundary:

```rust
// Rust native core: native/benchmark_core/src/lib.rs
uniffi::setup_scaffolding!();

#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum BenchmarkEngineError {
    #[error("Hardware capability missing: {0}")]
    CapabilityUnsupported(String),
    #[error("Thermal safety trip exceeded: {temperature_celsius}°C")]
    ThermalTripAborted { temperature_celsius: f32 },
    #[error("Vulkan initialization failed with code: {vk_result}")]
    VulkanInitializationError { vk_result: i32 },
    #[error("Execution failed: {message}")]
    ExecutionFailure { message: String },
}

#[derive(Clone, Debug, uniffi::Record)]
pub struct BenchmarkTelemetrySample {
    pub timestamp_ns: u64,
    pub core_frequencies_khz: Vec<u32>,
    pub cpu_utilization_percent: f32,
    pub soc_temperature_celsius: f32,
    pub battery_voltage_mv: u32,
    pub instantaneous_power_mw: f32,
    pub frames_per_second: f32,
}

#[uniffi::export(callback_interface)]
pub trait TelemetryReceiver: Send + Sync {
    fn on_telemetry_sample(&self, sample: BenchmarkTelemetrySample);
}

#[derive(uniffi::Object)]
pub struct NativeBenchmarkCoordinator {
    is_running: std::sync::atomic::AtomicBool,
}

#[uniffi::export]
impl NativeBenchmarkCoordinator {
    #[uniffi::constructor]
    pub fn new() -> std::sync::Arc<Self> {
        std::sync::Arc::new(Self {
            is_running: std::sync::atomic::AtomicBool::new(false),
        })
    }

    pub fn execute_workload(
        &self,
        test_id: String,
        warmup_iterations: u32,
        measurement_iterations: u32,
        receiver: Box<dyn TelemetryReceiver>,
    ) -> Result<f64, BenchmarkEngineError> {
        // Enforce panic boundary inside Rust core
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            self.run_guarded_kernel(&test_id, warmup_iterations, measurement_iterations, &*receiver)
        }))
        .map_err(|_| BenchmarkEngineError::ExecutionFailure {
            message: "Native kernel panicked during execution".into(),
        })?
    }
}
```

#### 2.2.2 Zero-Copy Memory & Panic Safety Invariants

1. **Zero-Copy Telemetry & Buffer Sharing:** Large memory arrays (e.g., raw GPU readback buffers, memory bandwidth test matrices, audio PCM frames) bypass JNI memory copies. The Kotlin layer allocates an off-heap `java.nio.ByteBuffer.allocateDirect()` or obtains an `AHardwareBuffer` handle via the NDK, passing the direct address (`GetDirectBufferAddress`) to Rust. Rust wraps this address in a safe lifetime-bound slice `std::slice::from_raw_parts_mut`, executing AVX/NEON SIMD passes without intermediate allocations.
2. **Strict FFI Panic Boundaries:** A native Rust panic unwinding across the JNI C boundary results in undefined behavior (instantaneous process abort without stack traces). Every native entry point encapsulates execution in `std::panic::catch_unwind`. Unwound panics are caught, mapped into structured `BenchmarkEngineError` variants, and propagated across UniFFI as typed Kotlin exceptions (`BenchmarkEngineException`).
3. **Lockless Telemetry Dispatch:** Real-time sensor and hardware polling threads write into a lockless native ring buffer (using atomic sequence indices). A dedicated background telemetry thread flushes samples across the UniFFI callback interface at a controlled 10 Hz cadence, ensuring high-frequency internal sampling (1 kHz) never stalls or creates GC pressure in the Android runtime.

---

### 2.3 Graphics & Compute: Vulkan Pipeline Architecture

Mobile GPU performance is evaluated via the Khronos Vulkan 1.1–1.3 graphics and compute API using the Rust `ash` crate, interfacing directly with the Android NDK `vulkan.h` loader.

```
+---------------------------------------------------------------------------------------+
|                                Vulkan Device Instance                                 |
+---------------------------------------------------------------------------------------+
| Dedicated Graphics Queue Family   | Dedicated Compute Queue Family | Dedicated Transfer|
| (VK_QUEUE_GRAPHICS_BIT)           | (VK_QUEUE_COMPUTE_BIT)         | Queue Family      |
|                                   |                                |                   |
| - ANativeWindow Surface Rendering | - Heavy BVH Ray Traversal      | - Host-to-Device  |
| - Swapchain (FIFO / Mailbox)      | - Async Matrix Multiplications |   Staging Memory  |
| - RenderPass & Graphics Pipelines | - Parallel Cloth/Physics Sims  | - Buffer Uploads  |
+-----------------------------------+--------------------------------+-------------------+
|               Synchronization: VkTimelineSemaphoreKHR & VkFence                       |
|               Shaders: Pre-Compiled SPIR-V Bytecode Cached via VkPipelineCache        |
+---------------------------------------------------------------------------------------+
```

#### 2.3.1 Queue Management & Asynchronous Compute

Mobile SoCs (such as Qualcomm Adreno, ARM Immortalis/Mali, and Imagination PowerVR) exhibit distinct queue behaviors:
- **Dedicated Graphics Queue (`VK_QUEUE_GRAPHICS_BIT`):** Owns presentation to the Android `ANativeWindow` surface (`VK_KHR_android_surface`). Operates in two distinct modes:
  - `VK_PRESENT_MODE_FIFO_KHR`: Strictly capped to display refresh rate (60/90/120 Hz) to measure frame pacing consistency, jitter, and 1% low frame durations.
  - `VK_PRESENT_MODE_MAILBOX_KHR` or `VK_PRESENT_MODE_IMMEDIATE_KHR`: Triple-buffered non-blocking presentation to measure unconstrained peak fillrate and sustained GPU throughput under unrestricted load.
- **Dedicated Asynchronous Compute Queue (`VK_QUEUE_COMPUTE_BIT`):** The engine probes `vkGetPhysicalDeviceQueueFamilyProperties` to discover independent compute queue families. Heavy compute shaders (e.g., ray tracing bounding volume hierarchy [BVH] updates, particle simulations) are dispatched concurrently to the compute queue while the graphics queue renders scene geometry, directly evaluating SoC concurrent pipeline saturation.
- **Cross-Queue Synchronization (`VkTimelineSemaphoreKHR`):** Modern timeline semaphores replace legacy binary semaphore chains, allowing fine-grained execution dependencies between compute tasks and raster passes using monotonically increasing 64-bit integer values without CPU intervention.

#### 2.3.2 SPIR-V Shaders & Pipeline Cache Management

- **Offline Bytecode Compilation:** All GLSL/Slang shader source files are pre-compiled during build time using `glslangValidator` into optimized SPIR-V 1.3 / 1.5 binaries and embedded within the APK assets.
- **Elimination of Runtime Shader Compilation Jitter:** Driver shader compilation during active rendering triggers severe frame drops, corrupting frame-pacing metrics. The Vulkan engine initializes a persistent `VkPipelineCache`. On first run, all pipeline states are pre-compiled and warmed up during the pre-test staging phase. The serialized cache binary is written to the app's internal cache directory via `vkGetPipelineCacheData` and restored on subsequent launches, guaranteeing deterministic run-time execution.
- **Hardware Feature Gating & Graceful Degradation:**
  - *Hardware Ray Tracing:* Probed via `VK_KHR_ray_tracing_pipeline` and `VK_KHR_acceleration_structure`. If unsupported by the underlying GPU hardware/driver, the test gracefully switches to a compute-shader software BVH traversal pass, tagging the result metadata accordingly.
  - *Mesh Shading:* Probed via `VK_EXT_mesh_shader`. When absent, traditional vertex/index primitive assembly pipelines are executed.
  - *Variable Rate Shading (VRS):* Probed via `VK_KHR_fragment_shading_rate`. Evaluates fillrate power efficiency across $1\times1$, $2\times2$, and $4\times4$ coarse pixel shading.

---

### 2.4 Machine Learning Runtime: LiteRT & NPU Fallback Engine

With Android 15 formally deprecating the Android Neural Networks API (NNAPI, API 35), this benchmark suite migrates entirely to **Google LiteRT** (formerly TensorFlow Lite Runtime) leveraging direct vendor hardware delegates.

```
+---------------------------------------------------------------------------------------+
|                                   LiteRT Model Graph                                  |
+---------------------------------------------------------------------------------------+
                                           |
                                           v
+---------------------------------------------------------------------------------------+
|                       Vendor NPU Delegate Priority Cascade                            |
|                                                                                       |
|   1. Qualcomm Snapdragon: QNN Delegate (libQnnHtp.so / QnnDelegate)                   |
|   2. MediaTek Dimensity:  NeuroPilot Delegate (libneuron_adapter.so)                  |
|   3. Samsung Exynos:      ENPU Delegate (libeden_delegate.so)                         |
|   4. Google Tensor:       EdgeTPU Delegate (libedgetpu_delegate.so)                   |
+---------------------------------------------------------------------------------------+
                                           |
                              [Fallback Triggered / Failed]
                                           v
+---------------------------------------------------------------------------------------+
|                   GPU Fallback: TfLiteVulkanDelegate / OpenCL Delegate                |
+---------------------------------------------------------------------------------------+
                                           |
                              [Fallback Triggered / Failed]
                                           v
+---------------------------------------------------------------------------------------+
|                 CPU SIMD Fallback: XNNPACK Delegate (FP16 / INT8 / NEON)              |
+---------------------------------------------------------------------------------------+
```

#### 2.4.1 Vendor Delegate Selection Hierarchy

During hardware initialization, the AI engine probes vendor hardware strings (`android.os.Build.HARDWARE`, `/proc/cpuinfo`, and system library availability in `/vendor/lib64/`) and instantiates delegates in the following priority:
1. **Qualcomm NPU:** Dynamically loads the Qualcomm QNN HTP (Hexagon Tensor Processor) delegate (`libQnnHtp.so`), configuring quantized INT8/INT4/FP16 execution graphs.
2. **MediaTek NPU:** Dynamically loads the MediaTek NeuroPilot delegate (`libneuron_adapter.so`) targeting APU hardware blocks.
3. **Samsung Exynos NPU:** Interfaces with the Samsung ENPU runtime (`libeden_delegate.so`).
4. **Google Tensor NPU:** Loads the proprietary Google EdgeTPU delegate (`libedgetpu_delegate.so`).
5. **GPU Acceleration Fallback:** If vendor NPU libraries are absent or reject the model operator graph, the runtime instantiates `TfLiteVulkanDelegate` for hardware acceleration.
6. **CPU SIMD Fallback:** If GPU compilation fails, the engine falls back to `TfLiteXNNPackDelegate`, enabling multi-threaded ARM NEON, DotProd, and FP16 vector instructions.

#### 2.4.2 Silent Fallback Detection & Transparency Engine

A notorious flaw in mobile AI benchmarking is **silent CPU fallback**: when a vendor NPU delegate encounters an unsupported operator (e.g., custom GELU, SwiGLU, LayerNorm, or non-standard quantization), the runtime frequently falls back to CPU execution without throwing an error. This artificially pollutes NPU benchmarks by measuring CPU performance under the guise of NPU acceleration.

The suite prevents this distortion using a multi-stage fallback detection engine:

```
[LiteRT Model Execution]
           |
           +---> 1. Intercept Delegate Return Status & Graph Partitioning Logs
           |
           +---> 2. Introspect TfLiteNode Delegate Pointer Assignments
           |
           +---> 3. Real-Time Telemetry Correlation:
                     - Did CPU cluster utilization jump > 40%?
                     - Did SoC/NPU power rail remain flat?
           |
           v
+---------------------------------------------------------------------------------------+
| Verdict Determination:                                                                |
| - DELEGATE_HARDWARE_ACCELERATED (100% NPU Graph Execution)                            |
| - DELEGATE_PARTIAL_FALLBACK (e.g. 78% NPU, 22% CPU Operators)                         |
| - DELEGATE_SILENT_CPU_FALLBACK (Flagged as Invalid NPU Run; CPU Fallback Warning)   |
+---------------------------------------------------------------------------------------+
```

1. **Graph Partitioning Introspection:** Post delegate registration, the engine inspects the compiled `TfLiteInterpreter` node execution graph. Each `TfLiteNode` pointer is audited to confirm whether it is bound to the vendor delegate pointer or mapped to the default CPU kernel.
2. **Telemetry Correlation Heuristics:** During inference execution, native telemetry monitors per-cluster CPU thread activity and battery discharge wattage. If an NPU test reports high CPU thread utilization accompanied by low NPU rail energy, the result is flagged with `DELEGATE_SILENT_CPU_FALLBACK`.
3. **Execution Metadata Provenance:** Benchmark results record explicit hardware execution provenance:
   ```json
   "execution_provenance": {
     "requested_delegate": "NPU_QUALCOMM_QNN",
     "actual_delegate": "NPU_QUALCOMM_QNN",
     "npu_operator_coverage_percent": 100.0,
     "fallback_detected": false,
     "quantization": "INT8_SYMMETRIC",
     "model_id": "mobilenet_v4_medium"
   }
   ```

---

### 2.5 Persistence Architecture: Room SQLite WAL & Proto DataStore

#### 2.5.1 Room Database & SQLite WAL Configuration

High-frequency telemetry logging during a 30-minute stress run produces thousands of time-series samples. Standard SQLite configurations lock the entire database file during writes, causing severe frame drops in Compose chart rendering.

The suite addresses this with an optimized Write-Ahead Logging (WAL) configuration:

```kotlin
// Database creation and pragma optimization
@Database(
    entities = [
        BenchmarkRunEntity::class,
        BenchmarkTelemetrySampleEntity::class,
        DeviceProfileEntity::class,
        HealthRecordEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(RoomTypeConverters::class)
abstract class BenchmarkDatabase : RoomDatabase() {
    abstract fun benchmarkRunDao(): BenchmarkRunDao
    abstract fun telemetryDao(): TelemetryDao

    companion object {
        fun buildDatabase(context: Context): BenchmarkDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                BenchmarkDatabase::class.java,
                "benchmark_suite.db"
            )
            .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
            .addCallback(object : Callback() {
                override fun onOpen(db: SupportSQLiteDatabase) {
                    super.onOpen(db)
                    // High-performance SQLite tuning pragmas
                    db.execSQL("PRAGMA synchronous = NORMAL;")
                    db.execSQL("PRAGMA busy_timeout = 5000;")
                    db.execSQL("PRAGMA mmap_size = 268435456;") // 256 MB memory-mapped I/O
                    db.execSQL("PRAGMA temp_store = MEMORY;")
                }
            })
            .build()
        }
    }
}
```

- **WAL Mode (`JournalMode.WRITE_AHEAD_LOGGING`):** Separates database reads and writes into independent OS threads. The Jetpack Compose UI reads historical data and renders 120 FPS charts concurrently while the native benchmark engine appends real-time telemetry into the WAL journal.
- **`PRAGMA synchronous = NORMAL`:** In WAL mode, `NORMAL` synchronization preserves database integrity against app crashes while eliminating costly disk platter syncs on every commit.
- **`PRAGMA mmap_size = 268435456`:** Maps up to 256 MB of the database file directly into process virtual memory, eliminating userspace-kernel context switches during large historical queries.
- **Two-Tier Storage Architecture:**
  - *Transient High-Resolution Telemetry:* Detailed 10 Hz telemetry samples are written to `benchmark_telemetry_samples` with an indexed `run_id`. After report generation, samples are downsampled into percentile distributions ($p_{50}, p_{90}, p_{99}$) to prevent local database bloat.
  - *Permanent Benchmark Metadata:* Stores normalized aggregate scores, environment conditions (ambient temperature, battery level), cryptographic signatures, and device hardware fingerprints.

#### 2.5.2 Jetpack Proto DataStore Architecture

App settings, thermal trip thresholds, UI preferences, and feature configuration flags are stored using Jetpack Proto DataStore instead of legacy `SharedPreferences`:

```protobuf
// Proto definition: core/datastore/src/main/proto/user_preferences.proto
syntax = "proto3";

option java_package = "com.benchmark.suite.core.datastore";
option java_multiple_files = true;

message UserPreferences {
  bool dark_mode_amoled = 1;
  bool allow_cloud_sync = 2;
  float thermal_abort_threshold_celsius = 3;
  bool bypass_environment_warnings = 4;
  string anonymous_device_uuid = 5;
  int32 execution_repeat_count = 6;
  bool auto_export_pdf = 7;
}
```

- **Transactional Safety & Strong Typing:** Serialization is governed by compiled Protobuf schemas, eliminating runtime type casting errors.
- **Thread Confinement:** Writes are non-blocking and execute exclusively on `Dispatchers.IO`. Reads are exposed as immutable Kotlin `Flow<UserPreferences>`, guaranteeing atomic updates without race conditions.
- **Corruption Resilience:** Employs a `CorruptionHandler` that intercepts schema parsing errors, backs up corrupt files, and restores verified default preferences without application crashes.

---

### 2.6 Compilation Targets & Build Configuration

| Build Parameter | Value / Directive | Purpose / Technical Rationale |
| :--- | :--- | :--- |
| `minSdk` | **29** (Android 10.0) | Captures 94%+ of active Android devices; baseline for `ThermalStatus` listeners and `AHardwareBuffer`. |
| `targetSdk` / `compileSdk` | **36** (Android 16) | Enables native 16 KB page alignment compatibility, Predictive Back, and modern ADPF performance hint APIs. |
| **Primary ABI** | `arm64-v8a`, `arm64-v8.2-a+`, `arm64-v9-a` | Optimized with ARM NEON, DotProd, FP16, and SVE2 hardware intrinsics. |
| **Secondary ABI** | `armeabi-v7a` | Available for legacy 32-bit hardware (restricted to subset of CPU/memory tests; Vulkan/LLM gated). |
| **Code Shrinking & R8** | Full R8 mode (`android.enableR8.fullMode=true`) | Aggressive class merging, dead-code elimination, and UniFFI JNI bridge symbol preservation. |
| **16 KB Memory Page Support** | `-z max-page-size=16384` | Meets Google Play mandatory requirement for Android 15/16 16 KB page-size kernel compatibility. |

---

## 3. System Architecture & Modularization

The application is structured according to **Clean Architecture** principles, enforcing strict unidirectional data flow (UDF) across isolated boundaries. Architectural diagrams are detailed in [WORKFLOW.md#10-system-architecture](WORKFLOW.md#10-system-architecture) and [WORKFLOW.md#15-component-diagram](WORKFLOW.md#15-component-diagram).

### 3.1 Clean Architecture Layers

```
+---------------------------------------------------------------------------------------+
|                                  Presentation Layer                                   |
|       Jetpack Compose Screens | ViewModels | UI State Models | Canvas Renderers       |
+---------------------------------------------------------------------------------------+
                                           |
                                [Unidirectional Data Flow]
                                           v
+---------------------------------------------------------------------------------------+
|                                   Domain Layer                                        |
|         Use Cases | Business Rules | Scoring Algorithms | Health Formulas             |
+---------------------------------------------------------------------------------------+
                                           |
                                [Dependency Inversion]
                                           v
+---------------------------------------------------------------------------------------+
|                             Engines & Native Bridge                                   |
|   Benchmark Engine | Hardware Monitors | Native Coordinator (Rust) | AI Engine        |
+---------------------------------------------------------------------------------------+
                                           |
                                           v
+---------------------------------------------------------------------------------------+
|                                    Data Layer                                         |
|    Room DAOs (WAL) | Proto DataStore | KeyStore Manager | Cloud Ingestion Client      |
+---------------------------------------------------------------------------------------+
```

### 3.2 Multi-Module Gradle Topology

To maintain rapid incremental compilation, eliminate cyclic dependencies, and enforce strict architectural isolation, the project is organized into Gradle modules:

```
:app
├── :core:common             (Shared primitives, Result wrappers, Dispatcher providers)
├── :core:designsystem       (Material 3 theme, color tokens, typography, chart components)
├── :core:domain             (Entities, repository interfaces, use case interactors)
├── :core:database           (Room DB, entities, DAOs, WAL configuration, migrations)
├── :core:datastore          (Proto DataStore schemas, preferences repository)
├── :core:nativebridge       (UniFFI bindings, JNI loaders, native ABI wrappers)
├── :core:integrity          (Play Integrity client, Android KeyStore result signing)
├── :engine:benchmark        (Execution orchestrator, test state machine, lifecycle)
├── :engine:monitoring       (ThermalStatus listeners, battery sampler, CPU frequency reader)
├── :engine:ai-analysis      (Root-cause bottleneck engine, rule-based recommendation trees)
├── :engine:reporting        (PDF generation via PdfDocument, CSV/JSON serialization)
├── :feature:dashboard       (Screen 5: System overview, health gauge, quick-run launcher)
├── :feature:benchmarks      (Screen 6: Category selection, custom suite configurator)
├── :feature:execution       (Screens 7, 8, 34: Pre-test checklist, live run, error retry)
├── :feature:results         (Screens 9, 10, 35: Summary card, detail charts, share generator)
├── :feature:categories      (Screens 11-18: Subsystem-specific deep diagnostic screens)
├── :feature:insights        (Screens 19, 20: AI insight engine, upgrade recommendations)
├── :feature:history         (Screens 21, 22: Historical runs, side-by-side comparison)
├── :feature:reports         (Screens 23, 24: Document archive, PDF preview & exporter)
├── :feature:leaderboard     (Screen 25: Verified global community device rankings)
├── :feature:tools           (Screens 26, 27, 28: Hardware info, custom builder, scheduler)
├── :feature:account         (Screens 29-33: Profile, settings, privacy, support, about)
└── :dynamic:heavy-workloads (On-demand Play Feature Delivery: 4K textures, LLM weights)
```

**Module Boundary Rules:**
1. Feature modules depend solely on `:core:*` and engine interfaces exposed by `:core:domain`.
2. Feature modules never depend directly on other feature modules; cross-screen navigation is coordinated via typed deep links and URI contracts handled in `:app`.
3. Heavy test assets (e.g., ray tracing geometry, 1B parameter quantized LLM weights) are isolated in `:dynamic:*` modules delivered on-demand via Play Feature Delivery.

---

### 3.3 Benchmark Execution Lifecycle & Test Contract

Every test workload adheres to an invariant state machine lifecycle (see [WORKFLOW.md#3-benchmark-engine-workflow](WORKFLOW.md#3-benchmark-engine-workflow) and [WORKFLOW.md#12-benchmark-state-diagram](WORKFLOW.md#12-benchmark-state-diagram)):

```
[Describe] ---> [Prepare] ---> [Warmup] ---> [Run Loop] ---> [Score] ---> [Cleanup]
   |                |              |             |              |             |
   +----------------+--------------+-------------+--------------+-------------+---> [On Failure: Abort & Release]
```

```kotlin
// Core test contract interface: core/domain/src/main/kotlin/com/benchmark/suite/core/domain/BenchmarkTestContract.kt
interface BenchmarkTestContract {
    val metadata: TestMetadata

    /** Phase 1: Allocate memory buffers, map files, load shaders/models */
    suspend fun prepare(context: TestExecutionContext)

    /** Phase 2: Prime CPU caches and DVFS governor clocks */
    suspend fun warmup(context: TestExecutionContext)

    /** Phase 3: Execute timing-sensitive workload loop and emit telemetry */
    suspend fun execute(
        context: TestExecutionContext,
        telemetryEmitter: (BenchmarkTelemetrySample) -> Unit
    ): RawTestResult

    /** Phase 4: Compute normalized score, variance, and confidence index */
    fun calculateScore(rawResult: RawTestResult, baseline: ReferenceBaseline): NormalizedScore

    /** Phase 5: Release GPU buffers, unload delegates, clear scratch memory */
    suspend fun cleanup()
}
```

---

### 3.4 Scoring Methodology & Statistical Normalization

1. **Reference Normalization ($Baseline = 1000$):** Raw metrics (instructions per cycle, GFLOPS, memory bandwidth in GB/s, tokens/second) are normalized against a fixed reference hardware baseline (standardized Snapdragon 8 Gen 2 reference platform yielding 1,000 points per category).
2. **Weighted Geometric Mean:** Overall composite scores are calculated using a weighted geometric mean rather than an arithmetic mean, preventing an exceptionally high score in one subsystem from masking severe failure in another:
   $$\text{Composite Score} = \exp\left( \sum_{i=1}^{n} w_i \ln(S_i) \right) \quad \text{where} \quad \sum_{i=1}^{n} w_i = 1.0$$
3. **Category Weighting Distribution:**
   - CPU Architecture: **20%**
   - GPU Graphics & Compute: **20%**
   - NPU & On-Device AI: **15%**
   - Sustained Stability & Thermals: **15%**
   - Memory Subsystem: **10%**
   - Storage Subsystem: **10%**
   - Real-World Workloads (Gaming/Export): **10%**
4. **Statistical Outlier Trimming & Reproducibility:** Each test workload executes a minimum of 5 iterations. The maximum and minimum values are trimmed, and the median is evaluated. If the coefficient of variation ($CV = \frac{\sigma}{\mu}$) exceeds 5%, the harness triggers an automatic cool-down and re-tests to guarantee reproducible results.

---

## 4. Application Screen Catalog (35 Screens)

The user interface comprises 35 distinct screens organized into 7 cohesive functional modules:

| # | Screen Identifier | Functional Group | Architectural Purpose & Core Capabilities |
| :-: | :--- | :--- | :--- |
| **1** | `SplashScreen` | Application Entry | Cold-boot branding, native library loading, schema integrity verification. |
| **2** | `OnboardingScreen` | Application Entry | Product value proposition, permission context, and first-run initialization. |
| **3** | `PermissionRationaleScreen` | Application Entry | Explains rationale for runtime permissions (notifications, post-test alarms, storage). |
| **4** | `HardwareDetectionScreen` | Application Entry | Scans CPU topology, GPU extensions, NPU delegates, display capabilities, and sensors. |
| **5** | `DashboardScreen` | Core Navigation | Primary landing hub: composite health gauge, last run summary, quick-run trigger. |
| **6** | `BenchmarksHubScreen` | Core Navigation | Subsystem test selector (Full Suite, Quick Test, Category Run, Custom Suites). |
| **7** | `PreTestChecklistScreen` | Core Execution | Environment audit: battery $\ge 20\%$, temperature $\le 38^\circ\text{C}$, charger status, background load. |
| **8** | `LiveRunScreen` | Core Execution | Real-time 10 Hz telemetry gauges (FPS, core clocks, thermal ramp, instantaneous power). |
| **9** | `ResultSummaryScreen` | Core Execution | High-level scores, performance tier classification, reproducibility confidence badge. |
| **10** | `ResultDetailScreen` | Core Execution | Interactive time-series charts, thermal decay curves, frame-time histograms, raw metrics. |
| **11** | `CpuBenchmarkScreen` | Subsystem Deep-Dive | Single/multi-core GFLOPS, IPC throughput, core-to-core latency, context switch latency. |
| **12** | `GpuBenchmarkScreen` | Subsystem Deep-Dive | Vulkan rasterization, async compute saturation, ray tracing BVH, mesh shader tests. |
| **13** | `MemoryBenchmarkScreen` | Subsystem Deep-Dive | Sequential/random bandwidth (L1, L2, L3 cache, LPDDR5X RAM), memory latency matrix. |
| **14** | `StorageBenchmarkScreen` | Subsystem Deep-Dive | Sequential & random 4KB read/write IOPS, queue depth scaling ($QD=1\dots32$), UFS decay. |
| **15** | `AiBenchmarkScreen` | Subsystem Deep-Dive | LiteRT LLM tokens/sec, vision classification, NPU fallback verification, energy per token. |
| **16** | `GamingBenchmarkScreen` | Subsystem Deep-Dive | Frame pacing consistency, 1% low FPS, predicted real-world game FPS, touch latency. |
| **17** | `StressTestScreen` | Subsystem Deep-Dive | 15–30 minute endurance loops, thermal throttling slopes, battery drain rate curves. |
| **18** | `DeviceHealthScreen` | Subsystem Deep-Dive | Tri-part health score: battery wear level, storage endurance, thermal dissipation efficiency. |
| **19** | `AiInsightsScreen` | Insight & Diagnostics | Root-cause diagnostic explainer, hardware bottleneck identification, efficiency rankings. |
| **20** | `RecommendationsScreen` | Insight & Diagnostics | Actionable advice: gaming settings, battery optimization, upgrade lifecycle timing. |
| **21** | `HistoryScreen` | Historical & Data | Chronological run log, multi-parameter filtering, performance trend lines over time. |
| **22** | `ComparisonScreen` | Historical & Data | Side-by-side run comparisons or peer-device delta charts across all 22 categories. |
| **23** | `ReportsListScreen` | Historical & Data | Archive of generated PDF, JSON, and CSV diagnostic reports. |
| **24** | `ReportPreviewScreen` | Historical & Data | High-resolution PDF document viewer, print dispatch, and encrypted export sharing. |
| **25** | `LeaderboardScreen` | Community & Global | Verified global device rankings, SoC family distributions, percentile placements. |
| **26** | `DeviceInfoScreen` | Diagnostic Tools | Exhaustive hardware audit: SoC stepping, Vulkan extensions, thermal zones, display panels. |
| **27** | `CustomBuilderScreen` | Diagnostic Tools | Custom benchmark composer: select specific tests, iterations, and thermal constraints. |
| **28** | `SchedulerQueueScreen` | Diagnostic Tools | Configures automated background health scans and off-peak execution queues. |
| **29** | `ProfileScreen` | Account & System | User identity, verified device registrations, achievement badges, cloud sync status. |
| **30** | `SettingsScreen` | Account & System | Theme mode (AMOLED / Light), measurement units, sound effects, run defaults. |
| **31** | `PrivacyDataScreen` | Account & System | Granular telemetry consent, export local data archive, complete database erasure. |
| **32** | `AboutScreen` | Account & System | App version, methodology specification version, open-source licenses, legal notices. |
| **33** | `HelpSupportScreen` | Account & System | Frequently asked questions, test methodology documentation, issue reporting portal. |
| **34** | `RunFailedScreen` | Edge Case & Recovery | Failure root-cause diagnosis (thermal abort, low battery, process killed), retry wizard. |
| **35** | `ShareCardScreen` | Edge Case & Recovery | Visual social share card generator: customizable metrics, theme layouts, QR code links. |

---

## 5. Navigation Architecture & Deep Linking

The application employs Jetpack Navigation Compose with strongly typed routes, enforcing strict back-stack invariants (see [WORKFLOW.md#2-navigation-flow](WORKFLOW.md#2-navigation-flow)).

### 5.1 Graph Topology & Back-Stack Invariants

- **Bottom Navigation Destinations (5 Primary Roots):**
  1. `Dashboard` (`route_dashboard`)
  2. `Benchmarks` (`route_benchmarks`)
  3. `History` (`route_history`)
  4. `Reports` (`route_reports`)
  5. `Profile` (`route_profile`)
- **Linear Run Flow Protection:** During an active benchmark run (`PreTestChecklist` $\to$ `LiveRun` $\to$ `ResultSummary`), the system back button is intercepted by an explicit `BackHandler` presenting a modal cancellation confirmation. The run cannot be terminated accidentally.
- **Persistent Execution Banner:** Navigating away from `LiveRunScreen` keeps the benchmark engine alive in a foreground service. A persistent non-intrusive status banner appears across all screens, allowing one-tap return to the live execution view.
- **Deep-Link Resolution:** Results and reports are exposed via URI contracts (`benchmark://result/{run_id}` and `benchmark://report/{report_id}`). External links (from notifications or shared URLs) resolve directly into `ResultDetailScreen` or `ReportPreviewScreen`.

### 5.2 Adaptive Form Factors & Multi-Window Support

- **Foldables & Tablets:** On displays with width $\ge 600\,\text{dp}$, the bottom navigation bar transforms into a persistent navigation rail. `HistoryScreen`, `ComparisonScreen`, and `ResultDetailScreen` automatically switch to a two-pane list-detail layout (`ListDetailPaneScaffold`).
- **Display Cutouts & Edge-to-Edge:** Full compliance with Android 15 edge-to-edge window insets (`WindowInsetsCompat`), ensuring charts and gauges adapt around camera notches and system navigation bars.

---

## 6. Design System & Visual Specification

### 6.1 Design Principles

- **Dark-First AMOLED Aesthetic:** Default background uses true near-black (`#05070A`) to eliminate OLED display power draw during active benchmarking.
- **Tabular Numeric Stability:** All live metrics, clocks, and percentages use monospace tabular figures (`FontFeatureSettings = "tnum"`) to eliminate layout jitter during high-frequency gauge updates.
- **Accessible Multi-Channel Encoding:** Color is never the sole communicator of state. Every score band and warning combines color with distinctive iconography, text labels, and haptic feedback.

### 6.2 Dark Theme Color Tokens (AMOLED Default)

| Token Identifier | Hex Value | Semantic Application & Contrast |
| :--- | :--- | :--- |
| `background` | `#05070A` | Deep AMOLED canvas; minimizes display power during runs. |
| `surface` | `#10141A` | Primary card surfaces and container backgrounds. |
| `surfaceVariant` | `#1A2029` | Elevated containers, interactive input fields, chips. |
| `outline` | `#2A3340` | Structural dividers, card borders, inactive progress tracks. |
| `primary` | `#22D3EE` | Electric cyan brand accent; key actions, active tab indicators. |
| `onPrimary` | `#00363D` | High-contrast text rendered over primary surfaces. |
| `secondary` | `#A78BFA` | Violet accent; dedicated to AI, NPU, and machine learning metrics. |
| `textPrimary` | `#E6EAF0` | Primary headings, values, and high-emphasis body text ($16.7:1$ contrast). |
| `textSecondary` | `#9AA4B2` | Supporting labels, timestamps, and captions ($7.3:1$ contrast). |
| `success` | `#34D399` | Emerald green; indicates excellent scores and stable thermal state. |
| `warning` | `#FBBF24` | Amber; indicates moderate performance, rising heat, or battery warnings. |
| `danger` | `#F87171` | Coral red; flags thermal throttling, critical battery, or test failures. |

### 6.3 Light Theme Color Tokens

| Token Identifier | Hex Value | Semantic Application & Contrast |
| :--- | :--- | :--- |
| `background` | `#F6F8FB` | Light neutral canvas for daytime legibility. |
| `surface` | `#FFFFFF` | Clean white card surfaces. |
| `surfaceVariant` | `#E2E8F0` | Subtle elevated card containers and input backgrounds. |
| `outline` | `#CBD5E1` | Borders and dividers. |
| `primary` | `#0E7490` | Deep cyan brand accent ($5.4:1$ contrast on surface). |
| `onPrimary` | `#FFFFFF` | Crisp white text on primary buttons. |
| `secondary` | `#6D28D9` | Deep violet accent for AI and specialized metrics. |
| `textPrimary` | `#0F172A` | Slate black primary text ($16.8:1$ contrast on background). |
| `textSecondary` | `#475569` | Muted slate secondary text ($7.6:1$ contrast on surface). |
| `success` | `#047857` | Forest green success indicator. |
| `warning` | `#B45309` | Dark amber warning indicator ($5.0:1$ contrast). |
| `danger` | `#B91C1C` | Crimson danger indicator ($6.5:1$ contrast). |

### 6.4 WCAG 2.1 Contrast Verification

All token combinations are mathematically verified to exceed **WCAG 2.1 Level AA** standards (minimum $4.5:1$ for normal text, $3.0:1$ for large text/graphical elements):
- Dark Theme `textPrimary` on `background`: **$16.7:1$** (Passes AAA)
- Dark Theme `primary` on `surface`: **$10.2:1$** (Passes AAA)
- Dark Theme `warning` on `surface`: **$8.9:1$** (Passes AAA)
- Light Theme `textPrimary` on `background`: **$16.8:1$** (Passes AAA)
- Light Theme `primary` on `surface`: **$5.4:1$** (Passes AA)

### 6.5 Semantic Color Rules & Visualization Guidelines

- **Standardized Score Tiers:**
  - *Tier 1 (Elite):* $\ge 900$ points $\to$ `success` (Emerald Green) + "Elite" badge.
  - *Tier 2 (Good):* $700 - 899$ points $\to$ `primary` (Electric Cyan) + "Good" badge.
  - *Tier 3 (Fair):* $500 - 699$ points $\to$ `warning` (Amber) + "Fair" badge.
  - *Tier 4 (Poor):* $< 500$ points $\to$ `danger` (Coral Red) + "Needs Attention" badge.
- **Thermal Heat Ramp:** Cold blue ($< 30^\circ\text{C}$) $\to$ Green ($30–37^\circ\text{C}$) $\to$ Amber ($38–43^\circ\text{C}$) $\to$ Orange ($44–48^\circ\text{C}$) $\to$ Red ($> 48^\circ\text{C}$). Restricted exclusively to temperature visualizations.
- **Chart Data Series Invariance:** When comparing multiple runs or devices, data series follow an immutable palette order (`primary`, `secondary`, `warning`, `success`), using dashed versus solid strokes to maintain clarity for color-blind users.

### 6.6 Typography, Spacing, Surface Geometry & Motion

- **Typography Scale:** System sans-serif for UI titles; tabular-figure monospace for live numeric readouts. Scale follows Material 3: Display 32 sp, Headline 24 sp, Title 20 sp, Body 16 sp, Label 12 sp.
- **8-Point Spacing Grid:** UI spacing conforms to a rigid 4/8-point grid: 4 dp (tight padding), 8 dp (standard elements), 16 dp (screen margins), 24 dp (card section padding), 32 dp (major module separation).
- **Surface Geometry:** 12 dp rounded corners for standard metric cards; 20 dp for bottom sheets; full pills for status badges and chips.
- **Motion & Frame-Rate Guidelines:** Standard transitions use 150–300 ms cubic ease-out curves. **Crucial measurement rule:** All decorative UI animations and particle effects are suspended during `LiveRunScreen` execution to eliminate GPU contention.

### 6.7 Accessibility & Inclusive Design

- Complete Android TalkBack screen-reader descriptions for all charts via custom Compose accessibility semantics (`contentDescription` summarizes min, max, median, and throttling trends).
- Dynamic Type support scaling seamlessly up to 200% font scale without text truncation or layout overlap.
- Touch target sizes maintain an absolute minimum bounding box of $48\times48\,\text{dp}$.

### 6.8 Core Reusable Component Catalog

1. `ScoreGauge`: Circular SVG canvas arc displaying composite score, tier badge, and animated sweep.
2. `MetricTile`: Modular card showing subsystem score, delta comparison, and peak vs. sustained indicators.
3. `DecayCurveChart`: Real-time canvas line chart plotting frequency, FPS, and temperature decay over elapsed time.
4. `FrameTimeHistogram`: Frequency-distribution bucket chart illustrating frame pacing jitter and 1% lows.
5. `ThermalHeatmap`: 2D spatial representation of device surface temperatures and hot spots.
6. `ChecklistRow`: Status indicator row used in pre-test audits (icon, title, status chip, action button).
7. `ExecutionBanner`: Persistent compact banner displayed when navigating away from an active run.

---

## 7. Performance Engineering & Measurement Integrity

### 7.1 Observer Effect Minimization (Measurement Integrity)

A benchmark that perturbs the device under test produces distorted measurements. The platform implements rigorous safeguards:

| Distortion Risk | Engineering Mitigation |
| :--- | :--- |
| **JVM Garbage Collection Pauses** | Core timing loops run exclusively in native Rust; zero object allocations in hot loops. |
| **UI Rendering CPU Theft** | UI telemetry state updates are throttled to 10 Hz during live runs; gauges use reusable Canvas paths. |
| **Dynamic Voltage/Frequency Spikes** | Warmup loops prime caches and CPU governors before recording timing metrics. |
| **Thermal Carryover Contamination** | Mandatory cool-down periods enforced between heavy test suites until battery temp $\le 36^\circ\text{C}$. |
| **Wall-Clock Drift & NTP Adjustments** | Timing loops exclusively employ monotonic clocks (`CLOCK_MONOTONIC_RAW` in Rust). |
| **Background Thread Competition** | Worker threads register with the Android Dynamic Performance Framework (ADPF) Performance Hint API. |

### 7.2 Strict Performance Budgets

| Metric | Budget Constraint | Measurement Tooling / Verification |
| :--- | :--- | :--- |
| **Cold Startup Time** | $< 800\,\text{ms}$ to interactive frame | Measured via Android Macrobenchmark suite (`StartupTimingMetric`). |
| **UI Frame Jank** | $< 1.0\%$ jank frames on 120 Hz displays | Verified via `FrameTimingMetric` across all non-run screens. |
| **Idle Memory Footprint** | $< 120\,\text{MB}$ Resident Set Size (RSS) | Measured via Android Studio Memory Profiler. |
| **Peak Run Memory** | $< 350\,\text{MB}$ (excluding AI/LLM models) | Enforced via explicit buffer pooling and native heap caps. |
| **Base APK Size** | $< 28\,\text{MB}$ download size | Achieved via R8 full-mode shrinking, WebP assets, and ABI splits. |
| **Database History Query** | $< 50\,\text{ms}$ for latest 1,000 runs | Indexed SQLite queries operating over memory-mapped WAL storage. |
| **Background Idle Drain** | $< 0.8\%$ battery consumption per 24h | Constraint-driven WorkManager triggers with zero ongoing wake locks. |

### 7.3 Budget Enforcement Architecture

- **Baseline Profiles:** Baseline profile definitions compiled into the APK pre-compile critical execution paths (Compose startup, Room DAO lookups, navigation routes), eliminating runtime JIT compilation overhead during initial launch.
- **Continuous Macrobenchmarks:** CI/CD regression pipelines execute automated Macrobenchmark runs on physical device farms on every commit to enforce frame budgets.

---

## 8. Data Governance, Privacy & Cryptographic Security

### 8.1 Local-First Data Lifecycle

- All raw sensor telemetry, database records, and generated PDF reports reside strictly within private application storage (`/data/user/0/com.benchmark.suite/`).
- No personal identifiers (IMEI, phone number, Google Account ID, advertising ID) are ever queried or recorded.
- Telemetry exports generate a random, locally generated installation UUID that can be reset by the user at any time.

### 8.2 Privacy Guardrails & Regulatory Compliance

- **Explicit Opt-In:** Cloud leaderboard submissions and peer comparisons require affirmative, unbundled user consent.
- **Data Minimization:** Uploaded result bundles contain only normalized scores, SoC model strings, OS version, and cryptographic attestation signatures.
- **GDPR & India DPDP Compliance:** One-tap "Export All Data" (producing a verified JSON archive) and "Delete All Data" (executing complete SQLite and DataStore erasure) accessible in `PrivacyDataScreen`.

### 8.3 Cryptographic Integrity & Anti-Cheating Architecture

To ensure the integrity of the global leaderboard and eliminate vendor benchmark cheating, results undergo multi-layered cryptographic verification (see [FEATURES.md#category-17-fair-play--result-integrity](FEATURES.md#category-17-fair-play--result-integrity)):

```
[Local Benchmark Run Completed]
              |
              v
[Result Bundle Payload Serialized] (Scores, Clocks, Thermal Decay, SoC Stepping)
              |
              v
[Hardware Key Attestation] (Android KeyStore generates ECDSA P-256 signature)
              |
              v
[Play Integrity Token Attached] (Verifies unmodified Google Play binary & device lock)
              |
              v
[Secure HTTPS TLS 1.3 Upload with Certificate Pinning]
              |
              v
[Backend Verification Engine] (Validates signature chain, statistical sanity, vendor whitelist)
```

1. **Hardware-Backed Key Attestation:** The result payload is signed using an ECDSA P-256 key pair generated inside the device's hardware-isolated Secure Element / StrongBox Keymaster. The public key certificate chain is validated by the backend to verify the signature originated from an authentic Android hardware key.
2. **Play Integrity API Integration:** Leaderboard submissions require a valid Google Play Integrity token confirming the app binary is unmodified, installed from Google Play, and running on a certified device passing CTS/basic integrity.
3. **Cheat & Whitelist Detection Engine:**
   - Detects artificial thermal governor override daemons (e.g., vendor processes pinning big CPU cores to maximum clock upon detecting the benchmark package name).
   - Monitors clock frequencies during the pre-test idle checklist. If core clocks peg to maximum frequency while CPU load is zero, a `SUSPECTED_VENDOR_BENCHMARK_BOOST` flag is stamped onto the result.
   - Runs randomized micro-kernel timing loops disguised under variable package signatures to cross-examine whether the device delivers identical IPC when the benchmark package is unannounced.

---

## 9. Backend Services & Cloud Ingestion (Phase 2+)

While the application is fundamentally local-first, an optional cloud backend facilitates the verified global leaderboard, peer percentiles, and public share links.

### 9.1 Microservice Topology

```
+---------------------------------------------------------------------------------------+
|                          Cloudflare Edge CDN / WAF Gateway                            |
+---------------------------------------------------------------------------------------+
                                           |
                              [TLS 1.3 / Certificate Pinning]
                                           v
+---------------------------------------------------------------------------------------+
|                        Ingestion API (Rust / Axum Framework)                          |
|         - Request validation & rate limiting (Redis token bucket)                     |
|         - Payload schema verification & deserialization                               |
+---------------------------------------------------------------------------------------+
                                           |
                                           v
+---------------------------------------------------------------------------------------+
|                       Cryptographic Verification Worker Service                       |
|         - Play Integrity token validation via Google APIs                             |
|         - Hardware Key Attestation ECDSA certificate chain verification               |
|         - Statistical anomaly & cheat detection analysis                              |
+---------------------------------------------------------------------------------------+
                         |                                           |
              [Valid Verified Result]                     [Aggregate Queries]
                         v                                           v
+------------------------------------+      +-------------------------------------------+
| PostgreSQL Cluster (Partitioned)   |      | Redis Cache Layer                         |
| - Results, Devices, Verification   |      | - Leaderboard sorted sets (ZSET)          |
| - S3-Compatible Object Store (PDFs)|      | - Real-time SoC percentile distributions  |
+------------------------------------+      +-------------------------------------------+
```

- **Axum High-Throughput Ingestion Service:** Written in native Rust, handling high-concurrency result submissions with sub-millisecond serialization overhead.
- **PostgreSQL Partitioned Storage:** Benchmark result tables are partitioned by calendar month and SoC architecture family, maintaining lightning-fast query response times across tens of millions of records.
- **Redis Cache Layer:** Global leaderboards and peer percentiles are computed asynchronously and served directly from Redis sorted sets (`ZSET`), offloading relational database infrastructure.

---

## 10. Quality Assurance & Verification Matrix

### 10.1 Multi-Tier Testing Pyramid

```
                /  End-to-End & Device Lab  \       <- Physical SoC Matrix, Soak Tests
               /-----------------------------\
              /      Compose UI Tests         \     <- Screenshot Tests, Font Scales
             /---------------------------------\
            /     Integration & Engine Tests    \   <- Mock Monitors, Deterministic Workloads
           /-------------------------------------\
          /           Unit Tests (70%+)           \ <- Scoring Math, Norm Formulas, Rust Tests
         +-----------------------------------------+
```

- **Unit Testing Layer:**
  - Scoring mathematics, geometric mean calculations, statistical outlier filtering, and confidence score algorithms.
  - Rust unit tests (`cargo test`) verifying memory buffer safety, SIMD matrix multiplication accuracy, and error handling.
- **Integration Testing Layer:**
  - Mocked hardware monitor engines verifying state machine transitions under simulated thermal throttling, battery dips, and process interruptions.
  - Room database migration tests verifying schema evolution without data loss.
- **UI & Screenshot Regression Tests:**
  - Paparazzi screenshot testing framework validating all 35 screens across both AMOLED Dark and Light themes, phone and tablet form factors, and $100\%$ through $200\%$ dynamic font scales.
- **Reproducibility Verification:**
  - Automated continuous regression runs on physical hardware: 10 consecutive executions must exhibit a coefficient of variation ($CV$) strictly below $3.0\%$ on reference hardware.

### 10.2 Device Lab Matrix & Soak Testing

Testing covers an extensive matrix of reference mobile platforms:
- **Qualcomm Snapdragon:** 8 Gen 3, 8 Gen 2, 7+ Gen 2, 6 Gen 1.
- **MediaTek Dimensity:** 9300, 9200, 8300, 7200.
- **Samsung Exynos:** 2400, 2200, 1480.
- **Google Tensor:** G4, G3, G2.
- **Form Factors:** Standard slabs, foldables (Samsung Galaxy Z Fold/Flip series), tablets, and Android 16 developer virtual devices.

---

## 11. Delivery & Release Engineering

### 11.1 CI/CD Automation & Regression Gates

The deployment pipeline is automated via GitHub Actions and Fastlane:
1. **Commit Validation:** Runs Spotless code formatting, Kotlin linter (`detekt`), Rust linter (`cargo clippy`), and static analysis (`Android Lint`).
2. **Automated Unit & Native Test Suite:** Executes all JVM unit tests and native Rust unit tests across `x86_64` and `aarch64` targets.
3. **Macrobenchmark & Profiling Gate:** Automatically provisions reference hardware on a private device farm, running cold startup and sustained frame-timing checks. Any PR causing a $> 5\%$ regression in startup time or frame drops is automatically blocked.
4. **Binary Assembly:** Assembles signed Android App Bundles (AAB) with R8 full minification, producing per-ABI dynamic feature splits.

### 11.2 Release Distribution & Hot-Patching Strategy

- **Methodology Versioning:** Every benchmark result stores an immutable methodology version tag (`methodology_version = "2026.1"`). When scoring weights or algorithmic kernels are updated, the version increments, guaranteeing that old and new benchmark scores are never mixed or compared directly.
- **Dynamic Feature Delivery:** Heavy ray-tracing scenes and large AI models are downloaded dynamically on-demand post-install via Google Play Feature Delivery, keeping initial download size under 28 MB.
- **Emergency Test Kill Switch:** Feature-flag configuration served via Firebase Remote Config / Proto DataStore allows remote, immediate disabling of a specific faulty micro-test on problematic device models without requiring a full store release.

---

## 12. Implementation Roadmap & Risk Management

The rollout strategy is structured into four milestone phases derived directly from priority, technical difficulty, and architectural dependencies (see [FEATURES.md#implementation-roadmap](FEATURES.md#implementation-roadmap)).

### 12.1 Phased Execution Schedule

```
Phase 1: MVP Core (Launch)       [22 Features]  -> Engine core, quick/full runs, health gauges, reports
Phase 2: Differentiation Moat    [60 Features]  -> Insight engine, thermal decay, gaming FPS, AI benchmarks
Phase 3: Deep Technical Mastery  [23 Features]  -> Ray tracing, mesh shaders, on-device RAG, Wi-Fi 7 / 5G
Phase 4: Expansion & Enterprise  [53 Features]  -> Fleet management, foldables, stylus, CLI automation
```

| Phase | Strategic Focus | Feature Deliverables & Milestones | Target Status |
| :--- | :--- | :--- | :--- |
| **Phase 1: MVP Core** | Engine Foundation & Essential Diagnostics | 22 Must-Have features: Core Rust engine, quick/full test execution, SQLite WAL persistence, pre-test checklist, frame pacing analyzer, battery health correlation, PDF/CSV export. | **Ready for Rollout** |
| **Phase 2: Differentiation** | Insight Layer & Trust Moat | 60 features: Thermal throttling decay curve, predicted gaming FPS, LiteRT NPU fallback detection, cheat/whitelist detector, verified global leaderboard, root-cause explainer. | **In Active Development** |
| **Phase 3: Deep Technical** | Advanced Microarchitecture & Graphics | 23 features: Vulkan ray tracing BVH, mesh shaders, async compute saturation, on-device RAG, core-to-core latency matrix, Wi-Fi 7 / 5G URLLC latency. | **Scheduled** |
| **Phase 4: Expansion** | Enterprise & Form Factors | 53 features: Foldable hinge durability monitor, fleet dashboard, headless ADB/CLI automation, Wear OS companion, post-quantum crypto benchmark. | **Roadmap** |

### 12.2 Key Performance Indicators (KPIs)

- **Measurement Reproducibility:** Median Coefficient of Variation ($CV$) $< 3.5\%$ across identical hardware runs.
- **First-Run Completion Rate:** $> 92\%$ of installed users successfully complete a benchmark run on first launch.
- **Diagnostic Engagement:** $> 40\%$ of users explore detailed AI insights and recommendations post-run.
- **Technical Stability:** Crash-free session rate exceeding $99.9\%$; ANR rate $< 0.02\%$.

### 12.3 Technical Risk Register & Mitigation Strategy

| Identified Risk | Severity | Engineering Mitigation Strategy |
| :--- | :---: | :--- |
| **OEM Throttling & Whitelisting Manipulation** | High | Integrate dynamic cheat detection; verify clocks against background baselines; sign all result payloads via hardware Key Attestation. |
| **Fragmented Vendor NPU Drivers** | High | Implement strict LiteRT vendor priority cascade; detect and flag silent CPU fallbacks; log explicit hardware execution provenance. |
| **Device Overheating During Stress Tests** | High | Enforce hard thermal cutoff limits ($48^\circ\text{C}$ battery / $85^\circ\text{C}$ junction); trigger automatic cool-down halts before hardware thermal protection trips. |
| **Methodology Score Drift Across Updates** | Medium | Stamp an immutable methodology version on all results; maintain strict database isolation between conflicting score iterations. |
| **Large Scope Scale (158 Features)** | Medium | Modular Clean Architecture Gradle boundaries; strict phased delivery; decoupled native kernel contracts allowing independent component shipping. |
