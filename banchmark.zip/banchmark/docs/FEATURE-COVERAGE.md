# BenchSuite — Feature Coverage (158)

Scan of `app/src/main/java/com/benchsuite/app/engine/**` and `native/bench-core/src/**` against `FEATURES.md`.

## Summary

| Phase | Total | Wired | Engine/Native only | Missing |
|---|---|---|---|---|
| Phase 1 | 22 | 7 | 14 | 1 |
| Phase 2 | 60 | 0 | 19 | 41 |
| Phase 3 | 23 | 0 | 14 | 9 |
| Phase 4 | 53 | 0 | 11 | 42 |
| **Total** | **158** | **7** | **58** | **93** |

## Full table

| ID | Feature | Phase | Status | Current / proposed path |
|---|---|---|---|---|
| 1.1 | Scheduler Efficiency Profiler | 2 | Engine only | engine/phase2/system/SchedulerEfficiencyProfiler.kt |
| 1.2 | Context Switch Storm Benchmark | 1 | Native only | native/bench-core/src/engine/context_switch.rs |
| 1.3 | Interrupt Latency Analyzer | 3 | Engine only | engine/phase3/cpu/InterruptLatencyAnalyzer.kt<br>native/bench-core/src/engine/phase3_raytracing.rs<br>native/bench-core/src/engine/phase3_meshshader.rs |
| 1.4 | Branch Prediction Stress Test | 4 | Missing | `engine/phase4/cpu/BranchPredictionStressTest.kt` |
| 1.5 | Sustained Performance Decay Curve | 1 | Engine only | engine/stability/SustainedDecayEngine.kt |
| 1.6 | Big-Core Reservation Efficiency | 3 | Engine only | engine/phase3/cpu/InterruptLatencyAnalyzer.kt |
| 1.7 | Memory Bandwidth Bottleneck Detector | 2 | Engine only | engine/phase2/system/SchedulerEfficiencyProfiler.kt |
| 1.8 | Post-Quantum Cryptography Benchmark | 4 | Native only | native/bench-core/src/engine/phase4_pqc.rs |
| 1.9 | Cache Hierarchy Latency Mapper | 2 | Missing | `engine/phase2/cpu/CacheHierarchyLatencyMapper.kt` |
| 1.10 | SIMD / NEON / SVE2 Throughput Profiler | 2 | Missing | `engine/phase2/cpu/SimdNeonSve2ThroughputProfiler.kt` |
| 1.11 | Core-to-Core Latency Matrix | 4 | Missing | `engine/phase4/cpu/CoreToCoreLatencyMatrix.kt` |
| 2.1 | Ray Tracing Quality-Performance Tradeoff Analyzer | 3 | Native only | native/bench-core/src/engine/phase3_raytracing.rs |
| 2.2 | Variable Rate Shading (VRS) Efficiency Benchmark | 2 | Missing | `engine/phase2/gpu/VariableRateShadingEfficiencyBenchmark.kt` |
| 2.3 | GPU Memory Compression Ratio Tester | 4 | Missing | `engine/phase4/gpu/GpuMemoryCompressionRatioTester.kt` |
| 2.4 | Mesh Shader Pipeline Benchmark | 3 | Native only | native/bench-core/src/engine/phase3_meshshader.rs |
| 2.5 | GPU Async Compute Saturation Test | 3 | Native only | native/bench-core/src/engine/phase3_async_compute.rs |
| 2.6 | Shader Compilation Stutter Profiler | 2 | Missing | `engine/phase2/gpu/ShaderCompilationStutterProfiler.kt` |
| 2.7 | GPU Frequency Residency Tracker | 2 | Missing | `engine/phase2/gpu/GpuFrequencyResidencyTracker.kt` |
| 2.8 | Vulkan Feature & Extension Scanner | 1 | Native only | native/bench-core/src/engine/vulkan_scan.rs |
| 2.9 | Fillrate & Texture Bandwidth Analyzer | 4 | Missing | `engine/phase4/gpu/FillrateTextureBandwidthAnalyzer.kt` |
| 3.1 | LLM Context Window Efficiency Curve | 2 | Engine only | engine/phase2/ai/LiteRtNpuEngine.kt |
| 3.2 | Multi-Modal AI Pipeline Benchmark | 2 | Missing | `engine/phase2/ai/MultiModalAiPipelineBenchmark.kt` |
| 3.3 | AI Accuracy-Performance Pareto Frontier | 2 | Missing | `engine/phase2/ai/AiAccuracyPerformanceParetoFrontier.kt` |
| 3.4 | Stable Diffusion Iteration-Time Consistency | 2 | Missing | `engine/phase2/ai/StableDiffusionIterationTimeConsistency.kt` |
| 3.5 | NPU Thermal Throttling Characterization | 1 | Missing | `engine/phase1/ai/NpuThermalThrottlingCharacterization.kt` |
| 3.6 | AI Model Load-Time Benchmark | 2 | Missing | `engine/phase2/ai/AiModelLoadTimeBenchmark.kt` |
| 3.7 | Speculative Decoding Efficiency Test | 4 | Missing | `engine/phase4/ai/SpeculativeDecodingEfficiencyTest.kt` |
| 3.8 | Federated Learning Node Benchmark | 4 | Missing | `engine/phase4/ai/FederatedLearningNodeBenchmark.kt` |
| 3.9 | NPU Delegate Fallback Detector | 2 | Engine only | engine/phase2/ai/LiteRtNpuEngine.kt |
| 3.10 | On-Device RAG Benchmark | 3 | Missing | `engine/phase3/ai/OnDeviceRagBenchmark.kt` |
| 3.11 | Speech Recognition Real-Time Factor | 2 | Missing | `engine/phase2/ai/SpeechRecognitionRealTimeFactor.kt` |
| 3.12 | AI Energy-per-Token Meter | 2 | Engine only | engine/phase2/ai/LiteRtNpuEngine.kt |
| 4.1 | Storage Fragmentation Simulator | 2 | Missing | `engine/phase2/storage/StorageFragmentationSimulator.kt` |
| 4.2 | AI Workload Storage Pattern Benchmark | 2 | Missing | `engine/phase2/storage/AiWorkloadStoragePatternBenchmark.kt` |
| 4.3 | Memory Pressure Cascade Test | 1 | Native only | native/bench-core/src/engine/memory.rs |
| 4.4 | ZRAM/Swap Efficiency Analyzer | 2 | Missing | `engine/phase2/storage/ZramSwapEfficiencyAnalyzer.kt` |
| 4.5 | UFS Controller Thermal Throttling Test | 3 | Missing | `engine/phase3/storage/UfsControllerThermalThrottlingTest.kt` |
| 4.6 | Random IOPS Queue-Depth Scaling | 1 | Native only | native/bench-core/src/engine/storage.rs |
| 4.7 | Storage Endurance & Wear Estimator | 3 | Missing | `engine/phase3/storage/StorageEnduranceWearEstimator.kt` |
| 4.8 | App Install & DEX Optimization Time | 4 | Missing | `engine/phase4/storage/AppInstallDexOptimizationTime.kt` |
| 4.9 | Small-File Metadata Stress | 4 | Missing | `engine/phase4/storage/SmallFileMetadataStress.kt` |
| 5.1 | WiFi 7 MLO Consistency Benchmark | 3 | Engine only | engine/phase3/network/Wifi7MloBenchmark.kt |
| 5.2 | 5G Advanced URLLC Latency Profiler | 3 | Engine only | engine/phase3/network/Urllc5gLatencyProfiler.kt |
| 5.3 | Satellite SOS Time-to-Rescue Benchmark | 2 | Missing | `engine/phase2/network/SatelliteSosTimeToRescueBenchmark.kt` |
| 5.4 | UWB Precision & Security Benchmark | 3 | Engine only | engine/phase3/network/UwbPrecisionBenchmark.kt |
| 5.5 | eSIM Profile Switching Speed Test | 2 | Missing | `engine/phase2/network/EsimProfileSwitchingSpeedTest.kt` |
| 5.6 | Bluetooth LE Audio Latency & Quality Benchmark | 4 | Missing | `engine/phase4/network/BluetoothLeAudioLatencyQualityBenchmark.kt` |
| 5.7 | Network Handover Latency Profiler | 3 | Engine only | engine/phase3/network/Wifi7MloBenchmark.kt |
| 5.8 | Bufferbloat & Loaded Latency Test | 2 | Missing | `engine/phase2/network/BufferbloatLoadedLatencyTest.kt` |
| 5.9 | Cellular Modem Thermal & Power Profile | 4 | Missing | `engine/phase4/network/CellularModemThermalPowerProfile.kt` |
| 5.10 | Wi-Fi Roaming Stability Test | 4 | Missing | `engine/phase4/network/WiFiRoamingStabilityTest.kt` |
| 6.1 | End-to-End Touch Latency Profiler | 2 | Engine only | engine/phase2/display/TouchLatencyProfiler.kt |
| 6.2 | PWM Dimming Frequency Detector | 2 | Engine only | engine/phase2/display/PwmDimmingDetector.kt |
| 6.3 | HDR Tone Mapping Quality Analyzer | 3 | Engine only | engine/phase3/display/HdrToneMappingAnalyzer.kt |
| 6.4 | Display Uniformity & Color Accuracy Map | 3 | Engine only | engine/phase3/display/HdrToneMappingAnalyzer.kt |
| 6.5 | Variable Refresh Rate (VRR) Transition Smoothness | 4 | Missing | `engine/phase4/display/VariableRefreshRateTransitionSmoothness.kt` |
| 6.6 | Stylus Latency & Pressure Precision Benchmark | 4 | Missing | `engine/phase4/display/StylusLatencyPressurePrecisionBenchmark.kt` |
| 6.7 | Touch Sampling Rate Verifier | 2 | Engine only | engine/phase2/display/TouchLatencyProfiler.kt |
| 6.8 | Peak & Sustained Luminance Curve | 4 | Missing | `engine/phase4/display/PeakSustainedLuminanceCurve.kt` |
| 6.9 | Palm Rejection & Ghost Touch Test | 4 | Missing | `engine/phase4/display/PalmRejectionGhostTouchTest.kt` |
| 7.1 | Tap-to-Tone Latency Benchmark | 2 | Missing | `engine/phase2/audio/TapToToneLatencyBenchmark.kt` |
| 7.2 | Haptic Frequency Response Analyzer | 4 | Missing | `engine/phase4/audio/HapticFrequencyResponseAnalyzer.kt` |
| 7.3 | Spatial Audio Head Tracking Latency | 4 | Engine only | engine/phase4/audio/SpatialAudioHeadTracker.kt |
| 7.4 | Active Noise Cancellation (ANC) Effectiveness Profiler | 4 | Engine only | engine/phase4/audio/SpatialAudioHeadTracker.kt |
| 7.5 | Speaker Frequency Response & Distortion | 4 | Missing | `engine/phase4/audio/SpeakerFrequencyResponseDistortion.kt` |
| 7.6 | Microphone Noise Floor & Dynamic Range | 4 | Missing | `engine/phase4/audio/MicrophoneNoiseFloorDynamicRange.kt` |
| 8.1 | Shutter-to-Saved Latency Benchmark | 2 | Engine only | engine/phase2/camera/CameraIspBenchmark.kt |
| 8.2 | Burst Capture Sustainability Test | 2 | Engine only | engine/phase2/camera/CameraIspBenchmark.kt |
| 8.3 | Night Mode Processing Latency | 2 | Missing | `engine/phase2/camera/NightModeProcessingLatency.kt` |
| 8.4 | Video Stabilization Quality Analyzer | 3 | Missing | `engine/phase3/camera/VideoStabilizationQualityAnalyzer.kt` |
| 8.5 | RAW Processing Pipeline Benchmark | 4 | Missing | `engine/phase4/camera/RawProcessingPipelineBenchmark.kt` |
| 8.6 | Autofocus Acquisition Speed | 4 | Missing | `engine/phase4/camera/AutofocusAcquisitionSpeed.kt` |
| 8.7 | Camera Warm Start & Mode Switch Latency | 2 | Engine only | engine/phase2/camera/CameraIspBenchmark.kt |
| 9.1 | Battery Health-Performance Correlation Engine | 1 | Engine only | engine/telemetry/BatteryHealthEngine.kt |
| 9.2 | Silicon-Carbon Battery Cycle Simulator | 3 | Engine only | engine/phase3/battery/SiliconCarbonBatteryModel.kt |
| 9.3 | Per-App Power Attribution Profiler | 2 | Missing | `engine/phase2/battery/PerAppPowerAttributionProfiler.kt` |
| 9.4 | Wireless Charging Efficiency Benchmark | 4 | Missing | `engine/phase4/battery/WirelessChargingEfficiencyBenchmark.kt` |
| 9.5 | Reverse Wireless Charging Stress Test | 4 | Missing | `engine/phase4/battery/ReverseWirelessChargingStressTest.kt` |
| 9.6 | Screen-On-Time Predictor | 1 | Engine only | engine/telemetry/ScreenOnTimePredictor.kt |
| 9.7 | Wired Charging Curve & Thermal Profiler | 2 | Missing | `engine/phase2/battery/WiredChargingCurveThermalProfiler.kt` |
| 9.8 | Idle Drain & Deep Sleep Efficiency | 2 | Missing | `engine/phase2/battery/IdleDrainDeepSleepEfficiency.kt` |
| 9.9 | Battery Internal Resistance Estimator | 4 | Missing | `engine/phase4/battery/BatteryInternalResistanceEstimator.kt` |
| 10.1 | Surface Temperature Heatmap Generator | 2 | Engine only | engine/phase2/thermal/ThermalStorytellingEngine.kt |
| 10.2 | Active Cooling Efficiency Index | 4 | Missing | `engine/phase4/thermal/ActiveCoolingEfficiencyIndex.kt` |
| 10.3 | Thermal Throttling Prediction Model | 3 | Engine only | engine/phase3/thermal/ThermalPredictionModel.kt |
| 10.4 | Skin Temperature Comfort Index | 2 | Engine only | engine/phase2/thermal/ThermalStorytellingEngine.kt |
| 10.5 | Cool-Down Recovery Time Benchmark | 2 | Engine only | engine/phase2/thermal/ThermalStorytellingEngine.kt |
| 10.6 | Thermal Zone Correlation Map | 4 | Missing | `engine/phase4/thermal/ThermalZoneCorrelationMap.kt` |
| 11.1 | MEMS Sensor Calibration Quality Score | 2 | Missing | `engine/phase2/sensors/MemsSensorCalibrationQualityScore.kt` |
| 11.2 | GNSS Cold-Start Time-to-First-Fix | 2 | Missing | `engine/phase2/sensors/GnssColdStartTimeToFirstFix.kt` |
| 11.3 | Barometric Altimeter Accuracy Test | 4 | Missing | `engine/phase4/sensors/BarometricAltimeterAccuracyTest.kt` |
| 11.4 | Magnetometer Interference Profiler | 4 | Missing | `engine/phase4/sensors/MagnetometerInterferenceProfiler.kt` |
| 11.5 | Gyroscope Drift Test | 4 | Missing | `engine/phase4/sensors/GyroscopeDriftTest.kt` |
| 11.6 | Dual-Frequency GNSS Accuracy Walk Test | 4 | Missing | `engine/phase4/sensors/DualFrequencyGnssAccuracyWalkTest.kt` |
| 12.1 | Predicted Gaming FPS Engine | 2 | Missing | `engine/phase2/gaming/PredictedGamingFpsEngine.kt` |
| 12.2 | Emulator Performance Predictor | 3 | Missing | `engine/phase3/gaming/EmulatorPerformancePredictor.kt` |
| 12.3 | Cloud Gaming Readiness Score | 2 | Missing | `engine/phase2/gaming/CloudGamingReadinessScore.kt` |
| 12.4 | Long Gaming Session Stability Index | 1 | Engine only | engine/stability/GamingStabilityEngine.kt |
| 12.5 | App Launch Time Consistency Benchmark | 2 | Missing | `engine/phase2/gaming/AppLaunchTimeConsistencyBenchmark.kt` |
| 12.6 | Frame Pacing Consistency Analyzer | 1 | Engine only | engine/stability/FramePacingAnalyzer.kt |
| 12.7 | OEM Booster Honesty Check | 2 | Engine only | engine/phase2/fairplay/CheatDetectorEngine.kt |
| 12.8 | Touch-to-Photon Gaming Latency | 3 | Missing | `engine/phase3/gaming/TouchToPhotonGamingLatency.kt` |
| 12.9 | Cold vs Warm Game Launch Time | 4 | Missing | `engine/phase4/gaming/ColdVsWarmGameLaunchTime.kt` |
| 13.1 | Mobile Video Export Time Predictor | 3 | Missing | `engine/phase3/productivity/MobileVideoExportTimePredictor.kt` |
| 13.2 | Code Compilation Speed Benchmark | 4 | Missing | `engine/phase4/productivity/CodeCompilationSpeedBenchmark.kt` |
| 13.3 | Container/Docker Startup Benchmark | 4 | Missing | `engine/phase4/productivity/ContainerDockerStartupBenchmark.kt` |
| 13.4 | PDF Rendering & Annotation Stress Test | 4 | Missing | `engine/phase4/productivity/PdfRenderingAnnotationStressTest.kt` |
| 13.5 | Spreadsheet Calculation Benchmark | 4 | Missing | `engine/phase4/productivity/SpreadsheetCalculationBenchmark.kt` |
| 13.6 | Photo Batch Edit & RAW Export | 4 | Missing | `engine/phase4/productivity/PhotoBatchEditRawExport.kt` |
| 13.7 | Multi-Window & Desktop Mode Workload | 4 | Missing | `engine/phase4/productivity/MultiWindowDesktopModeWorkload.kt` |
| 14.1 | Biometric Unlock Latency & Accuracy Profiler | 2 | Missing | `engine/phase2/security/BiometricUnlockLatencyAccuracyProfiler.kt` |
| 14.2 | Hardware Security Module (HSM) Throughput Test | 4 | Missing | `engine/phase4/security/HardwareSecurityModuleThroughputTest.kt` |
| 14.3 | Side-Channel Leakage Detection | 3 | Missing | `engine/phase3/security/SideChannelLeakageDetection.kt` |
| 14.4 | Integrity & Root Posture Scanner | 2 | Missing | `engine/phase2/security/IntegrityRootPostureScanner.kt` |
| 14.5 | File-Based Encryption Throughput Benchmark | 4 | Missing | `engine/phase4/security/FileBasedEncryptionThroughputBenchmark.kt` |
| 14.6 | Patch Freshness & Exposure Score | 1 | Engine only | engine/analysis/SecurityPatchScanner.kt |
| 15.1 | Hinge Durability Tracker | 3 | Engine only | engine/phase4/foldable/HingeDurabilityTracker.kt |
| 15.2 | Crease Visibility Monitor | 4 | Engine only | engine/phase4/foldable/HingeDurabilityTracker.kt |
| 15.3 | Flex-Mode Transition Latency | 2 | Engine only | engine/phase4/foldable/HingeDurabilityTracker.kt |
| 15.4 | Cover vs Inner Display Parity | 4 | Engine only | engine/phase4/foldable/HingeDurabilityTracker.kt |
| 16.1 | Device Aging Index | 1 | Engine only | engine/analysis/AgingIndexCalculator.kt |
| 16.2 | OS Update Regression Tracker | 2 | Missing | `engine/phase2/longevity/OsUpdateRegressionTracker.kt` |
| 16.3 | Device Health Certificate | 2 | Missing | `engine/phase2/longevity/DeviceHealthCertificate.kt` |
| 16.4 | Remaining Useful Life Predictor | 4 | Engine only | engine/phase4/longevity/RemainingUsefulLifePredictor.kt |
| 17.1 | Benchmark Cheat & Throttle-Bypass Detector | 2 | Engine only | engine/phase2/fairplay/CheatDetectorEngine.kt |
| 17.2 | Signed Result Tamper-Proofing | 2 | Missing | `engine/phase2/fairplay/SignedResultTamperProofing.kt` |
| 17.3 | Environment Normalization Score | 1 | Engine only | engine/telemetry/EnvironmentNormalizer.kt |
| 17.4 | Reproducibility Confidence Score | 1 | Engine only | engine/analysis/ConfidenceScorer.kt |
| 18.1 | Natural-Language Performance Explainer | 1 | Wired | engine/analysis/PerformanceExplainer.kt |
| 18.2 | Bottleneck Root-Cause Engine | 2 | Missing | `engine/phase2/insights/BottleneckRootCauseEngine.kt` |
| 18.3 | Use-Case Fit Score | 1 | Wired | engine/analysis/UseCaseFitCalculator.kt |
| 18.4 | Upgrade Advisor | 2 | Missing | `engine/phase2/insights/UpgradeAdvisor.kt` |
| 18.5 | Peer Percentile Ranking | 2 | Missing | `engine/phase2/insights/PeerPercentileRanking.kt` |
| 18.6 | Performance Forecast Engine | 3 | Missing | `engine/phase3/insights/PerformanceForecastEngine.kt` |
| 18.7 | Anomaly & Regression Alerts | 2 | Missing | `engine/phase2/insights/AnomalyRegressionAlerts.kt` |
| 18.8 | Personalized Optimization Tips | 2 | Missing | `engine/phase2/insights/PersonalizedOptimizationTips.kt` |
| 19.1 | Verified Global Leaderboard | 2 | Engine only | engine/phase2/network/LeaderboardClient.kt |
| 19.2 | Side-by-Side Device Comparison | 1 | Engine only | engine/analysis/DeviceComparisonEngine.kt |
| 19.3 | SoC Family Ranking | 4 | Missing | `engine/phase4/social/SocFamilyRanking.kt` |
| 19.4 | Reviewer Mode | 2 | Missing | `engine/phase2/social/ReviewerMode.kt` |
| 19.5 | Community Heatmap | 4 | Missing | `engine/phase4/social/CommunityHeatmap.kt` |
| 19.6 | Shareable Result Card | 1 | Wired | engine/export/ShareCardRenderer.kt |
| 20.1 | PDF Report Generator | 1 | Wired | engine/export/PdfReportGenerator.kt |
| 20.2 | JSON & CSV Raw Export | 1 | Wired | engine/export/RawDataExporter.kt |
| 20.3 | Reviewer Report Template | 4 | Missing | `engine/phase4/reporting/ReviewerReportTemplate.kt` |
| 20.4 | Scheduled Health Reports | 2 | Missing | `engine/phase2/reporting/ScheduledHealthReports.kt` |
| 20.5 | Verifiable Public Report Link | 2 | Engine only | engine/phase2/network/LeaderboardClient.kt |
| 21.1 | Custom Benchmark Builder | 2 | Missing | `engine/phase2/enterprise/CustomBenchmarkBuilder.kt` |
| 21.2 | CLI & ADB Automation | 2 | Missing | `engine/phase2/enterprise/CliAdbAutomation.kt` |
| 21.3 | Fleet Management Dashboard | 4 | Engine only | engine/phase4/enterprise/FleetManagementDashboard.kt |
| 21.4 | Perfetto Trace Export | 4 | Engine only | engine/phase4/enterprise/PerfettoTraceExporter.kt |
| 21.5 | Target App Profiler | 4 | Engine only | engine/phase4/enterprise/TargetAppProfiler.kt |
| 21.6 | CI Regression API | 4 | Engine only | engine/phase4/enterprise/FleetManagementDashboard.kt |
| 22.1 | One-Tap Quick Test | 1 | Wired | engine/benchmark/QuickTestEngine.kt |
| 22.2 | Guided Pre-Test Checklist | 1 | Wired | engine/telemetry/GuidedPreTestChecklist.kt |
| 22.3 | Live Performance Overlay | 2 | Missing | `engine/phase2/ux/LivePerformanceOverlay.kt` |
| 22.4 | Widgets & Quick Settings Tile | 4 | Missing | `engine/phase4/ux/WidgetsQuickSettingsTile.kt` |
| 22.5 | Wear OS Companion | 4 | Engine only | engine/phase4/wearable/WearOsCompanionBridge.kt |

## Integration reality

Only **7 features** are reachable from the app UI/state today:

`18.1 18.3 19.6 20.1 20.2 22.1 22.2`

Everything else is either engine-only (Kotlin class exists, no caller) or native-only
(Rust exists, no Kotlin JNI/UI). Phase 2/3/4 folders have **no navigation routes or screens**;
`Routes.kt` / `BenchSuiteApp.kt` only cover the original 35-screen UI.

## Build health

- `cargo check` passes.
- `cargo test -- --test-threads=1` → **38 passed, 0 failed** (12s).
- Fixed during this audit: missing `stats::percentile` / `stats::round2`,
  `normalize_inverse` naming, `Sample`/`stats` imports in `memory.rs`, ambiguous
  `f64` in `vulkan_scan.rs`, raytracing scene triangle count, and the ML-KEM
  NTT/zeta/basemul implementation (now round-trips correctly).
- Kotlin compile is not verified locally (no JDK/Android SDK here); static checks
  (`balancescan`, `importaudit`, `argaudit`) pass.

## Status meaning

- **Wired** — referenced outside `engine/`, so it runs in the app path.
- **Engine only** — Kotlin implementation exists but is not called by UI/state/native yet.
- **Native only** — implemented in Rust; Kotlin JNI wrapper + UI route still needed.
- **Missing** — no code; proposed path shown.
