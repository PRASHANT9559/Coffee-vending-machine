import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
  },
  resolve: {
    alias: {
      '@swati/schema': path.resolve(__dirname, './packages/schema/src/index.ts'),
      '@swati/generator': path.resolve(__dirname, './packages/generator/src/index.ts'),
      '@': path.resolve(__dirname, './apps/studio/src'),
    },
  },
});
