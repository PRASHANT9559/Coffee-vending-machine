'use client';

import { StudioConfig } from '@swati/schema';
import { ScreenComponent, AppScreen } from './store';
import {
  templateScreenDart,
  generateScreenRoutesDart,
  type ExportedScreen,
  type ExportedComponent,
} from '@swati/generator';

export type { ExportedScreen, ExportedComponent };

export class ScreenExportService {
  private static instance: ScreenExportService;

  public static getInstance(): ScreenExportService {
    if (!ScreenExportService.instance) {
      ScreenExportService.instance = new ScreenExportService();
    }
    return ScreenExportService.instance;
  }

  /**
   * Transforms store AppScreens to clean ExportedScreen objects.
   */
  public exportScreens(
    screens: AppScreen[],
    _components?: ScreenComponent[],
    _config?: Partial<StudioConfig>
  ): ExportedScreen[] {
    return screens.map((screen) => {
      const screenComponents: ExportedComponent[] = screen.components.map((comp) => {
        const exportedComp: ExportedComponent = {
          id: comp.id,
          type: comp.type as ExportedComponent['type'],
          name: comp.name,
          props: { ...comp.props },
        };
        return exportedComp;
      });

      return {
        id: screen.id,
        name: screen.name,
        route: screen.route,
        isInitial: screen.isInitial,
        components: screenComponents,
      };
    });
  }

  /**
   * Exports screens to JSON string.
   */
  public exportToJson(screens: AppScreen[], components: ScreenComponent[]): string {
    const exportedScreens = this.exportScreens(screens, components, {});

    const exportData = {
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      screens: exportedScreens,
      metadata: {
        totalScreens: exportedScreens.length,
        totalComponents: exportedScreens.reduce((sum, s) => sum + s.components.length, 0),
      },
    };

    return JSON.stringify(exportData, null, 2);
  }

  /**
   * Imports screens from JSON string.
   */
  public importFromJson(jsonString: string): { screens: AppScreen[]; components: ScreenComponent[] } | null {
    try {
      const data = JSON.parse(jsonString);

      if (!data.screens || !Array.isArray(data.screens)) {
        throw new Error('Invalid export data format: missing screens array');
      }

      const screens: AppScreen[] = data.screens.map((screen: any) => ({
        id: screen.id || `screen-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        name: screen.name || 'Screen',
        route: screen.route || '/',
        isInitial: Boolean(screen.isInitial),
        components: Array.isArray(screen.components)
          ? screen.components.map((comp: any) => ({
              id: comp.id || `comp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
              type: comp.type || 'card',
              name: comp.name || 'Component',
              props: { ...comp.props },
            }))
          : [],
      }));

      const allComponents = screens.flatMap((s) => s.components);

      return {
        screens,
        components: allComponents,
      };
    } catch (error) {
      console.error('Failed to import screens:', error);
      return null;
    }
  }

  /**
   * Exports an individual screen to Flutter Dart source code.
   */
  public exportScreenToDart(screen: AppScreen): string {
    const exported = this.exportScreens([screen])[0];
    return templateScreenDart(exported);
  }

  /**
   * Exports all screens to an array of Dart files with code.
   */
  public exportAllScreensToDart(screens: AppScreen[]): { fileName: string; code: string; route: string }[] {
    const exported = this.exportScreens(screens);
    const result: { fileName: string; code: string; route: string }[] = [];

    for (const sc of exported) {
      const cleanName = sc.name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
      result.push({
        fileName: `${cleanName}_page.dart`,
        code: templateScreenDart(sc),
        route: sc.route,
      });
    }

    result.push({
      fileName: 'app_routes.dart',
      code: generateScreenRoutesDart(exported),
      route: '*',
    });

    return result;
  }
}

export const screenExportService = ScreenExportService.getInstance();
