'use client';

import { useCallback, useState } from 'react';
import type { ScreenComponent, AppScreen } from './store';
import { screenExportService } from './screenExportService';

export type ScreenBuilderAction =
  | { type: 'ADD_SCREEN'; screen: AppScreen }
  | { type: 'DELETE_SCREEN'; screenId: string }
  | { type: 'RENAME_SCREEN'; screenId: string; name: string; route: string }
  | { type: 'SET_INITIAL_SCREEN'; screenId: string }
  | { type: 'ADD_COMPONENT'; screenId: string; component: ScreenComponent }
  | { type: 'UPDATE_COMPONENT'; screenId: string; componentId: string; updates: Partial<ScreenComponent['props']> }
  | { type: 'DELETE_COMPONENT'; screenId: string; componentId: string }
  | { type: 'REORDER_COMPONENTS'; screenId: string; fromIndex: number; toIndex: number }
  | { type: 'UPDATE_SCREEN_METADATA'; screenId: string; updates: Partial<AppScreen> }
  | { type: 'SET_STATE'; state: ScreenBuilderState }
  | { type: 'RESET_STATE' };

export interface ScreenBuilderState {
  screens: AppScreen[];
  activeScreenId: string;
  activeComponents: ScreenComponent[];
  selectedComponentId: string | null;
}

function screenBuilderReducer(
  state: ScreenBuilderState,
  action: ScreenBuilderAction
): ScreenBuilderState {
  switch (action.type) {
    case 'SET_STATE':
      return { ...action.state };

    case 'ADD_SCREEN':
      return {
        ...state,
        screens: [...state.screens, action.screen],
        activeScreenId: action.screen.id,
        activeComponents: action.screen.components,
        selectedComponentId: action.screen.components[0]?.id ?? null,
      };

    case 'DELETE_SCREEN': {
      if (state.screens.length <= 1) return state;

      const updatedScreens = state.screens.filter((s) => s.id !== action.screenId);
      const nextActive = updatedScreens[0];

      return {
        ...state,
        screens: updatedScreens,
        activeScreenId: nextActive.id,
        activeComponents: nextActive.components,
        selectedComponentId: nextActive.components[0]?.id ?? null,
      };
    }

    case 'RENAME_SCREEN':
      return {
        ...state,
        screens: state.screens.map((s) =>
          s.id === action.screenId
            ? { ...s, name: action.name, route: action.route }
            : s
        ),
      };

    case 'SET_INITIAL_SCREEN':
      return {
        ...state,
        screens: state.screens.map((s) => ({
          ...s,
          isInitial: s.id === action.screenId,
        })),
      };

    case 'ADD_COMPONENT': {
      const targetScreen = state.screens.find((s) => s.id === action.screenId);
      if (!targetScreen) return state;

      const newComponent: ScreenComponent = {
        ...action.component,
        id: action.component.id || `comp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      };
      const updatedComponents = [...targetScreen.components, newComponent];

      return {
        ...state,
        screens: state.screens.map((s) =>
          s.id === action.screenId
            ? { ...s, components: updatedComponents }
            : s
        ),
        activeComponents:
          state.activeScreenId === action.screenId
            ? updatedComponents
            : state.activeComponents,
        selectedComponentId:
          state.activeScreenId === action.screenId
            ? newComponent.id
            : state.selectedComponentId,
      };
    }

    case 'UPDATE_COMPONENT': {
      const updatedScreens = state.screens.map((s) => {
        if (s.id !== action.screenId) return s;
        return {
          ...s,
          components: s.components.map((c) => {
            if (c.id !== action.componentId) return c;
            return {
              ...c,
              props: { ...c.props, ...action.updates },
            };
          }),
        };
      });

      const currentActiveScreen = updatedScreens.find((s) => s.id === state.activeScreenId);

      return {
        ...state,
        screens: updatedScreens,
        activeComponents: currentActiveScreen ? currentActiveScreen.components : state.activeComponents,
      };
    }

    case 'DELETE_COMPONENT': {
      const deletedScreens = state.screens.map((s) => {
        if (s.id !== action.screenId) return s;
        return {
          ...s,
          components: s.components.filter((c) => c.id !== action.componentId),
        };
      });

      const activeScreen = deletedScreens.find((s) => s.id === state.activeScreenId);
      const activeComponents = activeScreen ? activeScreen.components : [];
      const nextSelected =
        state.selectedComponentId === action.componentId
          ? activeComponents[0]?.id ?? null
          : state.selectedComponentId;

      return {
        ...state,
        screens: deletedScreens,
        activeComponents,
        selectedComponentId: nextSelected,
      };
    }

    case 'REORDER_COMPONENTS': {
      const screen = state.screens.find((s) => s.id === action.screenId);
      if (!screen) return state;

      const items = [...screen.components];
      if (
        action.fromIndex < 0 ||
        action.fromIndex >= items.length ||
        action.toIndex < 0 ||
        action.toIndex >= items.length
      ) {
        return state;
      }

      const [removed] = items.splice(action.fromIndex, 1);
      items.splice(action.toIndex, 0, removed);

      const reorderedScreens = state.screens.map((s) =>
        s.id === action.screenId ? { ...s, components: items } : s
      );

      return {
        ...state,
        screens: reorderedScreens,
        activeComponents:
          state.activeScreenId === action.screenId ? items : state.activeComponents,
      };
    }

    case 'UPDATE_SCREEN_METADATA':
      return {
        ...state,
        screens: state.screens.map((s) =>
          s.id === action.screenId ? { ...s, ...action.updates } : s
        ),
      };

    case 'RESET_STATE': {
      const defaultComponents: ScreenComponent[] = [
        {
          id: 'comp-appbar-1',
          type: 'appbar',
          name: 'Top AppBar',
          props: { title: 'Home Screen', elevation: 2 },
        },
        {
          id: 'comp-card-1',
          type: 'card',
          name: 'Welcome Card',
          props: { title: 'Welcome', borderRadius: 16, padding: 16 },
        },
      ];

      const defaultScreens: AppScreen[] = [
        {
          id: 'screen-home',
          name: 'Home Screen',
          route: '/',
          isInitial: true,
          components: defaultComponents,
        },
      ];

      return {
        screens: defaultScreens,
        activeScreenId: 'screen-home',
        activeComponents: defaultComponents,
        selectedComponentId: defaultComponents[0]?.id ?? null,
      };
    }

    default:
      return state;
  }
}

export function useScreenBuilderUndoRedo(
  initialState: ScreenBuilderState,
  maxHistory: number = 50
) {
  const [history, setHistory] = useState<ScreenBuilderState[]>([initialState]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const canUndo = currentIndex > 0;
  const canRedo = currentIndex < history.length - 1;

  const dispatch = useCallback(
    (action: ScreenBuilderAction) => {
      setHistory((prevHistory) => {
        const current = prevHistory[currentIndex] ?? initialState;
        const newState = screenBuilderReducer(current, action);
        const trimmed = prevHistory.slice(0, currentIndex + 1);
        trimmed.push(newState);

        if (trimmed.length > maxHistory) {
          trimmed.shift();
        }
        return trimmed;
      });
      setCurrentIndex((prev) => Math.min(prev + 1, maxHistory - 1));
    },
    [currentIndex, initialState, maxHistory]
  );

  const undo = useCallback(() => {
    if (canUndo) {
      setCurrentIndex((prev) => prev - 1);
    }
  }, [canUndo]);

  const redo = useCallback(() => {
    if (canRedo) {
      setCurrentIndex((prev) => prev + 1);
    }
  }, [canRedo]);

  const reset = useCallback(
    (state?: ScreenBuilderState) => {
      const base = state || initialState;
      setHistory([base]);
      setCurrentIndex(0);
    },
    [initialState]
  );

  const exportScreens = useCallback(() => {
    const current = history[currentIndex] || initialState;
    return screenExportService.exportToJson(current.screens, current.activeComponents);
  }, [history, currentIndex, initialState]);

  const importScreens = useCallback(
    (jsonString: string): boolean => {
      const imported = screenExportService.importFromJson(jsonString);
      if (imported) {
        const newState: ScreenBuilderState = {
          screens: imported.screens,
          activeScreenId: imported.screens[0]?.id || 'screen-home',
          activeComponents: imported.components,
          selectedComponentId: imported.components[0]?.id || null,
        };

        setHistory((prev) => {
          const next = prev.slice(0, currentIndex + 1);
          next.push(newState);
          return next;
        });
        setCurrentIndex((prev) => prev + 1);
        return true;
      }
      return false;
    },
    [currentIndex]
  );

  return {
    state: history[currentIndex] || initialState,
    dispatch,
    undo,
    redo,
    canUndo,
    canRedo,
    reset,
    historyLength: history.length,
    currentIndex,
    exportScreens,
    importScreens,
  };
}
