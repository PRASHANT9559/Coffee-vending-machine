import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  defaultConfig,
  steps,
  themeOptions,
  type FieldValue,
  type StudioConfig,
  type ThemePalette,
} from '@swati/schema';

export interface ScreenComponent {
  id: string;
  type:
    | 'appbar'
    | 'button'
    | 'text'
    | 'card'
    | 'textfield'
    | 'image'
    | 'listview'
    | 'floating_action_button'
    | 'badge'
    | 'stat_card'
    | 'container'
    | 'divider'
    | 'spacer';
  name: string;
  props: {
    title?: string;
    subtitle?: string;
    text?: string;
    label?: string;
    placeholder?: string;
    variant?: 'elevated' | 'filled' | 'outlined' | 'text' | 'h1' | 'h2' | 'body';
    color?: string;
    bgColor?: string;
    fontSize?: number;
    padding?: number;
    borderRadius?: number;
    icon?: string;
    elevation?: number;
    imageUrl?: string;
    value?: string;
    items?: string[];
    // Dynamic Routing Action Trigger
    actionType?: 'none' | 'navigate' | 'snackbar' | 'dialog';
    targetRoute?: string;
    height?: number;
    width?: number;
  };
}

export interface AppScreen {
  id: string;
  name: string;
  route: string;
  isInitial: boolean;
  components: ScreenComponent[];
}

export interface SavedApp {
  id: string;
  name: string;
  packageName: string;
  version: string;
  description: string;
  config: StudioConfig;
  selectedThemePalette: string;
  screens: AppScreen[];
  activeScreenId: string;
  components: ScreenComponent[];
  createdAt: string;
  updatedAt: string;
}

export const DEFAULT_SCREEN_COMPONENTS: ScreenComponent[] = [
  {
    id: 'comp-appbar-1',
    type: 'appbar',
    name: 'Top AppBar',
    props: {
      title: 'Home Screen',
      elevation: 2,
    },
  },
  {
    id: 'comp-card-1',
    type: 'card',
    name: 'Welcome Card',
    props: {
      title: 'Welcome to Swati Studio',
      subtitle: 'Build, route, and style Flutter screens with 20 dynamic palettes.',
      borderRadius: 16,
      padding: 16,
    },
  },
  {
    id: 'comp-btn-1',
    type: 'button',
    name: 'Navigate to Profile',
    props: {
      label: 'Open Profile Screen',
      variant: 'elevated',
      borderRadius: 12,
      actionType: 'navigate',
      targetRoute: '/profile',
    },
  },
  {
    id: 'comp-list-1',
    type: 'listview',
    name: 'Quick Navigation',
    props: {
      title: 'Application Routes',
      items: ['Home Screen (/)', 'Profile Screen (/profile)', 'Settings Screen (/settings)'],
      borderRadius: 12,
    },
  },
  {
    id: 'comp-fab-1',
    type: 'floating_action_button',
    name: 'Floating Action Button',
    props: {
      icon: 'Plus',
      elevation: 6,
    },
  },
];

export const DEFAULT_SCREENS: AppScreen[] = [
  {
    id: 'screen-home',
    name: 'Home Screen',
    route: '/',
    isInitial: true,
    components: DEFAULT_SCREEN_COMPONENTS,
  },
  {
    id: 'screen-profile',
    name: 'Profile Screen',
    route: '/profile',
    isInitial: false,
    components: [
      {
        id: 'comp-profile-appbar',
        type: 'appbar',
        name: 'Profile AppBar',
        props: {
          title: 'User Profile',
          elevation: 2,
        },
      },
      {
        id: 'comp-profile-card',
        type: 'card',
        name: 'Profile Details',
        props: {
          title: 'John Doe',
          subtitle: 'Lead Mobile Architect & Flutter Developer',
          borderRadius: 16,
          padding: 16,
        },
      },
      {
        id: 'comp-profile-stats',
        type: 'stat_card',
        name: 'Metric Stats',
        props: {
          title: 'Completed Projects',
          value: '42',
        },
      },
      {
        id: 'comp-profile-btn',
        type: 'button',
        name: 'Back to Home',
        props: {
          label: '← Back to Home Screen',
          variant: 'elevated',
          borderRadius: 12,
          actionType: 'navigate',
          targetRoute: '/',
        },
      },
    ],
  },
];

export interface StudioState {
  config: StudioConfig;
  currentStep: number;
  theme: 'light' | 'dark' | 'system';
  sidebarCollapsed: boolean;
  lastResult: { ok: boolean; message: string; path?: string } | null;

  // Multi-app & Screen views
  currentView: 'wizard' | 'applications' | 'screen_builder';
  apps: SavedApp[];
  currentAppId: string | null;

  // Active Screens & Routing State
  screens: AppScreen[];
  activeScreenId: string;
  activeComponents: ScreenComponent[];
  selectedComponentId: string | null;

  // 20 Themes Dynamic Selection
  selectedThemePalette: string;

  // View & navigation actions
  setCurrentView: (view: 'wizard' | 'applications' | 'screen_builder') => void;
  setValue: (id: string, value: FieldValue) => void;
  toggleInArray: (id: string, value: string) => void;
  goToStep: (index: number) => void;
  nextStep: () => void;
  prevStep: () => void;
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  toggleSidebar: () => void;
  setLastResult: (result: { ok: boolean; message: string; path?: string } | null) => void;
  resetConfig: () => void;
  loadConfig: (config: Partial<StudioConfig>) => void;

  // Multi-App Management
  saveCurrentApp: (customName?: string) => SavedApp;
  selectApp: (id: string, targetView?: 'wizard' | 'screen_builder') => void;
  deleteApp: (id: string) => void;
  createNewApp: () => void;
  updateCurrentAppMetadata: (name: string, description?: string) => void;

  // Multi-Screen & Routing Actions
  addScreen: (name: string, route?: string) => AppScreen;
  deleteScreen: (screenId: string) => void;
  renameScreen: (screenId: string, name: string, route: string) => void;
  setInitialScreen: (screenId: string) => void;
  selectScreen: (screenId: string) => void;

  // Screen component actions (Add, Update, Delete)
  addComponent: (component: Omit<ScreenComponent, 'id'>) => ScreenComponent;
  updateComponent: (id: string, props: Partial<ScreenComponent['props']>) => void;
  deleteComponent: (id: string) => void;
  reorderComponents: (fromIndex: number, toIndex: number) => void;
  setSelectedComponentId: (id: string | null) => void;
  resetActiveComponents: () => void;

  // 20 Theme Palettes Action (Single-point update cascades everywhere)
  setThemePalette: (paletteId: string) => void;
}

export const useStudioStore = create<StudioState>()(
  persist(
    (set, get) => ({
      config: defaultConfig(),
      currentStep: 0,
      theme: 'dark',
      sidebarCollapsed: false,
      lastResult: null,

      currentView: 'wizard',
      apps: [],
      currentAppId: null,

      screens: DEFAULT_SCREENS,
      activeScreenId: 'screen-home',
      activeComponents: DEFAULT_SCREENS[0].components,
      selectedComponentId: DEFAULT_SCREENS[0].components[0]?.id ?? null,

      selectedThemePalette: 'royal_indigo',

      setCurrentView: (view) => set({ currentView: view }),

      setValue: (id, value) =>
        set((state) => {
          const newConfig = {
            ...state.config,
            [id]: value,
          };
          let updatedApps = state.apps;
          if (state.currentAppId) {
            updatedApps = state.apps.map((app) =>
              app.id === state.currentAppId
                ? {
                    ...app,
                    name: id === 'project.name' ? String(value) : app.name,
                    packageName: id === 'project.packageName' ? String(value) : app.packageName,
                    config: newConfig,
                    updatedAt: new Date().toISOString(),
                  }
                : app,
            );
          }
          return {
            config: newConfig,
            apps: updatedApps,
          };
        }),

      toggleInArray: (id, itemValue) =>
        set((state) => {
          const current = Array.isArray(state.config[id])
            ? ([...(state.config[id] as string[])])
            : [];
          const idx = current.indexOf(itemValue);
          if (idx >= 0) {
            current.splice(idx, 1);
          } else {
            current.push(itemValue);
          }
          const newConfig = {
            ...state.config,
            [id]: current,
          };
          let updatedApps = state.apps;
          if (state.currentAppId) {
            updatedApps = state.apps.map((app) =>
              app.id === state.currentAppId
                ? { ...app, config: newConfig, updatedAt: new Date().toISOString() }
                : app,
            );
          }
          return {
            config: newConfig,
            apps: updatedApps,
          };
        }),

      goToStep: (index) => {
        const clamped = Math.max(0, Math.min(steps.length - 1, index));
        set({ currentStep: clamped, currentView: 'wizard' });
      },

      nextStep: () => {
        const { currentStep } = get();
        if (currentStep < steps.length - 1) {
          set({ currentStep: currentStep + 1 });
        }
      },

      prevStep: () => {
        const { currentStep } = get();
        if (currentStep > 0) {
          set({ currentStep: currentStep - 1 });
        }
      },

      setTheme: (theme) => set({ theme }),

      toggleSidebar: () =>
        set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),

      setLastResult: (lastResult) => set({ lastResult }),

      resetConfig: () =>
        set({
          config: defaultConfig(),
          currentStep: 0,
          lastResult: null,
          currentAppId: null,
          screens: DEFAULT_SCREENS,
          activeScreenId: 'screen-home',
          activeComponents: DEFAULT_SCREENS[0].components,
          selectedComponentId: null,
        }),

      loadConfig: (incoming) =>
        set((state) => ({
          config: {
            ...state.config,
            ...incoming,
          },
        })),

      // Multi-App Management
      saveCurrentApp: (customName) => {
        const state = get();
        const appName = customName || String(state.config['project.name'] || 'My Flutter App');
        const packageName = String(state.config['project.packageName'] || 'com.example.app');
        const version = String(state.config['project.version'] || '1.0.0');
        const description = String(state.config['project.description'] || '');

        const existingIndex = state.apps.findIndex(
          (a) => a.id === state.currentAppId || a.name.toLowerCase() === appName.toLowerCase(),
        );

        const now = new Date().toISOString();

        if (existingIndex >= 0) {
          const updated = [...state.apps];
          const existing = updated[existingIndex];
          const savedApp: SavedApp = {
            ...existing,
            name: appName,
            packageName,
            version,
            description,
            config: { ...state.config, 'project.name': appName },
            selectedThemePalette: state.selectedThemePalette,
            screens: state.screens,
            activeScreenId: state.activeScreenId,
            components: state.activeComponents,
            updatedAt: now,
          };
          updated[existingIndex] = savedApp;
          set({ apps: updated, currentAppId: savedApp.id });
          return savedApp;
        }

        const newApp: SavedApp = {
          id: `app_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          name: appName,
          packageName,
          version,
          description,
          config: { ...state.config, 'project.name': appName },
          selectedThemePalette: state.selectedThemePalette,
          screens: state.screens,
          activeScreenId: state.activeScreenId,
          components: state.activeComponents,
          createdAt: now,
          updatedAt: now,
        };

        set((s) => ({
          apps: [newApp, ...s.apps],
          currentAppId: newApp.id,
        }));
        return newApp;
      },

      selectApp: (id, targetView = 'screen_builder') => {
        const { apps } = get();
        const target = apps.find((a) => a.id === id);
        if (!target) return;

        const screens = target.screens && target.screens.length > 0 ? target.screens : DEFAULT_SCREENS;
        const activeScreen = screens.find((s) => s.id === target.activeScreenId) || screens[0];

        set({
          currentAppId: target.id,
          config: { ...target.config },
          selectedThemePalette: target.selectedThemePalette || 'royal_indigo',
          screens,
          activeScreenId: activeScreen.id,
          activeComponents: activeScreen.components,
          selectedComponentId: activeScreen.components[0]?.id ?? null,
          currentView: targetView,
        });
      },

      deleteApp: (id) => {
        set((state) => {
          const nextApps = state.apps.filter((a) => a.id !== id);
          const isCurrent = state.currentAppId === id;
          return {
            apps: nextApps,
            currentAppId: isCurrent ? null : state.currentAppId,
            currentView: isCurrent ? 'applications' : state.currentView,
          };
        });
      },

      createNewApp: () => {
        const freshConfig = defaultConfig();
        const newAppId = `app_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const freshApp: SavedApp = {
          id: newAppId,
          name: 'New Flutter App',
          packageName: 'com.example.new_app',
          version: '1.0.0',
          description: 'A new Flutter application created with Swati Studio',
          config: freshConfig,
          selectedThemePalette: 'royal_indigo',
          screens: DEFAULT_SCREENS,
          activeScreenId: 'screen-home',
          components: DEFAULT_SCREENS[0].components,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        set((state) => ({
          apps: [freshApp, ...state.apps],
          currentAppId: newAppId,
          config: freshConfig,
          selectedThemePalette: 'royal_indigo',
          screens: DEFAULT_SCREENS,
          activeScreenId: 'screen-home',
          activeComponents: DEFAULT_SCREENS[0].components,
          selectedComponentId: DEFAULT_SCREENS[0].components[0].id,
          currentStep: 0,
          currentView: 'wizard',
        }));
      },

      updateCurrentAppMetadata: (name, description) => {
        set((state) => {
          if (!state.currentAppId) return state;
          const updatedApps = state.apps.map((app) =>
            app.id === state.currentAppId
              ? {
                  ...app,
                  name,
                  description: description !== undefined ? description : app.description,
                  config: { ...app.config, 'project.name': name },
                  updatedAt: new Date().toISOString(),
                }
              : app,
          );
          return {
            apps: updatedApps,
            config: { ...state.config, 'project.name': name },
          };
        });
      },

      // ==========================================================
      // Multi-Screen Routing Actions
      // ==========================================================
      addScreen: (name, route) => {
        const routePath = route || `/${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
        const newScreenId = `screen-${Date.now().toString(36)}`;
        const newScreen: AppScreen = {
          id: newScreenId,
          name,
          route: routePath,
          isInitial: false,
          components: [
            {
              id: `comp-appbar-${newScreenId}`,
              type: 'appbar',
              name: `${name} AppBar`,
              props: { title: name, elevation: 2 },
            },
            {
              id: `comp-card-${newScreenId}`,
              type: 'card',
              name: `${name} Container`,
              props: {
                title: name,
                subtitle: `Route: ${routePath}`,
                borderRadius: 16,
                padding: 16,
              },
            },
            {
              id: `comp-back-btn-${newScreenId}`,
              type: 'button',
              name: 'Back Action Button',
              props: {
                label: '← Back to Home',
                variant: 'elevated',
                borderRadius: 12,
                actionType: 'navigate',
                targetRoute: '/',
              },
            },
          ],
        };

        set((state) => {
          const updatedScreens = [...state.screens, newScreen];
          const updatedApps = state.currentAppId
            ? state.apps.map((a) =>
                a.id === state.currentAppId
                  ? { ...a, screens: updatedScreens, updatedAt: new Date().toISOString() }
                  : a,
              )
            : state.apps;

          return {
            screens: updatedScreens,
            activeScreenId: newScreenId,
            activeComponents: newScreen.components,
            selectedComponentId: newScreen.components[0].id,
            apps: updatedApps,
          };
        });

        return newScreen;
      },

      deleteScreen: (screenId) => {
        set((state) => {
          if (state.screens.length <= 1) return state; // Keep at least one screen
          const updatedScreens = state.screens.filter((s) => s.id !== screenId);
          // If we deleted initial screen, make the first one initial
          if (!updatedScreens.some((s) => s.isInitial)) {
            updatedScreens[0].isInitial = true;
          }
          const nextActive = updatedScreens[0];

          const updatedApps = state.currentAppId
            ? state.apps.map((a) =>
                a.id === state.currentAppId
                  ? {
                      ...a,
                      screens: updatedScreens,
                      activeScreenId: nextActive.id,
                      updatedAt: new Date().toISOString(),
                    }
                  : a,
              )
            : state.apps;

          return {
            screens: updatedScreens,
            activeScreenId: nextActive.id,
            activeComponents: nextActive.components,
            selectedComponentId: nextActive.components[0]?.id ?? null,
            apps: updatedApps,
          };
        });
      },

      renameScreen: (screenId, name, route) => {
        set((state) => {
          const updatedScreens = state.screens.map((s) =>
            s.id === screenId ? { ...s, name, route } : s,
          );
          const updatedApps = state.currentAppId
            ? state.apps.map((a) =>
                a.id === state.currentAppId
                  ? { ...a, screens: updatedScreens, updatedAt: new Date().toISOString() }
                  : a,
              )
            : state.apps;

          return {
            screens: updatedScreens,
            apps: updatedApps,
          };
        });
      },

      setInitialScreen: (screenId) => {
        set((state) => {
          const updatedScreens = state.screens.map((s) => ({
            ...s,
            isInitial: s.id === screenId,
          }));
          const updatedApps = state.currentAppId
            ? state.apps.map((a) =>
                a.id === state.currentAppId
                  ? { ...a, screens: updatedScreens, updatedAt: new Date().toISOString() }
                  : a,
              )
            : state.apps;

          return {
            screens: updatedScreens,
            apps: updatedApps,
          };
        });
      },

      selectScreen: (screenId) => {
        const { screens } = get();
        const target = screens.find((s) => s.id === screenId);
        if (!target) return;

        set((state) => {
          const updatedApps = state.currentAppId
            ? state.apps.map((a) =>
                a.id === state.currentAppId ? { ...a, activeScreenId: screenId } : a,
              )
            : state.apps;

          return {
            activeScreenId: target.id,
            activeComponents: target.components,
            selectedComponentId: target.components[0]?.id ?? null,
            apps: updatedApps,
          };
        });
      },

      // ==========================================================
      // Screen Component Actions (Synchronized to Active Screen)
      // ==========================================================
      addComponent: (compData) => {
        const id = `comp-${compData.type}-${Date.now().toString(36)}`;
        const newComponent: ScreenComponent = {
          ...compData,
          id,
        };

        set((state) => {
          const updatedComponents = [...state.activeComponents, newComponent];
          const updatedScreens = state.screens.map((s) =>
            s.id === state.activeScreenId ? { ...s, components: updatedComponents } : s,
          );

          const updatedApps = state.currentAppId
            ? state.apps.map((app) =>
                app.id === state.currentAppId
                  ? {
                      ...app,
                      screens: updatedScreens,
                      components: updatedComponents,
                      updatedAt: new Date().toISOString(),
                    }
                  : app,
              )
            : state.apps;

          return {
            activeComponents: updatedComponents,
            screens: updatedScreens,
            selectedComponentId: id,
            apps: updatedApps,
          };
        });

        return newComponent;
      },

      updateComponent: (id, propsUpdates) => {
        set((state) => {
          const updatedComponents = state.activeComponents.map((c) =>
            c.id === id
              ? {
                  ...c,
                  props: {
                    ...c.props,
                    ...propsUpdates,
                  },
                }
              : c,
          );

          const updatedScreens = state.screens.map((s) =>
            s.id === state.activeScreenId ? { ...s, components: updatedComponents } : s,
          );

          const updatedApps = state.currentAppId
            ? state.apps.map((app) =>
                app.id === state.currentAppId
                  ? {
                      ...app,
                      screens: updatedScreens,
                      components: updatedComponents,
                      updatedAt: new Date().toISOString(),
                    }
                  : app,
              )
            : state.apps;

          return {
            activeComponents: updatedComponents,
            screens: updatedScreens,
            apps: updatedApps,
          };
        });
      },

      deleteComponent: (id) => {
        set((state) => {
          const updatedComponents = state.activeComponents.filter((c) => c.id !== id);
          const nextSelected =
            state.selectedComponentId === id
              ? updatedComponents.length > 0
                ? updatedComponents[0].id
                : null
              : state.selectedComponentId;

          const updatedScreens = state.screens.map((s) =>
            s.id === state.activeScreenId ? { ...s, components: updatedComponents } : s,
          );

          const updatedApps = state.currentAppId
            ? state.apps.map((app) =>
                app.id === state.currentAppId
                  ? {
                      ...app,
                      screens: updatedScreens,
                      components: updatedComponents,
                      updatedAt: new Date().toISOString(),
                    }
                  : app,
              )
            : state.apps;

          return {
            activeComponents: updatedComponents,
            screens: updatedScreens,
            selectedComponentId: nextSelected,
            apps: updatedApps,
          };
        });
      },

      reorderComponents: (fromIndex, toIndex) => {
        set((state) => {
          if (
            fromIndex < 0 ||
            fromIndex >= state.activeComponents.length ||
            toIndex < 0 ||
            toIndex >= state.activeComponents.length
          ) {
            return state;
          }

          const items = [...state.activeComponents];
          const [moved] = items.splice(fromIndex, 1);
          items.splice(toIndex, 0, moved);

          const updatedScreens = state.screens.map((s) =>
            s.id === state.activeScreenId ? { ...s, components: items } : s,
          );

          const updatedApps = state.currentAppId
            ? state.apps.map((app) =>
                app.id === state.currentAppId
                  ? {
                      ...app,
                      screens: updatedScreens,
                      components: items,
                      updatedAt: new Date().toISOString(),
                    }
                  : app,
              )
            : state.apps;

          return {
            activeComponents: items,
            screens: updatedScreens,
            apps: updatedApps,
          };
        });
      },

      setSelectedComponentId: (id) => set({ selectedComponentId: id }),

      resetActiveComponents: () =>
        set((state) => ({
          activeComponents: DEFAULT_SCREEN_COMPONENTS,
          selectedComponentId: DEFAULT_SCREEN_COMPONENTS[0]?.id ?? null,
        })),

      // ==========================================================
      // 20 Theme Palettes Action (Single-point update cascades everywhere)
      // ==========================================================
      setThemePalette: (paletteId) => {
        const found = themeOptions.find(
          (t) => t.name.toLowerCase().replace(/[^a-z0-9]+/g, '_') === paletteId,
        );

        set((state) => {
          const accentColor = found?.light?.blue || '#6366f1';
          const newConfig = {
            ...state.config,
            'frontend.themeColor': paletteId,
            'frontend.customColor': accentColor,
          };

          const updatedApps = state.currentAppId
            ? state.apps.map((a) =>
                a.id === state.currentAppId
                  ? {
                      ...a,
                      selectedThemePalette: paletteId,
                      config: newConfig,
                      updatedAt: new Date().toISOString(),
                    }
                  : a,
              )
            : state.apps;

          return {
            selectedThemePalette: paletteId,
            config: newConfig,
            apps: updatedApps,
          };
        });
      },
    }),
    {
      name: 'swati-studio-draft',
      partialize: (state) => ({
        config: state.config,
        currentStep: state.currentStep,
        theme: state.theme,
        sidebarCollapsed: state.sidebarCollapsed,
        apps: state.apps,
        currentAppId: state.currentAppId,
        screens: state.screens,
        activeScreenId: state.activeScreenId,
        activeComponents: state.activeComponents,
        selectedThemePalette: state.selectedThemePalette,
        currentView: state.currentView,
      }),
    },
  ),
);
