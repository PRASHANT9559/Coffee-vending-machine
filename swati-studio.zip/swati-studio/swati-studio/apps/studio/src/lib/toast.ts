import { create } from 'zustand';

export type ToastKind = 'success' | 'error' | 'info';

export interface ToastItem {
  id: string;
  kind: ToastKind;
  message: string;
}

interface ToastStore {
  toasts: ToastItem[];
  add: (kind: ToastKind, message: string, durationMs?: number) => string;
  dismiss: (id: string) => void;
}

export const useToastStore = create<ToastStore>((set) => ({
  toasts: [],
  add: (kind, message, durationMs = 4000) => {
    const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    set((state) => ({
      toasts: [...state.toasts, { id, kind, message }],
    }));

    if (durationMs > 0 && typeof window !== 'undefined') {
      setTimeout(() => {
        set((state) => ({
          toasts: state.toasts.filter((t) => t.id !== id),
        }));
      }, durationMs);
    }

    return id;
  },
  dismiss: (id) =>
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    })),
}));

export const toast = {
  success: (message: string, durationMs?: number) =>
    useToastStore.getState().add('success', message, durationMs),
  error: (message: string, durationMs?: number) =>
    useToastStore.getState().add('error', message, durationMs),
  info: (message: string, durationMs?: number) =>
    useToastStore.getState().add('info', message, durationMs),
};
