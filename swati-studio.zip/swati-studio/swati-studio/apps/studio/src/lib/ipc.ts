import { zipSync, strToU8 } from 'fflate';

export interface GeneratedFile {
  path: string;
  contents: string;
}

export interface WriteResult {
  ok: boolean;
  path: string;
  files: number;
  message: string;
}

export interface ToolchainReport {
  flutter: string | null;
  dart: string | null;
  node: string | null;
  rustc: string | null;
}

function isTauri(): boolean {
  return typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;
}

async function invokeTauri<T>(cmd: string, args?: Record<string, unknown>): Promise<T | null> {
  if (!isTauri()) return null;
  try {
    const { invoke } = await import('@tauri-apps/api/core');
    return await invoke<T>(cmd, args);
  } catch (err) {
    console.warn(`Tauri IPC call '${cmd}' failed:`, err);
    return null;
  }
}

/** Detects installed toolchains (Flutter, Dart, Node, Rust). */
export async function detectToolchains(): Promise<ToolchainReport | null> {
  if (!isTauri()) return null;
  return invokeTauri<ToolchainReport>('detect_toolchains');
}

/** Gets the default project generation folder. */
export async function defaultOutputDir(): Promise<string | null> {
  if (!isTauri()) return '';
  return invokeTauri<string>('default_output_dir');
}

/** Native folder picker dialog. */
export async function pickOutputDir(): Promise<string | null> {
  if (!isTauri()) return null;
  return invokeTauri<string>('pick_output_dir');
}

/** Opens a folder or file in the default application. */
export async function openPath(path: string): Promise<boolean> {
  const result = await invokeTauri<boolean>('open_path', { path });
  return result ?? false;
}

/** Reveals a file or folder in the system file manager. */
export async function revealPath(path: string): Promise<boolean> {
  const result = await invokeTauri<boolean>('reveal_path', { path });
  return result ?? false;
}

/** Saves a draft file to OS app data or localStorage. */
export async function saveNativeDraft(name: string, content: string): Promise<boolean> {
  if (isTauri()) {
    const ok = await invokeTauri<boolean>('save_draft', { name, content });
    if (ok) return true;
  }
  try {
    localStorage.setItem(`swati-draft-${name}`, content);
    return true;
  } catch {
    return false;
  }
}

/** Loads a draft file from OS app data or localStorage. */
export async function loadNativeDraft(name: string): Promise<string | null> {
  if (isTauri()) {
    const result = await invokeTauri<string | null>('load_draft', { name });
    if (result) return result;
  }
  try {
    return localStorage.getItem(`swati-draft-${name}`);
  } catch {
    return null;
  }
}

/** Runs `flutter create` in the target project folder. */
export async function runFlutterCreate(
  directory: string,
  organization: string,
  projectName: string,
): Promise<string | null> {
  if (!isTauri()) return null;
  return invokeTauri<string>('run_flutter_create', {
    directory,
    organization,
    projectName,
  });
}

/**
 * Writes the generated files to disk via Tauri Rust commands.
 * When running in the browser, falls back to in-memory zipping with `fflate`
 * and automatic browser download.
 */
export async function writeProject(
  files: GeneratedFile[],
  outputDir: string,
  projectName: string,
  createZip: boolean = true,
): Promise<WriteResult> {
  if (isTauri()) {
    try {
      const { invoke } = await import('@tauri-apps/api/core');
      const res = await invoke<WriteResult>('write_project', {
        files,
        outputDir,
        projectName,
        createZip,
      });
      return res;
    } catch (err) {
      return {
        ok: false,
        path: '',
        files: 0,
        message: err instanceof Error ? err.message : String(err),
      };
    }
  }

  // Browser fallback with fflate zip and trigger download
  try {
    const zipEntries: Record<string, Uint8Array> = {};
    const rootName = projectName.trim() || 'my_app';

    for (const file of files) {
      const cleanPath = file.path.replace(/^\/+/, '');
      zipEntries[`${rootName}/${cleanPath}`] = strToU8(file.contents);
    }

    const zipped = zipSync(zipEntries, { level: 6 });
    const blob = new Blob([zipped], { type: 'application/zip' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${rootName}.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    return {
      ok: true,
      path: `${rootName}.zip`,
      files: files.length,
      message: `${files.length} files generated and downloaded as ${rootName}.zip`,
    };
  } catch (err) {
    return {
      ok: false,
      path: '',
      files: 0,
      message: `Browser zip generation failed: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
