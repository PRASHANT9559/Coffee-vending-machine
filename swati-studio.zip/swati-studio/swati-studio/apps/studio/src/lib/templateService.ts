'use client';

import React from 'react';
import { StudioConfig } from '@swati/schema';

export interface StudioTemplate {
  id: string;
  name: string;
  description: string;
  category: 'web' | 'mobile' | 'desktop' | 'custom';
  config: Partial<StudioConfig>;
  thumbnail?: string;
  createdAt: string;
  updatedAt: string;
  author?: string;
  version?: string;
  tags?: string[];
}

const TEMPLATES_STORAGE_KEY = 'swati-studio-templates';
const DEFAULT_TEMPLATES: StudioTemplate[] = [
  {
    id: 'web-app',
    name: 'Web Application',
    description: 'A standard web application with React and Next.js',
    category: 'web',
    config: {
      'frontend.framework': 'nextjs',
      'project.type': 'web',
      'frontend.routing': 'pages',
    },
    createdAt: '2024-11-01T00:00:00.000Z',
    updatedAt: '2024-11-01T00:00:00.000Z',
    author: 'Swati Studio',
    version: '1.0.0',
    tags: ['web', 'nextjs', 'react'],
  },
  {
    id: 'mobile-app',
    name: 'Mobile App',
    description: 'A Flutter mobile application',
    category: 'mobile',
    config: {
      'frontend.framework': 'flutter',
      'project.type': 'mobile',
      'architecture.pattern': 'clean',
      'stateManager': 'riverpod',
    },
    createdAt: '2024-11-01T00:00:00.000Z',
    updatedAt: '2024-11-01T00:00:00.000Z',
    author: 'Swati Studio',
    version: '1.0.0',
    tags: ['flutter', 'mobile', 'clean'],
  },
  {
    id: 'ecommerce',
    name: 'E-Commerce',
    description: 'An e-commerce application with payments and cart',
    category: 'custom',
    config: {
      'backend.provider': 'supabase',
      'database': 'postgresql',
      'features.selected': ['auth', 'payments', 'notifications', 'maps'],
      'components.selected': ['commerce', 'cart', 'checkout', 'payment'],
    },
    createdAt: '2024-11-01T00:00:00.000Z',
    updatedAt: '2024-11-01T00:00:00.000Z',
    author: 'Swati Studio',
    version: '1.0.0',
    tags: ['ecommerce', 'supabase', 'payments'],
  },
  {
    id: 'social-media',
    name: 'Social Media App',
    description: 'A social media application with user profiles and feeds',
    category: 'custom',
    config: {
      'backend.provider': 'firebase',
      'database': 'firestore',
      'features.selected': ['auth', 'realtime', 'storage', 'notifications'],
      'components.selected': ['navigation', 'profile', 'feed', 'messaging'],
    },
    createdAt: '2024-11-01T00:00:00.000Z',
    updatedAt: '2024-11-01T00:00:00.000Z',
    author: 'Swati Studio',
    version: '1.0.0',
    tags: ['social', 'firebase', 'realtime'],
  },
  {
    id: 'dashboard',
    name: 'Admin Dashboard',
    description: 'An admin dashboard with analytics and data visualization',
    category: 'web',
    config: {
      'frontend.framework': 'nextjs',
      'components.selected': ['charts', 'tables', 'cards', 'metrics'],
      'features.selected': ['auth', 'api', 'analytics'],
    },
    createdAt: '2024-11-01T00:00:00.000Z',
    updatedAt: '2024-11-01T00:00:00.000Z',
    author: 'Swati Studio',
    version: '1.0.0',
    tags: ['dashboard', 'analytics', 'admin'],
  },
];

class TemplateService {
  private static instance: TemplateService;

  public static getInstance(): TemplateService {
    if (!TemplateService.instance) {
      TemplateService.instance = new TemplateService();
    }
    return TemplateService.instance;
  }

  public getAllTemplates(): StudioTemplate[] {
    const stored = localStorage.getItem(TEMPLATES_STORAGE_KEY);
    const userTemplates = stored ? JSON.parse(stored) : [];
    return [...DEFAULT_TEMPLATES, ...userTemplates].sort((a, b) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public getTemplate(id: string): StudioTemplate | undefined {
    const templates = this.getAllTemplates();
    return templates.find((t) => t.id === id);
  }

  public createTemplate(template: Omit<StudioTemplate, 'id' | 'createdAt' | 'updatedAt'>): StudioTemplate {
    const id = this.generateId();
    const now = new Date().toISOString();

    const newTemplate: StudioTemplate = {
      ...template,
      id,
      createdAt: now,
      updatedAt: now,
    };

    this.saveTemplate(newTemplate);
    return newTemplate;
  }

  public updateTemplate(id: string, updates: Partial<StudioTemplate>): StudioTemplate | null {
    const templates = this.getAllTemplates();
    const index = templates.findIndex((t) => t.id === id);

    if (index === -1) return null;

    const updatedTemplate = {
      ...templates[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    templates[index] = updatedTemplate;
    this.saveAllTemplates(templates);
    return updatedTemplate;
  }

  public deleteTemplate(id: string): boolean {
    const templates = this.getAllTemplates();
    const filtered = templates.filter((t) => t.id !== id);

    if (filtered.length === templates.length) return false;

    this.saveAllTemplates(filtered);
    return true;
  }

  public exportConfig(config: Partial<StudioConfig>): string {
    return JSON.stringify(config, null, 2);
  }

  public importConfig(jsonString: string): Partial<StudioConfig> | null {
    try {
      const config = JSON.parse(jsonString);
      return config as Partial<StudioConfig>;
    } catch (error) {
      console.error('Failed to import config:', error);
      return null;
    }
  }

  public applyTemplateToConfig(
    config: Partial<StudioConfig>,
    template: StudioTemplate
  ): Partial<StudioConfig> {
    // Deep merge template config with existing config
    const merged = { ...config, ...template.config };

    // Ensure template-specific fields are applied
    if (template.config) {
      Object.assign(merged, template.config);
    }

    return merged;
  }

  public getTemplatesByCategory(category: StudioTemplate['category']): StudioTemplate[] {
    return this.getAllTemplates().filter((t) => t.category === category);
  }

  public getRecentTemplates(limit: number = 5): StudioTemplate[] {
    return this.getAllTemplates()
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, limit);
  }

  private saveTemplate(template: StudioTemplate): void {
    const templates = this.getAllTemplates();
    const index = templates.findIndex((t) => t.id === template.id);

    if (index >= 0) {
      templates[index] = template;
    } else {
      templates.push(template);
    }

    this.saveAllTemplates(templates);
  }

  private saveAllTemplates(templates: StudioTemplate[]): void {
    // Remove default templates from saved templates
    const userTemplates = templates.filter((t) =>
      !DEFAULT_TEMPLATES.some((dt) => dt.id === t.id)
    );
    localStorage.setItem(TEMPLATES_STORAGE_KEY, JSON.stringify(userTemplates));
  }

  private generateId(): string {
    return `template_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  }
}

export const templateService = TemplateService.getInstance();

// React hooks for template management
export function useTemplates() {
  const [templates, setTemplates] = React.useState<StudioTemplate[]>([]);

  React.useEffect(() => {
    setTemplates(templateService.getAllTemplates());
  }, []);

  const createTemplate = (template: Omit<StudioTemplate, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newTemplate = templateService.createTemplate(template);
    setTemplates(templateService.getAllTemplates());
    return newTemplate;
  };

  const updateTemplate = (id: string, updates: Partial<StudioTemplate>) => {
    const updated = templateService.updateTemplate(id, updates);
    if (updated) {
      setTemplates(templateService.getAllTemplates());
    }
    return updated;
  };

  const deleteTemplate = (id: string) => {
    const success = templateService.deleteTemplate(id);
    if (success) {
      setTemplates(templateService.getAllTemplates());
    }
    return success;
  };

  const importConfig = (jsonString: string) => {
    return templateService.importConfig(jsonString);
  };

  return {
    templates,
    createTemplate,
    updateTemplate,
    deleteTemplate,
    importConfig,
    getAllTemplates: templateService.getAllTemplates.bind(templateService),
    getTemplate: templateService.getTemplate.bind(templateService),
  };
}