import type { Metadata, Viewport } from 'next';
import './globals.css';
import { ThemeSync } from '@/components/ThemeSync';

export const metadata: Metadata = {
  title: 'Swati Studio — Schema-driven app builder',
  description:
    'Pick a stack, pick a style, get a real project on disk. Swati Studio turns a wizard into working code.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
};

/**
 * Applies the persisted theme before the first paint so the app never
 * flashes the wrong colour scheme.
 */
const themeScript = `
(function () {
  try {
    var raw = localStorage.getItem('swati-studio-draft');
    var theme = 'dark';
    if (raw) {
      var parsed = JSON.parse(raw);
      theme = (parsed && parsed.state && parsed.state.theme) || 'dark';
    }
    var dark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.classList.toggle('dark', dark);
  } catch (e) {}
})();
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="font-sans">
        <ThemeSync />
        {children}
      </body>
    </html>
  );
}
