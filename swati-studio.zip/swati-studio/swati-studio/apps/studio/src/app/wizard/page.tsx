'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  AppWindow,
  ChevronLeft,
  ChevronRight,
  DollarSign,
  Keyboard,
  Layers,
  Menu,
  Moon,
  Package,
  Puzzle,
  Save,
  Search,
  Share2,
  Smartphone,
  Sparkles,
  Sun,
  Wand2,
} from 'lucide-react';
import {
  buildSummary,
  serializeConfig,
  steps,
  validateConfig,
  type AppTemplate,
  type FieldValue,
  type StudioConfig,
  type StudioPlugin,
} from '@swati/schema';
import { generateProject } from '@swati/generator';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Toaster } from '@/components/ui/Toaster';
import { ApplicationsDashboard } from '@/components/applications/ApplicationsDashboard';
import { ScreenBuilderView } from '@/components/screen-builder/ScreenBuilderView';
import { CommandPalette } from '@/components/wizard/CommandPalette';
import { GenerateModal } from '@/components/wizard/GenerateModal';
import { PhonePreview } from '@/components/wizard/PhonePreview';
import { PreviewPanel } from '@/components/wizard/PreviewPanel';
import { ReviewPanel } from '@/components/wizard/ReviewPanel';
import { StepContent } from '@/components/wizard/StepContent';
import { StepIcon } from '@/components/wizard/StepIcon';
import { Stepper } from '@/components/wizard/Stepper';
import { TemplateMarketplaceModal } from '@/components/wizard/TemplateMarketplaceModal';
import { AiWizardModal } from '@/components/wizard/AiWizardModal';
import { ProjectHealthModal } from '@/components/wizard/ProjectHealthModal';
import { CostEstimatorModal } from '@/components/wizard/CostEstimatorModal';
import { TeamCollabModal } from '@/components/wizard/TeamCollabModal';
import { PluginMarketplaceModal } from '@/components/wizard/PluginMarketplaceModal';
import { EnterpriseHubModal } from '@/components/wizard/EnterpriseHubModal';
import { RegenerationModal } from '@/components/wizard/RegenerationModal';
import { BrownfieldModal } from '@/components/wizard/BrownfieldModal';
import { SchemaDesignerModal } from '@/components/wizard/SchemaDesignerModal';
import { CrudScaffolderModal } from '@/components/wizard/CrudScaffolderModal';
import { PushNotificationsModal } from '@/components/wizard/PushNotificationsModal';
import { RemoteConfigModal } from '@/components/wizard/RemoteConfigModal';
import { BackendScaffoldModal } from '@/components/wizard/BackendScaffoldModal';
import { ComplianceModal } from '@/components/wizard/ComplianceModal';
import { UiStatesModal } from '@/components/wizard/UiStatesModal';
import { BrandingModal } from '@/components/wizard/BrandingModal';
import { MockDataModal } from '@/components/wizard/MockDataModal';
import { AccessibilityModal } from '@/components/wizard/AccessibilityModal';
import { PerformanceBudgetModal } from '@/components/wizard/PerformanceBudgetModal';
import { AutoDocsModal } from '@/components/wizard/AutoDocsModal';
import { ConfigAsCodeModal } from '@/components/wizard/ConfigAsCodeModal';
import {
  defaultOutputDir,
  detectToolchains,
  openPath,
  pickOutputDir,
  revealPath,
  saveNativeDraft,
  writeProject,
  runFlutterCreate,
  type ToolchainReport,
} from '@/lib/ipc';
import { screenExportService } from '@/lib/screenExportService';
import { useStudioStore } from '@/lib/store';
import { toast } from '@/lib/toast';
import { cn } from '@/lib/utils';

const SHORTCUTS = [
  { label: 'Next step', keys: 'Ctrl + →' },
  { label: 'Previous step', keys: 'Ctrl + ←' },
  { label: 'Save draft', keys: 'Ctrl + S' },
  { label: 'Generate project', keys: 'Ctrl + ⏎' },
  { label: 'Toggle theme', keys: 'Ctrl + Shift + L' },
  { label: 'Search', keys: 'Ctrl + K' },
  { label: 'Shortcuts help', keys: '?' },
];

const GENERATE_PHASES = [
  { id: 'scaffold', label: 'Scaffolding project structure' },
  { id: 'deps', label: 'Configuring dependencies' },
  { id: 'backend', label: 'Setting up backend integration' },
  { id: 'theme', label: 'Generating theme and components' },
  { id: 'finalise', label: 'Finalizing build configuration' },
];

export default function WizardPage() {
  const {
    config,
    currentStep,
    theme,
    sidebarCollapsed,
    lastResult,
    currentView,
    apps,
    screens,
    activeComponents,
    setCurrentView,
    saveCurrentApp,
    setValue,
    toggleInArray,
    goToStep,
    nextStep,
    prevStep,
    setTheme,
    toggleSidebar,
    setLastResult,
  } = useStudioStore();

  const [paletteOpen, setPaletteOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [templateMarketplaceOpen, setTemplateMarketplaceOpen] = useState(false);
  const [aiWizardOpen, setAiWizardOpen] = useState(false);
  const [healthModalOpen, setHealthModalOpen] = useState(false);
  const [costModalOpen, setCostModalOpen] = useState(false);
  const [teamCollabModalOpen, setTeamCollabModalOpen] = useState(false);
  const [pluginsModalOpen, setPluginsModalOpen] = useState(false);
  // Enterprise Part 2 Modals State (#26 to #40)
  const [enterpriseHubOpen, setEnterpriseHubOpen] = useState(false);
  const [regenModalOpen, setRegenModalOpen] = useState(false);
  const [brownfieldModalOpen, setBrownfieldModalOpen] = useState(false);
  const [schemaModalOpen, setSchemaModalOpen] = useState(false);
  const [crudModalOpen, setCrudModalOpen] = useState(false);
  const [pushModalOpen, setPushModalOpen] = useState(false);
  const [remoteConfigModalOpen, setRemoteConfigModalOpen] = useState(false);
  const [backendModalOpen, setBackendModalOpen] = useState(false);
  const [complianceModalOpen, setComplianceModalOpen] = useState(false);
  const [uiStatesModalOpen, setUiStatesModalOpen] = useState(false);
  const [brandingModalOpen, setBrandingModalOpen] = useState(false);
  const [mockDataModalOpen, setMockDataModalOpen] = useState(false);
  const [a11yModalOpen, setA11yModalOpen] = useState(false);
  const [perfBudgetModalOpen, setPerfBudgetModalOpen] = useState(false);
  const [autoDocsModalOpen, setAutoDocsModalOpen] = useState(false);
  const [configAsCodeModalOpen, setConfigAsCodeModalOpen] = useState(false);

  const handleSelectFeature = useCallback((featureId: number) => {
    switch (featureId) {
      case 26: setRegenModalOpen(true); break;
      case 27: setBrownfieldModalOpen(true); break;
      case 28: setSchemaModalOpen(true); break;
      case 29: setCrudModalOpen(true); break;
      case 30: setPushModalOpen(true); break;
      case 31: setRemoteConfigModalOpen(true); break;
      case 32: setBackendModalOpen(true); break;
      case 33: setComplianceModalOpen(true); break;
      case 34: setUiStatesModalOpen(true); break;
      case 35: setBrandingModalOpen(true); break;
      case 36: setMockDataModalOpen(true); break;
      case 37: setA11yModalOpen(true); break;
      case 38: setPerfBudgetModalOpen(true); break;
      case 39: setAutoDocsModalOpen(true); break;
      case 40: setConfigAsCodeModalOpen(true); break;
    }
  }, []);
  const [generating, setGenerating] = useState(false);
  const [phase, setPhase] = useState(0);
  const [progress, setProgress] = useState(0);
  const [finished, setFinished] = useState(false);
  const [toolchains, setToolchains] = useState<ToolchainReport | null>(null);
  const [autoFlutterCreate, setAutoFlutterCreate] = useState(false);
  const [runningFlutterCreate, setRunningFlutterCreate] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleApplyTemplate = useCallback((template: AppTemplate) => {
    for (const [key, val] of Object.entries(template.presetConfig)) {
      if (val !== undefined) setValue(key, val);
    }
  }, [setValue]);

  const handleApplyAiConfig = useCallback((configUpdates: Partial<StudioConfig>) => {
    for (const [key, val] of Object.entries(configUpdates)) {
      if (val !== undefined) setValue(key, val as FieldValue);
    }
  }, [setValue]);

  const handleInstallPlugin = useCallback((plugin: StudioPlugin) => {
    toast.success(`Configured ${plugin.name} integration!`);
  }, []);

  const issues = useMemo(() => validateConfig(config), [config]);
  const errors = useMemo(() => {
    const map: Record<string, string> = {};
    for (const issue of issues) {
      if (issue.severity === 'error' && !map[issue.field]) map[issue.field] = issue.message;
    }
    return map;
  }, [issues]);

  const step = steps[currentStep];
  const isDark = theme === 'dark';

  /* ---------------------------------------------------------- *
   * Output folder default + toolchain probe
   * ---------------------------------------------------------- */
  useEffect(() => {
    let cancelled = false;
    void defaultOutputDir().then((dir) => {
      if (cancelled) return;
      if (!config['output.dir']) {
        setValue('output.dir', dir);
      }
    });
    void detectToolchains().then((report) => {
      if (cancelled) return;
      setToolchains(report);
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const summary = useMemo(() => buildSummary(config), [config]);

  const chooseFolder = useCallback(async () => {
    const picked = await pickOutputDir();
    if (picked) {
      setValue('output.dir', picked);
      toast.success('Output folder updated.');
    }
  }, [setValue]);


  /* ---------------------------------------------------------- *
   * Run the generator pipeline
   * ---------------------------------------------------------- */
  const runGenerate = useCallback(async () => {
    // Audit defect #9: generation is only offered on the Review step.
    if (currentView !== 'wizard' || currentStep !== steps.length - 1) {
      toast.info(`Generation is offered on the Review step (step ${steps.length}).`);
      return;
    }
    if (generating) return;

    const errorList = issues.filter((i) => i.severity === 'error');
    if (errorList.length > 0) {
      toast.error(`Please fix ${errorList.length} error(s) before generating.`);
      const first = errorList[0];
      const targetStep = steps.findIndex((s) => s.fields.some((f) => f.id === first.field));
      if (targetStep >= 0) goToStep(targetStep);
      return;
    }

    setGenerating(true);
    setPhase(0);
    setProgress(5);
    setFinished(false);
    setLastResult(null);

    const tick = (index: number) => {
      setPhase(index);
      setProgress(Math.min(90, 10 + index * 18));
    };

    tick(0);
    await wait(180);

    let files: ReturnType<typeof generateProject>['files'] = [];
    try {
      const exportedScreens = screenExportService.exportScreens(screens);
      const result = generateProject(config, exportedScreens);
      files = result.files;
    } catch (error) {
      setGenerating(false);
      setLastResult({ ok: false, message: (error as Error).message });
      toast.error('Could not build the project tree.');
      return;
    }

    tick(1);
    await wait(160);
    tick(2);
    await wait(160);
    tick(3);
    await wait(160);
    tick(4);
    await wait(160);

    const projectName = String(config['project.name'] ?? 'app')
      .trim()
      .replace(/[^a-zA-Z0-9_-]+/g, '_');
    const outputDir = String(config['output.dir'] ?? '').trim();
    const createZip = config['output.createZip'] !== false;

    const written = await writeProject(files, outputDir, projectName, createZip);
    setProgress(100);
    setFinished(true);
    setLastResult({
      ok: written.ok,
      message: written.message,
      path: written.path,
    });
    if (written.ok) {
      toast.success(`Generated ${written.files} files.`);
      // Auto-save into Applications registry
      saveCurrentApp();

      if (autoFlutterCreate && toolchains?.flutter) {
        toast.info('Running flutter create for platform scaffolding...');
        try {
          const org = String(config['project.organization'] || 'com.example');
          const projectPath = outputDir ? `${outputDir}/${projectName}` : written.path;
          const fcRes = await runFlutterCreate(projectPath, org, projectName);
          if (fcRes) {
            toast.success('Native Android, iOS & Web platform folders created via flutter create!');
          }
        } catch (fcErr) {
          console.warn('flutter create error:', fcErr);
        }
      }
    } else {
      toast.error(written.message);
    }
  }, [config, screens, issues, autoFlutterCreate, toolchains, goToStep, setLastResult, saveCurrentApp, currentView, currentStep, generating]);

  const handleRunFlutterCreateManual = useCallback(async () => {
    const targetDir = String(config['output.dir'] ?? '').trim();
    const projectName = String(config['project.name'] ?? 'app')
      .trim()
      .replace(/[^a-zA-Z0-9_-]+/g, '_');
    const org = String(config['project.organization'] || 'com.example');

    if (!targetDir) {
      toast.error('Please specify an output directory first.');
      return;
    }
    setRunningFlutterCreate(true);
    toast.info('Executing flutter create...');
    try {
      const projectPath = `${targetDir}/${projectName}`;
      const res = await runFlutterCreate(projectPath, org, projectName);
      if (res) {
        toast.success('flutter create completed successfully!');
      } else {
        toast.error('flutter create returned an error or requires Tauri desktop app.');
      }
    } catch (err) {
      toast.error('Failed to run flutter create');
    } finally {
      setRunningFlutterCreate(false);
    }
  }, [config]);

  /** Header "Generate": jumps to the Review step first — generation lives there only. */
  const handleGenerateClick = useCallback(() => {
    if (currentView === 'wizard' && currentStep === steps.length - 1) {
      void runGenerate();
      return;
    }
    setCurrentView('wizard');
    goToStep(steps.length - 1);
    toast.info('Review your configuration, then generate.');
  }, [currentView, currentStep, goToStep, setCurrentView, runGenerate]);

  /* ---------------------------------------------------------- *
   * Keyboard shortcuts
   * ---------------------------------------------------------- */
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable);

      if (event.key === '?' && !event.ctrlKey && !event.metaKey && !typing) {
        event.preventDefault();
        setShortcutsOpen(true);
        return;
      }
      if (event.ctrlKey || event.metaKey) {
        if (event.key.toLowerCase() === 'k') {
          event.preventDefault();
          setPaletteOpen(true);
        }
        if (event.key.toLowerCase() === 's') {
          event.preventDefault();
          handleSave();
        }
        if (event.key === 'Enter') {
          event.preventDefault();
          void runGenerate();
        }
        if (event.shiftKey && event.key.toLowerCase() === 'l') {
          event.preventDefault();
          setTheme(isDark ? 'light' : 'dark');
        }
        if (event.key === 'ArrowRight') {
          event.preventDefault();
          nextStep();
        }
        if (event.key === 'ArrowLeft') {
          event.preventDefault();
          prevStep();
        }
      }
      if (event.key === 'Escape') {
        setPaletteOpen(false);
        setShortcutsOpen(false);
      }
    };

    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDark, nextStep, prevStep, setTheme, runGenerate]);

  const handleSave = useCallback(() => {
    // NOTE: 'swati-studio-draft' belongs to the zustand persist middleware,
    // which already writes a valid {state, version} envelope on every change.
    // Writing the flat config JSON here would clobber that envelope (the
    // original prototype's corrupt-draft bug, defect #2, in a new shape).
    const payload = serializeConfig(config);
    saveCurrentApp();
    void saveNativeDraft('draft.json', payload).then((ok) => {
      toast.success(ok ? 'Draft saved to disk & Applications.' : 'Saved to Applications.');
    });
  }, [config, saveCurrentApp]);

  const handleExport = useCallback(() => {
    const payload = serializeConfig(config);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${String(config['project.name'] ?? 'swati-app')
      .toLowerCase()
      .replace(/\s+/g, '-')}-config.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success('Configuration exported.');
  }, [config]);

  return (
    <div className="flex h-screen overflow-hidden">
      {/* ---------------------------------------------------------- *
       * Sidebar
       * ---------------------------------------------------------- */}
      <aside
        className={cn(
          'glass z-20 flex shrink-0 flex-col border-r border-gray-200 transition-all duration-300 dark:border-slate-800',
          sidebarCollapsed ? 'w-[72px]' : 'w-64',
        )}
      >
        <div className="flex items-center gap-3 border-b border-gray-200 p-4 dark:border-slate-800">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg">
            <Wand2 className="h-5 w-5 text-white" />
          </div>
          {!sidebarCollapsed ? (
            <div className="transition-opacity duration-200">
              <h1 className="text-sm font-bold tracking-tight">Swati Studio</h1>
              <p className="text-[10px] text-gray-500 dark:text-gray-400">Flutter App Builder</p>
            </div>
          ) : null}
          <button
            type="button"
            onClick={toggleSidebar}
            className="ml-auto rounded-lg p-1.5 transition hover:bg-gray-200 lg:hidden dark:hover:bg-slate-700"
            aria-label="Toggle sidebar"
          >
            <Menu className="h-4 w-4" />
          </button>
        </div>

        {/* Top Primary Navigation: Applications & Screen Builder */}
        <div className="border-b border-gray-200 px-3 py-3 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setCurrentView('applications')}
            className={cn(
              'sidebar-link flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition',
              currentView === 'applications'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-slate-800',
            )}
            title="View all applications"
          >
            <div className="flex items-center gap-3">
              <AppWindow className="h-5 w-5 shrink-0" />
              {!sidebarCollapsed ? <span>Applications</span> : null}
            </div>
            {!sidebarCollapsed ? (
              <span
                className={cn(
                  'rounded-full px-2 py-0.5 text-[10px] font-bold',
                  currentView === 'applications'
                    ? 'bg-white/20 text-white'
                    : 'bg-gray-200 text-gray-700 dark:bg-slate-700 dark:text-gray-300',
                )}
              >
                {apps.length}
              </span>
            ) : null}
          </button>

          <button
            type="button"
            onClick={() => setCurrentView('screen_builder')}
            className={cn(
              'sidebar-link mt-1.5 flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition',
              currentView === 'screen_builder'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-slate-800',
            )}
            title="Visual Screen Builder"
          >
            <div className="flex items-center gap-3">
              <Smartphone className="h-5 w-5 shrink-0" />
              {!sidebarCollapsed ? <span>Screen Builder</span> : null}
            </div>
            {!sidebarCollapsed ? (
              <span
                className={cn(
                  'rounded-full px-2 py-0.5 text-[10px] font-bold',
                  currentView === 'screen_builder'
                    ? 'bg-white/20 text-white'
                    : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300',
                )}
              >
                {activeComponents.length}
              </span>
            ) : null}
          </button>

          <button
            type="button"
            onClick={() => setEnterpriseHubOpen(true)}
            className="sidebar-link mt-1.5 flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-slate-800"
            title="Enterprise Suite (#26 to #40)"
          >
            <div className="flex items-center gap-3">
              <Layers className="h-5 w-5 shrink-0 text-purple-500" />
              {!sidebarCollapsed ? <span>Enterprise Suite</span> : null}
            </div>
            {!sidebarCollapsed ? (
              <span className="rounded-full bg-gradient-to-r from-purple-500 to-indigo-600 px-2 py-0.5 text-[10px] font-bold text-white">
                15 Tools
              </span>
            ) : null}
          </button>
        </div>

        {/* Wizard Steps Navigation */}
        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-3">
          <p className="mb-2 px-3 text-xs font-semibold tracking-wider text-gray-400 uppercase dark:text-gray-500">
            {!sidebarCollapsed ? 'Setup Wizard' : null}
          </p>
          {steps.map((item, index) => {
            const isStepActive = currentView === 'wizard' && index === currentStep;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setCurrentView('wizard');
                  goToStep(index);
                }}
                className={cn(
                  'sidebar-link flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm font-medium transition',
                  isStepActive
                    ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400'
                    : 'text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-slate-800',
                  isStepActive && 'active',
                )}
              >
                <StepIcon name={item.icon} className="h-5 w-5 shrink-0" />
                {!sidebarCollapsed ? <span>{item.label}</span> : null}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-gray-200 p-4 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-cyan-500 text-xs font-bold text-white">
              SS
            </div>
            {!sidebarCollapsed ? (
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">Swati Studio</p>
                <p className="truncate text-xs text-gray-500 dark:text-gray-400">Local workspace</p>
              </div>
            ) : null}
          </div>
        </div>
      </aside>

      {/* ---------------------------------------------------------- *
       * Main Column: Conditional Views (Applications, Screen Builder, or Wizard)
       * ---------------------------------------------------------- */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        {currentView === 'applications' ? (
          <ApplicationsDashboard />
        ) : currentView === 'screen_builder' ? (
          <ScreenBuilderView />
        ) : (
          /* ======================================================= */
          /* WIZARD SETUP VIEW */
          /* ======================================================= */
          <>
            <header className="glass sticky top-0 z-30 border-b border-gray-200 px-4 py-3 sm:px-6 dark:border-slate-800">
              <div className="flex items-center justify-between gap-4">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <button
                    type="button"
                    onClick={toggleSidebar}
                    className="hidden rounded-lg p-2 transition hover:bg-gray-200 lg:flex dark:hover:bg-slate-700"
                    aria-label="Toggle sidebar"
                  >
                    <Menu className="h-5 w-5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaletteOpen(true)}
                    className="flex max-w-md flex-1 items-center gap-2 rounded-lg bg-gray-100 px-3 py-1.5 text-sm text-gray-500 transition hover:bg-gray-200 dark:bg-slate-800 dark:text-gray-400 dark:hover:bg-slate-700"
                  >
                    <Search className="h-4 w-4" />
                    <span className="hidden sm:inline">Search project settings…</span>
                    <kbd className="ml-auto hidden rounded border bg-white px-1.5 py-0.5 font-mono text-[10px] sm:block dark:bg-slate-700">
                      Ctrl+K
                    </kbd>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setTheme(isDark ? 'light' : 'dark')}
                    className="rounded-lg p-2 transition hover:bg-gray-200 dark:hover:bg-slate-700"
                    aria-label="Toggle theme"
                  >
                    {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShortcutsOpen(true)}
                    className="hidden rounded-lg p-2 transition hover:bg-gray-200 sm:block dark:hover:bg-slate-700"
                    aria-label="Keyboard shortcuts"
                  >
                    <Keyboard className="h-5 w-5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setTemplateMarketplaceOpen(true)}
                    className="flex items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50/80 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 transition hover:bg-indigo-100 sm:px-3 dark:border-indigo-800/60 dark:bg-indigo-950/40 dark:text-indigo-300"
                    title="Browse Enterprise App Templates (Step 0)"
                  >
                    <Package className="h-4 w-4" />
                    <span className="hidden sm:inline">Templates</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setAiWizardOpen(true)}
                    className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 px-2.5 py-1.5 text-xs font-semibold text-white shadow-xs transition hover:opacity-90 sm:px-3"
                    title="AI-Powered Smart Wizard"
                  >
                    <Sparkles className="h-4 w-4" />
                    <span className="hidden sm:inline">AI Wizard</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setHealthModalOpen(true)}
                    className="hidden xl:flex items-center gap-1.5 rounded-lg border border-gray-200 px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 dark:border-slate-800 dark:text-gray-300 dark:hover:bg-slate-800"
                    title="Project Health Dashboard"
                  >
                    <Activity className="h-3.5 w-3.5 text-indigo-500" />
                    <span>Health</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCostModalOpen(true)}
                    className="hidden xl:flex items-center gap-1.5 rounded-lg border border-gray-200 px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 dark:border-slate-800 dark:text-gray-300 dark:hover:bg-slate-800"
                    title="Smart Cost Estimation"
                  >
                    <DollarSign className="h-3.5 w-3.5 text-emerald-500" />
                    <span>Cost</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setTeamCollabModalOpen(true)}
                    className="hidden lg:flex items-center gap-1.5 rounded-lg border border-gray-200 px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 dark:border-slate-800 dark:text-gray-300 dark:hover:bg-slate-800"
                    title="Team Collaboration & Share"
                  >
                    <Share2 className="h-3.5 w-3.5 text-blue-500" />
                    <span>Share</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEnterpriseHubOpen(true)}
                    className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 px-2.5 py-1.5 text-xs font-semibold text-white shadow-xs transition hover:opacity-90 sm:px-3"
                    title="Enterprise Suite (Part 2: Features #26–#40)"
                  >
                    <Layers className="h-4 w-4" />
                    <span>Enterprise #26–#40</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPluginsModalOpen(true)}
                    className="hidden lg:flex items-center gap-1.5 rounded-lg border border-gray-200 px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 dark:border-slate-800 dark:text-gray-300 dark:hover:bg-slate-800"
                    title="Plugin Marketplace"
                  >
                    <Puzzle className="h-3.5 w-3.5 text-purple-500" />
                    <span>Plugins</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSave}
                    className="hidden items-center gap-2 rounded-lg border border-gray-200 px-3 py-1.5 text-sm font-medium text-gray-600 transition hover:bg-gray-100 sm:flex dark:border-slate-700 dark:text-gray-300 dark:hover:bg-slate-800"
                  >
                    <Save className="h-4 w-4" />
                    Save Draft
                  </button>
                  <Button onClick={handleGenerateClick} size="sm" className="h-9 px-4">
                    <Wand2 className="h-4 w-4" />
                    <span className="hidden sm:inline">Generate</span>
                  </Button>
                </div>
              </div>
            </header>

            <main className="flex min-h-0 flex-1 overflow-hidden">
              <div ref={containerRef} className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
                <div className="mb-8 overflow-x-auto pb-2">
                  <Stepper currentStep={currentStep} onSelect={goToStep} />
                </div>

                <div className="mx-auto max-w-5xl">
                  {step.panel === 'preview' ? (
                    <PreviewPanel config={config} />
                  ) : (
                    <StepContent
                      stepIndex={currentStep}
                      config={config}
                      errors={errors}
                      onChange={(id: string, value: FieldValue) => setValue(id, value)}
                      onToggle={(id: string, value: string) => toggleInArray(id, value)}
                    />
                  )}

                  {step.panel === 'review' ? (
                    <div className="mt-10 space-y-8">
                      {/* Prominent Quick Jump to Applications & Screen Builder */}
                      <div className="rounded-2xl border border-indigo-200 bg-gradient-to-r from-indigo-50/90 to-purple-50/90 p-5 dark:border-indigo-500/30 dark:from-indigo-950/40 dark:to-purple-950/40">
                        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-md">
                              <Smartphone className="h-6 w-6" />
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-gray-900 dark:text-white">
                                All Setup Steps Complete!
                              </h4>
                              <p className="text-xs text-gray-600 dark:text-gray-300">
                                View this app in <strong>Applications</strong> or launch <strong>Screen Builder</strong> to visually add, update, and delete Flutter screen components.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                saveCurrentApp();
                                setCurrentView('applications');
                              }}
                              className="gap-1.5 text-xs font-semibold"
                            >
                              <AppWindow className="h-3.5 w-3.5" />
                              Applications
                            </Button>
                            <Button
                              type="button"
                              variant="primary"
                              size="sm"
                              onClick={() => {
                                saveCurrentApp();
                                setCurrentView('screen_builder');
                              }}
                              className="gap-1.5 text-xs font-semibold shadow-md"
                            >
                              <Smartphone className="h-3.5 w-3.5" />
                              Screen Builder
                            </Button>
                          </div>
                        </div>
                      </div>

                      <ReviewPanel config={config} lastResult={lastResult} />

                      {/* Output destination + toolchain */}
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-slate-700 dark:bg-slate-800">
                          <p className="text-xs text-gray-500 dark:text-gray-400">Output destination</p>
                          <p className="mt-1 break-all font-mono text-xs">
                            {String(config['output.dir'] ?? '') || 'not set'}
                          </p>
                          <div className="mt-3 flex flex-wrap gap-2">
                            <Button variant="secondary" size="sm" onClick={() => void chooseFolder()}>
                              Choose folder…
                            </Button>
                            <Button
                              variant="secondary"
                              size="sm"
                              onClick={() => {
                                const target = String(config['output.dir'] ?? '');
                                if (target) void openPath(target);
                              }}
                            >
                              Open
                            </Button>
                            <Button
                              variant="secondary"
                              size="sm"
                              onClick={() => {
                                const target = String(config['output.dir'] ?? '');
                                if (target) void revealPath(target);
                              }}
                            >
                              Reveal
                            </Button>
                          </div>
                        </div>

                        <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-slate-700 dark:bg-slate-800">
                          <p className="text-xs text-gray-500 dark:text-gray-400">Detected toolchains</p>
                          {toolchains ? (
                            <ul className="mt-2 space-y-1 font-mono text-xs">
                              {(
                                [
                                  ['flutter', toolchains.flutter],
                                  ['dart', toolchains.dart],
                                  ['node', toolchains.node],
                                  ['rustc', toolchains.rustc],
                                ] as const
                              ).map(([name, value]) => (
                                <li key={name} className="flex justify-between gap-3">
                                  <span className="text-gray-500 dark:text-gray-400">{name}</span>
                                  <span className={value ? 'truncate' : 'text-gray-400'}>
                                    {value ?? 'not found'}
                                  </span>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="mt-2 text-xs text-gray-400">
                              Run the desktop app to detect Flutter, Dart, Node and Rust.
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Native Platform Scaffolding (flutter create toggle & trigger) */}
                      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-slate-700 dark:bg-slate-800">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white">
                              Native Platform Scaffolding (flutter create)
                            </h4>
                            <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                              Generate native <code>android/</code>, <code>ios/</code>, <code>web/</code>, and <code>windows/</code> runner projects.
                            </p>
                          </div>
                          <div className="flex items-center gap-3">
                            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
                              <input
                                type="checkbox"
                                checked={autoFlutterCreate}
                                onChange={(e) => setAutoFlutterCreate(e.target.checked)}
                                className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                              />
                              <span>Auto-run on Generate</span>
                            </label>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => void handleRunFlutterCreateManual()}
                              disabled={runningFlutterCreate}
                              className="text-xs font-semibold"
                            >
                              {runningFlutterCreate ? 'Running...' : 'Run flutter create now'}
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap justify-center gap-3 pt-2">
                        <Button onClick={() => void runGenerate()}>
                          <Wand2 className="h-5 w-5" />
                          Generate Project
                        </Button>
                        <Button variant="outline" onClick={() => setRegenModalOpen(true)}>
                          <RefreshCw className="h-4 w-4 mr-1.5" />
                          🔁 Dry Run & Regen Preview (#26)
                        </Button>
                        <Button variant="secondary" onClick={handleExport}>
                          Export Config
                        </Button>
                        <Button variant="secondary" onClick={handleSave}>
                          <Save className="h-5 w-5" />
                          Save as Template
                        </Button>
                      </div>
                    </div>
                  ) : null}
                </div>

                <div className="mx-auto mt-8 flex max-w-5xl items-center justify-between">
                  <Button
                    variant="secondary"
                    onClick={prevStep}
                    disabled={currentStep === 0}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Button>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      Step {currentStep + 1} of {steps.length}
                    </span>
                    <Button onClick={nextStep} disabled={currentStep === steps.length - 1}>
                      Next
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="h-20" />
              </div>

              {/* Live preview panel */}
              <div className="glass phone-preview-panel hidden w-[360px] shrink-0 flex-col border-l border-gray-200 xl:flex dark:border-slate-800">
                <div className="flex items-center justify-between border-b border-gray-200 p-4 dark:border-slate-800">
                  <h3 className="text-sm font-semibold">Live Preview</h3>
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
                    <span className="text-xs text-gray-500 dark:text-gray-400">Auto-updating</span>
                  </div>
                </div>
                <div className="flex flex-1 items-start justify-center overflow-y-auto p-6">
                  <div className="phone-mockup h-[560px] w-[280px] shrink-0 bg-slate-900">
                    <div className="phone-screen h-full w-full">
                      <PhonePreview config={config} dark={isDark} stepIndex={currentStep} />
                    </div>
                  </div>
                </div>
                <div className="space-y-3 border-t border-gray-200 p-4 dark:border-slate-800">
                  {summary.slice(0, 3).map((row) => (
                    <div key={row.label} className="flex justify-between text-xs">
                      <span className="text-gray-500 dark:text-gray-400">{row.label}</span>
                      <span className="font-mono font-medium">{row.value}</span>
                    </div>
                  ))}
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500 dark:text-gray-400">Features</span>
                    <span className="font-mono font-medium">{summary[10]?.value}</span>
                  </div>
                </div>
              </div>
            </main>
          </>
        )}
      </div>

      <CommandPalette
        open={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        onSelectStep={(idx) => {
          setCurrentView('wizard');
          goToStep(idx);
        }}
        onOpenTemplates={() => setTemplateMarketplaceOpen(true)}
        onOpenAiWizard={() => setAiWizardOpen(true)}
        onOpenHealth={() => setHealthModalOpen(true)}
        onOpenCost={() => setCostModalOpen(true)}
        onOpenTeamCollab={() => setTeamCollabModalOpen(true)}
        onOpenPlugins={() => setPluginsModalOpen(true)}
        onOpenRegeneration={() => setRegenModalOpen(true)}
        onOpenBrownfield={() => setBrownfieldModalOpen(true)}
        onOpenSchemaDesigner={() => setSchemaModalOpen(true)}
        onOpenCrudScaffolder={() => setCrudModalOpen(true)}
        onOpenPushNotifications={() => setPushModalOpen(true)}
        onOpenRemoteConfig={() => setRemoteConfigModalOpen(true)}
        onOpenBackendScaffold={() => setBackendModalOpen(true)}
        onOpenCompliance={() => setComplianceModalOpen(true)}
        onOpenUiStates={() => setUiStatesModalOpen(true)}
        onOpenBranding={() => setBrandingModalOpen(true)}
        onOpenMockData={() => setMockDataModalOpen(true)}
        onOpenAccessibility={() => setA11yModalOpen(true)}
        onOpenPerfBudget={() => setPerfBudgetModalOpen(true)}
        onOpenAutoDocs={() => setAutoDocsModalOpen(true)}
        onOpenConfigAsCode={() => setConfigAsCodeModalOpen(true)}
      />

      <Modal
        open={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
        title="Keyboard Shortcuts"
        description="Speed up your workflow"
      >
        <div className="space-y-3">
          {SHORTCUTS.map((item) => (
            <div
              key={item.label}
              className="flex items-center justify-between border-b border-gray-200 py-2 dark:border-slate-700"
            >
              <span className="text-sm">{item.label}</span>
              <kbd className="rounded border bg-gray-100 px-2 py-1 font-mono text-xs dark:bg-slate-800">
                {item.keys}
              </kbd>
            </div>
          ))}
        </div>
      </Modal>

      <GenerateModal
        open={generating}
        onClose={() => setGenerating(false)}
        phases={GENERATE_PHASES}
        activePhase={phase}
        progress={progress}
        finished={finished}
      />

      <TemplateMarketplaceModal
        open={templateMarketplaceOpen}
        onClose={() => setTemplateMarketplaceOpen(false)}
        onApplyTemplate={handleApplyTemplate}
      />

      <AiWizardModal
        open={aiWizardOpen}
        onClose={() => setAiWizardOpen(false)}
        onApplyConfig={handleApplyAiConfig}
      />

      <ProjectHealthModal
        open={healthModalOpen}
        onClose={() => setHealthModalOpen(false)}
        config={config}
      />

      <CostEstimatorModal
        open={costModalOpen}
        onClose={() => setCostModalOpen(false)}
        config={config}
      />

      <TeamCollabModal
        open={teamCollabModalOpen}
        onClose={() => setTeamCollabModalOpen(false)}
        config={config}
        onApplyConfig={handleApplyAiConfig}
      />

      <PluginMarketplaceModal
        open={pluginsModalOpen}
        onClose={() => setPluginsModalOpen(false)}
        config={config}
        onInstallPlugin={handleInstallPlugin}
      />

      <EnterpriseHubModal
        open={enterpriseHubOpen}
        onClose={() => setEnterpriseHubOpen(false)}
        onSelectFeature={handleSelectFeature}
      />

      <RegenerationModal
        open={regenModalOpen}
        onClose={() => setRegenModalOpen(false)}
      />

      <BrownfieldModal
        open={brownfieldModalOpen}
        onClose={() => setBrownfieldModalOpen(false)}
      />

      <SchemaDesignerModal
        open={schemaModalOpen}
        onClose={() => setSchemaModalOpen(false)}
      />

      <CrudScaffolderModal
        open={crudModalOpen}
        onClose={() => setCrudModalOpen(false)}
      />

      <PushNotificationsModal
        open={pushModalOpen}
        onClose={() => setPushModalOpen(false)}
      />

      <RemoteConfigModal
        open={remoteConfigModalOpen}
        onClose={() => setRemoteConfigModalOpen(false)}
      />

      <BackendScaffoldModal
        open={backendModalOpen}
        onClose={() => setBackendModalOpen(false)}
      />

      <ComplianceModal
        open={complianceModalOpen}
        onClose={() => setComplianceModalOpen(false)}
      />

      <UiStatesModal
        open={uiStatesModalOpen}
        onClose={() => setUiStatesModalOpen(false)}
      />

      <BrandingModal
        open={brandingModalOpen}
        onClose={() => setBrandingModalOpen(false)}
      />

      <MockDataModal
        open={mockDataModalOpen}
        onClose={() => setMockDataModalOpen(false)}
      />

      <AccessibilityModal
        open={a11yModalOpen}
        onClose={() => setA11yModalOpen(false)}
      />

      <PerformanceBudgetModal
        open={perfBudgetModalOpen}
        onClose={() => setPerfBudgetModalOpen(false)}
      />

      <AutoDocsModal
        open={autoDocsModalOpen}
        onClose={() => setAutoDocsModalOpen(false)}
      />

      <ConfigAsCodeModal
        open={configAsCodeModalOpen}
        onClose={() => setConfigAsCodeModalOpen(false)}
      />

      <Toaster />
    </div>
  );
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
