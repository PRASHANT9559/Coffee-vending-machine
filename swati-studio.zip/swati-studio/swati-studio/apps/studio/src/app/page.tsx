'use client';

import Link from 'next/link';
import { ArrowRight, Command, Layers, Sparkles, Terminal as TerminalIcon, Wand2 } from 'lucide-react';
import { Select } from '@/components/ui/Select';
import { homeStyles } from '@swati/schema';
import { useStudioStore } from '@/lib/store';

/**
 * The landing page.
 *
 * The style dropdown at the top right re-skins this entire page live —
 * the exact same value that is written into the generated project.
 */
export default function HomePage() {
  const config = useStudioStore((s) => s.config);
  const setValue = useStudioStore((s) => s.setValue);
  const theme = useStudioStore((s) => s.theme);
  const setTheme = useStudioStore((s) => s.setTheme);

  const style = String(config['project.homeStyle'] ?? 'studio');
  const isDark = theme === 'dark';

  return (
    <div className="relative min-h-screen overflow-hidden">
      {style === 'glass' ? <div className="aurora" /> : null}

      <div className="relative z-10">
        {/* ---------------------------------------------------------- *
         * Nav
         * ---------------------------------------------------------- */}
        <header className="sticky top-0 z-40 border-b border-gray-200/60 bg-white/70 backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-950/70">
          <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 sm:px-6">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg">
                <Wand2 className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold tracking-tight">Swati Studio</p>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Schema-driven app builder</p>
              </div>
            </div>

            <div className="ml-auto flex items-center gap-2">
              <div className="hidden sm:block">
                <Select
                  value={style}
                  options={homeStyles}
                  onChange={(id) => setValue('project.homeStyle', id)}
                  searchable={false}
                  showAccent
                />
              </div>
              <Link
                href="/wizard"
                className="inline-flex h-8 items-center gap-2 rounded-lg border border-gray-300 px-3 text-xs font-medium text-gray-700 transition hover:bg-gray-100 dark:border-slate-600 dark:text-gray-200 dark:hover:bg-slate-800"
              >
                Open wizard
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </header>

        {/* ---------------------------------------------------------- *
         * Hero — one layout per style
         * ---------------------------------------------------------- */}
        <main>
          {style === 'terminal' ? (
            <TerminalHero />
          ) : style === 'bento' ? (
            <BentoHero />
          ) : style === 'editorial' ? (
            <EditorialHero />
          ) : style === 'minimal' ? (
            <MinimalHero />
          ) : (
            <StudioHero />
          )}

          {/* -------------------------------------------------------- *
           * Feature grid
           * -------------------------------------------------------- */}
          <section id="how" className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
            <div className="mb-12 text-center">
              <p className="mb-3 text-xs font-semibold tracking-[0.2em] text-indigo-600 uppercase dark:text-indigo-400">
                How it works
              </p>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Add a choice. Not a component.
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-gray-600 dark:text-gray-400">
                Every option in Swati Studio is a data object. Add a backend, a database or a
                feature and the dropdown, the validation, the review card and the generated
                project all update on their own.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  icon: Layers,
                  title: 'One schema drives everything',
                  body: 'Steps, fields, options and dependencies are declared in packages/schema. The UI is a generic renderer.',
                },
                {
                  icon: TerminalIcon,
                  title: 'Real output, not a mockup',
                  body: 'The generator writes a compiling Flutter project: pubspec, theme, routes, features, tests.',
                },
                {
                  icon: Sparkles,
                  title: 'Native desktop shell',
                  body: 'Tauri v2 + Rust handles file writing, zipping, toolchain detection and native dialogs.',
                },
                {
                  icon: Command,
                  title: 'Keyboard first',
                  body: 'Ctrl+K palette, Ctrl+S draft, Ctrl+⏎ generate. Every step is reachable without a mouse.',
                },
                {
                  icon: Wand2,
                  title: 'Live phone preview',
                  body: 'Theme, font, radius and spacing changes are reflected in the mockup while you type.',
                },
                {
                  icon: ArrowRight,
                  title: 'Portable configuration',
                  body: 'Export the wizard state as JSON and replay it on another machine, or save it as a template.',
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="card-hover rounded-2xl border border-gray-200 bg-white p-6 dark:border-slate-700 dark:bg-slate-800/60"
                >
                  <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-500/10">
                    <item.icon className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <h3 className="mb-2 font-semibold">{item.title}</h3>
                  <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-400">
                    {item.body}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* -------------------------------------------------------- *
           * Stack
           * -------------------------------------------------------- */}
          <section className="border-y border-gray-200 bg-gray-100/60 dark:border-slate-800/60 dark:bg-slate-900/40">
            <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
              <h2 className="mb-8 text-center text-2xl font-bold tracking-tight">
                Built with the boring-but-solid stack
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  ['Next.js 15', 'App Router + static export'],
                  ['Tauri v2', 'Native shell, ~10 MB installer'],
                  ['Rust', 'File IO, zip, toolchain detection'],
                  ['Tailwind v4', 'CSS-first theming, no config file'],
                ].map(([title, body]) => (
                  <div
                    key={title}
                    className="rounded-xl border border-gray-200 bg-white p-4 text-center dark:border-slate-700 dark:bg-slate-800"
                  >
                    <p className="text-sm font-semibold">{title}</p>
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{body}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <footer className="mx-auto max-w-6xl px-4 py-10 text-center text-sm text-gray-500 sm:px-6 dark:text-gray-400">
          Swati Studio — MIT licensed. Generated projects carry the license you pick in the wizard.
        </footer>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Style variants
 * ------------------------------------------------------------------ */

function StudioHero() {
  return (
    <section className="mx-auto max-w-6xl px-4 pt-20 pb-16 sm:px-6">
      <div className="text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-medium text-indigo-600 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-400">
          <Sparkles className="h-3.5 w-3.5" />
          Schema-driven generation
        </span>
        <h1 className="mt-6 text-4xl font-extrabold tracking-tight sm:text-6xl">
          Stop writing the same <span className="gradient-text">boilerplate</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-gray-600 dark:text-gray-400">
          Describe the app you want. Swati Studio generates a real, compiling Flutter project —
          and it does it from a config file, not from hand-written UI.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Link
            href="/wizard"
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-7 py-3 text-sm font-medium text-white shadow-lg shadow-indigo-500/25 transition hover:from-indigo-500 hover:to-purple-500"
          >
            Start the wizard
            <ArrowRight className="h-4 w-4" />
          </Link>
          <a
            href="#how"
            className="inline-flex items-center gap-2 rounded-xl border border-gray-300 px-7 py-3 text-sm font-medium transition hover:bg-gray-100 dark:border-slate-600 dark:hover:bg-slate-800"
          >
            See how it works
          </a>
        </div>
      </div>

      <div className="mx-auto mt-16 max-w-4xl overflow-hidden rounded-2xl border border-gray-200 bg-gray-900 shadow-2xl dark:border-slate-700">
        <div className="flex items-center gap-2 border-b border-gray-800 px-4 py-2.5">
          <span className="h-3 w-3 rounded-full bg-red-500/80" />
          <span className="h-3 w-3 rounded-full bg-yellow-500/80" />
          <span className="h-3 w-3 rounded-full bg-green-500/80" />
          <span className="ml-3 font-mono text-xs text-gray-500">swati-studio</span>
        </div>
        <pre className="overflow-x-auto p-5 font-mono text-xs leading-relaxed text-gray-300">
{`// packages/schema/src/catalogs/backends.ts
export const backends: OptionDef[] = [
  {
    id: 'supabase',
    name: 'Supabase',
    desc: 'Open-source Firebase alternative on PostgreSQL',
    fields: [
      { id: 'backend.supabase.url', kind: 'text', label: 'Project URL' },
      { id: 'backend.supabase.anonKey', kind: 'text', label: 'Anon Key' },
    ],
  },
  // + 10 more backends
];`}
        </pre>
      </div>
    </section>
  );
}

function TerminalHero() {
  return (
    <section className="mx-auto max-w-4xl px-4 pt-16 pb-16 sm:px-6">
      <div className="overflow-hidden rounded-2xl border border-gray-700 bg-gray-950 shadow-2xl">
        <div className="flex items-center gap-2 border-b border-gray-800 px-4 py-2.5">
          <span className="h-3 w-3 rounded-full bg-red-500/80" />
          <span className="h-3 w-3 rounded-full bg-yellow-500/80" />
          <span className="h-3 w-3 rounded-full bg-green-500/80" />
          <span className="ml-3 font-mono text-xs text-gray-500">~/swati-studio</span>
        </div>
        <pre className="overflow-x-auto p-6 font-mono text-sm leading-relaxed text-emerald-400">
{`$ swati studio init

  ✓ schema loaded      10 steps · 74 options
  ✓ catalog resolved   backends · databases · features
  ✓ generator ready    flutter · 6 architectures

$ swati studio generate --out ./my_app

  → lib/main.dart
  → lib/core/theme/app_theme.dart
  → lib/features/home/presentation/home_page.dart
  → pubspec.yaml
  → README.md

  done in 1.4s · 27 files`}
        </pre>
      </div>
    </section>
  );
}

function BentoHero() {
  return (
    <section className="mx-auto max-w-6xl px-4 pt-16 pb-16 sm:px-6">
      <div className="grid gap-4 md:grid-cols-3 md:grid-rows-2">
        <div className="md:col-span-2 md:row-span-2 flex flex-col justify-center rounded-3xl border border-gray-200 bg-white p-8 dark:border-slate-700 dark:bg-slate-800/60">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl">
            A wizard that <span className="gradient-text">actually writes code</span>
          </h1>
          <p className="mt-4 max-w-lg text-gray-600 dark:text-gray-400">
            Every option is data. The renderer, the validator and the generator read the same
            source of truth.
          </p>
          <Link
            href="/wizard"
            className="mt-7 inline-flex w-fit items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-3 text-sm font-medium text-white"
          >
            Open the wizard <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        {[
          { title: 'Tauri v2 + Rust', body: 'Native shell, real file IO.' },
          { title: 'Next.js + Tailwind', body: 'One generic field renderer.' },
          { title: 'Schema first', body: 'Add options without touching UI.' },
          { title: 'Versioned output', body: 'Every project gets a config manifest.' },
        ].map((tile) => (
          <div
            key={tile.title}
            className="card-hover flex flex-col justify-center rounded-3xl border border-gray-200 bg-white p-6 dark:border-slate-700 dark:bg-slate-800/60"
          >
            <h3 className="font-semibold">{tile.title}</h3>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">{tile.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function EditorialHero() {
  return (
    <section className="mx-auto max-w-4xl px-4 pt-20 pb-16 sm:px-6">
      <p className="text-xs font-semibold tracking-[0.3em] text-indigo-600 uppercase dark:text-indigo-400">
        Issue 01
      </p>
      <h1 className="mt-6 text-5xl leading-[1.05] font-extrabold tracking-tight sm:text-7xl">
        The boring part of app building, finally automated.
      </h1>
      <p className="mt-6 max-w-2xl text-lg text-gray-600 dark:text-gray-400">
        Pick a stack, pick a style, and let the generator do the rest. You keep the interesting
        code — the business logic — and the tool keeps the scaffolding.
      </p>
      <div className="mt-10 flex flex-wrap items-center gap-4">
        <Link
          href="/wizard"
          className="inline-flex items-center gap-2 border-b-2 border-indigo-600 pb-1 text-lg font-semibold text-indigo-600 dark:text-indigo-400"
        >
          Read the wizard <ArrowRight className="h-5 w-5" />
        </Link>
        <span className="text-sm text-gray-500 dark:text-gray-400">~4 min</span>
      </div>
    </section>
  );
}

function MinimalHero() {
  return (
    <section className="mx-auto max-w-2xl px-4 pt-24 pb-20 sm:px-6">
      <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">Swati Studio</h1>
      <p className="mt-6 text-lg leading-relaxed text-gray-600 dark:text-gray-400">
        A wizard that generates a real Flutter project from a configuration. Open it, pick your
        stack, and the files appear on your disk.
      </p>
      <Link
        href="/wizard"
        className="mt-10 inline-flex items-center gap-2 text-sm font-medium underline underline-offset-4"
      >
        Open the wizard <ArrowRight className="h-4 w-4" />
      </Link>
    </section>
  );
}
