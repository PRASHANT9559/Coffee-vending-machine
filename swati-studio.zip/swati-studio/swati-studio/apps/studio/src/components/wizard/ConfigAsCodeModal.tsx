'use client';

import { useState } from 'react';
import {
  Terminal,
  FileCode,
  Copy,
  Download,
  CheckCircle2,
  Workflow,
  Sparkles,
  Layers,
  Code,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface ConfigAsCodeModalProps {
  open: boolean;
  onClose: () => void;
  configYaml?: string;
}

const DEFAULT_SWATI_YAML = `# Swati Studio Configuration File (Config-as-Code)
# Source of truth version-controlled in Git repository
schemaVersion: 3

app:
  name: "MyShop"
  package: "com.example.myshop"
  description: "Enterprise multi-platform Flutter application"

stack:
  state: riverpod
  backend: supabase
  architecture: feature_first
  theme: material_you

features:
  auth:
    enabled: true
    methods:
      - email_password
      - google_oauth
      - biometric
  push:
    enabled: true
    provider: fcm
  remoteConfig:
    enabled: true
    cacheTtlHours: 1
  crud:
    scaffoldProducts: true
  compliance:
    gdpr: true
    dpdp: true
    deleteAccountFlow: true
  offline:
    enabled: true
  sizeBudgetMb: 25

environments:
  - dev
  - staging
  - prod
`;

export function ConfigAsCodeModal({ open, onClose, configYaml = DEFAULT_SWATI_YAML }: ConfigAsCodeModalProps) {
  const [yamlContent, setYamlContent] = useState(configYaml);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(yamlContent);
    setCopied(true);
    toast.success('swati.yaml copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([yamlContent], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'swati.yaml';
    a.click();
    URL.revokeObjectURL(url);
    toast.success('swati.yaml downloaded!');
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="💻 Headless CLI Mode & Config-as-Code (#40)"
      description="Manage your architecture as code with swati.yaml. Automate generator runs via CLI in CI/CD pipelines or reproducible team setups."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Status & Validation Banner */}
        <div className="flex items-center justify-between rounded-xl border border-emerald-200 bg-emerald-50/70 p-3 text-xs dark:border-emerald-950/40 dark:bg-emerald-950/20">
          <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-semibold">
            <CheckCircle2 className="h-4 w-4" />
            <span>Valid Schema Version 3 (Draft-07 Compatible)</span>
          </div>
          <span className="font-mono text-[10px] text-gray-500">.swati/schema/swati.schema.json</span>
        </div>

        {/* YAML Interactive Editor */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
              swati.yaml Specification
            </label>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handleCopy}>
                <Copy className="h-3.5 w-3.5 mr-1" />
                {copied ? 'Copied!' : 'Copy YAML'}
              </Button>
              <Button size="sm" variant="outline" onClick={handleDownload}>
                <Download className="h-3.5 w-3.5 mr-1" />
                Download
              </Button>
            </div>
          </div>
          <textarea
            value={yamlContent}
            onChange={(e) => setYamlContent(e.target.value)}
            rows={12}
            className="w-full rounded-xl border border-gray-300 bg-slate-950 p-4 font-mono text-xs text-indigo-300 focus:outline-none dark:border-slate-800 leading-relaxed"
            spellCheck={false}
          />
        </div>

        {/* Headless CLI Commands Cheat Sheet */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
            <Terminal className="h-4 w-4 text-indigo-500" />
            <span>Headless CLI Quick Reference</span>
          </label>
          <div className="rounded-xl bg-gray-900 p-3 font-mono text-[11px] text-gray-300 space-y-1 overflow-x-auto">
            <p><span className="text-emerald-400">$ swati init --template e-commerce</span> <span className="text-gray-500"># Generate swati.yaml from preset</span></p>
            <p><span className="text-emerald-400">$ swati generate --config swati.yaml</span> <span className="text-gray-500"># Headless project generation</span></p>
            <p><span className="text-emerald-400">$ swati generate --dry-run</span> <span className="text-gray-500"># Safe re-generation preview (#26)</span></p>
            <p><span className="text-emerald-400">$ swati add auth --methods email,google</span> <span className="text-gray-500"># Add module to existing app (#27)</span></p>
            <p><span className="text-emerald-400">$ swati validate</span> <span className="text-gray-500"># Check schema constraints</span></p>
            <p><span className="text-emerald-400">$ swati doctor</span> <span className="text-gray-500"># Flutter SDK & toolchain health check</span></p>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
}
