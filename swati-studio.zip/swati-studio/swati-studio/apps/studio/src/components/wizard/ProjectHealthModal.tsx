'use client';

import { computeProjectHealth, type StudioConfig } from '@swati/schema';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  FileCode2,
  HardDrive,
  Info,
  Package,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';

interface ProjectHealthModalProps {
  open: boolean;
  onClose: () => void;
  config: StudioConfig;
}

export function ProjectHealthModal({ open, onClose, config }: ProjectHealthModalProps) {
  const health = computeProjectHealth(config);

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-500 border-emerald-500';
    if (score >= 75) return 'text-indigo-500 border-indigo-500';
    return 'text-amber-500 border-amber-500';
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="📊 Enterprise Project Health Dashboard"
      description="Holistic evaluation of architecture patterns, security compliance, performance, and code quality"
      size="lg"
    >
      <div className="space-y-6">
        {/* Top Summary Banner */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 rounded-2xl border border-indigo-200 bg-gradient-to-r from-indigo-50/80 to-purple-50/80 p-5 dark:border-indigo-900/40 dark:from-indigo-950/30 dark:to-purple-950/30">
          <div className="flex items-center gap-4">
            <div
              className={`flex h-16 w-16 items-center justify-center rounded-2xl border-2 bg-white text-2xl font-black shadow-sm dark:bg-slate-900 ${getScoreColor(
                health.overallScore
              )}`}
            >
              {health.overallScore}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-gray-900 dark:text-white">
                  Project Readiness Score
                </h3>
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                  Grade A+
                </span>
              </div>
              <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                Estimated ~{health.estimatedFiles} generated files across {health.estimatedPackages} pub dependencies.
              </p>
            </div>
          </div>
        </div>

        {/* 4 Health Pillars */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/60">
            <div className="flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-1">
              <Cpu className="h-4 w-4" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Architecture</span>
            <p className="mt-1 text-lg font-black text-gray-900 dark:text-white">
              {health.architectureScore}/100
            </p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/60">
            <div className="flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-1">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Security</span>
            <p className="mt-1 text-lg font-black text-gray-900 dark:text-white">
              {health.securityScore}/100
            </p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/60">
            <div className="flex items-center justify-center text-amber-600 dark:text-amber-400 mb-1">
              <Zap className="h-4 w-4" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Performance</span>
            <p className="mt-1 text-lg font-black text-gray-900 dark:text-white">
              {health.performanceScore}/100
            </p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/60">
            <div className="flex items-center justify-center text-purple-600 dark:text-purple-400 mb-1">
              <FileCode2 className="h-4 w-4" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Code Quality</span>
            <p className="mt-1 text-lg font-black text-gray-900 dark:text-white">
              {health.codeQualityScore}/100
            </p>
          </div>
        </div>

        {/* Actionable Recommendations */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-gray-900 dark:text-white uppercase tracking-wider">
            Smart Recommendations
          </h4>
          <div className="space-y-2 max-h-[180px] overflow-y-auto">
            {health.recommendations.map((rec, i) => (
              <div
                key={i}
                className="flex items-start gap-2.5 rounded-xl border border-gray-200 bg-white p-3 text-xs dark:border-slate-800 dark:bg-slate-900"
              >
                {rec.type === 'security' ? (
                  <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-500 mt-0.5" />
                ) : rec.type === 'warning' ? (
                  <AlertTriangle className="h-4 w-4 shrink-0 text-amber-500 mt-0.5" />
                ) : (
                  <Info className="h-4 w-4 shrink-0 text-indigo-500 mt-0.5" />
                )}
                <span className="text-gray-700 dark:text-gray-300">{rec.message}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2 border-t border-gray-200 dark:border-slate-800">
          <Button onClick={onClose} size="sm">
            Close Dashboard
          </Button>
        </div>
      </div>
    </Modal>
  );
}
