'use client';

import { useState } from 'react';
import {
  generateShareUrl,
  teamPresets,
  type StudioConfig,
  type TeamPreset,
} from '@swati/schema';
import {
  Check,
  Copy,
  Download,
  Link,
  Lock,
  Share2,
  Upload,
  Users,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface TeamCollabModalProps {
  open: boolean;
  onClose: () => void;
  config: StudioConfig;
  onApplyConfig: (updates: Partial<StudioConfig>) => void;
}

export function TeamCollabModal({
  open,
  onClose,
  config,
  onApplyConfig,
}: TeamCollabModalProps) {
  const [copied, setCopied] = useState(false);
  const shareUrl = generateShareUrl(config);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    toast.success('Share link copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadConfig = () => {
    const jsonStr = JSON.stringify(config, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${String(config['project.packageName'] ?? 'swati-studio')}.config.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Config downloaded!');
  };

  const handleApplyPreset = (preset: TeamPreset) => {
    onApplyConfig(preset.config);
    toast.success(`Applied ${preset.name}!`);
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="👥 Team Collaboration & Config Sharing"
      description="Share this wizard setup across engineering teams or enforce company standard presets"
      size="lg"
    >
      <div className="space-y-6">
        {/* Share Link Field */}
        <div>
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Shareable Team Setup Link
          </label>
          <div className="mt-1.5 flex gap-2">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="flex-1 rounded-xl border border-gray-200 bg-gray-50 px-3.5 py-2 text-xs font-mono text-gray-600 outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-gray-300"
            />
            <Button onClick={handleCopyLink} size="sm" className="flex items-center gap-1.5">
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {copied ? 'Copied' : 'Copy'}
            </Button>
          </div>
        </div>

        {/* Quick Export / Download */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadConfig}
            className="flex items-center gap-1.5 text-xs"
          >
            <Download className="h-3.5 w-3.5" />
            Download .swati-config.json
          </Button>
        </div>

        {/* Team Standard Presets */}
        <div className="space-y-3">
          <span className="text-[11px] font-bold uppercase tracking-wider text-gray-400">
            Corporate Team Presets
          </span>
          <div className="grid gap-2.5">
            {teamPresets.map((preset) => (
              <div
                key={preset.id}
                className="flex items-center justify-between rounded-xl border border-gray-200 bg-white p-3.5 dark:border-slate-800 dark:bg-slate-900"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="text-xs font-bold text-gray-900 dark:text-white">
                      {preset.name}
                    </h5>
                    {preset.lockedFields.length > 0 && (
                      <span className="flex items-center gap-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-medium text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                        <Lock className="h-2.5 w-2.5" />
                        {preset.lockedFields.length} locked fields
                      </span>
                    )}
                  </div>
                  <p className="mt-0.5 text-[11px] text-gray-500 dark:text-gray-400">
                    {preset.description}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleApplyPreset(preset)}
                  className="text-xs"
                >
                  Apply Preset
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2 border-t border-gray-200 dark:border-slate-800">
          <Button onClick={onClose} size="sm">
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
}
