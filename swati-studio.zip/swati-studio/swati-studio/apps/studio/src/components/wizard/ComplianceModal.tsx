'use client';

import { useState } from 'react';
import {
  Scale,
  ShieldAlert,
  FileText,
  Globe,
  Trash2,
  Mail,
  CheckCircle2,
  Download,
  AlertCircle,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface ComplianceModalProps {
  open: boolean;
  onClose: () => void;
}

export function ComplianceModal({ open, onClose }: ComplianceModalProps) {
  const [supportEmail, setSupportEmail] = useState('support@myapp.com');
  const [gdpr, setGdpr] = useState(true);
  const [dpdp, setDpdp] = useState(true);
  const [ccpa, setCcpa] = useState(false);
  const [coppa, setCoppa] = useState(false);
  const [deleteAccountFlow, setDeleteAccountFlow] = useState(true);
  const [consentScreen, setConsentScreen] = useState(true);
  const [dataSafetySheet, setDataSafetySheet] = useState(true);
  const [viewCheatsheet, setViewCheatsheet] = useState(false);

  const handleGenerate = () => {
    toast.success('Generated legal kit: Privacy Policy, Terms, Deletion URL & Data Safety sheet!');
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="⚖️ Legal & Store Compliance Kit (#33)"
      description="Auto-generate store-ready Privacy Policy, Terms of Service, Play Store Data Safety answers, and Apple/Google compliant Account Deletion flows."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Legal Disclaimer Warning */}
        <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50/80 p-3 text-xs text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
          <AlertCircle className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
          <p>
            <strong>Disclaimer:</strong> Generated documents are starting templates tailored to your selected features. Always have qualified legal counsel review them before publishing.
          </p>
        </div>

        {/* Data Collected Detected Summary */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Detected Data Collection (From selected features)
          </label>
          <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3 dark:border-slate-800 dark:bg-slate-900/40">
            <div className="flex items-center gap-1.5 text-gray-700 dark:text-gray-300">
              <CheckCircle2 className="h-3.5 w-3.5 text-indigo-500" />
              <span>Email & Name (Authentication)</span>
            </div>
            <div className="flex items-center gap-1.5 text-gray-700 dark:text-gray-300">
              <CheckCircle2 className="h-3.5 w-3.5 text-indigo-500" />
              <span>Device FCM Tokens (Push)</span>
            </div>
            <div className="flex items-center gap-1.5 text-gray-700 dark:text-gray-300">
              <CheckCircle2 className="h-3.5 w-3.5 text-indigo-500" />
              <span>Diagnostics & Crash Logs</span>
            </div>
            <div className="flex items-center gap-1.5 text-gray-700 dark:text-gray-300">
              <CheckCircle2 className="h-3.5 w-3.5 text-indigo-500" />
              <span>Payment Tokens (Razorpay / Stripe)</span>
            </div>
          </div>
        </div>

        {/* Jurisdictions */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Applicable Jurisdictions</label>
          <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
            <label className="flex items-center gap-2 rounded-lg border border-gray-200 p-2.5 cursor-pointer dark:border-slate-800">
              <input
                type="checkbox"
                checked={dpdp}
                onChange={(e) => setDpdp(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>🇮🇳 India (DPDP Act)</span>
            </label>
            <label className="flex items-center gap-2 rounded-lg border border-gray-200 p-2.5 cursor-pointer dark:border-slate-800">
              <input
                type="checkbox"
                checked={gdpr}
                onChange={(e) => setGdpr(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>🇪🇺 EU (GDPR)</span>
            </label>
            <label className="flex items-center gap-2 rounded-lg border border-gray-200 p-2.5 cursor-pointer dark:border-slate-800">
              <input
                type="checkbox"
                checked={ccpa}
                onChange={(e) => setCcpa(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>🇺🇸 California (CCPA)</span>
            </label>
            <label className="flex items-center gap-2 rounded-lg border border-gray-200 p-2.5 cursor-pointer dark:border-slate-800">
              <input
                type="checkbox"
                checked={coppa}
                onChange={(e) => setCoppa(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>👶 Children (COPPA)</span>
            </label>
          </div>
        </div>

        {/* Support Email */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Public Support / Privacy Officer Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            <input
              type="email"
              value={supportEmail}
              onChange={(e) => setSupportEmail(e.target.value)}
              className="w-full rounded-lg border border-gray-300 bg-white pl-9 pr-3 py-2 text-xs font-mono dark:border-slate-700 dark:bg-slate-800"
              placeholder="support@myapp.com"
            />
          </div>
        </div>

        {/* Generated Deliverables Checklist */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={deleteAccountFlow}
              onChange={(e) => setDeleteAccountFlow(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Store-mandated Account Deletion web page & in-app flow</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={dataSafetySheet}
              onChange={(e) => setDataSafetySheet(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Play Store Data Safety Questionnaire cheat-sheet</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={consentScreen}
              onChange={(e) => setConsentScreen(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>In-app consent & tracking transparency dialog</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked disabled className="rounded text-indigo-600" />
            <span>Hosting-ready Markdown & HTML Privacy Policy</span>
          </label>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-2">
          <Button variant="outline" size="sm" onClick={() => setViewCheatsheet(!viewCheatsheet)}>
            <FileText className="h-4 w-4 mr-1.5" />
            {viewCheatsheet ? 'Hide Cheatsheet' : 'Preview Data Safety'}
          </Button>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleGenerate}>
              Generate Legal Kit
            </Button>
          </div>
        </div>

        {viewCheatsheet && (
          <div className="rounded-xl bg-slate-950 p-4 font-mono text-[11px] text-gray-300 max-h-52 overflow-y-auto whitespace-pre leading-relaxed">
{`# Google Play Data Safety Questionnaire Cheatsheet

1. Personal Info -> Email Address
   - Collected? YES
   - Shared with 3rd parties? NO
   - Handled ephemerally? NO
   - Required or Optional? REQUIRED (Account creation)
   - Purposes: App functionality, Account management

2. Device or other IDs -> Advertising ID
   - Collected? YES (if AdMob enabled)
   - Shared? YES (with Google AdMob network)
   - Purposes: Advertising, Analytics

3. Data Deletion Mechanism
   - Web URL Provided: https://myapp.com/legal/account_deletion.html
   - In-App Deletion: Provided in Settings > Account > Delete Account`}
          </div>
        )}
      </div>
    </Modal>
  );
}
