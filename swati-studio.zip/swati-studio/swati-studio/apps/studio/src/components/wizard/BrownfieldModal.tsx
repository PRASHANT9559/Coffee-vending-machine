'use client';

import { useState } from 'react';
import {
  FolderSearch,
  CheckCircle2,
  Layers,
  Globe,
  Bell,
  Shield,
  Workflow,
  Sparkles,
  FileCheck,
  Cpu,
  ArrowRight,
  Database,
  Terminal,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface DetectedStack {
  sdk: string;
  state: string;
  navigation: string;
  backend: string;
  httpClient: string;
  architecture: string;
  theme: string;
}

const SAMPLE_STACK: DetectedStack = {
  sdk: 'Flutter 3.x',
  state: 'Riverpod (flutter_riverpod: ^2.5.1)',
  navigation: 'GoRouter (go_router: ^14.0.0)',
  backend: 'Supabase (supabase_flutter: ^2.6.0)',
  httpClient: 'Dio (^5.4.0)',
  architecture: 'Feature-First (lib/features/*)',
  theme: 'Material 3 (ThemeData detected)',
};

interface AddonOption {
  id: string;
  name: string;
  icon: typeof Globe;
  description: string;
  changes: string[];
}

const AVAILABLE_ADDONS: AddonOption[] = [
  {
    id: 'i18n',
    name: '🌐 i18n Localization',
    icon: Globe,
    description: 'Multi-language ARB localization with Hindi & English delegates',
    changes: [
      'M  pubspec.yaml (+flutter_localizations, +intl)',
      'M  lib/main.dart (+localizationsDelegates, +supportedLocales)',
      'A  lib/l10n/app_en.arb',
      'A  lib/l10n/app_hi.arb',
      'A  l10n.yaml',
    ],
  },
  {
    id: 'cicd',
    name: '🔄 CI/CD Pipelines',
    icon: Workflow,
    description: 'GitHub Actions for linting, unit tests, and Android release builds',
    changes: [
      'A  .github/workflows/ci.yml',
      'A  .github/workflows/build-android.yml',
    ],
  },
  {
    id: 'env',
    name: '🌍 Environments & Flavors',
    icon: Terminal,
    description: 'Dev, Staging, and Prod configurations with .env file support',
    changes: [
      'M  pubspec.yaml (+flutter_dotenv)',
      'A  assets/env/dev.env',
      'A  assets/env/prod.env',
      'A  lib/config/app_config.dart',
      'A  lib/main_dev.dart',
      'A  lib/main_prod.dart',
    ],
  },
  {
    id: 'push',
    name: '🔔 Push Notifications',
    icon: Bell,
    description: 'Firebase Cloud Messaging + Android 13 permissions & channels',
    changes: [
      'M  pubspec.yaml (+firebase_messaging, +flutter_local_notifications)',
      'M  android/app/src/main/AndroidManifest.xml (+POST_NOTIFICATIONS)',
      'A  lib/core/notifications/notification_service.dart',
      'A  lib/core/notifications/notification_channels.dart',
    ],
  },
  {
    id: 'security',
    name: '🛡️ Security & RBAC',
    icon: Shield,
    description: 'Role guards, biometric auth, and FlutterSecureStorage storage',
    changes: [
      'M  pubspec.yaml (+flutter_secure_storage, +local_auth)',
      'A  lib/core/security/security_service.dart',
      'A  lib/core/security/role_guard.dart',
    ],
  },
];

interface BrownfieldModalProps {
  open: boolean;
  onClose: () => void;
}

export function BrownfieldModal({ open, onClose }: BrownfieldModalProps) {
  const [projectPath, setProjectPath] = useState('/projects/my_existing_flutter_app');
  const [scanned, setScanned] = useState(true);
  const [selectedAddon, setSelectedAddon] = useState<AddonOption | null>(null);
  const [applying, setApplying] = useState(false);

  const handleApplyAddon = async () => {
    if (!selectedAddon) return;
    setApplying(true);
    await new Promise((r) => setTimeout(r, 800));
    setApplying(false);
    toast.success(`Successfully added ${selectedAddon.name} to existing project!`);
    setSelectedAddon(null);
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="📂 Brownfield Mode — Existing Project Import (#27)"
      description="Import an existing Flutter codebase. Swati automatically analyzes your tech stack and injects missing enterprise capabilities without touching your existing code."
      size="2xl"
    >
      <div className="space-y-5">
        {/* Project Path Scanner */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Existing Flutter Project Directory
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={projectPath}
              onChange={(e) => setProjectPath(e.target.value)}
              className="flex-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs font-mono dark:border-slate-700 dark:bg-slate-800"
              placeholder="/path/to/flutter_app"
            />
            <Button size="sm" onClick={() => setScanned(true)}>
              <FolderSearch className="h-4 w-4 mr-1.5" />
              Scan Stack
            </Button>
          </div>
        </div>

        {/* Detected Stack Grid */}
        {scanned && (
          <div className="rounded-xl border border-gray-200 bg-gray-50/70 p-4 dark:border-slate-800 dark:bg-slate-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider dark:text-white flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                Detected Technology Stack
              </h4>
              <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-semibold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                Additive Safe Mode Active
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-white border border-gray-200 dark:bg-slate-800 dark:border-slate-700">
                <span className="text-gray-400 block text-[10px]">State Management</span>
                <span className="font-semibold text-indigo-600 dark:text-indigo-400">{SAMPLE_STACK.state}</span>
              </div>
              <div className="p-2 rounded-lg bg-white border border-gray-200 dark:bg-slate-800 dark:border-slate-700">
                <span className="text-gray-400 block text-[10px]">Navigation</span>
                <span className="font-semibold text-gray-900 dark:text-white">{SAMPLE_STACK.navigation}</span>
              </div>
              <div className="p-2 rounded-lg bg-white border border-gray-200 dark:bg-slate-800 dark:border-slate-700">
                <span className="text-gray-400 block text-[10px]">Backend Platform</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">{SAMPLE_STACK.backend}</span>
              </div>
              <div className="p-2 rounded-lg bg-white border border-gray-200 dark:bg-slate-800 dark:border-slate-700">
                <span className="text-gray-400 block text-[10px]">Architecture</span>
                <span className="font-semibold text-gray-900 dark:text-white">{SAMPLE_STACK.architecture}</span>
              </div>
            </div>
          </div>
        )}

        {/* Add-ons Selector */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider dark:text-white">
            Available Enterprise Add-ons (Select to Review Diff)
          </h4>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {AVAILABLE_ADDONS.map((addon) => {
              const isSelected = selectedAddon?.id === addon.id;
              return (
                <button
                  key={addon.id}
                  type="button"
                  onClick={() => setSelectedAddon(addon)}
                  className={`text-left p-3 rounded-xl border transition cursor-pointer ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30'
                      : 'border-gray-200 hover:border-gray-300 dark:border-slate-800 dark:hover:border-slate-700'
                  }`}
                >
                  <p className="text-xs font-bold text-gray-900 dark:text-white">{addon.name}</p>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-1">{addon.description}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Review Diff Panel */}
        {selectedAddon && (
          <div className="rounded-xl border border-indigo-200 bg-indigo-50/30 p-4 dark:border-indigo-900/60 dark:bg-indigo-950/20 space-y-3">
            <div className="flex items-center justify-between">
              <h5 className="text-xs font-bold text-gray-900 dark:text-white">
                📝 Diff Preview: Adding {selectedAddon.name}
              </h5>
              <span className="text-[10px] text-gray-500 font-mono">Additive-only guarantee</span>
            </div>
            <div className="rounded-lg bg-slate-900 p-3 font-mono text-xs text-emerald-400 space-y-1">
              {selectedAddon.changes.map((ch, idx) => (
                <div key={idx}>{ch}</div>
              ))}
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" size="sm" onClick={() => setSelectedAddon(null)}>
                Cancel
              </Button>
              <Button size="sm" onClick={() => void handleApplyAddon()} disabled={applying}>
                {applying ? 'Applying Addon...' : 'Apply Add-on to Project'}
              </Button>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
}
