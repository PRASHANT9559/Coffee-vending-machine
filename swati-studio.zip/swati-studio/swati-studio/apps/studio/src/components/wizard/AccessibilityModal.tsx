'use client';

import { useState } from 'react';
import {
  Eye,
  Smartphone,
  Tablet,
  Monitor,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Contrast,
  Sliders,
  Type,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface AccessibilityModalProps {
  open: boolean;
  onClose: () => void;
}

export function AccessibilityModal({ open, onClose }: AccessibilityModalProps) {
  const [formFactors, setFormFactors] = useState({
    phone: true,
    tablet: true,
    foldable: false,
    web: true,
    desktop: false,
  });
  const [semantics, setSemantics] = useState(true);
  const [minTapTarget, setMinTapTarget] = useState(true);
  const [textScaling200, setTextScaling200] = useState(true);
  const [reduceMotion, setReduceMotion] = useState(true);
  const [accentColor, setAccentColor] = useState('#FF9800');
  const [fixedContrast, setFixedContrast] = useState(false);

  const handleFixContrast = () => {
    setAccentColor('#BF360C');
    setFixedContrast(true);
    toast.success('Applied WCAG AA compliant color: #BF360C (Contrast 5.6:1)!');
  };

  const handleSave = () => {
    toast.success('Accessibility & Responsive layout rules saved!');
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="♿ Accessibility & Responsive Layouts (#37)"
      description="Multi-form factor breakpoints (Phone ↔ Tablet rail ↔ Desktop drawer), WCAG AA color contrast validation, and screen reader semantics."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Target Form Factors */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Target Form Factors</label>
          <div className="grid grid-cols-5 gap-2 text-xs">
            <button
              type="button"
              onClick={() => setFormFactors({ ...formFactors, phone: !formFactors.phone })}
              className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                formFactors.phone
                  ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-300'
                  : 'border-gray-200 dark:border-slate-800 text-gray-500'
              }`}
            >
              <Smartphone className="h-5 w-5 mx-auto mb-1" />
              <span className="font-semibold block text-[11px]">Phone</span>
            </button>

            <button
              type="button"
              onClick={() => setFormFactors({ ...formFactors, tablet: !formFactors.tablet })}
              className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                formFactors.tablet
                  ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-300'
                  : 'border-gray-200 dark:border-slate-800 text-gray-500'
              }`}
            >
              <Tablet className="h-5 w-5 mx-auto mb-1" />
              <span className="font-semibold block text-[11px]">Tablet</span>
            </button>

            <button
              type="button"
              onClick={() => setFormFactors({ ...formFactors, foldable: !formFactors.foldable })}
              className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                formFactors.foldable
                  ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-300'
                  : 'border-gray-200 dark:border-slate-800 text-gray-500'
              }`}
            >
              <span className="text-lg block mb-1">🔀</span>
              <span className="font-semibold block text-[11px]">Foldable</span>
            </button>

            <button
              type="button"
              onClick={() => setFormFactors({ ...formFactors, web: !formFactors.web })}
              className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                formFactors.web
                  ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-300'
                  : 'border-gray-200 dark:border-slate-800 text-gray-500'
              }`}
            >
              <span className="text-lg block mb-1">🌐</span>
              <span className="font-semibold block text-[11px]">Web</span>
            </button>

            <button
              type="button"
              onClick={() => setFormFactors({ ...formFactors, desktop: !formFactors.desktop })}
              className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                formFactors.desktop
                  ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-300'
                  : 'border-gray-200 dark:border-slate-800 text-gray-500'
              }`}
            >
              <Monitor className="h-5 w-5 mx-auto mb-1" />
              <span className="font-semibold block text-[11px]">Desktop</span>
            </button>
          </div>
        </div>

        {/* Breakpoints Mapping Guide */}
        <div className="rounded-xl border border-gray-200 bg-gray-50/70 p-3 text-xs dark:border-slate-800 dark:bg-slate-900/40 space-y-1.5">
          <h4 className="font-bold text-gray-900 uppercase tracking-wider dark:text-white text-[10px]">
            Adaptive Navigation Breakpoints
          </h4>
          <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
            <div className="p-2 rounded bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700">
              <span className="text-gray-400 block text-[10px]">Compact (&lt;600dp)</span>
              <span className="font-semibold text-gray-900 dark:text-white">Bottom Navigation Bar</span>
            </div>
            <div className="p-2 rounded bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700">
              <span className="text-gray-400 block text-[10px]">Medium (600–840dp)</span>
              <span className="font-semibold text-indigo-600 dark:text-indigo-400">Navigation Rail</span>
            </div>
            <div className="p-2 rounded bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700">
              <span className="text-gray-400 block text-[10px]">Expanded (&gt;840dp)</span>
              <span className="font-semibold text-emerald-600 dark:text-emerald-400">Side Drawer + Master-Detail</span>
            </div>
          </div>
        </div>

        {/* WCAG Contrast Live Checker */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Live WCAG AA Color Contrast Audit
          </label>
          <div className="flex items-center justify-between rounded-xl border border-gray-200 bg-white p-3.5 dark:border-slate-800 dark:bg-slate-900 text-xs">
            <div className="flex items-center gap-3">
              <div
                className="h-9 w-9 rounded-lg flex items-center justify-center font-bold text-white shadow-xs"
                style={{ backgroundColor: accentColor }}
              >
                Aa
              </div>
              <div>
                <p className="font-semibold text-gray-900 dark:text-white">
                  Accent color {accentColor} on white background
                </p>
                <p className="text-[11px] text-gray-500">
                  {fixedContrast ? (
                    <span className="text-emerald-600 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="h-3.5 w-3.5 inline" /> Contrast Ratio ≈ 5.6:1 (Meets WCAG AA)
                    </span>
                  ) : (
                    <span className="text-rose-600 font-semibold flex items-center gap-1">
                      <AlertTriangle className="h-3.5 w-3.5 inline" /> Contrast Ratio ≈ 2.2:1 (Needs minimum 4.5:1)
                    </span>
                  )}
                </p>
              </div>
            </div>

            {!fixedContrast && (
              <Button size="sm" onClick={handleFixContrast}>
                Apply Suggested Fix (#BF360C)
              </Button>
            )}
          </div>
        </div>

        {/* Accessibility Features Checkboxes */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={semantics}
              onChange={(e) => setSemantics(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Semantics labels on all generated widgets</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={minTapTarget}
              onChange={(e) => setMinTapTarget(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Minimum tap target 48×48dp</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={textScaling200}
              onChange={(e) => setTextScaling200(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Support text scale up to 200% without overflow</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={reduceMotion}
              onChange={(e) => setReduceMotion(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Reduce-motion preference respect (disable heavy animations)</span>
          </label>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Layout & A11y Config
          </Button>
        </div>
      </div>
    </Modal>
  );
}
