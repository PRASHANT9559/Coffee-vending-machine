'use client';

import { Check } from 'lucide-react';
import { steps } from '@swati/schema';
import { cn } from '@/lib/utils';

export interface StepperProps {
  currentStep: number;
  onSelect: (index: number) => void;
}

/** Horizontal step indicator, same behaviour as the original prototype. */
export function Stepper({ currentStep, onSelect }: StepperProps) {
  return (
    <div className="flex min-w-max items-center px-2">
      {steps.map((step, index) => {
        const isActive = index === currentStep;
        const isCompleted = index < currentStep;
        const isLast = index === steps.length - 1;
        return (
          <div key={step.id} className={cn('flex items-center', !isLast && 'flex-1')}>
            <button
              type="button"
              onClick={() => onSelect(index)}
              className="group relative flex items-center gap-2"
              aria-current={isActive ? 'step' : undefined}
            >
              <span
                className={cn(
                  'flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-all duration-300',
                  isActive &&
                    'scale-110 bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30',
                  isCompleted && 'bg-emerald-500 text-white',
                  !isActive &&
                    !isCompleted &&
                    'bg-gray-200 text-gray-500 dark:bg-slate-700 dark:text-gray-400',
                )}
              >
                {isCompleted ? <Check className="h-4 w-4" strokeWidth={3} /> : index + 1}
              </span>
              <span
                className={cn(
                  'whitespace-nowrap text-xs font-medium transition-colors',
                  isActive && 'text-indigo-600 dark:text-indigo-400',
                  isCompleted && 'text-emerald-600 dark:text-emerald-400',
                  !isActive && !isCompleted && 'text-gray-500 dark:text-gray-400',
                )}
              >
                {step.label}
              </span>
            </button>
            {!isLast ? (
              <span
                className={cn(
                  'mx-2 h-0.5 flex-1 rounded-full transition-all duration-500',
                  isCompleted ? 'bg-emerald-500' : 'bg-gray-200 dark:bg-slate-700',
                )}
              />
            ) : null}
          </div>
        );
      })}
    </div>
  );
}
