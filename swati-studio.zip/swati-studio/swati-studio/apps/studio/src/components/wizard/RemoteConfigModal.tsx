'use client';

import { useState } from 'react';
import {
  Sliders,
  ShieldAlert,
  Flame,
  Database,
  Globe,
  Plus,
  RefreshCw,
  Clock,
  CheckCircle2,
  Trash2,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface ConfigParam {
  key: string;
  type: 'String' | 'bool' | 'int';
  defaultValue: string;
}

const DEFAULT_PARAMS: ConfigParam[] = [
  { key: 'min_supported_version', type: 'String', defaultValue: '"1.0.0"' },
  { key: 'latest_version', type: 'String', defaultValue: '"1.2.0"' },
  { key: 'maintenance_mode', type: 'bool', defaultValue: 'false' },
  { key: 'maintenance_message', type: 'String', defaultValue: '"Back soon for maintenance!"' },
  { key: 'show_ads', type: 'bool', defaultValue: 'true' },
  { key: 'interstitial_gap_sec', type: 'int', defaultValue: '120' },
  { key: 'new_checkout_enabled', type: 'bool', defaultValue: 'false' },
];

interface RemoteConfigModalProps {
  open: boolean;
  onClose: () => void;
}

export function RemoteConfigModal({ open, onClose }: RemoteConfigModalProps) {
  const [provider, setProvider] = useState<'firebase' | 'supabase' | 'custom'>('firebase');
  const [params, setParams] = useState<ConfigParam[]>(DEFAULT_PARAMS);
  const [forceUpdate, setForceUpdate] = useState(true);
  const [softUpdate, setSoftUpdate] = useState(true);
  const [inAppUpdate, setInAppUpdate] = useState(true);
  const [maintenanceGate, setMaintenanceGate] = useState(true);
  const [cacheTtlHours, setCacheTtlHours] = useState('1');

  const handleAddParam = () => {
    const newKey = `feature_flag_${params.length + 1}`;
    setParams([...params, { key: newKey, type: 'bool', defaultValue: 'true' }]);
  };

  const handleDeleteParam = (key: string) => {
    setParams(params.filter((p) => p.key !== key));
  };

  const handleSave = () => {
    toast.success('Remote Config & Maintenance Mode settings saved!');
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🎛️ Remote Config, Force Update & Maintenance Mode (#31)"
      description="Control feature flags, enforce minimum app versions, and trigger maintenance mode without publishing a new app store release."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Provider Radio Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Config Provider</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setProvider('firebase')}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                provider === 'firebase'
                  ? 'border-orange-500 bg-orange-50/60 dark:bg-orange-950/20'
                  : 'border-gray-200 hover:border-gray-300 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="text-xs font-bold text-gray-900 dark:text-white">Firebase</span>
              </div>
              <p className="text-[10px] text-gray-500 mt-1">Firebase Remote Config SDK</p>
            </button>

            <button
              type="button"
              onClick={() => setProvider('supabase')}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                provider === 'supabase'
                  ? 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/20'
                  : 'border-gray-200 hover:border-gray-300 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-emerald-500" />
                <span className="text-xs font-bold text-gray-900 dark:text-white">Supabase</span>
              </div>
              <p className="text-[10px] text-gray-500 mt-1">Realtime config table</p>
            </button>

            <button
              type="button"
              onClick={() => setProvider('custom')}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                provider === 'custom'
                  ? 'border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/20'
                  : 'border-gray-200 hover:border-gray-300 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-indigo-500" />
                <span className="text-xs font-bold text-gray-900 dark:text-white">Custom REST</span>
              </div>
              <p className="text-[10px] text-gray-500 mt-1">Self-hosted config endpoint</p>
            </button>
          </div>
        </div>

        {/* Parameters Table */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
              Remote Parameters & Feature Flags
            </label>
            <Button size="sm" variant="outline" onClick={handleAddParam}>
              <Plus className="h-3.5 w-3.5 mr-1" />
              Add Param
            </Button>
          </div>
          <div className="max-h-60 overflow-y-auto rounded-xl border border-gray-200 dark:border-slate-800 text-xs">
            <table className="w-full text-left">
              <thead className="bg-gray-100 dark:bg-slate-800 text-gray-500 font-semibold">
                <tr>
                  <th className="p-2.5">Key</th>
                  <th className="p-2.5">Type</th>
                  <th className="p-2.5">Offline Default</th>
                  <th className="p-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                {params.map((p) => (
                  <tr key={p.key} className="hover:bg-gray-50 dark:hover:bg-slate-850">
                    <td className="p-2.5 font-mono font-medium">{p.key}</td>
                    <td className="p-2.5 font-mono text-indigo-600 dark:text-indigo-400">{p.type}</td>
                    <td className="p-2.5 font-mono text-gray-600 dark:text-gray-400">{p.defaultValue}</td>
                    <td className="p-2.5 text-right">
                      {!p.key.startsWith('min_') && !p.key.startsWith('latest_') && !p.key.startsWith('maintenance_') && (
                        <button
                          type="button"
                          onClick={() => handleDeleteParam(p.key)}
                          className="text-gray-400 hover:text-rose-500"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Update & Gating Behaviors */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={forceUpdate}
              onChange={(e) => setForceUpdate(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Force Update dialog (version &lt; min_supported)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={softUpdate}
              onChange={(e) => setSoftUpdate(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Soft update notification banner (version &lt; latest)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={maintenanceGate}
              onChange={(e) => setMaintenanceGate(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Maintenance mode full-screen blocker gate</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={inAppUpdate}
              onChange={(e) => setInAppUpdate(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Android In-App Update API support</span>
          </label>
        </div>

        {/* Caching Strategy */}
        <div className="flex items-center justify-between text-xs rounded-xl border border-gray-200 p-3 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-gray-400" />
            <span className="font-medium">Client Cache TTL:</span>
          </div>
          <select
            value={cacheTtlHours}
            onChange={(e) => setCacheTtlHours(e.target.value)}
            className="rounded-lg border border-gray-300 bg-white px-2.5 py-1 text-xs dark:border-slate-700 dark:bg-slate-800"
          >
            <option value="0">0 (Immediate fetch on each launch)</option>
            <option value="1">1 hour (Recommended)</option>
            <option value="6">6 hours</option>
            <option value="24">24 hours</option>
          </select>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Remote Config
          </Button>
        </div>
      </div>
    </Modal>
  );
}
