'use client';

import { useState } from 'react';
import { analyzeAppPrompt, type AiRecommendation, type StudioConfig } from '@swati/schema';
import { Bot, CheckCircle2, ChevronRight, Sparkles, Wand2 } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface AiWizardModalProps {
  open: boolean;
  onClose: () => void;
  onApplyConfig: (configUpdates: Partial<StudioConfig>) => void;
}

const SAMPLE_PROMPTS = [
  'Food delivery app with live driver tracking on map, payments, and restaurant menus',
  'Real-time encrypted chat messenger with voice notes and dark glass theme',
  'Modern E-commerce store with AMOLED true black mode, Stripe checkout, and push notifications',
  'FinTech digital banking app with biometric authentication and spend analytics',
];

export function AiWizardModal({ open, onClose, onApplyConfig }: AiWizardModalProps) {
  const [prompt, setPrompt] = useState('');
  const [recommendation, setRecommendation] = useState<AiRecommendation | null>(null);

  const handleAnalyze = () => {
    if (!prompt.trim()) return;
    const result = analyzeAppPrompt(prompt);
    setRecommendation(result);
  };

  const handleApply = () => {
    if (!recommendation) return;
    onApplyConfig(recommendation.config);
    toast.success(`✨ Applied AI recommendations for ${recommendation.appName}!`);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🤖 AI-Powered Smart Wizard"
      description="Describe your application in one sentence — AI will analyze requirements and automatically configure your architecture and screens."
      size="lg"
    >
      <div className="space-y-5">
        <div>
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Describe what you want to build:
          </label>
          <div className="mt-1.5 flex gap-2">
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. I want to build a fitness workout tracker with dark mode, calorie charts, and exercise library..."
              className="flex-1 rounded-xl border border-gray-200 bg-gray-50 p-3 text-sm text-gray-900 outline-none transition focus:border-indigo-500 focus:bg-white dark:border-slate-800 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] text-gray-400">Quick suggestions:</span>
            {SAMPLE_PROMPTS.map((sample) => (
              <button
                key={sample}
                type="button"
                onClick={() => setPrompt(sample)}
                className="rounded-md border border-gray-200 bg-white px-2 py-0.5 text-[11px] text-gray-600 transition hover:bg-gray-50 hover:text-indigo-600 dark:border-slate-800 dark:bg-slate-800 dark:text-gray-400 dark:hover:bg-slate-700"
              >
                {sample.slice(0, 32)}…
              </button>
            ))}
          </div>
        </div>

        <div className="flex justify-end">
          <Button
            onClick={handleAnalyze}
            disabled={!prompt.trim()}
            size="sm"
            className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
          >
            <Sparkles className="h-4 w-4" />
            Analyze & Generate Stack
          </Button>
        </div>

        {/* AI Recommendations View */}
        {recommendation && (
          <div className="rounded-2xl border border-indigo-200 bg-indigo-50/50 p-4 space-y-4 dark:border-indigo-900/50 dark:bg-indigo-950/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white">
                  <Bot className="h-4 w-4" />
                </div>
                <h4 className="text-sm font-bold text-gray-900 dark:text-white">
                  AI Recommendation: {recommendation.appName}
                </h4>
              </div>
              <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                {Math.round(recommendation.confidence * 100)}% Match
              </span>
            </div>

            <p className="text-xs text-gray-600 dark:text-gray-300">
              {recommendation.summary}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="rounded-lg bg-white p-2 border border-gray-200 dark:border-slate-800 dark:bg-slate-900">
                <span className="text-[10px] text-gray-400">Backend</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(recommendation.config['backend.provider'])}
                </p>
              </div>
              <div className="rounded-lg bg-white p-2 border border-gray-200 dark:border-slate-800 dark:bg-slate-900">
                <span className="text-[10px] text-gray-400">State</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(recommendation.config['state.manager'])}
                </p>
              </div>
              <div className="rounded-lg bg-white p-2 border border-gray-200 dark:border-slate-800 dark:bg-slate-900">
                <span className="text-[10px] text-gray-400">Theme</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(recommendation.config['frontend.themeMode'])}
                </p>
              </div>
              <div className="rounded-lg bg-white p-2 border border-gray-200 dark:border-slate-800 dark:bg-slate-900">
                <span className="text-[10px] text-gray-400">Database</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(recommendation.config['database.engine'])}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <Button onClick={handleApply} size="sm" className="bg-indigo-600 text-white hover:bg-indigo-700">
                <CheckCircle2 className="mr-1.5 h-4 w-4" />
                Apply AI Configuration
              </Button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
