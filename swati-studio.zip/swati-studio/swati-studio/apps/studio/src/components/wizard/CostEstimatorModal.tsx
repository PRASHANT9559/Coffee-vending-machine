'use client';

import { estimateMonthlyCost, type StudioConfig } from '@swati/schema';
import { Coins, DollarSign, HelpCircle, Lightbulb, Shield, Users } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';

interface CostEstimatorModalProps {
  open: boolean;
  onClose: () => void;
  config: StudioConfig;
}

export function CostEstimatorModal({ open, onClose, config }: CostEstimatorModalProps) {
  const estimate = estimateMonthlyCost(config);

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="💲 Smart Cost Estimation Engine"
      description="Real-time projected monthly cloud infrastructure & service expenses based on your configuration"
      size="md"
    >
      <div className="space-y-5">
        {/* Total Cost Highlight */}
        <div className="flex items-center justify-between rounded-2xl border border-emerald-200 bg-emerald-50/70 p-5 dark:border-emerald-900/40 dark:bg-emerald-950/30">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
              Estimated Monthly Cost
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black text-gray-900 dark:text-white">
                \${estimate.totalUsd}
              </span>
              <span className="text-xs text-gray-500 dark:text-gray-400">
                / month (~₹{estimate.totalInr.toLocaleString('en-IN')})
              </span>
            </div>
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-sm">
            <DollarSign className="h-6 w-6" />
          </div>
        </div>

        {/* Free Tier Capacity */}
        <div className="flex items-center gap-3 rounded-xl border border-gray-200 bg-white p-3.5 text-xs dark:border-slate-800 dark:bg-slate-900">
          <Users className="h-5 w-5 text-indigo-500 shrink-0" />
          <div>
            <span className="font-bold text-gray-900 dark:text-white">Free Tier Allowance:</span>
            <p className="text-gray-500 dark:text-gray-400 mt-0.5">{estimate.freeTierCoverage}</p>
          </div>
        </div>

        {/* Service Breakdown */}
        <div className="space-y-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-gray-400">
            Service Line Items
          </span>
          <div className="space-y-2">
            {estimate.items.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between rounded-xl border border-gray-100 bg-gray-50/80 p-3 text-xs dark:border-slate-800 dark:bg-slate-900/50"
              >
                <div>
                  <h5 className="font-semibold text-gray-900 dark:text-white">{item.service}</h5>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">{item.notes}</p>
                </div>
                <div className="text-right">
                  <span className="font-bold text-gray-900 dark:text-white">
                    {item.monthlyUsd === 0 ? 'Free' : `\$${item.monthlyUsd}/mo`}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Optimization Tip */}
        <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50/60 p-3 text-xs dark:border-amber-900/30 dark:bg-amber-950/20">
          <Lightbulb className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
          <p className="text-amber-900 dark:text-amber-300">{estimate.costSavingTip}</p>
        </div>

        <div className="flex justify-end pt-2 border-t border-gray-200 dark:border-slate-800">
          <Button onClick={onClose} size="sm">
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
}
