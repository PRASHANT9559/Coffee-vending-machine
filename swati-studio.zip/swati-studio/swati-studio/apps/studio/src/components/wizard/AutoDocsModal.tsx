'use client';

import { useState } from 'react';
import {
  BookOpen,
  FileText,
  Workflow,
  CheckCircle2,
  FileCode,
  Download,
  Copy,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface AutoDocsModalProps {
  open: boolean;
  onClose: () => void;
}

export function AutoDocsModal({ open, onClose }: AutoDocsModalProps) {
  const [includeReadme, setIncludeReadme] = useState(true);
  const [includeArch, setIncludeArch] = useState(true);
  const [includeDb, setIncludeDb] = useState(true);
  const [includeContributing, setIncludeContributing] = useState(true);
  const [includeChangelog, setIncludeChangelog] = useState(true);
  const [includeAdrs, setIncludeAdrs] = useState(true);
  const [includeOnboarding, setIncludeOnboarding] = useState(true);
  const [activeTab, setActiveTab] = useState<'architecture' | 'adr' | 'onboarding'>('architecture');

  const handleGenerate = () => {
    toast.success('Generated complete documentation suite with ADRs and Mermaid diagrams!');
    onClose();
  };

  const sampleArchMermaid = `flowchart TD
    subgraph UI ["Presentation Layer (Flutter)"]
        Screens["Screens & Widgets"]
        Controllers["Riverpod / Controllers"]
    end

    subgraph Domain ["Domain Layer"]
        Models["Immutable Models (Freezed)"]
        RepoInterfaces["Repository Contracts"]
    end

    subgraph Data ["Data Layer"]
        RepoImpl["Repository Implementations"]
        RemoteSource["Supabase / Dio Remote Source"]
        LocalSource["Drift / Hive Offline Cache"]
    end

    Screens --> Controllers
    Controllers --> RepoInterfaces
    RepoImpl -.-> RepoInterfaces
    RepoImpl --> RemoteSource
    RepoImpl --> LocalSource`;

  const sampleAdr = `# ADR 0001: State Management Selection

## Status: Accepted
## Context:
The enterprise application requires compile-time safety, unidirectional data flow, testability without BuildContext coupling, and seamless code-generation support.

## Decision:
We selected **flutter_riverpod** with auto-dispose providers and code generation.

## Consequences:
- High performance and zero memory leaks.
- Clear separation between UI views and business controllers.
- Minimal boilerplate using generated providers.`;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="📚 Auto Documentation Generator (#39)"
      description="Automatically generate architecture diagrams, decision records (ADRs), developer onboarding guides, and living documentation from your wizard choices."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Document Checklist */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Generated Documentation Suite</label>
          <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeReadme}
                onChange={(e) => setIncludeReadme(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>README.md (Setup, flavors, run commands)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeArch}
                onChange={(e) => setIncludeArch(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>ARCHITECTURE.md (Layers + Mermaid diagrams)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeDb}
                onChange={(e) => setIncludeDb(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>DATABASE.md (ERD visual specs from #28)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeAdrs}
                onChange={(e) => setIncludeAdrs(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>docs/adr/* (Architecture Decision Records)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeOnboarding}
                onChange={(e) => setIncludeOnboarding(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>ONBOARDING.md (New engineer Day-1 checklist)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeContributing}
                onChange={(e) => setIncludeContributing(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>CONTRIBUTING.md & CHANGELOG.md</span>
            </label>
          </div>
        </div>

        {/* Live Preview Tabs */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Live Preview</label>
            <div className="flex gap-1 text-[10px]">
              <button
                type="button"
                onClick={() => setActiveTab('architecture')}
                className={`px-2.5 py-1 rounded font-semibold uppercase cursor-pointer ${
                  activeTab === 'architecture'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-600 dark:bg-slate-800 dark:text-gray-400'
                }`}
              >
                Architecture Mermaid
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('adr')}
                className={`px-2.5 py-1 rounded font-semibold uppercase cursor-pointer ${
                  activeTab === 'adr'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-600 dark:bg-slate-800 dark:text-gray-400'
                }`}
              >
                Sample ADR Record
              </button>
            </div>
          </div>

          <div className="rounded-xl bg-slate-950 p-4 font-mono text-[11px] text-emerald-400 max-h-56 overflow-y-auto whitespace-pre leading-relaxed">
            {activeTab === 'architecture' ? sampleArchMermaid : sampleAdr}
          </div>
        </div>

        {/* Notice on Regeneration Safety */}
        <div className="text-[11px] text-gray-500 rounded-lg bg-gray-50 p-2.5 dark:bg-slate-900 border border-gray-200 dark:border-slate-800">
          💡 <strong>Living Documentation:</strong> All generated docs are classified as <strong>Hybrid files</strong> (#26). When re-generating, automated sections update while your team notes remain preserved.
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleGenerate}>
            Generate Documentation Suite
          </Button>
        </div>
      </div>
    </Modal>
  );
}
