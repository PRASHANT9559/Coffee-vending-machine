'use client';

import { useState } from 'react';
import {
  Sparkles,
  Loader2,
  Inbox,
  AlertTriangle,
  WifiOff,
  RefreshCw,
  Eye,
  CheckCircle2,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface UiStatesModalProps {
  open: boolean;
  onClose: () => void;
}

export function UiStatesModal({ open, onClose }: UiStatesModalProps) {
  const [loadingStyle, setLoadingStyle] = useState<'shimmer' | 'spinner'>('shimmer');
  const [emptyStyle, setEmptyStyle] = useState<'icon' | 'lottie'>('icon');
  const [includeSkeleton, setIncludeSkeleton] = useState(true);
  const [includeEmpty, setIncludeEmpty] = useState(true);
  const [includeError, setIncludeError] = useState(true);
  const [includeOffline, setIncludeOffline] = useState(true);
  const [includePermission, setIncludePermission] = useState(true);
  const [includePagination, setIncludePagination] = useState(true);
  const [previewTab, setPreviewTab] = useState<'loading' | 'empty' | 'error' | 'offline'>('empty');

  const handleSave = () => {
    toast.success('UI States Kit configuration saved!');
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🧩 Standard UI States Kit (#34)"
      description="Production-grade reusable state widgets for loading skeletons, zero-data empty states, offline banners, and error handlers."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Style Pickers */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Loading Style</label>
            <div className="flex rounded-lg border border-gray-200 bg-gray-100 p-0.5 dark:border-slate-800 dark:bg-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setLoadingStyle('shimmer')}
                className={`flex-1 py-1.5 rounded-md font-medium cursor-pointer ${
                  loadingStyle === 'shimmer' ? 'bg-white shadow-xs text-indigo-600 dark:bg-slate-900 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                ✨ Shimmer Skeleton
              </button>
              <button
                type="button"
                onClick={() => setLoadingStyle('spinner')}
                className={`flex-1 py-1.5 rounded-md font-medium cursor-pointer ${
                  loadingStyle === 'spinner' ? 'bg-white shadow-xs text-indigo-600 dark:bg-slate-900 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                ⭕ Spinner
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Empty State Style</label>
            <div className="flex rounded-lg border border-gray-200 bg-gray-100 p-0.5 dark:border-slate-800 dark:bg-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setEmptyStyle('icon')}
                className={`flex-1 py-1.5 rounded-md font-medium cursor-pointer ${
                  emptyStyle === 'icon' ? 'bg-white shadow-xs text-indigo-600 dark:bg-slate-900 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                📭 Icon + Text + CTA
              </button>
              <button
                type="button"
                onClick={() => setEmptyStyle('lottie')}
                className={`flex-1 py-1.5 rounded-md font-medium cursor-pointer ${
                  emptyStyle === 'lottie' ? 'bg-white shadow-xs text-indigo-600 dark:bg-slate-900 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                🎨 Lottie Animation
              </button>
            </div>
          </div>
        </div>

        {/* Visual Preview Sandbox */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Live Visual Preview</label>
            <div className="flex gap-1">
              {(['loading', 'empty', 'error', 'offline'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setPreviewTab(tab)}
                  className={`px-2 py-0.5 text-[10px] font-semibold rounded uppercase cursor-pointer ${
                    previewTab === tab
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 text-gray-600 dark:bg-slate-800 dark:text-gray-400'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-center rounded-xl border border-gray-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 min-h-44">
            {previewTab === 'loading' && (
              <div className="w-full max-w-xs space-y-2.5 animate-pulse">
                <div className="h-4 bg-gray-200 dark:bg-slate-800 rounded w-3/4" />
                <div className="h-3 bg-gray-200 dark:bg-slate-800 rounded w-1/2" />
                <div className="h-20 bg-gray-200 dark:bg-slate-800 rounded-lg" />
              </div>
            )}

            {previewTab === 'empty' && (
              <div className="text-center space-y-2">
                <div className="flex h-12 w-12 mx-auto items-center justify-center rounded-full bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600">
                  <Inbox className="h-6 w-6" />
                </div>
                <h5 className="text-xs font-bold text-gray-900 dark:text-white">Koi item nahi mila</h5>
                <p className="text-[11px] text-gray-500">Jab naya order banega, yahan dikhega.</p>
                <Button size="sm" className="mt-1">
                  Abhi Banayein
                </Button>
              </div>
            )}

            {previewTab === 'error' && (
              <div className="text-center space-y-2">
                <div className="flex h-12 w-12 mx-auto items-center justify-center rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-600">
                  <AlertTriangle className="h-6 w-6" />
                </div>
                <h5 className="text-xs font-bold text-gray-900 dark:text-white">Kuch galat ho gaya</h5>
                <p className="text-[11px] text-gray-500">Kripya internet check karein aur dobara koshish karein.</p>
                <Button size="sm" variant="outline" className="mt-1">
                  <RefreshCw className="h-3.5 w-3.5 mr-1" />
                  Retry
                </Button>
              </div>
            )}

            {previewTab === 'offline' && (
              <div className="w-full max-w-sm rounded-lg bg-slate-900 text-white p-3 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <WifiOff className="h-4 w-4 text-amber-400" />
                  <span>Aap offline hain (cached data display ho raha hai)</span>
                </div>
                <span className="text-[10px] text-amber-400 uppercase font-mono">Offline</span>
              </div>
            )}
          </div>
        </div>

        {/* Checkbox Options */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={includeSkeleton}
              onChange={(e) => setIncludeSkeleton(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>AsyncValueView generic wrapper</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={includeOffline}
              onChange={(e) => setIncludeOffline(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Offline network banner widget</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={includePermission}
              onChange={(e) => setIncludePermission(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Permission denied fallback screen</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={includePagination}
              onChange={(e) => setIncludePagination(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Paginated footer loader indicator</span>
          </label>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save UI States Kit
          </Button>
        </div>
      </div>
    </Modal>
  );
}
