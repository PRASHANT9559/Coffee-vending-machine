'use client';

import { Zap } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { cn } from '@/lib/utils';

export interface GenerateModalProps {
  open: boolean;
  onClose: () => void;
  phases: { id: string; label: string }[];
  activePhase: number;
  progress: number;
  finished: boolean;
}

const PHASE_LABELS = [
  'Scaffolding project structure',
  'Configuring dependencies',
  'Setting up backend integration',
  'Generating theme and components',
  'Finalizing build configuration',
];

/** Progress overlay shown while the project is being written to disk. */
export function GenerateModal({
  open,
  onClose,
  phases,
  activePhase,
  progress,
  finished,
}: GenerateModalProps) {
  return (
    <Modal
      open={open}
      onClose={() => (finished ? onClose() : undefined)}
      ariaLabel="Generating project"
      className="max-w-md text-center"
    >
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 animate-pulse-soft">
        <Zap className="h-8 w-8 text-white" />
      </div>
      <h2 className="mb-2 text-2xl font-bold">
        {finished ? 'Project generated' : 'Generating project…'}
      </h2>
      <p className="mb-6 text-gray-500 dark:text-gray-400">
        {finished
          ? 'Your project has been written to disk.'
          : 'Swati Studio is crafting your application'}
      </p>

      <div className="mb-6 space-y-3 text-left">
        {(phases.length ? phases : PHASE_LABELS.map((label, id) => ({ id: String(id), label }))).map(
          (phase, index) => (
            <div
              key={phase.id}
              className={cn(
                'flex items-center gap-3 text-sm',
                index < activePhase && 'text-emerald-600 dark:text-emerald-400',
                index === activePhase && 'text-indigo-600 dark:text-indigo-400',
                index > activePhase && 'text-gray-500 dark:text-gray-400',
              )}
            >
              <span
                className={cn(
                  'h-2 w-2 rounded-full',
                  index < activePhase
                    ? 'bg-emerald-500'
                    : index === activePhase
                      ? 'animate-pulse bg-indigo-500'
                      : 'bg-gray-300 dark:bg-slate-600',
                )}
              />
              {phase.label}
            </div>
          ),
        )}
      </div>

      <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200 dark:bg-slate-700">
        <div
          className="progress-shine h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
    </Modal>
  );
}
