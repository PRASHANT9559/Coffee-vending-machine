'use client';

import { useState } from 'react';
import {
  Sparkles,
  Server,
  Zap,
  Globe,
  Sliders,
  Database,
  CheckCircle2,
  AlertTriangle,
  Play,
  FileCode,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface MockDataModalProps {
  open: boolean;
  onClose: () => void;
}

export function MockDataModal({ open, onClose }: MockDataModalProps) {
  const [recordCount, setRecordCount] = useState(25);
  const [locale, setLocale] = useState('hi_IN');
  const [mockProducts, setMockProducts] = useState(true);
  const [mockOrders, setMockOrders] = useState(true);
  const [mockUsers, setMockUsers] = useState(true);
  const [latencyMs, setLatencyMs] = useState(600);
  const [failureRate, setFailureRate] = useState(5);
  const [emptyListScenario, setEmptyListScenario] = useState(false);
  const [sim401, setSim401] = useState(false);
  const [viewJson, setViewJson] = useState(false);

  const handleGenerate = () => {
    toast.success(`Generated ${recordCount} mock records per model with latency simulator!`);
    onClose();
  };

  const sampleJson = `[
  {
    "id": "prod_001",
    "name": "Wireless Bluetooth Earbuds",
    "price": 1499.00,
    "category": "Electronics",
    "in_stock": true,
    "image_url": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df"
  },
  {
    "id": "prod_002",
    "name": "Stainless Steel Water Bottle",
    "price": 499.00,
    "category": "Home & Kitchen",
    "in_stock": true,
    "image_url": "https://images.unsplash.com/photo-1602143407151-7111542de6e8"
  }
]`;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🎭 Mock Data & Fake Server (#36)"
      description="Generate realistic dummy datasets, inject network latency and error simulations, and run a local fake server to develop without a live backend."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Model Selection & Count */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="space-y-1.5">
            <label className="font-semibold text-gray-700 dark:text-gray-300">Models to Generate</label>
            <div className="flex gap-2">
              <label className="flex items-center gap-1.5 rounded-lg border border-gray-200 p-2 cursor-pointer dark:border-slate-800">
                <input
                  type="checkbox"
                  checked={mockProducts}
                  onChange={(e) => setMockProducts(e.target.checked)}
                  className="rounded text-indigo-600"
                />
                <span>Products</span>
              </label>
              <label className="flex items-center gap-1.5 rounded-lg border border-gray-200 p-2 cursor-pointer dark:border-slate-800">
                <input
                  type="checkbox"
                  checked={mockOrders}
                  onChange={(e) => setMockOrders(e.target.checked)}
                  className="rounded text-indigo-600"
                />
                <span>Orders</span>
              </label>
              <label className="flex items-center gap-1.5 rounded-lg border border-gray-200 p-2 cursor-pointer dark:border-slate-800">
                <input
                  type="checkbox"
                  checked={mockUsers}
                  onChange={(e) => setMockUsers(e.target.checked)}
                  className="rounded text-indigo-600"
                />
                <span>Users</span>
              </label>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between font-semibold text-gray-700 dark:text-gray-300">
              <span>Records per Model:</span>
              <span className="font-mono text-indigo-600 dark:text-indigo-400">{recordCount}</span>
            </div>
            <input
              type="range"
              min="5"
              max="100"
              step="5"
              value={recordCount}
              onChange={(e) => setRecordCount(Number(e.target.value))}
              className="w-full cursor-pointer accent-indigo-600"
            />
          </div>
        </div>

        {/* Locale & Mode */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="space-y-1.5">
            <label className="font-semibold text-gray-700 dark:text-gray-300">Data Locale</label>
            <select
              value={locale}
              onChange={(e) => setLocale(e.target.value)}
              className="w-full rounded-lg border border-gray-300 bg-white p-2 text-xs dark:border-slate-700 dark:bg-slate-800"
            >
              <option value="hi_IN">🇮🇳 Hindi / India (hi_IN — ₹ Rupee)</option>
              <option value="en_US">🇺🇸 English / US (en_US — $ Dollar)</option>
              <option value="en_GB">🇬🇧 English / UK (en_GB — £ Pound)</option>
              <option value="es_ES">🇪🇸 Spanish (es_ES — € Euro)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="font-semibold text-gray-700 dark:text-gray-300">Simulation Modes</label>
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-2 text-[11px] text-gray-600 dark:border-slate-800 dark:bg-slate-900 dark:text-gray-400">
              In-app DI Mock Repository + Standalone Dart fake server
            </div>
          </div>
        </div>

        {/* Network Chaos / Latency Sliders */}
        <div className="space-y-2 rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 text-xs dark:border-slate-800 dark:bg-slate-900/40">
          <h4 className="font-bold text-gray-900 uppercase tracking-wider dark:text-white text-[11px]">
            Network Simulation & Failure Injection (Dio Interceptor)
          </h4>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Simulated Latency:</span>
                <span className="font-mono text-indigo-600 dark:text-indigo-400">{latencyMs} ms</span>
              </div>
              <input
                type="range"
                min="0"
                max="2500"
                step="100"
                value={latencyMs}
                onChange={(e) => setLatencyMs(Number(e.target.value))}
                className="w-full cursor-pointer accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Simulated Failure Rate:</span>
                <span className="font-mono text-rose-600 dark:text-rose-400">{failureRate}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="5"
                value={failureRate}
                onChange={(e) => setFailureRate(Number(e.target.value))}
                className="w-full cursor-pointer accent-rose-600"
              />
            </div>
          </div>

          <div className="flex items-center gap-4 pt-1">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={emptyListScenario}
                onChange={(e) => setEmptyListScenario(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>Empty-list scenario</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={sim401}
                onChange={(e) => setSim401(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>401 Token-expired scenario</span>
            </label>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-2">
          <Button variant="outline" size="sm" onClick={() => setViewJson(!viewJson)}>
            <FileCode className="h-4 w-4 mr-1.5" />
            {viewJson ? 'Hide JSON' : 'Preview Fixture'}
          </Button>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleGenerate}>
              Generate Mock Server & Fixtures
            </Button>
          </div>
        </div>

        {viewJson && (
          <div className="rounded-xl bg-slate-950 p-4 font-mono text-[11px] text-emerald-400 max-h-52 overflow-y-auto whitespace-pre leading-relaxed">
            {sampleJson}
          </div>
        )}
      </div>
    </Modal>
  );
}
