'use client';

import { useState } from 'react';
import {
  Gauge,
  Zap,
  TrendingDown,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  FileCode,
  Sliders,
  Cpu,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface PerformanceBudgetModalProps {
  open: boolean;
  onClose: () => void;
}

export function PerformanceBudgetModal({ open, onClose }: PerformanceBudgetModalProps) {
  const [budgetMb, setBudgetMb] = useState(25);
  const [r8Shrinking, setR8Shrinking] = useState(true);
  const [splitPerAbi, setSplitPerAbi] = useState(true);
  const [obfuscate, setObfuscate] = useState(true);
  const [fontTreeShaking, setFontTreeShaking] = useState(true);
  const [parallelInit, setParallelInit] = useState(true);
  const [lazyHeavySdks, setLazyHeavySdks] = useState(true);

  const estimatedMb = 21.4;
  const isUnderBudget = estimatedMb <= budgetMb;

  const handleSave = () => {
    toast.success('Performance budget & Release optimization rules saved!');
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="📉 App Size & Performance Budget (#38)"
      description="Set production APK size budgets, configure R8 resource shrinking, split-per-abi, code obfuscation, and optimize startup latency via parallel bootstrapping."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Budget Slider & Meter */}
        <div className="rounded-xl border border-gray-200 bg-gray-50/70 p-4 dark:border-slate-800 dark:bg-slate-900/40 space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-gray-700 dark:text-gray-300">Target Size Budget (arm64 APK):</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400 text-sm">{budgetMb} MB</span>
          </div>
          <input
            type="range"
            min="15"
            max="50"
            step="1"
            value={budgetMb}
            onChange={(e) => setBudgetMb(Number(e.target.value))}
            className="w-full cursor-pointer accent-indigo-600"
          />

          {/* Meter Bar */}
          <div className="space-y-1.5 pt-1">
            <div className="flex justify-between text-xs">
              <span className="text-gray-500">Estimated Release Size:</span>
              <span
                className={`font-mono font-bold ${
                  isUnderBudget ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                ~{estimatedMb} MB {isUnderBudget ? '✅ (Under Budget)' : '⚠️ (Exceeds Budget)'}
              </span>
            </div>
            <div className="h-3 w-full rounded-full bg-gray-200 dark:bg-slate-800 overflow-hidden flex">
              <div style={{ width: '55%' }} className="bg-indigo-600 h-full" title="Base Engine (11.8 MB)" />
              <div style={{ width: '18%' }} className="bg-purple-500 h-full" title="Firebase Plugins (4.1 MB)" />
              <div style={{ width: '15%' }} className="bg-amber-500 h-full" title="Assets & Fonts (3.2 MB)" />
              <div style={{ width: '12%' }} className="bg-teal-500 h-full" title="Compiled Code (2.3 MB)" />
            </div>
            <div className="flex justify-between text-[10px] text-gray-400 pt-0.5">
              <span>Engine (11.8MB)</span>
              <span>Plugins (4.1MB)</span>
              <span>Assets (3.2MB)</span>
              <span>Code (2.3MB)</span>
            </div>
          </div>
        </div>

        {/* Smart Suggestions */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
            <Lightbulb className="h-4 w-4 text-amber-500" />
            <span>Optimization Suggestions</span>
          </label>
          <div className="rounded-xl border border-gray-200 bg-white p-3 text-xs dark:border-slate-800 dark:bg-slate-900 space-y-2">
            <div className="flex items-center justify-between text-gray-700 dark:text-gray-300">
              <span>• Convert raster PNG assets to WebP format</span>
              <span className="text-emerald-600 font-semibold font-mono text-[11px]">-40% typical asset size</span>
            </div>
            <div className="flex items-center justify-between text-gray-700 dark:text-gray-300">
              <span>• Split APK per ABI architecture (arm64-v8a / armeabi-v7a)</span>
              <span className="text-emerald-600 font-semibold font-mono text-[11px]">-60% download size</span>
            </div>
            <div className="flex items-center justify-between text-gray-700 dark:text-gray-300">
              <span>• Enable R8 code & resource shrinking in build.gradle</span>
              <span className="text-emerald-600 font-semibold font-mono text-[11px]">-15% DEX size</span>
            </div>
          </div>
        </div>

        {/* Release Build Flags Checkboxes */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={r8Shrinking}
              onChange={(e) => setR8Shrinking(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>R8 code shrinking & resource shrinking</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={splitPerAbi}
              onChange={(e) => setSplitPerAbi(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>--split-per-abi release build</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={obfuscate}
              onChange={(e) => setObfuscate(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>--obfuscate --split-debug-info</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={fontTreeShaking}
              onChange={(e) => setFontTreeShaking(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Font tree-shaking</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={parallelInit}
              onChange={(e) => setParallelInit(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Parallel service init (Future.wait)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={lazyHeavySdks}
              onChange={(e) => setLazyHeavySdks(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Lazy-init heavy SDKs after first frame</span>
          </label>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Optimization Flags
          </Button>
        </div>
      </div>
    </Modal>
  );
}
