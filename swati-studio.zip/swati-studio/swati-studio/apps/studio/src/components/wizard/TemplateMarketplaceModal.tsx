'use client';

import { useState } from 'react';
import {
  enterpriseTemplates,
  type AppTemplate,
  type StudioConfig,
} from '@swati/schema';
import {
  Check,
  Compass,
  FileText,
  Flame,
  Heart,
  LayoutGrid,
  MessageCircle,
  Package,
  Search,
  ShoppingCart,
  Sparkles,
  User,
  Zap,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface TemplateMarketplaceModalProps {
  open: boolean;
  onClose: () => void;
  onApplyTemplate: (template: AppTemplate) => void;
}

const ICON_MAP: Record<string, React.ReactNode> = {
  ShoppingCart: <ShoppingCart className="h-5 w-5" />,
  MessageCircle: <MessageCircle className="h-5 w-5" />,
  LayoutGrid: <LayoutGrid className="h-5 w-5" />,
  Sparkles: <Sparkles className="h-5 w-5" />,
  FileText: <FileText className="h-5 w-5" />,
  Heart: <Heart className="h-5 w-5" />,
  Zap: <Zap className="h-5 w-5" />,
  Flame: <Flame className="h-5 w-5" />,
  Check: <Check className="h-5 w-5" />,
};

export function TemplateMarketplaceModal({
  open,
  onClose,
  onApplyTemplate,
}: TemplateMarketplaceModalProps) {
  const [selectedId, setSelectedId] = useState<string>(enterpriseTemplates[0].id);
  const [search, setSearch] = useState('');

  const filtered = enterpriseTemplates.filter((t) =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.desc.toLowerCase().includes(search.toLowerCase()) ||
    t.category.toLowerCase().includes(search.toLowerCase())
  );

  const activeTemplate = enterpriseTemplates.find((t) => t.id === selectedId) ?? enterpriseTemplates[0];

  const handleApply = () => {
    onApplyTemplate(activeTemplate);
    toast.success(`Applied ${activeTemplate.name} template! All steps configured.`);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🚀 Enterprise App Templates (Step 0)"
      description="Pick a pre-configured enterprise starter to fast-track your app development by 80%"
      size="xl"
    >
      <div className="flex flex-col gap-6 lg:flex-row">
        {/* Left side: Search & Template List */}
        <div className="flex flex-1 flex-col gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search templates (e-commerce, food, chat, fintech)..."
              className="w-full rounded-xl border border-gray-200 bg-gray-50 py-2 pl-9 pr-4 text-sm text-gray-900 outline-none transition focus:border-indigo-500 focus:bg-white dark:border-slate-800 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <div className="max-h-[380px] space-y-2 overflow-y-auto pr-1">
            {filtered.map((tmpl) => {
              const isSelected = tmpl.id === activeTemplate.id;
              return (
                <div
                  key={tmpl.id}
                  onClick={() => setSelectedId(tmpl.id)}
                  className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 transition ${
                    isSelected
                      ? 'border-indigo-500 bg-indigo-50/70 shadow-sm dark:border-indigo-500 dark:bg-indigo-950/40'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50 dark:border-slate-800 dark:hover:bg-slate-900'
                  }`}
                >
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-gray-100 text-gray-600 dark:bg-slate-800 dark:text-gray-300'
                    }`}
                  >
                    {ICON_MAP[tmpl.icon] ?? <Package className="h-5 w-5" />}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                        {tmpl.name}
                      </h4>
                      {tmpl.badge && (
                        <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-[10px] font-bold text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300">
                          {tmpl.badge}
                        </span>
                      )}
                    </div>
                    <p className="mt-0.5 text-xs text-gray-500 line-clamp-2 dark:text-gray-400">
                      {tmpl.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right side: Detailed Preset Stack Preview */}
        <div className="flex flex-1 flex-col justify-between rounded-2xl border border-gray-200 bg-gray-50/70 p-5 dark:border-slate-800 dark:bg-slate-900/70">
          <div className="space-y-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Preset Tech Stack
              </span>
              <h3 className="text-base font-bold text-gray-900 dark:text-white">
                {activeTemplate.name}
              </h3>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {activeTemplate.desc}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="rounded-lg border border-gray-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-800">
                <span className="text-[10px] text-gray-400 uppercase">Backend</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(activeTemplate.presetConfig['backend.provider'])}
                </p>
              </div>

              <div className="rounded-lg border border-gray-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-800">
                <span className="text-[10px] text-gray-400 uppercase">State Engine</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(activeTemplate.presetConfig['state.manager'])}
                </p>
              </div>

              <div className="rounded-lg border border-gray-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-800">
                <span className="text-[10px] text-gray-400 uppercase">UI & Theme Mode</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(activeTemplate.presetConfig['frontend.uiStyle'])} ({String(activeTemplate.presetConfig['frontend.themeMode'])})
                </p>
              </div>

              <div className="rounded-lg border border-gray-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-800">
                <span className="text-[10px] text-gray-400 uppercase">Database</span>
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  {String(activeTemplate.presetConfig['database.engine'])}
                </p>
              </div>
            </div>

            <div>
              <span className="text-[11px] font-bold text-gray-700 dark:text-gray-300">
                Pre-configured Screens & Nav:
              </span>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {((activeTemplate.presetConfig['navigation.items'] as { name: string }[]) ?? []).map((nav) => (
                  <span
                    key={nav.name}
                    className="rounded-md bg-white px-2 py-1 text-[11px] font-medium text-gray-700 shadow-xs border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-gray-300"
                  >
                    📱 {nav.name}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-slate-800">
            <Button variant="ghost" onClick={onClose} size="sm">
              Cancel
            </Button>
            <Button onClick={handleApply} size="sm" className="bg-indigo-600 text-white hover:bg-indigo-700">
              Apply This Template
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}
