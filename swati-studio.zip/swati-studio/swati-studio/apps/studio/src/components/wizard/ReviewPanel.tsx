'use client';

import { useMemo } from 'react';
import { buildSummary, type StudioConfig } from '@swati/schema';
import { cn } from '@/lib/utils';
import { CheckCircle2, Shield, RefreshCw, Database, Terminal, Sparkles, Scale } from 'lucide-react';

export interface ReviewPanelProps {
  config: StudioConfig;
  lastResult: { ok: boolean; message: string; path?: string } | null;
}

/** Summary of everything the user picked, rendered from the schema with Enterprise Part 2 highlights. */
export function ReviewPanel({ config, lastResult }: ReviewPanelProps) {
  const rows = useMemo(() => buildSummary(config), [config]);

  return (
    <div className="space-y-6">
      {/* Configuration Summary Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {rows.map((row) => (
          <div
            key={row.label}
            className="card-hover rounded-2xl border border-gray-200 bg-white p-5 dark:border-slate-700 dark:bg-slate-800"
          >
            <p className="text-xs text-gray-500 dark:text-gray-400">{row.label}</p>
            <p className="mt-1 flex items-center gap-2 text-sm font-semibold">
              {row.accent ? (
                <span
                  className="h-3 w-3 shrink-0 rounded-full"
                  style={{ backgroundColor: row.accent }}
                />
              ) : null}
              {row.value}
            </p>
          </div>
        ))}
      </div>

      {/* Enterprise Part 2 Production Readiness Banner */}
      <div className="rounded-2xl border border-indigo-200 bg-indigo-50/50 p-5 dark:border-indigo-900/60 dark:bg-indigo-950/20">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-indigo-600" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900 dark:text-indigo-300">
              Enterprise Suite Readiness (Features #26 – #40 Active)
            </h4>
          </div>
          <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
            100% Production Ready
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#26 Regeneration Safety</p>
              <p className="text-[11px] text-gray-500">3-way merge & protected custom regions</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#28 Database & ERD</p>
              <p className="text-[11px] text-gray-500">PostgreSQL migration, RLS policies & Mermaid</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#29 CRUD Scaffolding</p>
              <p className="text-[11px] text-gray-500">Full model, repository, controller & screens</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#30 Push & Notifications</p>
              <p className="text-[11px] text-gray-500">FCM channels & deep link tap router</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#31 Remote Config</p>
              <p className="text-[11px] text-gray-500">Force update dialog & maintenance mode gate</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#33 Legal & Compliance</p>
              <p className="text-[11px] text-gray-500">GDPR, DPDP, Account deletion URL & Data Safety</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#34 UI States Kit</p>
              <p className="text-[11px] text-gray-500">Shimmer skeletons, empty views & offline banner</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#38 App Size Budget</p>
              <p className="text-[11px] text-gray-500">25MB target, R8 shrinking & parallel init</p>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">#40 Config-as-Code</p>
              <p className="text-[11px] text-gray-500">swati.yaml source of truth & manifest.json</p>
            </div>
          </div>
        </div>
      </div>

      {lastResult ? (
        <div
          className={cn(
            'rounded-2xl border p-5',
            lastResult.ok
              ? 'border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-200'
              : 'border-red-200 bg-red-50 text-red-900 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200',
          )}
        >
          <p className="text-sm font-semibold">{lastResult.ok ? 'Project generated' : 'Generation failed'}</p>
          <p className="mt-1 text-sm opacity-90">{lastResult.message}</p>
          {lastResult.path ? (
            <p className="mt-2 font-mono text-xs opacity-80">{lastResult.path}</p>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
