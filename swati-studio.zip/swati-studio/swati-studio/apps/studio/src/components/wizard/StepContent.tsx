'use client';

import { useMemo } from 'react';
import {
  fieldsForStep,
  steps,
  type FieldDef,
  type FieldValue,
  type StudioConfig,
} from '@swati/schema';
import { SchemaField } from '@/components/ui/SchemaField';
import { cn } from '@/lib/utils';

export interface StepContentProps {
  stepIndex: number;
  config: StudioConfig;
  errors: Record<string, string>;
  onChange: (id: string, value: FieldValue) => void;
  onToggle: (id: string, value: string) => void;
}

/** Renders the active step: title, description and every field it owns. */
export function StepContent({ stepIndex, config, errors, onChange, onToggle }: StepContentProps) {
  const step = steps[stepIndex];
  const fields = useMemo(
    () => fieldsForStep(step, config as unknown as Record<string, unknown>),
    [step, config],
  );
  const customColor = String(config['frontend.customColor'] ?? '#6366f1');
  const navStyle = String(config['navigation.style'] ?? 'bottom_nav');

  const groups = groupFields(fields);

  return (
    <div className="animate-slide-up">
      <div className="mb-8 text-center">
        <h2 className="mb-2 text-2xl font-bold">{step.title}</h2>
        <p className="text-gray-500 dark:text-gray-400">{step.subtitle}</p>
      </div>

      <div className="space-y-8">
        {groups.map((group) => (
          <section key={group.name} className="space-y-4">
            {group.name ? (
              <div className="flex items-center gap-3">
                <h3 className="text-xs font-semibold tracking-wider text-gray-400 uppercase">
                  {group.name}
                </h3>
                <span className="h-px flex-1 bg-gray-200 dark:bg-slate-800" />
              </div>
            ) : null}
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {group.fields.map((field) => (
                <div
                  key={field.id}
                  className={cn(
                    field.kind === 'select' && field.presentation === 'cards' && 'md:col-span-2',
                    field.kind === 'multiselect' && 'md:col-span-2',
                    field.kind === 'textarea' && 'md:col-span-2',
                    field.kind === 'list' && 'md:col-span-2',
                    field.kind === 'file' && 'md:col-span-2',
                  )}
                >
                  <SchemaField
                    field={field}
                    value={config[field.id] ?? null}
                    customColor={customColor}
                    error={errors[field.id]}
                    navStyle={navStyle}
                    onChange={onChange}
                    onToggle={onToggle}
                  />
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

interface FieldGroup {
  name: string;
  fields: FieldDef[];
}

function groupFields(fields: FieldDef[]): FieldGroup[] {
  const groups: FieldGroup[] = [];
  for (const field of fields) {
    const name = field.group ?? '';
    const existing = groups.find((group) => group.name === name);
    if (existing) existing.fields.push(field);
    else groups.push({ name, fields: [field] });
  }
  return groups;
}
