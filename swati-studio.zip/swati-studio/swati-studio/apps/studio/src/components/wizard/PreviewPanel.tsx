'use client';

import { useMemo } from 'react';
import { buildTree, generateProject, type TreeNode } from '@swati/generator';
import type { StudioConfig } from '@swati/schema';

export interface PreviewPanelProps {
  config: StudioConfig;
}

/** File tree + project stats, computed by the real generator. */
export function PreviewPanel({ config }: PreviewPanelProps) {
  const result = useMemo(() => {
    try {
      return generateProject(config);
    } catch (error) {
      console.error(error);
      return null;
    }
  }, [config]);

  if (!result) {
    return <p className="text-sm text-gray-500">Could not compute the project preview.</p>;
  }

  const tree = buildTree(result.files);

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <div className="space-y-4">
        <h3 className="font-semibold">Generated folder structure</h3>
        <div className="overflow-x-auto rounded-xl bg-gray-900 p-4 font-mono text-xs text-gray-300">
          <TreeView node={tree} depth={0} />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-semibold">What will be written</h3>
        <div className="space-y-3">
          <Stat label="Files" value={String(result.summary.files)} />
          <Stat label="Folders" value={String(result.summary.directories.length)} />
          <Stat label="Pub packages" value={String(result.summary.packages)} />
          <Stat label="Estimated size" value={`~${result.summary.estimatedSizeKb} KB`} />
          <Stat label="Architecture" value={result.context.architectureName} />
          <Stat label="State management" value={result.context.stateName} />
          <Stat label="Backend" value={result.context.backendName} />
          <Stat label="Database" value={result.context.databaseName} />
        </div>

        <h3 className="pt-2 font-semibold">Package preview</h3>
        <div className="flex flex-wrap gap-1.5">
          {result.context.packages.map((pkg) => (
            <span
              key={pkg.name}
              className="rounded-md bg-gray-100 px-2 py-0.5 font-mono text-[11px] text-gray-700 dark:bg-slate-700 dark:text-gray-200"
            >
              {pkg.name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-lg border border-gray-200 bg-white p-3 dark:border-slate-700 dark:bg-slate-800">
      <span className="text-sm text-gray-500 dark:text-gray-400">{label}</span>
      <span className="text-sm font-medium">{value}</span>
    </div>
  );
}

function TreeView({ node, depth }: { node: TreeNode; depth: number }) {
  if (depth === 0) {
    return (
      <>
        {node.children.map((child) => (
          <TreeView key={child.path} node={child} depth={1} />
        ))}
      </>
    );
  }
  return (
    <>
      <div style={{ paddingLeft: depth * 12 }} className="whitespace-pre">
        {depth > 1 ? '├── ' : ''}
        {node.name}
        {node.isFile ? '' : '/'}
      </div>
      {node.children.map((child) => (
        <TreeView key={child.path} node={child} depth={depth + 1} />
      ))}
    </>
  );
}
