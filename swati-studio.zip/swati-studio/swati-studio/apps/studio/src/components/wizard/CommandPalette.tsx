'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bot,
  Cpu,
  DollarSign,
  Package,
  Puzzle,
  Search,
  Share2,
  Sparkles,
  RefreshCw,
  FolderSearch,
  Database,
  Boxes,
  Bell,
  Sliders,
  Server,
  Scale,
  Palette,
  Image as ImageIcon,
  Zap,
  Eye,
  Gauge,
  BookOpen,
  Terminal,
} from 'lucide-react';
import { steps } from '@swati/schema';
import { Modal } from '@/components/ui/Modal';

export interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
  onSelectStep: (index: number) => void;
  onOpenTemplates?: () => void;
  onOpenAiWizard?: () => void;
  onOpenHealth?: () => void;
  onOpenCost?: () => void;
  onOpenTeamCollab?: () => void;
  onOpenPlugins?: () => void;
  // Part 2 Enterprise Features (#26 to #40)
  onOpenRegeneration?: () => void;
  onOpenBrownfield?: () => void;
  onOpenSchemaDesigner?: () => void;
  onOpenCrudScaffolder?: () => void;
  onOpenPushNotifications?: () => void;
  onOpenRemoteConfig?: () => void;
  onOpenBackendScaffold?: () => void;
  onOpenCompliance?: () => void;
  onOpenUiStates?: () => void;
  onOpenBranding?: () => void;
  onOpenMockData?: () => void;
  onOpenAccessibility?: () => void;
  onOpenPerfBudget?: () => void;
  onOpenAutoDocs?: () => void;
  onOpenConfigAsCode?: () => void;
}

interface Entry {
  step?: number;
  label: string;
  desc: string;
  action?:
    | 'templates'
    | 'ai_wizard'
    | 'health'
    | 'cost'
    | 'team'
    | 'plugins'
    | 'regen'
    | 'brownfield'
    | 'schema'
    | 'crud'
    | 'push'
    | 'remote_config'
    | 'backend'
    | 'compliance'
    | 'ui_states'
    | 'branding'
    | 'mock'
    | 'a11y'
    | 'perf'
    | 'autodocs'
    | 'cli';
}

const ENTRIES: Entry[] = [
  // Enterprise Part 1 Actions
  { label: '🎨 Browse Enterprise Templates', desc: 'Step 0: Choose pre-configured starter (E-Commerce, Social, Food)', action: 'templates' },
  { label: '🤖 AI Smart Wizard Prompt', desc: 'Describe app in 1 sentence for instant auto-config', action: 'ai_wizard' },
  { label: '📊 Project Health Dashboard', desc: 'Inspect architecture, security compliance and score', action: 'health' },
  { label: '💲 Smart Cost Estimation', desc: 'Projected monthly infrastructure expenses in USD & INR', action: 'cost' },
  { label: '👥 Team Collaboration & Share', desc: 'Generate share link or apply corporate preset', action: 'team' },
  { label: '🧩 Plugin Marketplace', desc: 'Install GraphQL, Stripe, WebSockets, PDF addons', action: 'plugins' },

  // Enterprise Part 2 Actions (#26 to #40)
  { label: '🔁 #26 Regeneration-Safe Codegen Preview', desc: 'Dry-run preview with 3-way merge & protected custom regions', action: 'regen' },
  { label: '📂 #27 Brownfield Mode — Import Project', desc: 'Scan existing Flutter project and safely inject enterprise addons', action: 'brownfield' },
  { label: '🗄️ #28 Database Schema Designer', desc: 'Visual ER diagram, SQL migrations, Drift entities, and Supabase RLS', action: 'schema' },
  { label: '🧱 #29 CRUD & Form Scaffolder', desc: 'Scaffold lists, search/filter, detail views, and validated forms', action: 'crud' },
  { label: '🔔 #30 Push Notification Setup', desc: 'FCM / OneSignal providers, Android 13 permissions & channels', action: 'push' },
  { label: '🎛️ #31 Remote Config & Maintenance Mode', desc: 'Runtime feature flags, force update blocker, and maintenance gate', action: 'remote_config' },
  { label: '🖥️ #32 Backend Scaffold Generator', desc: 'Dart Frog, Rust Axum, Node Fastify or Supabase with OpenAPI contract', action: 'backend' },
  { label: '⚖️ #33 Legal & Store Compliance Kit', desc: 'Privacy Policy, Terms, Play Store Data Safety, and Account Deletion', action: 'compliance' },
  { label: '🧩 #34 Standard UI States Kit', desc: 'Shimmer skeletons, zero-data empty views, and offline banners', action: 'ui_states' },
  { label: '🖼️ #35 App Icon & Splash Branding', desc: 'Adaptive icon masks preview, Android 12+ splash, and store assets', action: 'branding' },
  { label: '🎭 #36 Mock Data & Fake Server', desc: 'Realistic faker datasets, latency & error simulator, local server', action: 'mock' },
  { label: '♿ #37 Accessibility & Responsive Breakpoints', desc: 'Adaptive layout rail/drawer + live WCAG AA contrast validation', action: 'a11y' },
  { label: '📉 #38 App Size & Performance Budget', desc: '25MB budget meter, R8 shrinking, parallel app bootstrapping', action: 'perf' },
  { label: '📚 #39 Auto Documentation Generator', desc: 'README, ARCHITECTURE with Mermaid, and Architecture Decision Records', action: 'autodocs' },
  { label: '💻 #40 Headless CLI & Config-as-Code', desc: 'swati.yaml source of truth editor, CLI commands & JSON schema', action: 'cli' },

  // Wizard Steps (11 Steps)
  { step: 0, label: 'Theme & UI Style', desc: 'Step 1: 43 UI styles, AMOLED #000, Sepia & mixed combos' },
  { step: 1, label: 'Navigation & Dynamic Screens', desc: 'Step 2: 11 bottom bar styles & dynamic screen buttons' },
  { step: 2, label: 'Project Metadata', desc: 'Step 3: Name, package ID, environments & CI/CD' },
  { step: 3, label: 'Database & Asset Import', desc: 'Step 4: Database engine & .db file upload' },
  { step: 4, label: 'Backend Provider', desc: 'Step 5: Supabase, Firebase, PocketBase or REST' },
  { step: 5, label: 'Architecture Pattern', desc: 'Step 6: Feature-first or Clean Architecture' },
  { step: 6, label: 'State Management', desc: 'Step 7: Riverpod, Bloc, Provider or GetX' },
  { step: 7, label: 'Features & Capabilities', desc: 'Step 8: Auth methods, RBAC, offline sync, notifications' },
  { step: 8, label: 'Component Library', desc: 'Step 9: Shared UI widget primitives' },
  { step: 9, label: 'File Tree Preview', desc: 'Step 10: Inspect generated project structure' },
  { step: 10, label: 'Review & Generate', desc: 'Step 11: Summary and write files to disk' },
];

/** Supercharged command palette that handles natural language searches and instant actions. */
export function CommandPalette({
  open,
  onClose,
  onSelectStep,
  onOpenTemplates,
  onOpenAiWizard,
  onOpenHealth,
  onOpenCost,
  onOpenTeamCollab,
  onOpenPlugins,
  onOpenRegeneration,
  onOpenBrownfield,
  onOpenSchemaDesigner,
  onOpenCrudScaffolder,
  onOpenPushNotifications,
  onOpenRemoteConfig,
  onOpenBackendScaffold,
  onOpenCompliance,
  onOpenUiStates,
  onOpenBranding,
  onOpenMockData,
  onOpenAccessibility,
  onOpenPerfBudget,
  onOpenAutoDocs,
  onOpenConfigAsCode,
}: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setQuery('');
      setActiveIndex(0);
      window.setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return ENTRIES;
    return ENTRIES.filter((entry) =>
      `${entry.label} ${entry.desc}`.toLowerCase().includes(q)
    );
  }, [query]);

  useEffect(() => {
    setActiveIndex(0);
  }, [query]);

  useEffect(() => {
    if (!open) return;
    const active = listRef.current?.querySelector<HTMLElement>('[aria-selected="true"]');
    active?.scrollIntoView({ block: 'nearest' });
  }, [activeIndex, open, results.length]);

  const select = (index: number) => {
    const entry = results[index];
    if (!entry) return;

    if (entry.action) {
      onClose();
      switch (entry.action) {
        case 'templates': onOpenTemplates?.(); break;
        case 'ai_wizard': onOpenAiWizard?.(); break;
        case 'health': onOpenHealth?.(); break;
        case 'cost': onOpenCost?.(); break;
        case 'team': onOpenTeamCollab?.(); break;
        case 'plugins': onOpenPlugins?.(); break;
        case 'regen': onOpenRegeneration?.(); break;
        case 'brownfield': onOpenBrownfield?.(); break;
        case 'schema': onOpenSchemaDesigner?.(); break;
        case 'crud': onOpenCrudScaffolder?.(); break;
        case 'push': onOpenPushNotifications?.(); break;
        case 'remote_config': onOpenRemoteConfig?.(); break;
        case 'backend': onOpenBackendScaffold?.(); break;
        case 'compliance': onOpenCompliance?.(); break;
        case 'ui_states': onOpenUiStates?.(); break;
        case 'branding': onOpenBranding?.(); break;
        case 'mock': onOpenMockData?.(); break;
        case 'a11y': onOpenAccessibility?.(); break;
        case 'perf': onOpenPerfBudget?.(); break;
        case 'autodocs': onOpenAutoDocs?.(); break;
        case 'cli': onOpenConfigAsCode?.(); break;
      }
      return;
    }

    if (entry.step !== undefined) {
      onSelectStep(entry.step);
      onClose();
    }
  };

  const activeId = results[activeIndex] ? `command-palette-option-${activeIndex}` : undefined;

  return (
    <Modal open={open} onClose={onClose} ariaLabel="Command palette" className="max-w-2xl p-0">
      <div className="flex items-center gap-3 border-b border-gray-200 p-4 dark:border-slate-700">
        <Search className="h-5 w-5 text-gray-400" aria-hidden="true" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search features, tools, or press Enter to run action…"
          className="w-full bg-transparent text-sm focus:outline-hidden"
          role="combobox"
          aria-expanded={results.length > 0}
          aria-autocomplete="list"
          aria-controls="command-palette-list"
          aria-activedescendant={activeId}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') {
              e.preventDefault();
              setActiveIndex((i) => (i + 1) % results.length);
            } else if (e.key === 'ArrowUp') {
              e.preventDefault();
              setActiveIndex((i) => (i - 1 + results.length) % results.length);
            } else if (e.key === 'Enter') {
              e.preventDefault();
              select(activeIndex);
            }
          }}
        />
        <span className="text-xs text-gray-400">ESC</span>
      </div>

      <div id="command-palette-list" ref={listRef} role="listbox" className="max-h-96 overflow-y-auto p-2">
        {results.length === 0 ? (
          <p className="p-4 text-center text-sm text-gray-500">No results found for &ldquo;{query}&rdquo;</p>
        ) : (
          results.map((entry, index) => {
            const isSelected = index === activeIndex;
            return (
              <div
                key={entry.label}
                id={`command-palette-option-${index}`}
                role="option"
                aria-selected={isSelected}
                onClick={() => select(index)}
                onMouseEnter={() => setActiveIndex(index)}
                className={`flex cursor-pointer items-center justify-between rounded-lg p-3 text-sm transition ${
                  isSelected
                    ? 'bg-indigo-50 text-indigo-900 dark:bg-indigo-950/60 dark:text-indigo-200'
                    : 'hover:bg-gray-50 dark:hover:bg-slate-800'
                }`}
              >
                <div>
                  <div className="font-medium">{entry.label}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">{entry.desc}</div>
                </div>
                {entry.step !== undefined ? (
                  <span className="rounded bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-slate-700 dark:text-gray-300">
                    Step {entry.step + 1}
                  </span>
                ) : (
                  <span className="rounded bg-indigo-100 px-2 py-0.5 text-xs text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300">
                    Enterprise
                  </span>
                )}
              </div>
            );
          })
        )}
      </div>
    </Modal>
  );
}
