'use client';

import { useState } from 'react';
import {
  Bell,
  Smartphone,
  ShieldCheck,
  Radio,
  Flame,
  Volume2,
  Vibrate,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface ChannelConfig {
  id: string;
  name: string;
  importance: 'high' | 'default' | 'low';
  sound: boolean;
  vibrate: boolean;
}

const DEFAULT_CHANNELS: ChannelConfig[] = [
  { id: 'orders', name: '📦 Orders & Deliveries', importance: 'high', sound: true, vibrate: true },
  { id: 'chat', name: '💬 Direct Messages', importance: 'high', sound: true, vibrate: true },
  { id: 'promos', name: '🎁 Special Promotions', importance: 'default', sound: false, vibrate: false },
];

interface PushNotificationsModalProps {
  open: boolean;
  onClose: () => void;
}

export function PushNotificationsModal({ open, onClose }: PushNotificationsModalProps) {
  const [provider, setProvider] = useState<'fcm' | 'onesignal' | 'local'>('fcm');
  const [channels, setChannels] = useState<ChannelConfig[]>(DEFAULT_CHANNELS);
  const [promptTiming, setPromptTiming] = useState<'launch' | 'onboarding' | 'contextual'>('onboarding');
  const [foregroundBanner, setForegroundBanner] = useState(true);
  const [deepLinkRouting, setDeepLinkRouting] = useState(true);
  const [tokenSyncBackend, setTokenSyncBackend] = useState(true);
  const [inboxEnabled, setInboxEnabled] = useState(true);

  const handleSave = () => {
    toast.success('Push notification configuration saved!');
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🔔 Push Notification Setup (#30)"
      description="Configure FCM/OneSignal providers, Android 13 runtime permissions, high-priority notification channels, and deep link tap routing."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Provider Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">Push Provider</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setProvider('fcm')}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                provider === 'fcm'
                  ? 'border-orange-500 bg-orange-50/60 dark:bg-orange-950/20'
                  : 'border-gray-200 hover:border-gray-300 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="text-xs font-bold text-gray-900 dark:text-white">Firebase FCM</span>
              </div>
              <p className="text-[10px] text-gray-500 mt-1">Cross-platform Google FCM</p>
            </button>

            <button
              type="button"
              onClick={() => setProvider('onesignal')}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                provider === 'onesignal'
                  ? 'border-purple-500 bg-purple-50/60 dark:bg-purple-950/20'
                  : 'border-gray-200 hover:border-gray-300 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Radio className="h-4 w-4 text-purple-500" />
                <span className="text-xs font-bold text-gray-900 dark:text-white">OneSignal</span>
              </div>
              <p className="text-[10px] text-gray-500 mt-1">Marketing & In-app campaigns</p>
            </button>

            <button
              type="button"
              onClick={() => setProvider('local')}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                provider === 'local'
                  ? 'border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/20'
                  : 'border-gray-200 hover:border-gray-300 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Smartphone className="h-4 w-4 text-indigo-500" />
                <span className="text-xs font-bold text-gray-900 dark:text-white">Local Only</span>
              </div>
              <p className="text-[10px] text-gray-500 mt-1">Offline scheduled notifications</p>
            </button>
          </div>
        </div>

        {/* Channels Manager */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Android Notification Channels
          </label>
          <div className="rounded-xl border border-gray-200 dark:border-slate-800 overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-gray-100 dark:bg-slate-800 text-gray-500 font-semibold">
                <tr>
                  <th className="p-2.5">Channel Name</th>
                  <th className="p-2.5">Importance</th>
                  <th className="p-2.5 text-center">Sound</th>
                  <th className="p-2.5 text-center">Vibrate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                {channels.map((ch, idx) => (
                  <tr key={ch.id} className="hover:bg-gray-50 dark:hover:bg-slate-850">
                    <td className="p-2.5 font-medium">{ch.name}</td>
                    <td className="p-2.5 uppercase font-mono text-[10px] text-indigo-600 dark:text-indigo-400">
                      {ch.importance}
                    </td>
                    <td className="p-2.5 text-center">
                      <input
                        type="checkbox"
                        checked={ch.sound}
                        onChange={(e) => {
                          const val = e.target.checked;
                          setChannels(channels.map((c, i) => (i === idx ? { ...c, sound: val } : c)));
                        }}
                        className="rounded text-indigo-600"
                      />
                    </td>
                    <td className="p-2.5 text-center">
                      <input
                        type="checkbox"
                        checked={ch.vibrate}
                        onChange={(e) => {
                          const val = e.target.checked;
                          setChannels(channels.map((c, i) => (i === idx ? { ...c, vibrate: val } : c)));
                        }}
                        className="rounded text-indigo-600"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Permission Timing */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Permission Request Timing (Android 13+ & iOS)
          </label>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <label className="flex items-center gap-2 rounded-lg border border-gray-200 p-2.5 cursor-pointer dark:border-slate-800">
              <input
                type="radio"
                name="promptTiming"
                checked={promptTiming === 'launch'}
                onChange={() => setPromptTiming('launch')}
                className="text-indigo-600"
              />
              <span>On First Launch</span>
            </label>
            <label className="flex items-center gap-2 rounded-lg border border-gray-200 p-2.5 cursor-pointer dark:border-slate-800">
              <input
                type="radio"
                name="promptTiming"
                checked={promptTiming === 'onboarding'}
                onChange={() => setPromptTiming('onboarding')}
                className="text-indigo-600"
              />
              <span>After Onboarding</span>
            </label>
            <label className="flex items-center gap-2 rounded-lg border border-gray-200 p-2.5 cursor-pointer dark:border-slate-800">
              <input
                type="radio"
                name="promptTiming"
                checked={promptTiming === 'contextual'}
                onChange={() => setPromptTiming('contextual')}
                className="text-indigo-600"
              />
              <span>Contextual (Order placement)</span>
            </label>
          </div>
        </div>

        {/* Behavior Toggles */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={foregroundBanner}
              onChange={(e) => setForegroundBanner(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Show local banner when app is in foreground</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={deepLinkRouting}
              onChange={(e) => setDeepLinkRouting(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Tap deep link to screen router</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={tokenSyncBackend}
              onChange={(e) => setTokenSyncBackend(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Auto-sync FCM device token to backend</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={inboxEnabled}
              onChange={(e) => setInboxEnabled(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>In-app notification history & unread badge</span>
          </label>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Notification Setup
          </Button>
        </div>
      </div>
    </Modal>
  );
}
