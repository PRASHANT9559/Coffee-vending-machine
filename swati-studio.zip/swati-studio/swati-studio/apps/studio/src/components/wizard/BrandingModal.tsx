'use client';

import { useState } from 'react';
import {
  Image as ImageIcon,
  Palette,
  Upload,
  CheckCircle2,
  Smartphone,
  Eye,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface BrandingModalProps {
  open: boolean;
  onClose: () => void;
}

export function BrandingModal({ open, onClose }: BrandingModalProps) {
  const [brandColor, setBrandColor] = useState('#6366F1');
  const [darkBg, setDarkBg] = useState('#0F172A');
  const [adaptiveIcon, setAdaptiveIcon] = useState(true);
  const [themedIcon, setThemedIcon] = useState(true);
  const [iosIcon, setIosIcon] = useState(true);
  const [webFavicon, setWebFavicon] = useState(true);
  const [splashApi, setSplashApi] = useState(true);
  const [storeGraphics, setStoreGraphics] = useState(true);

  const handleGenerate = () => {
    toast.success('Generated launcher icons and native splash configurations!');
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🖼️ App Icon, Splash & Branding Generator (#35)"
      description="Upload your logo once. Automatically generate Android adaptive icons, monochrome themed icons, iOS icons, and Android 12+ splash screens."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Logo Upload Simulation */}
        <div className="flex items-center gap-4 rounded-xl border border-dashed border-gray-300 bg-gray-50/70 p-4 dark:border-slate-700 dark:bg-slate-900/40">
          <div
            className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl shadow-md text-white font-bold text-xl"
            style={{ backgroundColor: brandColor }}
          >
            🎨
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-gray-900 dark:text-white">Master Brand Logo (1024×1024)</h4>
            <p className="text-[11px] text-gray-500">
              High-resolution PNG or SVG used to generate all launcher and store assets.
            </p>
            <Button size="sm" variant="outline" className="h-7 text-xs mt-1">
              <Upload className="h-3.5 w-3.5 mr-1" />
              Choose Image
            </Button>
          </div>
        </div>

        {/* Colors Selection */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="space-y-1.5">
            <label className="font-semibold text-gray-700 dark:text-gray-300">Brand Primary Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={brandColor}
                onChange={(e) => setBrandColor(e.target.value)}
                className="h-8 w-12 rounded cursor-pointer border-0"
              />
              <input
                type="text"
                value={brandColor}
                onChange={(e) => setBrandColor(e.target.value)}
                className="w-24 rounded-lg border border-gray-300 px-2 py-1 font-mono uppercase dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="font-semibold text-gray-700 dark:text-gray-300">Splash Dark Background</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={darkBg}
                onChange={(e) => setDarkBg(e.target.value)}
                className="h-8 w-12 rounded cursor-pointer border-0"
              />
              <input
                type="text"
                value={darkBg}
                onChange={(e) => setDarkBg(e.target.value)}
                className="w-24 rounded-lg border border-gray-300 px-2 py-1 font-mono uppercase dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
          </div>
        </div>

        {/* Mask Previews */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-700 dark:text-gray-300">
            Android Adaptive Mask Previews
          </label>
          <div className="flex items-center justify-around rounded-xl border border-gray-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <div className="text-center space-y-1">
              <div
                className="h-12 w-12 rounded-lg flex items-center justify-center text-white text-lg shadow-sm mx-auto"
                style={{ backgroundColor: brandColor }}
              >
                🎨
              </div>
              <span className="text-[10px] text-gray-400">Square</span>
            </div>
            <div className="text-center space-y-1">
              <div
                className="h-12 w-12 rounded-2xl flex items-center justify-center text-white text-lg shadow-sm mx-auto"
                style={{ backgroundColor: brandColor }}
              >
                🎨
              </div>
              <span className="text-[10px] text-gray-400">Squircle</span>
            </div>
            <div className="text-center space-y-1">
              <div
                className="h-12 w-12 rounded-full flex items-center justify-center text-white text-lg shadow-sm mx-auto"
                style={{ backgroundColor: brandColor }}
              >
                🎨
              </div>
              <span className="text-[10px] text-gray-400">Circle</span>
            </div>
            <div className="text-center space-y-1">
              <div
                className="h-12 w-12 rounded-tl-full rounded-tr-full rounded-br-full flex items-center justify-center text-white text-lg shadow-sm mx-auto"
                style={{ backgroundColor: brandColor }}
              >
                🎨
              </div>
              <span className="text-[10px] text-gray-400">Teardrop</span>
            </div>
          </div>
        </div>

        {/* Feature Checkboxes */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={adaptiveIcon}
              onChange={(e) => setAdaptiveIcon(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Android adaptive icon (layers)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={themedIcon}
              onChange={(e) => setThemedIcon(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Android 13 themed monochrome icon</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={iosIcon}
              onChange={(e) => setIosIcon(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>iOS AppIcon (no alpha channels)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={splashApi}
              onChange={(e) => setSplashApi(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Android 12+ Splash Screen API</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={storeGraphics}
              onChange={(e) => setStoreGraphics(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Play Store Icon 512 & Feature 1024×500</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={webFavicon}
              onChange={(e) => setWebFavicon(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Web favicon & PWA manifest icons</span>
          </label>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleGenerate}>
            Generate Branding Assets
          </Button>
        </div>
      </div>
    </Modal>
  );
}
