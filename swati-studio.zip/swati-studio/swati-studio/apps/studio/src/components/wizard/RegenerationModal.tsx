'use client';

import { useState } from 'react';
import {
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  ShieldAlert,
  GitBranch,
  RotateCcw,
  Eye,
  Check,
  X,
  FilePlus,
  SkipForward,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface RegenerationFileItem {
  path: string;
  type: 'generated' | 'scaffold' | 'hybrid';
  action: 'overwritten' | 'merged' | 'conflict' | 'skipped' | 'new';
  description: string;
  diff?: string;
}

const SAMPLE_REGEN_FILES: RegenerationFileItem[] = [
  {
    path: 'lib/config/app_theme.dart',
    type: 'generated',
    action: 'overwritten',
    description: 'Updated with latest theme tokens (wizard owned)',
  },
  {
    path: 'lib/core/network/api_endpoints.dart',
    type: 'generated',
    action: 'overwritten',
    description: 'Endpoints refreshed with latest feature flags',
  },
  {
    path: 'lib/main.dart',
    type: 'hybrid',
    action: 'merged',
    description: 'Merged safely — preserved custom <swati:custom-init> code',
    diff: `@@ -15,4 +15,6 @@
 void main() async {
+  // <swati:custom-init>
+  await MyCustomService.init(); // ← user code preserved
+  // </swati:custom-init>
   runApp(const MyApp());
 }`,
  },
  {
    path: 'lib/features/home/home_screen.dart',
    type: 'scaffold',
    action: 'skipped',
    description: 'Skipped — user-owned scaffold never overwritten',
  },
  {
    path: 'lib/features/auth/login_screen.dart',
    type: 'scaffold',
    action: 'skipped',
    description: 'Skipped — user-owned scaffold never overwritten',
  },
  {
    path: 'lib/core/notifications/notification_service.dart',
    type: 'generated',
    action: 'new',
    description: 'New file added from Push Notifications feature',
  },
];

interface RegenerationModalProps {
  open: boolean;
  onClose: () => void;
}

export function RegenerationModal({ open, onClose }: RegenerationModalProps) {
  const [dryRun, setDryRun] = useState(true);
  const [gitBackup, setGitBackup] = useState(true);
  const [allowUndo, setAllowUndo] = useState(true);
  const [selectedDiff, setSelectedDiff] = useState<RegenerationFileItem | null>(null);
  const [applying, setApplying] = useState(false);

  const handleApply = async () => {
    setApplying(true);
    await new Promise((r) => setTimeout(r, 900));
    setApplying(false);
    toast.success('Project regenerated safely! User-owned code preserved.');
    onClose();
  };

  const handleUndo = () => {
    toast.success('Previous generation state restored from .swati/history backup.');
  };

  return (
    <>
      <Modal
        open={open}
        onClose={onClose}
        title="🔁 Regeneration-Safe Codegen (#26)"
        description="Re-generate features or settings without overwriting your custom code via 3-way merge and ownership rules."
        size="2xl"
      >
        <div className="space-y-5">
          {/* Top Banner & Dry Run Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-indigo-200 bg-indigo-50/70 p-4 dark:border-indigo-900/50 dark:bg-indigo-950/30">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-xs">
                <RefreshCw className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-gray-900 dark:text-white">
                  Safe Merge Engine Active
                </h4>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Protected tags <code>{'// <swati:tag>'}</code> guarantee your edits remain intact.
                </p>
              </div>
            </div>
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
              <input
                type="checkbox"
                checked={dryRun}
                onChange={(e) => setDryRun(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span>🧪 Dry Run Preview</span>
            </label>
          </div>

          {/* Ownership Legend */}
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-2 dark:border-slate-800 dark:bg-slate-900">
              <span className="font-semibold text-gray-900 dark:text-white">🔒 Generated</span>
              <p className="text-[10px] text-gray-500">Wizard owned — safe overwrite</p>
            </div>
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-2 dark:border-emerald-950/40 dark:bg-emerald-950/20">
              <span className="font-semibold text-emerald-800 dark:text-emerald-300">🌱 Scaffold</span>
              <p className="text-[10px] text-gray-500">User owned — never touched</p>
            </div>
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-2 dark:border-amber-950/40 dark:bg-amber-950/20">
              <span className="font-semibold text-amber-800 dark:text-amber-300">🔀 Hybrid</span>
              <p className="text-[10px] text-gray-500">Protected region merge</p>
            </div>
          </div>

          {/* Files List Preview */}
          <div className="max-h-72 overflow-y-auto rounded-xl border border-gray-200 dark:border-slate-800 divide-y divide-gray-100 dark:divide-slate-800">
            {SAMPLE_REGEN_FILES.map((file) => (
              <div
                key={file.path}
                className="flex items-center justify-between p-3 text-xs hover:bg-gray-50 dark:hover:bg-slate-850"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  {file.action === 'overwritten' && <CheckCircle2 className="h-4 w-4 text-indigo-600 shrink-0" />}
                  {file.action === 'merged' && <RefreshCw className="h-4 w-4 text-amber-600 shrink-0" />}
                  {file.action === 'skipped' && <SkipForward className="h-4 w-4 text-emerald-600 shrink-0" />}
                  {file.action === 'new' && <FilePlus className="h-4 w-4 text-blue-600 shrink-0" />}
                  {file.action === 'conflict' && <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />}
                  <div className="truncate">
                    <p className="font-mono font-medium text-gray-900 dark:text-white truncate">
                      {file.path}
                    </p>
                    <p className="text-[11px] text-gray-500 dark:text-gray-400">{file.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 ml-3">
                  <span
                    className={`rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase ${
                      file.action === 'overwritten'
                        ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                        : file.action === 'merged'
                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                        : file.action === 'skipped'
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                    }`}
                  >
                    {file.action}
                  </span>
                  {file.diff && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedDiff(file)}
                      className="h-7 px-2 text-xs"
                    >
                      <Eye className="h-3.5 w-3.5 mr-1" />
                      Diff
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Safety Checkboxes */}
          <div className="space-y-2 rounded-xl border border-gray-200 bg-gray-50/50 p-3.5 text-xs dark:border-slate-800 dark:bg-slate-900/50">
            <label className="flex items-center gap-2 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={gitBackup}
                onChange={(e) => setGitBackup(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <GitBranch className="h-3.5 w-3.5 text-gray-500" />
              <span>Auto-commit backup snapshot before applying (git stash / commit)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={allowUndo}
                onChange={(e) => setAllowUndo(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <RotateCcw className="h-3.5 w-3.5 text-gray-500" />
              <span>Allow 1-click undo to previous generation state (.swati/history)</span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2">
            <Button variant="outline" size="sm" onClick={handleUndo}>
              <RotateCcw className="h-4 w-4 mr-1.5" />
              Undo Last Regeneration
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="secondary" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={() => void handleApply()} disabled={applying}>
                {applying ? 'Applying Merge...' : dryRun ? 'Apply Changes (Live)' : 'Apply Changes'}
              </Button>
            </div>
          </div>
        </div>
      </Modal>

      {/* Diff Inspector Modal */}
      {selectedDiff && (
        <Modal
          open={!!selectedDiff}
          onClose={() => setSelectedDiff(null)}
          title={`Diff: ${selectedDiff.path}`}
          description="Protected regions merged seamlessly into updated template"
          size="lg"
        >
          <div className="space-y-3 font-mono text-xs">
            <div className="rounded-lg bg-slate-950 p-4 text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed">
              {selectedDiff.diff}
            </div>
            <div className="flex justify-end">
              <Button size="sm" onClick={() => setSelectedDiff(null)}>
                Close
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}
