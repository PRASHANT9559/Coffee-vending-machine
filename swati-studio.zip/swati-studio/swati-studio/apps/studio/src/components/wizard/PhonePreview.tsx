'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  findOption,
  steps,
  type NavigationItem,
  type StudioConfig,
  type UploadedDatabaseFile,
} from '@swati/schema';
import {
  Check,
  ChevronRight,
  Compass,
  Database,
  Eye,
  FileText,
  HardDrive,
  Heart,
  Home,
  Menu,
  MessageCircle,
  Moon,
  Plus,
  Search,
  Settings,
  ShoppingCart,
  Smartphone,
  Sparkles,
  Sun,
  User,
  Wifi,
  Zap,
} from 'lucide-react';
import { useStudioStore } from '@/lib/store';

export interface PhonePreviewProps {
  config: StudioConfig;
  dark: boolean;
  stepIndex?: number;
}

export function PhonePreview({ config, dark, stepIndex = 0 }: PhonePreviewProps) {
  const [useFlutterEngine, setUseFlutterEngine] = useState(false);
  const [activeScreenIndex, setActiveScreenIndex] = useState(0);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [previewModeOverride, setPreviewModeOverride] = useState<'light' | 'dark' | 'amoled' | 'sepia' | null>(null);
  const activeComponents = useStudioStore((s) => s.activeComponents);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const activeStep = steps[stepIndex] ?? steps[0];
  const stepId = activeStep?.id;

  const view = useMemo(() => {
    const configuredMode = String(config['frontend.themeMode'] ?? (dark ? 'dark' : 'light'));
    const activeMode = previewModeOverride ?? (configuredMode === 'adaptive' ? (dark ? 'dark' : 'light') : configuredMode);
    const isDark = activeMode === 'dark' || activeMode === 'amoled';

    const colorOption = findOption('themeColors', String(config['frontend.themeColor'] ?? 'indigo'));
    const palette = (isDark ? colorOption?.data?.dark : colorOption?.data?.light) as
      | { background: string; card: string; text: string; border: string; blue: string; red: string }
      | undefined;

    const hex =
      String(config['frontend.themeColor']) === 'custom'
        ? String(config['frontend.customColor'] ?? '#6366f1')
        : ((palette?.blue as string) ?? (colorOption?.data?.hex as string) ?? '#6366f1');

    const uiStyle = String(config['frontend.uiStyle'] ?? 'glassmorphism');

    // Base colors according to theme layer
    let bg = palette?.background ?? (isDark ? '#0f172a' : '#ffffff');
    let text = palette?.text ?? (isDark ? '#f1f5f9' : '#1e293b');
    let card = palette?.card ?? (isDark ? '#1e293b' : '#f8fafc');
    let line = palette?.border ?? (isDark ? '#334155' : '#e2e8f0');

    if (activeMode === 'amoled') {
      bg = '#000000';
      card = '#0c0c0c';
      text = '#ffffff';
      line = '#1f1f1f';
    } else if (activeMode === 'sepia') {
      bg = '#fbf0d9';
      card = '#f4e5c3';
      text = '#45321f';
      line = '#e4d0a6';
    }

    let radius = Number(config['frontend.borderRadius'] ?? 12);
    let cardShadow = '0 4px 12px rgba(0, 0, 0, 0.05)';
    let cardBorder = `1px solid ${line}`;
    let btnBorder = 'none';
    let btnShadow = 'none';
    let backdropBlur = 'none';

    // Apply exact CSS styling recipes from themes.txt
    if (uiStyle === 'neo_brutalism') {
      radius = 6;
      cardBorder = '3px solid #000000';
      cardShadow = '5px 5px 0px #000000';
      btnBorder = '3px solid #000000';
      btnShadow = '4px 4px 0px #000000';
      if (activeMode === 'light') {
        bg = '#fef08a';
      }
    } else if (uiStyle === 'glassmorphism') {
      card = isDark ? 'rgba(255, 255, 255, 0.07)' : 'rgba(255, 255, 255, 0.55)';
      backdropBlur = 'blur(14px)';
      cardBorder = isDark ? '1px solid rgba(255, 255, 255, 0.15)' : '1px solid rgba(255, 255, 255, 0.5)';
      cardShadow = '0 8px 32px 0 rgba(0, 0, 0, 0.25)';
      radius = Math.max(radius, 16);
    } else if (uiStyle === 'neumorphism') {
      radius = Math.max(radius, 20);
      cardBorder = 'none';
      cardShadow = isDark
        ? '6px 6px 14px #090c14, -6px -6px 14px #172033'
        : '8px 8px 16px #cbd5e1, -8px -8px 16px #ffffff';
      btnShadow = cardShadow;
    } else if (uiStyle === 'claymorphism') {
      radius = 28;
      cardShadow = '14px 14px 30px rgba(0,0,0,0.1), inset -6px -6px 12px rgba(196,107,139,0.2)';
      cardBorder = '2px solid rgba(255, 255, 255, 0.6)';
    } else if (uiStyle === 'cyberpunk') {
      cardBorder = '1.5px solid #d946ef';
      cardShadow = '0 0 15px rgba(217, 70, 239, 0.35)';
      text = '#00f6ff';
      bg = '#050508';
      card = 'rgba(15, 10, 30, 0.85)';
    } else if (uiStyle === 'terminal_cli') {
      bg = '#080c08';
      card = 'rgba(10, 24, 10, 0.85)';
      text = '#22c55e';
      cardBorder = '1px solid rgba(34, 197, 94, 0.4)';
      cardShadow = '0 0 12px rgba(34, 197, 94, 0.25)';
      radius = 4;
    } else if (uiStyle === 'liquid_glass') {
      card = isDark ? 'rgba(255, 255, 255, 0.12)' : 'rgba(255, 255, 255, 0.65)';
      backdropBlur = 'blur(20px)';
      cardBorder = isDark ? '1px solid rgba(255, 255, 255, 0.25)' : '1px solid rgba(255, 255, 255, 0.8)';
      cardShadow = '0 12px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.4)';
      radius = Math.max(radius, 18);
    } else if (uiStyle === 'y2k_chrome') {
      card = 'linear-gradient(135deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.05) 100%)';
      cardBorder = '1.5px solid rgba(56, 189, 248, 0.4)';
      cardShadow = '0 8px 24px rgba(56, 189, 248, 0.25)';
      radius = 20;
    } else if (uiStyle === 'retro_synthwave') {
      bg = '#110726';
      card = 'rgba(38, 12, 77, 0.75)';
      cardBorder = '1.5px solid #ec4899';
      cardShadow = '0 0 20px rgba(236, 72, 153, 0.35)';
      text = '#fde047';
    } else if (uiStyle === 'sepia_paper') {
      bg = '#fbf0d9';
      card = '#f4e5c3';
      text = '#45321f';
      cardBorder = '1px solid #e4d0a6';
      cardShadow = '2px 4px 12px rgba(70, 50, 20, 0.08)';
    } else if (uiStyle === 'flat_design') {
      cardBorder = 'none';
      cardShadow = 'none';
    }

    const name = String(config['project.name'] ?? 'My App');
    const font = String(config['frontend.font'] ?? 'Inter');

    const navStyle = String(config['navigation.style'] ?? 'minimal_clean');
    const navItems = Array.isArray(config['navigation.items'])
      ? (config['navigation.items'] as NavigationItem[])
      : [
          { id: '1', name: 'Home', icon: 'Home', route: '/home', title: 'Home' },
          { id: '2', name: 'Explore', icon: 'Compass', route: '/explore', title: 'Explore' },
          { id: '3', name: 'Search', icon: 'Search', route: '/search', title: 'Search' },
          { id: '4', name: 'Saved', icon: 'Heart', route: '/saved', title: 'Saved' },
          { id: '5', name: 'Profile', icon: 'User', route: '/profile', title: 'Profile' },
        ];

    const dbEngine = String(config['database.engine'] ?? 'sqlite');
    const dbFile = config['database.file'] as UploadedDatabaseFile | undefined;

    return {
      hex,
      bg,
      text,
      card,
      line,
      radius,
      name,
      font,
      navStyle,
      navItems,
      dbEngine,
      dbFile,
      uiStyle,
      activeMode,
      cardShadow,
      cardBorder,
      btnBorder,
      btnShadow,
      backdropBlur,
    };
  }, [config, dark, previewModeOverride]);

  const currentNav = view.navItems[activeScreenIndex] ?? view.navItems[0] ?? {
    name: 'Home',
    title: 'Home',
    icon: 'Home',
    route: '/home',
  };

  useEffect(() => {
    if (activeScreenIndex >= view.navItems.length) {
      setActiveScreenIndex(0);
    }
  }, [view.navItems.length, activeScreenIndex]);

  useEffect(() => {
    if (useFlutterEngine && iframeRef.current?.contentWindow) {
      iframeRef.current.contentWindow.postMessage(
        {
          type: 'SWATI_STUDIO_SYNC_COMPONENTS',
          components: activeComponents,
          theme: view.activeMode,
        },
        '*',
      );
    }
  }, [useFlutterEngine, activeComponents, view.activeMode]);

  const renderNavIcon = (iconName: string, className = 'h-4 w-4') => {
    switch (iconName) {
      case 'Home':
        return <Home className={className} />;
      case 'Search':
        return <Search className={className} />;
      case 'Heart':
      case 'Saved':
        return <Heart className={className} />;
      case 'ShoppingCart':
        return <ShoppingCart className={className} />;
      case 'Bell':
        return <Bell className={className} />;
      case 'User':
        return <User className={className} />;
      case 'Settings':
        return <Settings className={className} />;
      case 'MessageCircle':
        return <MessageCircle className={className} />;
      case 'Compass':
      case 'Explore':
        return <Compass className={className} />;
      default:
        return <Sparkles className={className} />;
    }
  };

  /* Helper to render the corresponding Navigation Bar style from the 11 UI kit designs */
  const renderBottomBar = () => {
    const items = view.navItems;

    switch (view.navStyle) {
      /* 01. Minimal Clean */
      case 'minimal_clean':
        return (
          <div
            className="flex items-center justify-around border-t py-2 transition"
            style={{ borderColor: view.line, background: view.bg }}
          >
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="flex flex-1 flex-col items-center gap-1 py-0.5 transition"
                  style={{ color: isActive ? view.hex : undefined, opacity: isActive ? 1 : 0.6 }}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[10px] font-medium">{item.name}</span>
                  <div
                    className="h-1 w-1 rounded-full transition-all"
                    style={{ background: isActive ? view.hex : 'transparent' }}
                  />
                </button>
              );
            })}
          </div>
        );

      /* 02. Glassmorphism */
      case 'glassmorphism':
        return (
          <div className="p-2 backdrop-blur-md bg-white/20 border-t border-white/30 dark:bg-black/30 dark:border-white/10 shadow-lg">
            <div className="flex items-center justify-around">
              {items.map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className={`flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1 transition ${
                      isActive ? 'bg-white/30 dark:bg-white/10 shadow-xs' : 'opacity-70'
                    }`}
                    style={{ color: isActive ? view.hex : undefined }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[10px] font-medium">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 03. Floating (Detached) */
      case 'floating_detached':
        return (
          <div className="p-3">
            <div
              className="flex items-center justify-around rounded-full px-2 py-2 shadow-xl border transition"
              style={{ background: view.card, borderColor: view.line }}
            >
              {items.map((item, idx) => {
                const isCenter = idx === Math.floor(items.length / 2);
                const isActive = idx === activeScreenIndex;
                if (isCenter) {
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveScreenIndex(idx)}
                      className="flex h-9 w-9 items-center justify-center rounded-full text-white shadow-md transition hover:scale-105"
                      style={{ background: view.hex }}
                      title={item.name}
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  );
                }
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-1 flex-col items-center gap-0.5 py-0.5"
                    style={{ color: isActive ? view.hex : undefined, opacity: isActive ? 1 : 0.6 }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-medium">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 04. Neumorphism */
      case 'neumorphism':
        return (
          <div
            className="flex items-center justify-around py-2.5 transition"
            style={{
              background: view.bg,
              boxShadow:
                view.activeMode === 'dark' || view.activeMode === 'amoled'
                  ? 'inset 0 1px 0 rgba(255,255,255,0.05), 0 -4px 12px rgba(0,0,0,0.4)'
                  : 'inset 0 1px 0 rgba(255,255,255,0.9), 0 -4px 12px rgba(0,0,0,0.06)',
            }}
          >
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 rounded-xl py-1 transition ${
                    isActive ? 'shadow-inner bg-black/5 dark:bg-white/5 font-bold' : 'opacity-65'
                  }`}
                  style={{ color: isActive ? view.hex : undefined }}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[10px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 05. Pill Highlight */
      case 'pill_highlight':
        return (
          <div
            className="flex items-center justify-around border-t py-2 transition"
            style={{ borderColor: view.line, background: view.card }}
          >
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="flex flex-1 flex-col items-center gap-1 transition"
                  style={{ color: isActive ? view.hex : undefined }}
                >
                  <div
                    className="flex items-center justify-center rounded-full px-3 py-1 transition"
                    style={{
                      background: isActive ? `${view.hex}22` : 'transparent',
                      color: isActive ? view.hex : undefined,
                    }}
                  >
                    {renderNavIcon(item.icon)}
                  </div>
                  <span className="text-[10px] font-medium" style={{ opacity: isActive ? 1 : 0.65 }}>
                    {item.name}
                  </span>
                </button>
              );
            })}
          </div>
        );

      /* 06. Center FAB */
      case 'center_fab':
        return (
          <div className="relative border-t" style={{ borderColor: view.line, background: view.card }}>
            <div className="flex items-center justify-around py-1.5">
              {items.map((item, idx) => {
                const isCenter = idx === Math.floor(items.length / 2);
                const isActive = idx === activeScreenIndex;
                if (isCenter) {
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveScreenIndex(idx)}
                      className="-mt-7 flex h-12 w-12 items-center justify-center rounded-full text-white shadow-xl border-4 transition hover:scale-105"
                      style={{ background: view.hex, borderColor: view.bg }}
                      title={item.name}
                    >
                      <Plus className="h-6 w-6" />
                    </button>
                  );
                }
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-1 flex-col items-center gap-0.5 py-1"
                    style={{ color: isActive ? view.hex : undefined, opacity: isActive ? 1 : 0.6 }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[10px] font-medium">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 07. Gradient Bold */
      case 'gradient_bold':
        return (
          <div className="bg-gradient-to-r from-purple-600 via-fuchsia-500 to-pink-500 p-2 text-white shadow-lg">
            <div className="flex items-center justify-around">
              {items.map((item, idx) => {
                const isCenter = idx === Math.floor(items.length / 2);
                const isActive = idx === activeScreenIndex;
                if (isCenter) {
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveScreenIndex(idx)}
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-purple-600 shadow-md transition"
                      title={item.name}
                    >
                      <Plus className="h-5 w-5" />
                    </button>
                  );
                }
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-1 flex-col items-center gap-0.5 py-0.5"
                    style={{ opacity: isActive ? 1 : 0.7 }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-semibold">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 08. Outline Icons */
      case 'outline_icons':
        return (
          <div
            className="flex items-center justify-around border-t py-2 transition"
            style={{ borderColor: view.line, background: view.card }}
          >
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="flex flex-1 flex-col items-center gap-1 py-0.5 transition"
                  style={{ color: isActive ? view.hex : undefined, opacity: isActive ? 1 : 0.6 }}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[10px] font-medium">{item.name}</span>
                  <div
                    className="h-0.5 w-4 rounded-full transition-all"
                    style={{ background: isActive ? view.hex : 'transparent' }}
                  />
                </button>
              );
            })}
          </div>
        );

      /* 09. Tab with Indicator */
      case 'tab_indicator':
        return (
          <div
            className="flex items-center justify-around border-t py-1.5 transition"
            style={{ borderColor: view.line, background: view.card }}
          >
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="relative flex flex-1 flex-col items-center gap-0.5 pt-1.5 pb-1 transition"
                  style={{ color: isActive ? view.hex : undefined, opacity: isActive ? 1 : 0.6 }}
                >
                  {isActive && (
                    <div
                      className="absolute top-0 h-0.5 w-6 rounded-full"
                      style={{ background: view.hex }}
                    />
                  )}
                  {renderNavIcon(item.icon)}
                  <span className="text-[10px] font-medium">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 10. Curved Background */
      case 'curved_bg':
        return (
          <div
            className="rounded-t-3xl pt-2 pb-1.5 shadow-xl transition"
            style={{
              background: `linear-gradient(to bottom, ${view.hex}30, ${view.hex}15)`,
              borderTop: `1.5px solid ${view.hex}40`,
            }}
          >
            <div className="flex items-center justify-around">
              {items.map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-1 flex-col items-center gap-0.5 py-1"
                    style={{ color: isActive ? view.hex : undefined, opacity: isActive ? 1 : 0.65 }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-medium">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 11. Dock Style (iOS Inspired) */
      case 'dock_ios':
        return (
          <div className="px-4 pb-3">
            <div
              className="flex items-center justify-around rounded-2xl py-1.5 shadow-lg border backdrop-blur-md transition"
              style={{
                background: view.activeMode === 'dark' || view.activeMode === 'amoled'
                  ? 'rgba(30, 41, 59, 0.85)'
                  : 'rgba(255, 255, 255, 0.85)',
                borderColor: view.line,
              }}
            >
              {items.map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className={`flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1 transition ${
                      isActive ? 'scale-105' : 'opacity-65'
                    }`}
                    style={{ color: isActive ? view.hex : undefined }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-semibold">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 12. Claymorphism */
      case 'claymorphism':
        return (
          <div className="p-3">
            <div className="flex items-center justify-around rounded-2xl p-1.5 shadow-md bg-[#f3f0ff] dark:bg-slate-900 border border-purple-200 dark:border-purple-900/40">
              {items.map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className={`flex flex-1 flex-col items-center gap-0.5 py-1 rounded-xl transition ${
                      isActive ? 'bg-indigo-600 text-white shadow-lg scale-105' : 'text-gray-500'
                    }`}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-semibold">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 13. Neon Glow (Cyberpunk) */
      case 'neon_glow':
        return (
          <div className="flex items-center justify-around border-t border-cyan-900/60 bg-black py-2 text-gray-500">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 transition ${
                    isActive ? 'text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)] font-bold' : 'opacity-60'
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 14. Material You Pill */
      case 'material_you_pill':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-[#efe6ff] dark:bg-slate-950 border-purple-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="flex flex-1 flex-col items-center gap-1 transition"
                >
                  <div className={`px-4 py-1 rounded-full transition ${isActive ? 'bg-[#6750a4] text-white shadow-xs' : 'text-gray-500'}`}>
                    {renderNavIcon(item.icon)}
                  </div>
                  <span className="text-[9px] font-medium text-gray-700 dark:text-gray-300">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 15. Neo-Brutalism */
      case 'neo_brutalism':
        return (
          <div className="flex items-center justify-around border-t-4 border-black bg-[#ffd93d] py-2 text-black">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-col items-center gap-0.5 px-3 py-1 font-black transition ${
                    isActive ? 'bg-[#ff5c5c] text-white border-2 border-black shadow-[3px_3px_0_#000] -translate-y-1' : ''
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px] font-bold uppercase">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 16. Retro Pixel (8-Bit) */
      case 'retro_pixel':
        return (
          <div className="flex items-center justify-around border-t-2 border-slate-700 bg-[#1a1c2c] py-2 font-mono text-[#7d80a3]">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 text-[9px] uppercase tracking-wider transition ${
                    isActive ? 'text-[#79f79f] font-bold border-t-2 border-[#79f79f]' : ''
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span>{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 17. Skeuomorphic Metal */
      case 'skeuomorphic_metal':
        return (
          <div className="flex items-center justify-around bg-gradient-to-b from-[#3a3f46] to-[#23272c] border-t border-[#565c66] py-2 text-slate-300 shadow-inner">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 rounded-lg py-1 transition ${
                    isActive ? 'bg-gradient-to-b from-[#1b1e22] to-[#2b3036] text-white shadow-inner font-bold border-t border-white/10' : 'opacity-70'
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 18. Hand-drawn Sketch */
      case 'hand_drawn_sketch':
        return (
          <div className="flex items-center justify-around border-t-2 border-dashed border-gray-600 bg-[#fffdf5] dark:bg-slate-900 py-2 text-gray-800 dark:text-gray-200">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-col items-center gap-0.5 px-3 py-1 transition rounded-xl ${
                    isActive ? 'bg-[#ffe66d] text-black border-2 border-black font-bold -rotate-1 shadow-xs' : ''
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px] font-medium">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 19. Aurora Mesh */
      case 'aurora_mesh':
        return (
          <div className="bg-gradient-to-r from-cyan-400 via-emerald-400 to-fuchsia-500 p-2 text-white shadow-lg animate-pulse">
            <div className="flex items-center justify-around">
              {items.map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className={`flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1 transition ${
                      isActive ? 'bg-white/30 backdrop-blur font-bold' : 'opacity-80'
                    }`}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px]">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 20. Pastel Soft */
      case 'pastel_soft': {
        const pastelColors = ['#ef7fae', '#5a9fd4', '#6cb06c', '#d09a4e', '#9a6fd0'];
        const pastelBgs = ['#fde7ef', '#e3f1fb', '#e6f6e6', '#fbf0e0', '#f1e8fb'];
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-100 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              const color = pastelColors[idx % pastelColors.length];
              const bg = pastelBgs[idx % pastelBgs.length];
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 rounded-xl py-1 transition ${
                    isActive ? 'font-bold' : 'text-gray-400'
                  }`}
                  style={{
                    color: isActive ? color : undefined,
                    background: isActive ? bg : 'transparent',
                  }}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );
      }

      /* 21. Cradle Cutout */
      case 'cradle_cutout':
        return (
          <div className="relative border-t bg-white dark:bg-slate-900 pt-2 pb-1 border-gray-200 dark:border-slate-800">
            <div className="flex items-center justify-around">
              {items.map((item, idx) => {
                const isCenter = idx === Math.floor(items.length / 2);
                const isActive = idx === activeScreenIndex;
                if (isCenter) {
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveScreenIndex(idx)}
                      className="-mt-7 flex h-12 w-12 items-center justify-center rounded-full text-white shadow-xl bg-indigo-600 border-4 border-[#eef0f4] dark:border-slate-950 transition hover:scale-105"
                      title={item.name}
                    >
                      <Plus className="h-6 w-6" />
                    </button>
                  );
                }
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-1 flex-col items-center gap-0.5 py-1 text-gray-500"
                    style={{ color: isActive ? view.hex : undefined }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-medium">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 22. Split Dock */
      case 'split_dock': {
        const leftItems = items.slice(0, 2);
        const rightItems = items.slice(2, 4);
        return (
          <div className="p-2.5 flex items-center justify-between gap-3">
            <div className="flex flex-1 items-center justify-around rounded-full bg-white dark:bg-slate-900 py-1.5 shadow-md border border-gray-200 dark:border-slate-800">
              {leftItems.map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-col items-center"
                    style={{ color: isActive ? view.hex : '#94a3b8' }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[8px]">{item.name}</span>
                  </button>
                );
              })}
            </div>
            <div className="h-2 w-2 rounded-full bg-indigo-500 animate-ping" />
            <div className="flex flex-1 items-center justify-around rounded-full bg-white dark:bg-slate-900 py-1.5 shadow-md border border-gray-200 dark:border-slate-800">
              {rightItems.map((item, idx) => {
                const realIdx = idx + 2;
                const isActive = realIdx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(realIdx)}
                    className="flex flex-col items-center"
                    style={{ color: isActive ? view.hex : '#94a3b8' }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[8px]">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );
      }

      /* 23. Icons-only Compact */
      case 'icons_only_compact':
        return (
          <div className="flex items-center justify-around border-t py-3 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`p-2 rounded-xl transition ${isActive ? 'scale-125' : 'opacity-50'}`}
                  style={{ color: isActive ? view.hex : undefined }}
                  title={item.name}
                >
                  {renderNavIcon(item.icon)}
                </button>
              );
            })}
          </div>
        );

      /* 24. Text-only Tabs */
      case 'text_only_tabs':
        return (
          <div className="flex items-center justify-around border-t py-3 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="flex flex-col items-center gap-1 font-semibold text-xs transition"
                  style={{ color: isActive ? view.hex : '#94a3b8' }}
                >
                  <span>{item.name}</span>
                  {isActive && <div className="h-0.5 w-6 rounded-full" style={{ background: view.hex }} />}
                </button>
              );
            })}
          </div>
        );

      /* 25. Double-deck */
      case 'double_deck':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="flex flex-col items-center transition"
                  style={{ color: isActive ? view.hex : '#94a3b8' }}
                >
                  {renderNavIcon(item.icon)}
                  {isActive && <span className="text-[9px] font-bold animate-fade-in">{item.name}</span>}
                </button>
              );
            })}
          </div>
        );

      /* 26. Nav + Search Combo */
      case 'nav_search_combo':
        return (
          <div className="flex items-center justify-between gap-2 border-t p-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            <div className="flex flex-1 items-center gap-1.5 rounded-full bg-gray-100 dark:bg-slate-800 px-3 py-1.5 text-xs text-gray-500">
              <Search className="h-3.5 w-3.5" />
              <input placeholder="Search app…" className="w-full bg-transparent text-[10px] outline-none" />
            </div>
            <div className="flex items-center gap-2">
              {items.slice(0, 3).map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="p-1.5 rounded-full"
                    style={{ color: isActive ? view.hex : '#94a3b8' }}
                  >
                    {renderNavIcon(item.icon)}
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 27. Scroll-aware Hide */
      case 'scroll_aware_hide':
        return (
          <div className="p-2">
            <div className="flex items-center justify-around rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur py-2 shadow-lg border border-gray-200 dark:border-slate-800">
              {items.map((item, idx) => {
                const isActive = idx === activeScreenIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-1 flex-col items-center gap-0.5"
                    style={{ color: isActive ? view.hex : '#94a3b8' }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-medium">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 28. Transparent Overlay */
      case 'transparent_overlay':
        return (
          <div className="flex items-center justify-around py-3 bg-gradient-to-t from-black/80 to-transparent text-white drop-shadow-md">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-0.5 transition ${isActive ? 'font-bold scale-110' : 'opacity-70'}`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 29. Sliding Pill */
      case 'sliding_pill':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-full transition-all ${
                    isActive ? 'bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-bold scale-105' : 'text-gray-500'
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 30. Morphing Blob */
      case 'morphing_blob':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-2xl transition-all ${
                    isActive ? 'bg-gradient-to-tr from-purple-600 to-pink-500 text-white font-bold scale-105 shadow-md' : 'text-gray-500'
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 31. Springboard FAB */
      case 'springboard_fab':
        return (
          <div className="relative border-t bg-white dark:bg-slate-900 pt-2 pb-1 border-gray-200 dark:border-slate-800">
            <div className="flex items-center justify-around">
              {items.map((item, idx) => {
                const isCenter = idx === Math.floor(items.length / 2);
                const isActive = idx === activeScreenIndex;
                if (isCenter) {
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveScreenIndex(idx)}
                      className="-mt-7 flex h-12 w-12 items-center justify-center rounded-full text-white shadow-xl bg-gradient-to-r from-purple-600 to-indigo-600 border-4 border-white dark:border-slate-900 transition hover:scale-105"
                      title={item.name}
                    >
                      <Plus className="h-6 w-6" />
                    </button>
                  );
                }
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-1 flex-col items-center gap-0.5 py-1 text-gray-500"
                    style={{ color: isActive ? view.hex : undefined }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px] font-medium">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );

      /* 32. Badge Counter */
      case 'badge_counter':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              const hasBadge = idx === 1 || idx === 3;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="relative flex flex-1 flex-col items-center gap-1 py-0.5 text-gray-500"
                  style={{ color: isActive ? view.hex : undefined }}
                >
                  <div className="relative">
                    {renderNavIcon(item.icon)}
                    {hasBadge && (
                      <span className="absolute -top-1 -right-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[8px] font-bold text-white">
                        {idx === 1 ? '3' : '9+'}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] font-medium">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 33. Lottie-like Pop */
      case 'lottie_pop':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 transition-all ${
                    isActive ? 'scale-110 -rotate-3 text-amber-500 font-bold' : 'text-gray-400'
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 34. Magnetic Icons */
      case 'magnetic_icons':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 transition hover:scale-125 ${
                    isActive ? 'text-blue-500 font-bold' : 'text-gray-400'
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      /* 35. Tooltip on Hold */
      case 'tooltip_hold':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <div key={item.id} className="relative flex flex-1 flex-col items-center">
                  {isActive && (
                    <div className="absolute -top-7 rounded bg-slate-900 text-white px-2 py-0.5 text-[8px] whitespace-nowrap shadow-md">
                      {item.name}
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => setActiveScreenIndex(idx)}
                    className="flex flex-col items-center gap-1"
                    style={{ color: isActive ? view.hex : '#94a3b8' }}
                  >
                    {renderNavIcon(item.icon)}
                    <span className="text-[9px]">{item.name}</span>
                  </button>
                </div>
              );
            })}
          </div>
        );

      /* 36. Haptic Bounce */
      case 'haptic_bounce':
        return (
          <div className="flex items-center justify-around border-t py-2 bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800 shadow-lg">
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className={`flex flex-1 flex-col items-center gap-1 transition-transform ${
                    isActive ? 'animate-bounce text-indigo-600 dark:text-indigo-400 font-bold' : 'text-gray-400'
                  }`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[9px]">{item.name}</span>
                </button>
              );
            })}
          </div>
        );

      case 'drawer':
      case 'rail':
      default:
        return (
          <div
            className="flex items-center justify-around border-t py-2 transition"
            style={{ borderColor: view.line, background: view.bg }}
          >
            {items.map((item, idx) => {
              const isActive = idx === activeScreenIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreenIndex(idx)}
                  className="flex flex-1 flex-col items-center gap-1 py-0.5 transition"
                  style={{ color: isActive ? view.hex : undefined, opacity: isActive ? 1 : 0.6 }}
                >
                  {renderNavIcon(item.icon)}
                  <span className="text-[10px] font-medium">{item.name}</span>
                  <div
                    className="h-1 w-1 rounded-full transition-all"
                    style={{ background: isActive ? view.hex : 'transparent' }}
                  />
                </button>
              );
            })}
          </div>
        );
    }
  };

  return (
    <div className="flex h-full flex-col">
      {/* Top Bar with Real-time Theme Layer Switcher (Light, Dark, AMOLED, Sepia) */}
      <div className="flex items-center justify-between border-b border-gray-200/40 bg-gray-100/90 px-3 py-1.5 text-[10px] backdrop-blur dark:border-slate-800/80 dark:bg-slate-950/80">
        <div className="flex items-center gap-1 font-mono text-[9px] text-gray-500 dark:text-gray-400">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="uppercase">{view.uiStyle.replace('_', ' ')}</span>
        </div>

        {/* 4 Theme Layers Quick Switcher */}
        <div className="flex items-center gap-1 bg-white/70 dark:bg-slate-900/70 rounded-md p-0.5 border border-gray-200 dark:border-slate-800">
          <button
            type="button"
            title="Light Theme"
            onClick={() => setPreviewModeOverride('light')}
            className={`px-1.5 py-0.5 rounded transition ${
              view.activeMode === 'light' ? 'bg-indigo-600 text-white font-bold' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            <Sun className="h-3 w-3" />
          </button>
          <button
            type="button"
            title="Dark Theme"
            onClick={() => setPreviewModeOverride('dark')}
            className={`px-1.5 py-0.5 rounded transition ${
              view.activeMode === 'dark' ? 'bg-indigo-600 text-white font-bold' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            <Moon className="h-3 w-3" />
          </button>
          <button
            type="button"
            title="AMOLED True Black (#000000)"
            onClick={() => setPreviewModeOverride('amoled')}
            className={`px-1.5 py-0.5 rounded transition text-[9px] font-mono ${
              view.activeMode === 'amoled' ? 'bg-black text-cyan-400 border border-cyan-500/50 font-bold' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            AMOLED
          </button>
          <button
            type="button"
            title="Warm Sepia (Reading Tone)"
            onClick={() => setPreviewModeOverride('sepia')}
            className={`px-1.5 py-0.5 rounded transition text-[9px] font-serif ${
              view.activeMode === 'sepia' ? 'bg-amber-800 text-amber-100 font-bold' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Sepia
          </button>
        </div>
      </div>

      {useFlutterEngine ? (
        <iframe
          ref={iframeRef}
          src="/flutter-preview.html"
          title="Flutter Web Live Engine"
          className="h-full w-full border-0 bg-slate-900"
          onLoad={() => {
            iframeRef.current?.contentWindow?.postMessage(
              {
                type: 'SWATI_STUDIO_SYNC_COMPONENTS',
                components: activeComponents,
                theme: view.activeMode,
              },
              '*',
            );
          }}
        />
      ) : (
        /* React Interactive Simulated Mockup */
        <div
          className="relative flex flex-1 flex-col overflow-hidden text-xs transition-colors duration-300"
          style={{
            background: view.bg,
            color: view.text,
            fontFamily: view.uiStyle === 'terminal_cli' ? 'monospace' : `${view.font}, system-ui, sans-serif`,
          }}
        >
          {/* Status Bar */}
          <div className="flex items-center justify-between px-4 pt-2 pb-1 text-[10px] opacity-70">
            <span>9:41</span>
            <div className="flex items-center gap-1.5">
              <Wifi className="h-3 w-3" />
              <div className="h-2 w-4 rounded-xs border border-current" />
            </div>
          </div>

          {/* Top AppBar */}
          <div
            className="flex items-center justify-between border-b px-4 py-2.5 transition shadow-2xs"
            style={{
              borderColor: view.line,
              background: view.uiStyle === 'neo_brutalism' ? view.bg : `${view.hex}10`,
              borderBottom: view.uiStyle === 'neo_brutalism' ? '3px solid #000' : undefined,
            }}
          >
            <div className="flex items-center gap-2">
              {view.navStyle === 'drawer' ? (
                <button
                  type="button"
                  onClick={() => setDrawerOpen(!drawerOpen)}
                  className="rounded p-1 hover:bg-black/10 dark:hover:bg-white/10"
                  aria-label="Open navigation drawer"
                >
                  <Menu className="h-4 w-4" />
                </button>
              ) : null}
              <h2 className="text-sm font-bold tracking-tight">
                {currentNav.title || currentNav.name}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <div
                className="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold text-white shadow-xs"
                style={{
                  background: view.hex,
                  border: view.btnBorder,
                  boxShadow: view.btnShadow,
                }}
              >
                {view.name.charAt(0).toUpperCase()}
              </div>
            </div>
          </div>

          {/* Slide-out Drawer Overlay */}
          {view.navStyle === 'drawer' && drawerOpen && (
            <div
              className="absolute inset-0 z-40 bg-black/50 backdrop-blur-xs transition"
              onClick={() => setDrawerOpen(false)}
            >
              <div
                className="h-full w-48 p-4 shadow-xl flex flex-col justify-between"
                style={{ background: view.bg }}
                onClick={(e) => e.stopPropagation()}
              >
                <div>
                  <div
                    className="mb-4 rounded-xl p-3 text-white"
                    style={{ background: view.hex, border: view.btnBorder }}
                  >
                    <div className="font-bold text-sm">{view.name}</div>
                    <div className="text-[10px] opacity-80">v1.0.0</div>
                  </div>

                  <div className="space-y-1">
                    {view.navItems.map((item, idx) => {
                      const isActive = idx === activeScreenIndex;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => {
                            setActiveScreenIndex(idx);
                            setDrawerOpen(false);
                          }}
                          className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left font-medium transition"
                          style={{
                            background: isActive ? `${view.hex}20` : 'transparent',
                            color: isActive ? view.hex : view.text,
                            border: isActive && view.uiStyle === 'neo_brutalism' ? '2px solid #000' : undefined,
                          }}
                        >
                          {renderNavIcon(item.icon)}
                          <span>{item.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="text-[10px] opacity-50">Swati Studio Generated</div>
              </div>
            </div>
          )}

          {/* Main Body Screen Content */}
          <div className="flex flex-1 overflow-hidden">
            {/* Scrollable Screen Content */}
            <div className="flex-1 space-y-3 overflow-y-auto p-4">
              {/* Step 4: Database View Preview */}
              {stepId === 'database' ? (
                <div className="space-y-3">
                  <div
                    className="rounded-xl p-3"
                    style={{
                      background: view.card,
                      border: view.cardBorder,
                      boxShadow: view.cardShadow,
                      borderRadius: view.radius,
                      backdropFilter: view.backdropBlur,
                    }}
                  >
                    <div className="flex items-center gap-2 mb-2 font-bold">
                      <Database className="h-4 w-4" style={{ color: view.hex }} />
                      <span>Database Engine</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="opacity-70">Selected Engine:</span>
                      <span className="font-mono font-bold uppercase">{view.dbEngine}</span>
                    </div>
                  </div>

                  {view.dbFile ? (
                    <div
                      className="p-3"
                      style={{
                        background: view.card,
                        border: view.cardBorder,
                        boxShadow: view.cardShadow,
                        borderRadius: view.radius,
                        backdropFilter: view.backdropBlur,
                      }}
                    >
                      <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold mb-1">
                        <Check className="h-4 w-4" />
                        <span>Database File Loaded</span>
                      </div>
                      <p className="text-[11px] font-mono opacity-80">
                        {view.dbFile.name} ({(view.dbFile.size / 1024).toFixed(1)} KB)
                      </p>
                      <p className="mt-1 text-[10px] opacity-60">
                        Bundled in project at <code>assets/db/{view.dbFile.name}</code>
                      </p>
                    </div>
                  ) : (
                    <div
                      className="rounded-xl border border-dashed p-3 text-center opacity-70"
                      style={{ borderColor: view.line }}
                    >
                      <HardDrive className="h-5 w-5 mx-auto mb-1 opacity-50" />
                      <p className="text-[11px]">No database file uploaded</p>
                      <p className="text-[10px] opacity-60">App will initialize a fresh local database.</p>
                    </div>
                  )}
                </div>
              ) : stepId === 'navigation' ? (
                /* Step 2: Navigation Screen Showcase */
                <div className="space-y-3">
                  <div
                    className="p-3 text-center"
                    style={{
                      background: view.card,
                      borderRadius: view.radius,
                      border: view.cardBorder,
                      boxShadow: view.cardShadow,
                      backdropFilter: view.backdropBlur,
                    }}
                  >
                    <div
                      className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-2xl text-white shadow-sm"
                      style={{
                        background: view.hex,
                        border: view.btnBorder,
                        boxShadow: view.btnShadow,
                      }}
                    >
                      {renderNavIcon(currentNav.icon)}
                    </div>
                    <h3 className="font-bold text-sm" style={{ color: view.hex }}>
                      {currentNav.title} Screen
                    </h3>
                    <p className="mt-0.5 text-[10px] font-mono opacity-70">
                      Route: {currentNav.route}
                    </p>
                  </div>

                  <div
                    className="p-3 space-y-2"
                    style={{
                      background: view.card,
                      border: view.cardBorder,
                      boxShadow: view.cardShadow,
                      borderRadius: view.radius,
                      backdropFilter: view.backdropBlur,
                    }}
                  >
                    <div className="text-[11px] font-semibold opacity-70">
                      Screen Details
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="opacity-60">Dart Class:</span>
                      <span className="font-mono font-medium">{currentNav.name}Screen</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="opacity-60">AppBar Title:</span>
                      <span className="font-medium">"{currentNav.title}"</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="opacity-60">Nav Style:</span>
                      <span className="font-medium capitalize">{view.navStyle.replace('_', ' ')}</span>
                    </div>
                  </div>

                  <div className="rounded-xl border p-2.5 text-center text-[10px] opacity-60">
                    👆 Click any item in the navigation bar below to preview its screen!
                  </div>
                </div>
              ) : (
                /* Step 1: Theme & General Interactive Showcase */
                <div className="space-y-3">
                  {/* Hero card styled according to the aesthetic recipe */}
                  <div
                    className="p-3.5 transition-all duration-300"
                    style={{
                      background: view.card,
                      borderRadius: view.radius,
                      border: view.cardBorder,
                      boxShadow: view.cardShadow,
                      backdropFilter: view.backdropBlur,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-bold text-sm" style={{ color: view.hex }}>
                        {currentNav.title}
                      </h3>
                      <span className="text-[9px] font-mono uppercase opacity-60">
                        {view.uiStyle.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-[11px] opacity-80 leading-relaxed">
                      Theme tokens live preview with active styling, font, border radius & shadows.
                    </p>
                  </div>

                  {/* Primary & Outlined Button Showcase */}
                  <div className="space-y-2">
                    <button
                      type="button"
                      className="flex h-9 w-full items-center justify-center font-bold text-white transition hover:opacity-95"
                      style={{
                        background: view.hex,
                        borderRadius: view.radius,
                        border: view.btnBorder,
                        boxShadow: view.btnShadow,
                      }}
                    >
                      Filled Button
                    </button>
                    <button
                      type="button"
                      className="flex h-9 w-full items-center justify-center font-bold transition"
                      style={{
                        borderRadius: view.radius,
                        border: view.uiStyle === 'neo_brutalism' ? '3px solid #000000' : `1.5px solid ${view.hex}`,
                        color: view.uiStyle === 'neo_brutalism' ? '#000000' : view.hex,
                        background: view.uiStyle === 'neo_brutalism' ? '#ffffff' : 'transparent',
                        boxShadow: view.btnShadow,
                      }}
                    >
                      Outlined Button
                    </button>
                  </div>

                  {/* Text Field Showcase */}
                  <div
                    className="flex h-9 items-center justify-between px-3 text-[11px] opacity-85 transition"
                    style={{
                      background: view.card,
                      borderRadius: view.radius,
                      border: view.cardBorder,
                      boxShadow: view.uiStyle === 'neo_brutalism' ? '3px 3px 0px #000' : undefined,
                    }}
                  >
                    <span>Sample Text Input...</span>
                  </div>

                  {/* Sample List Items */}
                  <div
                    className="divide-y overflow-hidden transition"
                    style={{
                      background: view.card,
                      borderRadius: view.radius,
                      border: view.cardBorder,
                      boxShadow: view.cardShadow,
                      backdropFilter: view.backdropBlur,
                    }}
                  >
                    <div className="flex items-center justify-between p-2.5">
                      <span className="font-semibold">Item Alpha</span>
                      <ChevronRight className="h-3 w-3 opacity-50" />
                    </div>
                    <div className="flex items-center justify-between p-2.5">
                      <span className="font-semibold">Item Beta</span>
                      <ChevronRight className="h-3 w-3 opacity-50" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Render the selected Navigation Bar Style */}
          {renderBottomBar()}
        </div>
      )}
    </div>
  );
}
