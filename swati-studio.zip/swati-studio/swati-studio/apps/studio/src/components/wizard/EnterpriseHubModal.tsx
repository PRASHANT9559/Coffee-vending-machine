'use client';

import {
  RefreshCw,
  FolderSearch,
  Database,
  Boxes,
  Bell,
  Sliders,
  Server,
  Scale,
  Palette,
  Image as ImageIcon,
  Zap,
  Eye,
  Gauge,
  BookOpen,
  Terminal,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';

interface EnterpriseHubModalProps {
  open: boolean;
  onClose: () => void;
  onSelectFeature: (featureId: number) => void;
}

interface FeatureItem {
  id: number;
  priority: 'P0' | 'P1' | 'P2' | 'P3';
  title: string;
  desc: string;
  icon: typeof RefreshCw;
  tag: string;
}

const FEATURES: FeatureItem[] = [
  // P0 Foundation
  {
    id: 26,
    priority: 'P0',
    title: '26. Regeneration-Safe Codegen',
    desc: '3-way merge & protected regions prevent overwriting custom user code',
    icon: RefreshCw,
    tag: 'Foundation',
  },
  {
    id: 28,
    priority: 'P0',
    title: '28. Database Schema Designer',
    desc: 'Visual ER diagram canvas, migrations, Drift models & Supabase RLS',
    icon: Database,
    tag: 'Data First',
  },
  {
    id: 29,
    priority: 'P0',
    title: '29. CRUD & Form Scaffolder',
    desc: '1-click full CRUD: List, detail, validated forms, pagination & search',
    icon: Boxes,
    tag: 'Scaffolding',
  },

  // P1 Production Essentials
  {
    id: 27,
    priority: 'P1',
    title: '27. Brownfield Mode (Import)',
    desc: 'Detect existing Flutter stack and safely inject enterprise add-ons',
    icon: FolderSearch,
    tag: 'Existing Apps',
  },
  {
    id: 30,
    priority: 'P1',
    title: '30. Push Notification Setup',
    desc: 'FCM / OneSignal, Android 13 permissions, channels & deep link routing',
    icon: Bell,
    tag: 'Notifications',
  },
  {
    id: 31,
    priority: 'P1',
    title: '31. Remote Config & Force Update',
    desc: 'Runtime feature flags, version checks, soft banners & maintenance gate',
    icon: Sliders,
    tag: 'Remote Config',
  },
  {
    id: 33,
    priority: 'P1',
    title: '33. Legal & Store Compliance',
    desc: 'Privacy Policy, Terms, Play Store Data Safety & Account Deletion flow',
    icon: Scale,
    tag: 'Store Approval',
  },
  {
    id: 34,
    priority: 'P1',
    title: '34. Standard UI States Kit',
    desc: 'Shimmer skeletons, zero-data empty states, offline banners & error retry',
    icon: Palette,
    tag: 'UI Primitives',
  },

  // P2 Full-Stack & Developer Experience
  {
    id: 32,
    priority: 'P2',
    title: '32. Backend Scaffold Generator',
    desc: 'Dart Frog, Rust Axum, Node Fastify or Supabase with OpenAPI 3.0 & Docker',
    icon: Server,
    tag: 'Full-Stack',
  },
  {
    id: 35,
    priority: 'P2',
    title: '35. App Icon & Splash Branding',
    desc: 'Adaptive icon masks, Android 12+ splash screen API & store graphics',
    icon: ImageIcon,
    tag: 'Branding',
  },
  {
    id: 36,
    priority: 'P2',
    title: '36. Mock Data & Fake Server',
    desc: 'Realistic faker datasets, latency & error simulator, standalone server',
    icon: Zap,
    tag: 'Testing',
  },
  {
    id: 40,
    priority: 'P2',
    title: '40. Headless CLI & Config-as-Code',
    desc: 'swati.yaml source of truth, automated CI/CD execution & JSON schema',
    icon: Terminal,
    tag: 'DevOps / CLI',
  },

  // P3 Polish & Scalability
  {
    id: 37,
    priority: 'P3',
    title: '37. Accessibility & Responsive Breakpoints',
    desc: 'Phone/Tablet/Desktop adaptive layouts + WCAG AA contrast validation',
    icon: Eye,
    tag: 'A11y / Layout',
  },
  {
    id: 38,
    priority: 'P3',
    title: '38. Size & Performance Budget',
    desc: '25MB release budget, R8 code shrinking, parallel app bootstrapping',
    icon: Gauge,
    tag: 'Optimization',
  },
  {
    id: 39,
    priority: 'P3',
    title: '39. Auto Documentation Generator',
    desc: 'Living README, ARCHITECTURE Mermaid diagrams, ERDs & ADR records',
    icon: BookOpen,
    tag: 'Living Docs',
  },
];

export function EnterpriseHubModal({ open, onClose, onSelectFeature }: EnterpriseHubModalProps) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🚀 Enterprise Wizard Suite (Part 2: #26 – #40)"
      description="All 15 enterprise features ready for production: codegen safety, brownfield import, schema designer, full-stack scaffolds, compliance, and CLI."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Priority Filter Bar */}
        <div className="flex items-center justify-between text-xs border-b border-gray-200 pb-2 dark:border-slate-800">
          <span className="font-semibold text-gray-500">15 Production Modules Available</span>
          <div className="flex gap-2">
            <span className="rounded bg-rose-100 px-1.5 py-0.5 text-[10px] font-bold text-rose-700 dark:bg-rose-950 dark:text-rose-300">
              P0 (Foundation)
            </span>
            <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700 dark:bg-amber-950 dark:text-amber-300">
              P1 (Essential)
            </span>
            <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
              P2 (Full-Stack)
            </span>
            <span className="rounded bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-700 dark:bg-blue-950 dark:text-blue-300">
              P3 (Polish)
            </span>
          </div>
        </div>

        {/* Features Grid */}
        <div className="max-h-[62vh] overflow-y-auto pr-1 space-y-2">
          {FEATURES.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                onClick={() => {
                  onClose();
                  onSelectFeature(item.id);
                }}
                className="group flex cursor-pointer items-center justify-between rounded-xl border border-gray-200 bg-white p-3.5 transition hover:border-indigo-500 hover:shadow-xs dark:border-slate-800 dark:bg-slate-900 dark:hover:border-indigo-500"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gray-100 text-gray-700 group-hover:bg-indigo-600 group-hover:text-white transition dark:bg-slate-800 dark:text-gray-300">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="truncate">
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition truncate">
                        {item.title}
                      </h4>
                      <span
                        className={`rounded px-1.5 py-0.2 text-[9px] font-bold shrink-0 ${
                          item.priority === 'P0'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                            : item.priority === 'P1'
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                            : item.priority === 'P2'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                        }`}
                      >
                        {item.priority}
                      </span>
                    </div>
                    <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5 truncate">
                      {item.desc}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 ml-3">
                  <span className="hidden sm:inline-block rounded-full bg-gray-100 px-2 py-0.5 text-[10px] font-medium text-gray-600 dark:bg-slate-800 dark:text-gray-400">
                    {item.tag}
                  </span>
                  <div className="rounded-lg p-1.5 text-gray-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition">
                    <ArrowRight className="h-4 w-4" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
}
