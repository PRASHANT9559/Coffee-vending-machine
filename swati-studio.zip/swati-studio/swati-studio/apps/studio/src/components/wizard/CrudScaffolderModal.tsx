'use client';

import { useState } from 'react';
import {
  Boxes,
  Check,
  Code,
  FileCode,
  LayoutGrid,
  ListFilter,
  RefreshCw,
  Search,
  Sparkles,
  Table,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface CrudField {
  name: string;
  type: string;
  inList: boolean;
  searchable: boolean;
  filterable: boolean;
  sortable: boolean;
}

const DEFAULT_FIELDS: CrudField[] = [
  { name: 'name', type: 'String', inList: true, searchable: true, filterable: false, sortable: true },
  { name: 'price', type: 'double', inList: true, searchable: false, filterable: true, sortable: true },
  { name: 'category', type: 'enum', inList: true, searchable: false, filterable: true, sortable: false },
  { name: 'image_url', type: 'String', inList: true, searchable: false, filterable: false, sortable: false },
  { name: 'in_stock', type: 'bool', inList: false, searchable: false, filterable: true, sortable: false },
];

interface CrudScaffolderModalProps {
  open: boolean;
  onClose: () => void;
}

export function CrudScaffolderModal({ open, onClose }: CrudScaffolderModalProps) {
  const [modelName, setModelName] = useState('Product');
  const [fields, setFields] = useState<CrudField[]>(DEFAULT_FIELDS);
  const [layout, setLayout] = useState<'list' | 'grid' | 'table'>('list');
  const [pagination, setPagination] = useState<'infinite' | 'paged'>('infinite');
  const [pullToRefresh, setPullToRefresh] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState(true);
  const [optimistic, setOptimistic] = useState(true);
  const [csvExport, setCsvExport] = useState(false);
  const [formValidation, setFormValidation] = useState(true);
  const [previewCode, setPreviewCode] = useState(false);

  const toggleFieldProp = (index: number, prop: keyof CrudField) => {
    const updated = [...fields];
    if (typeof updated[index][prop] === 'boolean') {
      (updated[index] as any)[prop] = !updated[index][prop];
      setFields(updated);
    }
  };

  const handleGenerate = () => {
    toast.success(`Generated complete CRUD module for ${modelName} (6 screens + controller + repository)!`);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🧱 CRUD & Form Scaffolder (#29)"
      description="Generate full Flutter CRUD interfaces: searchable lists, paginated grids, responsive forms, controllers, and validation."
      size="2xl"
    >
      <div className="space-y-4">
        {/* Model Name & Layout Picker */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-200 pb-3 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">Model:</span>
            <input
              type="text"
              value={modelName}
              onChange={(e) => setModelName(e.target.value)}
              className="rounded-lg border border-gray-300 bg-white px-2.5 py-1 text-xs font-bold text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-indigo-400"
            />
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-gray-500">Layout:</span>
            <div className="flex rounded-lg border border-gray-200 bg-gray-100 p-0.5 dark:border-slate-700 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => setLayout('list')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                  layout === 'list' ? 'bg-white shadow-xs text-indigo-600 dark:bg-slate-900 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                List
              </button>
              <button
                type="button"
                onClick={() => setLayout('grid')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                  layout === 'grid' ? 'bg-white shadow-xs text-indigo-600 dark:bg-slate-900 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                Grid
              </button>
              <button
                type="button"
                onClick={() => setLayout('table')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                  layout === 'table' ? 'bg-white shadow-xs text-indigo-600 dark:bg-slate-900 dark:text-indigo-400' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                Table
              </button>
            </div>
          </div>
        </div>

        {/* Fields Matrix Table */}
        <div className="rounded-xl border border-gray-200 dark:border-slate-800 overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 font-semibold">
              <tr>
                <th className="p-2.5">Field</th>
                <th className="p-2.5">Type</th>
                <th className="p-2.5 text-center">List</th>
                <th className="p-2.5 text-center">Search</th>
                <th className="p-2.5 text-center">Filter</th>
                <th className="p-2.5 text-center">Sort</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
              {fields.map((f, i) => (
                <tr key={f.name} className="hover:bg-gray-50 dark:hover:bg-slate-850">
                  <td className="p-2.5 font-mono font-medium">{f.name}</td>
                  <td className="p-2.5 font-mono text-gray-500">{f.type}</td>
                  <td className="p-2.5 text-center">
                    <input
                      type="checkbox"
                      checked={f.inList}
                      onChange={() => toggleFieldProp(i, 'inList')}
                      className="rounded text-indigo-600"
                    />
                  </td>
                  <td className="p-2.5 text-center">
                    <input
                      type="checkbox"
                      checked={f.searchable}
                      onChange={() => toggleFieldProp(i, 'searchable')}
                      className="rounded text-indigo-600"
                    />
                  </td>
                  <td className="p-2.5 text-center">
                    <input
                      type="checkbox"
                      checked={f.filterable}
                      onChange={() => toggleFieldProp(i, 'filterable')}
                      className="rounded text-indigo-600"
                    />
                  </td>
                  <td className="p-2.5 text-center">
                    <input
                      type="checkbox"
                      checked={f.sortable}
                      onChange={() => toggleFieldProp(i, 'sortable')}
                      className="rounded text-indigo-600"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Feature Checkboxes */}
        <div className="grid grid-cols-2 gap-2 text-xs rounded-xl border border-gray-200 bg-gray-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/40">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={pullToRefresh}
              onChange={(e) => setPullToRefresh(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Pull-to-refresh list</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={deleteConfirm}
              onChange={(e) => setDeleteConfirm(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Delete confirmation dialog</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={optimistic}
              onChange={(e) => setOptimistic(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Optimistic updates</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formValidation}
              onChange={(e) => setFormValidation(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Automatic form validation rules</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={csvExport}
              onChange={(e) => setCsvExport(e.target.checked)}
              className="rounded text-indigo-600"
            />
            <span>Export to CSV button</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={pagination === 'infinite'}
              onChange={(e) => setPagination(e.target.checked ? 'infinite' : 'paged')}
              className="rounded text-indigo-600"
            />
            <span>Infinite scroll pagination</span>
          </label>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-2">
          <Button variant="outline" size="sm" onClick={() => setPreviewCode(!previewCode)}>
            <FileCode className="h-4 w-4 mr-1.5" />
            {previewCode ? 'Hide Code' : 'Preview Screen Dart'}
          </Button>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleGenerate}>
              <Sparkles className="h-4 w-4 mr-1.5" />
              Scaffold {modelName} Module
            </Button>
          </div>
        </div>

        {previewCode && (
          <div className="rounded-xl bg-slate-950 p-4 font-mono text-[11px] text-indigo-300 max-h-60 overflow-y-auto whitespace-pre leading-relaxed">
{`// lib/features/products/screens/product_list_screen.dart
class ProductListScreen extends ConsumerWidget {
  const ProductListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(productControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Products')),
      body: RefreshIndicator(
        onRefresh: () => ref.read(productControllerProvider.notifier).fetchProducts(),
        child: ListView.builder(
          itemCount: state.products.length,
          itemBuilder: (ctx, i) => ProductCard(product: state.products[i]),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/products/create'),
        child: const Icon(Icons.add),
      ),
    );
  }
}`}
          </div>
        )}
      </div>
    </Modal>
  );
}
