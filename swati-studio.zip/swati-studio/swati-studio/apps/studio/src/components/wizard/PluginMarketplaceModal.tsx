'use client';

import { useState } from 'react';
import { studioPlugins, type StudioPlugin, type StudioConfig } from '@swati/schema';
import {
  Check,
  CreditCard,
  Download,
  FileText,
  Package,
  Plus,
  Search,
  Share2,
  ShieldCheck,
  Sparkles,
  Star,
  Wifi,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { toast } from '@/lib/toast';

interface PluginMarketplaceModalProps {
  open: boolean;
  onClose: () => void;
  config: StudioConfig;
  onInstallPlugin: (plugin: StudioPlugin) => void;
}

const PLUGIN_ICONS: Record<string, React.ReactNode> = {
  Share2: <Share2 className="h-5 w-5" />,
  CreditCard: <CreditCard className="h-5 w-5" />,
  Wifi: <Wifi className="h-5 w-5" />,
  FileText: <FileText className="h-5 w-5" />,
  Sparkles: <Sparkles className="h-5 w-5" />,
  ShieldCheck: <ShieldCheck className="h-5 w-5" />,
};

export function PluginMarketplaceModal({
  open,
  onClose,
  config,
  onInstallPlugin,
}: PluginMarketplaceModalProps) {
  const [search, setSearch] = useState('');
  const [installedIds, setInstalledIds] = useState<string[]>(['pdf_generator', 'stripe_payments']);

  const filtered = studioPlugins.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase())
  );

  const toggleInstall = (plugin: StudioPlugin) => {
    if (installedIds.includes(plugin.id)) {
      setInstalledIds(installedIds.filter((id) => id !== plugin.id));
      toast.info(`Uninstalled ${plugin.name}`);
    } else {
      setInstalledIds([...installedIds, plugin.id]);
      onInstallPlugin(plugin);
      toast.success(`Installed ${plugin.name}!`);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="🧩 Swati Plugin & Addon Marketplace"
      description="Supercharge your Flutter app architecture with battle-tested community plugins and integrations"
      size="lg"
    >
      <div className="space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search plugins (GraphQL, Stripe, WebSockets, PDF, Lottie)..."
            className="w-full rounded-xl border border-gray-200 bg-gray-50 py-2 pl-9 pr-4 text-xs text-gray-900 outline-none transition focus:border-indigo-500 focus:bg-white dark:border-slate-800 dark:bg-slate-900 dark:text-white"
          />
        </div>

        {/* Plugin Cards */}
        <div className="grid gap-3 max-h-[380px] overflow-y-auto pr-1">
          {filtered.map((plugin) => {
            const isInstalled = installedIds.includes(plugin.id);
            return (
              <div
                key={plugin.id}
                className="flex items-center justify-between rounded-xl border border-gray-200 bg-white p-3.5 transition hover:border-gray-300 dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
                    {PLUGIN_ICONS[plugin.icon] ?? <Package className="h-5 w-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-gray-900 dark:text-white">
                        {plugin.name}
                      </h4>
                      <span className="flex items-center text-[10px] text-amber-500 font-semibold">
                        <Star className="h-3 w-3 fill-amber-400 mr-0.5" />
                        {plugin.rating}
                      </span>
                      <span className="text-[10px] text-gray-400">
                        {plugin.downloads} installs
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      {plugin.description}
                    </p>
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {plugin.dependencies.map((dep) => (
                        <span
                          key={dep}
                          className="rounded bg-gray-100 px-1.5 py-0.5 text-[9px] font-mono text-gray-600 dark:bg-slate-800 dark:text-gray-400"
                        >
                          {dep}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <Button
                  variant={isInstalled ? 'outline' : 'default'}
                  size="sm"
                  onClick={() => toggleInstall(plugin)}
                  className={`text-xs ml-3 shrink-0 ${
                    isInstalled ? 'border-emerald-500 text-emerald-600 dark:border-emerald-700' : ''
                  }`}
                >
                  {isInstalled ? (
                    <>
                      <Check className="h-3.5 w-3.5 mr-1 text-emerald-500" />
                      Installed
                    </>
                  ) : (
                    <>
                      <Plus className="h-3.5 w-3.5 mr-1" />
                      Install
                    </>
                  )}
                </Button>
              </div>
            );
          })}
        </div>

        <div className="flex justify-end pt-2 border-t border-gray-200 dark:border-slate-800">
          <Button onClick={onClose} size="sm">
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
}
