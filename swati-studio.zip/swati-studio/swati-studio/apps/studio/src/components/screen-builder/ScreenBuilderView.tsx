'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  Code2,
  Copy,
  Check,
  Columns,
  Download,
  Edit2,
  Eye,
  FileCode,
  Home,
  Layers,
  LayoutTemplate,
  MousePointerClick,
  Palette,
  Plus,
  Redo2,
  Route as RouteIcon,
  Save,
  Search,
  Settings,
  Sliders,
  Smartphone,
  Sparkles,
  Split,
  Star,
  Trash2,
  Type,
  Undo2,
  Upload,
  X,
} from 'lucide-react';
import { themeOptions, type ThemePalette } from '@swati/schema';
import { Button } from '@/components/ui/Button';
import {
  useStudioStore,
  type AppScreen,
  type ScreenComponent,
} from '@/lib/store';
import { toast } from '@/lib/toast';
import {
  useScreenBuilderUndoRedo,
  type ScreenBuilderState,
} from '@/lib/undoRedoService';
import { screenExportService } from '@/lib/screenExportService';

interface ComponentTemplate {
  type: ScreenComponent['type'];
  name: string;
  category: 'Layout' | 'Buttons' | 'Inputs' | 'Content' | 'Data';
  icon: string;
  desc: string;
  defaultProps: ScreenComponent['props'];
}

const COMPONENT_CATALOG: ComponentTemplate[] = [
  // Layout
  {
    type: 'appbar',
    name: 'Top AppBar',
    category: 'Layout',
    icon: 'LayoutTemplate',
    desc: 'Material 3 Top App Bar with title & route',
    defaultProps: {
      title: 'Current Screen',
      elevation: 2,
    },
  },
  {
    type: 'container',
    name: 'Container Box',
    category: 'Layout',
    icon: 'Layers',
    desc: 'Structured box with padding, margin & border radius',
    defaultProps: {
      padding: 16,
      borderRadius: 12,
    },
  },
  {
    type: 'divider',
    name: 'Horizontal Divider',
    category: 'Layout',
    icon: 'Sliders',
    desc: 'Clean horizontal line separator',
    defaultProps: {},
  },
  {
    type: 'spacer',
    name: 'Vertical Spacer',
    category: 'Layout',
    icon: 'Sliders',
    desc: 'SizedBox height spacing element',
    defaultProps: {
      height: 16,
    },
  },

  // Buttons
  {
    type: 'button',
    name: 'Elevated Action Button',
    category: 'Buttons',
    icon: 'MousePointerClick',
    desc: 'Interactive button with tap ripple & navigation trigger',
    defaultProps: {
      label: 'Navigate to Next Screen',
      variant: 'elevated',
      borderRadius: 12,
      actionType: 'navigate',
      targetRoute: '/profile',
    },
  },
  {
    type: 'button',
    name: 'Outlined Button',
    category: 'Buttons',
    icon: 'MousePointerClick',
    desc: 'Bordered button with transparent background',
    defaultProps: {
      label: 'Secondary Action',
      variant: 'outlined',
      borderRadius: 12,
      actionType: 'snackbar',
    },
  },
  {
    type: 'floating_action_button',
    name: 'Floating Action Button (FAB)',
    category: 'Buttons',
    icon: 'Plus',
    desc: 'Prominent primary floating action button',
    defaultProps: {
      icon: 'Plus',
      elevation: 6,
      actionType: 'snackbar',
    },
  },

  // Content
  {
    type: 'card',
    name: 'Material Card',
    category: 'Content',
    icon: 'Layers',
    desc: 'Card container with dynamic theme surface & borders',
    defaultProps: {
      title: 'Dynamic Content Card',
      subtitle: 'Automatically styled using active theme palette tokens.',
      borderRadius: 16,
      padding: 16,
      elevation: 2,
    },
  },
  {
    type: 'text',
    name: 'Typography / Heading',
    category: 'Content',
    icon: 'Type',
    desc: 'Formatted text block with dynamic theme text color',
    defaultProps: {
      text: 'Dynamic Screen Header',
      variant: 'h1',
      fontSize: 22,
      padding: 6,
    },
  },
  {
    type: 'image',
    name: 'Gradient Banner',
    category: 'Content',
    icon: 'Palette',
    desc: 'Banner container styled with theme accent colors',
    defaultProps: {
      title: 'Featured Promotion',
      borderRadius: 14,
      height: 160,
    },
  },

  // Inputs
  {
    type: 'textfield',
    name: 'Form Input Field',
    category: 'Inputs',
    icon: 'Type',
    desc: 'Text input with floating label and hint',
    defaultProps: {
      label: 'User Input',
      placeholder: 'Enter details...',
      borderRadius: 10,
    },
  },

  // Data
  {
    type: 'listview',
    name: 'List Navigation Section',
    category: 'Data',
    icon: 'Layers',
    desc: 'List tiles with dynamic action routes',
    defaultProps: {
      title: 'Navigation Links',
      items: ['Dashboard Overview', 'User Profile Settings', 'Security & Privacy'],
      borderRadius: 12,
    },
  },
  {
    type: 'stat_card',
    name: 'Theme Metric Card',
    category: 'Data',
    icon: 'Layers',
    desc: 'Dashboard key metric styled with primary theme token',
    defaultProps: {
      title: 'Active Sessions',
      value: '1,420',
      borderRadius: 14,
    },
  },
];

export function ScreenBuilderView() {
  const {
    apps,
    currentAppId,
    config,
    theme,
    screens,
    activeScreenId,
    activeComponents,
    selectedComponentId,
    selectedThemePalette,
    addScreen,
    deleteScreen,
    renameScreen,
    setInitialScreen,
    selectScreen,
    setThemePalette,
    addComponent,
    updateComponent,
    deleteComponent,
    reorderComponents,
    setSelectedComponentId,
    setCurrentView,
    saveCurrentApp,
    updateCurrentAppMetadata,
  } = useStudioStore();

  // Undo/Redo state integration
  const initialScreenBuilderState: ScreenBuilderState = {
    screens,
    activeScreenId,
    activeComponents,
    selectedComponentId,
  };

  const {
    state: undoRedoState,
    dispatch,
    undo,
    redo,
    canUndo,
    canRedo,
    exportScreens,
    importScreens,
  } = useScreenBuilderUndoRedo(initialScreenBuilderState);

  const iframeRef = useRef<HTMLIFrameElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeTab, setActiveTab] = useState<'inspector' | 'tree' | 'routing'>('inspector');
  const [viewMode, setViewMode] = useState<'canvas' | 'split' | 'code'>('canvas');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [paletteSearch, setPaletteSearch] = useState('');
  const [isDraggingOverCanvas, setIsDraggingOverCanvas] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);

  const [appNameInput, setAppNameInput] = useState(
    () => apps.find((a) => a.id === currentAppId)?.name || String(config['project.name'] || 'My Flutter App')
  );

  // New screen modal state
  const [showAddScreenModal, setShowAddScreenModal] = useState(false);
  const [newScreenName, setNewScreenName] = useState('');
  const [newScreenRoute, setNewScreenRoute] = useState('');

  const activeScreen = screens.find((s) => s.id === activeScreenId) || screens[0];
  const selectedComponent = activeComponents.find((c) => c.id === selectedComponentId);

  // Active palette spec from the 20 theme options
  const activePaletteObj =
    themeOptions.find(
      (t) => t.name.toLowerCase().replace(/[^a-z0-9]+/g, '_') === selectedThemePalette
    ) || themeOptions[0];

  // Live generated Dart code for the active screen
  const generatedDartCode = activeScreen
    ? screenExportService.exportScreenToDart(activeScreen)
    : '// No screen selected';

  // Handle undo/redo with toast feedback and store synchronization
  const handleUndo = useCallback(() => {
    if (canUndo) {
      undo();
      // Synchronize restored snapshot into Zustand store
      const prevState = undoRedoState;
      if (prevState) {
        useStudioStore.setState({
          screens: prevState.screens,
          activeComponents: prevState.activeComponents,
          activeScreenId: prevState.activeScreenId,
          selectedComponentId: prevState.selectedComponentId,
        });
      }
      toast.success('Undo action');
    }
  }, [canUndo, undo, undoRedoState]);

  const handleRedo = useCallback(() => {
    if (canRedo) {
      redo();
      const nextState = undoRedoState;
      if (nextState) {
        useStudioStore.setState({
          screens: nextState.screens,
          activeComponents: nextState.activeComponents,
          activeScreenId: nextState.activeScreenId,
          selectedComponentId: nextState.selectedComponentId,
        });
      }
      toast.success('Redo action');
    }
  }, [canRedo, redo, undoRedoState]);

  // Keyboard shortcuts (Ctrl+Z, Ctrl+Y, Ctrl+S)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSaveApp();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  // Export JSON file download
  const handleExportJson = () => {
    try {
      const exportedData = screenExportService.exportToJson(screens, activeComponents);
      const blob = new Blob([exportedData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${activeScreen?.name || 'swati-studio'}-screens.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Screens exported to JSON');
    } catch (error) {
      toast.error('Failed to export screens');
      console.error(error);
    }
  };

  // Import JSON file
  const handleImportJson = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const imported = screenExportService.importFromJson(content);
        if (imported) {
          importScreens(content);
          toast.success(`Imported ${imported.screens.length} screens successfully!`);
        } else {
          toast.error('Invalid screen JSON format');
        }
      } catch (error) {
        toast.error('Failed to parse screen JSON');
        console.error(error);
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  };

  // Download standalone Dart file for active screen
  const handleDownloadDart = () => {
    try {
      const blob = new Blob([generatedDartCode], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const fileName = `${(activeScreen?.name || 'screen').toLowerCase().replace(/[^a-z0-9]/g, '_')}_page.dart`;
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success(`Downloaded ${fileName}`);
    } catch (error) {
      toast.error('Failed to download Dart code');
    }
  };

  // Copy Dart code to clipboard
  const handleCopyDart = async () => {
    try {
      await navigator.clipboard.writeText(generatedDartCode);
      setCopiedCode(true);
      toast.success('Dart code copied to clipboard!');
      setTimeout(() => setCopiedCode(false), 2000);
    } catch (err) {
      toast.error('Failed to copy code');
    }
  };

  // Sync state to flutter engine iframe via postMessage
  const syncWithFlutterEngine = () => {
    if (!iframeRef.current?.contentWindow) return;
    iframeRef.current.contentWindow.postMessage(
      {
        type: 'SWATI_STUDIO_SYNC_COMPONENTS',
        components: activeComponents,
        selectedId: selectedComponentId,
        theme: theme === 'dark' ? 'dark' : 'light',
        palette: activePaletteObj,
        currentRoute: activeScreen?.route || '/',
      },
      '*'
    );
  };

  useEffect(() => {
    syncWithFlutterEngine();
  }, [activeComponents, selectedComponentId, theme, selectedThemePalette, activeScreenId]);

  // Listen for messages from the flutter engine iframe
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!event.data || typeof event.data !== 'object') return;

      if (event.data.type === 'SWATI_STUDIO_SELECT_COMPONENT') {
        setSelectedComponentId(event.data.id);
        setActiveTab('inspector');
      } else if (event.data.type === 'SWATI_STUDIO_FRAME_READY') {
        syncWithFlutterEngine();
      } else if (event.data.type === 'SWATI_STUDIO_NAVIGATE') {
        const targetRoute = event.data.route;
        const targetScreen = screens.find((s) => s.route === targetRoute);
        if (targetScreen) {
          selectScreen(targetScreen.id);
          toast.success(`Navigated to ${targetScreen.name} (${targetRoute})`);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [activeComponents, selectedComponentId, theme, screens, activePaletteObj]);

  const handleAddComponent = (tpl: ComponentTemplate) => {
    const newComp = addComponent({
      type: tpl.type,
      name: tpl.name,
      props: { ...tpl.defaultProps },
    });
    dispatch({
      type: 'ADD_COMPONENT',
      screenId: activeScreen.id,
      component: newComp,
    });
    setSelectedComponentId(newComp.id);
    setActiveTab('inspector');
    toast.success(`Added ${tpl.name} to ${activeScreen.name}!`);
  };

  const handleDeleteComponent = (id: string, name: string) => {
    deleteComponent(id);
    dispatch({
      type: 'DELETE_COMPONENT',
      screenId: activeScreen.id,
      componentId: id,
    });
    toast.success(`Removed ${name}`);
  };

  const handleSaveApp = () => {
    updateCurrentAppMetadata(appNameInput);
    saveCurrentApp(appNameInput);
    toast.success('App, screens, routing & theme palette saved!');
  };

  const handleCreateNewScreen = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newScreenName.trim();
    if (!name) return;

    let route = newScreenRoute.trim();
    if (!route) {
      route = `/${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
    }
    if (!route.startsWith('/')) {
      route = `/${route}`;
    }

    const created = addScreen(name, route);
    dispatch({
      type: 'ADD_SCREEN',
      screen: created,
    });
    setShowAddScreenModal(false);
    setNewScreenName('');
    setNewScreenRoute('');
    toast.success(`Created screen "${created.name}" with route "${created.route}"`);
  };

  // HTML5 Drag & Drop handlers
  const handleDragStartPalette = (e: React.DragEvent, tpl: ComponentTemplate) => {
    e.dataTransfer.setData('application/json', JSON.stringify(tpl));
    e.dataTransfer.effectAllowed = 'copy';
  };

  const handleDragOverCanvas = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    setIsDraggingOverCanvas(true);
  };

  const handleDragLeaveCanvas = () => {
    setIsDraggingOverCanvas(false);
  };

  const handleDropOnCanvas = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOverCanvas(false);
    try {
      const dataStr = e.dataTransfer.getData('application/json');
      if (dataStr) {
        const tpl = JSON.parse(dataStr) as ComponentTemplate;
        handleAddComponent(tpl);
      }
    } catch (err) {
      console.warn('Drop error:', err);
    }
  };

  const filteredCatalog = COMPONENT_CATALOG.filter((tpl) => {
    const matchCat = categoryFilter === 'All' || tpl.category === categoryFilter;
    const matchSearch =
      tpl.name.toLowerCase().includes(paletteSearch.toLowerCase()) ||
      tpl.desc.toLowerCase().includes(paletteSearch.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="flex h-full flex-1 flex-col overflow-hidden bg-gray-50 dark:bg-slate-950">
      {/* Hidden file input for importing JSON */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={handleImportJson}
      />

      {/* ---------------------------------------------------------------- */}
      {/* Top Header: App Name, Undo/Redo, Themes, Views & Save */}
      {/* ---------------------------------------------------------------- */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-gray-200 bg-white px-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2 sm:gap-3">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setCurrentView('applications')}
            className="gap-1.5 text-xs text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" />
            <span className="hidden sm:inline">Applications</span>
          </Button>

          <div className="h-4 w-[1px] bg-gray-200 dark:bg-slate-800" />

          {/* App Name input */}
          <input
            type="text"
            value={appNameInput}
            onChange={(e) => setAppNameInput(e.target.value)}
            onBlur={handleSaveApp}
            className="rounded-lg border border-transparent px-2 py-1 text-sm font-bold text-gray-900 transition hover:border-gray-200 focus:border-indigo-500 focus:bg-white focus:outline-none dark:text-white dark:hover:border-slate-700 dark:focus:bg-slate-800"
            title="Click to rename app"
          />

          {/* Undo / Redo controls */}
          <div className="flex items-center gap-1 border-l border-gray-200 pl-2 dark:border-slate-800">
            <button
              type="button"
              onClick={handleUndo}
              disabled={!canUndo}
              title="Undo (Ctrl+Z)"
              className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100 disabled:opacity-30 dark:text-gray-400 dark:hover:bg-slate-800"
            >
              <Undo2 className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={!canRedo}
              title="Redo (Ctrl+Y)"
              className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100 disabled:opacity-30 dark:text-gray-400 dark:hover:bg-slate-800"
            >
              <Redo2 className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Center/Right Toolbar */}
        <div className="flex items-center gap-2">
          {/* View Mode Toggle: Canvas / Split / Code */}
          <div className="hidden sm:flex items-center rounded-xl border border-gray-200 bg-gray-100 p-0.5 dark:border-slate-800 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => setViewMode('canvas')}
              className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
                viewMode === 'canvas'
                  ? 'bg-white text-indigo-600 shadow-xs dark:bg-slate-900 dark:text-indigo-400'
                  : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white'
              }`}
            >
              <Smartphone className="h-3.5 w-3.5" />
              Canvas
            </button>
            <button
              type="button"
              onClick={() => setViewMode('split')}
              className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
                viewMode === 'split'
                  ? 'bg-white text-indigo-600 shadow-xs dark:bg-slate-900 dark:text-indigo-400'
                  : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white'
              }`}
            >
              <Split className="h-3.5 w-3.5" />
              Split
            </button>
            <button
              type="button"
              onClick={() => setViewMode('code')}
              className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
                viewMode === 'code'
                  ? 'bg-white text-indigo-600 shadow-xs dark:bg-slate-900 dark:text-indigo-400'
                  : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white'
              }`}
            >
              <Code2 className="h-3.5 w-3.5" />
              Dart Code
            </button>
          </div>

          {/* 20 Dynamic Theme Selector */}
          <div className="flex items-center gap-1.5 rounded-xl border border-gray-200 bg-gray-50 px-2.5 py-1 dark:border-slate-800 dark:bg-slate-800">
            <Palette className="h-3.5 w-3.5 text-indigo-500" />
            <select
              value={selectedThemePalette}
              onChange={(e) => {
                setThemePalette(e.target.value);
                toast.success('Theme updated! Dynamically applied across all screens.');
              }}
              className="bg-transparent text-xs font-semibold text-gray-800 outline-none cursor-pointer dark:text-gray-200"
            >
              {themeOptions.map((opt) => {
                const id = opt.name.toLowerCase().replace(/[^a-z0-9]+/g, '_');
                return (
                  <option key={id} value={id} className="dark:bg-slate-900 dark:text-white">
                    {opt.name}
                  </option>
                );
              })}
            </select>
            <span
              className="h-3 w-3 rounded-full shadow-xs shrink-0"
              style={{ backgroundColor: activePaletteObj.light.blue }}
              title={`Primary Color: ${activePaletteObj.light.blue}`}
            />
          </div>

          {/* Export Dart Code Button */}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setShowExportModal(true)}
            className="gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400"
          >
            <FileCode className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Export Dart</span>
          </Button>

          {/* Export / Import JSON dropdown/buttons */}
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleExportJson}
            title="Export Screens to JSON"
            className="text-xs text-gray-600 hover:text-gray-900 dark:text-gray-400"
          >
            <Download className="h-3.5 w-3.5" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            title="Import Screens from JSON"
            className="text-xs text-gray-600 hover:text-gray-900 dark:text-gray-400"
          >
            <Upload className="h-3.5 w-3.5" />
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setCurrentView('wizard')}
            className="text-xs"
          >
            <Settings className="mr-1.5 h-3.5 w-3.5" />
            Wizard
          </Button>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={handleSaveApp}
            className="gap-1.5 text-xs font-semibold shadow-xs"
          >
            <Save className="h-3.5 w-3.5" />
            Save App
          </Button>
        </div>
      </header>

      {/* ---------------------------------------------------------------- */}
      {/* Screen Routing Navigation Bar */}
      {/* ---------------------------------------------------------------- */}
      <div className="flex items-center justify-between border-b border-gray-200 bg-white/80 px-4 py-2 backdrop-blur dark:border-slate-800 dark:bg-slate-900/80">
        <div className="flex items-center gap-2 overflow-x-auto py-0.5">
          <span className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-gray-400 shrink-0">
            <RouteIcon className="h-3.5 w-3.5 text-indigo-500" />
            Screens:
          </span>

          {screens.map((sc) => {
            const isActive = sc.id === activeScreenId;
            return (
              <div
                key={sc.id}
                onClick={() => selectScreen(sc.id)}
                className={`group flex cursor-pointer items-center gap-2 rounded-xl border px-3 py-1.5 text-xs font-semibold transition ${
                  isActive
                    ? 'border-indigo-500 bg-indigo-50 text-indigo-700 shadow-xs dark:border-indigo-400 dark:bg-indigo-950/40 dark:text-indigo-300'
                    : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300 dark:border-slate-800 dark:bg-slate-800/80 dark:text-gray-300'
                }`}
              >
                {sc.isInitial ? (
                  <span title="Entry Screen (Initial Route: /)">
                    <Star className="h-3 w-3 fill-amber-400 text-amber-500 shrink-0" />
                  </span>
                ) : (
                  <Home className="h-3 w-3 opacity-40 shrink-0" />
                )}
                <span>{sc.name}</span>
                <span className="font-mono text-[10px] opacity-60">({sc.route})</span>

                {isActive && !sc.isInitial && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setInitialScreen(sc.id);
                      toast.success(`"${sc.name}" is now the Initial Starting Screen!`);
                    }}
                    className="ml-1 rounded px-1 text-[10px] text-amber-600 hover:bg-amber-100 dark:hover:bg-amber-950/50"
                    title="Make this screen the initial entry screen"
                  >
                    ★ Set as Home
                  </button>
                )}

                {screens.length > 1 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteScreen(sc.id);
                      dispatch({ type: 'DELETE_SCREEN', screenId: sc.id });
                      toast.success(`Deleted screen "${sc.name}"`);
                    }}
                    className="ml-1 opacity-40 hover:opacity-100 hover:text-red-500"
                    title="Delete screen"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </div>
            );
          })}

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setShowAddScreenModal(true)}
            className="gap-1 px-2.5 py-1 text-xs font-semibold"
          >
            <Plus className="h-3.5 w-3.5 text-indigo-500" />
            Add Screen
          </Button>
        </div>

        <div className="hidden lg:flex items-center gap-2 text-xs text-gray-400">
          <span>Active Route:</span>
          <code className="rounded bg-gray-100 px-2 py-0.5 font-mono text-[11px] font-bold text-indigo-600 dark:bg-slate-800 dark:text-indigo-400">
            {activeScreen?.route}
          </code>
        </div>
      </div>

      {/* ---------------------------------------------------------------- */}
      {/* 3-Column Studio Workspace */}
      {/* ---------------------------------------------------------------- */}
      <div className="grid flex-1 grid-cols-1 overflow-hidden lg:grid-cols-12">
        {/* ============================================================== */}
        {/* LEFT COLUMN: Component Palette (Draggable Widgets) */}
        {/* ============================================================== */}
        <aside className="border-r border-gray-200 bg-white p-3 lg:col-span-3 lg:overflow-y-auto dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between pb-3">
            <div>
              <h2 className="text-sm font-bold tracking-tight">Widget Library</h2>
              <p className="text-[11px] text-gray-500 dark:text-gray-400">
                Drag to canvas or click + to add
              </p>
            </div>
            <span className="rounded bg-indigo-50 px-2 py-0.5 text-[10px] font-semibold text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400">
              {filteredCatalog.length}
            </span>
          </div>

          {/* Search Palette */}
          <div className="relative mb-3">
            <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-gray-400" />
            <input
              type="text"
              value={paletteSearch}
              onChange={(e) => setPaletteSearch(e.target.value)}
              placeholder="Search components..."
              className="w-full rounded-lg border border-gray-200 bg-gray-50 py-1.5 pl-8 pr-3 text-xs outline-none transition focus:border-indigo-500 focus:bg-white dark:border-slate-800 dark:bg-slate-800/60 dark:focus:bg-slate-800"
            />
          </div>

          {/* Categories */}
          <div className="mb-3 flex flex-wrap gap-1">
            {['All', 'Layout', 'Buttons', 'Content', 'Inputs', 'Data'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`rounded px-2 py-0.5 text-[10px] font-medium transition ${
                  categoryFilter === cat
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-slate-800 dark:text-gray-400 dark:hover:bg-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Component Tiles List (Draggable + Click to Add) */}
          <div className="space-y-2">
            {filteredCatalog.map((tpl) => (
              <div
                key={tpl.type + tpl.name}
                draggable
                onDragStart={(e) => handleDragStartPalette(e, tpl)}
                onClick={() => handleAddComponent(tpl)}
                className="group flex cursor-grab active:cursor-grabbing items-start justify-between rounded-xl border border-gray-200/80 bg-white p-3 transition hover:border-indigo-400 hover:shadow-xs dark:border-slate-800 dark:bg-slate-900/60 dark:hover:border-indigo-500"
              >
                <div className="min-w-0 pr-2">
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-xs text-gray-900 group-hover:text-indigo-600 dark:text-white dark:group-hover:text-indigo-400">
                      {tpl.name}
                    </span>
                    <span className="rounded bg-gray-100 px-1.5 py-0.2 text-[9px] text-gray-500 dark:bg-slate-800 dark:text-gray-400">
                      {tpl.category}
                    </span>
                  </div>
                  <p className="mt-0.5 line-clamp-1 text-[10px] text-gray-500 dark:text-gray-400">
                    {tpl.desc}
                  </p>
                </div>
                <button
                  type="button"
                  title="Add to current screen"
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-600 transition group-hover:bg-indigo-600 group-hover:text-white dark:bg-slate-800 dark:text-gray-300"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </aside>

        {/* ============================================================== */}
        {/* CENTER COLUMN: Canvas / Split / Live Dart Code View */}
        {/* ============================================================== */}
        <main
          className={`flex flex-col items-center justify-center p-4 lg:overflow-y-auto ${
            viewMode === 'split' ? 'lg:col-span-6' : viewMode === 'code' ? 'lg:col-span-6' : 'lg:col-span-6'
          }`}
        >
          {viewMode === 'code' ? (
            /* Live Code Only View */
            <div className="flex h-full w-full flex-col rounded-2xl border border-gray-200 bg-slate-950 p-4 shadow-xl dark:border-slate-800">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <FileCode className="h-4 w-4 text-indigo-400" />
                  <span className="font-mono text-xs font-bold text-white">
                    {activeScreen?.name}_page.dart
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleCopyDart}
                    className="gap-1 text-xs text-slate-300 hover:text-white"
                  >
                    {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedCode ? 'Copied' : 'Copy'}
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={handleDownloadDart}
                    className="gap-1 text-xs"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download
                  </Button>
                </div>
              </div>
              <pre className="mt-3 flex-1 overflow-auto rounded-lg bg-slate-900/80 p-4 font-mono text-xs text-indigo-200 leading-relaxed">
                <code>{generatedDartCode}</code>
              </pre>
            </div>
          ) : viewMode === 'split' ? (
            /* Split View: Canvas + Code Side-by-Side */
            <div className="grid h-full w-full grid-cols-1 md:grid-cols-2 gap-4">
              {/* Canvas Side */}
              <div
                onDragOver={handleDragOverCanvas}
                onDragLeave={handleDragLeaveCanvas}
                onDrop={handleDropOnCanvas}
                className={`relative flex flex-col items-center justify-center rounded-2xl border-2 transition ${
                  isDraggingOverCanvas ? 'border-indigo-500 bg-indigo-50/20' : 'border-transparent'
                }`}
              >
                <div className="relative flex h-[580px] w-[310px] flex-col overflow-hidden rounded-[32px] border-[8px] border-slate-900 bg-slate-900 shadow-2xl">
                  <div className="absolute left-1/2 top-1.5 z-30 h-3.5 w-28 -translate-x-1/2 rounded-full bg-slate-900">
                    <div className="mx-auto mt-1 h-1.5 w-10 rounded-full bg-slate-800/90" />
                  </div>
                  <div className="relative flex-1 overflow-hidden pt-5">
                    <iframe
                      ref={iframeRef}
                      src="/flutter-preview.html"
                      title="Flutter Web Live Canvas"
                      className="h-full w-full border-0 bg-slate-950"
                    />
                  </div>
                </div>
              </div>

              {/* Code Side */}
              <div className="flex flex-col rounded-2xl border border-gray-200 bg-slate-950 p-3 shadow-lg dark:border-slate-800">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="font-mono text-xs text-slate-300">Live Flutter Dart Code</span>
                  <button
                    type="button"
                    onClick={handleCopyDart}
                    className="flex items-center gap-1 rounded bg-slate-800 px-2 py-1 text-[11px] text-slate-300 hover:text-white"
                  >
                    {copiedCode ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    {copiedCode ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="mt-2 flex-1 overflow-auto rounded bg-slate-900 p-3 font-mono text-[11px] text-indigo-200 leading-relaxed">
                  <code>{generatedDartCode}</code>
                </pre>
              </div>
            </div>
          ) : (
            /* Canvas Only View (Default) */
            <div
              onDragOver={handleDragOverCanvas}
              onDragLeave={handleDragLeaveCanvas}
              onDrop={handleDropOnCanvas}
              className={`relative flex flex-col items-center justify-center p-2 rounded-3xl transition ${
                isDraggingOverCanvas ? 'ring-4 ring-indigo-500/50 bg-indigo-50/10' : ''
              }`}
            >
              {isDraggingOverCanvas && (
                <div className="absolute inset-0 z-40 flex items-center justify-center rounded-3xl bg-indigo-600/20 backdrop-blur-xs border-2 border-dashed border-indigo-500">
                  <div className="rounded-xl bg-indigo-600 px-4 py-2 font-bold text-white shadow-lg text-sm">
                    Drop widget here to add
                  </div>
                </div>
              )}

              {/* Phone Frame */}
              <div className="relative flex h-[630px] w-[335px] flex-col overflow-hidden rounded-[36px] border-[10px] border-slate-900 bg-slate-900 shadow-2xl ring-1 ring-slate-800/80">
                {/* Phone Notch */}
                <div className="absolute left-1/2 top-2 z-30 h-4 w-32 -translate-x-1/2 rounded-full bg-slate-900">
                  <div className="mx-auto mt-1 h-2 w-12 rounded-full bg-slate-800/90" />
                </div>

                {/* Flutter Web Canvas Engine */}
                <div className="relative flex-1 overflow-hidden pt-6">
                  <iframe
                    ref={iframeRef}
                    src="/flutter-preview.html"
                    title="Flutter Web Live Canvas"
                    className="h-full w-full border-0 bg-slate-950"
                  />
                </div>

                {/* Phone Bottom Home Bar */}
                <div className="h-4 shrink-0 bg-slate-900">
                  <div className="mx-auto mt-1 h-1 w-24 rounded-full bg-slate-700/60" />
                </div>
              </div>

              <div className="mt-3 flex items-center gap-2 text-xs text-gray-400">
                <Sparkles className="h-3.5 w-3.5 text-indigo-500" />
                <span>
                  Screen: <strong>{activeScreen?.name}</strong> • Theme: <strong>{activePaletteObj.name}</strong>
                </span>
              </div>
            </div>
          )}
        </main>

        {/* ============================================================== */}
        {/* RIGHT COLUMN: Inspector, Component Tree & Routing Table */}
        {/* ============================================================== */}
        <aside className="flex flex-col border-l border-gray-200 bg-white lg:col-span-3 lg:overflow-hidden dark:border-slate-800 dark:bg-slate-900">
          {/* Tabs */}
          <div className="flex border-b border-gray-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setActiveTab('inspector')}
              className={`flex-1 border-b-2 py-3 text-center text-xs font-bold transition ${
                activeTab === 'inspector'
                  ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400'
                  : 'border-transparent text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200'
              }`}
            >
              <span className="flex items-center justify-center gap-1.5">
                <Sliders className="h-3.5 w-3.5" />
                Inspector
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('tree')}
              className={`flex-1 border-b-2 py-3 text-center text-xs font-bold transition ${
                activeTab === 'tree'
                  ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400'
                  : 'border-transparent text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200'
              }`}
            >
              <span className="flex items-center justify-center gap-1.5">
                <Layers className="h-3.5 w-3.5" />
                Tree ({activeComponents.length})
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('routing')}
              className={`flex-1 border-b-2 py-3 text-center text-xs font-bold transition ${
                activeTab === 'routing'
                  ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400'
                  : 'border-transparent text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200'
              }`}
            >
              <span className="flex items-center justify-center gap-1.5">
                <RouteIcon className="h-3.5 w-3.5" />
                Routes ({screens.length})
              </span>
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-4">
            {activeTab === 'inspector' ? (
              /* Inspector: Customize Widget */
              selectedComponent ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-gray-100 pb-3 dark:border-slate-800">
                    <div>
                      <span className="rounded bg-indigo-50 px-2 py-0.5 font-mono text-[10px] font-semibold text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400">
                        {selectedComponent.type.toUpperCase()}
                      </span>
                      <h3 className="mt-1 text-sm font-bold text-gray-900 dark:text-white">
                        {selectedComponent.name}
                      </h3>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() =>
                        handleDeleteComponent(selectedComponent.id, selectedComponent.name)
                      }
                      className="text-red-500 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/30"
                      title="Delete Component"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-3">
                    {/* Title / Label / Text */}
                    {(selectedComponent.props.title !== undefined ||
                      selectedComponent.props.label !== undefined ||
                      selectedComponent.props.text !== undefined) && (
                      <div>
                        <label className="mb-1 block text-xs font-semibold text-gray-600 dark:text-gray-300">
                          {selectedComponent.props.title !== undefined
                            ? 'Title'
                            : selectedComponent.props.label !== undefined
                              ? 'Label'
                              : 'Text Content'}
                        </label>
                        <input
                          type="text"
                          value={
                            selectedComponent.props.title ??
                            selectedComponent.props.label ??
                            selectedComponent.props.text ??
                            ''
                          }
                          onChange={(e) => {
                            const val = e.target.value;
                            if (selectedComponent.props.title !== undefined)
                              updateComponent(selectedComponent.id, { title: val });
                            else if (selectedComponent.props.label !== undefined)
                              updateComponent(selectedComponent.id, { label: val });
                            else updateComponent(selectedComponent.id, { text: val });
                          }}
                          className="w-full rounded-lg border border-gray-200 bg-white p-2 text-xs outline-none focus:border-indigo-500 dark:border-slate-700 dark:bg-slate-800"
                        />
                      </div>
                    )}

                    {/* Subtitle / Placeholder */}
                    {(selectedComponent.props.subtitle !== undefined ||
                      selectedComponent.props.placeholder !== undefined) && (
                      <div>
                        <label className="mb-1 block text-xs font-semibold text-gray-600 dark:text-gray-300">
                          {selectedComponent.props.subtitle !== undefined
                            ? 'Subtitle'
                            : 'Placeholder'}
                        </label>
                        <input
                          type="text"
                          value={
                            selectedComponent.props.subtitle ??
                            selectedComponent.props.placeholder ??
                            ''
                          }
                          onChange={(e) => {
                            const val = e.target.value;
                            if (selectedComponent.props.subtitle !== undefined)
                              updateComponent(selectedComponent.id, { subtitle: val });
                            else updateComponent(selectedComponent.id, { placeholder: val });
                          }}
                          className="w-full rounded-lg border border-gray-200 bg-white p-2 text-xs outline-none focus:border-indigo-500 dark:border-slate-700 dark:bg-slate-800"
                        />
                      </div>
                    )}

                    {/* Stat Value */}
                    {selectedComponent.props.value !== undefined && (
                      <div>
                        <label className="mb-1 block text-xs font-semibold text-gray-600 dark:text-gray-300">
                          Stat Metric Value
                        </label>
                        <input
                          type="text"
                          value={selectedComponent.props.value}
                          onChange={(e) =>
                            updateComponent(selectedComponent.id, { value: e.target.value })
                          }
                          className="w-full rounded-lg border border-gray-200 bg-white p-2 text-xs outline-none focus:border-indigo-500 dark:border-slate-700 dark:bg-slate-800"
                        />
                      </div>
                    )}

                    {/* Routing Action Trigger */}
                    {(selectedComponent.type === 'button' ||
                      selectedComponent.type === 'card' ||
                      selectedComponent.type === 'floating_action_button') && (
                      <div className="rounded-xl border border-indigo-100 bg-indigo-50/50 p-3 dark:border-indigo-900/40 dark:bg-indigo-950/20">
                        <label className="mb-1 flex items-center gap-1.5 text-xs font-bold text-indigo-900 dark:text-indigo-200">
                          <RouteIcon className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
                          On Tap / Click Routing Action
                        </label>
                        <p className="mb-2 text-[10px] text-gray-500 dark:text-gray-400">
                          Defines screen navigation when tapped
                        </p>

                        <div className="space-y-2">
                          <select
                            value={selectedComponent.props.actionType || 'none'}
                            onChange={(e) => {
                              const val = e.target.value as any;
                              updateComponent(selectedComponent.id, {
                                actionType: val,
                                targetRoute: val === 'navigate' ? screens[0]?.route : undefined,
                              });
                            }}
                            className="w-full rounded-lg border border-gray-200 bg-white p-1.5 text-xs font-medium outline-none dark:border-slate-700 dark:bg-slate-800"
                          >
                            <option value="none">No Action</option>
                            <option value="navigate">Navigate to Screen →</option>
                            <option value="snackbar">Show SnackBar</option>
                            <option value="dialog">Open Dialog</option>
                          </select>

                          {selectedComponent.props.actionType === 'navigate' && (
                            <div>
                              <label className="mb-1 block text-[10px] font-semibold text-gray-500">
                                Target Route:
                              </label>
                              <select
                                value={selectedComponent.props.targetRoute || '/'}
                                onChange={(e) =>
                                  updateComponent(selectedComponent.id, {
                                    targetRoute: e.target.value,
                                  })
                                }
                                className="w-full rounded-lg border border-indigo-300 bg-white p-1.5 text-xs font-semibold text-indigo-700 outline-none dark:border-indigo-600 dark:bg-slate-800 dark:text-indigo-300"
                              >
                                {screens.map((sc) => (
                                  <option key={sc.id} value={sc.route}>
                                    {sc.name} ({sc.route}) {sc.isInitial ? '★ Home' : ''}
                                  </option>
                                ))}
                              </select>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Border Radius */}
                    {selectedComponent.props.borderRadius !== undefined && (
                      <div>
                        <div className="flex items-center justify-between text-xs font-semibold text-gray-600 dark:text-gray-300">
                          <span>Border Radius</span>
                          <span>{selectedComponent.props.borderRadius}px</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="32"
                          step="2"
                          value={selectedComponent.props.borderRadius}
                          onChange={(e) =>
                            updateComponent(selectedComponent.id, {
                              borderRadius: Number(e.target.value),
                            })
                          }
                          className="mt-1 w-full"
                        />
                      </div>
                    )}

                    {/* Delete Widget */}
                    <div className="pt-2">
                      <Button
                        type="button"
                        variant="danger"
                        size="sm"
                        onClick={() =>
                          handleDeleteComponent(selectedComponent.id, selectedComponent.name)
                        }
                        className="w-full gap-2 text-xs"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Delete Widget
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-12 text-center text-xs text-gray-400">
                  <MousePointerClick className="mx-auto mb-2 h-6 w-6 opacity-40" />
                  Select a widget to edit its properties, route action, or style.
                </div>
              )
            ) : activeTab === 'tree' ? (
              /* Component Tree with Up/Down and Delete */
              <div className="space-y-2">
                <p className="text-[11px] text-gray-500 dark:text-gray-400">
                  Widgets in <strong>{activeScreen?.name}</strong>:
                </p>
                {activeComponents.map((comp, idx) => {
                  const isSelected = comp.id === selectedComponentId;
                  return (
                    <div
                      key={comp.id}
                      onClick={() => {
                        setSelectedComponentId(comp.id);
                        setActiveTab('inspector');
                      }}
                      className={`flex cursor-pointer items-center justify-between rounded-xl border p-2.5 transition ${
                        isSelected
                          ? 'border-indigo-500 bg-indigo-50/50 dark:border-indigo-400 dark:bg-indigo-950/30'
                          : 'border-gray-200 bg-white hover:border-gray-300 dark:border-slate-800 dark:bg-slate-900'
                      }`}
                    >
                      <div className="flex min-w-0 items-center gap-2">
                        <span className="flex h-5 w-5 items-center justify-center rounded bg-gray-100 text-[10px] font-bold text-gray-500 dark:bg-slate-800">
                          {idx + 1}
                        </span>
                        <div className="min-w-0">
                          <p className="truncate text-xs font-semibold text-gray-900 dark:text-white">
                            {comp.name}
                          </p>
                          <p className="font-mono text-[9px] uppercase text-gray-400">
                            {comp.type} {comp.props.targetRoute ? `→ ${comp.props.targetRoute}` : ''}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => reorderComponents(idx, idx - 1)}
                          className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-700 disabled:opacity-30 dark:hover:bg-slate-800"
                          title="Move up"
                        >
                          <ChevronUp className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === activeComponents.length - 1}
                          onClick={() => reorderComponents(idx, idx + 1)}
                          className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-700 disabled:opacity-30 dark:hover:bg-slate-800"
                          title="Move down"
                        >
                          <ChevronDown className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteComponent(comp.id, comp.name)}
                          className="rounded p-1 text-red-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/30"
                          title="Delete widget"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* Routes & Screen Table */
              <div className="space-y-4">
                <div className="rounded-xl border border-gray-200 bg-gray-50 p-3 dark:border-slate-800 dark:bg-slate-900/40">
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white">
                    Screen Routing Table
                  </h4>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">
                    Defines all named routes and entry point.
                  </p>
                </div>

                <div className="space-y-2">
                  {screens.map((sc) => (
                    <div
                      key={sc.id}
                      className={`rounded-xl border p-3 transition ${
                        sc.id === activeScreenId
                          ? 'border-indigo-500 bg-indigo-50/40 dark:border-indigo-500 dark:bg-indigo-950/30'
                          : 'border-gray-200 bg-white dark:border-slate-800 dark:bg-slate-900'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {sc.isInitial ? (
                            <span className="flex items-center gap-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                              <Star className="h-3 w-3 fill-amber-400" />
                              Initial Screen
                            </span>
                          ) : (
                            <span className="rounded bg-gray-100 px-1.5 py-0.5 text-[10px] font-medium text-gray-600 dark:bg-slate-800 dark:text-gray-400">
                              Route
                            </span>
                          )}
                          <span className="text-xs font-bold">{sc.name}</span>
                        </div>
                        <code className="text-xs font-mono text-indigo-600 dark:text-indigo-400">
                          {sc.route}
                        </code>
                      </div>

                      <div className="mt-3 flex items-center justify-between border-t border-gray-100 pt-2 text-[11px] dark:border-slate-800">
                        <span className="text-gray-400">{sc.components.length} components</span>
                        <div className="flex items-center gap-2">
                          {!sc.isInitial && (
                            <button
                              type="button"
                              onClick={() => {
                                setInitialScreen(sc.id);
                                toast.success(`"${sc.name}" is now the Initial Starting Screen`);
                              }}
                              className="font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
                            >
                              Make Initial
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => selectScreen(sc.id)}
                            className="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white"
                          >
                            Open →
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAddScreenModal(true)}
                  className="w-full gap-2 text-xs"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add Another Screen
                </Button>
              </div>
            )}
          </div>
        </aside>
      </div>

      {/* ---------------------------------------------------------------- */}
      {/* Modal: Export Full Flutter Dart Code */}
      {/* ---------------------------------------------------------------- */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
          <div className="flex h-[80vh] w-full max-w-3xl flex-col rounded-2xl border border-gray-200 bg-slate-900 text-white shadow-2xl dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-800 p-4">
              <div className="flex items-center gap-2">
                <FileCode className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-bold">
                  Flutter Dart Code — {activeScreen?.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowExportModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-4">
              <pre className="rounded-xl bg-slate-950 p-4 font-mono text-xs text-indigo-200 leading-relaxed overflow-x-auto">
                <code>{generatedDartCode}</code>
              </pre>
            </div>

            <div className="flex items-center justify-between border-t border-slate-800 p-4">
              <span className="text-xs text-slate-400">
                Ready to paste into your Flutter project
              </span>
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleCopyDart}
                  className="gap-1.5 text-xs text-slate-200"
                >
                  {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  {copiedCode ? 'Copied!' : 'Copy Code'}
                </Button>
                <Button
                  type="button"
                  variant="primary"
                  size="sm"
                  onClick={handleDownloadDart}
                  className="gap-1.5 text-xs"
                >
                  <Download className="h-3.5 w-3.5" />
                  Download .dart
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* Modal: Add New Screen with Route */}
      {/* ---------------------------------------------------------------- */}
      {showAddScreenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <RouteIcon className="h-5 w-5 text-indigo-600" />
                <h3 className="text-base font-bold">Add New Screen & Route</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddScreenModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateNewScreen} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  Screen Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Settings Screen, Product Details"
                  value={newScreenName}
                  onChange={(e) => {
                    setNewScreenName(e.target.value);
                    if (!newScreenRoute || newScreenRoute.startsWith('/')) {
                      setNewScreenRoute(
                        `/${e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`
                      );
                    }
                  }}
                  className="mt-1 w-full rounded-xl border border-gray-200 bg-white p-2.5 text-xs outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  Route Path
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. /settings, /details"
                  value={newScreenRoute}
                  onChange={(e) => setNewScreenRoute(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-gray-200 bg-white p-2.5 font-mono text-xs outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-800"
                />
                <p className="mt-1 text-[11px] text-gray-400">
                  Route used for: <code>Navigator.pushNamed(context, route)</code>
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAddScreenModal(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  Create Screen
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
