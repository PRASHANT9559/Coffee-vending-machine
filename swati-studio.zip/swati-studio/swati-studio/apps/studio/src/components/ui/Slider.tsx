'use client';

import { cn } from '@/lib/utils';

export interface SliderProps {
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  id?: string;
}

/** Range slider with a filled track. */
export function Slider({ value, min, max, step = 1, onChange, id }: SliderProps) {
  const percent = ((value - min) / (max - min)) * 100;
  return (
    <div className="flex items-center gap-4">
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="h-2 w-full cursor-pointer appearance-none rounded-full bg-gray-200 accent-indigo-600 dark:bg-slate-700"
        style={{
          background: `linear-gradient(to right, #6366f1 0%, #6366f1 ${percent}%, transparent ${percent}%)`,
        }}
      />
      <span
        className={cn(
          'w-14 shrink-0 rounded-lg bg-gray-100 px-2 py-1 text-center font-mono text-xs',
          'text-gray-600 dark:bg-slate-800 dark:text-gray-300',
        )}
      >
        {value}
      </span>
    </div>
  );
}
