'use client';

import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

export interface FieldProps {
  label: string;
  htmlFor?: string;
  help?: string;
  error?: string;
  required?: boolean;
  children: ReactNode;
  className?: string;
}

/** Label + help text + control. Used by every generated form control. */
export function Field({ label, htmlFor, help, error, required, children, className }: FieldProps) {
  return (
    <div className={cn('space-y-2', className)}>
      <div className="flex items-center justify-between gap-3">
        <label htmlFor={htmlFor} className="text-sm font-medium text-gray-800 dark:text-gray-200">
          {label}
          {required ? <span className="ml-1 text-red-500">*</span> : null}
        </label>
      </div>
      {children}
      {error ? (
        <p className="text-xs text-red-500">{error}</p>
      ) : help ? (
        <p className="text-xs text-gray-500 dark:text-gray-400">{help}</p>
      ) : null}
    </div>
  );
}

export const inputClass =
  'w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm outline-none transition placeholder:text-gray-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-gray-100';
