'use client';

import { cn } from '@/lib/utils';

export interface SwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  description?: string;
  id?: string;
}

/** Accessible toggle switch. */
export function Switch({ checked, onChange, label, description, id }: SwitchProps) {
  return (
    <div className="flex items-start gap-3">
      <button
        type="button"
        id={id}
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition',
          checked ? 'bg-indigo-600' : 'bg-gray-300 dark:bg-slate-700',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all',
            checked ? 'left-5.5' : 'left-0.5',
          )}
        />
      </button>
      {label ? (
        <span className="min-w-0">
          <span className="block text-sm font-medium text-gray-800 dark:text-gray-200">{label}</span>
          {description ? (
            <span className="mt-0.5 block text-xs text-gray-500 dark:text-gray-400">{description}</span>
          ) : null}
        </span>
      ) : null}
    </div>
  );
}
