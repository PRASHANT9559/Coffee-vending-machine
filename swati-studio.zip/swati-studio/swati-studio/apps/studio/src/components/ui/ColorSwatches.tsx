'use client';

import type { OptionDef } from '@swati/schema';
import { cn } from '@/lib/utils';

export interface ColorSwatchesProps {
  options: OptionDef[];
  value: string;
  onChange: (id: string) => void;
  customColor: string;
  onCustomColor: (hex: string) => void;
}

/** Colour swatch picker used for the theme colour field. */
export function ColorSwatches({
  options,
  value,
  onChange,
  customColor,
  onCustomColor,
}: ColorSwatchesProps) {
  const swatches = options.filter((option) => option.id !== 'custom');
  const isCustom = value === 'custom';

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        {swatches.map((option) => {
          const hex = (option.data?.hex as string) ?? option.accent ?? '#6366f1';
          const selected = value === option.id;
          return (
            <button
              key={option.id}
              type="button"
              title={option.name}
              aria-label={option.name}
              aria-pressed={selected}
              onClick={() => onChange(option.id)}
              className={cn('color-swatch h-10 w-10 rounded-xl', selected && 'selected')}
              style={{ backgroundColor: hex, color: hex }}
            />
          );
        })}
      </div>

      <div className="flex items-center gap-3">
        <span className="text-xs text-gray-500">Custom:</span>
        <input
          type="color"
          value={customColor}
          onChange={(event) => {
            onCustomColor(event.target.value);
            onChange('custom');
          }}
          className="h-8 w-10 cursor-pointer rounded-lg border-0 bg-transparent p-0"
          aria-label="Custom colour"
        />
        <span className="font-mono text-xs text-gray-500">{customColor}</span>
        {isCustom ? (
          <span className="rounded-md bg-indigo-50 px-2 py-0.5 text-[10px] font-semibold text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400">
            active
          </span>
        ) : null}
      </div>
    </div>
  );
}
