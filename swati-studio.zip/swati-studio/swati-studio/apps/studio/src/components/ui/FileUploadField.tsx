'use client';

import { useId, useRef, useState } from 'react';
import type { UploadedDatabaseFile } from '@swati/schema';
import { Database, FileCheck, FileUp, HardDrive, Trash2 } from 'lucide-react';

interface FileUploadFieldProps {
  value: UploadedDatabaseFile | null | undefined;
  onChange: (file: UploadedDatabaseFile | null) => void;
  accept?: string;
  label?: string;
  help?: string;
  error?: string;
}

export function FileUploadField({
  value,
  onChange,
  accept = '.db,.sqlite,.sqlite3,.json,.hive,.isar',
  label = 'Import Existing Database File (Optional)',
  help,
  error,
}: FileUploadFieldProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const inputId = useId();

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    const extension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = typeof reader.result === 'string' ? reader.result.split(',')[1] : '';
      const uploaded: UploadedDatabaseFile = {
        name: file.name,
        size: file.size,
        extension,
        lastModified: file.lastModified,
        contentBase64: base64,
      };
      onChange(uploaded);
    };
    reader.readAsDataURL(file);
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  };

  return (
    <div className="space-y-3">
      {label && (
        <label htmlFor={inputId} className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          {label}
        </label>
      )}

      {value ? (
        /* Display selected uploaded file */
        <div className="flex items-center justify-between rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-xs">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-gray-900 dark:text-white">{value.name}</span>
                <span className="rounded-md bg-emerald-200/80 px-2 py-0.5 text-[10px] font-mono font-bold uppercase text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">
                  {value.extension.replace('.', '')}
                </span>
              </div>
              <p className="mt-0.5 text-xs text-emerald-700 dark:text-emerald-300">
                {formatBytes(value.size)} • Will be placed into <code>assets/db/{value.name}</code>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onChange(null)}
              className="inline-flex items-center gap-1 rounded-lg border border-gray-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-rose-600 shadow-2xs hover:bg-rose-50 dark:border-slate-700 dark:bg-slate-800 dark:text-rose-400 dark:hover:bg-slate-700"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Remove
            </button>
          </div>
        </div>
      ) : (
        /* Drag and Drop Zone */
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            handleFiles(e.dataTransfer.files);
          }}
          onClick={() => fileInputRef.current?.click()}
          className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-6 text-center transition ${
            isDragging
              ? 'border-indigo-500 bg-indigo-50/50 dark:border-indigo-400 dark:bg-indigo-950/30'
              : 'border-gray-300 bg-gray-50/60 hover:border-indigo-400 hover:bg-white dark:border-slate-700 dark:bg-slate-900/40 dark:hover:border-slate-600'
          }`}
        >
          <input
            id={inputId}
            ref={fileInputRef}
            type="file"
            accept={accept}
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />

          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-600 dark:bg-indigo-950/80 dark:text-indigo-400">
            <FileUp className="h-6 w-6" />
          </div>

          <h4 className="text-sm font-semibold text-gray-900 dark:text-white">
            Upload Database File (Optional)
          </h4>
          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
            Drag & drop your file here, or click to browse
          </p>
          <p className="mt-2 font-mono text-[11px] text-gray-400 dark:text-gray-500">
            Supported: .db, .sqlite, .json, .hive, .isar
          </p>
        </div>
      )}

      {help && <p className="text-xs text-gray-500 dark:text-gray-400">{help}</p>}
      {error && <p className="text-xs font-semibold text-rose-500">{error}</p>}
    </div>
  );
}
