'use client';

import { Check } from 'lucide-react';
import type { OptionDef } from '@swati/schema';
import { cn } from '@/lib/utils';

export interface ChipMultiSelectProps {
  options: OptionDef[];
  value: string[];
  onToggle: (id: string) => void;
}

/** Compact chip based multi select. */
export function ChipMultiSelect({ options, value, onToggle }: ChipMultiSelectProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((option) => {
        const selected = value.includes(option.id);
        return (
          <button
            key={option.id}
            type="button"
            aria-pressed={selected}
            onClick={() => onToggle(option.id)}
            className={cn(
              'inline-flex items-center gap-1.5 rounded-xl border-2 px-3.5 py-2 text-sm font-medium transition',
              selected
                ? 'border-indigo-500 bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400'
                : 'border-gray-200 text-gray-600 hover:border-gray-300 dark:border-slate-700 dark:text-gray-400 dark:hover:border-slate-600',
            )}
          >
            {selected ? <Check className="h-3.5 w-3.5" /> : null}
            {option.name}
          </button>
        );
      })}
    </div>
  );
}
