'use client';

import type { FieldDef, FieldValue, NavigationItem, UploadedDatabaseFile } from '@swati/schema';
import { ChipMultiSelect } from './ChipMultiSelect';
import { ColorSwatches } from './ColorSwatches';
import { Field, inputClass } from './Field';
import { FileUploadField } from './FileUploadField';
import { NavigationButtonsField } from './NavigationButtonsField';
import { OptionCards } from './OptionCards';
import { Select } from './Select';
import { Slider } from './Slider';
import { Switch } from './Switch';

export interface SchemaFieldProps {
  field: FieldDef;
  value: FieldValue;
  customColor: string;
  error?: string;
  navStyle?: string;
  onChange: (id: string, value: FieldValue) => void;
  onToggle: (id: string, value: string) => void;
}

/**
 * Renders any field from the schema.
 *
 * This is the component that makes the app "config driven": the wizard
 * never knows what a "backend" is, it only knows how to draw a field
 * definition.
 */
export function SchemaField({
  field,
  value,
  customColor,
  error,
  navStyle,
  onChange,
  onToggle,
}: SchemaFieldProps) {
  const options = field.options ?? [];
  const fieldId = `field-${field.id}`;

  switch (field.kind) {
    case 'text':
      return (
        <Field label={field.label} htmlFor={fieldId} help={field.help} error={error} required={field.required}>
          <input
            id={fieldId}
            type="text"
            value={String(value ?? '')}
            placeholder={field.placeholder}
            onChange={(event) => onChange(field.id, event.target.value)}
            className={inputClass}
          />
        </Field>
      );

    case 'textarea':
      return (
        <Field label={field.label} htmlFor={fieldId} help={field.help} error={error} required={field.required}>
          <textarea
            id={fieldId}
            rows={3}
            value={String(value ?? '')}
            placeholder={field.placeholder}
            onChange={(event) => onChange(field.id, event.target.value)}
            className={`${inputClass} resize-none`}
          />
        </Field>
      );

    case 'number':
      return (
        <Field label={field.label} htmlFor={fieldId} help={field.help} error={error} required={field.required}>
          <input
            id={fieldId}
            type="number"
            value={Number(value ?? 0)}
            min={field.min}
            max={field.max}
            step={field.step ?? 1}
            onChange={(event) => onChange(field.id, Number(event.target.value))}
            className={`${inputClass} font-mono`}
          />
        </Field>
      );

    case 'range':
      return (
        <Field label={field.label} htmlFor={fieldId} help={field.help} error={error} required={field.required}>
          <div className="flex items-center gap-3">
            <Slider
              id={fieldId}
              value={Number(value ?? 0)}
              min={field.min ?? 0}
              max={field.max ?? 100}
              step={field.step ?? 1}
              onChange={(next) => onChange(field.id, next)}
            />
            {field.suffix ? (
              <span className="font-mono text-xs text-gray-500">{field.suffix}</span>
            ) : null}
          </div>
        </Field>
      );

    case 'toggle':
      return (
        <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
          <Switch
            id={fieldId}
            checked={Boolean(value)}
            label={field.label}
            description={field.help}
            onChange={(next) => onChange(field.id, next)}
          />
        </div>
      );

    case 'color':
      return (
        <Field label={field.label} help={field.help} error={error}>
          <input
            id={fieldId}
            type="color"
            value={String(value ?? '#6366f1')}
            onChange={(event) => onChange(field.id, event.target.value)}
            className="h-10 w-16 cursor-pointer rounded-lg border-0 bg-transparent p-0"
          />
        </Field>
      );

    case 'select': {
      if (field.presentation === 'swatches') {
        return (
          <Field label={field.label} help={field.help} error={error} required={field.required}>
            <ColorSwatches
              options={options}
              value={String(value ?? '')}
              customColor={customColor}
              onChange={(next) => onChange(field.id, next)}
              onCustomColor={(hex) => onChange('frontend.customColor', hex)}
            />
          </Field>
        );
      }

      if (field.presentation === 'cards') {
        return (
          <Field label={field.label} help={field.help} error={error} required={field.required}>
            <OptionCards
              options={options}
              value={value ? [String(value)] : []}
              onChange={(next) => onChange(field.id, next)}
            />
          </Field>
        );
      }

      return (
        <Field label={field.label} help={field.help} error={error} required={field.required}>
          <Select
            id={fieldId}
            value={value ? String(value) : null}
            options={options}
            showAccent
            onChange={(next) => onChange(field.id, next)}
          />
        </Field>
      );
    }

    case 'multiselect': {
      const selected = Array.isArray(value) ? (value as string[]) : [];

      if (field.presentation === 'chips') {
        return (
          <Field label={field.label} help={field.help} error={error} required={field.required}>
            <ChipMultiSelect
              options={options}
              value={selected}
              onToggle={(next) => onToggle(field.id, next)}
            />
          </Field>
        );
      }

      if (field.presentation === 'cards') {
        return (
          <Field label={field.label} help={field.help} error={error} required={field.required}>
            <OptionCards
              options={options}
              value={selected}
              multiple
              onChange={(next) => onToggle(field.id, next)}
            />
          </Field>
        );
      }

      return (
        <Field label={field.label} help={field.help} error={error} required={field.required}>
          <Select
            id={fieldId}
            value={selected[0] ?? null}
            options={options}
            onChange={(next) => onToggle(field.id, next)}
          />
        </Field>
      );
    }

    case 'list': {
      return (
        <NavigationButtonsField
          value={value as NavigationItem[]}
          onChange={(items) => onChange(field.id, items)}
          error={error}
          navStyle={navStyle}
        />
      );
    }

    case 'file': {
      return (
        <FileUploadField
          value={value as UploadedDatabaseFile | null}
          onChange={(file) => onChange(field.id, file)}
          accept={field.accept}
          label={field.label}
          help={field.help}
          error={error}
        />
      );
    }

    default:
      return null;
  }
}
