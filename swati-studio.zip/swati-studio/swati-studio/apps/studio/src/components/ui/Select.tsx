'use client';

import { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import type { OptionDef } from '@swati/schema';
import { cn } from '@/lib/utils';

export interface SelectProps {
  value: string | null;
  options: OptionDef[];
  onChange: (id: string) => void;
  placeholder?: string;
  searchable?: boolean;
  id?: string;
  className?: string;
  disabled?: boolean;
  /** Show a small coloured dot next to the label. */
  showAccent?: boolean;
}

/**
 * Searchable dropdown.
 *
 * This is the component that replaced the "wall of cards" in the original
 * prototype: pick a backend, a database, a font… from a compact dropdown
 * and the matching extra fields appear automatically.
 */
export function Select({
  value,
  options,
  onChange,
  placeholder = 'Select an option',
  searchable = true,
  id,
  className,
  disabled,
  showAccent,
}: SelectProps) {
  const listId = useId();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [highlight, setHighlight] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = options.find((option) => option.id === value) ?? null;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter((option) => {
      const haystack = [option.name, option.desc ?? '', ...(option.tags ?? [])].join(' ').toLowerCase();
      return haystack.includes(q);
    });
  }, [options, query]);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent) => {
      if (!containerRef.current?.contains(event.target as Node)) {
        setOpen(false);
        setQuery('');
      }
    };
    document.addEventListener('mousedown', onPointerDown);
    return () => document.removeEventListener('mousedown', onPointerDown);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    setHighlight(Math.max(0, options.findIndex((o) => o.id === value)));
    const timer = window.setTimeout(() => inputRef.current?.focus(), 10);
    return () => window.clearTimeout(timer);
    // `options`/`value` are intentionally not dependencies: the list is
    // rebuilt on every render and re-running this would reset the
    // highlighted row while the user types.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const commit = useCallback(
    (optionId: string) => {
      onChange(optionId);
      setOpen(false);
      setQuery('');
    },
    [onChange],
  );

  const onKeyDown = (event: React.KeyboardEvent) => {
    if (!open) {
      if (event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowDown') {
        event.preventDefault();
        setOpen(true);
      }
      return;
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setHighlight((h) => Math.min(h + 1, filtered.length - 1));
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (event.key === 'Enter') {
      event.preventDefault();
      const option = filtered[highlight];
      if (option) commit(option.id);
    } else if (event.key === 'Escape') {
      event.preventDefault();
      setOpen(false);
      setQuery('');
    } else if (event.key === 'Home') {
      event.preventDefault();
      setHighlight(0);
    } else if (event.key === 'End') {
      event.preventDefault();
      setHighlight(filtered.length - 1);
    }
  };

  return (
    <div ref={containerRef} className={cn('relative', className)}>
      <button
        type="button"
        id={id}
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        onKeyDown={onKeyDown}
        role="combobox"
        aria-expanded={open}
        aria-controls={listId}
        aria-haspopup="listbox"
        className={cn(
          'flex w-full items-center justify-between gap-2 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-left text-sm transition',
          'focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none',
          'disabled:cursor-not-allowed disabled:opacity-50',
          'dark:border-slate-700 dark:bg-slate-800 dark:text-gray-100',
        )}
      >
        <span className="flex min-w-0 items-center gap-2">
          {showAccent && selected?.accent ? (
            <span
              className="h-2.5 w-2.5 shrink-0 rounded-full"
              style={{ backgroundColor: selected.accent }}
            />
          ) : null}
          <span className={cn('truncate', !selected && 'text-gray-400')}>
            {selected ? selected.name : placeholder}
          </span>
        </span>
        <ChevronDown
          className={cn('h-4 w-4 shrink-0 text-gray-400 transition', open && 'rotate-180')}
        />
      </button>

      {open ? (
        <div className="absolute z-50 mt-2 w-full min-w-[260px] overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl dark:border-slate-700 dark:bg-slate-900">
          {searchable ? (
            <div className="flex items-center gap-2 border-b border-gray-100 px-3 py-2 dark:border-slate-800">
              <Search className="h-4 w-4 shrink-0 text-gray-400" />
              <input
                ref={inputRef}
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setHighlight(0);
                }}
                onKeyDown={onKeyDown}
                placeholder="Search…"
                className="w-full bg-transparent text-sm outline-none placeholder:text-gray-400"
              />
              {query ? (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  className="rounded p-0.5 text-gray-400 transition hover:text-gray-600"
                  aria-label="Clear search"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              ) : null}
            </div>
          ) : null}

          <ul id={listId} role="listbox" className="max-h-64 overflow-y-auto py-1">
            {filtered.length === 0 ? (
              <li className="px-4 py-6 text-center text-sm text-gray-400">No matches</li>
            ) : (
              filtered.map((option, index) => {
                const isSelected = option.id === value;
                return (
                  <li key={option.id}>
                    <button
                      type="button"
                      role="option"
                      aria-selected={isSelected}
                      onMouseEnter={() => setHighlight(index)}
                      onClick={() => commit(option.id)}
                      className={cn(
                        'flex w-full items-start gap-2 px-3 py-2 text-left transition',
                        index === highlight ? 'bg-gray-100 dark:bg-slate-800' : 'hover:bg-gray-50 dark:hover:bg-slate-800/60',
                      )}
                    >
                      <Check
                        className={cn(
                          'mt-0.5 h-4 w-4 shrink-0 text-indigo-600',
                          isSelected ? 'opacity-100' : 'opacity-0',
                        )}
                      />
                      <span className="min-w-0">
                        <span className="flex items-center gap-2">
                          {showAccent && option.accent ? (
                            <span
                              className="h-2 w-2 rounded-full"
                              style={{ backgroundColor: option.accent }}
                            />
                          ) : null}
                          <span className="text-sm font-medium text-gray-800 dark:text-gray-100">
                            {option.name}
                          </span>
                        </span>
                        {option.desc ? (
                          <span className="mt-0.5 block text-xs text-gray-500 dark:text-gray-400">
                            {option.desc}
                          </span>
                        ) : null}
                      </span>
                    </button>
                  </li>
                );
              })
            )}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
