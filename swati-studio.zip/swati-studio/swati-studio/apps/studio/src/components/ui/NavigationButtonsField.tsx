'use client';

import { useId, useState } from 'react';
import type { NavigationItem } from '@swati/schema';
import {
  Bell,
  Compass,
  GripVertical,
  Heart,
  Home,
  MessageCircle,
  Plus,
  Search,
  Settings,
  ShoppingCart,
  Trash2,
  User,
  Sliders,
  Sparkles,
} from 'lucide-react';

interface NavigationButtonsFieldProps {
  value: NavigationItem[] | null | undefined;
  onChange: (items: NavigationItem[]) => void;
  error?: string;
  navStyle?: string;
}

const COMMON_SUGGESTIONS = [
  { name: 'Home', icon: 'Home' },
  { name: 'Search', icon: 'Search' },
  { name: 'Favorites', icon: 'Heart' },
  { name: 'Cart', icon: 'ShoppingCart' },
  { name: 'Notifications', icon: 'Bell' },
  { name: 'Profile', icon: 'User' },
  { name: 'Settings', icon: 'Settings' },
];

export function NavigationButtonsField({
  value,
  onChange,
  error,
  navStyle = 'bottom_nav',
}: NavigationButtonsFieldProps) {
  const inputId = useId();
  const items = Array.isArray(value) ? value : [];
  const [inputName, setInputName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Home');

  const guessIcon = (name: string): string => {
    const lower = name.toLowerCase().trim();
    if (lower.includes('home') || lower.includes('main')) return 'Home';
    if (lower.includes('search') || lower.includes('find')) return 'Search';
    if (lower.includes('fav') || lower.includes('like') || lower.includes('wish')) return 'Heart';
    if (lower.includes('cart') || lower.includes('shop') || lower.includes('bag')) return 'ShoppingCart';
    if (lower.includes('bell') || lower.includes('alert') || lower.includes('notif')) return 'Bell';
    if (lower.includes('user') || lower.includes('profile') || lower.includes('account') || lower.includes('me')) return 'User';
    if (lower.includes('setting') || lower.includes('config') || lower.includes('pref')) return 'Settings';
    if (lower.includes('chat') || lower.includes('msg') || lower.includes('message')) return 'MessageCircle';
    if (lower.includes('explore') || lower.includes('discover')) return 'Compass';
    return 'Sparkles';
  };

  const handleNameChange = (val: string) => {
    setInputName(val);
    setSelectedIcon(guessIcon(val));
  };

  const handleAddButton = () => {
    const trimmed = inputName.trim();
    if (!trimmed) return;

    const slug = trimmed
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '');

    const newItem: NavigationItem = {
      id: `nav-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: trimmed,
      title: trimmed,
      route: `/${slug}`,
      icon: selectedIcon || guessIcon(trimmed),
    };

    onChange([...items, newItem]);
    setInputName('');
    setSelectedIcon('Home');
  };

  const handleRemove = (id: string) => {
    onChange(items.filter((it) => it.id !== id));
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= items.length) return;
    const copy = [...items];
    const [moved] = copy.splice(index, 1);
    copy.splice(targetIndex, 0, moved);
    onChange(copy);
  };

  const isBottomBar = navStyle !== 'drawer' && navStyle !== 'rail';
  const hasExceededBottomNav = isBottomBar && items.length > 5;

  return (
    <div className="space-y-4">
      {/* Quick Add Input Bar */}
      <div className="rounded-2xl border border-gray-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900/60">
        <label htmlFor={inputId} className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
          Add Navigation Button (Screen Name)
        </label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            id={inputId}
            type="text"
            value={inputName}
            placeholder="e.g. Home, Orders, Dashboard, Profile..."
            onChange={(e) => handleNameChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleAddButton();
              }
            }}
            className="flex-1 rounded-xl border border-gray-300 bg-gray-50/50 px-3.5 py-2 text-sm text-gray-900 transition focus:border-indigo-500 focus:bg-white focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />

          <select
            value={selectedIcon}
            onChange={(e) => setSelectedIcon(e.target.value)}
            className="rounded-xl border border-gray-300 bg-gray-50/50 px-3 py-2 text-sm text-gray-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            aria-label="Navigation icon"
          >
            <option value="Home">🏠 Home</option>
            <option value="Search">🔍 Search</option>
            <option value="Heart">❤️ Heart</option>
            <option value="ShoppingCart">🛒 Cart</option>
            <option value="Bell">🔔 Bell</option>
            <option value="User">👤 User</option>
            <option value="Settings">⚙️ Settings</option>
            <option value="MessageCircle">💬 Chat</option>
            <option value="Compass">🧭 Compass</option>
            <option value="Sliders">🎚️ Sliders</option>
            <option value="Sparkles">✨ Sparkles</option>
          </select>

          <button
            type="button"
            onClick={handleAddButton}
            disabled={!inputName.trim()}
            className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-500 disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            Add Button
          </button>
        </div>

        {/* Suggestion Chips */}
        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-medium text-gray-400">Suggestions:</span>
          {COMMON_SUGGESTIONS.map((sug) => {
            const alreadyExists = items.some((it) => it.name.toLowerCase() === sug.name.toLowerCase());
            return (
              <button
                key={sug.name}
                type="button"
                disabled={alreadyExists}
                onClick={() => {
                  const slug = sug.name.toLowerCase();
                  onChange([
                    ...items,
                    {
                      id: `nav-${Date.now()}-${slug}`,
                      name: sug.name,
                      title: sug.name,
                      route: `/${slug}`,
                      icon: sug.icon,
                    },
                  ]);
                }}
                className={`rounded-full px-2.5 py-0.5 text-xs font-medium transition ${
                  alreadyExists
                    ? 'cursor-not-allowed bg-gray-100 text-gray-400 dark:bg-slate-800 dark:text-gray-500'
                    : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:text-indigo-300 dark:hover:bg-indigo-900/50'
                }`}
              >
                + {sug.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Button Capacity Warning */}
      {hasExceededBottomNav && (
        <div className="rounded-xl border border-amber-300 bg-amber-50/80 p-3 text-xs text-amber-800 dark:border-amber-900/60 dark:bg-amber-950/40 dark:text-amber-300">
          ⚠️ <strong>Note:</strong> Bottom Navigation Bar displays up to 5 items comfortably. You currently have {items.length} buttons. For more than 5 buttons, consider selecting <strong>Side Navigation Drawer</strong> or <strong>Top Tab Bar</strong>.
        </div>
      )}

      {/* List of Configured Navigation Buttons */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
            Active Navigation Screens ({items.length})
          </span>
          <span className="text-[11px] text-gray-400">
            Each button generates a screen with matching title & route
          </span>
        </div>

        {items.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-rose-300 bg-rose-50/50 p-6 text-center dark:border-rose-900/50 dark:bg-rose-950/20">
            <p className="text-sm font-semibold text-rose-600 dark:text-rose-400">
              No navigation buttons added yet
            </p>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Navigation is mandatory — please add at least 2 navigation buttons above.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100 rounded-2xl border border-gray-200 bg-white shadow-xs dark:divide-slate-800 dark:border-slate-800 dark:bg-slate-900">
            {items.map((item, index) => (
              <div
                key={item.id}
                className="flex items-center justify-between gap-3 p-3 transition hover:bg-gray-50/80 dark:hover:bg-slate-800/40"
              >
                <div className="flex items-center gap-3">
                  <div className="flex flex-col gap-0.5">
                    <button
                      type="button"
                      disabled={index === 0}
                      onClick={() => handleMove(index, 'up')}
                      className="text-gray-400 hover:text-gray-600 disabled:opacity-20 dark:hover:text-gray-200"
                      title="Move Up"
                    >
                      ▲
                    </button>
                    <button
                      type="button"
                      disabled={index === items.length - 1}
                      onClick={() => handleMove(index, 'down')}
                      className="text-gray-400 hover:text-gray-600 disabled:opacity-20 dark:hover:text-gray-200"
                      title="Move Down"
                    >
                      ▼
                    </button>
                  </div>
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
                    {renderIcon(item.icon)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-gray-900 dark:text-white">
                        {item.name}
                      </span>
                      {index === 0 && (
                        <span className="rounded-full bg-emerald-100 px-2 py-0.2 text-[10px] font-semibold text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                          Initial Route
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 font-mono text-[11px] text-gray-500 dark:text-gray-400">
                      <span>Screen: {item.name}Screen</span>
                      <span>•</span>
                      <span>Route: {item.route}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleRemove(item.id)}
                    className="rounded-lg p-1.5 text-gray-400 transition hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/50 dark:hover:text-rose-400"
                    title="Remove Button"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {error && <p className="text-xs font-semibold text-rose-500">{error}</p>}
    </div>
  );
}

function renderIcon(iconName: string) {
  switch (iconName) {
    case 'Home':
      return <Home className="h-4 w-4" />;
    case 'Search':
      return <Search className="h-4 w-4" />;
    case 'Heart':
      return <Heart className="h-4 w-4" />;
    case 'ShoppingCart':
      return <ShoppingCart className="h-4 w-4" />;
    case 'Bell':
      return <Bell className="h-4 w-4" />;
    case 'User':
      return <User className="h-4 w-4" />;
    case 'Settings':
      return <Settings className="h-4 w-4" />;
    case 'MessageCircle':
      return <MessageCircle className="h-4 w-4" />;
    case 'Compass':
      return <Compass className="h-4 w-4" />;
    case 'Sliders':
      return <Sliders className="h-4 w-4" />;
    default:
      return <Sparkles className="h-4 w-4" />;
  }
}
