'use client';

import { Check } from 'lucide-react';
import type { OptionDef } from '@swati/schema';
import { cn } from '@/lib/utils';

export interface OptionCardsProps {
  options: OptionDef[];
  /** Selected ids (single or multiple depending on `multiple`). */
  value: string[];
  onChange: (id: string) => void;
  multiple?: boolean;
  columns?: string;
}

/**
 * Card style picker. Rendered from the same catalog data as the
 * dropdown, so the two presentations always stay in sync.
 */
export function OptionCards({
  options,
  value,
  onChange,
  multiple,
  columns = 'sm:grid-cols-2 lg:grid-cols-3',
}: OptionCardsProps) {
  return (
    <div className={cn('grid grid-cols-1 gap-3', columns)}>
      {options.map((option) => {
        const selected = value.includes(option.id);
        return (
          <button
            key={option.id}
            type="button"
            aria-pressed={selected}
            onClick={() => onChange(option.id)}
            className={cn(
              'option-card relative rounded-2xl border-2 border-gray-200 bg-white p-5 text-left dark:border-slate-700 dark:bg-slate-800',
              selected && 'selected',
            )}
          >
            <div className="flex items-start justify-between gap-3">
              <span
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
                style={
                  option.accent
                    ? { backgroundColor: `${option.accent}1f`, color: option.accent }
                    : undefined
                }
              >
                <span className="h-2.5 w-2.5 rounded-full bg-current opacity-70" />
              </span>
              {selected ? (
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-indigo-600">
                  <Check className="h-4 w-4 text-white" />
                </span>
              ) : null}
            </div>
            <span className="mt-3 block text-sm font-semibold text-gray-900 dark:text-gray-100">
              {option.name}
            </span>
            {option.desc ? (
              <span className="mt-1 block text-xs leading-relaxed text-gray-500 dark:text-gray-400">
                {option.desc}
              </span>
            ) : null}
            {option.tags?.length ? (
              <span className="mt-3 flex flex-wrap gap-1.5">
                {option.tags.slice(0, 3).map((tag) => (
                  <span
                    key={tag}
                    className="rounded-md bg-gray-100 px-2 py-0.5 text-[10px] font-medium text-gray-600 dark:bg-slate-700 dark:text-gray-300"
                  >
                    {tag}
                  </span>
                ))}
              </span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}
