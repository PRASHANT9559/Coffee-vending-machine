'use client';

import { useEffect, useId, useRef } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  /** Accessible name for modals rendered without a visible `title`. */
  ariaLabel?: string;
}

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

/**
 * Accessible modal: backdrop, escape contract, focus containment (Tab cycles
 * inside the dialog) and focus restoration to the trigger on close.
 */
export function Modal({ open, onClose, title, description, children, className, size = 'md', ariaLabel }: ModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);
  const focusedForOpenRef = useRef(false);
  const titleId = useId();
  const descriptionId = useId();

  useEffect(() => {
    if (!open) {
      focusedForOpenRef.current = false;
      return;
    }

    // Capture the trigger and move focus in — once per open cycle, so parent
    // re-renders (new onClose identity) never steal focus back from the inputs.
    if (!focusedForOpenRef.current) {
      focusedForOpenRef.current = true;
      previousFocusRef.current =
        document.activeElement instanceof HTMLElement ? document.activeElement : null;
      dialogRef.current?.focus();
    }

    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
        return;
      }
      if (event.key !== 'Tab') return;

      const dialog = dialogRef.current;
      if (!dialog) return;
      const focusables = Array.from(dialog.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR));
      if (focusables.length === 0) {
        event.preventDefault();
        dialog.focus();
        return;
      }

      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      const active = document.activeElement;
      const activeInside = active instanceof Node && dialog.contains(active);

      if (event.shiftKey) {
        if (!activeInside || active === first || active === dialog) {
          event.preventDefault();
          last.focus();
        }
      } else if (!activeInside || active === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener('keydown', onKey);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = previousOverflow;
      previousFocusRef.current?.focus();
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      ref={dialogRef}
      className="fixed inset-0 z-[110] outline-none"
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? titleId : undefined}
      aria-label={!title ? ariaLabel : undefined}
      aria-describedby={description ? descriptionId : undefined}
      tabIndex={-1}
    >
      <div
        className="absolute inset-0 animate-fade-in bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="flex min-h-screen items-center justify-center p-4">
        <div
          className={cn(
            'glass-strong relative w-full animate-scale-in rounded-2xl p-6 shadow-2xl',
            size === 'sm' && 'max-w-md',
            size === 'md' && 'max-w-lg',
            size === 'lg' && 'max-w-xl',
            size === 'xl' && 'max-w-2xl',
            size === '2xl' && 'max-w-3xl',
            className,
          )}
        >
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="absolute top-4 right-4 rounded-lg p-1 transition hover:bg-gray-200 dark:hover:bg-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
          {title ? (
            <h2 id={titleId} className="mb-1 text-lg font-bold">
              {title}
            </h2>
          ) : null}
          {description ? (
            <p id={descriptionId} className="mb-4 text-sm text-gray-500 dark:text-gray-400">
              {description}
            </p>
          ) : null}
          {children}
        </div>
      </div>
    </div>
  );
}
