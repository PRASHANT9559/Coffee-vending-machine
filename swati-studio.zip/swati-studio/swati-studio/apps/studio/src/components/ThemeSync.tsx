'use client';

import { useEffect } from 'react';
import { useStudioStore } from '@/lib/store';

/**
 * Keeps the `dark` class on <html> in sync with the persisted theme
 * preference. The inline script in the layout applies the class before
 * first paint, this component keeps it correct afterwards.
 */
export function ThemeSync() {
  const theme = useStudioStore((s) => s.theme);

  useEffect(() => {
    const root = document.documentElement;
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const dark = theme === 'dark' || (theme === 'system' && prefersDark);
    root.classList.toggle('dark', dark);
  }, [theme]);

  return null;
}
