'use client';

import { useState } from 'react';
import {
  AppWindow,
  ArrowRight,
  Calendar,
  Clock,
  Code2,
  Database,
  ExternalLink,
  Layers,
  Palette,
  Plus,
  Search,
  Server,
  Settings2,
  Smartphone,
  Sparkles,
  Trash2,
  Wand2,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useStudioStore, type SavedApp } from '@/lib/store';
import { toast } from '@/lib/toast';

export function ApplicationsDashboard() {
  const {
    apps,
    currentAppId,
    selectApp,
    deleteApp,
    createNewApp,
    saveCurrentApp,
    setCurrentView,
    goToStep,
  } = useStudioStore();

  const [search, setSearch] = useState('');
  const [deleteModalApp, setDeleteModalApp] = useState<SavedApp | null>(null);

  const filteredApps = apps.filter((app) => {
    const q = search.toLowerCase();
    return (
      app.name.toLowerCase().includes(q) ||
      app.packageName.toLowerCase().includes(q) ||
      (app.description && app.description.toLowerCase().includes(q))
    );
  });

  const handleOpenBuilder = (appId: string) => {
    selectApp(appId, 'screen_builder');
    toast.success('Opened in Screen Builder');
  };

  const handleEditWizard = (appId: string) => {
    selectApp(appId, 'wizard');
    goToStep(0);
    toast.success('Loaded project settings in Wizard');
  };

  const handleConfirmDelete = () => {
    if (!deleteModalApp) return;
    deleteApp(deleteModalApp.id);
    toast.success(`Deleted application "${deleteModalApp.name}"`);
    setDeleteModalApp(null);
  };

  const handleCreateNew = () => {
    createNewApp();
    toast.success('New application created! Configure it in wizard or screen builder.');
  };

  const handleSaveCurrentWizard = () => {
    const saved = saveCurrentApp();
    toast.success(`Saved "${saved.name}" to Applications!`);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      {/* Top Header */}
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                <AppWindow className="h-4 w-4" />
              </span>
              <h1 className="text-2xl font-bold tracking-tight">Applications</h1>
              <span className="rounded-full bg-indigo-100 px-2.5 py-0.5 text-xs font-semibold text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300">
                {apps.length} {apps.length === 1 ? 'App' : 'Apps'}
              </span>
            </div>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Manage your created Flutter applications, update configurations, and visually design screen components.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleSaveCurrentWizard}
              className="gap-2 text-xs"
            >
              <Wand2 className="h-3.5 w-3.5 text-indigo-500" />
              Save Current Wizard As App
            </Button>
            <Button
              type="button"
              variant="primary"
              size="sm"
              onClick={handleCreateNew}
              className="gap-2 text-xs"
            >
              <Plus className="h-3.5 w-3.5" />
              Create New App
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        {apps.length > 0 && (
          <div className="relative mt-6 max-w-md">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search applications by name or package..."
              className="w-full rounded-xl border border-gray-200 bg-white py-2 pl-9 pr-4 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-800 dark:bg-slate-900"
            />
          </div>
        )}

        {/* Applications Grid */}
        <div className="mt-6">
          {apps.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-gray-200 bg-white/50 p-12 text-center dark:border-slate-800 dark:bg-slate-900/30">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 shadow-sm dark:bg-indigo-950/40 dark:text-indigo-400">
                <Smartphone className="h-8 w-8" />
              </div>
              <h3 className="mt-4 text-lg font-bold">No Applications Yet</h3>
              <p className="mt-1 max-w-md text-sm text-gray-500 dark:text-gray-400">
                You haven&apos;t saved any apps yet. Complete the wizard steps and save your first app, or create a new one right now.
              </p>
              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                <Button
                  type="button"
                  variant="primary"
                  onClick={handleSaveCurrentWizard}
                  className="gap-2"
                >
                  <Sparkles className="h-4 w-4" />
                  Save Current Wizard Setup as App
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setCurrentView('wizard');
                    goToStep(0);
                  }}
                  className="gap-2"
                >
                  <ArrowRight className="h-4 w-4" />
                  Go to Setup Wizard
                </Button>
              </div>
            </div>
          ) : filteredApps.length === 0 ? (
            <div className="rounded-xl border border-gray-200 bg-white p-8 text-center text-sm text-gray-500 dark:border-slate-800 dark:bg-slate-900 dark:text-gray-400">
              No applications match &ldquo;{search}&rdquo;. Try another search term.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
              {filteredApps.map((app) => {
                const isActive = app.id === currentAppId;
                const componentCount = app.components?.length || 0;
                const backend = String(app.config['backend.provider'] || 'none');
                const db = String(app.config['database.engine'] || 'sqlite');
                const themeColor = String(app.config['frontend.themeColor'] || 'indigo');

                return (
                  <div
                    key={app.id}
                    className={`group relative flex flex-col justify-between rounded-2xl border bg-white p-5 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-md dark:bg-slate-900 ${
                      isActive
                        ? 'border-indigo-500 ring-2 ring-indigo-500/20 dark:border-indigo-400'
                        : 'border-gray-200 dark:border-slate-800'
                    }`}
                  >
                    <div>
                      {/* Top Header */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div
                            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-bold text-white shadow-sm"
                            style={{
                              backgroundColor:
                                themeColor === 'purple'
                                  ? '#a855f7'
                                  : themeColor === 'emerald'
                                    ? '#10b981'
                                    : themeColor === 'rose'
                                      ? '#f43f5e'
                                      : '#6366f1',
                            }}
                          >
                            {app.name.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <h3 className="truncate text-base font-bold text-gray-900 dark:text-white">
                              {app.name}
                            </h3>
                            <p className="truncate font-mono text-xs text-gray-400">
                              {app.packageName}
                            </p>
                          </div>
                        </div>

                        {isActive && (
                          <span className="shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                            Active
                          </span>
                        )}
                      </div>

                      {/* Description */}
                      <p className="mt-3 line-clamp-2 text-xs text-gray-500 dark:text-gray-400">
                        {app.description || 'Modern cross-platform Flutter application.'}
                      </p>

                      {/* Tech Badges */}
                      <div className="mt-4 flex flex-wrap gap-1.5">
                        <span className="inline-flex items-center gap-1 rounded-md bg-gray-100 px-2 py-0.5 text-[11px] font-medium text-gray-700 dark:bg-slate-800 dark:text-gray-300">
                          <Code2 className="h-3 w-3 text-indigo-500" />
                          Flutter 3.24
                        </span>
                        <span className="inline-flex items-center gap-1 rounded-md bg-gray-100 px-2 py-0.5 text-[11px] font-medium text-gray-700 dark:bg-slate-800 dark:text-gray-300">
                          <Server className="h-3 w-3 text-sky-500" />
                          {backend}
                        </span>
                        <span className="inline-flex items-center gap-1 rounded-md bg-gray-100 px-2 py-0.5 text-[11px] font-medium text-gray-700 dark:bg-slate-800 dark:text-gray-300">
                          <Database className="h-3 w-3 text-emerald-500" />
                          {db}
                        </span>
                        <span className="inline-flex items-center gap-1 rounded-md bg-indigo-50 px-2 py-0.5 text-[11px] font-medium text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300">
                          <Layers className="h-3 w-3" />
                          {componentCount} Widgets
                        </span>
                      </div>
                    </div>

                    {/* Bottom Actions */}
                    <div className="mt-6 border-t border-gray-100 pt-4 dark:border-slate-800/80">
                      <div className="flex items-center justify-between text-[11px] text-gray-400 mb-3">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(app.updatedAt).toLocaleDateString()}
                        </span>
                        <span>v{app.version}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          type="button"
                          variant="primary"
                          size="sm"
                          onClick={() => handleOpenBuilder(app.id)}
                          className="flex-1 gap-1.5 text-xs font-semibold"
                        >
                          <Smartphone className="h-3.5 w-3.5" />
                          Screen Builder
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditWizard(app.id)}
                          title="Edit in Wizard"
                          className="px-2.5"
                        >
                          <Settings2 className="h-3.5 w-3.5 text-gray-500" />
                        </Button>
                        <button
                          type="button"
                          onClick={() => setDeleteModalApp(app)}
                          title="Delete Application"
                          className="rounded-lg p-2 text-gray-400 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/30"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteModalApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-base font-bold text-gray-900 dark:text-white">
              Delete Application?
            </h3>
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
              Are you sure you want to delete &ldquo;{deleteModalApp.name}&rdquo;? This will remove the saved app and all its screen components.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setDeleteModalApp(null)}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="danger"
                size="sm"
                onClick={handleConfirmDelete}
              >
                Delete App
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
