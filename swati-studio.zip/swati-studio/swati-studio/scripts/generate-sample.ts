import { defaultConfig } from '@swati/schema';
import { generateProject } from '@swati/generator';

console.log('Generating sample project with default configuration...');
const config = defaultConfig();
const result = generateProject(config);

console.log(`\nGenerated ${result.files.length} files:`);
for (const file of result.files) {
  console.log(`  - ${file.path}`);
}

console.log('\nSummary:');
console.log(`  Files: ${result.summary.files}`);
console.log(`  Directories: ${result.summary.directories.length}`);
console.log(`  Packages: ${result.summary.packages}`);
console.log(`  Estimated Size: ~${result.summary.estimatedSizeKb} KB`);
console.log(`  Architecture: ${result.context.architectureName}`);
console.log(`  State Manager: ${result.context.stateName}`);
console.log(`  Backend: ${result.context.backendName}`);
console.log(`  Database: ${result.context.databaseName}`);
