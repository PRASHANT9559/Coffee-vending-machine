/**
 * Zero dependency static server for the exported Next.js build.
 *
 *   npm run build && npm run preview
 *
 * The Tauri shell serves the same files from `apps/studio/out`.
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..', 'apps', 'studio', 'out');
const port = Number(process.env.PORT || 4173);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.woff2': 'font/woff2',
};

if (!fs.existsSync(root)) {
  console.error(`No export found at ${root}. Run "npm run build" first.`);
  process.exit(1);
}

http
  .createServer((req, res) => {
    const url = decodeURIComponent((req.url || '/').split('?')[0]);
    let target = path.join(root, url);

    if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
      const withIndex = path.join(target, 'index.html');
      target = fs.existsSync(withIndex) ? withIndex : path.join(root, 'index.html');
    }

    if (!fs.existsSync(target)) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }

    res.writeHead(200, { 'Content-Type': MIME[path.extname(target)] || 'application/octet-stream' });
    fs.createReadStream(target).pipe(res);
  })
  .listen(port, () => {
    console.log(`Swati Studio preview running at http://localhost:${port}`);
    console.log(`  home    → http://localhost:${port}/`);
    console.log(`  wizard  → http://localhost:${port}/wizard/`);
  });
