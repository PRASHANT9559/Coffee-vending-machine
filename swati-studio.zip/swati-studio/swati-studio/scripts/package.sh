#!/usr/bin/env bash
# Packages the repository into a distributable zip.
#
#   ./scripts/package.sh            -> ../swati-studio.zip
#   ./scripts/package.sh ./out.zip  -> ./out.zip
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-$ROOT/../swati-studio.zip}"
NAME="$(basename "$TARGET" .zip)"

cd "$ROOT"

echo "Packaging $ROOT -> $TARGET"

# Build artifacts and dependencies are not part of the source package.
rm -f "$TARGET"
zip -r -q "$TARGET" . \
  -x "node_modules/*" \
  -x "*/node_modules/*" \
  -x ".next/*" \
  -x "*/.next/*" \
  -x "out/*" \
  -x "*/out/*" \
  -x "target/*" \
  -x "*/target/*" \
  -x ".git/*" \
  -x "*/.git/*" \
  -x "*.tsbuildinfo" \
  -x "*/gen/*" \
  -x "*/dist/*" \
  -x ".DS_Store"

echo "Done: $(du -h "$TARGET" | cut -f1)  ($TARGET)"
