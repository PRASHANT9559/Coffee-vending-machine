# Swati Studio

**A schema-driven desktop app builder.** Pick a stack, pick a style, and get a *real,
compiling* Flutter project on your disk — driven by a configuration file, not by
hand-written UI.

```
Tauri v2 shell  +  Rust backend  +  Next.js 15 UI  +  Tailwind CSS v4
```

---

## What it actually does

The original prototype was a single HTML file where the "Generate Project" button
faked a progress bar and produced nothing. This version:

| Area | Prototype | This repo |
| --- | --- | --- |
| Options (backends, databases, features…) | hard-coded arrays inside render functions | one data file per catalog in `packages/schema/src/catalogs` |
| Adding a backend | edit JSX + duplicate the config form | add one object to `backends.ts` |
| Validation | none | schema-driven, per field, per step |
| Review screen | hand-written cards | generated from the schema |
| "Generate" | fake progress modal | writes a real project tree to disk |
| Output | nothing | a compilable Flutter project + `.zip` |
| Persistence | `localStorage` draft that was never read back | zustand + native draft file |
| Desktop | n/a | Tauri v2 + Rust: file IO, zip, toolchain detection, native dialogs |

---

## Repository layout

```
swati-studio/
├── apps/
│   └── studio/                 Next.js 15 App Router (static export)
│       └── src/
│           ├── app/            / (landing) and /wizard
│           ├── components/
│           │   ├── ui/         generic controls (Select, OptionCards, SchemaField …)
│           │   └── wizard/     stepper, preview, review, command palette
│           └── lib/            store, IPC bridge, toasts
├── packages/
│   ├── schema/                 the single source of truth  ← start here
│   │   └── src/
│   │       ├── types.ts        FieldDef / OptionDef / StepDef
│   │       ├── schema.ts       the 10 wizard steps
│   │       ├── config.ts       defaults, validation, summary, import/export
│   │       └── catalogs/       backends, databases, features, styles …
│   └── generator/              config → real file tree
│       └── src/
│           ├── context.ts      resolves the config into a generation context
│           ├── layout.ts       architecture → folder layout
│           ├── plan.ts         assembles every generated file
│           └── templates/      the Dart / YAML / Markdown templates
├── src-tauri/                  Rust desktop shell (Tauri v2)
│   └── src/commands.rs         write_project, zip, toolchain detect, dialogs …
├── scripts/preview.mjs         zero dependency static server for the export
└── docs/                       migration notes, architecture, handoff
```

---

## Quick start

```bash
npm install

# web only (browser) — works without Rust
npm run dev            # http://localhost:3000

# desktop shell
npm run tauri:dev      # Tauri + Vite-less Next dev server
npm run tauri:build    # native installer in src-tauri/target/release/bundle
```

Production build + local preview of the exported site:

```bash
npm run build          # → apps/studio/out
npm run preview        # → http://localhost:4173
```

Checks:

```bash
npm run typecheck      # tsc --noEmit across app + packages
npm test               # vitest — 57 unit tests
cd src-tauri && cargo check
```

### Linux prerequisites for the desktop build

```bash
sudo apt install libwebkit2gtk-4.1-dev libgtk-3-dev librsvg2-dev \
                 libayatana-appindicator3-dev patchelf
```

---

## The one rule: options are data

This is the part that makes the tool maintainable. **You never write UI to add an
option.** You add a data object.

```ts
// packages/schema/src/catalogs/backends.ts
{
  id: 'supabase',
  name: 'Supabase',
  desc: 'Open-source Firebase alternative on PostgreSQL',
  accent: '#10b981',
  tags: ['baaS', 'postgres'],
  data: { sdk: 'supabase_flutter', kind: 'baas' },
  fields: [                       // ← these inputs appear automatically
    { id: 'backend.supabase.url', kind: 'text', label: 'Project URL' },
    { id: 'backend.supabase.anonKey', kind: 'text', label: 'Anon Key' },
  ],
}
```

That single object gives you, with **zero UI code**:

* an entry in the backend dropdown
* a searchable combobox with the right accent colour
* two extra inputs that appear only when Supabase is selected
* a validation rule for those inputs
* a row in the review summary
* the right `pubspec.yaml` dependencies in the generated project
* a `data/` folder in the generated project

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the full contract.

---

## The wizard

10 steps, all generated from `packages/schema/src/schema.ts`:

| # | Step | What it decides |
| --- | --- | --- |
| 1 | Project | name, package id, version, license, platforms, **home page style** |
| 2 | Frontend | UI style, theme colour, font, radius, spacing, motion, breakpoints |
| 3 | Backend | provider + its credentials |
| 4 | Database | engine + its connection settings |
| 5 | Architecture | clean / feature-first / DDD / MVVM / layer-first / MVC |
| 6 | State | Riverpod / Bloc / Provider / GetX / MobX |
| 7 | Features | 22 optional capabilities → packages, folders, routes |
| 8 | Components | 13 UI categories → shared widgets in the output |
| 9 | Preview | the **actual** file tree the generator will write |
| 10 | Review | summary, output folder, write to disk / zip |

Shortcuts: `Ctrl+K` command palette · `Ctrl+S` save draft · `Ctrl+⏎` generate ·
`Ctrl+→/←` step navigation · `Ctrl+Shift+L` theme · `?` shortcuts.

---

## What gets generated

```
my_app/
├── pubspec.yaml              # deps derived from features + state + backend + db
├── analysis_options.yaml
├── README.md
├── CHANGELOG.md
├── swati-studio.config.json  # manifest of the choices behind this project
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── config/               # app_config.dart, routes.dart
│   ├── core/
│   │   ├── constants/  errors/  network/  storage/
│   │   ├── theme/      # app_theme, app_colors, app_typography, design_tokens
│   │   └── widgets/    # app_button, app_text_field, app_card, app_empty_state
│   └── features/
│       ├── home/             # entity, repository, controller, page
│       └── <feature>/…       # one folder per selected feature
└── test/widget_test.dart
```

The theme uses a `ThemeExtension` (`DesignTokens`) instead of `CardTheme` /
`DialogTheme`, so the generated code keeps compiling on Flutter 3.24 **and** on
Flutter ≥ 3.27 where those classes were renamed.

---

## Where the Rust side earns its keep

`src-tauri/src/commands.rs`:

| Command | Why it is native |
| --- | --- |
| `write_project` | writes the tree, rejects path traversal, normalises names |
| (internal) `zip_directory` | real `.zip` via the `zip` crate |
| `detect_toolchains` | probes `flutter`, `dart`, `node`, `rustc` on `PATH` |
| `run_flutter_create` | shells out to `flutter create` for real platform folders |
| `save_draft` / `load_draft` | draft file in the OS app-data directory |
| `pick_output_dir` | native folder picker |
| `open_path` / `reveal_path` | open the result in the file manager |

In the browser the same IPC layer degrades gracefully: the project is zipped with
`fflate` and downloaded, so the app is fully usable without the native shell.

---

## Licence

MIT.
