# 🚀 Swati Studio — Project Overview & Comprehensive Guide

> **Project Name**: Swati Studio (स्वाति स्टूडियो)  
> **Type**: Visual App Builder & Enterprise Flutter/Multi-Target Desktop IDE  
> **Tech Stack**: Tauri v2 + Rust + Next.js (React 19) + Tailwind CSS + TypeScript  
> **Core Philosophy**: Zero Vendor Lock-in • Clean Code Export • Regeneration-Safe • Production-Ready

---

## 📌 1. Swati Studio Kya Hai? (What is Swati Studio?)

**Swati Studio** ek modern, high-performance **Visual App Builder aur Desktop IDE** hai jo developers, design-engineers, aur enterprise teams ko kuch hi minutes mein **production-ready Flutter (saath hi React Native aur Next.js)** applications visually design karne aur generate karne ki suvidha deta hai.

### 💡 The Big Problem It Solves:
* **Manual Setup Boilerplate**: Har naye Flutter app mein Auth, Routing, State Management (Riverpod/Bloc), Backend integration, Offline cache, Flavors, CI/CD aur Theme setup karne mein 2–4 hafte lagte hain.
* **Toy Generators vs Real Enterprise Code**: Zyadatar app builders "toy code" banate hain jisme vendor lock-in hota hai ya generated code ko customize karna namumkin hota hai.
* **Overwriting User Edits**: Agar user ne code generate hone ke baad kuch change kiya aur dobara wizard chalaya, toh purane tools user ka code overwrite kar dete hain.

### 🎯 Swati Studio Solution:
Swati Studio ek **Schema-Driven Architecture** par kaam karta hai. Chahe aap visually drag-and-drop karke screens banayein, 11-step wizard se project configure karein, ya AI prompt dein — Swati Studio ek clean, tested, enterprise-grade architecture export karta hai jo industry best practices (Clean Architecture, Feature-First, Freezed models, Repository pattern) ko follow karta hai.

---

## 🌟 2. Swati Studio Ke Core Features (Features Breakdown)

Swati Studio ko 4 bade core modules aur 40 enterprise features mein divide kiya gaya hai:

### A. 📱 Visual Screen Builder & Live Code Preview
1. **Interactive Canvas**: Mobile phone mockup canvas jisme widgets directly drop aur reorder hote hain.
2. **Component Library (9+ Widget Types)**:
   - AppBar, Buttons (Elevated, Filled, Outlined, Text), Cards, TextFields, Typography (H1, H2, Body), Dynamic ListView, Stat Cards, Images, Floating Action Buttons (FAB), Containers, Dividers, Spacers.
3. **Live Code Preview (Split View)**:
   - Jaise hi aap visual canvas par koi property ya color badalte hain, live Flutter Dart code real-time mein generate hota hai.
4. **Instant Export & Copy**:
   - 1-click "Copy Code", "Download .dart", ya complete Screen routes registry export.
5. **Undo / Redo History**: Full state history (Ctrl+Z / Ctrl+Y) har visual screen edit ke liye.

---

### B. 🧙‍♂️ Setup Wizard (11 Core Steps)
1. **Step 1: Theme & UI Style** — 43 pre-built themes, Material You 3, AMOLED pitch black, Sepia mode, glassmorphism, aur custom palette generation.
2. **Step 2: Navigation & Dynamic Screens** — 11 navigation patterns (Bottom Nav, Floating Bubble, Animated Wave, Side Drawer, Tabs) aur dynamic screen buttons.
3. **Step 3: Project Metadata** — App name, package ID (`com.example.app`), environments (Dev, Staging, Prod), aur CI/CD setup.
4. **Step 4: Database & Offline Sync** — Supabase, Drift (SQLite), Isar, Hive, aur custom `.db` file upload introspection.
5. **Step 5: Backend Provider** — Supabase, Firebase, PocketBase, Appwrite, GraphQL, ya Custom REST.
6. **Step 6: Architecture Pattern** — Feature-First, Clean Architecture (Domain/Data/Presentation), ya Layered MVC.
7. **Step 7: State Management** — Flutter Riverpod (Code-gen), BLoC / Cubit, Provider, Signals, ya GetX.
8. **Step 8: Capabilities & Features** — Auth flows, RBAC, Camera, Push notifications, Payments (Razorpay/Stripe), Biometrics, Maps.
9. **Step 9: Shared Components** — Custom buttons, skeleton loaders, inputs, bottom sheets.
10. **Step 10: File Tree Preview** — Real-time virtual file system preview jo disk par write hone se pehle poori structure dikhata hai.
11. **Step 11: Review & Generate** — Summary check, `flutter create` toggle, output folder picker, aur safe project generation.

---

### C. 🏢 Enterprise Wizard Suite (Part 1: Features #1 to #25)
* **#1 Template Marketplace (Step 0)**: 10+ pre-configured industry presets (E-Commerce, Food Delivery, HealthCare, Social Media, SaaS, Real Estate, Fitness, Banking).
* **#2 AI-Powered Smart Wizard**: 1 natural-language prompt likho (e.g. *"I want an e-commerce app with Supabase and Riverpod"*), aur AI poori configuration auto-set kar deta hai.
* **#3 Auth Flow Builder**: Email/Password, Google OAuth, Apple Sign-In, Phone OTP, Biometrics, Forgot Password flow.
* **#6 Multi-Environment Flavors**: `main_dev.dart`, `main_staging.dart`, `main_prod.dart` with `.env` secure assets.
* **#7 CI/CD Pipeline Generator**: GitHub Actions workflows for linting, testing, and release APK/AAB build.
* **#8 Role-Based Access Control (RBAC)**: Superadmin, Admin, Manager, User roles with widget-level permission guards.
* **#14 Deep Linking**: Universal Links (iOS) & App Links (Android) routing setup.
* **#17 Offline-First & Conflict Resolution**: Last-Write-Wins, local SQLite queue, background connectivity sync.
* **#18 Project Health Dashboard**: Security, architecture and package audit score.
* **#19 Team Collaboration & Share Presets**: Config import/export via encoded URL and corporate team presets.
* **#20 Smart Cost Estimation**: Monthly cloud infrastructure cost calculator in USD & INR.
* **#23 Plugin Marketplace**: 1-click install for Stripe, GraphQL, WebSockets, PDFs, etc.

---

### D. 🚀 Enterprise Wizard Suite (Part 2: Features #26 to #40)
* **#26 Regeneration-Safe Codegen**:
  - 3 File Ownerships (`generated` = overwrite, `scaffold` = user-owned untouched, `hybrid` = merge).
  - Protected regions (`// <swati:tag>`) jisse user ka custom code dobara generate karne par kabhi delete nahi hota.
  - Interactive Dry-Run preview aur 1-click Undo.
* **#27 Brownfield Mode (Existing Project Import)**:
  - Kisi bhi purane Flutter project ko scan karo, tech stack detect karo, aur bina existing code chhue missing enterprise features (i18n, CI/CD, Push, Security) inject karo.
* **#28 Database Schema Designer**:
  - Visual ER Diagram canvas, UUID primary keys, foreign key relations, Supabase RLS policies, Drift classes, aur Mermaid ERD export.
* **#29 CRUD & Form Scaffolder**:
  - Kisi bhi model ke liye 1-click full CRUD: List view (grid/table), infinite pagination, search, filter, form validation, aur controller.
* **#30 Push Notification Setup**:
  - FCM / OneSignal, Android 13 runtime permissions, high-priority channels (Orders, Chat, Promos), aur tap deep link router.
* **#31 Remote Config, Force Update & Maintenance Mode**:
  - Runtime feature flags, version compare (`compareSemver`), soft update banner, Play Store force update dialog, aur maintenance gate.
* **#32 Backend Scaffold Generator**:
  - Dart Frog, Rust (Axum), Node (Fastify), ya Supabase Edge Functions with OpenAPI 3.0 contract, Dockerfile, aur docker-compose.
* **#33 Legal & Store Compliance Kit**:
  - Auto-detected data collection, Privacy Policy (MD & HTML), Terms of Service, Play Store Data Safety Questionnaire cheatsheet, aur account deletion web URL.
* **#34 Standard UI States Kit**:
  - Reusable Shimmer skeleton list, empty data view, error view with retry, offline connectivity banner, aur `AsyncValueView<T>` wrapper.
* **#35 App Icon, Splash & Branding Generator**:
  - Logo upload se Android adaptive icon layers, Android 13 themed icons, iOS icons, Android 12+ splash API, aur Play Store 512x512 assets.
* **#36 Mock Data & Fake Server**:
  - Realistic dummy data generator (`hi_IN` with ₹ / `en_US`), network latency slider (300–2500ms), simulated failure injection, aur standalone mock server.
* **#37 Accessibility & Responsive Breakpoints**:
  - Adaptive layout (Phone Bottom Nav ↔ Tablet Rail ↔ Desktop Drawer), semantics labels, 48x48dp tap target, aur live WCAG AA contrast ratio validation with 1-click fix.
* **#38 App Size & Performance Budget**:
  - 25MB release budget meter, R8 code/resource shrinking, `--split-per-abi`, `--obfuscate`, aur parallel `AppBootstrap` startup initialization.
* **#39 Auto Documentation Generator**:
  - README, ARCHITECTURE.md with Mermaid diagrams, DATABASE.md with ERD, CONTRIBUTING, CHANGELOG, aur Architecture Decision Records (`docs/adr/*`).
* **#40 Headless CLI Mode & Config-as-Code**:
  - `swati.yaml` source of truth, JSON Schema Draft-07 autocomplete, aur headless CLI tool (`scripts/swati-cli.mjs`) for CI/CD runs.

---

### E. 🌐 Multi-Target Code Generator
Swati Studio sirf Flutter tak seemit nahi hai:
* **Flutter Material 3** (Default primary target)
* **Next.js 15 App Router** (React 19 + TypeScript + Tailwind CSS)
* **React Native / Expo** (TypeScript + React Navigation)

---

## ⚙️ 3. Swati Studio Kaise Kaam Karta Hai? (How It Works)

Swati Studio ka internal architecture 4 primary layers mein kaam karta hai:

```
┌──────────────────────────────────────────────────────────────┐
│                    1. Input & Design Layer                   │
│   • Visual Screen Canvas (Drag & Drop Components)            │
│   • 11-Step Setup Wizard (Dropdowns, Cards, Toggles)         │
│   • AI Prompt Bar ("I want an e-commerce app with Supabase") │
│   • Config-as-Code (swati.yaml import)                       │
└──────────────────────────────┬───────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────┐
│                   2. Reactive State Layer                    │
│   • Zustand Unified Store (`useStudioStore`)                 │
│   • StudioConfig JSON Schema Validation (Draft-07)           │
│   • Reverse Pubspec & Brownfield Detection Engine            │
└──────────────────────────────┬───────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────┐
│                  3. Pure Code Generator                      │
│   • Context Builder (`buildContext(config)`)                 │
│   • Assembly Plan (`assemblePlan(ctx)`)                      │
│   • 35+ Template Engines (auth, crud, rbac, push, theme...)  │
│   • 3-Way Merge & Regeneration Safety Engine                 │
└──────────────────────────────┬───────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────┐
│                 4. Execution & Export Layer                  │
│   • Desktop IPC File Writer (`writeProject`)                 │
│   • Automated `flutter create` scaffolding                   │
│   • Git commit / snapshot backup                             │
│   • Headless CLI Runner (`node scripts/swati-cli.mjs`)       │
└──────────────────────────────────────────────────────────────┘
```

### Detailed Workflow:
1. **User Input**: User wizard ke zariye ya Visual Screen Builder mein apni app choose karta hai.
2. **Schema Compilation**: Har choice ek type-safe `StudioConfig` key-value map mein convert hoti hai.
3. **Template Assembly**: Generator context create karke 35+ modular template generators ko run karta hai.
4. **Regeneration Check**: Agar purana code maujood hai, toh 3-way merge engine check karta hai aur user ke protected regions (`// <swati:tag>`) ko safe rakhta hai.
5. **Output**: Disk par complete compile-ready project write ho jaata hai jisme folder structure, assets, packages aur tests ready hote hain.

---

## 👥 4. Kin Users Ko Target Karta Hai? (Target Audience)

Swati Studio ko specifically in 5 user personas ke liye design kiya gaya hai:

| User Persona | Unki Problem | Swati Studio Unhe Kaise Help Karta Hai |
|---|---|---|
| **1. Flutter Freelancers & Solo Devs** | Har client project ke liye baar-baar same auth, theme, navigation setup karna padta hai jisme 1-2 hafte waste hote hain. | 10 minute mein complete base architecture + CRUD screens export karke seedha client ki business logic par kaam start kar sakte hain. |
| **2. Digital Agencies & Studios** | Multiple clients ke liye alag-alag stacks (Supabase, Firebase, Riverpod, BLoC) maintain karna mushkil hota hai. | Standardized corporate presets, clean separation of concerns, CI/CD pipelines, aur multi-environment flavors ready milte hain. |
| **3. Enterprise Engineering Teams** | Scalable code standards, strict architecture compliance, RBAC, offline sync aur security policies enforce karni hoti hain. | Feature-first modular code, RLS policies, GDPR/DPDP legal compliance, ADR documentation aur size budgeting built-in milta hai. |
| **4. Early-Stage Startups & Founders** | Fast MVP deliver karna hota hai bina kisi vendor lock-in ke. | Visual UI builder se rapid prototyping, AI wizard se instant setup, aur mock data server se backend ready hone se pehle frontend development. |
| **5. Full-Stack & Backend Developers** | Flutter frontend widget syntax seekhne mein time lagta hai. | Schema designer se database design karo, backend scaffold (Rust/Node/Dart Frog) generate karo, aur Flutter client automatically sync ho jata hai. |

---

## 💎 5. Swati Studio Ke Key Differentiators (Why Swati Studio?)

1. **No Vendor Lock-In**:
   - FlutterFlow ya doosre low-code tools jaisa koi subscription trap nahi hai. Jo code generate hota hai, woh 100% standard Flutter/Dart code hai jo kisi bhi IDE (VS Code, Android Studio) mein seedha run hota hai.
2. **Safe Code Re-generation (#26)**:
   - Zyadatar code generators sirf "ek baar" kaam aate hain. Swati Studio ka 3-way merge engine user ke code ko preserve karte hue configuration updates merge karta hai.
3. **Brownfield Friendly (#27)**:
   - Sirf naye projects nahi, balki pehle se chalte hue existing apps mein bhi add-on features inject kar sakta hai.
4. **Data-First & Full-Stack (#28, #32)**:
   - Frontend ke saath saath backend routes, SQL migrations, Docker, aur OpenAPI contracts bhi generate karta hai.
5. **Completely Local & Private**:
   - Tauri v2 aur local Rust shell ke karan aapka code aur database local machine par rehta hai — koi private cloud dependency nahi.

---

## 🏁 Summary

**Swati Studio** ek visual designer se kahin badhkar ek **Full-Fledged Desktop Engineering Suite** hai jo modern mobile aur multi-target development ko 10x tezi se, bina compromise ke, aur enterprise-grade reliability ke saath deliver karta hai.
