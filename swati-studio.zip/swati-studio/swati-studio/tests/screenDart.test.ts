import { describe, it, expect } from 'vitest';
import {
  templateScreenDart,
  componentToFlutterWidget,
  generateAllScreensDart,
  generateScreenRoutesDart,
  exportScreenToDart,
  type ExportedScreen,
  type ExportedComponent,
} from '@swati/generator';

describe('Screen Builder → Flutter Dart Code Generator', () => {
  const sampleScreen: ExportedScreen = {
    id: 'screen-test-1',
    name: 'Dashboard Overview',
    route: '/dashboard',
    isInitial: true,
    components: [
      {
        id: 'comp-1',
        type: 'appbar',
        name: 'Top AppBar',
        props: { title: 'Dashboard', elevation: 4 },
      },
      {
        id: 'comp-2',
        type: 'button',
        name: 'Action Button',
        props: {
          label: 'Go to Profile',
          variant: 'elevated',
          actionType: 'navigate',
          targetRoute: '/profile',
        },
      },
      {
        id: 'comp-3',
        type: 'card',
        name: 'Welcome Card',
        props: {
          title: 'Analytics Summary',
          subtitle: 'Active users +28% this week',
          borderRadius: 16,
          padding: 20,
        },
      },
      {
        id: 'comp-4',
        type: 'textfield',
        name: 'Search Input',
        props: {
          label: 'Search projects',
          placeholder: 'Type query...',
          borderRadius: 12,
        },
      },
      {
        id: 'comp-5',
        type: 'text',
        name: 'Heading',
        props: {
          text: 'Key Performance Indicators',
          variant: 'h1',
          fontSize: 24,
        },
      },
      {
        id: 'comp-6',
        type: 'listview',
        name: 'Recent Events',
        props: {
          title: 'Recent Logs',
          items: ['Log Alpha', 'Log Beta', 'Log Gamma'],
        },
      },
      {
        id: 'comp-7',
        type: 'stat_card',
        name: 'Stat Card',
        props: {
          title: 'Total Revenue',
          value: '$48,200',
          borderRadius: 14,
        },
      },
      {
        id: 'comp-8',
        type: 'image',
        name: 'Promo Banner',
        props: {
          title: 'Q4 Promotion',
          borderRadius: 12,
        },
      },
      {
        id: 'comp-9',
        type: 'floating_action_button',
        name: 'Add FAB',
        props: {
          icon: 'Plus',
          actionType: 'navigate',
          targetRoute: '/new-item',
        },
      },
      {
        id: 'comp-10',
        type: 'container',
        name: 'Box Container',
        props: {
          title: 'Custom Box',
          padding: 14,
        },
      },
      {
        id: 'comp-11',
        type: 'divider',
        name: 'Line Divider',
        props: {},
      },
      {
        id: 'comp-12',
        type: 'spacer',
        name: 'Gap Spacer',
        props: { height: 24 },
      },
      {
        id: 'comp-13',
        type: 'badge',
        name: 'Status Badge',
        props: { title: 'Verified' },
      },
    ],
  };

  it('generates valid Dart code for all component types', () => {
    const dartCode = templateScreenDart(sampleScreen);

    expect(dartCode).toContain("import 'package:flutter/material.dart';");
    expect(dartCode).toContain('class DashboardOverviewPage extends StatelessWidget');
    expect(dartCode).toContain("static const String routeName = '/dashboard';");

    // AppBar
    expect(dartCode).toContain('AppBar(');
    expect(dartCode).toContain("const Text('Dashboard')");

    // Button with navigation
    expect(dartCode).toContain('ElevatedButton(');
    expect(dartCode).toContain("Navigator.of(context).pushNamed('/profile')");
    expect(dartCode).toContain("Text('Go to Profile')");

    // Card
    expect(dartCode).toContain('Card(');
    expect(dartCode).toContain("Text('Analytics Summary'");

    // TextField
    expect(dartCode).toContain('TextField(');
    expect(dartCode).toContain("labelText: 'Search projects'");

    // Text Heading
    expect(dartCode).toContain('Key Performance Indicators');

    // StatCard
    expect(dartCode).toContain('$48,200');

    // ListView
    expect(dartCode).toContain('Log Alpha');

    // Image/Banner
    expect(dartCode).toContain('Q4 Promotion');

    // FAB
    expect(dartCode).toContain('FloatingActionButton(');
    expect(dartCode).toContain("floatingActionButton: FloatingActionButton(");

    // Layout primitives
    expect(dartCode).toContain('Custom Box');
    expect(dartCode).toContain('Divider()');
    expect(dartCode).toContain('SizedBox(height: 24.0)');
    expect(dartCode).toContain("Text('Verified')");
  });

  it('generates correct app_routes.dart table for multiple screens', () => {
    const screens: ExportedScreen[] = [
      sampleScreen,
      {
        id: 'screen-2',
        name: 'User Profile',
        route: '/profile',
        components: [
          {
            id: 'p-1',
            type: 'text',
            name: 'Profile Header',
            props: { text: 'My Profile' },
          },
        ],
      },
    ];

    const routesCode = generateScreenRoutesDart(screens);
    expect(routesCode).toContain("'/dashboard': (context) => const DashboardOverviewPage()");
    expect(routesCode).toContain("'/profile': (context) => const UserProfilePage()");
    expect(routesCode).toContain("static const String initialRoute = '/dashboard';");
  });

  it('generates individual files for all screens via generateAllScreensDart', () => {
    const files = generateAllScreensDart([sampleScreen]);
    expect(files.length).toBe(2); // 1 screen file + 1 app_routes.dart file
    expect(files[0].path).toBe('lib/screens/dashboard_overview_page.dart');
    expect(files[1].path).toBe('lib/screens/app_routes.dart');
  });

  it('standalone exportScreenToDart produces clean Dart code', () => {
    const code = exportScreenToDart(sampleScreen);
    expect(code).toBeTypeOf('string');
    expect(code.length).toBeGreaterThan(100);
  });
});
