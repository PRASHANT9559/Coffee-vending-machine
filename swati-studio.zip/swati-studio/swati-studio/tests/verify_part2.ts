import { defaultConfig } from '../packages/schema/src/config.ts';
import { extractProtectedRegions, mergeHybridFile, computeMergeAction } from '../packages/schema/src/codegenSafety.ts';
import { scanExistingProject } from '../packages/schema/src/brownfieldScanner.ts';
import { generateSqlMigration, generateMermaidErd, DatabaseDesignSchema } from '../packages/schema/src/schemaDesigner.ts';
import { parseCliArgs, serializeSwatiYaml, validateSwatiConfig, generateSwatiJsonSchema } from '../packages/schema/src/cliConfig.ts';
import { generateProject } from '../packages/generator/src/index.ts';

console.log('🧪 Starting Part 2 Verification Runner...');

// 26. Codegen Safety
const regions = extractProtectedRegions('// <swati:tag>\ncustomCode();\n// </swati:tag>');
if (!regions.has('tag') || !regions.get('tag')?.includes('customCode();')) {
  throw new Error('Failed: extractProtectedRegions');
}
const merged = mergeHybridFile('// <swati:tag>\ndefault\n// </swati:tag>', '// <swati:tag>\nuserCode\n// </swati:tag>');
if (!merged.includes('userCode') || merged.includes('default')) {
  throw new Error('Failed: mergeHybridFile');
}
console.log('✅ Feature 26: Regeneration-Safe Codegen OK');

// 27. Brownfield Scanner
const detected = scanExistingProject('dependencies:\n  flutter:\n    sdk: flutter\n  flutter_riverpod: ^2.0.0\n  supabase_flutter: ^2.0.0\n');
if (detected.stateManagement !== 'riverpod' || detected.backend !== 'supabase') {
  throw new Error('Failed: scanExistingProject');
}
console.log('✅ Feature 27: Brownfield Scanner OK');

// 28. Schema Designer
const schema: DatabaseDesignSchema = {
  version: '1.0',
  tables: [{
    name: 'products',
    enableRls: true,
    columns: [{ name: 'id', type: 'uuid', isPrimary: true }, { name: 'name', type: 'text' }]
  }]
};
const sql = generateSqlMigration(schema);
if (!sql.includes('CREATE TABLE IF NOT EXISTS public.products') || !sql.includes('ENABLE ROW LEVEL SECURITY')) {
  throw new Error('Failed: generateSqlMigration');
}
const erd = generateMermaidErd(schema);
if (!erd.includes('erDiagram') || !erd.includes('products {')) {
  throw new Error('Failed: generateMermaidErd');
}
console.log('✅ Feature 28: Database Schema Designer OK');

// 40. CLI Config
const cliArgs = parseCliArgs(['init', '--template', 'e-commerce']);
if (cliArgs.command !== 'init' || cliArgs.options.template !== 'e-commerce') {
  throw new Error('Failed: parseCliArgs');
}
const config = defaultConfig();
const yaml = serializeSwatiYaml(config);
if (!yaml.includes('schemaVersion: 3') || !yaml.includes('stack:')) {
  throw new Error('Failed: serializeSwatiYaml');
}
const validation = validateSwatiConfig(config);
if (!validation.valid) {
  throw new Error('Failed: validateSwatiConfig');
}
console.log('✅ Feature 40: CLI & Config-as-Code OK');

// Full Generator verification (Features 29 to 40)
const res = generateProject(config);
const paths = new Set(res.files.map(f => f.path));

const expected = [
  'supabase/migrations/20261103000000_init_schema.sql',
  'docs/erd.mmd',
  'lib/features/products/models/product_model.dart',
  'lib/features/products/repositories/product_repository.dart',
  'lib/features/products/controllers/product_controller.dart',
  'lib/features/products/screens/product_list_screen.dart',
  'lib/core/notifications/notification_service.dart',
  'lib/core/notifications/fcm_handler.dart',
  'lib/core/remote_config/remote_config_service.dart',
  'lib/core/remote_config/maintenance_gate.dart',
  'backend/openapi.yaml',
  'backend/Dockerfile',
  'backend/docker-compose.yml',
  'legal/privacy_policy.html',
  'legal/account_deletion.html',
  'legal/DATA-SAFETY-CHEATSHEET.md',
  'lib/core/widgets/states/async_value_view.dart',
  'flutter_launcher_icons.yaml',
  'flutter_native_splash.yaml',
  'lib/core/mock/mock_data_generator.dart',
  'tools/mock_server/server.dart',
  'lib/core/responsive/adaptive_scaffold.dart',
  'lib/core/accessibility/contrast_checker.dart',
  'android/app/proguard-rules.pro',
  'scripts/build_release.sh',
  'docs/SIZE-REPORT.md',
  'docs/ARCHITECTURE.md',
  'docs/DATABASE.md',
  'docs/ONBOARDING.md',
  'docs/adr/0001-state-management.md',
  'swati.yaml',
  '.swati/schema/swati.schema.json',
  '.swati/manifest.json'
];

for (const exp of expected) {
  if (!paths.has(exp)) {
    throw new Error(`Missing expected generated file: ${exp}`);
  }
}

console.log(`🎉 All ${expected.length} essential files verified across features #26 to #40! Total generated files: ${res.files.length}`);
