import { describe, it, expect } from 'vitest';
import {
  defaultConfig,
  computeProjectHealth,
  estimateMonthlyCost,
  generateShareUrl,
  parseShareUrl,
  teamPresets,
  studioPlugins,
  WizardMemoryStore,
} from '@swati/schema';
import { generateProject } from '@swati/generator';

describe('Enterprise Features 17 to 25 Test Suite', () => {
  it('17. Offline-First Architecture generates sync engine, queue, cache and banner widgets', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/core/offline/sync_engine.dart');
    expect(paths).toContain('lib/core/offline/offline_queue.dart');
    expect(paths).toContain('lib/core/offline/cache_manager.dart');
    expect(paths).toContain('lib/core/offline/conflict_resolver.dart');
    expect(paths).toContain('lib/core/offline/connectivity_monitor.dart');
    expect(paths).toContain('lib/core/offline/widgets/offline_banner.dart');
    expect(paths).toContain('lib/core/offline/widgets/sync_indicator.dart');

    const syncEngine = result.files.find((f) => f.path === 'lib/core/offline/sync_engine.dart');
    expect(syncEngine?.contents).toContain('syncPendingMutations');

    const queue = result.files.find((f) => f.path === 'lib/core/offline/offline_queue.dart');
    expect(queue?.contents).toContain('class QueueItem');
    expect(queue?.contents).toContain('class OfflineQueueManager');
  });

  it('18. Project Health Dashboard computes scores across 4 pillars and smart recommendations', () => {
    const config = defaultConfig();
    const health = computeProjectHealth(config);

    expect(health.overallScore).toBeGreaterThanOrEqual(70);
    expect(health.architectureScore).toBeGreaterThan(70);
    expect(health.securityScore).toBeGreaterThan(70);
    expect(health.performanceScore).toBeGreaterThan(70);
    expect(health.codeQualityScore).toBeGreaterThan(70);
    expect(health.estimatedFiles).toBeGreaterThan(20);
    expect(health.recommendations.length).toBeGreaterThan(0);
  });

  it('19. Team Collaboration encodes, decodes share URLs and provides corporate presets', () => {
    const config = defaultConfig();
    config['project.name'] = 'Enterprise Collab App';

    const url = generateShareUrl(config);
    expect(url).toContain('https://swati.studio/config?data=');

    const decoded = parseShareUrl(url);
    expect(decoded).not.toBeNull();
    expect(decoded?.['project.name']).toBe('Enterprise Collab App');

    expect(teamPresets.length).toBeGreaterThanOrEqual(3);
    const company = teamPresets.find((p) => p.id === 'company_standard');
    expect(company?.lockedFields).toContain('security.enableRbac');
  });

  it('20. Smart Cost Estimation Engine calculates accurate USD & INR estimates', () => {
    const config = defaultConfig();
    config['backend.provider'] = 'supabase';
    config['features.selected'] = ['maps', 'notifications', 'analytics'];

    const cost = estimateMonthlyCost(config);
    expect(cost.totalUsd).toBeGreaterThanOrEqual(25);
    expect(cost.totalInr).toBeGreaterThan(2000);
    expect(cost.freeTierCoverage).toContain('MAU');
    expect(cost.costSavingTip).toBeDefined();
    expect(cost.items.some((i) => i.service.includes('Supabase'))).toBe(true);
  });

  it('21. Testing Strategy Configuration generates test helpers, fake data and unit/widget tests', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('test/helpers/test_helpers.dart');
    expect(paths).toContain('test/helpers/fake_data.dart');
    expect(paths).toContain('test/unit/models/user_model_test.dart');
    expect(paths).toContain('test/widget/widgets/app_button_test.dart');
    expect(paths).toContain('coverage_config.yaml');

    const helpers = result.files.find((f) => f.path === 'test/helpers/test_helpers.dart');
    expect(helpers?.contents).toContain('pumpApp');

    const fakeData = result.files.find((f) => f.path === 'test/helpers/fake_data.dart');
    expect(fakeData?.contents).toContain('FakeDataFactory');
  });

  it('22. Version Control Auto-Setup generates .gitignore, CONTRIBUTING, CHANGELOG, and PR/issue templates', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('.gitignore');
    expect(paths).toContain('CONTRIBUTING.md');
    expect(paths).toContain('CHANGELOG.md');
    expect(paths).toContain('.github/pull_request_template.md');
    expect(paths).toContain('.github/ISSUE_TEMPLATE/bug_report.md');
    expect(paths).toContain('.github/ISSUE_TEMPLATE/feature_request.md');
    expect(paths).toContain('CODE_OF_CONDUCT.md');

    const gitignore = result.files.find((f) => f.path === '.gitignore');
    expect(gitignore?.contents).toContain('.dart_tool/');
    expect(gitignore?.contents).toContain('*.key');

    const contributing = result.files.find((f) => f.path === 'CONTRIBUTING.md');
    expect(contributing?.contents).toContain('Conventional Commits');
  });

  it('23. Plugin / Addon Marketplace provides curated plugins with dependencies', () => {
    expect(studioPlugins.length).toBeGreaterThanOrEqual(6);
    const graphql = studioPlugins.find((p) => p.id === 'graphql_client');
    expect(graphql?.dependencies).toContain('graphql_flutter: ^5.1.2');

    const stripe = studioPlugins.find((p) => p.id === 'stripe_payments');
    expect(stripe?.dependencies).toContain('flutter_stripe: ^11.4.0');
  });

  it('24. Wizard Memory accurately computes user stack preferences from past projects', () => {
    const prefs = WizardMemoryStore.computePreferences();
    expect(prefs.totalProjects).toBeGreaterThanOrEqual(2);
    expect(prefs.topBackend).toBe('supabase');
    expect(prefs.topStateManager).toBe('riverpod');
    expect(prefs.recommendationMessage).toContain('supabase');
  });
});
