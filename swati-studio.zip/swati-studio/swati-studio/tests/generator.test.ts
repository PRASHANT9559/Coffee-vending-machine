import { describe, it, expect } from 'vitest';
import { defaultConfig } from '@swati/schema';
import { generateProject } from '@swati/generator';

describe('Project Generator Engine', () => {
  it('generates standard Flutter project files with default config', () => {
    const config = defaultConfig();
    const result = generateProject(config);

    expect(result.files.length).toBeGreaterThan(15);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('pubspec.yaml');
    expect(paths).toContain('README.md');
    expect(paths).toContain('swati-studio.config.json');
    expect(paths).toContain('lib/main.dart');
    expect(paths).toContain('lib/app.dart');
    expect(paths).toContain('lib/core/theme/design_tokens.dart');
    expect(paths).toContain('lib/core/theme/app_theme.dart');
    expect(paths).toContain('lib/core/widgets/app_navigation.dart');
    expect(paths).toContain('lib/config/app_routes.dart');
    expect(paths).toContain('lib/features/home/home_screen.dart');
    expect(paths).toContain('lib/features/search/search_screen.dart');
    expect(paths).toContain('lib/features/profile/profile_screen.dart');

    // Verify AppBar Title in home_screen.dart matches button name
    const homeScreen = result.files.find((f) => f.path === 'lib/features/home/home_screen.dart');
    expect(homeScreen?.contents).toContain("title: Text('Home')");
  });

  it('generates custom navigation buttons and matching screens with titles', () => {
    const config = defaultConfig();
    config['navigation.style'] = 'drawer';
    config['navigation.items'] = [
      { id: '1', name: 'Dashboard', title: 'Dashboard', icon: 'Home', route: '/dashboard' },
      { id: '2', name: 'Orders', title: 'Orders', icon: 'ShoppingCart', route: '/orders' },
      { id: '3', name: 'Analytics', title: 'Analytics', icon: 'Compass', route: '/analytics' },
      { id: '4', name: 'Settings', title: 'Settings', icon: 'Settings', route: '/settings' },
    ];

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/features/dashboard/dashboard_screen.dart');
    expect(paths).toContain('lib/features/orders/orders_screen.dart');
    expect(paths).toContain('lib/features/analytics/analytics_screen.dart');
    expect(paths).toContain('lib/features/settings/settings_screen.dart');

    const ordersScreen = result.files.find((f) => f.path === 'lib/features/orders/orders_screen.dart');
    expect(ordersScreen?.contents).toContain("title: Text('Orders')");

    const navWidget = result.files.find((f) => f.path === 'lib/core/widgets/app_navigation.dart');
    expect(navWidget?.contents).toContain('Drawer');
    expect(navWidget?.contents).toContain("'Orders'");

    const routesFile = result.files.find((f) => f.path === 'lib/config/app_routes.dart');
    expect(routesFile?.contents).toContain("'/orders': (context) => const OrdersScreen(),");
  });

  it('bundles uploaded database file into assets/db/ and updates pubspec.yaml', () => {
    const config = defaultConfig();
    config['database.file'] = {
      name: 'sample_store.db',
      size: 45000,
      extension: '.db',
      contentBase64: Buffer.from('MOCK_SQLITE_DATA').toString('base64'),
    };

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('assets/db/sample_store.db');
    const pubspec = result.files.find((f) => f.path === 'pubspec.yaml');
    expect(pubspec?.contents).toContain('assets/db/');
  });

  it('includes custom visual screens and route table when visual screens are passed', () => {
    const config = defaultConfig();
    const screens = [
      {
        id: 'sc-1',
        name: 'Home Dashboard',
        route: '/',
        isInitial: true,
        components: [
          {
            id: 'c1',
            type: 'appbar' as const,
            name: 'Top Bar',
            props: { title: 'Welcome' },
          },
        ],
      },
      {
        id: 'sc-2',
        name: 'Settings View',
        route: '/settings',
        components: [
          {
            id: 'c2',
            type: 'button' as const,
            name: 'Save Button',
            props: { label: 'Save' },
          },
        ],
      },
    ];

    const result = generateProject(config, screens);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/screens/home_dashboard_page.dart');
    expect(paths).toContain('lib/screens/settings_view_page.dart');
    expect(paths).toContain('lib/screens/app_routes.dart');

    const appDart = result.files.find((f) => f.path === 'lib/app.dart');
    expect(appDart?.contents).toContain("import 'screens/app_routes.dart';");
    expect(appDart?.contents).toContain('initialRoute: AppRoutes.initialRoute,');
    expect(appDart?.contents).toContain('routes: AppRoutes.routes,');
  });

  it('generates AMOLED true black theme and design tokens when amoled themeMode is chosen', () => {
    const config = defaultConfig();
    config['frontend.themeMode'] = 'amoled';
    config['frontend.uiStyle'] = 'glassmorphism';

    const result = generateProject(config);
    const themeDart = result.files.find((f) => f.path === 'lib/core/theme/app_theme.dart');
    const designTokensDart = result.files.find((f) => f.path === 'lib/core/theme/design_tokens.dart');
    const appDart = result.files.find((f) => f.path === 'lib/app.dart');

    expect(themeDart?.contents).toContain('scaffoldBackgroundColor: const Color(0xFF000000)');
    expect(themeDart?.contents).toContain('static ThemeData get amoledTheme');
    expect(designTokensDart?.contents).toContain('final bool isAmoled');
    expect(appDart?.contents).toContain('themeMode: ThemeMode.dark');
  });

  it('generates Neo-Brutalism borders and Sepia warm colors when configured', () => {
    const config = defaultConfig();
    config['frontend.themeMode'] = 'sepia';
    config['frontend.uiStyle'] = 'neo_brutalism';

    const result = generateProject(config);
    const themeDart = result.files.find((f) => f.path === 'lib/core/theme/app_theme.dart');

    expect(themeDart?.contents).toContain('scaffoldBackgroundColor: const Color(0xFFFBF0D9)');
    expect(themeDart?.contents).toContain('BorderSide(color: Colors.black, width: 3.0)');
    expect(themeDart?.contents).toContain('elevatedButtonTheme');
  });

  it('generates enterprise auth flow screens and repository when authentication feature is enabled', () => {
    const config = defaultConfig();
    config['features.selected'] = ['authentication'];

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/features/auth/models/user_model.dart');
    expect(paths).toContain('lib/features/auth/repositories/auth_repository.dart');
    expect(paths).toContain('lib/features/auth/screens/login_screen.dart');
    expect(paths).toContain('lib/features/auth/screens/register_screen.dart');
    expect(paths).toContain('lib/features/auth/screens/forgot_password_screen.dart');
    expect(paths).toContain('lib/features/auth/widgets/social_login_buttons.dart');

    const routesFile = result.files.find((f) => f.path === 'lib/config/app_routes.dart');
    expect(routesFile?.contents).toContain("'/login': (context) => const LoginScreen()");
  });

  it('generates multi-environment flavors and .env files when configured', () => {
    const config = defaultConfig();
    config['project.environmentFlavor'] = 'full_flavors';

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/config/app_config.dart');
    expect(paths).toContain('lib/main_dev.dart');
    expect(paths).toContain('lib/main_staging.dart');
    expect(paths).toContain('lib/main_prod.dart');
    expect(paths).toContain('assets/env/dev.env');
    expect(paths).toContain('assets/env/prod.env');
  });

  it('generates CI/CD workflows, RBAC guards, Design Token exports, and i18n files', () => {
    const config = defaultConfig();
    config['project.cicdPlatform'] = 'github_actions';
    config['security.enableRbac'] = true;
    config['project.locale'] = 'hi';

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('.github/workflows/ci.yml');
    expect(paths).toContain('.github/workflows/build-android.yml');
    expect(paths).toContain('lib/core/auth/models/user_role.dart');
    expect(paths).toContain('lib/core/auth/guards/role_guard.dart');
    expect(paths).toContain('tokens/figma-tokens.json');
    expect(paths).toContain('tokens/css-variables.css');
    expect(paths).toContain('tokens/tailwind-theme.js');
    expect(paths).toContain('l10n.yaml');
    expect(paths).toContain('lib/l10n/app_en.arb');
    expect(paths).toContain('lib/l10n/app_hi.arb');
  });
});
