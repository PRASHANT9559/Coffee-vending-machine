import { describe, it, expect } from 'vitest';
import {
  defaultConfig,
  extractProtectedRegions,
  mergeHybridFile,
  computeMergeAction,
  scanExistingProject,
  generateSqlMigration,
  generateMermaidErd,
  type DatabaseDesignSchema,
  parseCliArgs,
  serializeSwatiYaml,
  validateSwatiConfig,
  generateSwatiJsonSchema,
} from '@swati/schema';
import { generateProject } from '@swati/generator';

describe('Enterprise Features Part 2 (#26 to #40) Test Suite', () => {
  // -------------------------------------------------------------
  // Feature 26: Regeneration-Safe Codegen
  // -------------------------------------------------------------
  describe('26. Regeneration-Safe Codegen', () => {
    it('extracts custom protected regions from hybrid files', () => {
      const code = `
import 'package:flutter/material.dart';
// <swati:custom-imports>
import 'package:my_pkg/my_custom_code.dart';
// </swati:custom-imports>

void main() {
  // <swati:custom-init>
  initCustomSdk();
  // </swati:custom-init>
  runApp(const MyApp());
}
`;
      const regions = extractProtectedRegions(code);
      expect(regions.has('custom-imports')).toBe(true);
      expect(regions.get('custom-imports')).toContain('import \'package:my_pkg/my_custom_code.dart\';');
      expect(regions.has('custom-init')).toBe(true);
      expect(regions.get('custom-init')).toContain('initCustomSdk();');
    });

    it('merges custom user regions safely into newly generated templates', () => {
      const existingUserFile = `
void main() {
  // <swati:custom-init>
  await CustomService.boot();
  // </swati:custom-init>
  runApp(const MyApp());
}
`;
      const newlyGeneratedTemplate = `
void main() {
  // <swati:custom-init>
  // default blank
  // </swati:custom-init>
  runApp(const MyApp());
}
`;
      const merged = mergeHybridFile(newlyGeneratedTemplate, existingUserFile);
      expect(merged).toContain('await CustomService.boot();');
      expect(merged).not.toContain('// default blank');
    });

    it('computeMergeAction respects scaffold, generated, and hybrid file ownerships', () => {
      // 1. Scaffold file owned by user -> skip
      const scaffoldAction = computeMergeAction(
        'lib/features/home/home_screen.dart',
        'scaffold',
        'old base',
        'user custom screen content',
        'new template content'
      );
      expect(scaffoldAction.action).toBe('skip');
      expect(scaffoldAction.result).toBe('user custom screen content');

      // 2. Generated file owned by wizard -> overwrite
      const generatedAction = computeMergeAction(
        'lib/config/app_routes.dart',
        'generated',
        'old base',
        'modified',
        'brand new routes'
      );
      expect(generatedAction.action).toBe('overwrite');
      expect(generatedAction.result).toBe('brand new routes');

      // 3. Hybrid file -> merge protected regions
      const hybridAction = computeMergeAction(
        'lib/main.dart',
        'hybrid',
        'base',
        '// <swati:custom-init>\nmyCode();\n// </swati:custom-init>',
        '// <swati:custom-init>\n// empty\n// </swati:custom-init>'
      );
      expect(hybridAction.action).toBe('merge');
      expect(hybridAction.result).toContain('myCode();');
    });
  });

  // -------------------------------------------------------------
  // Feature 27: Brownfield Mode — Existing Project Import
  // -------------------------------------------------------------
  describe('27. Brownfield Mode — Existing Project Import', () => {
    it('detects state management, backend, architecture, and recommends missing addons', () => {
      const mockPubspec = `
name: existing_corp_app
dependencies:
  flutter:
    sdk: flutter
  flutter_riverpod: ^2.5.1
  supabase_flutter: ^2.6.0
  dio: ^5.4.0
`;
      const mockDirectories = [
        'lib/features/auth',
        'lib/features/products',
      ];

      const detected = scanExistingProject(mockPubspec, mockDirectories);
      expect(detected.isFlutterProject).toBe(true);
      expect(detected.stateManagement).toBe('riverpod');
      expect(detected.backend).toBe('supabase');
      expect(detected.architecture).toBe('feature_first');
      expect(detected.recommendedAddons).toContain('i18n');
      expect(detected.recommendedAddons).toContain('cicd_pipeline');
      expect(detected.recommendedAddons).toContain('push_notifications');
    });
  });

  // -------------------------------------------------------------
  // Feature 28: Database Schema Designer
  // -------------------------------------------------------------
  describe('28. Database Schema Designer', () => {
    const testSchema: DatabaseDesignSchema = {
      version: '20261103000000',
      tables: [
        {
          name: 'users',
          enableRls: true,
          columns: [
            { name: 'id', type: 'uuid', isPrimary: true },
            { name: 'email', type: 'text', isUnique: true },
            { name: 'name', type: 'text' },
          ],
        },
        {
          name: 'orders',
          enableRls: true,
          columns: [
            { name: 'id', type: 'uuid', isPrimary: true },
            { name: 'user_id', type: 'uuid', foreignKeyTable: 'users', foreignKeyColumn: 'id' },
            { name: 'total', type: 'numeric' },
          ],
        },
      ],
    };

    it('generates valid SQL migrations with UUID primary keys and RLS policies', () => {
      const sql = generateSqlMigration(testSchema);
      expect(sql).toContain('CREATE EXTENSION IF NOT EXISTS "uuid-ossp";');
      expect(sql).toContain('CREATE TABLE IF NOT EXISTS public.users');
      expect(sql).toContain('id UUID PRIMARY KEY');
      expect(sql).toContain('email TEXT NOT NULL UNIQUE');
      expect(sql).toContain('ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;');
      expect(sql).toContain('REFERENCES public.users(id)');
    });

    it('generates Mermaid ERD diagrams for schema visualization', () => {
      const mmd = generateMermaidErd(testSchema);
      expect(mmd).toContain('erDiagram');
      expect(mmd).toContain('users {');
      expect(mmd).toContain('uuid id');
      expect(mmd).toContain('users ||--o{ orders : "has"');
    });
  });

  // -------------------------------------------------------------
  // Full Project Generation Verification (#29 to #40)
  // -------------------------------------------------------------
  describe('Full Project Generation Verification (#29 to #40)', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    it('28. Database schema migration & ERD are generated in the project', () => {
      expect(paths).toContain('supabase/migrations/20261103000000_init_schema.sql');
      expect(paths).toContain('docs/erd.mmd');
    });

    it('29. CRUD Scaffolder generates complete Product module', () => {
      expect(paths).toContain('lib/features/products/models/product_model.dart');
      expect(paths).toContain('lib/features/products/repositories/product_repository.dart');
      expect(paths).toContain('lib/features/products/controllers/product_controller.dart');
      expect(paths).toContain('lib/features/products/screens/product_list_screen.dart');
      expect(paths).toContain('lib/features/products/screens/product_detail_screen.dart');
      expect(paths).toContain('lib/features/products/screens/product_form_screen.dart');
      expect(paths).toContain('lib/features/products/widgets/product_card.dart');

      const model = result.files.find((f) => f.path === 'lib/features/products/models/product_model.dart');
      expect(model?.contents).toContain('class ProductModel');
      expect(model?.contents).toContain('factory ProductModel.fromJson');
    });

    it('30. Push Notification Setup generates channels, handlers, and routers', () => {
      expect(paths).toContain('lib/core/notifications/models/notification_payload.dart');
      expect(paths).toContain('lib/core/notifications/notification_channels.dart');
      expect(paths).toContain('lib/core/notifications/notification_router.dart');
      expect(paths).toContain('lib/core/notifications/local_notification_service.dart');
      expect(paths).toContain('lib/core/notifications/fcm_handler.dart');
      expect(paths).toContain('lib/core/notifications/notification_service.dart');

      const channels = result.files.find((f) => f.path === 'lib/core/notifications/notification_channels.dart');
      expect(channels?.contents).toContain('ordersChannelId');
      expect(channels?.contents).toContain('chatChannelId');

      const router = result.files.find((f) => f.path === 'lib/core/notifications/notification_router.dart');
      expect(router?.contents).toContain('class NotificationRouter');
      expect(router?.contents).toContain('handleNotificationTap');
    });

    it('31. Remote Config, Force Update & Maintenance Mode generates service and gates', () => {
      expect(paths).toContain('lib/core/remote_config/remote_keys.dart');
      expect(paths).toContain('lib/core/remote_config/app_version_checker.dart');
      expect(paths).toContain('lib/core/remote_config/remote_config_service.dart');
      expect(paths).toContain('lib/core/remote_config/feature_flags.dart');
      expect(paths).toContain('lib/core/remote_config/maintenance_gate.dart');
      expect(paths).toContain('lib/core/remote_config/update_dialog.dart');
      expect(paths).toContain('lib/core/remote_config/widgets/feature_gate.dart');
      expect(paths).toContain('docs/REMOTE-CONFIG.md');

      const checker = result.files.find((f) => f.path === 'lib/core/remote_config/app_version_checker.dart');
      expect(checker?.contents).toContain('compareSemver');
      expect(checker?.contents).toContain('isUpdateRequired');
    });

    it('32. Backend Scaffold Generator generates OpenAPI spec, Dockerfile, and docker-compose', () => {
      expect(paths).toContain('backend/openapi.yaml');
      expect(paths).toContain('backend/Dockerfile');
      expect(paths).toContain('backend/docker-compose.yml');
      expect(paths).toContain('backend/.env.example');
      expect(paths).toContain('backend/routes/health.dart');
      expect(paths).toContain('backend/routes/products.dart');
      expect(paths).toContain('backend/README.md');

      const openapi = result.files.find((f) => f.path === 'backend/openapi.yaml');
      expect(openapi?.contents).toContain('openapi: 3.0.3');
      expect(openapi?.contents).toContain('/auth/login');
      expect(openapi?.contents).toContain('/products');
      expect(openapi?.contents).toContain('/health');
    });

    it('33. Legal & Store Compliance Kit generates GDPR docs, account deletion flow, and data safety cheatsheet', () => {
      expect(paths).toContain('legal/privacy_policy.md');
      expect(paths).toContain('legal/privacy_policy.html');
      expect(paths).toContain('legal/terms_of_service.md');
      expect(paths).toContain('legal/account_deletion.html');
      expect(paths).toContain('legal/DATA-SAFETY-CHEATSHEET.md');
      expect(paths).toContain('lib/features/legal/screens/privacy_policy_screen.dart');
      expect(paths).toContain('lib/features/legal/screens/terms_screen.dart');
      expect(paths).toContain('lib/features/legal/screens/delete_account_screen.dart');
      expect(paths).toContain('lib/features/legal/controllers/account_deletion_controller.dart');
      expect(paths).toContain('lib/features/legal/widgets/consent_dialog.dart');

      const cheatsheet = result.files.find((f) => f.path === 'legal/DATA-SAFETY-CHEATSHEET.md');
      expect(cheatsheet?.contents).toContain('Data Safety Questionnaire Cheatsheet');
    });

    it('34. Standard UI States Kit generates async views, skeletons, empty/error views, and error mappers', () => {
      expect(paths).toContain('lib/core/errors/failure.dart');
      expect(paths).toContain('lib/core/errors/error_mapper.dart');
      expect(paths).toContain('lib/core/widgets/states/loading_view.dart');
      expect(paths).toContain('lib/core/widgets/states/skeleton_list.dart');
      expect(paths).toContain('lib/core/widgets/states/empty_view.dart');
      expect(paths).toContain('lib/core/widgets/states/error_view.dart');
      expect(paths).toContain('lib/core/widgets/states/offline_banner.dart');
      expect(paths).toContain('lib/core/widgets/states/permission_denied_view.dart');
      expect(paths).toContain('lib/core/widgets/states/paginated_footer.dart');
      expect(paths).toContain('lib/core/widgets/states/async_value_view.dart');

      const asyncView = result.files.find((f) => f.path === 'lib/core/widgets/states/async_value_view.dart');
      expect(asyncView?.contents).toContain('class AsyncValueView<T>');
    });

    it('35. App Icon, Splash & Branding Generator generates yaml configs and guidelines', () => {
      expect(paths).toContain('flutter_launcher_icons.yaml');
      expect(paths).toContain('flutter_native_splash.yaml');
      expect(paths).toContain('assets/branding/README.md');
      expect(paths).toContain('store_assets/README.md');

      const launcherIcons = result.files.find((f) => f.path === 'flutter_launcher_icons.yaml');
      expect(launcherIcons?.contents).toContain('adaptive_icon_background');
      expect(launcherIcons?.contents).toContain('adaptive_icon_foreground');
    });

    it('36. Mock Data & Fake Server generates fixtures, mock generator, and mock server', () => {
      expect(paths).toContain('lib/core/mock/fixtures/products.json');
      expect(paths).toContain('lib/core/mock/fixtures/orders.json');
      expect(paths).toContain('lib/core/mock/fixtures/users.json');
      expect(paths).toContain('lib/core/mock/mock_data_generator.dart');
      expect(paths).toContain('lib/core/mock/mock_interceptor.dart');
      expect(paths).toContain('lib/core/mock/repositories/mock_product_repository.dart');
      expect(paths).toContain('tools/mock_server/server.dart');

      const mockGen = result.files.find((f) => f.path === 'lib/core/mock/mock_data_generator.dart');
      expect(mockGen?.contents).toContain('class MockDataGenerator');
    });

    it('37. Accessibility & Responsive / Adaptive Layouts generates responsive builders and contrast checks', () => {
      expect(paths).toContain('lib/core/responsive/breakpoints.dart');
      expect(paths).toContain('lib/core/responsive/responsive_builder.dart');
      expect(paths).toContain('lib/core/responsive/adaptive_scaffold.dart');
      expect(paths).toContain('lib/core/responsive/max_content_width.dart');
      expect(paths).toContain('lib/core/accessibility/semantics_helpers.dart');
      expect(paths).toContain('lib/core/accessibility/contrast_checker.dart');
      expect(paths).toContain('test/accessibility/text_scale_test.dart');

      const scaffold = result.files.find((f) => f.path === 'lib/core/responsive/adaptive_scaffold.dart');
      expect(scaffold?.contents).toContain('class AdaptiveScaffold');
      expect(scaffold?.contents).toContain('NavigationRail');
      expect(scaffold?.contents).toContain('NavigationBar');
    });

    it('38. App Size & Performance Budget generates proguard rules, release scripts, and size report', () => {
      expect(paths).toContain('android/app/proguard-rules.pro');
      expect(paths).toContain('scripts/build_release.sh');
      expect(paths).toContain('scripts/size_report.sh');
      expect(paths).toContain('lib/core/bootstrap/app_bootstrap.dart');
      expect(paths).toContain('docs/SIZE-REPORT.md');

      const bootstrap = result.files.find((f) => f.path === 'lib/core/bootstrap/app_bootstrap.dart');
      expect(bootstrap?.contents).toContain('class AppBootstrap');
      expect(bootstrap?.contents).toContain('initCriticalServices');
      expect(bootstrap?.contents).toContain('initDeferredServices');
    });

    it('39. Auto Documentation Generator generates full docs suite, ADRs, CONTRIBUTING and CHANGELOG', () => {
      expect(paths).toContain('docs/ARCHITECTURE.md');
      expect(paths).toContain('docs/DATABASE.md');
      expect(paths).toContain('docs/ONBOARDING.md');
      expect(paths).toContain('docs/adr/0001-state-management.md');
      expect(paths).toContain('docs/adr/0002-backend.md');
      expect(paths).toContain('docs/adr/0003-architecture.md');
      expect(paths).toContain('CONTRIBUTING.md');
      expect(paths).toContain('CHANGELOG.md');

      const arch = result.files.find((f) => f.path === 'docs/ARCHITECTURE.md');
      expect(arch?.contents).toContain('flowchart TD');
      expect(arch?.contents).toContain('Presentation Layer');
    });

    it('40. Headless CLI Mode & Config-as-Code generates swati.yaml and .swati schema/manifest', () => {
      expect(paths).toContain('swati.yaml');
      expect(paths).toContain('.swati/schema/swati.schema.json');
      expect(paths).toContain('.swati/manifest.json');

      const swatiYaml = result.files.find((f) => f.path === 'swati.yaml');
      expect(swatiYaml?.contents).toContain('schemaVersion: 3');
      expect(swatiYaml?.contents).toContain('stack:');
    });

    it('40. CLI argument parser and config validator execute correctly', () => {
      const parsedInit = parseCliArgs(['init', '--template', 'e-commerce']);
      expect(parsedInit.command).toBe('init');
      expect(parsedInit.options.template).toBe('e-commerce');

      const parsedDoctor = parseCliArgs(['doctor']);
      expect(parsedDoctor.command).toBe('doctor');

      const parsedAdd = parseCliArgs(['add', 'auth', '--methods', 'email,google']);
      expect(parsedAdd.command).toBe('add');
      expect(parsedAdd.options.methods).toEqual(['email', 'google']);

      const validationValid = validateSwatiConfig(config);
      expect(validationValid.valid).toBe(true);

      const jsonSchema = generateSwatiJsonSchema();
      expect(jsonSchema.title).toBe('SwatiStudioConfig');
    });
  });
});
