import { extractProtectedRegions, mergeHybridFile, computeMergeAction } from '../packages/schema/src/codegenSafety.ts';
import { scanExistingProject } from '../packages/schema/src/brownfieldScanner.ts';
import { generateSqlMigration, generateMermaidErd, type DatabaseDesignSchema } from '../packages/schema/src/schemaDesigner.ts';
import { parseCliArgs } from '../packages/schema/src/cliConfig.ts';

console.log('🧪 Testing Part 2 Standalone Logic...');

// 26. Codegen Safety
const regions = extractProtectedRegions('// <swati:custom-init>\nmyCode();\n// </swati:custom-init>');
if (!regions.has('custom-init') || !regions.get('custom-init')?.includes('myCode();')) {
  throw new Error('Failed: extractProtectedRegions');
}
const merged = mergeHybridFile('// <swati:custom-init>\ndefault\n// </swati:custom-init>', '// <swati:custom-init>\nuserCode\n// </swati:custom-init>');
if (!merged.includes('userCode') || merged.includes('default')) {
  throw new Error('Failed: mergeHybridFile');
}
const action1 = computeMergeAction('test.dart', 'scaffold', null, 'existing', 'new');
if (action1.action !== 'skip') throw new Error('Failed: scaffold skip');
const action2 = computeMergeAction('test.dart', 'generated', null, 'existing', 'new');
if (action2.action !== 'overwrite') throw new Error('Failed: generated overwrite');
console.log('✅ Feature 26: Codegen Safety OK');

// 27. Brownfield Scanner
const scan = scanExistingProject('dependencies:\n  flutter:\n    sdk: flutter\n  flutter_riverpod: ^2.5.0\n  supabase_flutter: ^2.0.0\n');
if (scan.stateManagement !== 'riverpod' || scan.backend !== 'supabase') {
  throw new Error('Failed: scanExistingProject');
}
console.log('✅ Feature 27: Brownfield Scanner OK');

// 28. Schema Designer
const schema: DatabaseDesignSchema = {
  version: '1.0',
  tables: [{
    name: 'users',
    enableRls: true,
    columns: [{ name: 'id', type: 'uuid', isPrimary: true }, { name: 'email', type: 'text', isUnique: true }]
  }]
};
const sql = generateSqlMigration(schema);
if (!sql.includes('CREATE TABLE IF NOT EXISTS public.users') || !sql.includes('ENABLE ROW LEVEL SECURITY')) {
  throw new Error('Failed: generateSqlMigration');
}
const erd = generateMermaidErd(schema);
if (!erd.includes('erDiagram') || !erd.includes('users {')) {
  throw new Error('Failed: generateMermaidErd');
}
console.log('✅ Feature 28: Schema Designer OK');

// 40. CLI Parser
const cli = parseCliArgs(['init', '--template', 'e-commerce']);
if (cli.command !== 'init' || cli.options.template !== 'e-commerce') {
  throw new Error('Failed: parseCliArgs');
}
const cliDoctor = parseCliArgs(['doctor']);
if (cliDoctor.command !== 'doctor') {
  throw new Error('Failed: parseCliArgs doctor');
}
console.log('✅ Feature 40: CLI Parser OK');

console.log('🎉 All standalone logic unit tests passed successfully!');
