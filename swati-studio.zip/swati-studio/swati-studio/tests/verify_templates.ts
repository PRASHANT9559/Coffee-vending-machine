import { templateCrudFiles } from '../packages/generator/src/templates/crudDart.ts';
import { templatePushNotificationFiles } from '../packages/generator/src/templates/pushNotificationsDart.ts';
import { templateRemoteConfigFiles } from '../packages/generator/src/templates/remoteConfigDart.ts';
import { templateBackendScaffold } from '../packages/generator/src/templates/backendScaffold.ts';
import { templateComplianceFiles } from '../packages/generator/src/templates/complianceFiles.ts';
import { templateUiStatesFiles } from '../packages/generator/src/templates/uiStatesDart.ts';
import { templateBrandingFiles } from '../packages/generator/src/templates/brandingFiles.ts';
import { templateMockDataFiles } from '../packages/generator/src/templates/mockDataDart.ts';
import { templateResponsiveFiles } from '../packages/generator/src/templates/responsiveDart.ts';
import { templatePerfBudgetFiles } from '../packages/generator/src/templates/perfBudgetFiles.ts';
import { templateAutoDocsFiles } from '../packages/generator/src/templates/autoDocsFiles.ts';
import { templateConfigAsCodeFiles } from '../packages/generator/src/templates/configAsCode.ts';
import type { GenContext } from '../packages/generator/src/types.ts';

console.log('🧪 Testing Part 2 Template Generation (#29 to #40)...');

const mockCtx: GenContext = {
  name: 'Swati Enterprise App',
  slug: 'swati_enterprise_app',
  package: 'com.example.swati_enterprise_app',
  description: 'An enterprise Flutter application',
  stateManagement: 'riverpod',
  backend: 'supabase',
  architecture: 'feature_first',
  database: 'postgresql',
  navigationStyle: 'bottom_nav',
  themeAesthetic: 'material_you',
  themeColorHex: '#6366F1',
  themePalette: 'indigo',
  authEnabled: true,
  authScreens: ['login', 'register'],
  features: ['products', 'orders'],
  navigationItems: [],
  screens: [],
  packages: [],
  environments: ['dev', 'staging', 'prod'],
  rawConfig: {} as any,
};

const checks: [string, () => any[], string[]][] = [
  ['29. CRUD Scaffolder', () => templateCrudFiles(mockCtx), ['product_model.dart', 'product_list_screen.dart']],
  ['30. Push Notifications', () => templatePushNotificationFiles(mockCtx), ['notification_service.dart', 'fcm_handler.dart']],
  ['31. Remote Config', () => templateRemoteConfigFiles(mockCtx), ['remote_config_service.dart', 'maintenance_gate.dart']],
  ['32. Backend Scaffold', () => templateBackendScaffold(mockCtx), ['openapi.yaml', 'Dockerfile', 'docker-compose.yml']],
  ['33. Legal & Compliance', () => templateComplianceFiles(mockCtx), ['privacy_policy.html', 'account_deletion.html', 'DATA-SAFETY-CHEATSHEET.md']],
  ['34. UI States Kit', () => templateUiStatesFiles(mockCtx), ['async_value_view.dart', 'loading_view.dart', 'failure.dart']],
  ['35. Branding & Splash', () => templateBrandingFiles(mockCtx), ['flutter_launcher_icons.yaml', 'flutter_native_splash.yaml']],
  ['36. Mock Data & Server', () => templateMockDataFiles(mockCtx), ['mock_data_generator.dart', 'products.json', 'server.dart']],
  ['37. Responsive & A11y', () => templateResponsiveFiles(mockCtx), ['breakpoints.dart', 'adaptive_scaffold.dart', 'contrast_checker.dart']],
  ['38. Perf & Size Budget', () => templatePerfBudgetFiles(mockCtx), ['proguard-rules.pro', 'build_release.sh', 'SIZE-REPORT.md']],
  ['39. Auto Docs', () => templateAutoDocsFiles(mockCtx), ['ARCHITECTURE.md', 'DATABASE.md', 'ONBOARDING.md']],
  ['40. Config as Code', () => templateConfigAsCodeFiles(mockCtx), ['swati.yaml', 'swati.schema.json', 'manifest.json']],
];

for (const [name, fn, expectedSnippets] of checks) {
  const files = fn();
  if (files.length === 0) throw new Error(`${name} returned 0 files!`);
  const paths = files.map(f => f.path);
  for (const snippet of expectedSnippets) {
    const found = paths.some(p => p.includes(snippet));
    if (!found) throw new Error(`${name} missing expected file containing: ${snippet}`);
  }
  console.log(`✅ ${name} OK (${files.length} files generated)`);
}

console.log('🎉 All template generator tests passed successfully with 100% assertions satisfied!');
