import { describe, it, expect } from 'vitest';
import {
  defaultConfig,
  validateConfig,
  serializeConfig,
  parseConfig,
  buildSummary,
  reversePubspec,
  themeOptions,
  createCustomPalette,
} from '@swati/schema';

describe('Schema & Config Engine', () => {
  it('generates a valid default configuration', () => {
    const config = defaultConfig();
    expect(config).toBeDefined();
    expect(config['project.name']).toBe('My Flutter App');
    expect(config['project.packageName']).toBe('com.example.my_flutter_app');

    // Required provider credentials are intentionally blank on a fresh config
    // (the wizard asks for them on the Backend step) — fill them in and the
    // rest of the defaults must validate with zero errors.
    config['backend.supabase.url'] = 'https://example.supabase.co';
    config['backend.supabase.anonKey'] = 'test-anon-key';

    const issues = validateConfig(config);
    const errors = issues.filter((i) => i.severity === 'error');
    expect(errors.length).toBe(0);
  });

  it('validates invalid package names correctly', () => {
    const config = defaultConfig();
    config['project.packageName'] = 'INVALID-PACKAGE-NAME!';
    const issues = validateConfig(config);
    const pkgError = issues.find((i) => i.field === 'project.packageName');
    expect(pkgError).toBeDefined();
    expect(pkgError?.severity).toBe('error');
  });

  it('serializes and parses config round-trip without data loss', () => {
    const original = defaultConfig();
    original['project.name'] = 'RoundTrip App';
    original['features.selected'] = ['auth', 'notifications'];

    const json = serializeConfig(original);
    const parsed = parseConfig(json);

    expect(parsed['project.name']).toBe('RoundTrip App');
    expect(parsed['features.selected']).toEqual(['auth', 'notifications']);
  });

  it('builds summary rows from schema options', () => {
    const config = defaultConfig();
    const rows = buildSummary(config);
    expect(rows.length).toBeGreaterThan(5);
    const projectRow = rows.find((r) => r.label === 'Project Name');
    expect(projectRow?.value).toBe('My Flutter App');
  });

  it('reverse-engineers a pubspec.yaml file accurately', () => {
    const samplePubspec = `
name: super_ecommerce_app
description: A high performance Flutter online store.
version: 2.1.0

dependencies:
  flutter:
    sdk: flutter
  flutter_riverpod: ^2.5.1
  supabase_flutter: ^2.6.0
  isar: ^3.1.0
  google_maps_flutter: ^2.5.0
  camera: ^0.10.5
`;

    const { config, detected } = reversePubspec(samplePubspec);

    expect(config['project.name']).toBe('super ecommerce app');
    expect(config['project.packageName']).toBe('com.example.super_ecommerce_app');
    expect(config['project.version']).toBe('2.1.0');
    expect(detected.stateManager).toBe('riverpod');
    expect(detected.backend).toBe('supabase');
    expect(detected.database).toBe('isar');
    expect(detected.features).toContain('maps');
    expect(detected.features).toContain('camera');
  });

  it('does not produce false positives for path_provider or get_it in reversePubspec', () => {
    const yamlWithSimilarNames = `
name: utility_app
description: Utility tools
dependencies:
  path_provider: ^2.1.2
  get_it: ^7.6.0
`;
    const { detected } = reversePubspec(yamlWithSimilarNames);
    expect(detected.stateManager).toBeUndefined();
  });

  it('creates custom dynamic theme palettes', () => {
    const custom = createCustomPalette('Neon Purple', '#8B5CF6', '#F43F5E');
    expect(custom.name).toBe('Neon Purple');
    expect(custom.light.blue).toBe('#8B5CF6');
    expect(custom.dark.pink).toBe('#F43F5E');
  });

  it('contains 20 production theme options', () => {
    expect(themeOptions.length).toBe(20);
  });

  it('validates navigation items minimum requirement (at least 2)', () => {
    const config = defaultConfig();
    config['navigation.items'] = [
      { id: '1', name: 'Home', icon: 'Home', route: '/home', title: 'Home' },
    ];
    const issues = validateConfig(config);
    expect(issues.some((i) => i.field === 'navigation.items' && i.severity === 'error')).toBe(true);
  });
});
