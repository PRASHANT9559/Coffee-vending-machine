import { describe, it, expect } from 'vitest';
import {
  defaultConfig,
  enterpriseTemplates,
  analyzeAppPrompt,
  authMethods,
  defaultRbacRoles,
  environmentOptions,
  cicdPlatforms,
} from '@swati/schema';
import { generateProject } from '@swati/generator';

describe('Enterprise Features Test Suite', () => {
  it('1. App Template Marketplace (Step 0) has comprehensive enterprise presets', () => {
    expect(enterpriseTemplates.length).toBeGreaterThanOrEqual(10);

    const ecommerce = enterpriseTemplates.find((t) => t.id === 'ecommerce');
    expect(ecommerce).toBeDefined();
    expect(ecommerce?.presetConfig['backend.provider']).toBe('supabase');
    expect(ecommerce?.presetConfig['features.selected']).toContain('payments');

    const foodDelivery = enterpriseTemplates.find((t) => t.id === 'food_delivery');
    expect(foodDelivery).toBeDefined();
    expect(foodDelivery?.presetConfig['features.selected']).toContain('maps');
  });

  it('2. AI-Powered Smart Wizard parses prompt and outputs tailored configuration', () => {
    const prompt = 'I want to build an enterprise healthcare app with patient records, teleconsultation and biometrics';
    const recommendation = analyzeAppPrompt(prompt);

    expect(recommendation.matchedTemplateId).toBe('healthcare');
    expect(recommendation.detectedKeywords).toContain('healthcare');
    expect(recommendation.config['project.name']).toBeDefined();
    expect(recommendation.config['navigation.items']).toBeDefined();
    expect(recommendation.confidence).toBeGreaterThan(0.7);
  });

  it('3. Authentication Flow Builder generates full auth stack', () => {
    const config = defaultConfig();
    config['features.selected'] = ['authentication'];
    config['auth.methods'] = ['email_password', 'google_oauth', 'biometric'];
    config['auth.screens'] = ['login', 'register', 'forgot_password'];

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/features/auth/models/user_model.dart');
    expect(paths).toContain('lib/features/auth/repositories/auth_repository.dart');
    expect(paths).toContain('lib/features/auth/screens/login_screen.dart');
    expect(paths).toContain('lib/features/auth/screens/register_screen.dart');
    expect(paths).toContain('lib/features/auth/screens/forgot_password_screen.dart');
    expect(paths).toContain('lib/features/auth/widgets/social_login_buttons.dart');

    const userModel = result.files.find((f) => f.path === 'lib/features/auth/models/user_model.dart');
    expect(userModel?.contents).toContain('class UserModel');

    const authRepo = result.files.find((f) => f.path === 'lib/features/auth/repositories/auth_repository.dart');
    expect(authRepo?.contents).toContain('signInWithEmail');
    expect(authRepo?.contents).toContain('signInWithGoogle');

    const routes = result.files.find((f) => f.path === 'lib/config/app_routes.dart');
    expect(routes?.contents).toContain("'/login': (context) => const LoginScreen()");
  });

  it('6. Multi-Environment & Flavor Configuration generates flavor entrypoints', () => {
    const config = defaultConfig();
    config['project.environmentFlavor'] = 'full_flavors';

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/config/app_config.dart');
    expect(paths).toContain('lib/main_dev.dart');
    expect(paths).toContain('lib/main_staging.dart');
    expect(paths).toContain('lib/main_prod.dart');
    expect(paths).toContain('assets/env/dev.env');
    expect(paths).toContain('assets/env/staging.env');
    expect(paths).toContain('assets/env/prod.env');

    const appConfig = result.files.find((f) => f.path === 'lib/config/app_config.dart');
    expect(appConfig?.contents).toContain('enum Environment { dev, staging, prod }');
    expect(appConfig?.contents).toContain('static bool get isDev');
  });

  it('7. CI/CD Pipeline Generator outputs GitHub Actions workflows', () => {
    const config = defaultConfig();
    config['project.cicdPlatform'] = 'github_actions';

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('.github/workflows/ci.yml');
    expect(paths).toContain('.github/workflows/build-android.yml');

    const ciYml = result.files.find((f) => f.path === '.github/workflows/ci.yml');
    expect(ciYml?.contents).toContain('flutter analyze');
    expect(ciYml?.contents).toContain('flutter test');
  });

  it('8. Role-Based Access Control (RBAC) Designer generates guards and widgets', () => {
    const config = defaultConfig();
    config['security.enableRbac'] = true;

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/core/auth/models/user_role.dart');
    expect(paths).toContain('lib/core/auth/guards/role_guard.dart');
    expect(paths).toContain('lib/core/auth/widgets/role_based_widget.dart');

    const roleModel = result.files.find((f) => f.path === 'lib/core/auth/models/user_role.dart');
    expect(roleModel?.contents).toContain('enum UserRole');
    expect(roleModel?.contents).toContain('bool get isAdmin => this == UserRole.admin;');
  });

  it('16. Design Token Export System outputs Figma, CSS and Tailwind tokens', () => {
    const config = defaultConfig();
    config['frontend.customColor'] = '#00F6FF';
    config['frontend.themeColor'] = 'custom';
    config['frontend.borderRadius'] = 16;

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('tokens/figma-tokens.json');
    expect(paths).toContain('tokens/css-variables.css');
    expect(paths).toContain('tokens/tailwind-theme.js');

    const figma = result.files.find((f) => f.path === 'tokens/figma-tokens.json');
    expect(figma?.contents).toContain('#00F6FF');
    expect(figma?.contents).toContain('16px');

    const cssVars = result.files.find((f) => f.path === 'tokens/css-variables.css');
    expect(cssVars?.contents).toContain('--app-primary: #00F6FF');
  });

  it('11. Internationalization (i18n) generates ARB and locale provider', () => {
    const config = defaultConfig();
    config['project.locale'] = 'hi';

    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('l10n.yaml');
    expect(paths).toContain('lib/l10n/app_en.arb');
    expect(paths).toContain('lib/l10n/app_hi.arb');
    expect(paths).toContain('lib/core/localization/locale_provider.dart');

    const arbEn = result.files.find((f) => f.path === 'lib/l10n/app_en.arb');
    expect(arbEn?.contents).toContain('"@@locale": "en"');

    const arbHi = result.files.find((f) => f.path === 'lib/l10n/app_hi.arb');
    expect(arbHi?.contents).toContain('"@@locale": "hi"');
  });
});
