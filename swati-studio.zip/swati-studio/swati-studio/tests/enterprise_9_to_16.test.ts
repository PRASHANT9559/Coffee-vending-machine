import { describe, it, expect } from 'vitest';
import { defaultConfig } from '@swati/schema';
import { generateProject } from '@swati/generator';

describe('Enterprise Features 9 to 16 Test Suite', () => {
  it('9. Onboarding Flow Builder generates complete slide sequence and controller', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/features/onboarding/models/onboarding_data.dart');
    expect(paths).toContain('lib/features/onboarding/controllers/onboarding_controller.dart');
    expect(paths).toContain('lib/features/onboarding/widgets/dot_indicator.dart');
    expect(paths).toContain('lib/features/onboarding/widgets/onboarding_slide.dart');
    expect(paths).toContain('lib/features/onboarding/screens/onboarding_screen.dart');

    const screen = result.files.find((f) => f.path === 'lib/features/onboarding/screens/onboarding_screen.dart');
    expect(screen?.contents).toContain('PageView.builder');
    expect(screen?.contents).toContain('Get Started');

    const routes = result.files.find((f) => f.path === 'lib/config/app_routes.dart');
    expect(routes?.contents).toContain("'/onboarding': (context) => const OnboardingScreen()");
  });

  it('10. Monetization & In-App Purchases generates paywall, IAP and Ad services', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/features/monetization/models/product_model.dart');
    expect(paths).toContain('lib/features/monetization/services/purchase_service.dart');
    expect(paths).toContain('lib/features/monetization/services/ad_service.dart');
    expect(paths).toContain('lib/features/monetization/widgets/premium_badge.dart');
    expect(paths).toContain('lib/features/monetization/widgets/banner_ad_widget.dart');
    expect(paths).toContain('lib/features/monetization/screens/paywall_screen.dart');

    const purchase = result.files.find((f) => f.path === 'lib/features/monetization/services/purchase_service.dart');
    expect(purchase?.contents).toContain('purchaseProduct');
    expect(purchase?.contents).toContain('restorePurchases');

    const routes = result.files.find((f) => f.path === 'lib/config/app_routes.dart');
    expect(routes?.contents).toContain("'/paywall': (context) => const PaywallScreen()");
  });

  it('11. Internationalization (i18n) provides multi-language ARB and picker widget', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('l10n.yaml');
    expect(paths).toContain('lib/l10n/app_en.arb');
    expect(paths).toContain('lib/l10n/app_hi.arb');
    expect(paths).toContain('lib/l10n/app_es.arb');
    expect(paths).toContain('lib/core/localization/locale_provider.dart');
    expect(paths).toContain('lib/core/localization/language_picker.dart');

    const picker = result.files.find((f) => f.path === 'lib/core/localization/language_picker.dart');
    expect(picker?.contents).toContain('PopupMenuButton');
    expect(picker?.contents).toContain('Hindi');
    expect(picker?.contents).toContain('Español');
  });

  it('12. Security & Compliance generates secure storage, SSL pinning, and legal policies', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/core/security/secure_storage.dart');
    expect(paths).toContain('lib/core/security/ssl_pinning.dart');
    expect(paths).toContain('lib/core/security/root_detection.dart');
    expect(paths).toContain('lib/core/security/app_lock.dart');
    expect(paths).toContain('lib/core/security/session_manager.dart');
    expect(paths).toContain('docs/legal/PRIVACY_POLICY.md');
    expect(paths).toContain('docs/legal/TERMS_OF_SERVICE.md');

    const privacy = result.files.find((f) => f.path === 'docs/legal/PRIVACY_POLICY.md');
    expect(privacy?.contents).toContain('GDPR Compliance');
  });

  it('13. Analytics & Crash Reporting generates event logging and screen tracking observer', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/core/analytics/analytics_service.dart');
    expect(paths).toContain('lib/core/analytics/crash_reporting.dart');
    expect(paths).toContain('lib/core/analytics/performance_monitor.dart');
    expect(paths).toContain('lib/core/analytics/analytics_navigator_observer.dart');

    const analytics = result.files.find((f) => f.path === 'lib/core/analytics/analytics_service.dart');
    expect(analytics?.contents).toContain('logEvent');
    expect(analytics?.contents).toContain('setCurrentScreen');
  });

  it('14. Deep Linking & App Links generates URI handler and domain verification files', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('lib/core/routing/deep_link_handler.dart');
    expect(paths).toContain('assets/well-known/assetlinks.json');
    expect(paths).toContain('assets/well-known/apple-app-site-association');

    const handler = result.files.find((f) => f.path === 'lib/core/routing/deep_link_handler.dart');
    expect(handler?.contents).toContain('handleUri');
    expect(handler?.contents).toContain('createUniversalLink');
  });

  it('15. Deployment & Store Listing generates ASO descriptions, keywords and signing config', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('deployment/store_listing/short_description.txt');
    expect(paths).toContain('deployment/store_listing/full_description.txt');
    expect(paths).toContain('deployment/store_listing/keywords.txt');
    expect(paths).toContain('deployment/store_listing/changelogs/v1.0.0.txt');
    expect(paths).toContain('android/key.properties.example');
    expect(paths).toContain('ios/ExportOptions.plist');

    const shortDesc = result.files.find((f) => f.path === 'deployment/store_listing/short_description.txt');
    expect(shortDesc?.contents.length).toBeLessThanOrEqual(80);
  });

  it('16. Design Token Export System outputs Figma, Style Dictionary, CSS and Tailwind tokens', () => {
    const config = defaultConfig();
    const result = generateProject(config);
    const paths = result.files.map((f) => f.path);

    expect(paths).toContain('tokens/figma-tokens.json');
    expect(paths).toContain('tokens/style-dictionary.json');
    expect(paths).toContain('tokens/css-variables.css');
    expect(paths).toContain('tokens/tailwind-theme.js');

    const styleDict = result.files.find((f) => f.path === 'tokens/style-dictionary.json');
    expect(styleDict?.contents).toContain('"brand"');
    expect(styleDict?.contents).toContain('"radius"');
  });
});
