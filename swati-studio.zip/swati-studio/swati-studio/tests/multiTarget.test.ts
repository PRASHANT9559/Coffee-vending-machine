import { describe, it, expect } from 'vitest';
import { defaultConfig } from '@swati/schema';
import {
  generateTargetProject,
  generateNextJsProject,
  generateReactNativeProject,
} from '@swati/generator';

describe('Multi-Target Generator', () => {
  it('generates a full Next.js App Router project', () => {
    const config = defaultConfig();
    const result = generateNextJsProject(config, [
      {
        id: 's1',
        name: 'Landing',
        route: '/',
        components: [
          {
            id: 'c1',
            type: 'card',
            name: 'Hero Card',
            props: { title: 'Welcome to Next.js' },
          },
        ],
      },
    ]);

    const paths = result.files.map((f) => f.path);
    expect(paths).toContain('package.json');
    expect(paths).toContain('tsconfig.json');
    expect(paths).toContain('tailwind.config.ts');
    expect(paths).toContain('src/app/layout.tsx');
    expect(paths).toContain('src/app/page.tsx');
    expect(paths).toContain('src/app/screens/landing/page.tsx');

    const pkg = JSON.parse(result.files.find((f) => f.path === 'package.json')!.contents);
    expect(pkg.dependencies.next).toBeDefined();
    expect(pkg.dependencies.react).toBeDefined();
  });

  it('generates a full React Native Expo project', () => {
    const config = defaultConfig();
    const result = generateReactNativeProject(config, [
      {
        id: 's1',
        name: 'Profile',
        route: '/profile',
        components: [
          {
            id: 'c1',
            type: 'button',
            name: 'Save Button',
            props: { label: 'Save Profile' },
          },
        ],
      },
    ]);

    const paths = result.files.map((f) => f.path);
    expect(paths).toContain('package.json');
    expect(paths).toContain('app.json');
    expect(paths).toContain('App.tsx');
    expect(paths).toContain('src/screens/ProfileScreen.tsx');

    const appCode = result.files.find((f) => f.path === 'App.tsx')!.contents;
    expect(appCode).toContain('createNativeStackNavigator');
    expect(appCode).toContain('ProfileScreen');
  });

  it('unifies target generation via generateTargetProject', () => {
    const config = defaultConfig();
    const flutterRes = generateTargetProject(config, 'flutter');
    expect(flutterRes.files.some((f) => f.path === 'pubspec.yaml')).toBe(true);

    const nextRes = generateTargetProject(config, 'nextjs');
    expect(nextRes.files.some((f) => f.path === 'tailwind.config.ts')).toBe(true);

    const rnRes = generateTargetProject(config, 'react-native');
    expect(rnRes.files.some((f) => f.path === 'app.json')).toBe(true);
  });
});
