import { describe, it, expect } from 'vitest';
import { screenExportService } from '../apps/studio/src/lib/screenExportService';
import type { AppScreen, ScreenComponent } from '../apps/studio/src/lib/store';

describe('Screen Export & Undo/Redo Data Layer', () => {
  const mockScreens: AppScreen[] = [
    {
      id: 'sc-1',
      name: 'Main Screen',
      route: '/',
      isInitial: true,
      components: [
        {
          id: 'c-1',
          type: 'button',
          name: 'Button 1',
          props: { label: 'Click Me', actionType: 'navigate', targetRoute: '/second' },
        },
      ],
    },
    {
      id: 'sc-2',
      name: 'Second Screen',
      route: '/second',
      isInitial: false,
      components: [
        {
          id: 'c-2',
          type: 'card',
          name: 'Card 1',
          props: { title: 'Second Screen Info' },
        },
      ],
    },
  ];

  it('exports screens to clean JSON string with metadata', () => {
    const jsonStr = screenExportService.exportToJson(mockScreens, []);
    expect(jsonStr).toBeTypeOf('string');

    const parsed = JSON.parse(jsonStr);
    expect(parsed.version).toBe('1.0.0');
    expect(parsed.metadata.totalScreens).toBe(2);
    expect(parsed.metadata.totalComponents).toBe(2);
    expect(parsed.screens.length).toBe(2);
  });

  it('imports screens from JSON and preserves all properties', () => {
    const jsonStr = screenExportService.exportToJson(mockScreens, []);
    const imported = screenExportService.importFromJson(jsonStr);

    expect(imported).not.toBeNull();
    expect(imported?.screens.length).toBe(2);
    expect(imported?.screens[0].name).toBe('Main Screen');
    expect(imported?.screens[0].components[0].props.label).toBe('Click Me');
  });

  it('exports individual screen directly to valid Dart string', () => {
    const dartCode = screenExportService.exportScreenToDart(mockScreens[0]);
    expect(dartCode).toContain('class MainScreenPage extends StatelessWidget');
    expect(dartCode).toContain('ElevatedButton(');
    expect(dartCode).toContain("Navigator.of(context).pushNamed('/second')");
  });

  it('exports all screens to a bundle of Dart files', () => {
    const files = screenExportService.exportAllScreensToDart(mockScreens);
    expect(files.length).toBe(3); // 2 screens + 1 route table
    expect(files.some((f) => f.fileName === 'main_screen_page.dart')).toBe(true);
    expect(files.some((f) => f.fileName === 'second_screen_page.dart')).toBe(true);
    expect(files.some((f) => f.fileName === 'app_routes.dart')).toBe(true);
  });

  it('correctly handles immutable actions in screen builder reducer operations', () => {
    const initialScreens: AppScreen[] = [
      {
        id: 's1',
        name: 'Home',
        route: '/',
        isInitial: true,
        components: [
          { id: 'c1', type: 'appbar', name: 'AppBar', props: { title: 'Home' } },
        ],
      },
    ];

    // Add component
    const newComponent: ScreenComponent = {
      id: 'c2',
      type: 'button',
      name: 'New Button',
      props: { label: 'Submit' },
    };
    const afterAdd = {
      screens: initialScreens.map((s) => ({
        ...s,
        components: [...s.components, newComponent],
      })),
      activeScreenId: 's1',
      activeComponents: [...initialScreens[0].components, newComponent],
      selectedComponentId: 'c2',
    };

    expect(afterAdd.screens[0].components.length).toBe(2);
    expect(afterAdd.activeComponents.length).toBe(2);

    // Update component props
    const afterUpdate = {
      ...afterAdd,
      screens: afterAdd.screens.map((s) => ({
        ...s,
        components: s.components.map((c) =>
          c.id === 'c2' ? { ...c, props: { ...c.props, label: 'Updated Label' } } : c
        ),
      })),
    };

    expect(afterUpdate.screens[0].components[1].props.label).toBe('Updated Label');
  });
});
