# Architecture

The guiding idea: **the schema is the product, the UI is a renderer.**

---

## 1. Layers

```
┌──────────────────────────────────────────────────────────────┐
│ apps/studio            Next.js UI                            │
│   components/ui/       generic controls, know nothing about   │
│                        the domain (Select, OptionCards, …)    │
│   components/wizard/   wizard-specific panels (preview,       │
│                        review, command palette)               │
│   lib/store.ts         zustand store + persistence           │
│   lib/ipc.ts           typed bridge to the Rust backend       │
├──────────────────────────────────────────────────────────────┤
│ packages/schema        the single source of truth             │
│   types.ts             FieldDef, OptionDef, StepDef           │
│   catalogs/            the option data                        │
│   schema.ts            the wizard steps                       │
│   config.ts            defaults, validation, summary, IO      │
├──────────────────────────────────────────────────────────────┤
│ packages/generator     config → file tree (pure functions)    │
│   context.ts           config → generation context            │
│   layout.ts            architecture → folder layout           │
│   plan.ts              the file plan                          │
│   templates/           Dart / YAML / Markdown templates       │
├──────────────────────────────────────────────────────────────┤
│ src-tauri              Rust native layer                      │
│   commands.rs          write, zip, detect, dialogs            │
└──────────────────────────────────────────────────────────────┘
```

Dependencies only ever point **downwards**. The schema package imports nothing.
The generator imports the schema. The app imports both. Rust knows nothing about
the schema — it receives a flat list of `{ path, contents }`.

---

## 2. The schema contract

### `OptionDef`

```ts
interface OptionDef {
  id: string;                 // value written into the config
  name: string;               // label
  desc?: string;              // one line explanation
  icon?: string;              // lucide icon name
  accent?: string;            // colour for cards / dots
  tags?: string[];            // used by the dropdown filter
  fields?: FieldDef[];        // extra inputs revealed when selected
  data?: Record<string, unknown>; // consumed by the generator
}
```

`data` is the escape hatch. The generator reads `data.sdk`, `data.driver`,
`data.folders`, `data.packages` — and nothing in the UI layer knows those keys
exist.

### `FieldDef`

```ts
interface FieldDef {
  id: string;                 // globally unique key in the flat config
  kind: 'text' | 'textarea' | 'number' | 'select' | 'multiselect'
      | 'toggle' | 'range' | 'color';
  label: string;
  help?: string;
  required?: boolean;
  default?: FieldValue;
  options?: OptionDef[];
  min?: number; max?: number; step?: number; suffix?: string;
  visibleWhen?: { field: string; in: string[] };
  group?: string;             // visual grouping in the form
  multiple?: boolean;
  presentation?: 'dropdown' | 'cards' | 'chips' | 'swatches';
}
```

### `StepDef`

```ts
interface StepDef {
  id: string;
  label: string;
  icon: string;
  title: string;
  subtitle: string;
  fields: FieldDef[];
  required?: boolean;
  panel?: 'preview' | 'review';   // special rendering instead of fields
}
```

---

## 3. The flat config

```ts
type StudioConfig = Record<string, FieldValue>;
```

**Why flat?** Because it makes everything mechanical:

* a default is just `config[field.id] = field.default`
* a dependency is `config[otherFieldId]` — no path resolution
* a summary row is `label → config[field.id]`
* persistence is one JSON object with no nested transformations
* the Rust side never has to know the shape — it only receives files

The cost is that ids are global. The schema test
(`packages/schema/src/schema.test.ts`) enforces that they stay unique.

---

## 4. Dynamic fields

Selecting a provider must reveal the right inputs. That is expressed as data:

```ts
// in the catalog
fields: [
  { id: 'backend.supabase.url', kind: 'text', label: 'Project URL' },
  { id: 'backend.supabase.anonKey', kind: 'text', label: 'Anon Key' },
]
```

`dynamicFieldsFor(config)` resolves the currently selected option and returns
its `fields`. `fieldsForStep(step, config)` merges them into the step.
The renderer needs no knowledge of Supabase.

Adding a *cross-field* rule (show B only when A is X) is the `visibleWhen`
property, which the same renderer honours.

---

## 5. Rendering

```
StepContent
  └── for each grouped FieldDef
        └── SchemaField(field, value)
              switch (field.kind)
                'select'      → Select | OptionCards | ColorSwatches
                'multiselect' → ChipMultiSelect | OptionCards | Select
                'toggle'      → Switch
                'range'       → Slider
                'text'/'textarea'/'number'/'color' → native inputs
```

`SchemaField` is the only place a field type is interpreted. Everything above it
is data, everything below it is dumb controls.

---

## 6. The generator

```
StudioConfig
   │  buildContext()      resolve options → flat generation context
   ▼
GenContext
   │  layoutFor()         architecture → folder layout
   ▼
file plan
   │  templates/*.ts      each file's contents
   ▼
GeneratedFile[]  →  Rust write_project  →  disk  →  zip
```

`generateProject()` is a **pure function**: same config in, same files out. That
is what makes the preview step trustworthy — it renders the same tree the
writer will produce.

Adding a file type means adding a template function and one `add(...)` call in
`plan.ts`. Adding an architecture means one entry in `layout.ts`.

### Template engine

`packages/generator/src/template.ts` is ~30 lines: `{{key}}` interpolation
only. Conditional content is composed in TypeScript instead of markup, which
keeps the output predictable and the engine dependency-free.

---

## 7. The native boundary

TypeScript owns the *decisions*. Rust owns the *system*.

```
invoke('write_project', { files, outputDir, projectName, createZip })
```

| Concern | TypeScript | Rust |
| --- | --- | --- |
| what files | ✅ | |
| what goes in them | ✅ | |
| where on disk | | ✅ |
| zipping | | ✅ |
| native dialogs | | ✅ |
| `flutter create` | | ✅ |
| toolchain probing | | ✅ |

This split is deliberate: it keeps the Rust crate small, makes the generator
testable without a browser or a native shell, and lets the same UI run in the
browser (with `fflate` as the fallback writer).

The IPC layer is deliberately forgiving — `invokeSafe()` returns `null` when the
app is not running inside Tauri, and every call site has a browser fallback.

---

## 8. Persistence

| Where | What | How |
| --- | --- | --- |
| browser | wizard state | `zustand/persist` → `localStorage` |
| native | wizard state | Rust `save_draft` → app-data dir |
| native | generated project | Rust `write_project` → chosen folder |
| browser | generated project | `fflate` zip → browser download |

The theme is applied before first paint by an inline script in
`app/layout.tsx`, so there is no light-mode flash on a dark-mode machine.

---

## 9. Testing strategy

| Layer | Tool | Coverage |
| --- | --- | --- |
| schema | vitest | catalog integrity, unique ids, defaults point at real options, validation rules, import/export |
| generator | vitest | every file type produced, architecture changes the layout, components → widgets, state manager → controller code, theme colour → Dart constant, no duplicate paths |
| UI | manual | the wizard is a thin renderer over the tested schema |

57 tests, all runnable in ~1.5 s with no browser.

---

## 10. Extension points

| I want to… | Touch |
| --- | --- |
| add a backend / database / feature / style | `packages/schema/src/catalogs/*.ts` |
| add a wizard step or field | `packages/schema/src/schema.ts` |
| change the generated Dart | `packages/generator/src/templates/*.ts` |
| change where files go | `packages/generator/src/layout.ts` |
| change which pub packages a choice pulls in | `packages/generator/src/context.ts` |
| add a native capability | `src-tauri/src/commands.rs` + `capabilities/default.json` |
| change the look | `apps/studio/src/app/globals.css` (Tailwind v4 `@theme`) |
