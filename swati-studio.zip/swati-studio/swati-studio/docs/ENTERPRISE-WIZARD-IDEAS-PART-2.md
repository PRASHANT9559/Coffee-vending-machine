# 🚀 Swati Studio — Enterprise Wizard Ideas (Part 2: #26 – #40)

> **Document Type**: Feature Ideas & Enhancement Proposals
> **Continues**: `ENTERPRISE-WIZARD-IDEAS.md` (Ideas 1–25)
> **Date**: November 2026
> **Goal**: Part 1 ke gaps fill karna — regeneration safety, brownfield projects, backend, compliance aur polish features

---

## 📑 Table of Contents

26. [Regeneration-Safe Codegen](#26--regeneration-safe-codegen)
27. [Brownfield Mode — Existing Project Import](#27--brownfield-mode--existing-project-import)
28. [Database Schema Designer](#28--database-schema-designer)
29. [CRUD / Form Scaffolder](#29--crud--form-scaffolder)
30. [Push Notification Setup](#30--push-notification-setup)
31. [Remote Config, Force Update & Maintenance Mode](#31--remote-config-force-update--maintenance-mode)
32. [Backend Scaffold Generator](#32--backend-scaffold-generator)
33. [Legal & Store Compliance Kit](#33--legal--store-compliance-kit)
34. [Standard UI States Kit](#34--standard-ui-states-kit)
35. [App Icon, Splash & Branding Generator](#35--app-icon-splash--branding-generator)
36. [Mock Data & Fake Server](#36--mock-data--fake-server)
37. [Accessibility & Responsive / Adaptive Layouts](#37--accessibility--responsive--adaptive-layouts)
38. [App Size & Performance Budget](#38--app-size--performance-budget)
39. [Auto Documentation Generator](#39--auto-documentation-generator)
40. [Headless CLI Mode & Config-as-Code](#40--headless-cli-mode--config-as-code)

---

## 26. 🔁 Regeneration-Safe Codegen

### Problem:
Abhi ka wizard ek baar project generate karta hai. Lekin user ne generated code edit kar diya, phir wizard mein ek setting badli (jaise theme color ya naya feature) aur dobara generate dabaya — **toh user ka kaam overwrite ho jayega**. Isi wajah se zyadatar code generators sirf "ek baar use" ke tool ban jaate hain.

### Idea:
Har generated file ko **ownership level** do, aur re-generate pe safe merge karo.

### 3 File Ownership Types:

| Type | Kaun owner hai | Re-generate pe kya hota hai | Example |
|---|---|---|---|
| 🔒 **Generated** | Wizard | Hamesha overwrite (header: `// GENERATED — DO NOT EDIT`) | `app_routes.dart`, `api_endpoints.dart`, `app_theme.dart` |
| 🌱 **Scaffold** | User | Sirf pehli baar banta hai, phir kabhi touch nahi hota | `home_screen.dart`, `login_screen.dart` |
| 🔀 **Hybrid** | Dono | Protected regions ke bahar overwrite, andar user ka code safe | `main.dart`, `app_config.dart` |

### Protected Region Syntax:
```dart
// <swati:custom-imports>
import 'package:my_app/my_custom_thing.dart';   // ← user ka code, safe rahega
// </swati:custom-imports>

void main() {
  // <swati:custom-init>
  await MyCustomService.init();                  // ← user ka code, safe rahega
  // </swati:custom-init>

  runApp(const MyApp());                          // ← wizard-owned
}
```

### Merge Strategy (3-way merge):
```
 BASE   = last generated version  (.swati/base/<file>)
 OURS   = user ki current file
 THEIRS = naya generated version

 OURS == BASE        → seedha THEIRS se overwrite (user ne touch nahi kiya)
 OURS != BASE        → 3-way merge try karo
 Merge conflict      → conflict UI dikhao (user decide kare)
```

### UI — Regeneration Preview:
```
┌──────────────────────────────────────────────────────────────┐
│ 🔁 Regenerate Preview                       [ 🧪 Dry Run ✓ ] │
│                                                              │
│ Changes detected: Theme color, +Push Notifications           │
│                                                              │
│  ✅ lib/config/app_theme.dart          Overwritten (untouched)│
│  ✅ lib/core/network/api_endpoints.dart Overwritten (untouched)│
│  🟡 lib/main.dart                      Merged (custom kept)  │
│  🔴 lib/features/home/home_screen.dart CONFLICT  [ View Diff ]│
│  ⏭️ lib/features/auth/login_screen.dart Skipped (user-owned) │
│  🆕 lib/core/notifications/*           5 new files           │
│                                                              │
│ ☑ Auto-commit backup before applying (git)                  │
│ ☑ Allow undo last regeneration                              │
│                                                              │
│          [ Cancel ]            [ ✅ Apply Changes ]          │
└──────────────────────────────────────────────────────────────┘
```

### Safety Net:
- **Dry run** — pehle sirf preview, kuch disk pe nahi likhta
- **Auto git commit/stash** — regenerate se pehle snapshot, ek click mein undo
- **Conflict diff viewer** — side-by-side, "keep mine / take theirs / merge manually"
- **Never delete** — wizard kisi user file ko delete nahi karega, sirf "orphaned" mark karega

### What Gets Generated:
```
.swati/
├── manifest.json          ← har file ka path, ownership type, hash
├── base/                  ← last generated copies (3-way merge ke liye)
│   └── lib/...
├── config.json            ← wizard ka saved config
└── history/
    └── 2026-11-03T10-20.json   ← regeneration log
```

---

## 27. 📂 Brownfield Mode — Existing Project Import

### Idea:
Abhi poora wizard **greenfield** hai (naya project). Lekin asli developers ke paas pehle se chalte hue projects hote hain. Existing Flutter project open karo → wizard stack detect kare → user sirf **ek feature add** kar sake (auth, push, i18n, CI/CD...).

### Detection Engine:
```
┌──────────────────────────────────────────────────────────┐
│ 📂 Open Existing Project                                 │
│                                                          │
│ Scanning: /home/dev/projects/my_old_app ...              │
│                                                          │
│ ✅ Detected Stack:                                       │
│                                                          │
│  Flutter SDK      → 3.x                                  │
│  State Mgmt       → flutter_riverpod                     │
│  Navigation       → go_router                            │
│  Backend          → supabase_flutter                     │
│  HTTP Client      → dio                                  │
│  Architecture     → Feature-First (lib/features/*)       │
│  Theme            → Material 3 (ThemeData found)         │
│  Missing          → i18n, CI/CD, Env config, Tests       │
│                                                          │
│  ➕ Add to this project:                                 │
│  [ 🌐 i18n ] [ 🔄 CI/CD ] [ 🌍 Environments ]            │
│  [ 🧪 Testing ] [ 🔔 Push ] [ 🛡️ Security ]              │
└──────────────────────────────────────────────────────────┘
```

### Detection Sources:

| Kya detect karna hai | Kahan se |
|---|---|
| State management | `pubspec.yaml` deps (riverpod / bloc / provider / get) |
| Navigation | `go_router`, `auto_route`, ya `MaterialApp.routes` |
| Backend | `supabase_flutter`, `firebase_core`, `dio`, `graphql_flutter` |
| Architecture | Folder structure (`lib/features`, `lib/data`, `lib/domain`) |
| Naming convention | Existing files (`snake_case`, suffixes `_screen`, `_controller`) |
| Flavors | `android/app/build.gradle` flavors, `main_*.dart` |

### Safe-Add Rules:
- **Additive only** — existing code kabhi overwrite nahi hota
- Naye files **project ki detected convention** mein bante hain (naming, folder, state mgmt)
- `pubspec.yaml` mein deps `flutter pub add` se jaate hain
- Jahan existing file patch karni ho (`main.dart`, router), wahan **anchor comments** use ho aur **diff pehle dikhe**
- Har add-on ek alag git commit → rollback easy

### Diff Review Before Apply:
```
┌──────────────────────────────────────────────────────────┐
│ 📝 Review Changes — Add i18n                             │
│                                                          │
│  M  pubspec.yaml            (+3 deps, +1 flutter section)│
│  M  lib/main.dart           (+localizationsDelegates)    │
│  A  lib/l10n/app_en.arb                                  │
│  A  lib/l10n/app_hi.arb                                  │
│  A  l10n.yaml                                            │
│                                                          │
│  [ View Diff ]        [ ❌ Cancel ]   [ ✅ Apply ]       │
└──────────────────────────────────────────────────────────┘
```

### What Gets Generated:
```
.swati/
├── detected.json      ← detected stack + conventions
└── addons.log         ← kaun sa add-on kab apply hua
```

---

## 28. 🗄️ Database Schema Designer

### Idea:
Wizard mein DB choose karna kaafi nahi — **tables, columns aur relations visually design** karo. Us design se SQL migrations, Dart models, RLS policies aur seed data auto-generate ho.

### Visual ER Canvas:
```
┌──────────────────────────────────────────────────────────────────┐
│ 🗄️ Schema Designer                      [ ➕ Add Table ] [ 📥 Import ]│
│                                                                  │
│  ┌──────────────────┐         ┌──────────────────┐               │
│  │ users            │         │ orders           │               │
│  ├──────────────────┤         ├──────────────────┤               │
│  │ 🔑 id (uuid)     │◄──────┐ │ 🔑 id (uuid)     │               │
│  │ email (text) U   │       └─│ 🔗 user_id       │               │
│  │ name (text)      │         │ total (numeric)  │               │
│  │ role (enum)      │         │ status (enum)    │               │
│  │ created_at       │         │ created_at       │               │
│  └──────────────────┘         └────────┬─────────┘               │
│                                        │ 1                       │
│                                        │ N                       │
│  ┌──────────────────┐         ┌────────▼─────────┐               │
│  │ products         │◄────────│ order_items      │               │
│  │ 🔑 id            │ N     1 │ 🔗 order_id      │               │
│  │ name, price, ... │         │ 🔗 product_id    │               │
│  └──────────────────┘         │ qty (int)        │               │
│                               └──────────────────┘               │
└──────────────────────────────────────────────────────────────────┘
```

### Column Editor:
```
┌──────────────────────────────────────────────────────────┐
│ Table: orders                                            │
│                                                          │
│ Column      Type       Null  Default     Unique  FK      │
│ id          uuid       ☐     gen_random  ☑       —       │
│ user_id     uuid       ☐     —           ☐       users   │
│ total       numeric    ☐     0           ☐       —       │
│ status      enum       ☐     'pending'   ☐       —       │
│                                                          │
│ Table Options:                                           │
│ ☑ created_at / updated_at (auto)    ☑ UUID primary keys  │
│ ☐ Soft delete (deleted_at)          ☑ Indexes on FKs     │
│                                                          │
│ 🛡️ Row Level Security:                                   │
│ ( ) None   (•) Owner only   ( ) Role-based (from RBAC #8)│
└──────────────────────────────────────────────────────────┘
```

### Supported Targets:

| Target | Output |
|---|---|
| 🐘 PostgreSQL / Supabase | SQL migrations + RLS policies |
| 🔥 Firestore | Collections structure + `firestore.rules` + indexes |
| 📦 SQLite / Drift | Drift table classes (offline-first, see #17) |
| ⚡ Isar | Isar collections |

### Import Options:
- **SQL dump / schema.sql** upload → tables auto-detect
- **Supabase introspection** (connection URL) → live schema read
- **JSON sample** paste → columns guess karo

### What Gets Generated:
```
supabase/
├── migrations/
│   └── 20261103000000_init_schema.sql
├── seed.sql
└── policies.sql                 ← RLS policies

lib/core/database/
├── models/
│   ├── user_model.dart          ← freezed + json_serializable
│   ├── order_model.dart
│   └── order_item_model.dart
├── repositories/
│   ├── user_repository.dart
│   └── order_repository.dart
└── enums/
    └── order_status.dart

docs/
├── schema.dbml                  ← dbdiagram.io compatible
└── erd.mmd                      ← Mermaid erDiagram
```

---

## 29. 🧱 CRUD / Form Scaffolder

### Idea:
Model define hone ke baad (Idea #28 se ya manually), us model ke liye **poora CRUD module** ek click mein generate ho — list, detail, create/edit form, delete, search, filter, pagination.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 🧱 Scaffold CRUD for: Product                            │
│                                                          │
│ Fields:                                                  │
│ ┌────────────┬─────────┬──────┬────────┬────────┬──────┐ │
│ │ Field      │ Type    │ List │ Search │ Filter │ Sort │ │
│ ├────────────┼─────────┼──────┼────────┼────────┼──────┤ │
│ │ name       │ String  │  ☑   │   ☑    │   ☐    │  ☑   │ │
│ │ price      │ double  │  ☑   │   ☐    │   ☑    │  ☑   │ │
│ │ category   │ enum    │  ☑   │   ☐    │   ☑    │  ☐   │ │
│ │ image_url  │ String  │  ☑   │   ☐    │   ☐    │  ☐   │ │
│ │ in_stock   │ bool    │  ☐   │   ☐    │   ☑    │  ☐   │ │
│ └────────────┴─────────┴──────┴────────┴────────┴──────┘ │
│                                                          │
│ List Layout:  (•) List  ( ) Grid  ( ) Data Table (desktop)│
│ Pagination:   (•) Infinite scroll  ( ) Page numbers      │
│                                                          │
│ ☑ Pull-to-refresh        ☑ Delete confirmation dialog    │
│ ☑ Optimistic updates     ☐ Bulk select & delete          │
│ ☐ Export CSV (admin)     ☑ Form validation               │
└──────────────────────────────────────────────────────────┘
```

### Field Type → Form Widget Mapping:

| Field Type | Form Widget |
|---|---|
| `String` | `TextFormField` (+ validators: required, min/max length, regex) |
| `int` / `double` | Numeric keyboard field + range validation |
| `bool` | `Switch` |
| `enum` | `DropdownButtonFormField` / `SegmentedButton` |
| `DateTime` | Date / Time picker |
| `image_url` | Image picker + upload to storage + preview |
| Foreign key | Searchable relation picker (bottom sheet) |

### What Gets Generated:
```
lib/features/products/
├── screens/
│   ├── product_list_screen.dart
│   ├── product_detail_screen.dart
│   └── product_form_screen.dart      ← create + edit dono
├── controllers/
│   └── product_controller.dart       ← list state, search, filter, pagination
├── repositories/
│   └── product_repository.dart
├── models/
│   └── product_model.dart
└── widgets/
    ├── product_card.dart
    ├── product_filter_sheet.dart
    └── product_form_fields.dart
```

---

## 30. 🔔 Push Notification Setup

### Idea:
Part 1 mein push sirf templates ke andar mention hua hai. Ek **dedicated step** chahiye jo notifications ka poora setup kare — provider, channels, permission flow, tap routing.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 🔔 Push Notification Setup                               │
│                                                          │
│ Provider:                                                │
│ ┌────────────┐ ┌────────────┐ ┌────────────────┐         │
│ │ 🔥 FCM     │ │ 🟣 OneSignal│ │ 🔧 Local only  │         │
│ └────────────┘ └────────────┘ └────────────────┘         │
│                                                          │
│ Notification Channels (Android):                         │
│ ┌──────────────┬────────────┬────────┬─────────┐         │
│ │ Channel      │ Importance │ Sound  │ Vibrate │         │
│ ├──────────────┼────────────┼────────┼─────────┤         │
│ │ 📦 Orders    │ High       │  ☑     │   ☑     │         │
│ │ 💬 Chat      │ High       │  ☑     │   ☑     │         │
│ │ 🎁 Promos    │ Default    │  ☐     │   ☐     │         │
│ └──────────────┴────────────┴────────┴─────────┘         │
│                                                          │
│ Topics:  ☑ all_users  ☑ promotions  ☐ city_updates       │
│                                                          │
│ Permission Prompt Timing:                                │
│ ( ) On first launch                                      │
│ (•) After onboarding                                     │
│ ( ) Contextual (jab user pehli baar order place kare)    │
│                                                          │
│ Behavior:                                                │
│ ☑ Show local notification when app is in foreground      │
│ ☑ Tap → open specific screen (deep link payload)         │
│ ☑ Save FCM token to backend on login / refresh           │
│ ☐ In-app notification inbox (history + unread badge)     │
└──────────────────────────────────────────────────────────┘
```

### 3 App States Handling:
```
 Foreground  → local notification dikhao (FCM khud nahi dikhata)
 Background  → system tray notification, tap pe onMessageOpenedApp
 Terminated  → getInitialMessage() se launch-time routing
```

### What Gets Generated:
```
lib/core/notifications/
├── notification_service.dart         ← init, permission, token
├── fcm_handler.dart                  ← foreground/background/terminated
├── local_notification_service.dart
├── notification_channels.dart
├── notification_router.dart          ← payload → screen (Idea #4, #14 se linked)
└── models/
    └── notification_payload.dart

android/app/src/main/AndroidManifest.xml   ← POST_NOTIFICATIONS permission + default channel meta-data
web/firebase-messaging-sw.js               ← agar web target ho
supabase/functions/send-push/index.ts      ← sample sender (optional)
```

### Notes:
- Android 13+ pe `POST_NOTIFICATIONS` runtime permission zaroori hai — wizard uska flow bhi generate kare
- iOS ke liye APNs key upload ka **step-by-step checklist** dikhao (code generate nahi ho sakta, manual step hai)
- Token table: `device_tokens(user_id, token, platform, updated_at)` — Idea #28 ke schema mein auto-add

---

## 31. 🎛️ Remote Config, Force Update & Maintenance Mode

### Idea:
Part 1 ke Environment step mein feature flags sirf **build-time** (`.env`) hain. Production mein app store update ke bina behavior badalne ke liye **runtime remote config** chahiye — plus force update aur maintenance mode.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 🎛️ Remote Config                                         │
│                                                          │
│ Provider:                                                │
│ ┌──────────────┐ ┌──────────────┐ ┌──────────────────┐   │
│ │ 🔥 Firebase  │ │ 🟢 Supabase  │ │ 🌐 Custom API    │   │
│ │ Remote Config│ │ table        │ │ (self-hosted)    │   │
│ └──────────────┘ └──────────────┘ └──────────────────┘   │
│                                                          │
│ Parameters:                          [ ➕ Add Param ]    │
│ ┌──────────────────────┬─────────┬────────────────────┐  │
│ │ Key                  │ Type    │ Default            │  │
│ ├──────────────────────┼─────────┼────────────────────┤  │
│ │ min_supported_version│ String  │ "1.0.0"            │  │
│ │ latest_version       │ String  │ "1.0.0"            │  │
│ │ maintenance_mode     │ bool    │ false              │  │
│ │ maintenance_message  │ String  │ "Back soon!"       │  │
│ │ show_ads             │ bool    │ true               │  │
│ │ interstitial_gap_sec │ int     │ 120                │  │
│ │ new_checkout_enabled │ bool    │ false              │  │
│ └──────────────────────┴─────────┴────────────────────┘  │
│                                                          │
│ Update Behavior:                                         │
│ ☑ Force update (blocking, version < min_supported)       │
│ ☑ Soft update banner (version < latest)                  │
│ ☑ Android in-app update API                              │
│ ☑ Maintenance mode full-screen gate                      │
│                                                          │
│ Fetch Strategy:                                          │
│ ☑ On app launch    ☑ On resume from background           │
│ Cache TTL: [ 1 hour ▼ ]   ☑ Fallback to defaults offline │
└──────────────────────────────────────────────────────────┘
```

### Runtime Behavior:
```
 App launch
    │
    ├─ Cached config load  (instant, offline-safe)
    ├─ Background fetch    (latest values)
    │
    ├─ maintenance_mode == true ?   → 🚧 Maintenance screen (blocks app)
    ├─ version < min_supported ?    → 🔒 Force update dialog (Play Store link, no dismiss)
    ├─ version < latest ?           → 🔔 Soft update banner (dismissible)
    └─ else                         → ✅ Normal app
```

### Usage in UI Code:
```dart
FeatureGate(
  flag: 'new_checkout_enabled',
  child: NewCheckoutScreen(),
  fallback: OldCheckoutScreen(),
)
```

### What Gets Generated:
```
lib/core/remote_config/
├── remote_config_service.dart     ← fetch, cache, TTL, defaults
├── remote_keys.dart               ← typed keys (typos se bachao)
├── app_version_checker.dart       ← semver compare
├── feature_flags.dart
├── maintenance_gate.dart          ← wraps MaterialApp home
├── update_dialog.dart             ← force + soft variants
└── widgets/
    └── feature_gate.dart

supabase/migrations/..._app_config.sql   ← agar Supabase provider ho
docs/REMOTE-CONFIG.md                    ← keys ki list + kaise change karein
```

---

## 32. 🖥️ Backend Scaffold Generator

### Idea:
Wizard abhi frontend (Flutter) generate karta hai aur backend sirf *choose* hota hai. Frontend ke saath **backend skeleton bhi generate** ho, aur dono ek hi **API contract (OpenAPI)** se bane — taaki client aur server kabhi out-of-sync na ho.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 🖥️ Backend Scaffold                                      │
│                                                          │
│ Target:                                                  │
│ ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌─────────┐ │
│ │ 🟢 Supabase│ │ 🔥 Firebase│ │ 🦀 Rust    │ │ 🟩 Node │ │
│ │ Functions  │ │ Functions  │ │ (Axum)     │ │(Fastify)│ │
│ └────────────┘ └────────────┘ └────────────┘ └─────────┘ │
│                ┌────────────┐                            │
│                │ 🎯 Dart    │                            │
│                │ Frog       │                            │
│                └────────────┘                            │
│                                                          │
│ Modules:                                                 │
│ ☑ Auth (JWT verify middleware)   ☑ CRUD routes (from #28)│
│ ☑ File upload (signed URLs)      ☐ Webhooks (payments)   │
│ ☐ Cron / scheduled jobs          ☑ Rate limiting         │
│ ☑ CORS config                    ☑ OpenAPI docs (/docs)  │
│ ☑ Health check (/health)         ☑ Structured logging    │
│                                                          │
│ Deployment Files:                                        │
│ ☑ Dockerfile + docker-compose.yml    ☐ fly.toml          │
│ ☑ .env.example                       ☐ railway.json      │
└──────────────────────────────────────────────────────────┘
```

### Contract-First Flow:
```
        ┌─────────────────────────┐
        │  openapi.yaml (single   │
        │  source of truth)       │
        └───────────┬─────────────┘
          ┌─────────┴──────────┐
          ▼                    ▼
   Dart API client       Server route stubs
   (Idea #5 se link)     (is idea ka output)
```

### What Gets Generated (Rust/Axum example):
```
backend/
├── Cargo.toml
├── src/
│   ├── main.rs
│   ├── config.rs
│   ├── routes/
│   │   ├── mod.rs
│   │   ├── auth.rs
│   │   ├── products.rs
│   │   └── health.rs
│   ├── middleware/
│   │   ├── auth.rs
│   │   └── rate_limit.rs
│   ├── models/
│   └── db.rs
├── migrations/                  ← Idea #28 se
├── openapi.yaml
├── Dockerfile
├── docker-compose.yml
└── .env.example
```

### Notes:
- Supabase target mein server ki jagah **edge functions + RLS + storage buckets + `config.toml`** generate hoga
- Firebase target mein **`firestore.rules`, `storage.rules`, `firestore.indexes.json`** aur Cloud Functions

---

## 33. ⚖️ Legal & Store Compliance Kit

### Idea:
Play Store / App Store pe publish karne ke liye privacy policy, terms, account deletion aur data disclosure zaroori hote hain. Wizard ko pata hai kaun se features/SDKs on hain — toh ye sab documents **uski config se auto-generate** ho sakte hain.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ ⚖️ Legal & Compliance                                    │
│                                                          │
│ Data your app collects (auto-detected from features):    │
│ ☑ Email address        (Auth)                            │
│ ☑ Phone number         (Phone OTP)                       │
│ ☑ Approx. location     (Maps)                            │
│ ☑ Advertising ID       (AdMob)                           │
│ ☑ App interactions     (Analytics)                       │
│ ☑ Crash logs           (Crashlytics)                     │
│ ☑ Payment info         (via Razorpay / Stripe — not stored)│
│                                                          │
│ Third-party services: Firebase, Supabase, AdMob, Razorpay│
│                                                          │
│ Jurisdiction:                                            │
│ ☑ 🇮🇳 India (DPDP Act)   ☑ 🇪🇺 GDPR   ☐ 🇺🇸 CCPA          │
│ ☐ Children's data (COPPA / Families policy)              │
│                                                          │
│ Contact email:  [ support@myapp.com ]                    │
│                                                          │
│ Generate:                                                │
│ ☑ Privacy Policy      ☑ Terms of Service                 │
│ ☑ Account deletion page (web URL)                        │
│ ☑ In-app "Delete my account" flow + data export          │
│ ☑ Consent screen (ads consent / UMP for EEA)             │
│ ☑ Play Store Data Safety cheat-sheet                     │
│                                                          │
│ Hosting:  ( ) Download files  (•) GitHub Pages  ( ) Firebase Hosting│
└──────────────────────────────────────────────────────────┘
```

### Auto-Mapping: Feature → Data Safety Answer

| Feature enabled | Data Safety mein kya declare karna hoga |
|---|---|
| Email Auth | Personal info → Email address (collected, linked to user) |
| AdMob | Device or other IDs → Advertising ID (collected, shared with ad partners) |
| Firebase Analytics | App activity → App interactions |
| Crashlytics | App info & performance → Crash logs, Diagnostics |
| Maps / Location | Location → Approximate / Precise location |

### What Gets Generated:
```
legal/
├── privacy_policy.md
├── privacy_policy.html            ← hosting-ready
├── terms_of_service.md
├── account_deletion.html          ← Play Store web URL requirement
└── DATA-SAFETY-CHEATSHEET.md      ← Play Console form ke liye answers

lib/features/legal/
├── screens/
│   ├── privacy_policy_screen.dart
│   ├── terms_screen.dart
│   └── delete_account_screen.dart
├── controllers/
│   └── account_deletion_controller.dart
└── widgets/
    └── consent_dialog.dart
```

### ⚠️ Disclaimer (UI mein bhi dikhao):
Ye **templates** hain, legal advice nahi. Production mein publish karne se pehle kisi lawyer se review karwana chahiye — wizard ye clearly bataye.

---

## 34. 🧩 Standard UI States Kit

### Idea:
Har app mein same 6 states baar-baar manually banane padte hain — loading, empty, error, offline, permission denied, pagination. Ek **consistent kit** generate karo jo theme aur state management ke saath adapt ho.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 🧩 UI States Kit                                         │
│                                                          │
│ Loading style:   (•) Shimmer skeleton  ( ) Spinner       │
│ Empty state:     (•) Icon + text + CTA ( ) Lottie        │
│ Error state:     (•) Message + Retry button              │
│                                                          │
│ Include:                                                 │
│ ☑ Loading / skeleton list    ☑ Empty view                │
│ ☑ Error view with retry      ☑ No-internet banner        │
│ ☑ Pull-to-refresh wrapper    ☑ Pagination footer loader  │
│ ☑ Permission denied view     ☐ 404 / not-found screen    │
│                                                          │
│ ☑ Error mapping (exceptions → friendly messages)         │
│ ☑ Localized messages (hooks into i18n #11)               │
└──────────────────────────────────────────────────────────┘
```

### Preview (Right Panel):
```
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│  ▒▒▒▒▒▒▒▒▒   │ │              │ │      ⚠️      │
│  ▒▒▒▒▒       │ │      📭      │ │  Kuch galat  │
│  ▒▒▒▒▒▒▒▒    │ │  Koi order   │ │  ho gaya     │
│  ▒▒▒▒▒▒      │ │  nahi mila   │ │              │
│   Loading    │ │ [ Shop Now ] │ │  [ Retry ]   │
└──────────────┘ └──────────────┘ └──────────────┘
```

### Generic Wrapper (Riverpod example):
```dart
AsyncValueView<List<Order>>(
  value: ref.watch(ordersProvider),
  isEmpty: (list) => list.isEmpty,
  data: (orders) => OrderList(orders),
  emptyTitle: 'Koi order nahi mila',
  onRetry: () => ref.invalidate(ordersProvider),
)
```
Bloc / Provider choose karoge toh same API ka adapter generate hoga.

### What Gets Generated:
```
lib/core/widgets/states/
├── async_value_view.dart       ← loading/data/error/empty ek jagah
├── loading_view.dart
├── skeleton_list.dart
├── empty_view.dart
├── error_view.dart
├── offline_banner.dart         ← connectivity_plus
├── permission_denied_view.dart
└── paginated_footer.dart

lib/core/errors/
├── failure.dart
└── error_mapper.dart           ← DioException / PostgrestException → Failure
```

---

## 35. 🖼️ App Icon, Splash & Branding Generator

### Idea:
Logo ek baar upload karo — saare icon sizes, adaptive icon layers, splash screen aur store graphics auto-ban jayein. (`flutter_launcher_icons` aur `flutter_native_splash` ka manual config khatam.)

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 🖼️ Branding                                              │
│                                                          │
│ Logo:  [ 📁 Upload 1024×1024 PNG / SVG ]                 │
│ Brand Color: [ 🎨 #6366F1 ]    Dark BG: [ 🎨 #0F172A ]   │
│                                                          │
│ App Icon:                                                │
│ ☑ Android adaptive icon (foreground + background layers) │
│ ☑ Android 13 themed (monochrome) icon                    │
│ ☑ iOS icon (alpha auto-removed)                          │
│ ☑ Notification small icon (white silhouette)             │
│ ☑ Web favicon + PWA icons                                │
│                                                          │
│ Splash:                                                  │
│ ☑ Android 12+ splash API     ☑ Dark mode variant         │
│ ☐ Branding text at bottom    ☑ Fullscreen (hide status bar)│
│                                                          │
│ Store Graphics:                                          │
│ ☑ Play Store icon 512×512    ☑ Feature graphic 1024×500  │
└──────────────────────────────────────────────────────────┘
```

### Mask Preview:
```
 Same icon, alag-alag launcher shapes mein:

  ┌────┐   ╭────╮   ◯      ╭╮
  │ 🎨 │   │ 🎨 │   🎨    ╱🎨╲     ← square, squircle, circle, teardrop
  └────┘   ╰────╯          ╲╱
```
Safe-zone guide overlay dikhao taaki logo kisi mask mein cut na ho.

### What Gets Generated:
```
assets/branding/
├── logo.png
├── icon_foreground.png
├── icon_background.png
├── icon_monochrome.png
└── splash_logo.png

flutter_launcher_icons.yaml
flutter_native_splash.yaml

store_assets/
├── play_icon_512.png
└── feature_graphic_1024x500.png
```
Wizard dono tools khud run kare (`dart run flutter_launcher_icons`, `dart run flutter_native_splash:create`) — user ko manual commands na chalane padein.

---

## 36. 🎭 Mock Data & Fake Server

### Idea:
Backend ready hone se pehle UI development ruk jaata hai. Models se **realistic dummy data** generate karo aur ek **fake server** bhi do — jisme slow network aur errors simulate ho sakein. (Part 1 mein sirf ek "Mock API responses" checkbox tha.)

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 🎭 Mock Data & Fake Server                               │
│                                                          │
│ Models:  Product ☑   Order ☑   User ☑                    │
│ Records per model: [ 25 ]     Locale: [ hi_IN ▼ ]        │
│                                                          │
│ Field Rules (Product):                                   │
│  name       → Product name (faker)                       │
│  price      → Random ₹99 – ₹9,999                        │
│  category   → Pick from enum                             │
│  image_url  → Bundled placeholder set                    │
│                                                          │
│ Mode:                                                    │
│ ☑ In-app mock repositories (swap via flavor / DI)        │
│ ☑ Local fake server (json-server style)                  │
│ ☐ SQL seed file                                          │
│                                                          │
│ Network Simulation:                                      │
│  Latency:   [ 300–1500 ms ]                              │
│  Failure rate: [ 10 % ]  ☑ Empty-list scenario           │
│  ☑ 401 token-expired scenario   ☑ Offline scenario       │
└──────────────────────────────────────────────────────────┘
```

### How It Plugs In:
```
 Flavor = dev + "Mock API" flag ON   →  MockProductRepository
 Flavor = staging / prod             →  RealProductRepository
                (Idea #6 ke flavor flags se linked)
```

### What Gets Generated:
```
lib/core/mock/
├── mock_data_generator.dart
├── mock_interceptor.dart         ← Dio interceptor, latency + failure injection
├── fixtures/
│   ├── products.json
│   ├── orders.json
│   └── users.json
└── repositories/
    ├── mock_product_repository.dart
    └── mock_order_repository.dart

tools/mock_server/
├── server.dart
└── routes.json
```

---

## 37. ♿ Accessibility & Responsive / Adaptive Layouts

### Idea:
Enterprise apps ko sirf phone pe nahi chalna — tablet, foldable, web aur desktop bhi. Saath hi accessibility (screen reader, text scaling, contrast) built-in ho, baad mein patch na karni pade.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ ♿ Accessibility & Responsive                            │
│                                                          │
│ Target Form Factors:                                     │
│ ☑ 📱 Phone   ☑ 📋 Tablet   ☐ 🔀 Foldable   ☑ 🌐 Web      │
│ ☐ 🖥️ Desktop                                             │
│                                                          │
│ Breakpoints:                                             │
│  Compact  < 600dp   → Bottom navigation                  │
│  Medium   600–840   → Navigation rail                    │
│  Expanded > 840dp   → Side drawer + master-detail        │
│                                                          │
│ Accessibility:                                           │
│ ☑ Semantics labels on all generated widgets              │
│ ☑ Min tap target 48×48dp                                 │
│ ☑ Support text scale up to 200%                          │
│ ☑ Reduce-motion respect (animations off)                 │
│ ☑ WCAG AA contrast check on theme colors                 │
│                                                          │
│ ⚠️ Contrast Warning:                                     │
│  Accent #FF9800 on white = ≈2.2:1  ❌ (needs 4.5:1)      │
│  💡 Suggested: #BF360C (≈5.6:1)           [ Apply Fix ]  │
└──────────────────────────────────────────────────────────┘
```

### Adaptive Navigation:
```
 Phone                 Tablet                Desktop / Web
┌────────────┐      ┌──┬─────────┐      ┌────────┬────────┬────────┐
│            │      │🏠│         │      │ 🏠 Home│  List  │ Detail │
│  Content   │      │🔍│ Content │      │ 🔍 Find│        │        │
│            │      │👤│         │      │ 👤 Me  │        │        │
├────────────┤      └──┴─────────┘      └────────┴────────┴────────┘
│ 🏠  🔍  👤 │       Nav Rail             Side nav + master-detail
└────────────┘
 Bottom Nav
```

### What Gets Generated:
```
lib/core/responsive/
├── breakpoints.dart
├── responsive_builder.dart
├── adaptive_scaffold.dart        ← bottom nav ↔ rail ↔ drawer auto-switch
└── max_content_width.dart        ← web pe ultra-wide stretch roko

lib/core/accessibility/
├── semantics_helpers.dart
└── contrast_checker.dart         ← theme step mein live use hota hai

test/accessibility/
├── text_scale_test.dart          ← 1.0x / 1.5x / 2.0x pe overflow check
└── tap_target_test.dart
```
Health Dashboard (Idea #18) mein "Accessibility score" bhi add ho sakta hai.

---

## 38. 📉 App Size & Performance Budget

### Idea:
Features select karte jaoge toh app ka size badhta jayega. Wizard mein hi **size budget** set karo aur live estimate dekho — especially low-end devices aur slow networks wale market ke liye important hai.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 📉 Size & Performance Budget                             │
│                                                          │
│ Size Budget (arm64 APK):  [ 25 MB ]                      │
│                                                          │
│ Estimated (illustrative):  ████████████░░░░  ~21 MB      │
│  Base Flutter engine ........ core                       │
│  Firebase (3 plugins) ....... medium                     │
│  Google Maps ................ heavy   ⚠️                 │
│  Video player ............... heavy   ⚠️                 │
│                                                          │
│ 💡 Suggestions:                                          │
│  • Maps ko deferred component banao (load on demand)     │
│  • PNG assets → WebP convert (-40% typical)              │
│  • 3 unused packages mile — remove karo                  │
│                                                          │
│ Release Build Options:                                   │
│ ☑ R8 code shrinking + resource shrinking                 │
│ ☑ --split-per-abi                                        │
│ ☑ --obfuscate --split-debug-info                         │
│ ☑ Font tree-shaking (default)                            │
│ ☐ Deferred components for heavy features                 │
│                                                          │
│ Startup Performance:                                     │
│ ☑ Parallel service init (Future.wait)                    │
│ ☑ Lazy-init heavy SDKs after first frame                 │
└──────────────────────────────────────────────────────────┘
```

### What Gets Generated:
```
android/app/proguard-rules.pro
android/app/build.gradle                 ← minify + shrink flags patch

scripts/
├── build_release.sh                     ← split-per-abi + obfuscate wali full command
└── size_report.sh                       ← flutter build apk --analyze-size

lib/core/bootstrap/
└── app_bootstrap.dart                   ← parallel + lazy initialization

docs/SIZE-REPORT.md                      ← per-package size breakdown
```

### Notes:
- Size numbers wizard mein **estimates** honge; asli number ke liye `--analyze-size` report chalani hogi — UI mein ye clearly likho
- Health Dashboard (#18) mein "Size trend" chart: har release ke saath size kitna badha

---

## 39. 📚 Auto Documentation Generator

### Idea:
Wizard ko pata hai project mein kya-kya banaya gaya aur kyun — toh documentation bhi **config se auto-generate** ho. Naye developer ko onboarding mein din nahi lagne chahiye.

### UI:
```
┌──────────────────────────────────────────────────────────┐
│ 📚 Documentation                                         │
│                                                          │
│ ☑ README.md            (setup, run, flavors, structure)  │
│ ☑ ARCHITECTURE.md      (layers + Mermaid diagrams)       │
│ ☑ API.md               (from API Builder #5)             │
│ ☑ DATABASE.md          (ERD from Schema Designer #28)    │
│ ☑ CONTRIBUTING.md      (branching, commit style, PR rules)│
│ ☑ CHANGELOG.md         (Keep a Changelog format)         │
│ ☑ ADR records          (why-decisions, auto from wizard) │
│ ☐ Onboarding checklist (new dev ke liye day-1 steps)     │
└──────────────────────────────────────────────────────────┘
```

### Auto ADR (Architecture Decision Records):
User ne wizard mein jo choices ki, unka reason bhi doc ho jaye:
```
docs/adr/0001-state-management-riverpod.md

  # ADR 0001: State Management — Riverpod
  Status: Accepted
  Context: Compile-time safety, testability, no BuildContext dependency
  Decision: flutter_riverpod
  Consequences: Learning curve for new devs; provider scoping rules
```

### Auto Diagrams (Mermaid):
```
 ┌─ Layer diagram ──────────┐   ┌─ Navigation flow (from #4) ─┐
 │ UI → Controller → Repo   │   │ Splash → Login → Home       │
 │      → DataSource → API  │   │          └→ Register        │
 └──────────────────────────┘   └─────────────────────────────┘
```

### What Gets Generated:
```
README.md
CONTRIBUTING.md
CHANGELOG.md
docs/
├── ARCHITECTURE.md
├── API.md
├── DATABASE.md
├── ONBOARDING.md
└── adr/
    ├── 0001-state-management-riverpod.md
    ├── 0002-backend-supabase.md
    └── 0003-architecture-feature-first.md
```
Docs **Hybrid files** hain (Idea #26) — re-generate pe auto-sections update honge, user ki manually likhi lines safe rahengi.

---

## 40. 💻 Headless CLI Mode & Config-as-Code

### Idea:
GUI wizard ke saath ek **CLI** bhi ho. Wizard ka config ek versioned file (`swati.yaml`) ho jo project ke saath git mein jaaye — GUI sirf us config ka editor ban jaye. Engine ek hi rahe, GUI aur CLI dono usi ko call karein.

### CLI Commands:
```
$ swati init --template e-commerce        # template se config banao
$ swati generate --config swati.yaml      # project generate
$ swati generate --dry-run                # sirf preview (Idea #26)
$ swati add auth --methods email,google   # existing project mein add (Idea #27)
$ swati validate                          # config schema check
$ swati doctor                            # environment + project health check
$ swati upgrade --check                   # outdated deps / schema migrate
```

### Config File Example:
```yaml
schemaVersion: 3
app:
  name: MyShop
  package: com.example.myshop
stack:
  state: riverpod
  backend: supabase
  architecture: feature-first
features:
  - auth: { methods: [email, google, phone_otp] }
  - push: { provider: fcm }
  - i18n: { default: hi, locales: [hi, en] }
environments: [dev, staging, prod]
```

### Why This Matters:

| Benefit | Detail |
|---|---|
| 🔁 Reproducible | Same config → same project, kisi bhi machine pe |
| 🤖 CI friendly | PR pe `swati validate`, pipeline mein `swati generate` (Idea #7) |
| 👥 Team presets | Shared `swati.yaml` = team standard (Idea #19) |
| 🧩 Editor support | JSON Schema publish karo → VS Code mein autocomplete |
| ⬆️ Safe upgrades | `schemaVersion` + migrations — purani config naye version mein auto-upgrade |

### What Gets Generated:
```
swati.yaml                    ← source of truth
.swati/
├── schema/
│   └── swati.schema.json     ← editor autocomplete ke liye
└── migrations/
    └── v2_to_v3.json
```

---

## 🏁 Implementation Priority Matrix (Ideas 26–40)

| Priority | Feature | Impact | Effort | ROI |
|---|---|---|---|---|
| 🔴 P0 | #26 Regeneration-Safe Codegen | 🔥🔥🔥🔥🔥 | High | Iska bina tool "ek baar use" ka rehta hai — foundation |
| 🔴 P0 | #28 Database Schema Designer | 🔥🔥🔥🔥🔥 | High | Models, CRUD, mock, docs — sab iske upar bante hain |
| 🔴 P0 | #29 CRUD / Form Scaffolder | 🔥🔥🔥🔥🔥 | Medium | Sabse zyada dev time bachata hai |
| 🟡 P1 | #30 Push Notification Setup | 🔥🔥🔥🔥 | Medium | Almost har production app ko chahiye |
| 🟡 P1 | #31 Remote Config & Force Update | 🔥🔥🔥🔥 | Medium | Store update ke bina control |
| 🟡 P1 | #27 Brownfield Mode | 🔥🔥🔥🔥 | High | Existing projects = bada user base |
| 🟡 P1 | #34 UI States Kit | 🔥🔥🔥🔥 | Low | Cheap hai, har screen mein kaam aata hai |
| 🟡 P1 | #33 Legal & Store Compliance | 🔥🔥🔥🔥 | Medium | Publish blockers hatata hai |
| 🟢 P2 | #32 Backend Scaffold | 🔥🔥🔥🔥 | Very High | Full-stack story, par effort bada |
| 🟢 P2 | #35 Icon / Splash / Branding | 🔥🔥🔥 | Low | Quick win, visible polish |
| 🟢 P2 | #36 Mock Data & Fake Server | 🔥🔥🔥 | Medium | Frontend-first development |
| 🟢 P2 | #40 Headless CLI & Config-as-Code | 🔥🔥🔥🔥 | Medium | CI + reproducibility |
| 🔵 P3 | #37 Accessibility & Responsive | 🔥🔥🔥 | Medium | Tablet / web targets ke liye |
| 🔵 P3 | #38 Size & Performance Budget | 🔥🔥 | Medium | Optimization phase feature |
| 🔵 P3 | #39 Auto Documentation | 🔥🔥🔥 | Low | Nice to have, #26 ke baad easy |

---

## 🔗 Dependency Map (kaun kis par depend karta hai)

```
                    #26 Regeneration-Safe Codegen   ← sabki foundation
                         │
        ┌────────────────┼──────────────────┐
        ▼                ▼                  ▼
  #27 Brownfield   #40 CLI + Config    #39 Auto Docs
                                            ▲
  #28 Schema Designer ──┬──► #29 CRUD Scaffolder
        │               ├──► #36 Mock Data
        │               ├──► #32 Backend Scaffold ◄── #5 API Builder (Part 1)
        │               └──► #39 DATABASE.md
        │
        └──► #8 RBAC (Part 1) → RLS policies

  #30 Push ──► #14 Deep Links (Part 1)   (tap → screen routing)
  #31 Remote Config ──► #6 Environments (Part 1)
  #33 Legal ──► #12 Security, #13 Analytics, #10 Monetization (Part 1)
```

### Suggested Build Order:
1. **#26** pehle — warna baaki saare features "ek baar generate" tak hi limited rahenge
2. **#28 → #29** — schema ke baad CRUD, yahi sabse bada visible jump hoga
3. **#34** (cheap, har jagah kaam aata hai) aur **#30 / #31** (production essentials)
4. **#33** — publish karne se pehle zaroori
5. Baaki P2 / P3 apne hisaab se

---

## 🎯 Part 2 Summary

> Part 1 ne wizard ko **zyada features** diye. Part 2 usse **zyada reliable** banata hai:
>
> 1. **Safe Regeneration** — user ka code kabhi overwrite nahi hoga (#26)
> 2. **Existing Projects** — sirf naye projects nahi, purane projects mein bhi add-ons (#27)
> 3. **Data-First** — schema se models, CRUD, mock aur docs sab ek flow mein (#28, #29, #36, #39)
> 4. **Production-Ready** — push, remote config, compliance, UI states, size budget (#30, #31, #33, #34, #38)
> 5. **Full-Stack** — frontend ke saath backend bhi, ek hi API contract se (#32)
> 6. **Automation** — CLI + config-as-code se CI aur teams ke liye ready (#40)

---

*Document ends. Yeh Part 2 hai — Part 1 (Ideas 1–25) ke saath padho. Implementation ke waqt Priority Matrix aur Dependency Map dono follow karo.*
