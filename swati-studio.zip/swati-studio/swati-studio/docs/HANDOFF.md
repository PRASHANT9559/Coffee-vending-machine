# Handoff — for Mukesh

Welcome aboard. This is everything you need to run, understand and extend
**Swati Studio**.

---

## TL;DR

The original `swati-studio.html` was a beautiful UI mock-up whose "Generate
Project" button produced **nothing**. This repo is the real version:

* **Next.js 15 + Tailwind v4** — the wizard UI
* **Tauri v2 + Rust** — the desktop shell, file writing, zipping, native dialogs
* **A schema-first design** — adding a new option is a *data change*, not a
  code change
* **A real generator** — it writes a compiling Flutter project to your disk

```bash
npm install
npm run dev          # browser  → http://localhost:3000
npm run tauri:dev    # desktop  → native window
```

---

## Where things are

| I want to… | Go to |
| --- | --- |
| add a backend / database / feature / style | `packages/schema/src/catalogs/` |
| add or change a wizard step or field | `packages/schema/src/schema.ts` |
| change the generated Dart code | `packages/generator/src/templates/` |
| change where the generated folders go | `packages/generator/src/layout.ts` |
| change the look and feel | `apps/studio/src/app/globals.css` |
| add a native capability | `src-tauri/src/commands.rs` |
| understand the design | `docs/ARCHITECTURE.md` |
| see what changed vs the prototype | `docs/MIGRATION.md` + `docs/PROTOTYPE-AUDIT.md` |

---

## The one concept that matters

**You never write UI to add an option.**

```ts
// packages/schema/src/catalogs/backends.ts
{
  id: 'planetscale',
  name: 'PlanetScale',
  desc: 'Serverless MySQL',
  accent: '#b9fbc0',
  tags: ['sql', 'serverless'],
  data: { sdk: 'dio', kind: 'server' },
  fields: [
    { id: 'backend.planetscale.url', kind: 'text', label: 'Connection URL' },
  ],
}
```

Save the file, and you immediately get:

1. a "PlanetScale" entry in the backend dropdown (searchable, with the accent dot)
2. a "Connection URL" input that appears **only** when PlanetScale is selected
3. a validation rule for that input
4. a row in the review summary
5. `dio` in the generated `pubspec.yaml`
6. `lib/core/network/api_client.dart` in the generated project

Same trick works for a new wizard step, a new architecture, a new feature
category, a new theme colour, a new home-page style.

---

## Verified state

| Check | Result |
| --- | --- |
| `npm run typecheck` | ✅ clean (`tsc --noEmit`, strict) |
| `npm test` | ✅ 80/80 passing (schema + generator + generated-Dart sanity) |
| `npm run build` | ✅ Next 15.5 static export → `apps/studio/out` |
| `npm run preview` | ✅ serves `/` and `/wizard/` on :4173 |
| `cargo check` | ✅ clean, no warnings (Tauri 2.12) |
| `cargo build` | ✅ links the desktop binary |

Run them yourself:

```bash
npm run typecheck
npm test
npm run build && npm run preview   # → http://localhost:4173
cd src-tauri && cargo check
```

### One environment gotcha

If `cargo check` fails with
`error: failed to create encoded metadata from file: No such file or directory`,
the build is running on a network/FUSE mount that rustc dislikes. Point the
build at a normal filesystem:

```bash
CARGO_TARGET_DIR=/tmp/cargo-target cargo check
```

That is an environment quirk, not a code problem.

---

## Known limitations (be honest about these)

1. **The generator targets Flutter/Dart only.** A React Native or Next.js
   target needs a second planner next to `packages/generator/src/plan.ts`.
   The seam is intentionally left open.
2. **The desktop build needs Linux system libraries** (see README). On
   macOS/Windows use the bundled Tauri prerequisites.
3. **The generated Dart is a scaffold, not a product.** It compiles and shows
   the structure your choices imply; the business logic is still yours to
   write — that is the entire point of the tool.
4. **No CI yet.** Add a GitHub Actions workflow that runs
   `npm ci && npm run typecheck && npm test && npm run build` and
   `cargo check` — that is 20 minutes of work and worth doing.

---

## Suggested next steps (in priority order)

1. **Add a second generator target** — a Next.js app target would prove the
   architecture generalises. `packages/generator/src/targets/nextjs/`.
2. **Wire `pick_output_dir`** into the review step — the Rust command exists,
   the button does not.
3. **Use `run_flutter_create`** when the toggle is on — it produces real
   `android/` and `ios/` folders.
4. **Add a "Templates" feature** — save a configuration as a named preset and
   load it back. The config is already JSON; it needs a small store.
5. **Add CI** (see above).
6. **Snapshot tests** for the generated tree — `toMatchSnapshot()` on
   `generateProject(defaultConfig()).files` catches accidental template drift.

---

## Handy commands

```bash
npm run dev            # Next dev server
npm run build          # static export → apps/studio/out
npm run preview        # serve the export on :4173
npm test               # vitest
npm run typecheck      # tsc --noEmit
npm run tauri:dev      # desktop app
npm run tauri:build    # native installer
```

Inside `src-tauri/`:

```bash
cargo check            # fast compile check
cargo clippy           # lint
cargo tauri build      # release build with the frontend bundled
```

---

## Handy shortcuts in the app

| Key | Action |
| --- | --- |
| `Ctrl+K` | command palette — jump to any step or setting |
| `Ctrl+S` | save draft (browser + native) |
| `Ctrl+⏎` | generate the project |
| `Ctrl+→` / `Ctrl+←` | next / previous step |
| `Ctrl+Shift+L` | toggle light/dark |
| `?` | shortcut cheat sheet |

---

## Questions? Open the docs in this order

1. `docs/PROTOTYPE-AUDIT.md` — what the original got wrong
2. `docs/MIGRATION.md` — how each piece moved
3. `docs/ARCHITECTURE.md` — how the new thing works
4. `README.md` — quick start and the repository map
