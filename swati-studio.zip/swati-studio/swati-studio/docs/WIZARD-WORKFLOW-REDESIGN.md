# 🧙‍♂️ Swati Studio — Wizard Workflow Redesign & Implementation Guide

> **Author**: Swati Studio Team & Antigravity  
> **Status**: ✅ **Implemented & Production-Ready** (Tasks 1 to 4 Completed)  
> **Location in Project**: `docs/WIZARD-WORKFLOW-REDESIGN.md` (Phone-readable, no hidden dot folders)

---

## 🎯 Executive Overview & Architecture

Swati Studio के Wizard को एक **Enterprise-Grade Interactive Studio** में transform कर दिया गया है। 
11-Step Wizard Workflow में **Left Panel** (Controls & Dynamic Inputs) और **Right Panel** (Interactive Live Phone Mockup) आपस में real-time synced हैं।

```mermaid
flowchart LR
    subgraph Wizard["🧙 Swati Studio Wizard (Split Panel)"]
        direction LR
        subgraph LeftPanel["⚙️ Configuration Panel"]
            T1["Step 1: Theme & Worldwide UI Styles\n(43 Styles + 6 Layers + 20 Combos)"]
            T2["Step 2: Navigation & Dynamic Buttons\n(11 UI Kit Styles + Live Screen Generator)"]
            T3["Step 3: Project Metadata & Package ID"]
            T4["Step 4: Database Engine & File Bundler\n(.db, .sqlite, .json, .hive, .isar)"]
        end
        subgraph RightPanel["📱 Interactive Live Phone Preview"]
            P1["Live Theme Shader & AMOLED/Sepia Renderer"]
            P2["11 Interactive Nav Bars with Live Click State"]
            P3["AppBar Title Matching Active Button Name"]
            P4["Database Asset Status & Architecture Tile"]
        end
    end
    T1 -.-> P1
    T2 -.-> P2
    T2 -.-> P3
    T4 -.-> P4
```

---

## 🎨 Task 1: Theme & Design System (themes.txt Deep Integration)

`themes.txt` के सभी design specifications को catalogs, live UI preview, और Flutter code generator में implement किया गया है:

### 1. The 6 Theme Layers (har style par apply hoti hain)
1. ☀️ **Light Theme**: Clean, crisp, high-legibility canvas (`#FFFFFF` / `#F8FAFC`).
2. 🌙 **Dark Theme**: Modern slate/charcoal dark surface (`#0F172A`).
3. ⚫ **AMOLED / True Black (`#000000`)**: Zero gray wash, pitch black canvas saving battery on OLED displays.
4. 📜 **Warm Sepia Paper (`#FBF0D9`)**: Tactile parchment tone with soft text (`#45321F`) for eye comfort during long reading sessions.
5. 🔄 **Adaptive / Both**: Flutter `ThemeMode.system` automatically reacts to Android/iOS OS dark/light switch.
6. ♿ **High Contrast**: Vivid contrast ratios for accessibility.

### 2. Worldwide UI Styles (Part 1 of themes.txt)
Cataloged in `packages/schema/src/catalogs/styles.ts` with real-time CSS recipes in `PhonePreview.tsx`:
- **Glassmorphism**: Frosted glass cards, `backdrop-filter: blur(14px)`, `border: 1px solid rgba(255,255,255,0.15)`.
- **Liquid Glass (iOS 26 Style)**: Refractive glass highlights, light reflections, and layered spatial depth.
- **Neo-Brutalism**: Thick 3px solid black borders, hard 5px drop shadows (`box-shadow: 5px 5px 0px #000`), bold saturated background colors (`#fef08a`).
- **Neumorphism (Soft UI)**: Extruded surfaces with dual soft shadows (`box-shadow: 8px 8px 16px #cbd5e1, -8px -8px 16px #ffffff`).
- **Claymorphism**: Puffy pillowy cards, `border-radius: 28px`, inset gradient shadows (`inset -6px -6px 12px rgba(196,107,139,0.2)`).
- **Cyberpunk Neon**: Electric cyan text (`#00F6FF`), magenta neon borders (`#D946EF`), and pitch black backdrop (`#050508`).
- **Terminal / Hacker CLI**: Monospace typography (`Courier`, `JetBrains Mono`), matrix green text (`#22C55E`), scanline cards.
- **Y2K Chrome**: 2000s glossy chrome highlights, specular reflections, and bubble buttons.
- **Retro-Futurism / Synthwave**: 80s purple-pink neon grids with sunset gradient vibes.
- **Bento Grid UI**: Modular Apple & Linear inspired tile boxes.
- **Aurora Glow**: Ambient glowing gradient blobs diffusing softly under frosted glass.
- **Flat 2.0 & Minimalism**: Solid clean geometry, zero heavy clutter.

### 3. The 20 Mixed Combos (Part 3 of themes.txt)
Cataloged in `packages/schema/src/catalogs/aestheticCombos.ts`:
1. **NeuGlass** (Glassmorphism + Neumorphism)
2. **Midnight Glass** (Glassmorphism + Dark)
3. **Frosted Light** (Glassmorphism + Light)
4. **Soft Light UI** (Neumorphism + Light)
5. **Shadow Neu** (Neumorphism + Dark)
6. **Aurora Glass** (Aurora + Glass)
7. **Glass Bento** (Bento + Glass)
8. **Neu Bento** (Bento + Neumorphism)
9. **ClayGlass** (Clay + Glass)
10. **Brutal Pop** (Neo-Brutalism + Light)
11. **CyberGlass** (Cyberpunk + Glass)
12. **Material Glass** (Material 3 + Glass)
13. **Obsidian Glass** (Liquid Glass + AMOLED True Black `#000000`)
14. **Ghost UI** (Minimal + Glass)
15. **Prism UI** (Mesh Gradient + Glass)
16. **Soft Clay** (Neumorphism + Claymorphism)
17. **Hacker Glass** (Terminal + Glass)
18. **Chrome Glass** (Y2K Chrome + Glass)
19. **Retro-Futurism** (Retro + Futuristic Synthwave)
20. **Brutal Glass** (Brutalism + Glassmorphism)

---

## 🧭 Task 2: Navigation Styles & Dynamic Screen Generation

UI Kit image (`UI Kit_ Social Media Page Designs & Button Framers.jpeg`) se **11 ke 11 Bottom Navigation Styles** integrate kiye gaye hain:

| # | Style ID | UI Kit Name | Visual Behavior |
|---|---|---|---|
| 1 | `minimal_clean` | Style 1: Minimal Clean | Sleek borderless bottom bar with crisp icons & active color transition |
| 2 | `glassmorphism` | Style 2: Glassmorphism Frosted | Translucent frosted glass bar, backdrop blur, subtle top border highlight |
| 3 | `floating_detached`| Style 3: Floating Detached Island | Rounded pill floating 16px above screen bottom with elevated shadow |
| 4 | `neumorphism` | Style 4: Soft Neumorphic | Dual-embossed extruded shadows blending into the scaffold canvas |
| 5 | `pill_highlight` | Style 5: Pill Tab Highlight | Active item slides inside an enclosed rounded capsule background |
| 6 | `center_fab` | Style 6: Center Action FAB Notch | Center action button elevated with a curved cradle notch cutout |
| 7 | `gradient_bold` | Style 7: Gradient Accent Bar | Top gradient border line or gradient active icon glow |
| 8 | `outline_icons` | Style 8: Modern Outline Icons | Stroke-outline icon style transitioning to filled + badge on selection |
| 9 | `tab_indicator` | Style 9: Top Dot / Line Indicator | Smooth animated dot or line indicator gliding directly under active item |
| 10 | `curved_bg` | Style 10: Organic Curved Wave | Subtle organic wave silhouette along top edge of navigation bar |
| 11 | `dock_ios` | Style 11: macOS / iOS Dock | Compact floating rounded dock with icon scale magnification |
| + | `drawer` | Side Navigation Drawer | Material 3 slide-out hamburger navigation drawer |
| + | `rail` | Navigation Rail | Vertical rail bar optimized for tablets, foldable and desktop screens |

### Mandatory Dynamic Buttons & Screen Generation Rules:
1. **Minimum 2 Buttons Validation**: Wizard Step 2 validates that at least 2 navigation buttons exist.
2. **Bottom Bar Capacity Warning**: Agar Bottom Bar styles me 5 se zyada buttons add kiye jayein, toh wizard alert warning deta hai.
3. **Button Name = Screen Title**: Button ka jo bhi name hoga (e.g. `Orders`), generated screen ka AppBar title exactly wahi hoga:
   ```dart
   appBar: AppBar(
     title: const Text('Orders'),
     centerTitle: true,
   ),
   ```
4. **Button Name = Feature File & Route**:
   - Name: `Orders` → Route: `/orders` → File: `lib/features/orders/orders_screen.dart`
   - Name: `Analytics` → Route: `/analytics` → File: `lib/features/analytics/analytics_screen.dart`
5. **Interactive Phone Mockup Sync**: Phone preview me bottom bar ke buttons par click karne par live screen switch hoti hai aur AppBar title instant change hota hai!

---

## 🗄️ Task 4: Database File Upload & Asset Bundling

1. **Upload Field (`packages/schema/src/catalogs/databases.ts` & `apps/studio/src/components/ui/FileUploadField.tsx`)**:
   - Drag-and-drop & file browser input for `.db`, `.sqlite`, `.sqlite3`, `.json`, `.hive`, `.isar`.
   - File size, name, extension, aur base64 payload preserve hota hai.
2. **Asset Bundling Engine (`packages/generator/src/plan.ts`)**:
   - Uploaded file ko direct `assets/db/<filename>` me copy kiya jata hai.
3. **Pubspec Integration (`packages/generator/src/templates/pubspec.ts`)**:
   - `pubspec.yaml` me automatically `assets/db/` assets block add hota hai:
   ```yaml
   flutter:
     uses-material-design: true
     assets:
       - assets/db/
   ```

---

## 🧪 Verification & Test Suite

Tests covered in `tests/schema.test.ts` and `tests/generator.test.ts`:
- **11 Wizard Steps Schema Integrity**: Step 1 (Theme), Step 2 (Navigation), Step 3 (Project), Step 4 (Database), ..., Step 11 (Export).
- **13 Navigation Styles Validation**: All 11 UI Kit styles + Drawer + Rail recognized and validated.
- **Dynamic Button Code Generation**: Verifies that custom buttons (`Dashboard`, `Orders`, `Analytics`, `Settings`) create matching screens with titles `AppBar(title: Text('Orders'))`.
- **Database File Bundling**: Verifies that uploaded database files appear in `assets/db/` and `pubspec.yaml`.
- **AMOLED & Sepia Theme Generation**: Verifies scaffold background `#000000` for AMOLED, `#FBF0D9` for Sepia, and 3px black borders for Neo-Brutalism.
