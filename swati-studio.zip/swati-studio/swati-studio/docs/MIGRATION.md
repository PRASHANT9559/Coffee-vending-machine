# Prototype → real software: the migration map

This document answers the question *"how do we turn that HTML file into real
software?"* line by line, using the original
`swati-studio.html` (1 417 lines) as the starting point.

---

## 1. What the original file really was

A single HTML file containing:

* a Tailwind CDN script and an inline `tailwind.config`
* ~330 lines of static markup (sidebar, header, modals, phone mockup)
* ~40 hard-coded option arrays (`backends`, `databases`, `architectures`, …)
* ~20 render functions that build HTML strings
* a global mutable `state` object
* `localStorage` persistence
* zero build step, zero tests, zero real output

It was a **UI prototype**, and a good one. But everything that makes software
*software* was missing: no state discipline, no validation, no type safety, no
tests, no real file output, no native integration, and a rendering model
(string concatenation) that cannot be reasoned about.

---

## 2. The seven real problems, and what replaced them

### 2.1 The options were hard-coded in render functions

**Before** — `renderBackendStep()` inlined the whole grid; adding a backend meant
copy-pasting 20 lines of HTML *and* writing a branch in `renderBackendConfig()`.

**After** — `packages/schema/src/catalogs/backends.ts` holds data only:

```ts
{ id: 'supabase', name: 'Supabase', desc: '…', fields: [ … ] }
```

The grid, the dropdown, the dynamic credential inputs, the validation, the review
card and the generated `pubspec.yaml` entry all read from that one object.
`<SchemaField />` is the only component that knows how to draw a field, and it
does not know what a "backend" is.

### 2.2 The dropdown did not exist

**Before** — every choice was a 3-column wall of cards. Backend (11), Database (9),
Architecture (6), State (5), Features (22), Components (13) = 66 large cards
across 6 steps. You had to scroll to compare two options.

**After** — every catalog field supports a `presentation`:

| `presentation` | Rendering |
| --- | --- |
| `dropdown` | searchable combobox (arrow keys, type-to-filter, Esc) |
| `cards` | the original card grid, for choices that benefit from comparison |
| `chips` | compact multi-select chips |
| `swatches` | colour swatch grid |

So the backend and database steps are now **one dropdown + the fields that
provider actually needs**, which is the "dropdown UI" upgrade.

### 2.3 `generateProject()` generated nothing

**Before** — a 5-step progress modal driven by `setInterval`, ending in
`showToast('Project generated successfully!')`. No file was ever created.

**After** — the generator is a pure function:

```ts
generateProject(config) -> { files: GeneratedFile[], summary, context }
```

It produces 25–40 real files (Dart, YAML, Markdown, JSON) whose contents are
derived from the choices, and the Rust backend writes them to disk and zips
them. The preview step shows the *actual* tree, because it calls the same
function the writer calls.

### 2.4 The draft was saved and never restored

**Before** — `saveDraft()` wrote `JSON.stringify(state)` to `localStorage`.
`state.features` and `state.components` are `Set`s, and `JSON.stringify(new Set())`
produces `{}`. The stored draft was therefore **corrupt on every save**, and
nothing ever read it back anyway.

**After** — the store uses `zustand` + `persist` (which serialises Sets as
arrays correctly), the draft is also written to the OS app-data directory by
the Rust side, and `load_draft` can restore it.

### 2.5 The search was inverted

**Before** — `if ('project name'.includes(q))`. The haystack was the literal
string `"project name"` and the needle was the user's query, so searching `am`
matched "project name" and searching `colour` matched nothing.

**After** — `CommandPalette` searches a real entry list (`label + description`)
and supports arrow-key navigation.

### 2.6 Eight dead navigation items

**Before** — Templates, Components, Plugins, Preview, Settings, Documentation,
GitHub and About were `href="#"` anchors with no handler at all.

**After** — the sidebar renders only the 10 real steps, and every step is
reachable from the `Ctrl+K` palette as well.

### 2.7 No validation, no type safety, no tests

**Before** — a user could enter `Not A Package` as the package name and the
"generated" project would be nonsense. No tests existed.

**After** —

* `validateConfig()` checks package id, version, required selections, ranges and
  every dynamic provider field
* the whole codebase is TypeScript with `strict: true`
* 57 unit tests cover catalog integrity, schema defaults, validation,
  import/export and the generator output

---

## 3. Concept mapping

| Original concept | Where it lives now |
| --- | --- |
| `const state = {...}` | `useStudioStore` (zustand) + `StudioConfig` type |
| `const backends = [...]` | `packages/schema/src/catalogs/backends.ts` |
| `const steps = [...]` | `packages/schema/src/schema.ts` (with `fields` per step) |
| `renderStep()` + 10 renderers | one `<SchemaField />` driven by `FieldDef` |
| `renderBackendConfig(id)` | `OptionDef.fields` + `visibleWhen` |
| `updatePhonePreview()` | `<PhonePreview />` (React, props) |
| `generateFolderStructure()` | `buildTree(generateProject(config).files)` |
| `generateProject()` (fake) | `packages/generator` + Rust `write_project` |
| `exportConfig()` | `serializeConfig()` / `parseConfig()` |
| `saveDraft()` | zustand persist + Rust `save_draft` |
| `updatePreviewStats()` (fake numbers) | real `GenerateSummary` from the real tree |
| `setupKeyboardShortcuts()` | one `useEffect` in `/wizard/page.tsx` |
| `tailwind.config` inline | Tailwind v4 CSS-first `@theme` in `globals.css` |
| `<script src="cdn.tailwindcss.com">` | real Tailwind v4 build pipeline |
| — | **new**: Tauri v2 shell, Rust backend, native dialogs, toolchain detect |

---

## 4. Why these technologies

| Choice | Reason |
| --- | --- |
| **Tauri v2** | ~10 MB installer vs ~90 MB for Electron; the webview is the OS one. Gives a real desktop app from the same Next.js code. |
| **Rust** | The native work (path-safe file IO, zip, `flutter create` subprocess, `PATH` probing) belongs in Rust: fast, safe, no runtime to ship. |
| **Next.js 15 (App Router, static export)** | The app is a wizard, not a content site — a static export means Tauri ships plain files, no Node server in production. |
| **Tailwind v4** | CSS-first config, no `tailwind.config.js` needed, and the same class names port over from the prototype 1:1. |
| **zod-free, hand-rolled validation** | The schema already *is* the validation source; a second validation library would duplicate it. |
| **zustand** | Tiny, no provider boilerplate, and its `persist` middleware fixes the Set-serialisation bug for free. |

---

## 5. How to add things (the whole point)

**A new backend**

```ts
// packages/schema/src/catalogs/backends.ts
{
  id: 'planetscale',
  name: 'PlanetScale',
  desc: 'Serverless MySQL',
  data: { sdk: 'dio', kind: 'server' },
  fields: [{ id: 'backend.planetscale.url', kind: 'text', label: 'Connection URL' }],
}
```

Add its `dio` package to `BACKEND_PACKAGES` in `packages/generator/src/context.ts`.
Done — dropdown, validation, summary, generated `pubspec.yaml` and
`lib/core/network/api_client.dart` all follow.

**A new UI step**

```ts
// packages/schema/src/schema.ts
{
  id: 'payments',
  label: 'Payments',
  icon: 'CreditCard',
  title: 'Payments',
  subtitle: 'Pick a payment provider',
  fields: [{ id: 'payments.provider', kind: 'select', label: 'Provider', options: […] }],
}
```

The stepper, the sidebar, the navigation, the review summary and the `Ctrl+K`
palette all pick it up automatically.

**A new architecture**

Add one entry to `catalogs/architectures.ts` and one entry to
`packages/generator/src/layout.ts` that says where the folders go. The
generated tree changes; nothing else does.

**A new output target (e.g. React Native, Next.js instead of Flutter)**

Create `packages/generator/src/templates/<target>/` and a second planner next to
`plan.ts`, then switch on a new `project.target` field. The wizard, the
validation and the review screen already work with any target.

---

## 6. Honest limitations

* The generator targets **Flutter/Dart**. Other targets need a second planner
  (the seam is deliberately left open in `packages/generator`).
* The desktop shell was compiled with `cargo check` on Linux; GTK/WebKit dev
  libraries are required to produce an installer.
* The generated Dart is template-driven and compiles for the common case, but a
  real product still needs its business logic written by a human — that is the
  point of the tool.
