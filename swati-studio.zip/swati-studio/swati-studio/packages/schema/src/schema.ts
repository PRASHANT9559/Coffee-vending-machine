import type { StepDef } from './types';
import { aestheticCombos } from './catalogs/aestheticCombos';
import { architectures } from './catalogs/architectures';
import { backends } from './catalogs/backends';
import { componentCategories } from './catalogs/components';
import { databases } from './catalogs/databases';
import { featureList } from './catalogs/features';
import { navigationStyles } from './catalogs/navigationStyles';
import { stateManagers } from './catalogs/states';
import {
  animations,
  fonts,
  homeStyles,
  licenses,
  platforms,
  spacings,
  themeModes,
  uiStyles,
} from './catalogs/styles';
import { themeColors } from './catalogs/themeColors';
import { authMethods, authScreens, authSecurityFlags } from './catalogs/authMethods';
import { cicdPlatforms, environmentOptions, supportedLocales } from './catalogs/environments';

export const steps: StepDef[] = [
  /* ---------------------------------------------------------- *
   * Step 1: Theme & Design
   * ---------------------------------------------------------- */
  {
    id: 'frontend',
    label: 'Theme & Design',
    icon: 'Palette',
    title: 'Theme & Design System',
    subtitle: 'Customize typography, color tokens, and design language with instant live preview',
    fields: [
      {
        id: 'frontend.aestheticCombo',
        kind: 'select',
        label: 'Aesthetic Design Combo (Preset)',
        presentation: 'dropdown',
        options: aestheticCombos,
        default: 'midnight_glass',
        help: 'Pre-mixed design recipes from worldwide UI styles (Glass, Neumorphism, Clay, Neo-Brutalism)',
      },
      {
        id: 'frontend.themeMode',
        kind: 'select',
        label: 'Theme Layer (Brightness)',
        presentation: 'cards',
        options: themeModes,
        default: 'dark',
        help: 'Choose appearance mode: Light, Dark, AMOLED (True Black #000), Warm Sepia or Adaptive',
      },
      {
        id: 'frontend.uiStyle',
        kind: 'select',
        label: 'Design System & UI Style',
        presentation: 'cards',
        options: uiStyles,
        default: 'glassmorphism',
      },
      {
        id: 'frontend.themeColor',
        kind: 'select',
        label: 'Theme Palette',
        presentation: 'swatches',
        options: themeColors,
        default: 'indigo',
        help: 'Select a primary color scheme or dual light/dark palette',
      },
      {
        id: 'frontend.font',
        kind: 'select',
        label: 'Font Family',
        presentation: 'dropdown',
        options: fonts,
        default: 'Inter',
      },
      {
        id: 'frontend.borderRadius',
        kind: 'range',
        label: 'Border Radius',
        min: 0,
        max: 32,
        step: 2,
        suffix: 'px',
        default: 12,
      },
      {
        id: 'frontend.spacing',
        kind: 'select',
        label: 'Spacing Density',
        presentation: 'cards',
        options: spacings,
        default: 'normal',
      },
      {
        id: 'frontend.animation',
        kind: 'select',
        label: 'Micro-Interactions & Animation',
        presentation: 'dropdown',
        options: animations,
        default: 'smooth',
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 2: Navigation & Dynamic Screens
   * ---------------------------------------------------------- */
  {
    id: 'navigation',
    label: 'Navigation',
    icon: 'Compass',
    title: 'Navigation & App Structure',
    subtitle: 'Choose navigation style and add dynamic buttons — each button auto-generates its own screen',
    fields: [
      {
        id: 'navigation.style',
        kind: 'select',
        label: 'Navigation Style',
        presentation: 'cards',
        options: navigationStyles,
        default: 'minimal_clean',
        help: 'Select how users switch between primary screens in your application',
      },
      {
        id: 'navigation.items',
        kind: 'list',
        label: 'Navigation Buttons (Mandatory)',
        help: 'Add at least 2 buttons. Each button creates a dedicated screen file and named route.',
        required: true,
        default: [
          { id: 'nav-home', name: 'Home', icon: 'Home', route: '/home', title: 'Home' },
          { id: 'nav-search', name: 'Search', icon: 'Search', route: '/search', title: 'Search' },
          { id: 'nav-profile', name: 'Profile', icon: 'User', route: '/profile', title: 'Profile' },
        ],
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 3: Project Information
   * ---------------------------------------------------------- */
  {
    id: 'project',
    label: 'Project',
    icon: 'Folder',
    title: 'Project Information',
    subtitle: 'Define the foundation and metadata of your application',
    fields: [
      {
        id: 'project.name',
        kind: 'text',
        label: 'Project Name',
        placeholder: 'My Flutter App',
        help: 'The human-readable title of your application',
        required: true,
        default: 'My Flutter App',
      },
      {
        id: 'project.packageName',
        kind: 'text',
        label: 'Package ID / Bundle Identifier',
        placeholder: 'com.example.my_flutter_app',
        help: 'Must be a valid lowercase identifier (e.g. com.example.app)',
        required: true,
        default: 'com.example.my_flutter_app',
      },
      {
        id: 'project.organization',
        kind: 'text',
        label: 'Organization Domain',
        placeholder: 'com.example',
        default: 'com.example',
      },
      {
        id: 'project.version',
        kind: 'text',
        label: 'Version',
        placeholder: '1.0.0',
        default: '1.0.0',
      },
      {
        id: 'project.license',
        kind: 'select',
        label: 'Open Source License',
        presentation: 'dropdown',
        options: licenses,
        default: 'MIT',
      },
      {
        id: 'project.homeStyle',
        kind: 'select',
        label: 'Home Page Design Style',
        presentation: 'dropdown',
        options: homeStyles,
        default: 'studio',
      },
      {
        id: 'project.platforms',
        kind: 'multiselect',
        label: 'Target Platforms',
        presentation: 'chips',
        options: platforms,
        default: ['android', 'ios', 'web'],
      },
      {
        id: 'project.environmentFlavor',
        kind: 'select',
        label: 'Environments & Flavors',
        presentation: 'dropdown',
        options: environmentOptions,
        default: 'single',
        help: 'Generates dev, staging, and prod configurations with .env files and app_config.dart',
      },
      {
        id: 'project.cicdPlatform',
        kind: 'select',
        label: 'CI/CD Pipeline Automation',
        presentation: 'dropdown',
        options: cicdPlatforms,
        default: 'github_actions',
        help: 'Auto-generates GitHub Actions or GitLab CI test & build workflows',
      },
      {
        id: 'project.locale',
        kind: 'select',
        label: 'Primary Language & i18n',
        presentation: 'dropdown',
        options: supportedLocales,
        default: 'en',
        help: 'Generates ARB localization files and LocaleProvider',
      },
      {
        id: 'project.description',
        kind: 'textarea',
        label: 'Description',
        placeholder: 'A beautiful cross-platform application built with Flutter...',
        default: 'A modern, high-performance cross-platform Flutter application',
      },
      {
        id: 'project.readme',
        kind: 'toggle',
        label: 'Generate README & Architecture Docs',
        help: 'Creates a rich README.md with setup instructions, runbooks, and file map',
        default: true,
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 4: Database & Persistence (+ File Upload)
   * ---------------------------------------------------------- */
  {
    id: 'database',
    label: 'Database',
    icon: 'Database',
    title: 'Database & Local Storage',
    subtitle: 'Select database engine and optionally import an existing database file',
    fields: [
      {
        id: 'database.engine',
        kind: 'select',
        label: 'Database Engine',
        presentation: 'dropdown',
        options: databases,
        default: 'sqlite',
      },
      {
        id: 'database.file',
        kind: 'file',
        label: 'Import Existing Database File (Optional)',
        help: 'Drag and drop or browse to upload an existing .db, .sqlite, .json, .hive, or .isar file to bundle into assets/db/',
        accept: '.db,.sqlite,.sqlite3,.json,.hive,.isar',
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 5: Backend Integration
   * ---------------------------------------------------------- */
  {
    id: 'backend',
    label: 'Backend',
    icon: 'Server',
    title: 'Backend Integration',
    subtitle: 'Connect with a BaaS provider or custom REST API',
    fields: [
      {
        id: 'backend.provider',
        kind: 'select',
        label: 'Backend Service',
        presentation: 'dropdown',
        options: backends,
        default: 'supabase',
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 6: Architecture Pattern
   * ---------------------------------------------------------- */
  {
    id: 'architecture',
    label: 'Architecture',
    icon: 'Layers',
    title: 'Architecture Pattern',
    subtitle: 'Determine codebase directory organization and layering boundaries',
    fields: [
      {
        id: 'architecture.pattern',
        kind: 'select',
        label: 'Design Pattern',
        presentation: 'cards',
        options: architectures,
        default: 'feature_first',
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 7: State Management
   * ---------------------------------------------------------- */
  {
    id: 'state',
    label: 'State',
    icon: 'Zap',
    title: 'State Management',
    subtitle: 'Choose your reactive state management engine',
    fields: [
      {
        id: 'state.manager',
        kind: 'select',
        label: 'State Manager',
        presentation: 'cards',
        options: stateManagers,
        default: 'riverpod',
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 8: Features & Capabilities
   * ---------------------------------------------------------- */
  {
    id: 'features',
    label: 'Features',
    icon: 'CheckCircle2',
    title: 'Features & Capabilities',
    subtitle: 'Pick optional capabilities to scaffold modules and dependencies',
    fields: [
      {
        id: 'features.selected',
        kind: 'multiselect',
        label: 'Features',
        presentation: 'chips',
        options: featureList,
        default: ['authentication', 'offline', 'analytics'],
      },
      {
        id: 'auth.methods',
        kind: 'multiselect',
        label: 'Authentication Providers',
        presentation: 'chips',
        options: authMethods,
        default: ['email_password', 'google_oauth', 'biometric'],
        help: 'Select login methods to scaffold in the authentication flow',
      },
      {
        id: 'auth.screens',
        kind: 'multiselect',
        label: 'Authentication Screens',
        presentation: 'chips',
        options: authScreens,
        default: ['login', 'register', 'forgot_password'],
        help: 'Dedicated auth screens auto-wired to the navigator',
      },
      {
        id: 'security.enableRbac',
        kind: 'toggle',
        label: 'Role-Based Access Control (RBAC)',
        help: 'Generates UserRole enum, RoleGuard route protection, and RoleBasedWidget',
        default: false,
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 9: Shared Component Library
   * ---------------------------------------------------------- */
  {
    id: 'components',
    label: 'Components',
    icon: 'LayoutGrid',
    title: 'Shared Component Library',
    subtitle: 'Include pre-built, theme-aware Flutter widget primitives',
    fields: [
      {
        id: 'components.selected',
        kind: 'multiselect',
        label: 'Component Categories',
        presentation: 'cards',
        multiple: true,
        options: componentCategories,
        default: ['navigation', 'inputs', 'buttons', 'feedback'],
      },
    ],
  },

  /* ---------------------------------------------------------- *
   * Step 10: File Tree Preview
   * ---------------------------------------------------------- */
  {
    id: 'preview',
    label: 'Preview',
    icon: 'Eye',
    title: 'File Tree Preview',
    subtitle: 'Inspect the actual file tree generated before writing to disk',
    panel: 'preview',
    fields: [],
  },

  /* ---------------------------------------------------------- *
   * Step 11: Review & Generate
   * ---------------------------------------------------------- */
  {
    id: 'review',
    label: 'Review',
    icon: 'FileCheck',
    title: 'Review & Generate',
    subtitle: 'Confirm your configuration and output project',
    panel: 'review',
    fields: [],
  },
];
