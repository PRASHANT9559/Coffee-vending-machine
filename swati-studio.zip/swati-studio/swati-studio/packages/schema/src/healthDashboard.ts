import type { StudioConfig } from './types';

export interface ProjectHealthReport {
  overallScore: number;
  architectureScore: number;
  securityScore: number;
  performanceScore: number;
  codeQualityScore: number;
  estimatedFiles: number;
  estimatedPackages: number;
  recommendations: Array<{
    type: 'warning' | 'info' | 'security' | 'performance';
    message: string;
  }>;
}

export function computeProjectHealth(config: StudioConfig): ProjectHealthReport {
  let architectureScore = 85;
  let securityScore = 80;
  let performanceScore = 88;
  let codeQualityScore = 90;

  const recommendations: ProjectHealthReport['recommendations'] = [];

  const arch = String(config['architecture.pattern'] ?? 'feature_first');
  if (arch === 'clean_architecture') {
    architectureScore += 10;
  } else if (arch === 'feature_first') {
    architectureScore += 8;
  } else {
    recommendations.push({
      type: 'info',
      message: 'Consider Feature-First or Clean Architecture for better long-term scalability.',
    });
  }

  const features = Array.isArray(config['features.selected'])
    ? (config['features.selected'] as string[])
    : [];

  if (features.includes('authentication')) {
    securityScore += 8;
  } else {
    recommendations.push({
      type: 'security',
      message: 'No authentication provider selected. Ensure public endpoints are secured.',
    });
  }

  if (Boolean(config['security.enableRbac'])) {
    securityScore += 10;
  } else {
    recommendations.push({
      type: 'security',
      message: 'Enable Role-Based Access Control (RBAC) to restrict admin endpoints.',
    });
  }

  const isOffline = features.includes('offline');
  if (isOffline) {
    performanceScore += 8;
  } else {
    recommendations.push({
      type: 'performance',
      message: 'Add offline caching to provide instant UI rendering on unstable network connections.',
    });
  }

  const themeMode = String(config['frontend.themeMode'] ?? 'dark');
  if (themeMode === 'amoled') {
    performanceScore += 4;
  }

  architectureScore = Math.min(100, architectureScore);
  securityScore = Math.min(100, securityScore);
  performanceScore = Math.min(100, performanceScore);
  codeQualityScore = Math.min(100, codeQualityScore);

  const overallScore = Math.round(
    architectureScore * 0.3 + securityScore * 0.3 + performanceScore * 0.2 + codeQualityScore * 0.2
  );

  const navItems = Array.isArray(config['navigation.items']) ? config['navigation.items'].length : 3;
  const estimatedFiles = 25 + navItems * 2 + features.length * 3;
  const estimatedPackages = 8 + features.length;

  return {
    overallScore,
    architectureScore,
    securityScore,
    performanceScore,
    codeQualityScore,
    estimatedFiles,
    estimatedPackages,
    recommendations,
  };
}
