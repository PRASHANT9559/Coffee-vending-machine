import type { NavigationItem, StudioConfig } from './types';
import { enterpriseTemplates } from './catalogs/templates';

export interface AiRecommendation {
  appName: string;
  matchedTemplateId?: string;
  summary: string;
  confidence: number;
  config: Partial<StudioConfig>;
  detectedKeywords: string[];
}

/**
 * Parses a natural language user description of their app
 * and produces a comprehensive, enterprise-ready StudioConfig.
 */
export function analyzeAppPrompt(prompt: string): AiRecommendation {
  const text = prompt.toLowerCase();
  const detectedKeywords: string[] = [];

  // Keyword buckets
  const isEcommerce = /e-?commerce|shop|store|cart|buy|sell|product|checkout|retail/i.test(text);
  const isSocial = /social|feed|post|community|friend|follow|story|stories/i.test(text);
  const isChat = /chat|message|messaging|dm|conversation|voice|call/i.test(text);
  const isFood = /food|restaurant|delivery|dish|meal|menu|order food/i.test(text);
  const isHealthcare = /health|doctor|patient|medical|hospital|clinic|telemedicine/i.test(text);
  const isFintech = /bank|fintech|money|crypto|wallet|invest|transfer|finance|credit/i.test(text);
  const isNews = /news|blog|article|magazine|read|editorial|journal/i.test(text);
  const isFitness = /fit|fitness|workout|gym|exercise|routine|calorie/i.test(text);
  const isTask = /task|todo|project|kanban|sprint|agile|team|manage/i.test(text);

  // Style & theme keywords
  const isAmoled = /amoled|pure black|true black|pitch black/i.test(text);
  const isSepia = /sepia|warm|paper|reading mode/i.test(text);
  const isNeoBrutalist = /brutal|neo-brutal|gumroad|bold border/i.test(text);
  const isGlass = /glass|frosted|transparent|blur/i.test(text);
  const isNeu = /soft|neu|neumorphic/i.test(text);

  // Backend & DB hints
  const wantsFirebase = /firebase/i.test(text);
  const wantsSupabase = /supabase/i.test(text);
  const wantsPocketbase = /pocketbase/i.test(text);
  const wantsBloc = /bloc/i.test(text);
  const wantsRiverpod = /riverpod/i.test(text);

  // Collect keywords
  if (isEcommerce) detectedKeywords.push('e-commerce');
  if (isSocial) detectedKeywords.push('social');
  if (isChat) detectedKeywords.push('chat');
  if (isFood) detectedKeywords.push('food-delivery');
  if (isHealthcare) detectedKeywords.push('healthcare');
  if (isFintech) detectedKeywords.push('fintech');
  if (isNews) detectedKeywords.push('news/editorial');
  if (isFitness) detectedKeywords.push('fitness');
  if (isTask) detectedKeywords.push('task/management');
  if (isAmoled) detectedKeywords.push('amoled');
  if (isSepia) detectedKeywords.push('sepia');
  if (isNeoBrutalist) detectedKeywords.push('neo-brutalist');
  if (isGlass) detectedKeywords.push('glassmorphism');

  let templateId = 'ecommerce';
  let appName = 'My Modern App';

  if (isFood) {
    templateId = 'food_delivery';
    appName = 'QuickBite Delivery';
  } else if (isChat) {
    templateId = 'chat_messaging';
    appName = 'Whisper Messenger';
  } else if (isSocial) {
    templateId = 'social_media';
    appName = 'ConnectHub';
  } else if (isFintech) {
    templateId = 'fintech_banking';
    appName = 'Apex Banking';
  } else if (isHealthcare) {
    templateId = 'healthcare';
    appName = 'Aura Health';
  } else if (isNews) {
    templateId = 'news_blog';
    appName = 'Chronicle News';
  } else if (isFitness) {
    templateId = 'fitness_workout';
    appName = 'PulseFit';
  } else if (isTask) {
    templateId = 'task_manager';
    appName = 'SprintFlow';
  } else if (isEcommerce) {
    templateId = 'ecommerce';
    appName = 'ShopEase Store';
  }

  const baseTemplate = enterpriseTemplates.find((t) => t.id === templateId) ?? enterpriseTemplates[0];
  const config: Partial<StudioConfig> = { ...baseTemplate.presetConfig };

  config['project.name'] = appName;
  config['project.description'] = prompt.trim();

  // Fine tune based on specific style prompts
  if (isAmoled) {
    config['frontend.themeMode'] = 'amoled';
    config['frontend.aestheticCombo'] = 'obsidian_amoled';
  } else if (isSepia) {
    config['frontend.themeMode'] = 'sepia';
    config['frontend.aestheticCombo'] = 'sepia_paper';
  } else if (isNeoBrutalist) {
    config['frontend.uiStyle'] = 'neo_brutalism';
    config['frontend.aestheticCombo'] = 'brutal_pop';
  } else if (isGlass) {
    config['frontend.uiStyle'] = 'glassmorphism';
    config['frontend.aestheticCombo'] = 'midnight_glass';
  } else if (isNeu) {
    config['frontend.uiStyle'] = 'neumorphism';
    config['frontend.aestheticCombo'] = 'soft_light_neu';
  }

  // Fine tune backend & state
  if (wantsFirebase) config['backend.provider'] = 'firebase';
  if (wantsSupabase) config['backend.provider'] = 'supabase';
  if (wantsPocketbase) config['backend.provider'] = 'pocketbase';
  if (wantsBloc) config['state.manager'] = 'bloc';
  if (wantsRiverpod) config['state.manager'] = 'riverpod';

  const summary = `Detected ${detectedKeywords.join(', ') || 'custom modern application'}. Configured stack with ${config['backend.provider']} backend, ${config['state.manager']} state, and ${(config['navigation.items'] as NavigationItem[])?.length ?? 4} dynamic screens.`;

  return {
    appName,
    matchedTemplateId: baseTemplate.id,
    summary,
    confidence: detectedKeywords.length > 0 ? 0.95 : 0.75,
    config,
    detectedKeywords,
  };
}
