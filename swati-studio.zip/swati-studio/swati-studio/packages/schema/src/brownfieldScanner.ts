export interface DetectedProjectStack {
  isFlutterProject: boolean;
  flutterSdkVersion?: string;
  stateManagement?: 'riverpod' | 'bloc' | 'provider' | 'getx' | 'mobx' | 'unknown';
  backend?: 'supabase' | 'firebase' | 'dio' | 'graphql' | 'none';
  router?: 'go_router' | 'auto_route' | 'named_routes';
  architecture?: 'feature_first' | 'clean_architecture' | 'layered';
  existingFeatures: string[];
  recommendedAddons: string[];
}

export interface AddonPlanFileChange {
  path: string;
  changeType: 'added' | 'modified';
  description: string;
  sampleContentSnippet?: string;
}

export interface AddonPlan {
  addonId: string;
  name: string;
  description: string;
  dependenciesToAdd: string[];
  fileChanges: AddonPlanFileChange[];
}

export function scanExistingProject(pubspecYamlContent: string, directoryPaths: string[] = []): DetectedProjectStack {
  const content = pubspecYamlContent.toLowerCase();

  const isFlutterProject = content.includes('sdk: flutter') || content.includes('flutter:');

  // Detect State Management
  let stateManagement: DetectedProjectStack['stateManagement'] = 'unknown';
  if (content.includes('flutter_riverpod') || content.includes('hooks_riverpod')) {
    stateManagement = 'riverpod';
  } else if (content.includes('flutter_bloc') || content.includes('bloc:')) {
    stateManagement = 'bloc';
  } else if (content.includes('provider:')) {
    stateManagement = 'provider';
  } else if (content.includes('get:') || content.includes('getx:')) {
    stateManagement = 'getx';
  }

  // Detect Backend
  let backend: DetectedProjectStack['backend'] = 'none';
  if (content.includes('supabase_flutter')) {
    backend = 'supabase';
  } else if (content.includes('firebase_core')) {
    backend = 'firebase';
  } else if (content.includes('graphql_flutter')) {
    backend = 'graphql';
  } else if (content.includes('dio:')) {
    backend = 'dio';
  }

  // Detect Router
  let router: DetectedProjectStack['router'] = 'named_routes';
  if (content.includes('go_router')) {
    router = 'go_router';
  } else if (content.includes('auto_route')) {
    router = 'auto_route';
  }

  // Detect Architecture from directories
  let architecture: DetectedProjectStack['architecture'] = 'layered';
  const pathsString = directoryPaths.join(' ').toLowerCase();
  if (pathsString.includes('lib/features') || pathsString.includes('features/')) {
    architecture = 'feature_first';
  } else if (pathsString.includes('lib/domain') && pathsString.includes('lib/data')) {
    architecture = 'clean_architecture';
  }

  // Detect existing capabilities
  const existingFeatures: string[] = [];
  if (content.includes('flutter_local_notifications') || content.includes('firebase_messaging')) {
    existingFeatures.push('notifications');
  }
  if (content.includes('google_maps_flutter')) {
    existingFeatures.push('maps');
  }
  if (content.includes('flutter_stripe') || content.includes('in_app_purchase') || content.includes('razorpay')) {
    existingFeatures.push('payments');
  }
  if (content.includes('flutter_secure_storage')) {
    existingFeatures.push('secure_storage');
  }
  if (content.includes('intl:') || content.includes('flutter_localizations')) {
    existingFeatures.push('i18n');
  }
  if (content.includes('connectivity_plus')) {
    existingFeatures.push('offline');
  }

  // Recommend missing enterprise add-ons
  const recommendedAddons: string[] = [];
  if (!existingFeatures.includes('i18n')) recommendedAddons.push('i18n');
  if (!pathsString.includes('.github/workflows')) recommendedAddons.push('cicd_pipeline');
  if (!existingFeatures.includes('secure_storage')) recommendedAddons.push('security_rbac');
  if (!existingFeatures.includes('notifications')) recommendedAddons.push('push_notifications');
  if (!pathsString.includes('assets/env')) recommendedAddons.push('environments_flavors');
  if (!pathsString.includes('test/')) recommendedAddons.push('testing_suite');
  if (!content.includes('firebase_remote_config')) recommendedAddons.push('remote_config');

  return {
    isFlutterProject,
    flutterSdkVersion: '3.x',
    stateManagement,
    backend,
    router,
    architecture,
    existingFeatures,
    recommendedAddons,
  };
}

/**
 * Generates an additive, non-destructive Add-On execution plan with diff preview
 * for retrofitting an existing Flutter project.
 */
export function generateAddonPlan(addonId: string, stack: DetectedProjectStack): AddonPlan {
  switch (addonId) {
    case 'i18n':
      return {
        addonId,
        name: 'Internationalization (i18n)',
        description: 'Multi-lingual ARB setup with locale delegates and translation strings',
        dependenciesToAdd: ['flutter_localizations (sdk: flutter)', 'intl: ^0.19.0'],
        fileChanges: [
          { path: 'pubspec.yaml', changeType: 'modified', description: 'Added generate: true under flutter and intl dependency' },
          { path: 'l10n.yaml', changeType: 'added', description: 'Flutter localization config pointing to lib/l10n' },
          { path: 'lib/l10n/app_en.arb', changeType: 'added', description: 'English translation keys file' },
          { path: 'lib/l10n/app_hi.arb', changeType: 'added', description: 'Hindi translation keys file' },
          { path: 'lib/main.dart', changeType: 'modified', description: 'Injected localizationsDelegates and supportedLocales' },
        ],
      };

    case 'cicd_pipeline':
      return {
        addonId,
        name: 'CI/CD Pipeline',
        description: 'Automated GitHub Actions workflows for linting, testing, and Android builds',
        dependenciesToAdd: [],
        fileChanges: [
          { path: '.github/workflows/ci.yml', changeType: 'added', description: 'Analyze and test runner workflow' },
          { path: '.github/workflows/build-android.yml', changeType: 'added', description: 'Release APK/AAB build automation' },
        ],
      };

    case 'push_notifications':
      return {
        addonId,
        name: 'Push Notifications',
        description: 'FCM push notification service with Android 13 permissions and foreground channels',
        dependenciesToAdd: ['firebase_messaging: ^15.0.0', 'flutter_local_notifications: ^17.2.0'],
        fileChanges: [
          { path: 'lib/core/notifications/notification_service.dart', changeType: 'added', description: 'Notification initialization and token lifecycle' },
          { path: 'lib/core/notifications/notification_channels.dart', changeType: 'added', description: 'Android high-priority notification channels' },
          { path: 'android/app/src/main/AndroidManifest.xml', changeType: 'modified', description: 'Injected POST_NOTIFICATIONS runtime permission' },
        ],
      };

    case 'environments_flavors':
      return {
        addonId,
        name: 'Multi-Environment Flavors',
        description: 'Separate dev, staging, and prod configurations with .env assets',
        dependenciesToAdd: ['flutter_dotenv: ^5.1.0'],
        fileChanges: [
          { path: 'assets/env/dev.env', changeType: 'added', description: 'Dev environment variables' },
          { path: 'assets/env/staging.env', changeType: 'added', description: 'Staging environment variables' },
          { path: 'assets/env/prod.env', changeType: 'added', description: 'Prod environment variables' },
          { path: 'lib/config/app_config.dart', changeType: 'added', description: 'Environment enum and type-safe accessors' },
          { path: 'lib/main_dev.dart', changeType: 'added', description: 'Dev flavor entrypoint' },
          { path: 'lib/main_prod.dart', changeType: 'added', description: 'Prod flavor entrypoint' },
        ],
      };

    default:
      return {
        addonId,
        name: addonId,
        description: `Addon configuration for ${addonId}`,
        dependenciesToAdd: [],
        fileChanges: [
          { path: `.swati/addons/${addonId}.json`, changeType: 'added', description: 'Addon activation manifest' },
        ],
      };
  }
}
