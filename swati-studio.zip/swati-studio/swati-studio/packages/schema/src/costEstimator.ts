import type { StudioConfig } from './types';

export interface CostItem {
  service: string;
  plan: string;
  monthlyUsd: number;
  monthlyInr: number;
  notes: string;
}

export interface CostEstimationReport {
  items: CostItem[];
  totalUsd: number;
  totalInr: number;
  freeTierCoverage: string;
  costSavingTip: string;
}

const USD_TO_INR = 86.5;

export function estimateMonthlyCost(config: StudioConfig): CostEstimationReport {
  const items: CostItem[] = [];

  const backend = String(config['backend.provider'] ?? 'supabase');
  if (backend === 'supabase') {
    items.push({
      service: 'Backend (Supabase)',
      plan: 'Pro Plan',
      monthlyUsd: 25,
      monthlyInr: Math.round(25 * USD_TO_INR),
      notes: 'Includes Auth, Realtime, 8GB DB & 100GB Bandwidth',
    });
  } else if (backend === 'pocketbase') {
    items.push({
      service: 'Backend (PocketBase)',
      plan: 'Self-hosted VPS',
      monthlyUsd: 5,
      monthlyInr: Math.round(5 * USD_TO_INR),
      notes: 'Hetzner / DigitalOcean 1 vCPU sandbox',
    });
  } else if (backend === 'firebase') {
    items.push({
      service: 'Backend (Firebase)',
      plan: 'Pay as you go (Blaze)',
      monthlyUsd: 10,
      monthlyInr: Math.round(10 * USD_TO_INR),
      notes: 'Free tier covers first 50k reads/day',
    });
  } else {
    items.push({
      service: 'Backend (Custom REST)',
      plan: 'Standard API',
      monthlyUsd: 0,
      monthlyInr: 0,
      notes: 'External server managed independently',
    });
  }

  const features = Array.isArray(config['features.selected'])
    ? (config['features.selected'] as string[])
    : [];

  if (features.includes('maps')) {
    items.push({
      service: 'Google Maps API',
      plan: 'Pay-per-request',
      monthlyUsd: 7,
      monthlyInr: Math.round(7 * USD_TO_INR),
      notes: '~10,000 map loads / month (\$200 monthly free credit applies)',
    });
  }

  if (features.includes('notifications')) {
    items.push({
      service: 'Push Notifications (FCM)',
      plan: 'Firebase Cloud Messaging',
      monthlyUsd: 0,
      monthlyInr: 0,
      notes: '100% Free unlimited push notifications',
    });
  }

  if (features.includes('analytics')) {
    items.push({
      service: 'Analytics & Crashlytics',
      plan: 'Firebase Suite',
      monthlyUsd: 0,
      monthlyInr: 0,
      notes: 'Free real-time telemetry & crash logs',
    });
  }

  const totalUsd = items.reduce((acc, curr) => acc + curr.monthlyUsd, 0);
  const totalInr = Math.round(totalUsd * USD_TO_INR);

  const freeTierCoverage = backend === 'supabase'
    ? '~50,000 Monthly Active Users (MAU)'
    : backend === 'firebase'
    ? '~20,000 Monthly Active Users (MAU)'
    : '~10,000 Concurrent Users';

  const costSavingTip = backend === 'supabase'
    ? 'Switch to PocketBase for a $5/mo fixed self-hosted option on low-traffic phases.'
    : 'Use local SQLite / Hive caching to reduce billable database reads by up to 80%.';

  return {
    items,
    totalUsd,
    totalInr,
    freeTierCoverage,
    costSavingTip,
  };
}
