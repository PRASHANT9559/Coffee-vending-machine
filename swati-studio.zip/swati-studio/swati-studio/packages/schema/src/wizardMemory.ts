import type { StudioConfig } from './types';

export interface ProjectHistoryItem {
  id: string;
  name: string;
  updatedAt: string;
  config: Partial<StudioConfig>;
}

export interface UserPreferencesProfile {
  topBackend: string;
  topStateManager: string;
  topArchitecture: string;
  topThemeMode: string;
  totalProjects: number;
  recommendationMessage: string;
}

export class WizardMemoryStore {
  private static _history: ProjectHistoryItem[] = [
    {
      id: 'proj_demo_1',
      name: 'ShopEase E-Commerce',
      updatedAt: '2 days ago',
      config: {
        'backend.provider': 'supabase',
        'state.manager': 'riverpod',
        'architecture.pattern': 'feature_first',
        'frontend.themeMode': 'dark',
      },
    },
    {
      id: 'proj_demo_2',
      name: 'PulseFlow Dashboard',
      updatedAt: '1 week ago',
      config: {
        'backend.provider': 'supabase',
        'state.manager': 'riverpod',
        'architecture.pattern': 'feature_first',
        'frontend.themeMode': 'amoled',
      },
    },
  ];

  static getHistory(): ProjectHistoryItem[] {
    return this._history;
  }

  static addProject(name: string, config: StudioConfig): void {
    this._history.unshift({
      id: `proj_${Date.now()}`,
      name,
      updatedAt: 'Just now',
      config: { ...config },
    });
    if (this._history.length > 10) {
      this._history.pop();
    }
  }

  static computePreferences(): UserPreferencesProfile {
    const backendCount: Record<string, number> = {};
    const stateCount: Record<string, number> = {};
    const archCount: Record<string, number> = {};
    const themeCount: Record<string, number> = {};

    for (const item of this._history) {
      const b = String(item.config['backend.provider'] ?? 'supabase');
      backendCount[b] = (backendCount[b] || 0) + 1;

      const s = String(item.config['state.manager'] ?? 'riverpod');
      stateCount[s] = (stateCount[s] || 0) + 1;

      const a = String(item.config['architecture.pattern'] ?? 'feature_first');
      archCount[a] = (archCount[a] || 0) + 1;

      const t = String(item.config['frontend.themeMode'] ?? 'dark');
      themeCount[t] = (themeCount[t] || 0) + 1;
    }

    const topBackend = Object.keys(backendCount).sort((a, b) => backendCount[b] - backendCount[a])[0] ?? 'supabase';
    const topStateManager = Object.keys(stateCount).sort((a, b) => stateCount[b] - stateCount[a])[0] ?? 'riverpod';
    const topArchitecture = Object.keys(archCount).sort((a, b) => archCount[b] - archCount[a])[0] ?? 'feature_first';
    const topThemeMode = Object.keys(themeCount).sort((a, b) => themeCount[b] - themeCount[a])[0] ?? 'dark';

    return {
      topBackend,
      topStateManager,
      topArchitecture,
      topThemeMode,
      totalProjects: this._history.length,
      recommendationMessage: `Based on your recent projects, you prefer ${topBackend} backend with ${topStateManager} and ${topArchitecture}.`,
    };
  }
}
