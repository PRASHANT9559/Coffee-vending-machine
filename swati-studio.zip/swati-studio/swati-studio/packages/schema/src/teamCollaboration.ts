import type { StudioConfig } from './types';
import { defaultConfig } from './config';

export interface TeamPreset {
  id: string;
  name: string;
  description: string;
  lockedFields: string[];
  config: Partial<StudioConfig>;
}

export const teamPresets: TeamPreset[] = [
  {
    id: 'company_standard',
    name: '🏢 Company Standard Preset',
    description: 'Enforces corporate theme, Supabase backend, Riverpod, Clean Architecture and RBAC.',
    lockedFields: ['frontend.themeColor', 'backend.provider', 'architecture.pattern', 'security.enableRbac'],
    config: {
      'frontend.themeColor': 'indigo',
      'backend.provider': 'supabase',
      'architecture.pattern': 'clean_architecture',
      'state.manager': 'riverpod',
      'security.enableRbac': true,
    },
  },
  {
    id: 'hackathon_quick',
    name: '⚡ Hackathon MVP Sprint',
    description: 'PocketBase + Riverpod + Minimal Clean Bottom Nav for maximum development speed.',
    lockedFields: [],
    config: {
      'backend.provider': 'pocketbase',
      'architecture.pattern': 'feature_first',
      'state.manager': 'riverpod',
      'database.engine': 'sqlite',
    },
  },
  {
    id: 'mobile_first',
    name: '📱 Mobile-First Production',
    description: 'Full flavors (Dev + Staging + Prod), GitHub Actions CI/CD and i18n support enabled.',
    lockedFields: ['project.environmentFlavor', 'project.cicdPlatform'],
    config: {
      'project.environmentFlavor': 'full_flavors',
      'project.cicdPlatform': 'github_actions',
      'project.locale': 'en',
    },
  },
];

export function generateShareUrl(config: StudioConfig): string {
  try {
    const compact: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(config)) {
      if (v !== undefined && v !== null && v !== '') {
        compact[k] = v;
      }
    }
    const json = JSON.stringify(compact);
    const encoded = Buffer.from(json).toString('base64url');
    return `https://swati.studio/config?data=${encoded}`;
  } catch {
    return 'https://swati.studio/config';
  }
}

export function parseShareUrl(url: string): Partial<StudioConfig> | null {
  try {
    const parsed = new URL(url);
    const data = parsed.searchParams.get('data');
    if (!data) return null;
    const json = Buffer.from(data, 'base64url').toString('utf-8');
    return JSON.parse(json) as Partial<StudioConfig>;
  } catch {
    return null;
  }
}
