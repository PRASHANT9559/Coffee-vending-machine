import type { StudioConfig } from './types';

export interface CliCommandResult {
  command: 'init' | 'generate' | 'validate' | 'doctor' | 'add' | 'help' | 'unknown';
  options: Record<string, string | boolean | string[]>;
  valid: boolean;
  message?: string;
}

/**
 * Parses CLI command arguments for Headless CLI mode.
 * Example commands:
 * swati init --template e-commerce
 * swati generate --config swati.yaml --dry-run
 * swati validate --config swati.yaml
 * swati add auth --methods email,google
 * swati doctor
 */
export function parseCliArgs(args: string[]): CliCommandResult {
  if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
    return {
      command: 'help',
      options: {},
      valid: true,
      message: 'Usage: swati <command> [options]\nCommands: init, generate, validate, doctor, add',
    };
  }

  const rawCmd = args[0].toLowerCase();
  const options: Record<string, string | boolean | string[]> = {};

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      if (i + 1 < args.length && !args[i + 1].startsWith('--')) {
        const val = args[i + 1];
        if (val.includes(',')) {
          options[key] = val.split(',').map((s) => s.trim());
        } else {
          options[key] = val;
        }
        i++;
      } else {
        options[key] = true;
      }
    }
  }

  switch (rawCmd) {
    case 'init':
      return { command: 'init', options, valid: true };
    case 'generate':
      return { command: 'generate', options, valid: true };
    case 'validate':
      return { command: 'validate', options, valid: true };
    case 'doctor':
      return { command: 'doctor', options, valid: true };
    case 'add':
      return { command: 'add', options, valid: true };
    default:
      return {
        command: 'unknown',
        options,
        valid: false,
        message: `Unknown command: ${rawCmd}. Available: init, generate, validate, doctor, add`,
      };
  }
}

/**
 * Serializes StudioConfig into a clean, human-readable swati.yaml string.
 */
export function serializeSwatiYaml(config: StudioConfig): string {
  const lines: string[] = [
    `# Swati Studio Configuration File (Config-as-Code)`,
    `# Generated: ${new Date().toISOString()}`,
    `schemaVersion: 3`,
    ``,
    `app:`,
    `  name: "${config['project.name'] || 'SwatiApp'}"`,
    `  package: "${config['project.package'] || 'com.example.swati_app'}"`,
    `  description: "${config['project.description'] || 'A modern enterprise Flutter app'}"`,
    ``,
    `stack:`,
    `  state: ${config['state.framework'] || 'riverpod'}`,
    `  backend: ${config['backend.platform'] || 'supabase'}`,
    `  architecture: ${config['arch.pattern'] || 'feature_first'}`,
    `  theme: ${config['theme.aesthetic'] || 'material_you'}`,
    ``,
    `features:`,
    `  auth:`,
    `    enabled: ${config['auth.enabled'] ?? true}`,
    `    methods:`,
  ];

  const authMethods = (config['auth.methods'] as string[]) || ['email', 'google'];
  for (const method of authMethods) {
    lines.push(`      - ${method}`);
  }

  lines.push(
    `  push:`,
    `    enabled: ${config['push.enabled'] ?? true}`,
    `    provider: fcm`,
    `  remoteConfig:`,
    `    enabled: ${config['remoteConfig.enabled'] ?? true}`,
    `    cacheTtlHours: 1`,
    `  crud:`,
    `    scaffoldProducts: true`,
    `  compliance:`,
    `    gdpr: true`,
    `    dpdp: true`,
    `    deleteAccountFlow: true`,
    `  offline:`,
    `    enabled: ${config['offline.enabled'] ?? true}`,
    `  sizeBudgetMb: 25`,
    ``,
    `environments:`,
    `  - dev`,
    `  - staging`,
    `  - prod`
  );

  return lines.join('\n') + '\n';
}

/**
 * Validates a swati config object against standard schema constraints.
 */
export function validateSwatiConfig(config: Partial<StudioConfig>): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!config['project.name']) {
    errors.push('Missing required field: project.name');
  }
  if (!config['project.package']) {
    errors.push('Missing required field: project.package');
  } else if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(config['project.package'] as string)) {
    errors.push(`Invalid package identifier: "${config['project.package']}". Must match format com.example.app`);
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Generates JSON Schema Draft-07 representation of swati.yaml for VS Code / IDE autocomplete.
 */
export function generateSwatiJsonSchema(): Record<string, unknown> {
  return {
    $schema: 'http://json-schema.org/draft-07/schema#',
    title: 'SwatiStudioConfig',
    description: 'Schema definition for swati.yaml projects',
    type: 'object',
    required: ['schemaVersion', 'app', 'stack'],
    properties: {
      schemaVersion: {
        type: 'integer',
        enum: [1, 2, 3],
        description: 'Schema version of the configuration file',
      },
      app: {
        type: 'object',
        required: ['name', 'package'],
        properties: {
          name: { type: 'string', minLength: 1 },
          package: { type: 'string', pattern: '^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$' },
          description: { type: 'string' },
        },
      },
      stack: {
        type: 'object',
        required: ['state', 'backend', 'architecture'],
        properties: {
          state: { type: 'string', enum: ['riverpod', 'bloc', 'provider', 'signals', 'none'] },
          backend: { type: 'string', enum: ['supabase', 'firebase', 'appwrite', 'graphql', 'custom_rest'] },
          architecture: { type: 'string', enum: ['feature_first', 'clean_architecture', 'layered'] },
          theme: { type: 'string' },
        },
      },
      features: {
        type: 'object',
        properties: {
          auth: { type: 'object' },
          push: { type: 'object' },
          remoteConfig: { type: 'object' },
          crud: { type: 'object' },
          compliance: { type: 'object' },
          offline: { type: 'object' },
          sizeBudgetMb: { type: 'number' },
        },
      },
      environments: {
        type: 'array',
        items: { type: 'string' },
      },
    },
  };
}
