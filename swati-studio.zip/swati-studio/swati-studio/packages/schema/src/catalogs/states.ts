import type { OptionDef } from '../types';

export const stateManagers: OptionDef[] = [
  {
    id: 'riverpod',
    name: 'Riverpod',
    desc: 'Compile-safe, testable, and reactive state management library for Dart & Flutter',
    icon: 'Radio',
    accent: '#3b82f6',
    tags: ['recommended', 'compile-safe', 'reactive', 'testable'],
    data: {
      package: 'flutter_riverpod',
      pubPackages: ['flutter_riverpod', 'riverpod_annotation'],
      controllerTemplate: 'riverpod',
    },
  },
  {
    id: 'bloc',
    name: 'Bloc / Cubit',
    desc: 'Predictable state management based on event streams and reactive state transitions',
    icon: 'Layers',
    accent: '#6366f1',
    tags: ['enterprise', 'predictable', 'streams', 'events'],
    data: {
      package: 'flutter_bloc',
      pubPackages: ['flutter_bloc', 'bloc', 'equatable'],
      controllerTemplate: 'bloc',
    },
  },
  {
    id: 'provider',
    name: 'Provider',
    desc: 'Official recommended wrapper around InheritedWidgets for straightforward state',
    icon: 'Share2',
    accent: '#10b981',
    tags: ['standard', 'inherited-widget', 'simple'],
    data: {
      package: 'provider',
      pubPackages: ['provider'],
      controllerTemplate: 'provider',
    },
  },
  {
    id: 'getx',
    name: 'GetX',
    desc: 'Extra-light and powerful state management, navigation, and dependency injection',
    icon: 'Zap',
    accent: '#a855f7',
    tags: ['all-in-one', 'fast', 'no-context'],
    data: {
      package: 'get',
      pubPackages: ['get'],
      controllerTemplate: 'getx',
    },
  },
  {
    id: 'mobx',
    name: 'MobX',
    desc: 'Transparently applying Functional Reactive Programming (TFRP) with observables',
    icon: 'RefreshCw',
    accent: '#f97316',
    tags: ['observables', 'reactive', 'actions'],
    data: {
      package: 'flutter_mobx',
      pubPackages: ['mobx', 'flutter_mobx'],
      controllerTemplate: 'mobx',
    },
  },
];
