export interface StudioPlugin {
  id: string;
  name: string;
  description: string;
  author: string;
  rating: number;
  downloads: string;
  icon: string;
  category: 'network' | 'payments' | 'ui' | 'security' | 'tools';
  dependencies: string[];
  configSnippet?: Record<string, unknown>;
}

export const studioPlugins: StudioPlugin[] = [
  {
    id: 'graphql_client',
    name: 'GraphQL Integration Suite',
    description: 'Full graphql_flutter setup with normalized cache, schema introspection, and Ferry codegen helpers.',
    author: 'Swati Ecosystem',
    rating: 4.8,
    downloads: '12.5K',
    icon: 'Share2',
    category: 'network',
    dependencies: ['graphql_flutter: ^5.1.2', 'ferry: ^0.16.1'],
  },
  {
    id: 'stripe_payments',
    name: 'Stripe Payments Pro',
    description: 'Complete mobile checkout flow with PaymentSheet, Apple Pay, Google Pay, and customer card tokenization.',
    author: 'Stripe Official Community',
    rating: 4.9,
    downloads: '18.2K',
    icon: 'CreditCard',
    category: 'payments',
    dependencies: ['flutter_stripe: ^11.4.0'],
  },
  {
    id: 'websocket_realtime',
    name: 'WebSocket Real-time Client',
    description: 'Resilient WebSocket connection with automatic exponential reconnect, heartbeat ping/pong, and channel routing.',
    author: 'Realtime Labs',
    rating: 4.6,
    downloads: '8.4K',
    icon: 'Wifi',
    category: 'network',
    dependencies: ['web_socket_channel: ^3.0.1'],
  },
  {
    id: 'pdf_generator',
    name: 'PDF Generator & Printing',
    description: 'Render responsive PDF documents from Flutter widgets, with native print dialog and document sharing.',
    author: 'Swati Tools',
    rating: 4.7,
    downloads: '10.1K',
    icon: 'FileText',
    category: 'tools',
    dependencies: ['pdf: ^3.11.1', 'printing: ^5.13.2'],
  },
  {
    id: 'lottie_animations',
    name: 'Lottie Vector Player',
    description: 'High-performance vector Lottie JSON animations with frame controls, markers, and color delegate overrides.',
    author: 'Airbnb Community',
    rating: 4.9,
    downloads: '24.0K',
    icon: 'Sparkles',
    category: 'ui',
    dependencies: ['lottie: ^3.1.3'],
  },
  {
    id: 'biometric_vault',
    name: 'Biometric Secure Vault',
    description: 'TouchID / FaceID authentication wrapper with hardware-backed encryption key storage.',
    author: 'ZeroTrust Security',
    rating: 4.8,
    downloads: '9.3K',
    icon: 'ShieldCheck',
    category: 'security',
    dependencies: ['local_auth: ^2.3.0', 'flutter_secure_storage: ^9.2.2'],
  },
];
