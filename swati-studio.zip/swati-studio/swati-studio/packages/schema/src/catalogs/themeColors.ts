import type { OptionDef } from '../types';
import { themePalettes } from './themePalettes';

const legacyColors: OptionDef[] = [
  { id: 'indigo', name: 'Indigo', accent: '#4F46E5', data: { hex: '#4F46E5' } },
  { id: 'purple', name: 'Purple', accent: '#8b5cf6', data: { hex: '#8b5cf6' } },
  { id: 'pink', name: 'Pink', accent: '#ec4899', data: { hex: '#ec4899' } },
  { id: 'rose', name: 'Rose', accent: '#f43f5e', data: { hex: '#f43f5e' } },
  { id: 'orange', name: 'Orange', accent: '#f97316', data: { hex: '#f97316' } },
  { id: 'amber', name: 'Amber', accent: '#f59e0b', data: { hex: '#f59e0b' } },
  { id: 'emerald', name: 'Emerald', accent: '#10b981', data: { hex: '#10b981' } },
  { id: 'teal', name: 'Teal', accent: '#14b8a6', data: { hex: '#14b8a6' } },
  { id: 'cyan', name: 'Cyan', accent: '#06b6d4', data: { hex: '#06b6d4' } },
  { id: 'blue', name: 'Blue', accent: '#2563EB', data: { hex: '#2563EB' } },
  { id: 'violet', name: 'Violet', accent: '#5B21B6', data: { hex: '#5B21B6' } },
  { id: 'fuchsia', name: 'Fuchsia', accent: '#d946ef', data: { hex: '#d946ef' } },
  { id: 'red', name: 'Red', accent: '#dc2626', data: { hex: '#dc2626' } },
  { id: 'lime', name: 'Lime', accent: '#84cc16', data: { hex: '#84cc16' } },
  { id: 'green', name: 'Green', accent: '#22c55e', data: { hex: '#22c55e' } },
  { id: 'sky', name: 'Sky', accent: '#0ea5e9', data: { hex: '#0ea5e9' } },
  { id: 'slate', name: 'Slate', accent: '#64748b', data: { hex: '#64748b' } },
  { id: 'zinc', name: 'Zinc', accent: '#71717a', data: { hex: '#71717a' } },
  { id: 'stone', name: 'Stone', accent: '#78716c', data: { hex: '#78716c' } },
  { id: 'neutral', name: 'Neutral', accent: '#737373', data: { hex: '#737373' } },
];

/** The 20 comprehensive dual light/dark themes plus legacy aliases */
export const themeColors: OptionDef[] = [
  ...themePalettes,
  ...legacyColors.filter((leg) => !themePalettes.some((p) => p.id === leg.id)),
];
