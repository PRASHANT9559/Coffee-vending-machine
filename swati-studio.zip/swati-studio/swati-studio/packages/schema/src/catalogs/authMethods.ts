import type { OptionDef } from '../types';

export const authMethods: OptionDef[] = [
  { id: 'email_password', name: 'Email & Password', desc: 'Standard secure credentials with email verification', icon: 'Mail', accent: '#6366f1' },
  { id: 'phone_otp', name: 'Phone OTP (SMS)', desc: 'Mobile number login with 6-digit one-time passcode verification', icon: 'Smartphone', accent: '#10b981' },
  { id: 'google_oauth', name: 'Google Sign-In', desc: 'One-tap OAuth integration with Google account', icon: 'Globe', accent: '#ef4444' },
  { id: 'apple_oauth', name: 'Apple Sign-In', desc: 'Mandatory on iOS for apps using social login', icon: 'Shield', accent: '#ffffff' },
  { id: 'biometric', name: 'Biometric (Face/Fingerprint)', desc: 'Instant authentication using FaceID or Fingerprint via local_auth', icon: 'Eye', accent: '#06b6d4' },
  { id: 'github_oauth', name: 'GitHub Login', desc: 'Developer OAuth authentication via GitHub', icon: 'Code', accent: '#94a3b8' },
  { id: 'magic_link', name: 'Passwordless Magic Link', desc: 'Secure token link sent directly to user inbox', icon: 'Link', accent: '#8b5cf6' },
  { id: 'guest', name: 'Guest / Anonymous Access', desc: 'Browse instantly without friction, upgrade to registered account later', icon: 'User', accent: '#f59e0b' },
];

export const authScreens: OptionDef[] = [
  { id: 'login', name: 'Login Screen', desc: 'Credential input with social login buttons', icon: 'LogIn' },
  { id: 'register', name: 'Registration Screen', desc: 'Account creation with terms consent', icon: 'UserPlus' },
  { id: 'forgot_password', name: 'Forgot Password', desc: 'Email/phone recovery request flow', icon: 'Key' },
  { id: 'otp_verify', name: 'OTP Code Verification', desc: '6-digit pin code input with resend timer', icon: 'Smartphone' },
  { id: 'profile_setup', name: 'Profile Onboarding', desc: 'Avatar upload and initial user preferences', icon: 'UserCheck' },
];

export const authSecurityFlags: OptionDef[] = [
  { id: 'remember_me', name: 'Remember Me', desc: 'Persists user session token in secure storage' },
  { id: 'auto_login', name: 'Auto-Login on Launch', desc: 'Bypasses login screen when valid token exists' },
  { id: 'biometric_lock', name: 'App Lock Screen', desc: 'Prompts biometric scan on app resume' },
  { id: 'session_timeout', name: 'Idle Session Timeout', desc: 'Auto logouts user after 15 minutes of inactivity' },
];
