import type { OptionDef } from '../types';

export const themeModes: OptionDef[] = [
  { id: 'dark', name: 'Dark Theme', desc: 'Sleek modern dark surface, gentle on eyes', accent: '#0f172a' },
  { id: 'light', name: 'Light Theme', desc: 'Clean, crisp high-legibility light canvas', accent: '#f8fafc' },
  { id: 'amoled', name: 'AMOLED (True Black)', desc: 'Pure #000000 black canvas for battery saving & infinite contrast', accent: '#000000' },
  { id: 'sepia', name: 'Warm Sepia', desc: 'Warm gentle paper tone for reading & long-session eye comfort', accent: '#d97706' },
  { id: 'adaptive', name: 'Adaptive / Both', desc: 'Auto-adapts dynamically to OS system brightness', accent: '#10b981' },
  { id: 'high_contrast', name: 'High Contrast', desc: 'Maximum accessibility with vivid contrast ratios', accent: '#ffffff' },
];

export const homeStyles: OptionDef[] = [
  { id: 'studio', name: 'Studio', desc: 'Modern hero with live interactive code sample', accent: '#6366f1' },
  { id: 'terminal', name: 'Terminal', desc: 'Hacker-style retro CLI interface with command execution', accent: '#10b981' },
  { id: 'bento', name: 'Bento Grid', desc: 'Apple-inspired modular tile overview', accent: '#8b5cf6' },
  { id: 'editorial', name: 'Editorial', desc: 'Bold typography with high-contrast magazine layout', accent: '#f43f5e' },
  { id: 'minimal', name: 'Minimal', desc: 'Distraction-free clean aesthetic focusing purely on content', accent: '#64748b' },
  { id: 'glass', name: 'Glassmorphism', desc: 'Translucent frosted glass panels with aurora glow', accent: '#06b6d4' },
];

export const uiStyles: OptionDef[] = [
  { id: 'material3', name: 'Material Design 3', desc: 'Google M3 design system with dynamic tokens & tonal elevation', accent: '#6366f1' },
  { id: 'glassmorphism', name: 'Glassmorphism', desc: 'Frosted glass cards, backdrop-blur, translucent borders & soft glow', accent: '#06b6d4' },
  { id: 'liquid_glass', name: 'Liquid Glass (iOS)', desc: 'Apple iOS modern style — glass cards with light refraction & spatial depth', accent: '#38bdf8' },
  { id: 'neo_brutalism', name: 'Neo-Brutalism', desc: 'Thick 3px solid black borders, hard drop shadows & vibrant pop surfaces', accent: '#facc15' },
  { id: 'neumorphism', name: 'Neumorphism (Soft UI)', desc: 'Soft-extruded same-bg components with dual light/dark embossed shadows', accent: '#94a3b8' },
  { id: 'claymorphism', name: 'Claymorphism', desc: 'Puffy 3D rounded clay cards with pillowy depth & playful pastels', accent: '#f43f5e' },
  { id: 'bento_grid', name: 'Bento Grid UI', desc: 'Modular tile grid layouts inspired by Apple, Linear & Stripe', accent: '#8b5cf6' },
  { id: 'aurora_glow', name: 'Aurora / Glow UI', desc: 'Vibrant ambient gradient blobs diffusing under clean glass panels', accent: '#a855f7' },
  { id: 'cyberpunk', name: 'Cyberpunk Neon', desc: 'High-contrast pitch dark surfaces with electric cyan & magenta glows', accent: '#d946ef' },
  { id: 'terminal_cli', name: 'Terminal / Hacker CLI', desc: 'Retro matrix green monospace terminal with subtle scanline glow', accent: '#22c55e' },
  { id: 'y2k_chrome', name: 'Y2K Chrome UI', desc: '2000s glossy chrome, specular metallic reflections & playful bubble buttons', accent: '#38bdf8' },
  { id: 'retro_synthwave', name: 'Synthwave / Retrowave', desc: '80s magenta-cyan neon grids with nostalgic sunset gradient aesthetics', accent: '#ec4899' },
  { id: 'sepia_paper', name: 'Paper / Reading UI', desc: 'Tactile paper texture, ruled lines and warm organic reading tones', accent: '#d97706' },
  { id: 'minimalism', name: 'Minimalism (Pure)', desc: 'Distraction-free extreme whitespace with high-legibility typography', accent: '#64748b' },
  { id: 'flat_design', name: 'Flat Design 2.0', desc: 'Crisp solid geometry, zero heavy shadows, vivid direct color blocks', accent: '#10b981' },
  { id: 'ai_native', name: 'AI-Native UI', desc: 'Prompt-first generative interfaces with conversational card streams', accent: '#6366f1' },
  { id: 'cupertino', name: 'Cupertino (iOS)', desc: 'Native Apple Human Interface Guidelines look and feel', accent: '#0ea5e9' },
  { id: 'adaptive', name: 'Adaptive Multiplatform', desc: 'Renders Cupertino on iOS/macOS and Material on Android/Windows', accent: '#10b981' },
];

export const fonts: OptionDef[] = [
  { id: 'Inter', name: 'Inter' },
  { id: 'Roboto', name: 'Roboto' },
  { id: 'Poppins', name: 'Poppins' },
  { id: 'Montserrat', name: 'Montserrat' },
  { id: 'Open Sans', name: 'Open Sans' },
  { id: 'Nunito', name: 'Nunito' },
  { id: 'Lato', name: 'Lato' },
  { id: 'Raleway', name: 'Raleway' },
  { id: 'Work Sans', name: 'Work Sans' },
  { id: 'Outfit', name: 'Outfit' },
  { id: 'JetBrains Mono', name: 'JetBrains Mono (Code/CLI)' },
];

export const animations: OptionDef[] = [
  { id: 'smooth', name: 'Smooth & Elegant', desc: 'Graceful bezier curves and gentle transitions' },
  { id: 'bouncy', name: 'Bouncy & Playful', desc: 'Spring physics with subtle overshoots' },
  { id: 'snappy', name: 'Snappy & Fast', desc: 'High-speed micro-interactions under 150ms' },
  { id: 'minimal', name: 'Minimal & Subtle', desc: 'Reduced motion with simple opacity cross-fades' },
];

export const spacings: OptionDef[] = [
  { id: 'compact', name: 'Compact', desc: 'Dense layout for information-heavy data displays' },
  { id: 'normal', name: 'Normal', desc: 'Balanced standard padding and margins' },
  { id: 'spacious', name: 'Spacious', desc: 'Generous whitespace for relaxed reading' },
];

export const licenses: OptionDef[] = [
  { id: 'MIT', name: 'MIT', desc: 'Permissive open-source license' },
  { id: 'Apache-2.0', name: 'Apache 2.0', desc: 'Permissive with patent grant and trademark protection' },
  { id: 'BSD-3-Clause', name: 'BSD 3-Clause', desc: 'Permissive license with non-endorsement clause' },
  { id: 'GPL-3.0', name: 'GPL 3.0', desc: 'Strong copyleft open-source license' },
  { id: 'Proprietary', name: 'Proprietary / Closed Source', desc: 'All rights reserved by creator' },
];

export const platforms: OptionDef[] = [
  { id: 'android', name: 'Android', accent: '#3ddc84' },
  { id: 'ios', name: 'iOS', accent: '#007aff' },
  { id: 'web', name: 'Web', accent: '#f06529' },
  { id: 'macos', name: 'macOS', accent: '#999999' },
  { id: 'windows', name: 'Windows', accent: '#0078d7' },
  { id: 'linux', name: 'Linux', accent: '#fcc624' },
];
