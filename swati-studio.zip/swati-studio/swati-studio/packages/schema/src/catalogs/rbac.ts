import type { OptionDef, RbacRoleDef } from '../types';

export const defaultRbacRoles: RbacRoleDef[] = [
  {
    id: 'admin',
    name: 'Administrator',
    description: 'Complete unrestricted access across all resources and user administration',
    permissions: ['read', 'write', 'edit', 'delete', 'manage_users', 'export'],
  },
  {
    id: 'manager',
    name: 'Operations Manager',
    description: 'Can read, create, and update records; cannot delete system-level data',
    permissions: ['read', 'write', 'edit', 'export'],
  },
  {
    id: 'user',
    name: 'Standard User',
    description: 'Can manage own profile, view public and assigned records',
    permissions: ['read', 'write'],
  },
  {
    id: 'viewer',
    name: 'Auditor / Viewer',
    description: 'Read-only access to records and reporting dashboards',
    permissions: ['read'],
  },
  {
    id: 'guest',
    name: 'Guest / Public',
    description: 'Limited public catalog and login screens only',
    permissions: [],
  },
];

export const rbacPermissions: OptionDef[] = [
  { id: 'read', name: 'Read / View Records', desc: 'Allows viewing screens, dashboards, and entities' },
  { id: 'write', name: 'Create New Records', desc: 'Allows creating orders, posts, and entries' },
  { id: 'edit', name: 'Update Existing Records', desc: 'Allows modifying existing records' },
  { id: 'delete', name: 'Delete Records', desc: 'Destructive deletion permission' },
  { id: 'manage_users', name: 'User Management', desc: 'Can invite, assign roles, and revoke users' },
  { id: 'export', name: 'Data Export', desc: 'Can export reports as CSV/PDF' },
];
