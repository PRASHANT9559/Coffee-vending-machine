import type { OptionDef } from '../types';

export const environmentOptions: OptionDef[] = [
  { id: 'single', name: 'Single Environment', desc: 'Standard single app configuration without flavor branching' },
  { id: 'dev_prod', name: 'Dual (Dev + Production)', desc: 'Separate dev sandbox API from live production database' },
  { id: 'full_flavors', name: 'Full Enterprise (Dev + Staging + Prod)', desc: 'Includes Dev, Staging QA, and Production release flavors with unique bundle IDs and .env configs' },
];

export const cicdPlatforms: OptionDef[] = [
  { id: 'github_actions', name: 'GitHub Actions', desc: 'Pre-configured .github/workflows for test, analyze, and APK/AAB build', icon: 'GitPullRequest', accent: '#6366f1' },
  { id: 'gitlab_ci', name: 'GitLab CI/CD', desc: 'Enterprise .gitlab-ci.yml pipeline configuration with artifact cache', icon: 'GitBranch', accent: '#f97316' },
  { id: 'fastlane', name: 'Fastlane Automation', desc: 'Native Fastfile for iOS TestFlight and Android Play Store distribution', icon: 'Rocket', accent: '#10b981' },
  { id: 'none', name: 'None / Manual', desc: 'Skip CI/CD pipeline automation files' },
];

export const supportedLocales: OptionDef[] = [
  { id: 'en', name: 'English (US)', desc: 'Default international language', accent: '#3b82f6' },
  { id: 'hi', name: 'Hindi (हिंदी)', desc: 'Primary Indian regional language', accent: '#f97316' },
  { id: 'es', name: 'Spanish (Español)', desc: 'European & Latin American reach', accent: '#ef4444' },
  { id: 'fr', name: 'French (Français)', desc: 'Western Europe & Africa', accent: '#6366f1' },
  { id: 'de', name: 'German (Deutsch)', desc: 'Central Europe DACH region', accent: '#eab308' },
  { id: 'ar', name: 'Arabic (العربية) — RTL', desc: 'Full Right-to-Left bidirectional layout support', accent: '#10b981' },
  { id: 'ja', name: 'Japanese (日本語)', desc: 'East Asian typography', accent: '#ec4899' },
];
