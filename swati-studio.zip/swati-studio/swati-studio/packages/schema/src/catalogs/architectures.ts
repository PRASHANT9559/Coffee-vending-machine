import type { OptionDef } from '../types';

export const architectures: OptionDef[] = [
  {
    id: 'feature_first',
    name: 'Feature First',
    desc: 'Organize code by self-contained feature modules (recommended for Flutter)',
    icon: 'FolderTree',
    accent: '#6366f1',
    tags: ['modular', 'scalable', 'team-friendly'],
    data: {
      folderStyle: 'feature_first',
      description: 'Each feature contains its own presentation, domain, and data layers.',
    },
  },
  {
    id: 'clean',
    name: 'Clean Architecture',
    desc: 'Strict separation into Domain, Data, and Presentation layers',
    icon: 'Layers',
    accent: '#0ea5e9',
    tags: ['enterprise', 'testable', 'strict'],
    data: {
      folderStyle: 'clean',
      description: 'Independence of frameworks, UI, and databases with dependency inversion.',
    },
  },
  {
    id: 'ddd',
    name: 'Domain-Driven Design (DDD)',
    desc: 'Organized around complex business subdomains and ubiquitous language',
    icon: 'Network',
    accent: '#8b5cf6',
    tags: ['enterprise', 'business-logic', 'rich-domain'],
    data: {
      folderStyle: 'ddd',
      description: 'Aggregates, value objects, entities, and domain events.',
    },
  },
  {
    id: 'mvvm',
    name: 'MVVM (Model-View-ViewModel)',
    desc: 'Separates graphical UI markup from state and business data models',
    icon: 'Layout',
    accent: '#10b981',
    tags: ['reactive', 'view-models', 'ui-separation'],
    data: {
      folderStyle: 'mvvm',
      description: 'View binds to ViewModel; ViewModel exposes state to the View.',
    },
  },
  {
    id: 'layer_first',
    name: 'Layer First',
    desc: 'Top-level folders for models, views, controllers, and services',
    icon: 'Folder',
    accent: '#f59e0b',
    tags: ['simple', 'quick-start', 'traditional'],
    data: {
      folderStyle: 'layer_first',
      description: 'Simple structure ideal for small to medium apps.',
    },
  },
  {
    id: 'mvc',
    name: 'MVC (Model-View-Controller)',
    desc: 'Classic tri-part separation of state, display, and user interaction',
    icon: 'Boxes',
    accent: '#ec4899',
    tags: ['classic', 'lightweight'],
    data: {
      folderStyle: 'mvc',
      description: 'Models hold state, Views render UI, Controllers coordinate.',
    },
  },
];
