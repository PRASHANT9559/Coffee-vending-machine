import type { StudioConfig } from './types';

export interface ReverseDetectionResult {
  config: Partial<StudioConfig>;
  detected: {
    stateManager?: string;
    backend?: string;
    database?: string;
    features: string[];
    platforms: string[];
  };
}

/**
 * Reverse-engineers a Flutter pubspec.yaml file into Swati Studio configuration.
 */
export function reversePubspec(yamlContent: string): ReverseDetectionResult {
  const result: Partial<StudioConfig> = {};
  const detectedFeatures: string[] = [];

  // 1. Basic Metadata regex matching
  const nameMatch = yamlContent.match(/^name:\s*([a-zA-Z0-9_-]+)/m);
  if (nameMatch) {
    result['project.name'] = nameMatch[1].replace(/_/g, ' ');
    result['project.packageName'] = `com.example.${nameMatch[1]}`;
  }

  const descMatch = yamlContent.match(/^description:\s*["']?([^"'\n\r]+)["']?/m);
  if (descMatch) {
    result['project.description'] = descMatch[1].trim();
  }

  const versionMatch = yamlContent.match(/^version:\s*([0-9]+\.[0-9]+\.[0-9]+)/m);
  if (versionMatch) {
    result['project.version'] = versionMatch[1];
  }

  // 2. State Manager detection (anchored to dependency declarations to prevent false positives)
  let stateManager: string | undefined;
  if (/(?:^|\n)\s*(?:flutter_riverpod|hooks_riverpod)\s*:/m.test(yamlContent)) {
    stateManager = 'riverpod';
  } else if (/(?:^|\n)\s*(?:flutter_bloc|bloc)\s*:/m.test(yamlContent)) {
    stateManager = 'bloc';
  } else if (/(?:^|\n)\s*get\s*:/m.test(yamlContent)) {
    stateManager = 'getx';
  } else if (/(?:^|\n)\s*provider\s*:/m.test(yamlContent)) {
    stateManager = 'provider';
  } else if (/(?:^|\n)\s*(?:flutter_mobx|mobx)\s*:/m.test(yamlContent)) {
    stateManager = 'mobx';
  }
  if (stateManager) {
    result['state.manager'] = stateManager;
  }

  // 3. Backend detection
  let backend: string | undefined;
  if (/supabase_flutter|supabase/i.test(yamlContent)) {
    backend = 'supabase';
  } else if (/firebase_core|cloud_firestore|firebase_auth/i.test(yamlContent)) {
    backend = 'firebase';
  } else if (/appwrite/i.test(yamlContent)) {
    backend = 'appwrite';
  } else if (/pocketbase/i.test(yamlContent)) {
    backend = 'pocketbase';
  }
  if (backend) {
    result['backend.provider'] = backend;
  }

  // 4. Database detection
  let database: string | undefined;
  if (/isar|isar_flutter_libs/i.test(yamlContent)) {
    database = 'isar';
  } else if (/hive|hive_flutter/i.test(yamlContent)) {
    database = 'hive';
  } else if (/drift/i.test(yamlContent)) {
    database = 'drift';
  } else if (/sqflite/i.test(yamlContent)) {
    database = 'sqlite';
  }
  if (database) {
    result['database.provider'] = database;
  }

  // 5. Features detection
  if (/firebase_auth|supabase_auth|auth0/i.test(yamlContent)) {
    detectedFeatures.push('authentication');
  }
  if (/flutter_local_notifications|firebase_messaging/i.test(yamlContent)) {
    detectedFeatures.push('notifications');
  }
  if (/google_maps_flutter|mapbox_maps_flutter/i.test(yamlContent)) {
    detectedFeatures.push('maps');
  }
  if (/camera|image_picker/i.test(yamlContent)) {
    detectedFeatures.push('camera');
  }
  if (/flutter_stripe|pay|purchases_flutter/i.test(yamlContent)) {
    detectedFeatures.push('payments');
  }
  if (/flutter_blue_plus|quick_blue/i.test(yamlContent)) {
    detectedFeatures.push('bluetooth');
  }
  if (/google_generative_ai|langchain/i.test(yamlContent)) {
    detectedFeatures.push('ai_assistant');
  }

  if (detectedFeatures.length > 0) {
    result['features.selected'] = detectedFeatures;
  }

  return {
    config: result,
    detected: {
      stateManager,
      backend,
      database,
      features: detectedFeatures,
      platforms: ['android', 'ios'],
    },
  };
}
