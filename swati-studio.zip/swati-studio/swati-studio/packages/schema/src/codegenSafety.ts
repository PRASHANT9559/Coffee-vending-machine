export type FileOwnership = 'generated' | 'scaffold' | 'hybrid';

export interface FileManifestEntry {
  path: string;
  ownership: FileOwnership;
  hash: string;
  lastGeneratedAt: string;
}

export interface Manifest {
  schemaVersion: number;
  files: Record<string, FileManifestEntry>;
}

export interface RegenerationFileStatus {
  path: string;
  ownership: FileOwnership;
  status: 'overwritten' | 'merged' | 'conflict' | 'skipped' | 'new';
  summary: string;
  userCodeRetained?: boolean;
}

export interface RegenerationPreviewReport {
  timestamp: string;
  dryRun: boolean;
  totalFiles: number;
  overwrittenCount: number;
  mergedCount: number;
  conflictCount: number;
  skippedCount: number;
  newCount: number;
  files: RegenerationFileStatus[];
  recommendedGitBackup: boolean;
}

/**
 * Determines default ownership based on standard project conventions.
 */
export function determineFileOwnership(filePath: string): FileOwnership {
  // Hybrid files: main entrypoint, global config, living documentation
  if (
    filePath === 'lib/main.dart' ||
    filePath.startsWith('lib/main_') ||
    filePath === 'lib/config/app_config.dart' ||
    filePath === 'README.md' ||
    filePath === 'docs/ARCHITECTURE.md' ||
    filePath === 'docs/ONBOARDING.md'
  ) {
    return 'hybrid';
  }

  // Scaffold files: user-owned views, UI screens, mock repositories, tests
  if (
    filePath.includes('/screens/') ||
    filePath.includes('/pages/') ||
    filePath.endsWith('_screen.dart') ||
    filePath.endsWith('_page.dart') ||
    filePath.startsWith('test/') ||
    filePath.includes('/mock/')
  ) {
    return 'scaffold';
  }

  // Everything else is wizard-managed generated code
  return 'generated';
}

/**
 * Parses hybrid file content and extracts protected custom regions.
 * Protected syntax:
 * // <swati:custom-imports> ... // </swati:custom-imports>
 * // <swati:custom-code> ... // </swati:custom-code>
 */
export function extractProtectedRegions(content: string): Map<string, string> {
  const regions = new Map<string, string>();
  const regex = /\/\/\s*<swati:([a-zA-Z0-9_-]+)>([\s\S]*?)\/\/\s*<\/swati:\1>/g;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(content)) !== null) {
    const regionName = match[1];
    const customContent = match[2];
    regions.set(regionName, customContent);
  }

  return regions;
}

/**
 * Injects user's protected regions into newly generated template content,
 * ensuring user custom logic is never overwritten during re-generation.
 */
export function mergeHybridFile(newGeneratedContent: string, existingUserContent: string): string {
  const userRegions = extractProtectedRegions(existingUserContent);
  if (userRegions.size === 0) return newGeneratedContent;

  let merged = newGeneratedContent;

  for (const [regionName, customCode] of userRegions.entries()) {
    const targetTag = new RegExp(
      `(\\/\\/\\s*<swati:${regionName}>)[\\s\\S]*?(\\/\\/\\s*<\\/swati:${regionName}>)`,
      'g'
    );
    if (targetTag.test(merged)) {
      merged = merged.replace(targetTag, `$1${customCode}$2`);
    }
  }

  return merged;
}

/**
 * 3-Way Merge simulation:
 * Evaluates whether file should be cleanly overwritten, skipped, or merged.
 */
export function computeMergeAction(
  filePath: string,
  ownership: FileOwnership,
  baseContent: string | null,
  currentContent: string | null,
  newContent: string
): { action: 'overwrite' | 'skip' | 'merge' | 'conflict'; result: string } {
  if (ownership === 'scaffold' && currentContent !== null) {
    // User owns scaffold file; never touch after initial generation
    return { action: 'skip', result: currentContent };
  }

  if (ownership === 'generated') {
    // Pure generated file; cleanly overwrite
    return { action: 'overwrite', result: newContent };
  }

  if (ownership === 'hybrid') {
    if (currentContent === null) {
      return { action: 'overwrite', result: newContent };
    }
    const merged = mergeHybridFile(newContent, currentContent);
    return { action: 'merge', result: merged };
  }

  return { action: 'overwrite', result: newContent };
}

/**
 * Evaluates a complete regeneration dry-run preview across newly generated files
 * compared with existing files on disk and the last generated manifest.
 */
export function previewRegeneration(
  manifest: Manifest | null,
  existingFiles: Record<string, string>,
  newGeneratedFiles: Record<string, string>
): RegenerationPreviewReport {
  const results: RegenerationFileStatus[] = [];

  for (const [path, newContent] of Object.entries(newGeneratedFiles)) {
    const existing = existingFiles[path];
    const ownership = manifest?.files[path]?.ownership || determineFileOwnership(path);

    if (existing === undefined) {
      results.push({
        path,
        ownership,
        status: 'new',
        summary: 'New file created by wizard update',
      });
      continue;
    }

    if (ownership === 'scaffold') {
      results.push({
        path,
        ownership,
        status: 'skipped',
        summary: 'Preserved user-owned scaffold (untouched)',
        userCodeRetained: true,
      });
    } else if (ownership === 'generated') {
      results.push({
        path,
        ownership,
        status: 'overwritten',
        summary: 'Overwritten cleanly with latest generated code',
      });
    } else {
      // Hybrid file
      const userRegions = extractProtectedRegions(existing);
      results.push({
        path,
        ownership,
        status: 'merged',
        summary: `Merged successfully (${userRegions.size} custom protected region(s) retained)`,
        userCodeRetained: userRegions.size > 0,
      });
    }
  }

  return {
    timestamp: new Date().toISOString(),
    dryRun: true,
    totalFiles: results.length,
    overwrittenCount: results.filter((r) => r.status === 'overwritten').length,
    mergedCount: results.filter((r) => r.status === 'merged').length,
    conflictCount: results.filter((r) => r.status === 'conflict').length,
    skippedCount: results.filter((r) => r.status === 'skipped').length,
    newCount: results.filter((r) => r.status === 'new').length,
    files: results,
    recommendedGitBackup: true,
  };
}
