import { describe, expect, it } from 'vitest';
import {
  analyzeAppPrompt,
  architectures,
  authMethods,
  backends,
  buildSummary,
  cicdPlatforms,
  componentCategories,
  databases,
  defaultConfig,
  enterpriseTemplates,
  environmentOptions,
  featureList,
  findOption,
  homeStyles,
  licenses,
  navigationStyles,
  parseConfig,
  platforms,
  serializeConfig,
  stateManagers,
  steps,
  supportedLocales,
  themeColors,
  uiStyles,
  validateConfig,
} from './index';

describe('Schema Catalogs & Steps Integrity', () => {
  it('has 11 wizard steps (revised workflow)', () => {
    expect(steps.length).toBe(11);
    expect(steps[0].id).toBe('frontend');
    expect(steps[1].id).toBe('navigation');
    expect(steps[2].id).toBe('project');
    expect(steps[3].id).toBe('database');
  });

  it('all step ids are unique', () => {
    const ids = steps.map((s) => s.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('all field ids across all steps are unique', () => {
    const allFieldIds: string[] = [];
    for (const step of steps) {
      for (const f of step.fields) {
        allFieldIds.push(f.id);
      }
    }
    expect(new Set(allFieldIds).size).toBe(allFieldIds.length);
  });

  it('navigationStyles catalog has all 36+ UI Kit options with unique ids', () => {
    expect(navigationStyles.length).toBeGreaterThanOrEqual(36);
    const ids = navigationStyles.map((n) => n.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(ids).toContain('minimal_clean');
    expect(ids).toContain('glassmorphism');
    expect(ids).toContain('floating_detached');
    expect(ids).toContain('neumorphism');
    expect(ids).toContain('pill_highlight');
    expect(ids).toContain('center_fab');
    expect(ids).toContain('gradient_bold');
    expect(ids).toContain('outline_icons');
    expect(ids).toContain('neon_glow');
    expect(ids).toContain('claymorphism');
    expect(ids).toContain('retro_pixel');
    expect(ids).toContain('badge_counter');
    expect(ids).toContain('haptic_bounce');
    expect(ids).toContain('tab_indicator');
    expect(ids).toContain('curved_bg');
    expect(ids).toContain('dock_ios');
    expect(ids).toContain('drawer');
    expect(ids).toContain('rail');
  });

  it('backends catalog is non-empty and has unique ids', () => {
    expect(backends.length).toBeGreaterThanOrEqual(10);
    const ids = backends.map((b) => b.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('databases catalog is non-empty and has unique ids', () => {
    expect(databases.length).toBeGreaterThanOrEqual(8);
    const ids = databases.map((d) => d.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('architectures catalog has 6 patterns with unique ids', () => {
    expect(architectures.length).toBe(6);
    const ids = architectures.map((a) => a.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('state managers catalog has 5 options with unique ids', () => {
    expect(stateManagers.length).toBe(5);
    const ids = stateManagers.map((s) => s.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('features catalog has 22 items', () => {
    expect(featureList.length).toBe(22);
    const ids = featureList.map((f) => f.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('components catalog has 13 categories', () => {
    expect(componentCategories.length).toBe(13);
    const ids = componentCategories.map((c) => c.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('findOption finds valid entries in catalogs', () => {
    const indigo = findOption('themeColors', 'indigo');
    expect(indigo).toBeDefined();
    expect(indigo?.accent).toBe('#4F46E5');

    const supabase = findOption('backends', 'supabase');
    expect(supabase).toBeDefined();
    expect(supabase?.name).toBe('Supabase');

    const minimalClean = findOption('navigationStyles', 'minimal_clean');
    expect(minimalClean).toBeDefined();
    expect(minimalClean?.name).toBe('01. Minimal Clean');
  });
});

describe('Configuration & Validation', () => {
  it('generates a valid default configuration with navigation items', () => {
    const config = defaultConfig();
    expect(config['project.name']).toBe('My Flutter App');
    expect(config['navigation.style']).toBe('minimal_clean');
    expect(Array.isArray(config['navigation.items'])).toBe(true);
    expect((config['navigation.items'] as unknown[]).length).toBe(3);
    expect(config['backend.provider']).toBe('supabase');
    expect(config['database.engine']).toBe('sqlite');
    expect(config['architecture.pattern']).toBe('feature_first');
    expect(config['state.manager']).toBe('riverpod');
  });

  it('validates navigation items minimum requirement (at least 2)', () => {
    const config = defaultConfig();
    config['navigation.items'] = [
      { id: '1', name: 'Home', icon: 'Home', route: '/home', title: 'Home' },
    ];
    const issues = validateConfig(config);
    expect(issues.some((i) => i.field === 'navigation.items' && i.severity === 'error')).toBe(true);
  });

  it('validates required fields and reports errors', () => {
    const config = defaultConfig();
    config['project.name'] = '';
    config['project.packageName'] = 'INVALID PACKAGE!';

    const issues = validateConfig(config);
    expect(issues.some((i) => i.field === 'project.name')).toBe(true);
    expect(issues.some((i) => i.field === 'project.packageName')).toBe(true);
  });

  it('rejects a non-semver version', () => {
    const config = defaultConfig();
    config['project.version'] = 'one';
    const issues = validateConfig(config);
    expect(issues.some((i) => i.field === 'project.version')).toBe(true);

    config['project.version'] = '2.3.1-beta.1';
    expect(validateConfig(config).some((i) => i.field === 'project.version')).toBe(false);
  });

  it('every default selection points at a real catalog option', () => {
    const config = defaultConfig();
    for (const step of steps) {
      for (const field of step.fields) {
        if (!field.options || field.options.length === 0) continue;
        const value = config[field.id];
        if (value === undefined) continue;
        const valid = new Set(field.options.map((o) => o.id));
        const selected = Array.isArray(value) ? value : [value];
        for (const id of selected) {
          if (typeof id !== 'string') continue;
          expect(valid.has(id), `${field.id} default "${id}" is not in its catalog`).toBe(true);
        }
      }
    }
  });

  it('buildSummary returns all expected summary rows including Navigation', () => {
    const config = defaultConfig();
    const summary = buildSummary(config);
    expect(summary.length).toBeGreaterThanOrEqual(11);
    expect(summary.some((s) => s.label === 'Project Name')).toBe(true);
    expect(summary.some((s) => s.label === 'Navigation')).toBe(true);
    expect(summary.some((s) => s.label === 'Backend')).toBe(true);
    expect(summary.some((s) => s.label === 'Architecture')).toBe(true);
  });

  it('serializes and parses configuration without data corruption', () => {
    const config = defaultConfig();
    const serialized = serializeConfig(config);
    const parsed = parseConfig(serialized);
    expect(parsed['project.name']).toBe(config['project.name']);
    expect(parsed['project.packageName']).toBe(config['project.packageName']);
  });

  it('provides 10 enterprise app templates with complete preset configs', () => {
    expect(enterpriseTemplates.length).toBeGreaterThanOrEqual(10);
    for (const t of enterpriseTemplates) {
      expect(t.id).toBeDefined();
      expect(t.name).toBeDefined();
      expect(t.presetConfig).toBeDefined();
      expect(t.presetConfig['project.name']).toBeDefined();
      expect(t.presetConfig['navigation.items']).toBeDefined();
    }
  });

  it('AI Configurator parses food delivery prompt and generates matching stack', () => {
    const res = analyzeAppPrompt('Build a food delivery app with live map tracking, payments and chat');
    expect(res.matchedTemplateId).toBe('food_delivery');
    expect(res.detectedKeywords).toContain('food-delivery');
    expect(res.config['backend.provider']).toBeDefined();
    expect(res.config['navigation.items']).toBeDefined();
    const navItems = res.config['navigation.items'] as { name: string }[];
    expect(navItems.some((n) => n.name === 'Restaurants' || n.name === 'Tracking')).toBe(true);
  });

  it('AI Configurator recognizes AMOLED true black and dark styles', () => {
    const res = analyzeAppPrompt('E-commerce store with AMOLED true black theme and riverpod');
    expect(res.config['frontend.themeMode']).toBe('amoled');
    expect(res.config['state.manager']).toBe('riverpod');
  });
});
