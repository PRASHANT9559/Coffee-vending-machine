import type {
  FieldDef,
  FieldValue,
  NavigationItem,
  OptionDef,
  StepDef,
  StudioConfig,
  SummaryRow,
  UploadedDatabaseFile,
  ValidationIssue,
} from './types';
import { architectures } from './catalogs/architectures';
import { backends } from './catalogs/backends';
import { componentCategories } from './catalogs/components';
import { databases } from './catalogs/databases';
import { featureList } from './catalogs/features';
import { navigationStyles } from './catalogs/navigationStyles';
import { stateManagers } from './catalogs/states';
import {
  animations,
  fonts,
  homeStyles,
  licenses,
  platforms,
  spacings,
  themeModes,
  uiStyles,
} from './catalogs/styles';
import { themeColors } from './catalogs/themeColors';
import { aestheticCombos } from './catalogs/aestheticCombos';
import { authMethods, authScreens, authSecurityFlags } from './catalogs/authMethods';
import { cicdPlatforms, environmentOptions, supportedLocales } from './catalogs/environments';
import { enterpriseTemplates } from './catalogs/templates';
import { steps } from './schema';

const CATALOG_MAP: Record<string, OptionDef[]> = {
  backends,
  databases,
  architectures,
  states: stateManagers,
  stateManagers,
  features: featureList,
  featureList,
  components: componentCategories,
  componentCategories,
  themeColors,
  fonts,
  uiStyles,
  themeModes,
  aestheticCombos,
  homeStyles,
  animations,
  spacings,
  licenses,
  platforms,
  navigationStyles,
  navigation: navigationStyles,
  authMethods,
  authScreens,
  authSecurityFlags,
  cicdPlatforms,
  environmentOptions,
  supportedLocales,
};

/** Finds an option by catalog name and id. */
export function findOption(catalogName: string, id: string): OptionDef | undefined {
  const catalog = CATALOG_MAP[catalogName];
  if (!catalog) return undefined;
  return catalog.find((opt) => opt.id === id);
}

/** Resolves dynamic credential/config fields for the currently selected provider/engine. */
export function dynamicFieldsFor(config: Record<string, unknown>): FieldDef[] {
  const dynamic: FieldDef[] = [];

  const selectedBackend = String(config['backend.provider'] ?? 'supabase');
  const backendOpt = backends.find((b) => b.id === selectedBackend);
  if (backendOpt?.fields) {
    dynamic.push(...backendOpt.fields);
  }

  const selectedDb = String(config['database.engine'] ?? 'sqlite');
  const dbOpt = databases.find((d) => d.id === selectedDb);
  if (dbOpt?.fields) {
    dynamic.push(...dbOpt.fields);
  }

  return dynamic;
}

/** Returns all active fields for a given wizard step, including dynamic provider fields. */
export function fieldsForStep(step: StepDef, config: Record<string, unknown>): FieldDef[] {
  const list: FieldDef[] = [...step.fields];

  if (step.id === 'backend') {
    const selected = String(config['backend.provider'] ?? 'supabase');
    const opt = backends.find((b) => b.id === selected);
    if (opt?.fields) list.push(...opt.fields);
  }

  if (step.id === 'database') {
    const selected = String(config['database.engine'] ?? 'sqlite');
    const opt = databases.find((d) => d.id === selected);
    if (opt?.fields) list.push(...opt.fields);
  }

  return list.filter((field) => {
    if (!field.visibleWhen) return true;
    const rule = field.visibleWhen;
    if ('in' in rule && rule.field) {
      const current = String(config[rule.field] ?? '');
      return rule.in.includes(current);
    }
    if ('equals' in rule && rule.field) {
      const current = String(config[rule.field] ?? '');
      return current === rule.equals;
    }
    return true;
  });
}

/** Computes the default flat configuration. */
export function defaultConfig(): StudioConfig {
  const cfg: StudioConfig = {
    'output.dir': '',
    'output.createZip': true,
  };

  for (const step of steps) {
    for (const field of step.fields) {
      if (field.default !== undefined) {
        cfg[field.id] = field.default;
      }
    }
  }

  for (const backend of backends) {
    if (backend.fields) {
      for (const field of backend.fields) {
        if (field.default !== undefined) cfg[field.id] = field.default;
      }
    }
  }

  for (const db of databases) {
    if (db.fields) {
      for (const field of db.fields) {
        if (field.default !== undefined) cfg[field.id] = field.default;
      }
    }
  }

  return cfg;
}

/** Validates configuration values, surfacing inline errors per field and step. */
export function validateConfig(config: StudioConfig): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  const name = String(config['project.name'] ?? '').trim();
  if (!name) {
    issues.push({
      field: 'project.name',
      step: 'project',
      severity: 'error',
      message: 'Project name is required.',
    });
  }

  const pkg = String(config['project.packageName'] ?? '').trim();
  const pkgRegex = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
  if (!pkg) {
    issues.push({
      field: 'project.packageName',
      step: 'project',
      severity: 'error',
      message: 'Package identifier is required.',
    });
  } else if (!pkgRegex.test(pkg)) {
    issues.push({
      field: 'project.packageName',
      step: 'project',
      severity: 'error',
      message: 'Invalid package name. Must be lowercase reverse-domain (e.g. com.example.myapp).',
    });
  }

  const version = String(config['project.version'] ?? '').trim();
  const semver = /^\d+\.\d+\.\d+(-[0-9A-Za-z.-]+)?(\+[0-9A-Za-z.-]+)?$/;
  if (!version) {
    issues.push({
      field: 'project.version',
      step: 'project',
      severity: 'error',
      message: 'Version is required.',
    });
  } else if (!semver.test(version)) {
    issues.push({
      field: 'project.version',
      step: 'project',
      severity: 'error',
      message: 'Version must be semantic, e.g. 1.0.0.',
    });
  }

  // Navigation Validation (Mandatory min 2 buttons)
  const navItems = Array.isArray(config['navigation.items'])
    ? (config['navigation.items'] as NavigationItem[])
    : [];

  if (navItems.length < 2) {
    issues.push({
      field: 'navigation.items',
      step: 'navigation',
      severity: 'error',
      message: 'At least 2 navigation buttons are required to construct application navigation.',
    });
  }

  const navStyle = String(config['navigation.style'] ?? 'minimal_clean');
  if (navStyle !== 'drawer' && navStyle !== 'rail' && navItems.length > 5) {
    issues.push({
      field: 'navigation.items',
      step: 'navigation',
      severity: 'warning',
      message: 'Bottom Navigation Bars work best with up to 5 items. Consider using Side Navigation Drawer for more items.',
    });
  }

  // Check dynamic backend fields
  const backend = String(config['backend.provider'] ?? 'supabase');
  const backendOpt = backends.find((b) => b.id === backend);
  if (backendOpt?.fields) {
    for (const f of backendOpt.fields) {
      if (f.required) {
        const val = String(config[f.id] ?? '').trim();
        if (!val) {
          issues.push({
            field: f.id,
            step: 'backend',
            severity: 'error',
            message: `${f.label} is required for ${backendOpt.name}.`,
          });
        }
      }
    }
  }

  // Check dynamic database fields
  const db = String(config['database.engine'] ?? 'sqlite');
  const dbOpt = databases.find((d) => d.id === db);
  if (dbOpt?.fields) {
    for (const f of dbOpt.fields) {
      if (f.required) {
        const val = String(config[f.id] ?? '').trim();
        if (!val) {
          issues.push({
            field: f.id,
            step: 'database',
            severity: 'error',
            message: `${f.label} is required for ${dbOpt.name}.`,
          });
        }
      }
    }
  }

  return issues;
}

/** Builds the human-readable summary displayed in the review step. */
export function buildSummary(config: StudioConfig): SummaryRow[] {
  const rows: SummaryRow[] = [];

  const name = String(config['project.name'] ?? 'My App');
  const pkg = String(config['project.packageName'] ?? 'com.example.app');
  const version = String(config['project.version'] ?? '1.0.0');
  const license = String(config['project.license'] ?? 'MIT');

  rows.push({ label: 'Project Name', value: name });
  rows.push({ label: 'Package ID', value: pkg });
  rows.push({ label: 'Version & License', value: `${version} (${license})` });

  // Navigation
  const navStyleId = String(config['navigation.style'] ?? 'bottom_nav');
  const navStyleOpt = navigationStyles.find((n) => n.id === navStyleId);
  const navItems = Array.isArray(config['navigation.items'])
    ? (config['navigation.items'] as NavigationItem[])
    : [];
  rows.push({
    label: 'Navigation',
    value: `${navStyleOpt?.name ?? navStyleId} (${navItems.length} screens)`,
    accent: navStyleOpt?.accent ?? '#6366f1',
  });

  const comboId = String(config['frontend.aestheticCombo'] ?? 'midnight_glass');
  const comboOpt = aestheticCombos.find((c) => c.id === comboId);
  if (comboOpt) {
    rows.push({ label: 'Aesthetic Combo', value: comboOpt.name, accent: comboOpt.accent });
  }

  const themeModeId = String(config['frontend.themeMode'] ?? 'dark');
  const modeOpt = themeModes.find((m) => m.id === themeModeId);
  rows.push({ label: 'Theme Layer', value: modeOpt?.name ?? themeModeId });

  const uiStyleOpt = uiStyles.find((u) => u.id === config['frontend.uiStyle']);
  rows.push({ label: 'UI Style', value: uiStyleOpt?.name ?? String(config['frontend.uiStyle'] ?? 'Material 3') });

  const themeId = String(config['frontend.themeColor'] ?? 'indigo');
  const themeOpt = themeColors.find((t) => t.id === themeId);
  const accent = themeId === 'custom' ? String(config['frontend.customColor'] ?? '#6366f1') : (themeOpt?.accent ?? '#6366f1');
  rows.push({ label: 'Theme Color', value: themeId === 'custom' ? `Custom (${accent})` : (themeOpt?.name ?? themeId), accent });

  const font = String(config['frontend.font'] ?? 'Inter');
  rows.push({ label: 'Font Family', value: font });

  const backendId = String(config['backend.provider'] ?? 'none');
  const backendOpt = backends.find((b) => b.id === backendId);
  rows.push({ label: 'Backend', value: backendOpt?.name ?? backendId, accent: backendOpt?.accent });

  const dbId = String(config['database.engine'] ?? 'sqlite');
  const dbOpt = databases.find((d) => d.id === dbId);
  const dbFile = config['database.file'] as UploadedDatabaseFile | undefined;
  rows.push({
    label: 'Database',
    value: dbFile?.name ? `${dbOpt?.name ?? dbId} (+ ${dbFile.name})` : (dbOpt?.name ?? dbId),
    accent: dbOpt?.accent,
  });

  const archId = String(config['architecture.pattern'] ?? 'feature_first');
  const archOpt = architectures.find((a) => a.id === archId);
  rows.push({ label: 'Architecture', value: archOpt?.name ?? archId });

  const stateId = String(config['state.manager'] ?? 'riverpod');
  const stateOpt = stateManagers.find((s) => s.id === stateId);
  rows.push({ label: 'State Management', value: stateOpt?.name ?? stateId });

  const features = Array.isArray(config['features.selected']) ? (config['features.selected'] as string[]) : [];
  rows.push({ label: 'Features', value: `${features.length} selected` });

  const envFlavor = String(config['project.environmentFlavor'] ?? 'single');
  if (envFlavor !== 'single') {
    const envOpt = environmentOptions.find((e) => e.id === envFlavor);
    rows.push({ label: 'Flavors & Envs', value: envOpt?.name ?? envFlavor, accent: '#10b981' });
  }

  const cicd = String(config['project.cicdPlatform'] ?? 'github_actions');
  if (cicd !== 'none') {
    const cicdOpt = cicdPlatforms.find((c) => c.id === cicd);
    rows.push({ label: 'CI/CD Pipeline', value: cicdOpt?.name ?? cicd, accent: '#6366f1' });
  }

  const locale = String(config['project.locale'] ?? 'en');
  const localeOpt = supportedLocales.find((l) => l.id === locale);
  rows.push({ label: 'Language / i18n', value: localeOpt?.name ?? locale });

  if (Boolean(config['security.enableRbac'])) {
    rows.push({ label: 'RBAC Access Control', value: 'Enabled (5 roles)', accent: '#f59e0b' });
  }

  const components = Array.isArray(config['components.selected']) ? (config['components.selected'] as string[]) : [];
  rows.push({ label: 'Components', value: `${components.length} categories` });

  return rows;
}

/** Serializes config into formatted JSON for saving or exporting. */
export function serializeConfig(config: StudioConfig): string {
  return JSON.stringify(config, null, 2);
}

/** Parses and sanitizes a JSON configuration string. */
export function parseConfig(raw: string): StudioConfig {
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return { ...defaultConfig(), ...parsed };
    }
  } catch (err) {
    console.error('Failed to parse config JSON:', err);
  }
  return defaultConfig();
}
