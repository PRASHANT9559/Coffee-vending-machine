export interface NavigationItem {
  id: string;
  name: string;
  icon: string;
  route: string;
  title: string;
  description?: string;
}

export interface UploadedDatabaseFile {
  name: string;
  size: number;
  extension: string;
  path?: string;
  contentBase64?: string;
  lastModified?: number;
}

export type FieldValue =
  | string
  | number
  | boolean
  | string[]
  | NavigationItem[]
  | UploadedDatabaseFile
  | null
  | undefined;

export interface OptionDef {
  id: string;
  name: string;
  desc?: string;
  icon?: string;
  accent?: string;
  tags?: string[];
  fields?: FieldDef[];
  data?: Record<string, unknown>;
}

export type FieldKind =
  | 'text'
  | 'textarea'
  | 'number'
  | 'range'
  | 'toggle'
  | 'color'
  | 'select'
  | 'multiselect'
  | 'list'
  | 'file';

export interface FieldDef {
  id: string;
  kind: FieldKind;
  label: string;
  help?: string;
  placeholder?: string;
  required?: boolean;
  default?: FieldValue;
  options?: OptionDef[];
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
  accept?: string;
  visibleWhen?:
    | { field: string; in: string[] }
    | { field: string; equals: string }
    | { field: string; notEquals?: string };
  group?: string;
  multiple?: boolean;
  presentation?: 'dropdown' | 'cards' | 'chips' | 'swatches';
}

export interface StepDef {
  id: string;
  label: string;
  icon: string;
  title: string;
  subtitle: string;
  fields: FieldDef[];
  required?: boolean;
  panel?: 'preview' | 'review';
}

export type StudioConfig = Record<string, FieldValue>;

export interface ValidationIssue {
  field: string;
  message: string;
  severity: 'error' | 'warning';
  step?: string;
}

export interface SummaryRow {
  label: string;
  value: string;
  accent?: string;
}

export interface AppTemplate {
  id: string;
  name: string;
  desc: string;
  icon: string;
  category: 'commerce' | 'social' | 'productivity' | 'content' | 'fintech' | 'services';
  badge?: string;
  presetConfig: Record<string, FieldValue>;
}

export interface AuthMethodDef {
  id: string;
  name: string;
  icon: string;
  desc: string;
}

export interface RbacRoleDef {
  id: string;
  name: string;
  description: string;
  permissions: string[];
}

