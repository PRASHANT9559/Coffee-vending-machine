import type { GenContext, GeneratedFile } from '../types';

export function templateResponsiveFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Breakpoints Definition
  files.push({
    path: 'lib/core/responsive/breakpoints.dart',
    contents: `import 'package:flutter/material.dart';

enum DeviceScreenType { compact, medium, expanded }

class Breakpoints {
  Breakpoints._();

  static const double compactMax = 600.0;
  static const double mediumMax = 840.0;
  static const double maxContentWidth = 1200.0;

  static DeviceScreenType getScreenType(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width < compactMax) return DeviceScreenType.compact;
    if (width < mediumMax) return DeviceScreenType.medium;
    return DeviceScreenType.expanded;
  }

  static bool isCompact(BuildContext context) =>
      getScreenType(context) == DeviceScreenType.compact;

  static bool isMedium(BuildContext context) =>
      getScreenType(context) == DeviceScreenType.medium;

  static bool isExpanded(BuildContext context) =>
      getScreenType(context) == DeviceScreenType.expanded;
}
`,
  });

  // 2. Responsive Builder Widget
  files.push({
    path: 'lib/core/responsive/responsive_builder.dart',
    contents: `import 'package:flutter/material.dart';
import 'breakpoints.dart';

typedef ResponsiveWidgetBuilder = Widget Function(
  BuildContext context,
  DeviceScreenType screenType,
);

class ResponsiveBuilder extends StatelessWidget {
  final ResponsiveWidgetBuilder builder;

  const ResponsiveBuilder({super.key, required this.builder});

  @override
  Widget build(BuildContext context) {
    final screenType = Breakpoints.getScreenType(context);
    return builder(context, screenType);
  }
}
`,
  });

  // 3. Adaptive Scaffold (BottomNav vs NavigationRail vs Drawer / Split)
  files.push({
    path: 'lib/core/responsive/adaptive_scaffold.dart',
    contents: `import 'package:flutter/material.dart';
import 'breakpoints.dart';

class AdaptiveScaffoldDestination {
  final String label;
  final IconData icon;
  final IconData? selectedIcon;

  const AdaptiveScaffoldDestination({
    required this.label,
    required this.icon,
    this.selectedIcon,
  });
}

class AdaptiveScaffold extends StatelessWidget {
  final String title;
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final List<AdaptiveScaffoldDestination> destinations;
  final Widget body;
  final Widget? floatingActionButton;

  const AdaptiveScaffold({
    super.key,
    required this.title,
    required this.selectedIndex,
    required this.onDestinationSelected,
    required this.destinations,
    required this.body,
    this.floatingActionButton,
  });

  @override
  Widget build(BuildContext context) {
    final screenType = Breakpoints.getScreenType(context);

    // Compact layout: Standard Phone Bottom Navigation
    if (screenType == DeviceScreenType.compact) {
      return Scaffold(
        appBar: AppBar(title: Text(title)),
        body: body,
        floatingActionButton: floatingActionButton,
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: onDestinationSelected,
          destinations: destinations
              .map(
                (d) => NavigationDestination(
                  icon: Icon(d.icon),
                  selectedIcon: d.selectedIcon != null ? Icon(d.selectedIcon) : null,
                  label: d.label,
                ),
              )
              .toList(),
        ),
      );
    }

    // Medium layout: Tablet Navigation Rail
    if (screenType == DeviceScreenType.medium) {
      return Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Row(
          children: [
            NavigationRail(
              selectedIndex: selectedIndex,
              onDestinationSelected: onDestinationSelected,
              labelType: NavigationRailLabelType.selected,
              destinations: destinations
                  .map(
                    (d) => NavigationRailDestination(
                      icon: Icon(d.icon),
                      selectedIcon: d.selectedIcon != null ? Icon(d.selectedIcon) : null,
                      label: Text(d.label),
                    ),
                  )
                  .toList(),
            ),
            const VerticalDivider(thickness: 1, width: 1),
            Expanded(child: body),
          ],
        ),
        floatingActionButton: floatingActionButton,
      );
    }

    // Expanded layout: Desktop / Web Side Navigation Drawer + Master-Detail
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Row(
        children: [
          SizedBox(
            width: 240,
            child: NavigationDrawer(
              selectedIndex: selectedIndex,
              onDestinationSelected: onDestinationSelected,
              children: [
                const SizedBox(height: 16),
                ...destinations.map(
                  (d) => NavigationDrawerDestination(
                    icon: Icon(d.icon),
                    selectedIcon: d.selectedIcon != null ? Icon(d.selectedIcon) : null,
                    label: Text(d.label),
                  ),
                ),
              ],
            ),
          ),
          const VerticalDivider(thickness: 1, width: 1),
          Expanded(child: body),
        ],
      ),
      floatingActionButton: floatingActionButton,
    );
  }
}
`,
  });

  // 4. Max Content Width Wrapper
  files.push({
    path: 'lib/core/responsive/max_content_width.dart',
    contents: `import 'package:flutter/material.dart';
import 'breakpoints.dart';

class MaxContentWidth extends StatelessWidget {
  final Widget child;
  final double maxWidth;

  const MaxContentWidth({
    super.key,
    required this.child,
    this.maxWidth = Breakpoints.maxContentWidth,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: child,
      ),
    );
  }
}
`,
  });

  // 5. Semantics Helpers (WCAG Accessibility Standards)
  files.push({
    path: 'lib/core/accessibility/semantics_helpers.dart',
    contents: `import 'package:flutter/material.dart';

class SemanticsHelpers {
  SemanticsHelpers._();

  static const double minTouchTargetSize = 48.0;

  /// Wraps an interactive widget to enforce 48x48dp minimum touch target
  static Widget minTapTarget({
    required Widget child,
    VoidCallback? onTap,
    String? semanticLabel,
  }) {
    return Semantics(
      label: semanticLabel,
      button: true,
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minWidth: minTouchTargetSize,
          minHeight: minTouchTargetSize,
        ),
        child: Center(
          child: child,
        ),
      ),
    );
  }

  /// Announce message to accessibility screen readers (TalkBack / VoiceOver)
  static void announce(BuildContext context, String message) {
    SemanticsService.announce(message, Directionality.of(context));
  }
}
`,
  });

  // 6. WCAG AA Contrast Ratio Checker
  files.push({
    path: 'lib/core/accessibility/contrast_checker.dart',
    contents: `import 'dart:math';
import 'package:flutter/material.dart';

class ContrastChecker {
  ContrastChecker._();

  /// Computes the relative luminance of a color according to WCAG 2.1 specs
  static double getRelativeLuminance(Color color) {
    double transform(double c) {
      c = c / 255.0;
      return c <= 0.03928 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4).toDouble();
    }

    final r = transform(color.r * 255);
    final g = transform(color.g * 255);
    final b = transform(color.b * 255);

    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  /// Calculates contrast ratio between two colors (e.g. text color vs background)
  static double calculateContrastRatio(Color foreground, Color background) {
    final l1 = getRelativeLuminance(foreground);
    final l2 = getRelativeLuminance(background);
    final lighter = max(l1, l2);
    final darker = min(l1, l2);
    return (lighter + 0.05) / (darker + 0.05);
  }

  /// Verifies WCAG AA standard (at least 4.5:1 for normal text, 3.0:1 for large text)
  static bool meetsWcagAa(Color foreground, Color background, {bool isLargeText = false}) {
    final ratio = calculateContrastRatio(foreground, background);
    return ratio >= (isLargeText ? 3.0 : 4.5);
  }
}
`,
  });

  // 7. Text Scale Test
  files.push({
    path: 'test/accessibility/text_scale_test.dart',
    contents: `import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Screen renders correctly under 2.0x accessibility text scale', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(2.0)),
          child: const Scaffold(
            body: Center(
              child: Text('Accessibility Scale Test', overflow: TextOverflow.ellipsis),
            ),
          ),
        ),
      ),
    );

    expect(find.text('Accessibility Scale Test'), findsOneWidget);
  });
}
`,
  });

  return files;
}
