import type { GenContext } from '../types';

export function templateAppDart(ctx: GenContext): string {
  const isGetX = ctx.stateManager === 'getx';
  const appWidget = isGetX ? 'GetMaterialApp' : 'MaterialApp';
  const getImport = isGetX ? "import 'package:get/get.dart';\n" : '';

  const hasScreens = ctx.screens && ctx.screens.length > 0;
  const routesImport = hasScreens ? "import 'screens/app_routes.dart';" : "import 'config/app_routes.dart';";

  const themeModeDart =
    ctx.themeMode === 'amoled' || ctx.themeMode === 'dark'
      ? 'ThemeMode.dark'
      : ctx.themeMode === 'light' || ctx.themeMode === 'sepia'
      ? 'ThemeMode.light'
      : 'ThemeMode.system';

  return `import 'package:flutter/material.dart';
${getImport}import 'core/theme/app_theme.dart';
${routesImport}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ${appWidget}(
      title: '${ctx.projectName.replace(/'/g, "\\'")}',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ${themeModeDart},
      initialRoute: AppRoutes.initialRoute,
      routes: AppRoutes.routes,
    );
  }
}
`;
}
