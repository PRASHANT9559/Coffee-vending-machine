import type { GenContext } from '../types';

export function templateWidgetTest(ctx: GenContext): string {
  let appInit = 'const MyApp()';
  const extraImports = [];

  if (ctx.stateManager === 'riverpod') {
    extraImports.push("import 'package:flutter_riverpod/flutter_riverpod.dart';");
    appInit = 'const ProviderScope(child: MyApp())';
  }

  return `import 'package:flutter_test/flutter_test.dart';
${extraImports.join('\n')}
import 'package:${ctx.packageName}/app.dart';

void main() {
  testWidgets('App smoke test builds without exception', (WidgetTester tester) async {
    await tester.pumpWidget(${appInit});
    expect(find.byType(MyApp), findsOneWidget);
  });
}
`;
}
