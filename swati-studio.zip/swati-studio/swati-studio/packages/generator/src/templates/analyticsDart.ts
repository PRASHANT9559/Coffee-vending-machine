import type { GenContext, GeneratedFile } from '../types';

export function templateAnalyticsFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Analytics Service
  files.push({
    path: 'lib/core/analytics/analytics_service.dart',
    contents: `import 'package:flutter/foundation.dart';

class AnalyticsService {
  static bool loggingEnabled = !kReleaseMode;

  static Future<void> logEvent(String name, {Map<String, dynamic>? parameters}) async {
    if (loggingEnabled) {
      debugPrint('[Analytics Event] \$name: \$parameters');
    }
    // Scaffolded FirebaseAnalytics / Mixpanel call
  }

  static Future<void> setCurrentScreen(String screenName) async {
    if (loggingEnabled) {
      debugPrint('[Analytics Screen] \$screenName');
    }
  }

  static Future<void> setUserId(String? userId) async {
    if (loggingEnabled) {
      debugPrint('[Analytics User] \$userId');
    }
  }

  static Future<void> setUserProperty({required String name, required String value}) async {
    if (loggingEnabled) {
      debugPrint('[Analytics UserProperty] \$name = \$value');
    }
  }
}
`,
  });

  // 2. Crash Reporting Service
  files.push({
    path: 'lib/core/analytics/crash_reporting.dart',
    contents: `import 'package:flutter/foundation.dart';

class CrashReportingService {
  static Future<void> initialize() async {
    FlutterError.onError = (FlutterErrorDetails details) {
      recordFlutterError(details);
    };

    PlatformDispatcher.instance.onError = (error, stack) {
      recordError(error, stack);
      return true;
    };
  }

  static void recordFlutterError(FlutterErrorDetails details) {
    debugPrint('[CrashReporting] Flutter error: \${details.exceptionAsString()}');
    // Scaffolded FirebaseCrashlytics.instance.recordFlutterFatalError(details);
  }

  static void recordError(dynamic exception, StackTrace? stack, {String? reason}) {
    debugPrint('[CrashReporting] Unhandled exception: \$exception');
    // Scaffolded FirebaseCrashlytics.instance.recordError(exception, stack, reason: reason);
  }

  static void log(String message) {
    debugPrint('[CrashLog] \$message');
  }
}
`,
  });

  // 3. Performance Monitor
  files.push({
    path: 'lib/core/analytics/performance_monitor.dart',
    contents: `import 'package:flutter/foundation.dart';

class PerformanceMonitor {
  static final Map<String, Stopwatch> _activeTraces = {};

  static void startTrace(String traceName) {
    final sw = Stopwatch()..start();
    _activeTraces[traceName] = sw;
  }

  static void stopTrace(String traceName) {
    final sw = _activeTraces.remove(traceName);
    if (sw != null) {
      sw.stop();
      if (!kReleaseMode) {
        debugPrint('[Performance Trace] \$traceName took \${sw.elapsedMilliseconds} ms');
      }
    }
  }
}
`,
  });

  // 4. Analytics Navigator Observer
  files.push({
    path: 'lib/core/analytics/analytics_navigator_observer.dart',
    contents: `import 'package:flutter/material.dart';
import 'analytics_service.dart';

class AnalyticsNavigatorObserver extends NavigatorObserver {
  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    if (route.settings.name != null) {
      AnalyticsService.setCurrentScreen(route.settings.name!);
    }
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    if (newRoute?.settings.name != null) {
      AnalyticsService.setCurrentScreen(newRoute!.settings.name!);
    }
  }
}
`,
  });

  return files;
}
