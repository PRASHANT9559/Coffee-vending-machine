import type { GenContext } from '../types';

export function templateAppRoutes(ctx: GenContext): string {
  const items = ctx.navigationItems.length > 0 ? ctx.navigationItems : [
    { id: '1', name: 'Home', title: 'Home', icon: 'Home', route: '/home' },
    { id: '2', name: 'Search', title: 'Search', icon: 'Search', route: '/search' },
    { id: '3', name: 'Profile', title: 'Profile', icon: 'User', route: '/profile' },
  ];

  const hasAuth = ctx.features.includes('authentication') || (ctx.authScreens && ctx.authScreens.length > 0);

  const navImports = items
    .map((item) => {
      const slug = item.name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
      return `import '../features/${slug}/${slug}_screen.dart';`;
    })
    .join('\n');

  const authImports = hasAuth
    ? `import '../features/auth/screens/login_screen.dart';
import '../features/auth/screens/register_screen.dart';
import '../features/auth/screens/forgot_password_screen.dart';`
    : '';

  const authRoutes = hasAuth
    ? `    '/login': (context) => const LoginScreen(),
    '/register': (context) => const RegisterScreen(),
    '/forgot-password': (context) => const ForgotPasswordScreen(),`
    : '';

  return `import 'package:flutter/material.dart';
import '../core/widgets/app_navigation.dart';
import '../features/onboarding/screens/onboarding_screen.dart';
import '../features/monetization/screens/paywall_screen.dart';
import '../features/products/screens/product_list_screen.dart';
import '../features/products/screens/product_form_screen.dart';
import '../features/legal/screens/privacy_policy_screen.dart';
import '../features/legal/screens/terms_screen.dart';
import '../features/legal/screens/delete_account_screen.dart';
${navImports}
${authImports}

class AppRoutes {
  static const String initialRoute = '/';

  static Map<String, WidgetBuilder> get routes => {
    '/': (context) => const AppNavigationHost(),
    '/onboarding': (context) => const OnboardingScreen(),
    '/paywall': (context) => const PaywallScreen(),
    '/products': (context) => const ProductListScreen(),
    '/products/create': (context) => const ProductFormScreen(),
    '/legal/privacy-policy': (context) => const PrivacyPolicyScreen(),
    '/legal/terms': (context) => const TermsScreen(),
    '/legal/delete-account': (context) => const DeleteAccountScreen(),
${items
  .map((item) => {
    const className = toPascalCase(item.name) + 'Screen';
    return `    '${item.route}': (context) => const ${className}(),`;
  })
  .join('\n')}
${authRoutes}
  };
}
`;
}

function toPascalCase(str: string): string {
  return str
    .replace(/[^a-zA-Z0-9]+/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join('');
}
