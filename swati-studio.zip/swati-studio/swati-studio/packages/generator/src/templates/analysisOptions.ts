export function templateAnalysisOptions(): string {
  return `include: package:flutter_lints/flutter.yaml

linter:
  rules:
    prefer_const_constructors: true
    prefer_const_declarations: true
    avoid_print: true
    use_key_in_widget_constructors: true
    always_declare_return_types: true
`;
}
