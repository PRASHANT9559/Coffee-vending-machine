import type { GenContext, GeneratedFile } from '../types';

export function templateCicdFiles(ctx: GenContext): GeneratedFile[] {
  const platform = ctx.cicdPlatform ?? 'github_actions';
  if (platform === 'none') return [];

  const files: GeneratedFile[] = [];

  if (platform === 'github_actions') {
    files.push({
      path: '.github/workflows/ci.yml',
      contents: `name: Flutter CI Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    name: Code Analysis & Tests
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'

      - name: Setup Flutter SDK
        uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.27.x'
          channel: 'stable'
          cache: true

      - name: Install Dependencies
        run: flutter pub get

      - name: Check Code Formatting
        run: dart format --output=none --set-exit-if-changed .

      - name: Analyze Dart Code
        run: flutter analyze --no-fatal-infos

      - name: Run Unit & Widget Tests
        run: flutter test --coverage
`,
    });

    files.push({
      path: '.github/workflows/build-android.yml',
      contents: `name: Build Android Artifacts

on:
  push:
    tags:
      - 'v*'

jobs:
  build:
    name: Build Release APK & AAB
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'

      - name: Setup Flutter
        uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.27.x'
          channel: 'stable'

      - name: Install Dependencies
        run: flutter pub get

      - name: Build APK
        run: flutter build apk --release

      - name: Build App Bundle
        run: flutter build appbundle --release

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: build/app/outputs/flutter-apk/app-release.apk

      - name: Upload AAB
        uses: actions/upload-artifact@v4
        with:
          name: app-release-aab
          path: build/app/outputs/bundle/release/app-release.aab
`,
    });
  } else if (platform === 'gitlab_ci') {
    files.push({
      path: '.gitlab-ci.yml',
      contents: `image: ghcr.io/cirruslabs/flutter:3.27.0

stages:
  - analyze
  - test
  - build

before_script:
  - flutter pub get

lint:
  stage: analyze
  script:
    - dart format --set-exit-if-changed .
    - flutter analyze

test:
  stage: test
  script:
    - flutter test --coverage

build_apk:
  stage: build
  script:
    - flutter build apk --release
  artifacts:
    paths:
      - build/app/outputs/flutter-apk/app-release.apk
    expire_in: 1 week
`,
    });
  }

  return files;
}
