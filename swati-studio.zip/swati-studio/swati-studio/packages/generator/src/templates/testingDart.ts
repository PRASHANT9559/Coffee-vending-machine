import type { GenContext, GeneratedFile } from '../types';

export function templateTestingFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Test Helpers & PumpApp
  files.push({
    path: 'test/helpers/test_helpers.dart',
    contents: `import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

extension WidgetTesterX on WidgetTester {
  Future<void> pumpApp(Widget widget) async {
    await pumpWidget(
      MaterialApp(
        home: Scaffold(body: widget),
      ),
    );
    await pumpAndSettle();
  }
}
`,
  });

  // 2. Fake Data Factory
  files.push({
    path: 'test/helpers/fake_data.dart',
    contents: `class FakeDataFactory {
  static Map<String, dynamic> makeUserJson({String? id, String? email}) {
    return {
      'id': id ?? 'usr_test_123',
      'email': email ?? 'test@example.com',
      'display_name': 'Test User',
      'role': 'user',
      'created_at': DateTime.now().toIso8601String(),
    };
  }
}
`,
  });

  // 3. User Model Unit Test
  files.push({
    path: 'test/unit/models/user_model_test.dart',
    contents: `import 'package:flutter_test/flutter_test.dart';
import 'package:${ctx.packageName}/features/auth/models/user_model.dart';
import '../../helpers/fake_data.dart';

void main() {
  group('UserModel Entity Test', () {
    test('instantiates and parses JSON successfully', () {
      final json = FakeDataFactory.makeUserJson();
      final user = UserModel.fromJson(json);

      expect(user.id, equals(json['id']));
      expect(user.email, equals(json['email']));
      expect(user.role, equals('user'));
    });

    test('serializes to JSON correctly', () {
      final user = UserModel(
        id: '123',
        email: 'dev@swati.studio',
        createdAt: DateTime(2026, 11, 3),
      );
      final json = user.toJson();

      expect(json['id'], equals('123'));
      expect(json['email'], equals('dev@swati.studio'));
    });
  });
}
`,
  });

  // 4. App Button Widget Test
  files.push({
    path: 'test/widget/widgets/app_button_test.dart',
    contents: `import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:${ctx.packageName}/core/widgets/app_button.dart';
import '../../helpers/test_helpers.dart';

void main() {
  group('AppButton Widget Tests', () {
    testWidgets('renders label and handles tap event', (tester) async {
      bool tapped = false;

      await tester.pumpApp(
        AppButton(
          label: 'Submit Order',
          onPressed: () => tapped = true,
        ),
      );

      expect(find.text('Submit Order'), findsOneWidget);
      await tester.tap(find.text('Submit Order'));
      await tester.pumpAndSettle();

      expect(tapped, isTrue);
    });

    testWidgets('shows loading indicator when isLoading is true', (tester) async {
      await tester.pumpApp(
        AppButton(
          label: 'Submit',
          isLoading: true,
          onPressed: () {},
        ),
      );

      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });
  });
}
`,
  });

  // 5. Code Coverage Configuration YAML
  files.push({
    path: 'coverage_config.yaml',
    contents: `exclude:
  - "**/*.g.dart"
  - "**/*.freezed.dart"
  - "lib/generated/**"
  - "test/**"
targets:
  line_coverage: 80
`,
  });

  return files;
}
