import type { GenContext, GeneratedFile } from '../types';

export function templateEnvironmentFiles(ctx: GenContext): GeneratedFile[] {
  if (ctx.environmentFlavor === 'single') return [];

  const files: GeneratedFile[] = [];

  // App Config & Environment Enum
  files.push({
    path: 'lib/config/app_config.dart',
    contents: `enum Environment { dev, staging, prod }

class AppConfig {
  final Environment environment;
  final String appName;
  final String apiBaseUrl;
  final bool enableLogging;
  final bool isDebugBanner;

  static late AppConfig instance;

  AppConfig({
    required this.environment,
    required this.appName,
    required this.apiBaseUrl,
    this.enableLogging = true,
    this.isDebugBanner = true,
  });

  static bool get isDev => instance.environment == Environment.dev;
  static bool get isStaging => instance.environment == Environment.staging;
  static bool get isProd => instance.environment == Environment.prod;
}
`,
  });

  // main_dev.dart
  files.push({
    path: 'lib/main_dev.dart',
    contents: `import 'package:flutter/material.dart';
import 'app.dart';
import 'config/app_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConfig.instance = AppConfig(
    environment: Environment.dev,
    appName: '${ctx.projectName.replace(/'/g, "\\'")} (Dev)',
    apiBaseUrl: 'https://dev-api.example.com/v1',
    enableLogging: true,
    isDebugBanner: true,
  );

  runApp(const MyApp());
}
`,
  });

  // main_staging.dart
  files.push({
    path: 'lib/main_staging.dart',
    contents: `import 'package:flutter/material.dart';
import 'app.dart';
import 'config/app_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConfig.instance = AppConfig(
    environment: Environment.staging,
    appName: '${ctx.projectName.replace(/'/g, "\\'")} (Staging)',
    apiBaseUrl: 'https://staging-api.example.com/v1',
    enableLogging: true,
    isDebugBanner: false,
  );

  runApp(const MyApp());
}
`,
  });

  // main_prod.dart
  files.push({
    path: 'lib/main_prod.dart',
    contents: `import 'package:flutter/material.dart';
import 'app.dart';
import 'config/app_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConfig.instance = AppConfig(
    environment: Environment.prod,
    appName: '${ctx.projectName.replace(/'/g, "\\'")}',
    apiBaseUrl: 'https://api.example.com/v1',
    enableLogging: false,
    isDebugBanner: false,
  );

  runApp(const MyApp());
}
`,
  });

  // .env files
  files.push({
    path: 'assets/env/dev.env',
    contents: `ENVIRONMENT=development
API_BASE_URL=https://dev-api.example.com/v1
APP_NAME="${ctx.projectName} Dev"
ENABLE_DEBUG=true
`,
  });

  files.push({
    path: 'assets/env/staging.env',
    contents: `ENVIRONMENT=staging
API_BASE_URL=https://staging-api.example.com/v1
APP_NAME="${ctx.projectName} Staging"
ENABLE_DEBUG=false
`,
  });

  files.push({
    path: 'assets/env/prod.env',
    contents: `ENVIRONMENT=production
API_BASE_URL=https://api.example.com/v1
APP_NAME="${ctx.projectName}"
ENABLE_DEBUG=false
`,
  });

  return files;
}
