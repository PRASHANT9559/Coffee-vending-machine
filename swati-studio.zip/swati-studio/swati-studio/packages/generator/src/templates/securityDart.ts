import type { GenContext, GeneratedFile } from '../types';

export function templateSecurityFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Secure Storage Wrapper
  files.push({
    path: 'lib/core/security/secure_storage.dart',
    contents: `import 'dart:convert';

/// Enterprise Encrypted Key-Value Storage
/// Wraps keychain on iOS and EncryptedSharedPreferences on Android
class SecureStorageService {
  final Map<String, String> _memoryCache = {};

  Future<void> write({required String key, required String value}) async {
    _memoryCache[key] = value;
    // Scaffolded flutter_secure_storage write call
  }

  Future<String?> read({required String key}) async {
    return _memoryCache[key];
  }

  Future<void> delete({required String key}) async {
    _memoryCache.remove(key);
  }

  Future<void> deleteAll() async {
    _memoryCache.clear();
  }

  Future<void> writeJson({required String key, required Map<String, dynamic> json}) async {
    await write(key: key, value: jsonEncode(json));
  }

  Future<Map<String, dynamic>?> readJson({required String key}) async {
    final raw = await read(key: key);
    if (raw == null) return null;
    return jsonDecode(raw) as Map<String, dynamic>;
  }
}
`,
  });

  // 2. SSL Certificate Pinning Helper
  files.push({
    path: 'lib/core/security/ssl_pinning.dart',
    contents: `import 'dart:io';

class SslPinningConfig {
  static const List<String> allowedSha256Fingerprints = [
    // Add public key SHA-256 fingerprints here for MITM prevention
  ];

  static HttpClient createPinnedHttpClient() {
    final client = HttpClient();
    client.badCertificateCallback = (X509Certificate cert, String host, int port) {
      if (allowedSha256Fingerprints.isEmpty) return true; // dev fallback
      return cert.sha256.map((b) => b.toRadixString(16).padLeft(2, '0')).join(':') ==
          allowedSha256Fingerprints.first;
    };
    return client;
  }
}
`,
  });

  // 3. Root / Jailbreak Detection Helper
  files.push({
    path: 'lib/core/security/root_detection.dart',
    contents: `import 'dart:io';

class RootDetectionService {
  static Future<bool> isDeviceCompromised() async {
    try {
      if (Platform.isAndroid) {
        final paths = [
          '/system/app/Superuser.apk',
          '/sbin/su',
          '/system/bin/su',
          '/system/xbin/su',
          '/data/local/xbin/su',
          '/data/local/bin/su',
          '/system/sd/xbin/su',
        ];
        for (final path in paths) {
          if (File(path).existsSync()) return true;
        }
      } else if (Platform.isIOS) {
        final paths = [
          '/Applications/Cydia.app',
          '/Library/MobileSubstrate/MobileSubstrate.dylib',
          '/bin/bash',
          '/usr/sbin/sshd',
          '/etc/apt',
        ];
        for (final path in paths) {
          if (File(path).existsSync()) return true;
        }
      }
    } catch (_) {
      // Access denied or sandbox restriction
    }
    return false;
  }
}
`,
  });

  // 4. Biometric App Lock Screen
  files.push({
    path: 'lib/core/security/app_lock.dart',
    contents: `import 'package:flutter/material.dart';

class AppLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;

  const AppLockScreen({super.key, required this.onUnlocked});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  bool _isAuthenticating = false;

  void _authenticate() async {
    setState(() => _isAuthenticating = true);
    // Scaffolded local_auth biometric prompt
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    widget.onUnlocked();
  }

  @override
  void initState() {
    super.initState();
    _authenticate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.lock_rounded, size: 72, color: Colors.blue),
            const SizedBox(height: 24),
            const Text(
              '${ctx.projectName.replace(/'/g, "\\'")} is Locked',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Unlock with Biometrics or Passcode',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 32),
            FilledButton.icon(
              onPressed: _isAuthenticating ? null : _authenticate,
              icon: const Icon(Icons.fingerprint),
              label: const Text('Unlock App'),
            ),
          ],
        ),
      ),
    );
  }
}
`,
  });

  // 5. Session Timeout Manager
  files.push({
    path: 'lib/core/security/session_manager.dart',
    contents: `import 'dart:async';
import 'package:flutter/foundation.dart';

class SessionManager extends ChangeNotifier {
  static const Duration defaultTimeout = Duration(minutes: 15);
  Timer? _timer;

  void userActivityDetected() {
    _timer?.cancel();
    _timer = Timer(defaultTimeout, _handleSessionExpired);
  }

  void _handleSessionExpired() {
    notifyListeners();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
`,
  });

  // 6. Legal Privacy Policy Document
  files.push({
    path: 'docs/legal/PRIVACY_POLICY.md',
    contents: `# Privacy Policy for ${ctx.projectName}

Last updated: ${new Date().toISOString().split('T')[0]}

This Privacy Policy explains how ${ctx.organization} ("we", "us", or "our") collects, uses, and discloses information about you when you use ${ctx.projectName}.

## 1. Information We Collect
We collect information you provide directly to us (such as account credentials, contact information, and preferences) and automatically generated usage data.

## 2. How We Use Your Information
- To deliver, maintain, and enhance the application features.
- To detect, prevent, and address security incidents or fraudulent activity.
- To process in-app transactions and verify user sessions.

## 3. Data Protection & GDPR Compliance
Users located within the European Economic Area (EEA) have the right to request access to, rectification of, or erasure of their personal data.

## 4. Contact Us
For questions regarding this privacy policy, please contact us at support@${ctx.organization.replace('com.', '')}.
`,
  });

  // 7. Legal Terms of Service Document
  files.push({
    path: 'docs/legal/TERMS_OF_SERVICE.md',
    contents: `# Terms of Service for ${ctx.projectName}

Last updated: ${new Date().toISOString().split('T')[0]}

By downloading or using ${ctx.projectName}, you agree to be bound by these Terms of Service.

## 1. Acceptable Use
You agree not to misuse the application, reverse engineer backend endpoints, or attempt unauthorized access to other user accounts.

## 2. Intellectual Property
All design tokens, user interface components, and software logic generated by ${ctx.projectName} are protected under the ${ctx.license} license.

## 3. Limitation of Liability
In no event shall ${ctx.organization} be liable for any indirect, incidental, or consequential damages arising from the use of this application.
`,
  });

  return files;
}
