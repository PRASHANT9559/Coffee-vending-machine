import type { GenContext, GeneratedFile } from '../types';

export function templateMonetizationFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Product Model
  files.push({
    path: 'lib/features/monetization/models/product_model.dart',
    contents: `enum ProductType { subscription, nonConsumable, consumable }

class ProductItem {
  final String id;
  final String title;
  final String description;
  final String priceString;
  final double price;
  final ProductType type;
  final String? period;

  const ProductItem({
    required this.id,
    required this.title,
    required this.description,
    required this.priceString,
    required this.price,
    this.type = ProductType.subscription,
    this.period,
  });
}
`,
  });

  // 2. In-App Purchase Service
  files.push({
    path: 'lib/features/monetization/services/purchase_service.dart',
    contents: `import 'package:flutter/foundation.dart';
import '../models/product_model.dart';

class PurchaseService extends ChangeNotifier {
  bool _isProUser = false;
  bool _isLoading = false;

  bool get isProUser => _isProUser;
  bool get isLoading => _isLoading;

  final List<ProductItem> availableProducts = const [
    ProductItem(
      id: 'pro_monthly',
      title: 'Monthly Pro',
      description: 'Full access to all enterprise features, billed monthly',
      priceString: '\$4.99/mo',
      price: 4.99,
      type: ProductType.subscription,
      period: 'month',
    ),
    ProductItem(
      id: 'pro_annual',
      title: 'Annual Pro',
      description: 'Save 35% with annual billing + priority support',
      priceString: '\$39.99/yr',
      price: 39.99,
      type: ProductType.subscription,
      period: 'year',
    ),
    ProductItem(
      id: 'lifetime_unlock',
      title: 'Lifetime Pass',
      description: 'One-time purchase, forever access & all future updates',
      priceString: '\$99.00',
      price: 99.0,
      type: ProductType.nonConsumable,
    ),
  ];

  Future<bool> purchaseProduct(String productId) async {
    _isLoading = true;
    notifyListeners();

    // Scaffolded in_app_purchase integration call
    await Future.delayed(const Duration(milliseconds: 800));
    _isProUser = true;
    _isLoading = false;
    notifyListeners();
    return true;
  }

  Future<void> restorePurchases() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 600));
    _isLoading = false;
    notifyListeners();
  }
}
`,
  });

  // 3. Ad Service (Banner, Interstitial, Rewarded)
  files.push({
    path: 'lib/features/monetization/services/ad_service.dart',
    contents: `class AdService {
  static bool adsEnabled = true;

  static void showInterstitialAd({Function? onDismissed}) {
    // Scaffolded Google Mobile Ads interstitial display
    onDismissed?.call();
  }

  static void showRewardedAd({required Function onRewardEarned}) {
    // Scaffolded Rewarded Video Ad
    onRewardEarned();
  }
}
`,
  });

  // 4. Premium Badge Widget
  files.push({
    path: 'lib/features/monetization/widgets/premium_badge.dart',
    contents: `import 'package:flutter/material.dart';

class PremiumBadge extends StatelessWidget {
  final String label;

  const PremiumBadge({super.key, this.label = 'PRO'});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFFB703), Color(0xFFFB8500)],
        ),
        borderRadius: BorderRadius.circular(6),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFB8500).withOpacity(0.3),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.black,
          fontSize: 10,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
`,
  });

  // 5. Banner Ad Placeholder Widget
  files.push({
    path: 'lib/features/monetization/widgets/banner_ad_widget.dart',
    contents: `import 'package:flutter/material.dart';

class BannerAdWidget extends StatelessWidget {
  const BannerAdWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 54,
      color: Theme.of(context).cardColor,
      alignment: Alignment.center,
      child: Text(
        'Ad Banner (320x50)',
        style: TextStyle(
          color: Colors.grey.withOpacity(0.6),
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
`,
  });

  // 6. Paywall Screen
  files.push({
    path: 'lib/features/monetization/screens/paywall_screen.dart',
    contents: `import 'package:flutter/material.dart';
import '../widgets/premium_badge.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});

  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> {
  int _selectedPlanIndex = 1; // Default to Annual (Best Value)

  final List<Map<String, dynamic>> _plans = [
    {
      'id': 'monthly',
      'title': 'Monthly',
      'price': '\$4.99 / month',
      'tag': null,
    },
    {
      'id': 'annual',
      'title': 'Annual Plan',
      'price': '\$39.99 / year (\$3.33/mo)',
      'tag': 'BEST VALUE',
    },
    {
      'id': 'lifetime',
      'title': 'Lifetime Pass',
      'price': '\$99.00 one-time',
      'tag': 'FOREVER',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Purchases restored successfully.')),
              );
            },
            child: const Text('Restore'),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const PremiumBadge(label: 'ENTERPRISE PRO'),
              const SizedBox(height: 16),
              Text(
                'Unlock All Features in ${ctx.projectName.replace(/'/g, "\\'")}',
                textAlign: TextAlign.center,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Experience unlimited sync, priority cloud storage, advanced analytics and remove all advertisements.',
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.textTheme.bodyMedium?.color?.withOpacity(0.7)),
              ),
              const SizedBox(height: 32),
              // Plans Selector
              ...List.generate(_plans.length, (index) {
                final plan = _plans[index];
                final isSelected = index == _selectedPlanIndex;
                return GestureDetector(
                  onTap: () => setState(() => _selectedPlanIndex = index),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isSelected ? theme.colorScheme.primary.withOpacity(0.08) : theme.cardColor,
                      border: Border.override(
                        border: Border.all(
                          color: isSelected ? theme.colorScheme.primary : theme.dividerColor,
                          width: isSelected ? 2 : 1,
                        ),
                      ).border,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  plan['title'],
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                ),
                                if (plan['tag'] != null) ...[
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: theme.colorScheme.primary,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      plan['tag'],
                                      style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(plan['price'], style: TextStyle(color: theme.textTheme.bodySmall?.color)),
                          ],
                        ),
                        Icon(
                          isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                          color: isSelected ? theme.colorScheme.primary : Colors.grey,
                        ),
                      ],
                    ),
                  ),
                );
              }),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Thank you! Welcome to Pro.')),
                    );
                    Navigator.of(context).pop();
                  },
                  child: const Text('Upgrade Now', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Cancel anytime. Terms of Use & Privacy Policy apply.',
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
`,
  });

  return files;
}
