import type { GenContext, GeneratedFile } from '../types';

export function templateDesignTokenExports(ctx: GenContext): GeneratedFile[] {
  const hex = ctx.hexColor;
  const radius = ctx.borderRadius;
  const font = ctx.font;

  const files: GeneratedFile[] = [];

  // 1. Figma Tokens JSON
  const figmaTokens = {
    global: {
      color: {
        primary: { value: hex, type: 'color' },
        background: {
          value: ctx.themeMode === 'amoled' ? '#000000' : ctx.themeMode === 'dark' ? '#0f172a' : '#ffffff',
          type: 'color',
        },
        surface: {
          value: ctx.themeMode === 'amoled' ? '#0c0c0c' : ctx.themeMode === 'dark' ? '#1e293b' : '#f8fafc',
          type: 'color',
        },
      },
      borderRadius: {
        base: { value: `${radius}px`, type: 'borderRadius' },
        large: { value: `${Math.round(radius * 1.5)}px`, type: 'borderRadius' },
      },
      fontFamilies: {
        primary: { value: font, type: 'fontFamilies' },
      },
    },
  };

  files.push({
    path: 'tokens/figma-tokens.json',
    contents: JSON.stringify(figmaTokens, null, 2),
  });

  // 2. CSS Custom Properties
  const cssVars = `:root {
  --app-primary: ${hex};
  --app-font-family: '${font}', sans-serif;
  --app-border-radius: ${radius}px;
  --app-bg: ${ctx.themeMode === 'amoled' ? '#000000' : ctx.themeMode === 'dark' ? '#0f172a' : '#ffffff'};
  --app-surface: ${ctx.themeMode === 'amoled' ? '#0c0c0c' : ctx.themeMode === 'dark' ? '#1e293b' : '#f8fafc'};
}
`;
  files.push({
    path: 'tokens/css-variables.css',
    contents: cssVars,
  });

  // 3. Tailwind Theme Extension
  const tailwindConfig = `/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: '${hex}',
        appBg: '${ctx.themeMode === 'amoled' ? '#000000' : ctx.themeMode === 'dark' ? '#0f172a' : '#ffffff'}',
        appSurface: '${ctx.themeMode === 'amoled' ? '#0c0c0c' : ctx.themeMode === 'dark' ? '#1e293b' : '#f8fafc'}',
      },
      borderRadius: {
        app: '${radius}px',
      },
      fontFamily: {
        app: ['${font}', 'sans-serif'],
      },
    },
  },
};
`;
  files.push({
    path: 'tokens/tailwind-theme.js',
    contents: tailwindConfig,
  });

  // 4. Style Dictionary Format
  const styleDictionary = {
    color: {
      brand: {
        primary: { value: hex },
      },
      surface: {
        background: {
          value: ctx.themeMode === 'amoled' ? '#000000' : ctx.themeMode === 'dark' ? '#0f172a' : '#ffffff',
        },
        card: {
          value: ctx.themeMode === 'amoled' ? '#0c0c0c' : ctx.themeMode === 'dark' ? '#1e293b' : '#f8fafc',
        },
      },
    },
    size: {
      radius: {
        base: { value: `${radius}px` },
      },
    },
    asset: {
      font: {
        primary: { value: font },
      },
    },
  };

  files.push({
    path: 'tokens/style-dictionary.json',
    contents: JSON.stringify(styleDictionary, null, 2),
  });

  return files;
}
