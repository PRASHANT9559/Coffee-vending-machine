import type { GenContext } from '../types';
import { themeOptions } from '@swati/schema';

export function templateDesignTokens(ctx: GenContext): string {
  const isAmoled = ctx.themeMode === 'amoled';
  const isSepia = ctx.themeMode === 'sepia';
  const isNeoBrutalist = ctx.uiStyle === 'neo_brutalism' || ctx.aestheticCombo === 'brutal_pop';
  const isGlass = ctx.uiStyle.includes('glass') || ctx.aestheticCombo.includes('glass');
  const isClay = ctx.uiStyle === 'claymorphism' || ctx.aestheticCombo === 'clay_glass';

  return `import 'package:flutter/material.dart';

/// Design tokens extension safe across Flutter 3.24 through Flutter 3.27+
/// Generated with themeMode: '${ctx.themeMode}', uiStyle: '${ctx.uiStyle}', aestheticCombo: '${ctx.aestheticCombo}'
class DesignTokens extends ThemeExtension<DesignTokens> {
  final double borderRadius;
  final Color primaryColor;
  final String fontFamily;
  final String uiStyle;
  final String themeMode;
  final bool isAmoled;
  final bool isSepia;
  final bool isNeoBrutalist;
  final bool isGlass;
  final bool isClay;

  const DesignTokens({
    required this.borderRadius,
    required this.primaryColor,
    required this.fontFamily,
    this.uiStyle = '${ctx.uiStyle}',
    this.themeMode = '${ctx.themeMode}',
    this.isAmoled = ${isAmoled},
    this.isSepia = ${isSepia},
    this.isNeoBrutalist = ${isNeoBrutalist},
    this.isGlass = ${isGlass},
    this.isClay = ${isClay},
  });

  @override
  ThemeExtension<DesignTokens> copyWith({
    double? borderRadius,
    Color? primaryColor,
    String? fontFamily,
    String? uiStyle,
    String? themeMode,
    bool? isAmoled,
    bool? isSepia,
    bool? isNeoBrutalist,
    bool? isGlass,
    bool? isClay,
  }) {
    return DesignTokens(
      borderRadius: borderRadius ?? this.borderRadius,
      primaryColor: primaryColor ?? this.primaryColor,
      fontFamily: fontFamily ?? this.fontFamily,
      uiStyle: uiStyle ?? this.uiStyle,
      themeMode: themeMode ?? this.themeMode,
      isAmoled: isAmoled ?? this.isAmoled,
      isSepia: isSepia ?? this.isSepia,
      isNeoBrutalist: isNeoBrutalist ?? this.isNeoBrutalist,
      isGlass: isGlass ?? this.isGlass,
      isClay: isClay ?? this.isClay,
    );
  }

  @override
  ThemeExtension<DesignTokens> lerp(ThemeExtension<DesignTokens>? other, double t) {
    if (other is! DesignTokens) return this;
    return DesignTokens(
      borderRadius: lerpDouble(borderRadius, other.borderRadius, t) ?? borderRadius,
      primaryColor: Color.lerp(primaryColor, other.primaryColor, t) ?? primaryColor,
      fontFamily: other.fontFamily,
      uiStyle: other.uiStyle,
      themeMode: other.themeMode,
      isAmoled: other.isAmoled,
      isSepia: other.isSepia,
      isNeoBrutalist: other.isNeoBrutalist,
      isGlass: other.isGlass,
      isClay: other.isClay,
    );
  }

  static double? lerpDouble(double a, double b, double t) {
    return a + (b - a) * t;
  }
}
`;
}

function hexToDartColor(hexStr?: string, defaultHex: string = '#6366F1'): string {
  const clean = (hexStr || defaultHex).replace('#', '').toUpperCase();
  return `Color(0xFF${clean})`;
}

export function templateAppTheme(ctx: GenContext): string {
  const hex = ctx.hexColor.replace('#', '');
  const primaryHex = `0xFF${hex.toUpperCase()}`;
  const isAmoled = ctx.themeMode === 'amoled';
  const isSepia = ctx.themeMode === 'sepia';
  const isNeoBrutalist = ctx.uiStyle === 'neo_brutalism' || ctx.aestheticCombo === 'brutal_pop';
  const isClay = ctx.uiStyle === 'claymorphism' || ctx.aestheticCombo === 'clay_glass';

  // Find if matching one of the 20 full theme palettes
  const palette = themeOptions.find(
    (t) => t.name.toLowerCase().replace(/[^a-z0-9]+/g, '_') === ctx.themeColor,
  );

  const standardLightBg = palette ? hexToDartColor(palette.light.background, '#F8FAFC') : 'const Color(0xFFF8FAFC)';
  const standardLightCard = palette ? hexToDartColor(palette.light.card, '#FFFFFF') : 'const Color(0xFFFFFFFF)';

  const standardDarkBg = palette ? hexToDartColor(palette.dark.background, '#0F172A') : 'const Color(0xFF0F172A)';
  const standardDarkCard = palette ? hexToDartColor(palette.dark.card, '#1E293B') : 'const Color(0xFF1E293B)';

  // AMOLED True Black (#000000)
  const amoledBg = 'const Color(0xFF000000)';
  const amoledCard = 'const Color(0xFF0D0D0D)';

  // Sepia warm palette (#FBF0D9 / #F4E5C3)
  const sepiaBg = 'const Color(0xFFFBF0D9)';
  const sepiaCard = 'const Color(0xFFF4E5C3)';
  const sepiaText = 'const Color(0xFF45321F)';

  // Resolve active light & dark background/card depending on themeMode
  const activeLightBg = isSepia ? sepiaBg : standardLightBg;
  const activeLightCard = isSepia ? sepiaCard : standardLightCard;

  const activeDarkBg = isAmoled ? amoledBg : standardDarkBg;
  const activeDarkCard = isAmoled ? amoledCard : standardDarkCard;

  const radiusVal = isClay ? 30.0 : isNeoBrutalist ? 8.0 : ctx.borderRadius;

  const neoBorderLight = isNeoBrutalist
    ? 'side: const BorderSide(color: Colors.black, width: 3.0),'
    : '';
  const neoBorderDark = isNeoBrutalist
    ? 'side: const BorderSide(color: Colors.white, width: 3.0),'
    : '';

  return `import 'package:flutter/material.dart';
import 'design_tokens.dart';

/// AppTheme generated for Swati Studio
/// Theme Mode: ${ctx.themeMode}
/// UI Style: ${ctx.uiStyle}
/// Aesthetic Combo: ${ctx.aestheticCombo}
class AppTheme {
  static const Color primaryColor = Color(${primaryHex});
  static const double defaultRadius = ${radiusVal.toFixed(1)};
  static const String defaultFont = '${ctx.font}';

  static ThemeData get lightTheme {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryColor,
      brightness: Brightness.light,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: ${activeLightBg},
      cardColor: ${activeLightCard},
      fontFamily: defaultFont,
      extensions: const [
        DesignTokens(
          borderRadius: defaultRadius,
          primaryColor: primaryColor,
          fontFamily: defaultFont,
        ),
      ],
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        backgroundColor: ${activeLightBg},
      ),
      cardTheme: CardTheme(
        color: ${activeLightCard},
        elevation: ${isNeoBrutalist ? '6' : isClay ? '8' : '0'},
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(defaultRadius),
          ${neoBorderLight}
        ),
      ),
      ${isNeoBrutalist ? `elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 5,
          side: const BorderSide(color: Colors.black, width: 2.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(defaultRadius)),
        ),
      ),` : ''}
    );
  }

  static ThemeData get darkTheme {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryColor,
      brightness: Brightness.dark,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: ${activeDarkBg},
      cardColor: ${activeDarkCard},
      fontFamily: defaultFont,
      extensions: const [
        DesignTokens(
          borderRadius: defaultRadius,
          primaryColor: primaryColor,
          fontFamily: defaultFont,
        ),
      ],
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        backgroundColor: ${activeDarkBg},
      ),
      cardTheme: CardTheme(
        color: ${activeDarkCard},
        elevation: ${isNeoBrutalist ? '6' : isClay ? '8' : '0'},
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(defaultRadius),
          ${neoBorderDark}
        ),
      ),
      ${isNeoBrutalist ? `elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 5,
          side: const BorderSide(color: Colors.white, width: 2.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(defaultRadius)),
        ),
      ),` : ''}
    );
  }

  /// AMOLED / True Black theme (#000000 Scaffold + #0D0D0D Cards)
  static ThemeData get amoledTheme {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryColor,
      brightness: Brightness.dark,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: ${amoledBg},
      cardColor: ${amoledCard},
      fontFamily: defaultFont,
      extensions: const [
        DesignTokens(
          borderRadius: defaultRadius,
          primaryColor: primaryColor,
          fontFamily: defaultFont,
          isAmoled: true,
        ),
      ],
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        backgroundColor: ${amoledBg},
      ),
      cardTheme: CardTheme(
        color: ${amoledCard},
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(defaultRadius),
        ),
      ),
    );
  }

  /// Sepia Warm reading theme (#FBF0D9 Scaffold + #F4E5C3 Cards)
  static ThemeData get sepiaTheme {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryColor,
      brightness: Brightness.light,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: ${sepiaBg},
      cardColor: ${sepiaCard},
      fontFamily: defaultFont,
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: ${sepiaText}),
        bodyMedium: TextStyle(color: ${sepiaText}),
      ),
      extensions: const [
        DesignTokens(
          borderRadius: defaultRadius,
          primaryColor: primaryColor,
          fontFamily: defaultFont,
          isSepia: true,
        ),
      ],
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        backgroundColor: ${sepiaBg},
      ),
      cardTheme: CardTheme(
        color: ${sepiaCard},
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(defaultRadius),
        ),
      ),
    );
  }
}
`;
}
