import type { GenContext, GeneratedFile } from '../types';

export function templateBrandingFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Flutter Launcher Icons Config
  files.push({
    path: 'flutter_launcher_icons.yaml',
    contents: `flutter_launcher_icons:
  android: true
  ios: true
  image_path: "assets/branding/icon_foreground.png"
  min_sdk_android: 21

  # Android 8.0+ Adaptive Icons
  adaptive_icon_background: "#${ctx.themeColorHex.replace('#', '')}"
  adaptive_icon_foreground: "assets/branding/icon_foreground.png"

  # Android 13+ Themed (Monochrome) Icon
  adaptive_icon_monochrome: "assets/branding/icon_monochrome.png"

  # Web & Desktop Favicon / PWA
  web:
    generate: true
    image_path: "assets/branding/icon_foreground.png"
    background_color: "#${ctx.themeColorHex.replace('#', '')}"
    theme_color: "#${ctx.themeColorHex.replace('#', '')}"

  windows:
    generate: true
    image_path: "assets/branding/icon_foreground.png"
    icon_size: 256

  macos:
    generate: true
    image_path: "assets/branding/icon_foreground.png"
`,
  });

  // 2. Flutter Native Splash Config
  files.push({
    path: 'flutter_native_splash.yaml',
    contents: `flutter_native_splash:
  color: "#${ctx.themeColorHex.replace('#', '')}"
  image: "assets/branding/splash_logo.png"

  # Dark Mode Splash Screen
  color_dark: "#0F172A"
  image_dark: "assets/branding/splash_logo.png"

  # Android 12+ System Splash Screen API
  android_12:
    color: "#${ctx.themeColorHex.replace('#', '')}"
    color_dark: "#0F172A"
    image: "assets/branding/splash_logo.png"
    image_dark: "assets/branding/splash_logo.png"

  # Fullscreen Display
  fullscreen: true
`,
  });

  // 3. Branding Assets README
  files.push({
    path: 'assets/branding/README.md',
    contents: `# 🎨 Branding Assets Guidelines — ${ctx.name}

To customize the app icon and splash screen, place high-resolution assets in this directory:

## 📁 Required Assets
- \`logo.png\` (1024x1024 PNG / SVG master logo)
- \`icon_foreground.png\` (1024x1024 transparent foreground icon layer)
- \`icon_monochrome.png\` (Android 13 silhouette themed icon layer)
- \`splash_logo.png\` (Centered splash logo)

## ⚡ Generating Platform Icons & Splash
Run the following commands:
\`\`\`bash
dart run flutter_launcher_icons
dart run flutter_native_splash:create
\`\`\`
`,
  });

  // 4. Store Assets README
  files.push({
    path: 'store_assets/README.md',
    contents: `# 📱 App Store & Google Play Store Assets — ${ctx.name}

Place publication assets here:

- \`play_icon_512.png\` — Google Play Store 512x512 32-bit PNG (Max 1024KB)
- \`feature_graphic_1024x500.png\` — Google Play Feature Graphic 1024x500 JPEG/PNG
- \`app_store_icon_1024.png\` — Apple App Store 1024x1024 PNG (No transparency/alpha)
`,
  });

  return files;
}
