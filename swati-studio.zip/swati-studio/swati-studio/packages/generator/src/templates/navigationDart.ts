import type { NavigationItem } from '@swati/schema';
import type { GenContext } from '../types';

export function templateNavigationWidget(ctx: GenContext): string {
  const items = ctx.navigationItems.length > 0 ? ctx.navigationItems : [
    { id: '1', name: 'Home', title: 'Home', icon: 'Home', route: '/home' },
    { id: '2', name: 'Explore', title: 'Explore', icon: 'Compass', route: '/explore' },
    { id: '3', name: 'Search', title: 'Search', icon: 'Search', route: '/search' },
    { id: '4', name: 'Saved', title: 'Saved', icon: 'Heart', route: '/saved' },
    { id: '5', name: 'Profile', title: 'Profile', icon: 'User', route: '/profile' },
  ];

  const mapIcon = (iconName: string): string => {
    switch (iconName) {
      case 'Home':
        return 'Icons.home_outlined, selectedIcon: Icons.home';
      case 'Search':
        return 'Icons.search, selectedIcon: Icons.search';
      case 'Heart':
      case 'Saved':
        return 'Icons.favorite_border, selectedIcon: Icons.favorite';
      case 'ShoppingCart':
        return 'Icons.shopping_cart_outlined, selectedIcon: Icons.shopping_cart';
      case 'Bell':
        return 'Icons.notifications_none, selectedIcon: Icons.notifications';
      case 'User':
        return 'Icons.person_outline, selectedIcon: Icons.person';
      case 'Settings':
        return 'Icons.settings_outlined, selectedIcon: Icons.settings';
      case 'MessageCircle':
        return 'Icons.chat_bubble_outline, selectedIcon: Icons.chat_bubble';
      case 'Compass':
      case 'Explore':
        return 'Icons.explore_outlined, selectedIcon: Icons.explore';
      default:
        return 'Icons.auto_awesome_outlined, selectedIcon: Icons.auto_awesome';
    }
  };

  const imports = items
    .map((item) => {
      const slug = item.name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
      return `import '../../features/${slug}/${slug}_screen.dart';`;
    })
    .join('\n');

  const screenList = items
    .map((item) => {
      const className = toPascalCase(item.name) + 'Screen';
      return `      const ${className}(),`;
    })
    .join('\n');

  /* 12. Side Navigation Drawer */
  if (ctx.navigationStyle === 'drawer') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: theme.colorScheme.primary),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    '${ctx.projectName}',
                    style: theme.textTheme.titleLarge?.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Version ${ctx.version}',
                    style: theme.textTheme.bodySmall?.copyWith(color: Colors.white70),
                  ),
                ],
              ),
            ),
${items
  .map(
    (item, idx) => `            ListTile(
              leading: Icon(${mapIcon(item.icon).split(',')[0]}),
              title: Text('${item.title}'),
              selected: _currentIndex == ${idx},
              onTap: () {
                setState(() => _currentIndex = ${idx});
                Navigator.pop(context);
              },
            ),`,
  )
  .join('\n')}
          ],
        ),
      ),
      body: _screens[_currentIndex],
    );
  }
}
`;
  }

  /* 13. Vertical Navigation Rail */
  if (ctx.navigationStyle === 'rail') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: _currentIndex,
            onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
            labelType: NavigationRailLabelType.all,
            destinations: const [
${items
  .map(
    (it) => `              NavigationRailDestination(
                icon: Icon(${mapIcon(it.icon).split(',')[0]}),
                selectedIcon: Icon(${mapIcon(it.icon).includes('selectedIcon:') ? mapIcon(it.icon).split('selectedIcon: ')[1] : mapIcon(it.icon).split(',')[0]}),
                label: Text('${it.name}'),
              ),`,
  )
  .join('\n')}
            ],
          ),
          const VerticalDivider(thickness: 1, width: 1),
          Expanded(child: _screens[_currentIndex]),
        ],
      ),
    );
  }
}
`;
  }

  /* 02. Glassmorphism */
  if (ctx.navigationStyle === 'glassmorphism') {
    return `import 'dart:ui';
import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            decoration: BoxDecoration(
              color: isDark ? Colors.black.withOpacity(0.4) : Colors.white.withOpacity(0.35),
              border: Border(top: BorderSide(color: isDark ? Colors.white10 : Colors.white24, width: 1.0)),
            ),
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
${items
  .map(
    (it, idx) => `                _buildGlassItem(${idx}, '${it.name}', ${mapIcon(it.icon).split(',')[0]}, theme),`,
  )
  .join('\n')}
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassItem(int index, String label, IconData icon, ThemeData theme) {
    final isSelected = _currentIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _currentIndex = index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? theme.colorScheme.primary.withOpacity(0.18) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: isSelected ? theme.colorScheme.primary : theme.colorScheme.onSurface.withOpacity(0.6)),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? theme.colorScheme.primary : theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
`;
  }

  /* 03. Floating (Detached) */
  if (ctx.navigationStyle === 'floating_detached') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Container(
            height: 64,
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(32),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.12),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
${items
  .map(
    (it, idx) => `                IconButton(
                  icon: Icon(${mapIcon(it.icon).split(',')[0]}),
                  color: _currentIndex == ${idx} ? theme.colorScheme.primary : theme.colorScheme.onSurfaceVariant,
                  onPressed: () => setState(() => _currentIndex = ${idx}),
                ),`,
  )
  .join('\n')}
              ],
            ),
          ),
        ),
      ),
    );
  }
}
`;
  }

  /* 06. Center FAB */
  if (ctx.navigationStyle === 'center_fab') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Center Action Button Tapped!'), behavior: SnackBarBehavior.floating),
          );
        },
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: Colors.white,
        shape: const CircleBorder(),
        child: const Icon(Icons.add, size: 28),
      ),
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
${items
  .map(
    (it, idx) => `            IconButton(
              icon: Icon(${mapIcon(it.icon).split(',')[0]}),
              color: _currentIndex == ${idx} ? theme.colorScheme.primary : theme.colorScheme.onSurfaceVariant,
              onPressed: () => setState(() => _currentIndex = ${idx}),
            ),`,
  )
  .join('\n')}
          ],
        ),
      ),
    );
  }
}
`;
  }

  /* 07. Gradient Bold */
  if (ctx.navigationStyle === 'gradient_bold') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF9333EA), Color(0xFFD946EF), Color(0xFFEC4899)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, -2)),
          ],
        ),
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
${items
  .map(
    (it, idx) => `            GestureDetector(
              onTap: () => setState(() => _currentIndex = ${idx}),
              behavior: HitTestBehavior.opaque,
              child: Opacity(
                opacity: _currentIndex == ${idx} ? 1.0 : 0.7,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(${mapIcon(it.icon).split(',')[0]}, color: Colors.white, size: 22),
                    const SizedBox(height: 2),
                    Text('${it.name}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),`,
  )
  .join('\n')}
          ],
        ),
      ),
    );
  }
}
`;
  }

  /* 11. Dock Style (iOS Inspired) */
  if (ctx.navigationStyle === 'dock_ios') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Container(
            height: 60,
            decoration: BoxDecoration(
              color: theme.colorScheme.surface.withOpacity(0.92),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: theme.dividerColor.withOpacity(0.1)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
${items
  .map(
    (it, idx) => `                IconButton(
                  icon: Icon(${mapIcon(it.icon).split(',')[0]}),
                  color: _currentIndex == ${idx} ? theme.colorScheme.primary : theme.colorScheme.onSurface.withOpacity(0.5),
                  onPressed: () => setState(() => _currentIndex = ${idx}),
                ),`,
  )
  .join('\n')}
              ],
            ),
          ),
        ),
      ),
    );
  }
}
`;
  }

  /* 13. Neon Glow (Cyberpunk) */
  if (ctx.navigationStyle === 'neon_glow') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0B0D14),
          border: const Border(top: BorderSide(color: Color(0xFF1F2430), width: 1.5)),
          boxShadow: [
            BoxShadow(
              color: Colors.cyanAccent.withOpacity(0.15),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
${items
  .map(
    (it, idx) => `            GestureDetector(
              onTap: () => setState(() => _currentIndex = ${idx}),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    ${mapIcon(it.icon).split(',')[0]},
                    color: _currentIndex == ${idx} ? Colors.cyanAccent : Colors.grey[600],
                    shadows: _currentIndex == ${idx}
                        ? [const Shadow(color: Colors.cyanAccent, blurRadius: 12)]
                        : null,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    '${it.name}',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: _currentIndex == ${idx} ? FontWeight.bold : FontWeight.normal,
                      color: _currentIndex == ${idx} ? Colors.cyanAccent : Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),`,
  )
  .join('\n')}
          ],
        ),
      ),
    );
  }
}
`;
  }

  /* 15. Neo-Brutalism */
  if (ctx.navigationStyle === 'neo_brutalism') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFFFFD93D),
          border: Border(top: BorderSide(color: Colors.black, width: 3.5)),
        ),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
${items
  .map(
    (it, idx) => `            GestureDetector(
              onTap: () => setState(() => _currentIndex = ${idx}),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: _currentIndex == ${idx}
                    ? BoxDecoration(
                        color: const Color(0xFFFF5C5C),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: Colors.black, width: 2),
                        boxShadow: const [BoxShadow(color: Colors.black, offset: Offset(3, 3))],
                      )
                    : null,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(${mapIcon(it.icon).split(',')[0]}, color: _currentIndex == ${idx} ? Colors.white : Colors.black),
                    Text(
                      '${it.name}',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        color: _currentIndex == ${idx} ? Colors.white : Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ),`,
  )
  .join('\n')}
          ],
        ),
      ),
    );
  }
}
`;
  }

  /* 21. Cradle Cutout */
  if (ctx.navigationStyle === 'cradle_cutout') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        elevation: 6,
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: Colors.white,
        shape: const CircleBorder(),
        onPressed: () {},
        child: const Icon(Icons.add, size: 28),
      ),
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
${items
  .slice(0, Math.ceil(items.length / 2))
  .map(
    (it, idx) => `            IconButton(
              icon: Icon(${mapIcon(it.icon).split(',')[0]}),
              color: _currentIndex == ${idx} ? theme.colorScheme.primary : theme.colorScheme.onSurface.withOpacity(0.5),
              onPressed: () => setState(() => _currentIndex = ${idx}),
            ),`,
  )
  .join('\n')}
            const SizedBox(width: 48), // Cradle gap
${items
  .slice(Math.ceil(items.length / 2))
  .map(
    (it, idx) => `            IconButton(
              icon: Icon(${mapIcon(it.icon).split(',')[0]}),
              color: _currentIndex == ${Math.ceil(items.length / 2) + idx} ? theme.colorScheme.primary : theme.colorScheme.onSurface.withOpacity(0.5),
              onPressed: () => setState(() => _currentIndex = ${Math.ceil(items.length / 2) + idx}),
            ),`,
  )
  .join('\n')}
          ],
        ),
      ),
    );
  }
}
`;
  }

  /* 32. Badge Counter */
  if (ctx.navigationStyle === 'badge_counter') {
    return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: [
${items
  .map(
    (item, idx) => `          NavigationDestination(
            icon: ${idx === 1 ? "Badge(label: const Text('3'), child: Icon(" + mapIcon(item.icon).split(',')[0] + '))' : idx === 3 ? "Badge(label: const Text('9+'), child: Icon(" + mapIcon(item.icon).split(',')[0] + '))' : 'Icon(' + mapIcon(item.icon).split(',')[0] + ')'},
            label: '${item.name}',
          ),`,
  )
  .join('\n')}
        ],
      ),
    );
  }
}
`;
  }

  /* 36. Haptic Bounce */
  if (ctx.navigationStyle === 'haptic_bounce') {
    return `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          HapticFeedback.lightImpact();
          setState(() => _currentIndex = index);
        },
        destinations: const [
${items
  .map(
    (item) => `          NavigationDestination(
            icon: Icon(${mapIcon(item.icon).split(',')[0]}),
            label: '${item.name}',
          ),`,
  )
  .join('\n')}
        ],
      ),
    );
  }
}
`;
  }

  /* Default (Minimal Clean / Pill Highlight / Outline / Curved): Standard Material 3 NavigationBar */
  return `import 'package:flutter/material.dart';
${imports}

class AppNavigationHost extends StatefulWidget {
  const AppNavigationHost({super.key});

  @override
  State<AppNavigationHost> createState() => _AppNavigationHostState();
}

class _AppNavigationHostState extends State<AppNavigationHost> {
  int _currentIndex = 0;

  static const List<Widget> _screens = [
${screenList}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        destinations: const [
${items
  .map(
    (item) => `          NavigationDestination(
            icon: Icon(${mapIcon(item.icon).split(',')[0]}),
            selectedIcon: Icon(${mapIcon(item.icon).includes('selectedIcon:') ? mapIcon(item.icon).split('selectedIcon: ')[1] : mapIcon(item.icon).split(',')[0]}),
            label: '${item.name}',
          ),`,
  )
  .join('\n')}
        ],
      ),
    );
  }
}
`;
}

function toPascalCase(str: string): string {
  return str
    .replace(/[^a-zA-Z0-9]+/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join('');
}
