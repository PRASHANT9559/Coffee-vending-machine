import type { GenContext } from '../types';

export function templateApiClient(ctx: GenContext): string {
  const isDio = ctx.packages.some((p) => p.name === 'dio');

  if (isDio) {
    const baseUrl = String(
      ctx.rawConfig[`backend.${ctx.backend}.url`] ?? 'https://api.example.com',
    );

    return `import 'package:dio/dio.dart';

class ApiClient {
  static final ApiClient _instance = ApiClient._internal();
  late final Dio dio;

  factory ApiClient() => _instance;

  ApiClient._internal() {
    dio = Dio(
      BaseOptions(
        baseUrl: '${baseUrl}',
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ),
    );

    dio.interceptors.add(
      LogInterceptor(
        requestBody: true,
        responseBody: true,
      ),
    );
  }
}
`;
  }

  return `class ApiClient {
  static final ApiClient _instance = ApiClient._internal();
  factory ApiClient() => _instance;
  ApiClient._internal();

  Future<Map<String, dynamic>> get(String endpoint) async {
    return {'status': 'ok'};
  }
}
`;
}
