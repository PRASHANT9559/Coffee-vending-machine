import type { GenContext, GeneratedFile } from '../types';

export function templateOfflineFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Offline Mutation Queue Item
  files.push({
    path: 'lib/core/offline/offline_queue.dart',
    contents: `import 'dart:convert';

enum MutationOperation { create, update, delete }

class QueueItem {
  final String id;
  final String entity;
  final MutationOperation operation;
  final Map<String, dynamic> payload;
  final DateTime timestamp;
  int retryCount;

  QueueItem({
    required this.id,
    required this.entity,
    required this.operation,
    required this.payload,
    required this.timestamp,
    this.retryCount = 0,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'entity': entity,
        'operation': operation.name,
        'payload': payload,
        'timestamp': timestamp.toIso8601String(),
        'retryCount': retryCount,
      };

  factory QueueItem.fromJson(Map<String, dynamic> json) => QueueItem(
        id: json['id'] as String,
        entity: json['entity'] as String,
        operation: MutationOperation.values.byName(json['operation'] as String),
        payload: json['payload'] as Map<String, dynamic>,
        timestamp: DateTime.parse(json['timestamp'] as String),
        retryCount: json['retryCount'] as int? ?? 0,
      );
}

class OfflineQueueManager {
  final List<QueueItem> _queue = [];

  List<QueueItem> get items => List.unmodifiable(_queue);
  bool get isEmpty => _queue.isEmpty;
  int get count => _queue.length;

  void enqueue(QueueItem item) {
    _queue.add(item);
  }

  QueueItem? peek() {
    return _queue.isNotEmpty ? _queue.first : null;
  }

  void remove(String id) {
    _queue.removeWhere((i) => i.id === id);
  }

  void clear() {
    _queue.clear();
  }
}
`,
  });

  // 2. Connectivity Monitor (Online/Offline State)
  files.push({
    path: 'lib/core/offline/connectivity_monitor.dart',
    contents: `import 'package:flutter/foundation.dart';

class ConnectivityMonitor extends ChangeNotifier {
  bool _isOnline = true;

  bool get isOnline => _isOnline;
  bool get isOffline => !_isOnline;

  void updateConnectionStatus(bool online) {
    if (_isOnline == online) return;
    _isOnline = online;
    notifyListeners();
  }
}
`,
  });

  // 3. Conflict Resolution Strategy
  files.push({
    path: 'lib/core/offline/conflict_resolver.dart',
    contents: `enum ConflictStrategy { lastWriteWins, serverWins, clientWins }

class ConflictResolver {
  static Map<String, dynamic> resolve({
    required Map<String, dynamic> localData,
    required Map<String, dynamic> remoteData,
    ConflictStrategy strategy = ConflictStrategy.lastWriteWins,
  }) {
    switch (strategy) {
      case ConflictStrategy.serverWins:
        return Map.from(remoteData);
      case ConflictStrategy.clientWins:
        return Map.from(localData);
      case ConflictStrategy.lastWriteWins:
      default:
        final localUpdated = DateTime.tryParse(localData['updated_at']?.toString() ?? '');
        final remoteUpdated = DateTime.tryParse(remoteData['updated_at']?.toString() ?? '');

        if (localUpdated != null && remoteUpdated != null) {
          return localUpdated.isAfter(remoteUpdated) ? localData : remoteData;
        }
        return remoteData;
    }
  }
}
`,
  });

  // 4. Cache Manager
  files.push({
    path: 'lib/core/offline/cache_manager.dart',
    contents: `class CacheManager {
  static final Map<String, dynamic> _memoryCache = {};
  static final Map<String, DateTime> _expiryMap = {};

  static void put(String key, dynamic data, {Duration ttl = const Duration(days: 7)}) {
    _memoryCache[key] = data;
    _expiryMap[key] = DateTime.now().add(ttl);
  }

  static dynamic get(String key) {
    final expiry = _expiryMap[key];
    if (expiry != null && DateTime.now().isAfter(expiry)) {
      _memoryCache.remove(key);
      _expiryMap.remove(key);
      return null;
    }
    return _memoryCache[key];
  }

  static bool has(String key) {
    return get(key) != null;
  }

  static void invalidate(String key) {
    _memoryCache.remove(key);
    _expiryMap.remove(key);
  }

  static void clear() {
    _memoryCache.clear();
    _expiryMap.clear();
  }
}
`,
  });

  // 5. Background Sync Engine
  files.push({
    path: 'lib/core/offline/sync_engine.dart',
    contents: `import 'dart:async';
import 'package:flutter/foundation.dart';
import 'offline_queue.dart';
import 'connectivity_monitor.dart';

class SyncEngine extends ChangeNotifier {
  final OfflineQueueManager queue = OfflineQueueManager();
  final ConnectivityMonitor connectivity = ConnectivityMonitor();
  bool _isSyncing = false;
  DateTime? _lastSyncedAt;

  bool get isSyncing => _isSyncing;
  DateTime? get lastSyncedAt => _lastSyncedAt;

  Future<void> syncPendingMutations() async {
    if (!connectivity.isOnline || _isSyncing || queue.isEmpty) return;

    _isSyncing = true;
    notifyListeners();

    try {
      while (!queue.isEmpty) {
        final item = queue.peek();
        if (item == null) break;

        // Process item with backend provider
        await Future.delayed(const Duration(milliseconds: 300));
        queue.remove(item.id);
      }
      _lastSyncedAt = DateTime.now();
    } catch (e) {
      debugPrint('[SyncEngine Error] \$e');
    } finally {
      _isSyncing = false;
      notifyListeners();
    }
  }
}
`,
  });

  // 6. Offline Banner Widget
  files.push({
    path: 'lib/core/offline/widgets/offline_banner.dart',
    contents: `import 'package:flutter/material.dart';

class OfflineBannerWidget extends StatelessWidget {
  final bool isOffline;

  const OfflineBannerWidget({super.key, required this.isOffline});

  @override
  Widget build(BuildContext context) {
    if (!isOffline) return const SizedBox.shrink();

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: double.infinity,
      color: Colors.amber.shade900,
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(Icons.wifi_off_rounded, color: Colors.white, size: 16),
          SizedBox(width: 8),
          Text(
            'You are offline. Changes will sync automatically.',
            style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
`,
  });

  // 7. Sync Progress Indicator Widget
  files.push({
    path: 'lib/core/offline/widgets/sync_indicator.dart',
    contents: `import 'package:flutter/material.dart';

class SyncIndicatorWidget extends StatelessWidget {
  final bool isSyncing;

  const SyncIndicatorWidget({super.key, required this.isSyncing});

  @override
  Widget build(BuildContext context) {
    if (!isSyncing) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.blue.shade900.withOpacity(0.85),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: const [
          SizedBox(
            height: 12,
            width: 12,
            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
          ),
          SizedBox(width: 6),
          Text('Syncing...', style: TextStyle(color: Colors.white, fontSize: 11)),
        ],
      ),
    );
  }
}
`,
  });

  return files;
}
