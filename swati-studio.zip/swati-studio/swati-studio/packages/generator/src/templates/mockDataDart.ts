import type { GenContext, GeneratedFile } from '../types';

export function templateMockDataFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Fixtures: products.json
  files.push({
    path: 'lib/core/mock/fixtures/products.json',
    contents: JSON.stringify(
      [
        {
          id: 'prod_101',
          name: 'Wireless Noise Canceling Headphones',
          price: 2999.0,
          category: 'Electronics',
          image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
          in_stock: true,
          created_at: '2026-11-01T10:00:00Z',
        },
        {
          id: 'prod_102',
          name: 'Mechanical Gaming Keyboard',
          price: 4499.0,
          category: 'Electronics',
          image_url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3',
          in_stock: true,
          created_at: '2026-11-01T11:00:00Z',
        },
        {
          id: 'prod_103',
          name: 'Ergonomic Desk Chair',
          price: 9999.0,
          category: 'Furniture',
          image_url: 'https://images.unsplash.com/photo-1580481077195-c266a2e99f4d',
          in_stock: false,
          created_at: '2026-11-02T08:30:00Z',
        },
        {
          id: 'prod_104',
          name: 'Minimalist Steel Water Bottle',
          price: 799.0,
          category: 'Lifestyle',
          image_url: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8',
          in_stock: true,
          created_at: '2026-11-02T09:15:00Z',
        },
      ],
      null,
      2
    ) + '\n',
  });

  // 2. Fixtures: orders.json
  files.push({
    path: 'lib/core/mock/fixtures/orders.json',
    contents: JSON.stringify(
      [
        {
          id: 'ord_9001',
          user_id: 'user_42',
          total: 7498.0,
          status: 'delivered',
          items_count: 2,
          created_at: '2026-10-30T14:20:00Z',
        },
        {
          id: 'ord_9002',
          user_id: 'user_42',
          total: 2999.0,
          status: 'in_transit',
          items_count: 1,
          created_at: '2026-11-02T16:45:00Z',
        },
      ],
      null,
      2
    ) + '\n',
  });

  // 3. Fixtures: users.json
  files.push({
    path: 'lib/core/mock/fixtures/users.json',
    contents: JSON.stringify(
      [
        {
          id: 'user_42',
          email: 'developer@example.com',
          name: 'Test Developer',
          role: 'admin',
          avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb',
        },
      ],
      null,
      2
    ) + '\n',
  });

  // 4. Mock Data Generator
  files.push({
    path: 'lib/core/mock/mock_data_generator.dart',
    contents: `import 'dart:math';

class MockDataGenerator {
  static final _random = Random(42);

  static const List<String> _productNames = [
    'Wireless Earbuds Pro',
    'Smart Fitness Tracker',
    'Portable Power Bank 20000mAh',
    'Ultra-wide Curved Monitor',
    'Laptop Stand Aluminum',
    'USB-C Fast Charger 65W',
    'Bluetooth Speaker Waterproof',
  ];

  static const List<String> _categories = [
    'Electronics',
    'Accessories',
    'Lifestyle',
    'Fitness',
  ];

  static List<Map<String, dynamic>> generateProducts(int count) {
    return List.generate(count, (index) {
      final name = _productNames[index % _productNames.length];
      final price = (99 + _random.nextInt(9000)).toDouble();
      final category = _categories[index % _categories.length];

      return {
        'id': 'mock_prod_\${index + 1}',
        'name': '\$name #\${index + 1}',
        'price': price,
        'category': category,
        'image_url': 'https://picsum.photos/seed/\${index + 1}/400/300',
        'in_stock': _random.nextDouble() > 0.15,
        'created_at': DateTime.now().subtract(Duration(days: index)).toIso8601String(),
      };
    });
  }
}
`,
  });

  // 5. Mock Network Interceptor (Dio-style simulated latency and error rates)
  files.push({
    path: 'lib/core/mock/mock_interceptor.dart',
    contents: `import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';

class MockInterceptorConfig {
  final int minLatencyMs;
  final int maxLatencyMs;
  final double failureRate;
  final bool simulate401;

  const MockInterceptorConfig({
    this.minLatencyMs = 300,
    this.maxLatencyMs = 1200,
    this.failureRate = 0.05,
    this.simulate401 = false,
  });
}

class MockInterceptor {
  final MockInterceptorConfig config;
  final Random _random = Random();

  MockInterceptor({this.config = const MockInterceptorConfig()});

  Future<void> simulateNetworkDelay() async {
    final latency = config.minLatencyMs +
        _random.nextInt(max(1, config.maxLatencyMs - config.minLatencyMs));
    await Future.delayed(Duration(milliseconds: latency));

    if (config.simulate401) {
      throw Exception('401 Unauthorized: Session Token Expired');
    }

    if (_random.nextDouble() < config.failureRate) {
      throw Exception('500 Internal Server Error: Mock simulated failure');
    }
  }
}
`,
  });

  // 6. Mock Product Repository Implementation
  files.push({
    path: 'lib/core/mock/repositories/mock_product_repository.dart',
    contents: `import 'package:flutter/foundation.dart';
import '../mock_data_generator.dart';
import '../mock_interceptor.dart';

class MockProductRepository {
  final MockInterceptor interceptor;
  final List<Map<String, dynamic>> _items;

  MockProductRepository({MockInterceptor? interceptor})
      : interceptor = interceptor ?? MockInterceptor(),
        _items = MockDataGenerator.generateProducts(25);

  Future<List<Map<String, dynamic>>> getProducts({
    String? search,
    String? category,
    int page = 1,
    int limit = 10,
  }) async {
    await interceptor.simulateNetworkDelay();

    var filtered = _items;
    if (search != null && search.isNotEmpty) {
      filtered = filtered
          .where((p) => (p['name'] as String).toLowerCase().contains(search.toLowerCase()))
          .toList();
    }
    if (category != null && category.isNotEmpty) {
      filtered = filtered.where((p) => p['category'] == category).toList();
    }

    final startIndex = (page - 1) * limit;
    if (startIndex >= filtered.length) return [];
    final endIndex = min(startIndex + limit, filtered.length);

    debugPrint('[MockProductRepository] Returning \${endIndex - startIndex} products (page: \$page)');
    return filtered.sublist(startIndex, endIndex);
  }

  Future<Map<String, dynamic>> addProduct(Map<String, dynamic> data) async {
    await interceptor.simulateNetworkDelay();
    final newProduct = {
      ...data,
      'id': 'mock_prod_\${DateTime.now().millisecondsSinceEpoch}',
      'created_at': DateTime.now().toIso8601String(),
    };
    _items.insert(0, newProduct);
    return newProduct;
  }
}
`,
  });

  // 7. Standalone zero-dependency HTTP server
  files.push({
    path: 'tools/mock_server/server.dart',
    contents: `import 'dart:convert';
import 'dart:io';

Future<void> main(List<String> args) async {
  final port = int.tryParse(Platform.environment['PORT'] ?? '8081') ?? 8081;
  final server = await HttpServer.bind(InternetAddress.loopbackIPv4, port);
  print('🚀 [Swati Mock Server] Running at http://localhost:\$port');

  await for (HttpRequest request in server) {
    request.response.headers.add('Access-Control-Allow-Origin', '*');
    request.response.headers.add('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    request.response.headers.add('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (request.method == 'OPTIONS') {
      request.response.statusCode = HttpStatus.ok;
      await request.response.close();
      continue;
    }

    final path = request.uri.path;
    print('\${request.method} \$path');

    if (path.contains('/products')) {
      final sample = [
        {'id': 'p1', 'name': 'Mock Wireless Headphones', 'price': 2999.0, 'category': 'Electronics'},
        {'id': 'p2', 'name': 'Mock Ergonomic Chair', 'price': 8999.0, 'category': 'Furniture'},
      ];
      request.response
        ..headers.contentType = ContentType.json
        ..write(jsonEncode(sample));
      await request.response.close();
      continue;
    }

    request.response
      ..headers.contentType = ContentType.json
      ..write(jsonEncode({'status': 'ok', 'service': '${ctx.name} Mock Server'}));
    await request.response.close();
  }
}
`,
  });

  return files;
}
