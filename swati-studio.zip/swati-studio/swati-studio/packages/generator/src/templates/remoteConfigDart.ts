import type { GenContext, GeneratedFile } from '../types';

export function templateRemoteConfigFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Remote Keys Constants
  files.push({
    path: 'lib/core/remote_config/remote_keys.dart',
    contents: `class RemoteKeys {
  RemoteKeys._();

  static const String minSupportedVersion = 'min_supported_version';
  static const String latestVersion = 'latest_version';
  static const String maintenanceMode = 'maintenance_mode';
  static const String maintenanceMessage = 'maintenance_message';
  static const String showAds = 'show_ads';
  static const String interstitialGapSeconds = 'interstitial_gap_sec';
  static const String newCheckoutEnabled = 'new_checkout_enabled';
  static const String supportContactEmail = 'support_contact_email';
}
`,
  });

  // 2. Semver Checker
  files.push({
    path: 'lib/core/remote_config/app_version_checker.dart',
    contents: `class AppVersionChecker {
  AppVersionChecker._();

  /// Compares two semver strings (e.g. "1.2.0" and "1.3.0").
  /// Returns:
  ///   < 0 if v1 < v2
  ///   0   if v1 == v2
  ///   > 0 if v1 > v2
  static int compareSemver(String v1, String v2) {
    final clean1 = v1.split('+').first.split('-').first;
    final clean2 = v2.split('+').first.split('-').first;

    final parts1 = clean1.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final parts2 = clean2.split('.').map((e) => int.tryParse(e) ?? 0).toList();

    while (parts1.length < 3) parts1.add(0);
    while (parts2.length < 3) parts2.add(0);

    for (int i = 0; i < 3; i++) {
      if (parts1[i] < parts2[i]) return -1;
      if (parts1[i] > parts2[i]) return 1;
    }
    return 0;
  }

  static bool isUpdateRequired({
    required String currentVersion,
    required String minSupportedVersion,
  }) {
    return compareSemver(currentVersion, minSupportedVersion) < 0;
  }

  static bool isUpdateAvailable({
    required String currentVersion,
    required String latestVersion,
  }) {
    return compareSemver(currentVersion, latestVersion) < 0;
  }
}
`,
  });

  // 3. Remote Config Service
  files.push({
    path: 'lib/core/remote_config/remote_config_service.dart',
    contents: `import 'package:flutter/foundation.dart';
import 'remote_keys.dart';

class RemoteConfigService {
  RemoteConfigService._();
  static final RemoteConfigService instance = RemoteConfigService._();

  final Map<String, dynamic> _defaults = {
    RemoteKeys.minSupportedVersion: '1.0.0',
    RemoteKeys.latestVersion: '1.0.0',
    RemoteKeys.maintenanceMode: false,
    RemoteKeys.maintenanceMessage: 'We are performing scheduled maintenance. Please check back shortly!',
    RemoteKeys.showAds: false,
    RemoteKeys.interstitialGapSeconds: 120,
    RemoteKeys.newCheckoutEnabled: false,
    RemoteKeys.supportContactEmail: 'support@${ctx.slug}.com',
  };

  final Map<String, dynamic> _activeConfig = {};
  DateTime? _lastFetchTime;
  Duration cacheTtl = const Duration(hours: 1);

  Map<String, dynamic> get allValues => Map.unmodifiable({..._defaults, ..._activeConfig});

  Future<void> initialize() async {
    debugPrint('[RemoteConfigService] Initializing remote config defaults...');
    _activeConfig.addAll(_defaults);
    await fetchAndActivate();
  }

  Future<bool> fetchAndActivate() async {
    final now = DateTime.now();
    if (_lastFetchTime != null && now.difference(_lastFetchTime!) < cacheTtl) {
      debugPrint('[RemoteConfigService] Cache TTL valid. Skipping network fetch.');
      return false;
    }

    try {
      debugPrint('[RemoteConfigService] Fetching latest remote config values...');
      // In production, delegates to Firebase Remote Config or Supabase app_config table
      _lastFetchTime = now;
      return true;
    } catch (e) {
      debugPrint('[RemoteConfigService] Fetch failed, falling back to cache/defaults: \$e');
      return false;
    }
  }

  String getString(String key, [String fallback = '']) {
    return _activeConfig[key]?.toString() ?? _defaults[key]?.toString() ?? fallback;
  }

  bool getBool(String key, [bool fallback = false]) {
    final val = _activeConfig[key] ?? _defaults[key];
    if (val is bool) return val;
    if (val is String) return val.toLowerCase() == 'true';
    return fallback;
  }

  int getInt(String key, [int fallback = 0]) {
    final val = _activeConfig[key] ?? _defaults[key];
    if (val is int) return val;
    if (val is num) return val.toInt();
    if (val is String) return int.tryParse(val) ?? fallback;
    return fallback;
  }

  double getDouble(String key, [double fallback = 0.0]) {
    final val = _activeConfig[key] ?? _defaults[key];
    if (val is double) return val;
    if (val is num) return val.toDouble();
    if (val is String) return double.tryParse(val) ?? fallback;
    return fallback;
  }
}
`,
  });

  // 4. Feature Flags Facade
  files.push({
    path: 'lib/core/remote_config/feature_flags.dart',
    contents: `import 'remote_config_service.dart';
import 'remote_keys.dart';

class FeatureFlags {
  FeatureFlags._();

  static bool get isMaintenanceMode =>
      RemoteConfigService.instance.getBool(RemoteKeys.maintenanceMode);

  static String get maintenanceMessage =>
      RemoteConfigService.instance.getString(RemoteKeys.maintenanceMessage);

  static bool get isNewCheckoutEnabled =>
      RemoteConfigService.instance.getBool(RemoteKeys.newCheckoutEnabled);

  static bool get showAds =>
      RemoteConfigService.instance.getBool(RemoteKeys.showAds);

  static bool isEnabled(String key) =>
      RemoteConfigService.instance.getBool(key);
}
`,
  });

  // 5. Maintenance Gate Widget
  files.push({
    path: 'lib/core/remote_config/maintenance_gate.dart',
    contents: `import 'package:flutter/material.dart';
import 'remote_config_service.dart';
import 'remote_keys.dart';

class MaintenanceGate extends StatefulWidget {
  final Widget child;

  const MaintenanceGate({super.key, required this.child});

  @override
  State<MaintenanceGate> createState() => _MaintenanceGateState();
}

class _MaintenanceGateState extends State<MaintenanceGate> {
  bool _isMaintenance = false;
  String _message = '';

  @override
  void initState() {
    super.initState();
    _checkStatus();
  }

  void _checkStatus() {
    setState(() {
      _isMaintenance = RemoteConfigService.instance.getBool(RemoteKeys.maintenanceMode);
      _message = RemoteConfigService.instance.getString(RemoteKeys.maintenanceMessage);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_isMaintenance) {
      return widget.child;
    }

    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.construction_rounded,
                  size: 80,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(height: 24),
                Text(
                  'Under Maintenance',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  _message,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 32),
                FilledButton.icon(
                  onPressed: () async {
                    await RemoteConfigService.instance.fetchAndActivate();
                    _checkStatus();
                  },
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Check Again'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
`,
  });

  // 6. Update Dialogs (Force + Soft)
  files.push({
    path: 'lib/core/remote_config/update_dialog.dart',
    contents: `import 'package:flutter/material.dart';

class UpdateDialog {
  UpdateDialog._();

  static void showForceUpdate(BuildContext context, {required String latestVersion}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => PopScope(
        canPop: false,
        child: AlertDialog(
          icon: const Icon(Icons.system_update_rounded, size: 48, color: Colors.blue),
          title: const Text('Update Required'),
          content: Text(
            'A required update (v\$latestVersion) is available with essential security updates and bug fixes. Please update to continue.',
          ),
          actions: [
            FilledButton(
              onPressed: () {
                // Launch store URL (Play Store / App Store)
                Navigator.of(ctx).pop();
              },
              child: const Text('Update Now'),
            ),
          ],
        ),
      ),
    );
  }

  static void showSoftUpdateBanner(BuildContext context, {required String latestVersion}) {
    ScaffoldMessenger.of(context).showMaterialBanner(
      MaterialBanner(
        leading: const Icon(Icons.info_outline_rounded, color: Colors.indigo),
        content: Text('A new version (v\$latestVersion) is now available.'),
        actions: [
          TextButton(
            onPressed: () => ScaffoldMessenger.of(context).hideCurrentMaterialBanner(),
            child: const Text('Later'),
          ),
          FilledButton.tonal(
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
              // Open store URL
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }
}
`,
  });

  // 7. Feature Gate Widget
  files.push({
    path: 'lib/core/remote_config/widgets/feature_gate.dart',
    contents: `import 'package:flutter/material.dart';
import '../feature_flags.dart';

class FeatureGate extends StatelessWidget {
  final String flag;
  final Widget child;
  final Widget? fallback;

  const FeatureGate({
    super.key,
    required this.flag,
    required this.child,
    this.fallback,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = FeatureFlags.isEnabled(flag);
    if (enabled) return child;
    return fallback ?? const SizedBox.shrink();
  }
}
`,
  });

  // 8. Documentation: REMOTE-CONFIG.md
  files.push({
    path: 'docs/REMOTE-CONFIG.md',
    contents: `# 🎛️ Remote Config & Feature Flags Guide — ${ctx.name}

This project includes dynamic runtime remote configuration and feature flagging capabilities.

## 📋 Standard Remote Keys

| Key | Type | Default | Description |
|---|---|---|---|
| \`min_supported_version\` | String | \`1.0.0\` | App versions below this require blocking force update |
| \`latest_version\` | String | \`1.0.0\` | Latest store release version for optional soft update banner |
| \`maintenance_mode\` | bool | \`false\` | When true, puts the app into full-screen maintenance mode |
| \`maintenance_message\` | String | \`"Under Maintenance"\` | Message displayed on the maintenance screen |
| \`new_checkout_enabled\` | bool | \`false\` | Toggle for new checkout flow |
| \`show_ads\` | bool | \`false\` | Enable or disable AdMob monetization dynamically |

## 🚀 Usage in Flutter UI

\`\`\`dart
// Feature Gate Widget
FeatureGate(
  flag: RemoteKeys.newCheckoutEnabled,
  child: const NewCheckoutScreen(),
  fallback: const ClassicCheckoutScreen(),
);

// Programmatic Flag Check
if (FeatureFlags.showAds) {
  AdService.instance.showInterstitial();
}
\`\`\`
`,
  });

  return files;
}
