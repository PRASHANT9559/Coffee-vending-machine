import type { GenContext, GeneratedFile } from '../types';

export function templateUiStatesFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Domain Failure class
  files.push({
    path: 'lib/core/errors/failure.dart',
    contents: `abstract class Failure {
  final String message;
  final int? code;
  final Object? cause;

  const Failure(this.message, {this.code, this.cause});

  @override
  String toString() => 'Failure(message: \$message, code: \$code)';
}

class ServerFailure extends Failure {
  const ServerFailure(super.message, {super.code, super.cause});
}

class NetworkFailure extends Failure {
  const NetworkFailure([super.message = 'No internet connection. Please verify network.']);
}

class AuthFailure extends Failure {
  const AuthFailure([super.message = 'Session expired or unauthorized. Please re-login.']);
}

class ValidationFailure extends Failure {
  const ValidationFailure(super.message);
}

class NotFoundFailure extends Failure {
  const NotFoundFailure([super.message = 'Requested resource was not found.']);
}
`,
  });

  // 2. Error Mapper
  files.push({
    path: 'lib/core/errors/error_mapper.dart',
    contents: `import 'failure.dart';

class ErrorMapper {
  ErrorMapper._();

  static Failure mapToFailure(Object error) {
    final str = error.toString().toLowerCase();

    if (str.contains('socketexception') || str.contains('network') || str.contains('timeout')) {
      return const NetworkFailure();
    }

    if (str.contains('401') || str.contains('unauthorized') || str.contains('jwt')) {
      return const AuthFailure();
    }

    if (str.contains('404') || str.contains('not found')) {
      return const NotFoundFailure();
    }

    if (str.contains('validation') || str.contains('invalid')) {
      return ValidationFailure(error.toString());
    }

    return ServerFailure(error.toString());
  }
}
`,
  });

  // 3. Loading View
  files.push({
    path: 'lib/core/widgets/states/loading_view.dart',
    contents: `import 'package:flutter/material.dart';

class LoadingView extends StatelessWidget {
  final String? message;

  const LoadingView({super.key, this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(),
          if (message != null) ...[
            const SizedBox(height: 16),
            Text(message!, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ],
      ),
    );
  }
}
`,
  });

  // 4. Skeleton List (Shimmer placeholder simulator)
  files.push({
    path: 'lib/core/widgets/states/skeleton_list.dart',
    contents: `import 'package:flutter/material.dart';

class SkeletonList extends StatelessWidget {
  final int itemCount;
  final double itemHeight;

  const SkeletonList({
    super.key,
    this.itemCount = 6,
    this.itemHeight = 72.0,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5);

    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: itemCount,
      itemBuilder: (context, index) {
        return Container(
          height: itemHeight,
          margin: const EdgeInsets.only(bottom: 12.0),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12.0),
          ),
        );
      },
    );
  }
}
`,
  });

  // 5. Empty View
  files.push({
    path: 'lib/core/widgets/states/empty_view.dart',
    contents: `import 'package:flutter/material.dart';

class EmptyView extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;
  final VoidCallback? onAction;
  final String? actionLabel;

  const EmptyView({
    super.key,
    required this.title,
    this.subtitle,
    this.icon = Icons.inbox_outlined,
    this.onAction,
    this.actionLabel,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 72, color: theme.colorScheme.outline),
            const SizedBox(height: 16),
            Text(
              title,
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 8),
              Text(
                subtitle!,
                style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                textAlign: TextAlign.center,
              ),
            ],
            if (onAction != null && actionLabel != null) ...[
              const SizedBox(height: 24),
              FilledButton.tonal(
                onPressed: onAction,
                child: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
`,
  });

  // 6. Error View
  files.push({
    path: 'lib/core/widgets/states/error_view.dart',
    contents: `import 'package:flutter/material.dart';

class ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final IconData icon;

  const ErrorView({
    super.key,
    required this.message,
    this.onRetry,
    this.icon = Icons.error_outline_rounded,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: theme.colorScheme.error),
            const SizedBox(height: 16),
            Text(
              'Something went wrong',
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              textAlign: TextAlign.center,
            ),
            if (onRetry != null) ...[
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try Again'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
`,
  });

  // 7. Offline Banner
  files.push({
    path: 'lib/core/widgets/states/offline_banner.dart',
    contents: `import 'package:flutter/material.dart';

class OfflineBanner extends StatelessWidget {
  final bool isOffline;

  const OfflineBanner({super.key, required this.isOffline});

  @override
  Widget build(BuildContext context) {
    if (!isOffline) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      color: Colors.amber.shade800,
      padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 16.0),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.wifi_off_rounded, size: 16, color: Colors.white),
          SizedBox(width: 8),
          Text(
            'You are offline. Showing cached content.',
            style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
`,
  });

  // 8. Permission Denied View
  files.push({
    path: 'lib/core/widgets/states/permission_denied_view.dart',
    contents: `import 'package:flutter/material.dart';

class PermissionDeniedView extends StatelessWidget {
  final String permissionName;
  final VoidCallback? onOpenSettings;

  const PermissionDeniedView({
    super.key,
    required this.permissionName,
    this.onOpenSettings,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock_person_outlined, size: 64, color: Colors.blueGrey),
            const SizedBox(height: 16),
            Text(
              'Permission Required',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Please grant \$permissionName permission from system settings to enable this feature.',
              textAlign: TextAlign.center,
            ),
            if (onOpenSettings != null) ...[
              const SizedBox(height: 24),
              FilledButton(
                onPressed: onOpenSettings,
                child: const Text('Open Settings'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
`,
  });

  // 9. Paginated Footer
  files.push({
    path: 'lib/core/widgets/states/paginated_footer.dart',
    contents: `import 'package:flutter/material.dart';

class PaginatedFooter extends StatelessWidget {
  final bool hasMore;
  final bool isLoading;

  const PaginatedFooter({
    super.key,
    required this.hasMore,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 20.0),
        child: Center(child: CircularProgressIndicator(strokeWidth: 2.5)),
      );
    }

    if (!hasMore) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 24.0),
        child: Center(
          child: Text(
            'You have reached the end of the list',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey),
          ),
        ),
      );
    }

    return const SizedBox.shrink();
  }
}
`,
  });

  // 10. Async Value View (Universal Async state handler)
  files.push({
    path: 'lib/core/widgets/states/async_value_view.dart',
    contents: `import 'package:flutter/material.dart';
import 'loading_view.dart';
import 'error_view.dart';
import 'empty_view.dart';

class AsyncValueView<T> extends StatelessWidget {
  final bool isLoading;
  final Object? error;
  final T? data;
  final bool Function(T data)? isEmpty;
  final Widget Function(T data) onData;
  final String emptyTitle;
  final VoidCallback? onRetry;

  const AsyncValueView({
    super.key,
    required this.isLoading,
    this.error,
    this.data,
    this.isEmpty,
    required this.onData,
    this.emptyTitle = 'No records found',
    this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading && data == null) {
      return const LoadingView();
    }

    if (error != null && data == null) {
      return ErrorView(
        message: error.toString(),
        onRetry: onRetry,
      );
    }

    if (data != null) {
      if (isEmpty != null && isEmpty!(data as T)) {
        return EmptyView(
          title: emptyTitle,
          onAction: onRetry,
          actionLabel: 'Refresh',
        );
      }
      return onData(data as T);
    }

    return const LoadingView();
  }
}
`,
  });

  return files;
}
