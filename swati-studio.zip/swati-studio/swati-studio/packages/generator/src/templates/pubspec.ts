import type { GenContext } from '../types';

export function templatePubspec(ctx: GenContext): string {
  const dependencies: string[] = [
    '  flutter:',
    '    sdk: flutter',
    '  cupertino_icons: ^1.0.8',
  ];

  for (const pkg of ctx.packages) {
    if (pkg.name !== 'flutter' && pkg.name !== 'cupertino_icons') {
      dependencies.push(`  ${pkg.name}: ${pkg.version ?? 'any'}`);
    }
  }

  const assetsSection = ctx.databaseFile
    ? `\n  assets:\n    - assets/db/\n`
    : '';

  return `name: ${ctx.packageName}
description: "${ctx.description.replace(/"/g, '\\"')}"
publish_to: "none"
version: ${ctx.version}+1

environment:
  sdk: ^3.5.0
  flutter: ">=3.24.0"

dependencies:
${dependencies.join('\n')}

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^5.0.0

flutter:
  uses-material-design: true${assetsSection}`;
}
