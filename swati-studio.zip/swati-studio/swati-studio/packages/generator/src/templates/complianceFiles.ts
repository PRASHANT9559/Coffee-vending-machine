import type { GenContext, GeneratedFile } from '../types';

export function templateComplianceFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const contactEmail = `privacy@${ctx.slug}.com`;
  const appName = ctx.name;

  // 1. Privacy Policy Markdown
  files.push({
    path: 'legal/privacy_policy.md',
    contents: `# Privacy Policy for ${appName}

**Last Updated:** ${new Date().toISOString().split('T')[0]}

${appName} ("we", "our", or "us") is dedicated to protecting your personal privacy. This Privacy Policy outlines our practices regarding data collection, use, and disclosure in compliance with GDPR (EU), DPDP Act (India), and CCPA (California).

---

## 1. Information We Collect

### A. Information You Provide
- **Account Information:** Name, email address, password hash, phone number when registering.
- **Support Requests:** Communications sent to our support desk.

### B. Automated Telemetry & Diagnostics
- **Crash Logs:** Diagnostic stack traces, device model, operating system version (via Crashlytics / Sentry).
- **Usage Metrics:** Feature usage, screen view counts, and engagement intervals.

---

## 2. How We Use Your Data
1. Authenticate user sessions securely.
2. Provide, maintain, and improve app functionality.
3. Comply with applicable legal obligations.

---

## 3. Account & Data Deletion Rights
Under GDPR, DPDP, and Store Guidelines, you have the right to request full erasure of your account and associated records at any time.

- In-app: Navigate to **Settings > Account > Delete Account**.
- Web Portal: Visit [Account Deletion Portal](https://${ctx.slug}.com/legal/account_deletion.html).
- Email: Contact us at [${contactEmail}](mailto:${contactEmail}).

---

## 4. Contact Us
For any privacy inquiries or Data Protection Officer requests:
- **Email:** ${contactEmail}
- **Website:** https://${ctx.slug}.com
`,
  });

  // 2. Hosting-ready Privacy Policy HTML
  files.push({
    path: 'legal/privacy_policy.html',
    contents: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Privacy Policy - ${appName}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; max-width: 800px; margin: 40px auto; padding: 0 20px; color: #1e293b; }
    h1, h2 { color: #0f172a; }
    .card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin: 20px 0; }
  </style>
</head>
<body>
  <h1>Privacy Policy for ${appName}</h1>
  <p><strong>Effective Date:</strong> ${new Date().toISOString().split('T')[0]}</p>
  <div class="card">
    <p>This policy details how <strong>${appName}</strong> collects, processes, and protects your information across Android, iOS, and Web platforms.</p>
  </div>
  <h2>1. Data Collection</h2>
  <p>We only collect data strictly necessary for application functionality, authentication, and error monitoring.</p>
  <h2>2. Account Deletion Request</h2>
  <p>Users may delete their account and associated data directly in-app or via our <a href="account_deletion.html">Account Deletion Page</a>.</p>
  <h2>3. Contact</h2>
  <p>Contact our Data Safety Team at <a href="mailto:${contactEmail}">${contactEmail}</a>.</p>
</body>
</html>
`,
  });

  // 3. Terms of Service Markdown
  files.push({
    path: 'legal/terms_of_service.md',
    contents: `# Terms of Service — ${appName}

**Effective Date:** ${new Date().toISOString().split('T')[0]}

Welcome to ${appName}. By downloading, accessing, or using our mobile and web applications, you agree to be bound by these Terms of Service.

## 1. Acceptable Use
You agree not to misuse our services, reverse engineer the binary, or perform unauthorized security penetration testing.

## 2. User Accounts
You are responsible for maintaining the confidentiality of your authentication credentials.

## 3. Termination
We reserve the right to suspend or terminate accounts that violate local laws or platform terms.

## 4. Contact
For legal notices: ${contactEmail}
`,
  });

  // 4. Play Store Account Deletion Page (HTML)
  files.push({
    path: 'legal/account_deletion.html',
    contents: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Account Deletion Request - ${appName}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; max-width: 600px; margin: 40px auto; padding: 0 20px; color: #1e293b; }
    .box { border: 1px solid #cbd5e1; border-radius: 12px; padding: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    button { background: #ef4444; color: white; border: none; padding: 12px 20px; border-radius: 6px; font-weight: bold; cursor: pointer; }
    input[type="email"] { width: 100%; padding: 10px; margin: 10px 0 20px; border: 1px solid #cbd5e1; border-radius: 6px; box-sizing: border-box; }
  </style>
</head>
<body>
  <div class="box">
    <h1>Delete Your ${appName} Account</h1>
    <p>In accordance with Google Play Store and Apple Developer requirements, you can request the permanent deletion of your account and all associated personal data.</p>
    <hr>
    <h3>What happens when you delete your account?</h3>
    <ul>
      <li>Your personal profile, email, and authentication records are permanently erased.</li>
      <li>All active sessions, push tokens, and cloud sync records are revoked.</li>
      <li>This action cannot be undone.</li>
    </ul>
    <form action="mailto:${contactEmail}?subject=Account%20Deletion%20Request" method="post" enctype="text/plain">
      <label for="email">Enter your registered email address:</label>
      <input type="email" id="email" name="user_email" required placeholder="name@example.com">
      <button type="submit">Submit Deletion Request</button>
    </form>
  </div>
</body>
</html>
`,
  });

  // 5. Play Console Data Safety Cheatsheet
  files.push({
    path: 'legal/DATA-SAFETY-CHEATSHEET.md',
    contents: `# 🛡️ Google Play Store Data Safety Questionnaire Cheatsheet

Use these ready-to-answer responses when filling out the Google Play Console **Data Safety Form** for **${appName}**.

---

### Overview Questions:
- **Does your app collect or share any user data?**
  👉 **Yes**
- **Is all data encrypted in transit?**
  👉 **Yes** (HTTPS/TLS 1.3 on all endpoints)
- **Do you provide a way for users to request data deletion?**
  👉 **Yes** (In-app flow + public URL: \`https://${ctx.slug}.com/legal/account_deletion.html\`)

---

### Data Types Breakdown:

| Data Category | Specific Data | Collected? | Shared? | Purpose | Linked to user? |
|---|---|---|---|---|---|
| **Personal Info** | Email address | Yes | No | Account management, Auth | Yes |
| **Personal Info** | Name | Yes | No | Profile display | Yes |
| **Location** | Coarse / Approximate | Optional | No | Localized content / Store finder | No |
| **App Activity** | Page views & clicks | Yes | No | Analytics & optimization | No |
| **App Info & Perf** | Crash logs & Diagnostics | Yes | No | Bug fixes & stability | No |
| **Device IDs** | Push token (FCM) | Yes | No | Push notifications | Yes |

---
`,
  });

  // 6. In-App Privacy Policy Screen
  files.push({
    path: 'lib/features/legal/screens/privacy_policy_screen.dart',
    contents: `import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Policy'),
      ),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Privacy Policy for ${appName}',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            Text(
              'We respect your privacy and are committed to protecting your personal data. This application encrypts all network communications via HTTPS/TLS.',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
            SizedBox(height: 20),
            Text(
              'Data We Collect:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text('• Authentication data (Email, Name)\\n• Device token for push updates\\n• Diagnostic crash reports'),
          ],
        ),
      ),
    );
  }
}
`,
  });

  // 7. In-App Terms Screen
  files.push({
    path: 'lib/features/legal/screens/terms_screen.dart',
    contents: `import 'package:flutter/material.dart';

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Terms of Service'),
      ),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Terms of Service — ${appName}',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            Text(
              'By utilizing this application, you acknowledge and agree to comply with all acceptable usage terms and conditions.',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}
`,
  });

  // 8. Delete Account Screen
  files.push({
    path: 'lib/features/legal/screens/delete_account_screen.dart',
    contents: `import 'package:flutter/material.dart';
import '../controllers/account_deletion_controller.dart';

class DeleteAccountScreen extends StatefulWidget {
  const DeleteAccountScreen({super.key});

  @override
  State<DeleteAccountScreen> createState() => _DeleteAccountScreenState();
}

class _DeleteAccountScreenState extends State<DeleteAccountScreen> {
  final _confirmationController = TextEditingController();
  final _controller = AccountDeletionController();
  bool _isProcessing = false;

  @override
  void dispose() {
    _confirmationController.dispose();
    super.dispose();
  }

  Future<void> _handleDelete() async {
    if (_confirmationController.text.trim().toUpperCase() != 'DELETE') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please type DELETE to confirm.')),
      );
      return;
    }

    setState(() => _isProcessing = true);
    final success = await _controller.deleteUserAccount();
    setState(() => _isProcessing = false);

    if (success && mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Delete Account'),
        backgroundColor: Colors.transparent,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.warning_amber_rounded, size: 64, color: theme.colorScheme.error),
              const SizedBox(height: 16),
              Text(
                'Permanent Account Erasure',
                style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Text(
                'This will permanently delete your account, remove all cloud data, and revoke authorization. This action cannot be reversed.',
                style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _confirmationController,
                decoration: const InputDecoration(
                  labelText: 'Type "DELETE" to confirm',
                  border: OutlineInputBorder(),
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: theme.colorScheme.error),
                  onPressed: _isProcessing ? null : _handleDelete,
                  child: _isProcessing
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Permanently Delete My Account'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
`,
  });

  // 9. Account Deletion Controller
  files.push({
    path: 'lib/features/legal/controllers/account_deletion_controller.dart',
    contents: `import 'package:flutter/foundation.dart';

class AccountDeletionController {
  Future<bool> deleteUserAccount() async {
    try {
      debugPrint('[AccountDeletionController] Requesting server-side account deletion...');
      // 1. Send API deletion command
      // 2. Clear secure storage tokens
      // 3. Clear local caches
      await Future.delayed(const Duration(milliseconds: 600));
      return true;
    } catch (e) {
      debugPrint('[AccountDeletionController] Deletion failed: \$e');
      return false;
    }
  }

  Future<void> requestDataExport() async {
    debugPrint('[AccountDeletionController] Triggering GDPR data export package...');
  }
}
`,
  });

  // 10. Consent Dialog
  files.push({
    path: 'lib/features/legal/widgets/consent_dialog.dart',
    contents: `import 'package:flutter/material.dart';

class ConsentDialog extends StatelessWidget {
  const ConsentDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Privacy & Consent'),
      content: const Text(
        'We value your privacy. We use anonymous performance diagnostics to improve application stability.',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Decline'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: const Text('Accept & Continue'),
        ),
      ],
    );
  }
}
`,
  });

  return files;
}
