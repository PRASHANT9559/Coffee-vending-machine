import type { GenContext, GeneratedFile } from '../types';

export function templateI18nFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // l10n.yaml
  files.push({
    path: 'l10n.yaml',
    contents: `arb-dir: lib/l10n
template-arb-file: app_en.arb
output-localization-file: app_localizations.dart
untranslated-messages-file: untranslated.json
`,
  });

  // app_en.arb
  files.push({
    path: 'lib/l10n/app_en.arb',
    contents: `{
  "@@locale": "en",
  "appTitle": "${ctx.projectName}",
  "welcomeMessage": "Welcome to ${ctx.projectName}",
  "loginButton": "Sign In",
  "registerButton": "Create Account",
  "searchPlaceholder": "Search...",
  "settingsTitle": "Settings",
  "languageSelect": "Language",
  "saveButton": "Save",
  "cancelButton": "Cancel"
}
`,
  });

  // app_hi.arb
  files.push({
    path: 'lib/l10n/app_hi.arb',
    contents: `{
  "@@locale": "hi",
  "appTitle": "${ctx.projectName}",
  "welcomeMessage": "${ctx.projectName} में आपका स्वागत है",
  "loginButton": "लॉग इन करें",
  "registerButton": "खाता बनाएं",
  "searchPlaceholder": "खोजें...",
  "settingsTitle": "सेटिंग्स",
  "languageSelect": "भाषा",
  "saveButton": "सुरक्षित करें",
  "cancelButton": "रद्द करें"
}
`,
  });

  // app_es.arb
  files.push({
    path: 'lib/l10n/app_es.arb',
    contents: `{
  "@@locale": "es",
  "appTitle": "${ctx.projectName}",
  "welcomeMessage": "Bienvenido a ${ctx.projectName}",
  "loginButton": "Iniciar Sesión",
  "registerButton": "Crear Cuenta",
  "searchPlaceholder": "Buscar...",
  "settingsTitle": "Ajustes",
  "languageSelect": "Idioma",
  "saveButton": "Guardar",
  "cancelButton": "Cancelar"
}
`,
  });

  // Locale Provider
  files.push({
    path: 'lib/core/localization/locale_provider.dart',
    contents: `import 'package:flutter/material.dart';

class LocaleProvider extends ChangeNotifier {
  Locale _locale = const Locale('${ctx.locale ?? 'en'}');

  Locale get locale => _locale;

  void setLocale(Locale locale) {
    if (_locale == locale) return;
    _locale = locale;
    notifyListeners();
  }

  void clearLocale() {
    _locale = const Locale('en');
    notifyListeners();
  }
}
`,
  });

  // Language Picker Widget
  files.push({
    path: 'lib/core/localization/language_picker.dart',
    contents: `import 'package:flutter/material.dart';
import 'locale_provider.dart';

class LanguagePickerWidget extends StatelessWidget {
  final LocaleProvider localeProvider;

  const LanguagePickerWidget({super.key, required this.localeProvider});

  @override
  Widget build(BuildContext context) {
    final currentCode = localeProvider.locale.languageCode;

    final languages = [
      {'code': 'en', 'name': 'English (US)', 'flag': '🇺🇸'},
      {'code': 'hi', 'name': 'हिंदी (Hindi)', 'flag': '🇮🇳'},
      {'code': 'es', 'name': 'Español (Spanish)', 'flag': '🇪🇸'},
    ];

    return PopupMenuButton<String>(
      initialValue: currentCode,
      tooltip: 'Change Language',
      icon: const Icon(Icons.language),
      onSelected: (String code) {
        localeProvider.setLocale(Locale(code));
      },
      itemBuilder: (BuildContext context) {
        return languages.map((lang) {
          final isSelected = lang['code'] == currentCode;
          return PopupMenuItem<String>(
            value: lang['code'],
            child: Row(
              children: [
                Text(lang['flag']!, style: const TextStyle(fontSize: 18)),
                const SizedBox(width: 12),
                Text(lang['name']!),
                if (isSelected) ...[
                  const Spacer(),
                  const Icon(Icons.check, size: 16, color: Colors.blue),
                ],
              ],
            ),
          );
        }).toList();
      },
    );
  }
}
`,
  });

  return files;
}
