import type { GenContext } from '../types';

export function templateMainDart(ctx: GenContext): string {
  const imports: string[] = ["import 'package:flutter/material.dart';"];
  const inits: string[] = ['  WidgetsFlutterBinding.ensureInitialized();'];

  if (ctx.stateManager === 'riverpod') {
    imports.push("import 'package:flutter_riverpod/flutter_riverpod.dart';");
  }

  if (ctx.backend === 'supabase') {
    imports.push("import 'package:supabase_flutter/supabase_flutter.dart';");
    const url = String(ctx.rawConfig['backend.supabase.url'] ?? 'https://example.supabase.co');
    const anonKey = String(ctx.rawConfig['backend.supabase.anonKey'] ?? 'anon-key-placeholder');
    inits.push(`  await Supabase.initialize(
    url: '${url}',
    anonKey: '${anonKey}',
  );`);
  }

  if (ctx.database === 'hive') {
    imports.push("import 'package:hive_flutter/hive_flutter.dart';");
    inits.push('  await Hive.initFlutter();');
  }

  imports.push("import 'app.dart';");

  let appRunner = 'const MyApp()';
  if (ctx.stateManager === 'riverpod') {
    appRunner = 'const ProviderScope(child: MyApp())';
  }

  return `${imports.join('\n')}

void main() async {
${inits.join('\n')}
  runApp(${appRunner});
}
`;
}
