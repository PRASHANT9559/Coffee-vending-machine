import type { GenContext, GeneratedFile } from '../types';

export function templateDeepLinkingFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Deep Link Handler
  files.push({
    path: 'lib/core/routing/deep_link_handler.dart',
    contents: `import 'package:flutter/material.dart';

class DeepLinkHandler {
  static void handleUri(Uri uri, BuildContext context) {
    final path = uri.path;
    final query = uri.queryParameters;

    debugPrint('[DeepLink] Incoming URI: \$uri with path: \$path');

    if (path.startsWith('/product/') || path.startsWith('/order/') || path.startsWith('/user/')) {
      Navigator.of(context).pushNamed(path, arguments: query);
    } else {
      Navigator.of(context).pushNamed(path);
    }
  }

  static Uri createUniversalLink({required String path, Map<String, String>? queryParams}) {
    return Uri(
      scheme: 'https',
      host: '${ctx.packageName}.app',
      path: path,
      queryParameters: queryParams,
    );
  }
}
`,
  });

  // 2. Android assetlinks.json
  files.push({
    path: 'assets/well-known/assetlinks.json',
    contents: `[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "${ctx.packageName}",
      "sha256_cert_fingerprints": [
        "14:6D:E9:7D:0F:52:CC:71:85:4E:87:EF:29:16:E7:EA:92:E3:69:4F:10:98:24:2D:A6:4E:47:4F:B7:A8:13:B9"
      ]
    }
  }
]
`,
  });

  // 3. iOS apple-app-site-association
  files.push({
    path: 'assets/well-known/apple-app-site-association',
    contents: `{
  "applinks": {
    "apps": [],
    "details": [
      {
        "appID": "TEAMID.${ctx.packageName}",
        "paths": ["*"]
      }
    ]
  }
}
`,
  });

  return files;
}
