import type { GenContext, GeneratedFile } from '../types';

export function templateOnboardingFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Onboarding Slide Data Model
  files.push({
    path: 'lib/features/onboarding/models/onboarding_data.dart',
    contents: `import 'package:flutter/material.dart';

class OnboardingSlideData {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color? accentColor;

  const OnboardingSlideData({
    required this.title,
    required this.subtitle,
    required this.icon,
    this.accentColor,
  });
}
`,
  });

  // 2. Onboarding Controller (First Launch Persistence)
  files.push({
    path: 'lib/features/onboarding/controllers/onboarding_controller.dart',
    contents: `import 'package:flutter/material.dart';

class OnboardingController extends ChangeNotifier {
  int _currentIndex = 0;
  bool _hasSeenOnboarding = false;

  int get currentIndex => _currentIndex;
  bool get hasSeenOnboarding => _hasSeenOnboarding;

  void setIndex(int index) {
    _currentIndex = index;
    notifyListeners();
  }

  Future<void> completeOnboarding() async {
    _hasSeenOnboarding = true;
    notifyListeners();
    // SharedPreferences or SecureStorage persistence key: 'has_seen_onboarding'
  }
}
`,
  });

  // 3. Dot Indicator Widget
  files.push({
    path: 'lib/features/onboarding/widgets/dot_indicator.dart',
    contents: `import 'package:flutter/material.dart';

class DotIndicator extends StatelessWidget {
  final int count;
  final int activeIndex;
  final Color activeColor;

  const DotIndicator({
    super.key,
    required this.count,
    required this.activeIndex,
    required this.activeColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (index) {
        final isActive = index == activeIndex;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          height: 8,
          width: isActive ? 24 : 8,
          decoration: BoxDecoration(
            color: isActive ? activeColor : activeColor.withOpacity(0.25),
            borderRadius: BorderRadius.circular(4),
          ),
        );
      }),
    );
  }
}
`,
  });

  // 4. Onboarding Slide Widget
  files.push({
    path: 'lib/features/onboarding/widgets/onboarding_slide.dart',
    contents: `import 'package:flutter/material.dart';
import '../models/onboarding_data.dart';

class OnboardingSlideWidget extends StatelessWidget {
  final OnboardingSlideData data;

  const OnboardingSlideWidget({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = data.accentColor ?? theme.colorScheme.primary;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 24.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(data.icon, size: 64, color: color),
          ),
          const SizedBox(height: 40),
          Text(
            data.title,
            textAlign: TextAlign.center,
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            data.subtitle,
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.textTheme.bodyMedium?.color?.withOpacity(0.7),
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
`,
  });

  // 5. Onboarding Screen (PageView with Skip & CTA)
  files.push({
    path: 'lib/features/onboarding/screens/onboarding_screen.dart',
    contents: `import 'package:flutter/material.dart';
import '../models/onboarding_data.dart';
import '../widgets/dot_indicator.dart';
import '../widgets/onboarding_slide.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentIndex = 0;

  final List<OnboardingSlideData> _slides = const [
    OnboardingSlideData(
      title: 'Welcome to ${ctx.projectName.replace(/'/g, "\\'")}',
      subtitle: '${ctx.description.replace(/'/g, "\\'")}. Engineered with modern clean architecture.',
      icon: Icons.rocket_launch_rounded,
    ),
    OnboardingSlideData(
      title: 'Real-time & Offline-First',
      subtitle: 'Experience lightning-fast data updates with seamless local caching and auto-sync.',
      icon: Icons.bolt_rounded,
    ),
    OnboardingSlideData(
      title: 'Ready for Productivity',
      subtitle: 'Manage your workflow, track performance, and customize your experience effortlessly.',
      icon: Icons.auto_awesome_rounded,
    ),
  ];

  void _finishOnboarding() {
    Navigator.of(context).pushReplacementNamed('/');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLastSlide = _currentIndex == _slides.length - 1;

    return Scaffold(
      appBar: AppBar(
        actions: [
          if (!isLastSlide)
            TextButton(
              onPressed: _finishOnboarding,
              child: const Text('Skip'),
            ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: _slides.length,
                onPageChanged: (idx) => setState(() => _currentIndex = idx),
                itemBuilder: (context, index) {
                  return OnboardingSlideWidget(data: _slides[index]);
                },
              ),
            ),
            DotIndicator(
              count: _slides.length,
              activeIndex: _currentIndex,
              activeColor: theme.colorScheme.primary,
            ),
            const SizedBox(height: 32),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                  onPressed: isLastSlide
                      ? _finishOnboarding
                      : () {
                          _pageController.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                          );
                        },
                  child: Text(
                    isLastSlide ? 'Get Started' : 'Continue',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
`,
  });

  return files;
}
