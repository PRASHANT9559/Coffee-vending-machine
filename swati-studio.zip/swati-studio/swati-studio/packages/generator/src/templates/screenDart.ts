import type { GenContext, GeneratedFile } from '../types';

export interface ExportedComponent {
  id: string;
  type:
    | 'appbar'
    | 'button'
    | 'text'
    | 'card'
    | 'textfield'
    | 'image'
    | 'listview'
    | 'floating_action_button'
    | 'badge'
    | 'stat_card'
    | 'container'
    | 'divider'
    | 'spacer';
  name: string;
  props: {
    title?: string;
    subtitle?: string;
    text?: string;
    label?: string;
    placeholder?: string;
    variant?: 'elevated' | 'filled' | 'outlined' | 'text' | 'h1' | 'h2' | 'body';
    color?: string;
    bgColor?: string;
    fontSize?: number;
    padding?: number;
    borderRadius?: number;
    icon?: string;
    elevation?: number;
    imageUrl?: string;
    value?: string;
    items?: string[];
    actionType?: 'none' | 'navigate' | 'snackbar' | 'dialog';
    targetRoute?: string;
    height?: number;
    width?: number;
  };
}

export interface ExportedScreen {
  id: string;
  name: string;
  route: string;
  isInitial?: boolean;
  components: ExportedComponent[];
}

function escapeDartString(str?: string | null): string {
  if (!str) return '';
  return str
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\$/g, '\\$')
    .replace(/\r/g, '\\r')
    .replace(/\n/g, '\\n');
}

function getFlutterIcon(iconName?: string): string {
  if (!iconName) return 'Icons.star';
  const iconMap: Record<string, string> = {
    Plus: 'Icons.add',
    Minus: 'Icons.remove',
    Edit: 'Icons.edit',
    Delete: 'Icons.delete',
    Search: 'Icons.search',
    Settings: 'Icons.settings',
    Home: 'Icons.home',
    User: 'Icons.person',
    Heart: 'Icons.favorite',
    Star: 'Icons.star',
    Arrow: 'Icons.arrow_forward',
    ArrowLeft: 'Icons.arrow_back',
    Check: 'Icons.check',
    Close: 'Icons.close',
    Menu: 'Icons.menu',
    Bell: 'Icons.notifications',
    Mail: 'Icons.mail',
    Phone: 'Icons.phone',
    Camera: 'Icons.camera_alt',
    Share: 'Icons.share',
    Refresh: 'Icons.refresh',
    Info: 'Icons.info_outline',
  };
  const sanitized = iconName.replace(/[^a-zA-Z0-9_]/g, '').toLowerCase();
  return iconMap[iconName] || `Icons.${sanitized || 'star'}`;
}

/**
 * Converts a single Screen Builder component into Flutter widget code.
 */
export function componentToFlutterWidget(
  component: ExportedComponent,
  context?: Partial<GenContext>
): string {
  const { type, props } = component;

  switch (type) {
    case 'appbar': {
      const title = escapeDartString(props.title || 'Screen');
      const elev = props.elevation ?? 2;
      return `AppBar(
        title: const Text('${title}'),
        centerTitle: true,
        elevation: ${elev},
      )`;
    }

    case 'button': {
      const label = escapeDartString(props.label || 'Click Here');
      const radius = props.borderRadius ?? 12;
      const variant = props.variant || 'elevated';

      let actionCode = '() {}';
      if (props.actionType === 'navigate' && props.targetRoute) {
        actionCode = `() {
          Navigator.of(context).pushNamed('${escapeDartString(props.targetRoute)}');
        }`;
      } else if (props.actionType === 'snackbar') {
        actionCode = `() {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('${label} clicked!')),
          );
        }`;
      } else if (props.actionType === 'dialog') {
        actionCode = `() {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('${label}'),
              content: const Text('Action triggered successfully.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(),
                  child: const Text('OK'),
                ),
              ],
            ),
          );
        }`;
      }

      const iconWidget = props.icon
        ? `Icon(${getFlutterIcon(props.icon)}, size: 18), const SizedBox(width: 8), `
        : '';

      const shapeCode = `RoundedRectangleBorder(borderRadius: BorderRadius.circular(${radius}))`;

      if (variant === 'outlined') {
        return `OutlinedButton(
          onPressed: ${actionCode},
          style: OutlinedButton.styleFrom(
            shape: ${shapeCode},
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ${iconWidget}Text('${label}'),
            ],
          ),
        )`;
      }

      if (variant === 'text') {
        return `TextButton(
          onPressed: ${actionCode},
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ${iconWidget}Text('${label}'),
            ],
          ),
        )`;
      }

      if (variant === 'filled') {
        return `FilledButton(
          onPressed: ${actionCode},
          style: FilledButton.styleFrom(
            shape: ${shapeCode},
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ${iconWidget}Text('${label}'),
            ],
          ),
        )`;
      }

      return `ElevatedButton(
        onPressed: ${actionCode},
        style: ElevatedButton.styleFrom(
          elevation: ${props.elevation ?? 2},
          shape: ${shapeCode},
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ${iconWidget}Text('${label}'),
          ],
        ),
      )`;
    }

    case 'text': {
      const text = escapeDartString(props.text || 'Hello World');
      const fontSize = props.fontSize || (props.variant === 'h1' ? 24 : props.variant === 'h2' ? 20 : 16);
      const fontWeight =
        props.variant === 'h1'
          ? 'FontWeight.bold'
          : props.variant === 'h2'
            ? 'FontWeight.w600'
            : 'FontWeight.normal';

      const paddingVal = props.padding ?? 4;
      return `Padding(
        padding: const EdgeInsets.all(${paddingVal}.0),
        child: Text(
          '${text}',
          style: TextStyle(
            fontSize: ${fontSize}.0,
            fontWeight: ${fontWeight},
          ),
        ),
      )`;
    }

    case 'card': {
      const title = props.title ? escapeDartString(props.title) : null;
      const subtitle = props.subtitle ? escapeDartString(props.subtitle) : null;
      const padding = props.padding ?? 16;
      const radius = props.borderRadius ?? 16;
      const elev = props.elevation ?? 1;

      let onTapWrapper = '';
      let onTapEnd = '';
      if (props.actionType === 'navigate' && props.targetRoute) {
        onTapWrapper = `InkWell(
          borderRadius: BorderRadius.circular(${radius}),
          onTap: () => Navigator.of(context).pushNamed('${escapeDartString(props.targetRoute)}'),
          child: `;
        onTapEnd = `,
        )`;
      }

      return `Card(
        elevation: ${elev}.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(${radius}.0),
        ),
        child: ${onTapWrapper}Padding(
          padding: const EdgeInsets.all(${padding}.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ${title ? `Text('${title}', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),` : ''}
              ${title && subtitle ? 'const SizedBox(height: 6),' : ''}
              ${subtitle ? `Text('${subtitle}', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),` : ''}
            ],
          ),
        )${onTapEnd},
      )`;
    }

    case 'textfield': {
      const label = escapeDartString(props.label || 'Input');
      const placeholder = escapeDartString(props.placeholder || 'Enter text...');
      const radius = props.borderRadius ?? 10;

      return `Padding(
        padding: const EdgeInsets.symmetric(vertical: 6.0),
        child: TextField(
          decoration: InputDecoration(
            labelText: '${label}',
            hintText: '${placeholder}',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(${radius}.0),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      )`;
    }

    case 'listview': {
      const title = props.title ? escapeDartString(props.title) : 'Navigation Links';
      const items = props.items && props.items.length > 0
        ? props.items
        : ['Item 1', 'Item 2', 'Item 3'];
      const radius = props.borderRadius ?? 12;

      return `Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(${radius}.0)),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Text(
                  '${title}',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
                ),
              ),
              const Divider(height: 1),
              ${items
                .map(
                  (item) => `ListTile(
                leading: Icon(Icons.circle, size: 8, color: Theme.of(context).colorScheme.primary),
                title: Text('${escapeDartString(item)}'),
                trailing: const Icon(Icons.chevron_right, size: 18),
                onTap: () {},
              )`
                )
                .join(',\n              ')},
            ],
          ),
        ),
      )`;
    }

    case 'stat_card': {
      const title = escapeDartString(props.title || 'Metric');
      const value = escapeDartString(props.value || '0');
      const radius = props.borderRadius ?? 14;

      return `Container(
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.4),
          borderRadius: BorderRadius.circular(${radius}.0),
          border: Border.all(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${title}',
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${value}',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ),
      )`;
    }

    case 'image': {
      const radius = props.borderRadius ?? 14;
      const height = props.height ?? 160;
      const imageUrl = props.imageUrl;

      if (imageUrl) {
        return `ClipRRect(
        borderRadius: BorderRadius.circular(${radius}.0),
        child: Image.network(
          '${escapeDartString(imageUrl)}',
          height: ${height}.0,
          width: double.infinity,
          fit: BoxFit.cover,
          errorBuilder: (ctx, err, stack) => Container(
            height: ${height}.0,
            color: Theme.of(context).colorScheme.surfaceVariant,
            child: const Center(child: Icon(Icons.broken_image, size: 40)),
          ),
        ),
      )`;
      }

      return `Container(
        height: ${height}.0,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Theme.of(context).colorScheme.primary,
              Theme.of(context).colorScheme.tertiary,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(${radius}.0),
        ),
        child: Center(
          child: Text(
            '${escapeDartString(props.title || 'Featured Banner')}',
            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      )`;
    }

    case 'floating_action_button': {
      const icon = getFlutterIcon(props.icon || 'Plus');
      const elev = props.elevation ?? 6;

      let action = '() {}';
      if (props.actionType === 'navigate' && props.targetRoute) {
        action = `() {
          Navigator.of(context).pushNamed('${escapeDartString(props.targetRoute)}');
        }`;
      }

      return `FloatingActionButton(
        elevation: ${elev}.0,
        onPressed: ${action},
        child: const Icon(${icon}),
      )`;
    }

    case 'badge': {
      const title = escapeDartString(props.title || 'Badge');
      return `Chip(
        avatar: const Icon(Icons.tag, size: 16),
        label: const Text('${title}'),
      )`;
    }

    case 'container': {
      const padding = props.padding ?? 12;
      const radius = props.borderRadius ?? 8;
      const childText = escapeDartString(props.title || props.text || 'Container Box');
      return `Container(
        padding: const EdgeInsets.all(${padding}.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(${radius}.0),
          border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        ),
        child: Text('${childText}'),
      )`;
    }

    case 'divider': {
      return `const Padding(
        padding: EdgeInsets.symmetric(vertical: 8.0),
        child: Divider(),
      )`;
    }

    case 'spacer': {
      const height = props.height ?? 16;
      return `const SizedBox(height: ${height}.0)`;
    }

    default:
      return `// Unrecognized component: ${type}`;
  }
}

/**
 * Capitalizes string to PascalCase for Flutter Widget class name.
 */
export function toPascalCase(str: string): string {
  const pascal = str
    .replace(/[^a-zA-Z0-9]/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join('');
  if (/^[0-9]/.test(pascal)) {
    return `Screen${pascal}`;
  }
  return pascal || 'Screen';
}

/**
 * Converts screen name to snake_case for file names.
 */
export function toSnakeCase(str: string): string {
  return str
    .replace(/[^a-zA-Z0-9]/g, '_')
    .replace(/_+/g, '_')
    .toLowerCase();
}

/**
 * Generates the full Dart source code for a single screen.
 */
export function templateScreenDart(
  screen: ExportedScreen,
  context?: Partial<GenContext>
): string {
  const className = `${toPascalCase(screen.name || 'Screen')}Page`;

  // Separate appbar, fab, and body widgets
  let appBarCode: string | null = null;
  let fabCode: string | null = null;
  const bodyWidgets: string[] = [];

  for (const comp of screen.components) {
    if (comp.type === 'appbar' && !appBarCode) {
      appBarCode = componentToFlutterWidget(comp, context);
    } else if (comp.type === 'floating_action_button' && !fabCode) {
      fabCode = componentToFlutterWidget(comp, context);
    } else {
      bodyWidgets.push(componentToFlutterWidget(comp, context));
    }
  }

  // Fallback default AppBar if none defined
  if (!appBarCode) {
    appBarCode = `AppBar(
        title: const Text('${escapeDartString(screen.name || 'Screen')}'),
        centerTitle: true,
      )`;
  }

  const scaffoldParts: string[] = [];
  scaffoldParts.push(`      appBar: ${appBarCode},`);

  if (bodyWidgets.length > 0) {
    const formattedChildren = bodyWidgets
      .map((w) => `            ${w.replace(/\n/g, '\n            ')},`)
      .join('\n            const SizedBox(height: 12),\n');

    scaffoldParts.push(`      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
${formattedChildren}
            ],
          ),
        ),
      ),`);
  } else {
    scaffoldParts.push(`      body: const SafeArea(
        child: Center(
          child: Text('Screen content will appear here.'),
        ),
      ),`);
  }

  if (fabCode) {
    scaffoldParts.push(`      floatingActionButton: ${fabCode},`);
  }

  return `import 'package:flutter/material.dart';

/// Generated screen for route: ${screen.route}
class ${className} extends StatelessWidget {
  const ${className}({super.key});

  static const String routeName = '${screen.route}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
${scaffoldParts.join('\n')}
    );
  }
}
`;
}

/**
 * Generates Dart code for all screens and their route table.
 */
export function generateAllScreensDart(
  screens: ExportedScreen[],
  context?: Partial<GenContext>
): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  for (const screen of screens) {
    const fileName = `${toSnakeCase(screen.name || 'screen')}_page.dart`;
    files.push({
      path: `lib/screens/${fileName}`,
      contents: templateScreenDart(screen, context),
    });
  }

  // Also generate the unified routes file
  files.push({
    path: 'lib/screens/app_routes.dart',
    contents: generateScreenRoutesDart(screens),
  });

  return files;
}

/**
 * Generates an `app_routes.dart` file that provides the `Map<String, WidgetBuilder>` for MaterialApp.
 */
export function generateScreenRoutesDart(screens: ExportedScreen[]): string {
  const imports: string[] = ["import 'package:flutter/material.dart';"];
  const routeEntries: string[] = [];

  let initialRoute = '/';
  for (const screen of screens) {
    const className = `${toPascalCase(screen.name || 'Screen')}Page`;
    const fileName = `${toSnakeCase(screen.name || 'screen')}_page.dart`;
    imports.push(`import '${fileName}';`);

    const route = screen.route.startsWith('/') ? screen.route : `/${screen.route}`;
    if (screen.isInitial) {
      initialRoute = route;
    }

    routeEntries.push(`    '${route}': (context) => const ${className}(),`);
  }

  return `${imports.join('\n')}

class AppRoutes {
  static const String initialRoute = '${initialRoute}';

  static final Map<String, WidgetBuilder> routes = {
${routeEntries.join('\n')}
  };
}
`;
}

/**
 * Helper to export a single screen directly to a standalone Dart code string.
 */
export function exportScreenToDart(
  screen: ExportedScreen,
  context?: Partial<GenContext>
): string {
  return templateScreenDart(screen, context);
}
