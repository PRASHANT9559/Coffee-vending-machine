import type { GenContext } from '../types';

export function templateHomeModel(ctx: GenContext): string {
  return `class HomeModel {
  final String title;
  final int counter;
  final bool isLoading;

  const HomeModel({
    required this.title,
    this.counter = 0,
    this.isLoading = false,
  });

  HomeModel copyWith({
    String? title,
    int? counter,
    bool? isLoading,
  }) {
    return HomeModel(
      title: title ?? this.title,
      counter: counter ?? this.counter,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}
`;
}

export function templateHomeController(ctx: GenContext): string {
  if (ctx.stateManager === 'riverpod') {
    return `import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/home_model.dart';

class HomeNotifier extends StateNotifier<HomeModel> {
  HomeNotifier() : super(const HomeModel(title: '${ctx.projectName.replace(/'/g, "\\'")}'));

  void increment() {
    state = state.copyWith(counter: state.counter + 1);
  }

  void decrement() {
    state = state.copyWith(counter: state.counter - 1);
  }
}

final homeProvider = StateNotifierProvider<HomeNotifier, HomeModel>((ref) {
  return HomeNotifier();
});
`;
  }

  if (ctx.stateManager === 'bloc') {
    return `import 'package:flutter_bloc/flutter_bloc.dart';
import '../domain/home_model.dart';

abstract class HomeEvent {}
class IncrementEvent extends HomeEvent {}
class DecrementEvent extends HomeEvent {}

class HomeBloc extends Bloc<HomeEvent, HomeModel> {
  HomeBloc() : super(const HomeModel(title: '${ctx.projectName.replace(/'/g, "\\'")}')) {
    on<IncrementEvent>((event, emit) => emit(state.copyWith(counter: state.counter + 1)));
    on<DecrementEvent>((event, emit) => emit(state.copyWith(counter: state.counter - 1)));
  }
}
`;
  }

  if (ctx.stateManager === 'getx') {
    return `import 'package:get/get.dart';

class HomeController extends GetxController {
  final counter = 0.obs;
  final title = '${ctx.projectName.replace(/'/g, "\\'")}'.obs;

  void increment() => counter.value++;
  void decrement() => counter.value--;
}
`;
  }

  // Default: ChangeNotifier (Provider / standard)
  return `import 'package:flutter/foundation.dart';
import '../domain/home_model.dart';

class HomeController extends ChangeNotifier {
  HomeModel _state = const HomeModel(title: '${ctx.projectName.replace(/'/g, "\\'")}');
  HomeModel get state => _state;

  void increment() {
    _state = _state.copyWith(counter: _state.counter + 1);
    notifyListeners();
  }

  void decrement() {
    _state = _state.copyWith(counter: _state.counter - 1);
    notifyListeners();
  }
}
`;
}

export function templateHomePage(ctx: GenContext): string {
  return `import 'package:flutter/material.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _counter = 0;

  void _increment() {
    setState(() => _counter++);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('${ctx.projectName.replace(/'/g, "\\'")}'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome to your generated app!',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${ctx.description.replace(/'/g, "\\'")}',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.textTheme.bodyMedium?.color?.withOpacity(0.8),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Chip(
                        label: Text('Arch: ${ctx.architectureName}'),
                        backgroundColor: theme.colorScheme.primaryContainer,
                      ),
                      Chip(
                        label: Text('State: ${ctx.stateName}'),
                        backgroundColor: theme.colorScheme.secondaryContainer,
                      ),
                      Chip(
                        label: Text('Backend: ${ctx.backendName}'),
                        backgroundColor: theme.colorScheme.tertiaryContainer,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            AppCard(
              child: Column(
                children: [
                  const Text('Reactive Counter Sample'),
                  const SizedBox(height: 8),
                  Text(
                    '$_counter',
                    style: theme.textTheme.displaySmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 16),
                  AppButton(
                    label: 'Increment Counter',
                    icon: Icons.add,
                    onPressed: _increment,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
`;
}

export function templateFeaturePage(featureId: string, featureName: string): string {
  return `import 'package:flutter/material.dart';

class ${capitalize(featureId)}Page extends StatelessWidget {
  const ${capitalize(featureId)}Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('${featureName}'),
      ),
      body: Center(
        child: Text('${featureName} Module Ready'),
      ),
    );
  }
}
`;
}

function capitalize(s: string): string {
  return s
    .split('_')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join('');
}
