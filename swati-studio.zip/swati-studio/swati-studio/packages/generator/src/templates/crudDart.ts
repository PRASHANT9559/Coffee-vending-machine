import type { GenContext, GeneratedFile } from '../types';

export function templateCrudFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Entity Model
  files.push({
    path: 'lib/features/products/models/product_model.dart',
    contents: `class ProductModel {
  final String id;
  final String name;
  final double price;
  final String category;
  final String? imageUrl;
  final bool inStock;
  final DateTime createdAt;

  const ProductModel({
    required this.id,
    required this.name,
    required this.price,
    required this.category,
    this.imageUrl,
    this.inStock = true,
    required this.createdAt,
  });

  factory ProductModel.fromJson(Map<String, dynamic> json) => ProductModel(
        id: json['id'] as String,
        name: json['name'] as String,
        price: (json['price'] as num).toDouble(),
        category: json['category'] as String? ?? 'General',
        imageUrl: json['image_url'] as String?,
        inStock: json['in_stock'] as bool? ?? true,
        createdAt: json['created_at'] != null
            ? DateTime.parse(json['created_at'] as String)
            : DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'price': price,
        'category': category,
        'image_url': imageUrl,
        'in_stock': inStock,
        'created_at': createdAt.toIso8601String(),
      };
}
`,
  });

  // 2. Repository
  files.push({
    path: 'lib/features/products/repositories/product_repository.dart',
    contents: `import '../models/product_model.dart';

abstract class ProductRepository {
  Future<List<ProductModel>> getProducts({String? query, String? category});
  Future<ProductModel> getProductById(String id);
  Future<ProductModel> createProduct(Map<String, dynamic> data);
  Future<ProductModel> updateProduct(String id, Map<String, dynamic> data);
  Future<void> deleteProduct(String id);
}

class DefaultProductRepository implements ProductRepository {
  final List<ProductModel> _mockStore = [
    ProductModel(
      id: 'prod_1',
      name: 'Wireless Noise-Cancelling Headphones',
      price: 199.99,
      category: 'Electronics',
      inStock: true,
      createdAt: DateTime.now(),
    ),
    ProductModel(
      id: 'prod_2',
      name: 'Ergonomic Mechanical Keyboard',
      price: 129.50,
      category: 'Accessories',
      inStock: true,
      createdAt: DateTime.now(),
    ),
  ];

  @override
  Future<List<ProductModel>> getProducts({String? query, String? category}) async {
    await Future.delayed(const Duration(milliseconds: 300));
    var list = _mockStore;
    if (query != null && query.isNotEmpty) {
      list = list.where((p) => p.name.toLowerCase().contains(query.toLowerCase())).toList();
    }
    return list;
  }

  @override
  Future<ProductModel> getProductById(String id) async {
    return _mockStore.firstWhere((p) => p.id == id);
  }

  @override
  Future<ProductModel> createProduct(Map<String, dynamic> data) async {
    final newProd = ProductModel(
      id: 'prod_\${DateTime.now().millisecondsSinceEpoch}',
      name: data['name'] as String,
      price: (data['price'] as num).toDouble(),
      category: data['category'] as String? ?? 'General',
      inStock: data['in_stock'] as bool? ?? true,
      createdAt: DateTime.now(),
    );
    _mockStore.insert(0, newProd);
    return newProd;
  }

  @override
  Future<ProductModel> updateProduct(String id, Map<String, dynamic> data) async {
    final idx = _mockStore.indexWhere((p) => p.id == id);
    if (idx >= 0) {
      _mockStore[idx] = ProductModel(
        id: id,
        name: data['name'] ?? _mockStore[idx].name,
        price: data['price'] != null ? (data['price'] as num).toDouble() : _mockStore[idx].price,
        category: data['category'] ?? _mockStore[idx].category,
        inStock: data['in_stock'] ?? _mockStore[idx].inStock,
        createdAt: _mockStore[idx].createdAt,
      );
      return _mockStore[idx];
    }
    throw Exception('Product not found');
  }

  @override
  Future<void> deleteProduct(String id) async {
    _mockStore.removeWhere((p) => p.id == id);
  }
}
`,
  });

  // 3. Controller
  files.push({
    path: 'lib/features/products/controllers/product_controller.dart',
    contents: `import 'package:flutter/foundation.dart';
import '../models/product_model.dart';
import '../repositories/product_repository.dart';

class ProductController extends ChangeNotifier {
  final ProductRepository repository;
  List<ProductModel> products = [];
  bool isLoading = false;
  String? errorMessage;
  String searchQuery = '';

  ProductController({required this.repository});

  Future<void> fetchProducts() async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      products = await repository.getProducts(query: searchQuery);
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  void updateSearch(String query) {
    searchQuery = query;
    fetchProducts();
  }

  Future<void> delete(String id) async {
    await repository.deleteProduct(id);
    products.removeWhere((p) => p.id == id);
    notifyListeners();
  }
}
`,
  });

  // 4. Product List Screen
  files.push({
    path: 'lib/features/products/screens/product_list_screen.dart',
    contents: `import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../repositories/product_repository.dart';
import '../controllers/product_controller.dart';
import '../widgets/product_card.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  late final ProductController _controller;

  @override
  void initState() {
    super.initState();
    _controller = ProductController(repository: DefaultProductRepository());
    _controller.fetchProducts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Products Catalog'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => Navigator.of(context).pushNamed('/products/create'),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: _controller,
        builder: (context, _) {
          if (_controller.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (_controller.products.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.inventory_2_outlined, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No products available yet.', style: TextStyle(color: Colors.grey)),
                ],
              ),
            );
          }

          return RefreshIndicator(
            onRefresh: _controller.fetchProducts,
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _controller.products.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final product = _controller.products[index];
                return ProductCardWidget(
                  product: product,
                  onDelete: () => _controller.delete(product.id),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
`,
  });

  // 5. Product Form Screen (Create & Edit)
  files.push({
    path: 'lib/features/products/screens/product_form_screen.dart',
    contents: `import 'package:flutter/material.dart';
import '../models/product_model.dart';

class ProductFormScreen extends StatefulWidget {
  final ProductModel? existingProduct;

  const ProductFormScreen({super.key, this.existingProduct});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _priceController;
  String _category = 'Electronics';
  bool _inStock = true;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.existingProduct?.name ?? '');
    _priceController = TextEditingController(text: widget.existingProduct?.price.toString() ?? '');
    _category = widget.existingProduct?.category ?? 'Electronics';
    _inStock = widget.existingProduct?.inStock ?? true;
  }

  void _save() {
    if (_formKey.currentState?.validate() ?? false) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Product saved successfully.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existingProduct == null ? 'Add Product' : 'Edit Product'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Product Name', border: OutlineInputBorder()),
                validator: (val) => val == null || val.isEmpty ? 'Please enter name' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _priceController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Price (\$)', border: OutlineInputBorder()),
                validator: (val) => double.tryParse(val ?? '') == null ? 'Please enter valid price' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()),
                items: ['Electronics', 'Accessories', 'Fashion', 'Home']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (val) => setState(() => _category = val ?? 'Electronics'),
              ),
              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('Available In Stock'),
                value: _inStock,
                onChanged: (val) => setState(() => _inStock = val),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _save,
                child: const Text('Save Record'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
`,
  });

  // 6. Product Card Widget
  files.push({
    path: 'lib/features/products/widgets/product_card.dart',
    contents: `import 'package:flutter/material.dart';
import '../models/product_model.dart';

class ProductCardWidget extends StatelessWidget {
  final ProductModel product;
  final VoidCallback onDelete;

  const ProductCardWidget({
    super.key,
    required this.product,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Theme.of(context).dividerColor),
      ),
      child: ListTile(
        title: Text(product.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('\${product.category} · \$\${product.price.toStringAsFixed(2)}'),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.red),
          onPressed: onDelete,
        ),
      ),
    );
  }
}
`,
  });

  return files;
}
