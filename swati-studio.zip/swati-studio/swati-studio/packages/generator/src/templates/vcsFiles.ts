import type { GenContext, GeneratedFile } from '../types';

export function templateVcsFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. .gitignore (Flutter & IDE optimized)
  files.push({
    path: '.gitignore',
    contents: `# Flutter / Dart generated
.dart_tool/
.flutter-plugins
.flutter-plugins-dependencies
.packages
build/
ephemeral/

# Android generated
.gradle
local.properties
**/android/**/gradle-wrapper.jar
android/key.properties

# iOS generated
**/ios/**/*.mode1v3
**/ios/**/*.mode2v3
**/ios/**/*.moved-aside
**/ios/**/*.pbxuser
**/ios/**/*.perspectivev3
**/ios/**/Pods/
**/ios/**/.symlinks/

# Environment secrets
*.env
*.key
*.jks

# IDE configs
.idea/
.vscode/
*.swp
*.DS_Store
`,
  });

  // 2. CONTRIBUTING.md
  files.push({
    path: 'CONTRIBUTING.md',
    contents: `# Contributing to ${ctx.projectName}

Thank you for your interest in contributing!

## 1. Development Workflow
1. Fork the repository and create your feature branch from \`develop\`:
   \`\`\`bash
   git checkout -b feature/amazing-feature
   \`\`\`
2. Install dependencies:
   \`\`\`bash
   flutter pub get
   \`\`\`
3. Verify formatting and linting:
   \`\`\`bash
   dart format .
   flutter analyze
   \`\`\`
4. Run test suite:
   \`\`\`bash
   flutter test
   \`\`\`

## 2. Commit Message Convention
We adhere to **Conventional Commits**:
- \`feat: add biometric app lock\`
- \`fix: resolve null check on user sign out\`
- \`docs: update README runbook\`
- \`test: add unit tests for auth repository\`
`,
  });

  // 3. CHANGELOG.md
  files.push({
    path: 'CHANGELOG.md',
    contents: `# Changelog

All notable changes to ${ctx.projectName} will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] - ${new Date().toISOString().split('T')[0]}
### Added
- Initial project scaffolding via Swati Studio.
- Multi-theme support with responsive light, dark, and AMOLED modes.
- Core navigation structure with dynamic feature screens.
- Offline-first cache engine with background synchronization.
- Authentication repository, secure storage, and route guards.
`,
  });

  // 4. PR Template
  files.push({
    path: '.github/pull_request_template.md',
    contents: `## Description
<!-- Provide a brief overview of changes made -->

## Type of Change
- [ ] 🚀 New feature
- [ ] 🐛 Bug fix
- [ ] ⚡ Performance improvement
- [ ] 📝 Documentation update
- [ ] 🧪 Tests addition

## Checklist
- [ ] Code follows project formatting (\`dart format .\`)
- [ ] Code passes analysis (\`flutter analyze\`)
- [ ] Added corresponding unit or widget tests
- [ ] Tested on target platforms
`,
  });

  // 5. Bug Report Issue Template
  files.push({
    path: '.github/ISSUE_TEMPLATE/bug_report.md',
    contents: `---
name: Bug Report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Device Information:**
 - Device: [e.g. Pixel 8, iPhone 15]
 - OS: [e.g. Android 14, iOS 17]
 - Flutter Version: [e.g. 3.27.x]
`,
  });

  // 6. Feature Request Issue Template
  files.push({
    path: '.github/ISSUE_TEMPLATE/feature_request.md',
    contents: `---
name: Feature Request
about: Suggest an idea for this project
title: '[FEAT] '
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem? Please describe.**
A clear description of what the problem is.

**Describe the solution you'd like**
A clear description of what you want to happen.

**Describe alternatives you've considered**
Any alternative solutions or features considered.
`,
  });

  // 7. Code of Conduct
  files.push({
    path: 'CODE_OF_CONDUCT.md',
    contents: `# Contributor Covenant Code of Conduct

## Our Pledge
We pledge to make participation in our community a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, caste, color, religion, or sexual identity and orientation.

## Our Standards
Examples of behavior that contributes to a positive environment:
* Demonstrating empathy and kindness toward other people
* Being respectful of differing opinions, viewpoints, and experiences
* Giving and gracefully accepting constructive feedback

## Enforcement
Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the project maintainers.
`,
  });

  return files;
}
