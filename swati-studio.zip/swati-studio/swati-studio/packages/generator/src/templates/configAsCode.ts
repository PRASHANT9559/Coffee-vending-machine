import type { GenContext, GeneratedFile } from '../types';
import { serializeSwatiYaml, generateSwatiJsonSchema } from '@swati/schema';

export function templateConfigAsCodeFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. swati.yaml (Config-as-Code Source of Truth)
  files.push({
    path: 'swati.yaml',
    contents: serializeSwatiYaml(ctx.rawConfig),
  });

  // 2. .swati/schema/swati.schema.json (VS Code / JetBrains autocomplete)
  files.push({
    path: '.swati/schema/swati.schema.json',
    contents: JSON.stringify(generateSwatiJsonSchema(), null, 2) + '\n',
  });

  // 3. .swati/manifest.json (Feature #26 Regeneration-Safe Manifest)
  const initialManifest = {
    schemaVersion: 3,
    appName: ctx.name,
    package: ctx.package,
    createdAt: new Date().toISOString(),
    ownershipRules: {
      generated: ['lib/config/app_routes.dart', 'lib/core/network/api_client.dart', 'lib/core/theme/app_theme.dart'],
      scaffold: ['lib/features/home/home_screen.dart', 'lib/features/auth/screens/login_screen.dart'],
      hybrid: ['lib/main.dart', 'pubspec.yaml', 'docs/ARCHITECTURE.md'],
    },
  };

  files.push({
    path: '.swati/manifest.json',
    contents: JSON.stringify(initialManifest, null, 2) + '\n',
  });

  return files;
}
