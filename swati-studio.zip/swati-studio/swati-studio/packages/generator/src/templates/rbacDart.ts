import type { GenContext, GeneratedFile } from '../types';

export function templateRbacFiles(ctx: GenContext): GeneratedFile[] {
  if (!ctx.enableRbac) return [];

  const files: GeneratedFile[] = [];

  // UserRole Enum
  files.push({
    path: 'lib/core/auth/models/user_role.dart',
    contents: `/// Enterprise Role-Based Access Control (RBAC)
enum UserRole {
  admin,
  manager,
  user,
  viewer,
  guest;

  bool get isAdmin => this == UserRole.admin;
  bool get canWrite => this == UserRole.admin || this == UserRole.manager || this == UserRole.user;
  bool get canDelete => this == UserRole.admin;
  bool get canManageUsers => this == UserRole.admin;

  static UserRole fromString(String? role) {
    switch (role?.toLowerCase()) {
      case 'admin':
        return UserRole.admin;
      case 'manager':
        return UserRole.manager;
      case 'viewer':
        return UserRole.viewer;
      case 'guest':
        return UserRole.guest;
      case 'user':
      default:
        return UserRole.user;
    }
  }
}
`,
  });

  // Role Guard
  files.push({
    path: 'lib/core/auth/guards/role_guard.dart',
    contents: `import '../models/user_role.dart';

class RoleGuard {
  static bool hasAccess({
    required UserRole userRole,
    required List<UserRole> allowedRoles,
  }) {
    if (userRole == UserRole.admin) return true;
    return allowedRoles.contains(userRole);
  }
}
`,
  });

  // RoleBasedWidget
  files.push({
    path: 'lib/core/auth/widgets/role_based_widget.dart',
    contents: `import 'package:flutter/material.dart';
import '../models/user_role.dart';
import '../guards/role_guard.dart';

class RoleBasedWidget extends StatelessWidget {
  final UserRole currentRole;
  final List<UserRole> allowedRoles;
  final Widget child;
  final Widget? fallback;

  const RoleBasedWidget({
    super.key,
    required this.currentRole,
    required this.allowedRoles,
    required this.child,
    this.fallback,
  });

  @override
  Widget build(BuildContext context) {
    final canView = RoleGuard.hasAccess(
      userRole: currentRole,
      allowedRoles: allowedRoles,
    );

    if (canView) return child;
    return fallback ?? const SizedBox.shrink();
  }
}
`,
  });

  return files;
}
