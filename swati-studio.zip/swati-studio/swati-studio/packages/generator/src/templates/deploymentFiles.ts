import type { GenContext, GeneratedFile } from '../types';

export function templateDeploymentFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // Short description (Max 80 chars)
  const shortDesc = `${ctx.projectName} — ${ctx.description}`.slice(0, 80);
  files.push({
    path: 'deployment/store_listing/short_description.txt',
    contents: shortDesc,
  });

  // Full description (Rich formatted for Google Play Store & Apple App Store)
  const fullDesc = `# ${ctx.projectName}

${ctx.description}

Key Highlights:
- 🚀 Lightning-fast cross-platform performance engineered with Flutter
- 🎨 Modern aesthetic UI with responsive light, dark, and AMOLED modes
- 📶 Offline-first architecture with instant data caching
- 🔒 Secure authentication and encrypted session storage
- 🌐 Internationalized with multilingual localization support

Built with love using Swati Studio.
`;
  files.push({
    path: 'deployment/store_listing/full_description.txt',
    contents: fullDesc,
  });

  // ASO Keywords
  const keywords = [
    ctx.projectName.toLowerCase(),
    'flutter',
    'mobile app',
    'productivity',
    'cross platform',
    ctx.themeColor,
  ].join(', ');
  files.push({
    path: 'deployment/store_listing/keywords.txt',
    contents: keywords,
  });

  // Changelogs v1.0.0
  files.push({
    path: 'deployment/store_listing/changelogs/v1.0.0.txt',
    contents: `Version 1.0.0
- Initial official release of ${ctx.projectName}
- Core navigation and dynamic interactive features
- Offline synchronization and security hardening
`,
  });

  // Android key.properties.example
  files.push({
    path: 'android/key.properties.example',
    contents: `storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=upload
storeFile=/path/to/upload-keystore.jks
`,
  });

  // iOS ExportOptions.plist
  files.push({
    path: 'ios/ExportOptions.plist',
    contents: `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>app-store</string>
    <key>uploadSymbols</key>
    <true/>
    <key>uploadBitcode</key>
    <false/>
</dict>
</plist>
`,
  });

  return files;
}
