import type { GenContext, GeneratedFile } from '../types';

export function templatePushNotificationFiles(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];

  // 1. Notification Model / Payload
  files.push({
    path: 'lib/core/notifications/models/notification_payload.dart',
    contents: `class NotificationPayload {
  final String id;
  final String title;
  final String body;
  final String? type;
  final String? targetRoute;
  final Map<String, dynamic> data;
  final DateTime receivedAt;

  const NotificationPayload({
    required this.id,
    required this.title,
    required this.body,
    this.type,
    this.targetRoute,
    this.data = const {},
    required this.receivedAt,
  });

  factory NotificationPayload.fromMap(Map<String, dynamic> map) {
    return NotificationPayload(
      id: map['id']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: map['title']?.toString() ?? '',
      body: map['body']?.toString() ?? '',
      type: map['type']?.toString(),
      targetRoute: map['target_route']?.toString() ?? map['route']?.toString(),
      data: Map<String, dynamic>.from(map['data'] as Map? ?? {}),
      receivedAt: DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'body': body,
        'type': type,
        'target_route': targetRoute,
        'data': data,
        'received_at': receivedAt.toIso8601String(),
      };
}
`,
  });

  // 2. Notification Channels (Android Importance & Channels)
  files.push({
    path: 'lib/core/notifications/notification_channels.dart',
    contents: `class NotificationChannels {
  NotificationChannels._();

  static const String ordersChannelId = 'orders_channel';
  static const String ordersChannelName = 'Order Updates';
  static const String ordersChannelDesc = 'Real-time notifications for order status and tracking';

  static const String chatChannelId = 'chat_channel';
  static const String chatChannelName = 'Messages & Support';
  static const String chatChannelDesc = 'Important user communications and messages';

  static const String promosChannelId = 'promos_channel';
  static const String promosChannelName = 'Promotions & Offers';
  static const String promosChannelDesc = 'Discounts, seasonal sales and special offers';

  static List<Map<String, dynamic>> getAllChannels() => [
        {
          'id': ordersChannelId,
          'name': ordersChannelName,
          'description': ordersChannelDesc,
          'importance': 'high',
          'sound': true,
          'vibrate': true,
        },
        {
          'id': chatChannelId,
          'name': chatChannelName,
          'description': chatChannelDesc,
          'importance': 'high',
          'sound': true,
          'vibrate': true,
        },
        {
          'id': promosChannelId,
          'name': promosChannelName,
          'description': promosChannelDesc,
          'importance': 'default',
          'sound': false,
          'vibrate': false,
        },
      ];
}
`,
  });

  // 3. Notification Router (Payload -> Target Screen Navigation)
  files.push({
    path: 'lib/core/notifications/notification_router.dart',
    contents: `import 'package:flutter/material.dart';
import 'models/notification_payload.dart';

typedef RouteNavigator = void Function(String route, {Object? arguments});

class NotificationRouter {
  final GlobalKey<NavigatorState> navigatorKey;

  NotificationRouter({required this.navigatorKey});

  void handleNotificationTap(NotificationPayload payload) {
    debugPrint('[NotificationRouter] Handling notification tap: \${payload.type} -> \${payload.targetRoute}');

    if (payload.targetRoute != null && payload.targetRoute!.isNotEmpty) {
      navigatorKey.currentState?.pushNamed(
        payload.targetRoute!,
        arguments: payload.data,
      );
      return;
    }

    // Default route resolver by notification type
    switch (payload.type) {
      case 'order':
        final orderId = payload.data['order_id'];
        navigatorKey.currentState?.pushNamed('/orders', arguments: orderId);
        break;
      case 'product':
        final productId = payload.data['product_id'];
        navigatorKey.currentState?.pushNamed('/products', arguments: productId);
        break;
      case 'chat':
        navigatorKey.currentState?.pushNamed('/chat');
        break;
      default:
        navigatorKey.currentState?.pushNamed('/home');
    }
  }
}
`,
  });

  // 4. Local Notification Service
  files.push({
    path: 'lib/core/notifications/local_notification_service.dart',
    contents: `import 'package:flutter/foundation.dart';
import 'models/notification_payload.dart';
import 'notification_channels.dart';

class LocalNotificationService {
  LocalNotificationService._();
  static final LocalNotificationService instance = LocalNotificationService._();

  bool _initialized = false;
  void Function(NotificationPayload)? onNotificationTapped;

  Future<void> initialize({void Function(NotificationPayload)? onTapped}) async {
    if (_initialized) return;
    onNotificationTapped = onTapped;
    debugPrint('[LocalNotificationService] Initializing notification channels...');
    // Simulated native setup for local notification display
    _initialized = true;
  }

  Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    String channelId = NotificationChannels.ordersChannelId,
    Map<String, dynamic>? payloadData,
  }) async {
    debugPrint('[LocalNotificationService] Displaying banner: [$channelId] \$title - \$body');
    // Native plugin display triggered here
  }

  void simulateTap(NotificationPayload payload) {
    onNotificationTapped?.call(payload);
  }
}
`,
  });

  // 5. FCM / Remote Notification Handler
  files.push({
    path: 'lib/core/notifications/fcm_handler.dart',
    contents: `import 'package:flutter/foundation.dart';
import 'models/notification_payload.dart';
import 'local_notification_service.dart';

/// Top-level background message handler
Future<void> firebaseMessagingBackgroundHandler(Map<String, dynamic> message) async {
  debugPrint('[FCM Background] Received message in background: \${message['messageId']}');
}

class FcmHandler {
  final LocalNotificationService localNotifications;
  final void Function(NotificationPayload) onPayloadReceived;

  FcmHandler({
    required this.localNotifications,
    required this.onPayloadReceived,
  });

  void handleForegroundMessage(Map<String, dynamic> remoteMessage) {
    debugPrint('[FCM Foreground] Message received: \${remoteMessage['notification']}');
    final title = remoteMessage['title'] ?? 'New Notification';
    final body = remoteMessage['body'] ?? '';
    final data = Map<String, dynamic>.from(remoteMessage['data'] ?? {});

    final payload = NotificationPayload(
      id: remoteMessage['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      body: body,
      type: data['type']?.toString(),
      targetRoute: data['route']?.toString(),
      data: data,
      receivedAt: DateTime.now(),
    );

    // Show local heads-up notification in foreground
    localNotifications.showNotification(
      id: payload.id.hashCode,
      title: payload.title,
      body: payload.body,
      payloadData: payload.data,
    );

    onPayloadReceived(payload);
  }

  void handleMessageOpenedApp(Map<String, dynamic> remoteMessage) {
    debugPrint('[FCM Background/Resume] User tapped notification from background');
    final payload = NotificationPayload.fromMap(remoteMessage);
    onPayloadReceived(payload);
  }
}
`,
  });

  // 6. Primary Notification Service Facade
  files.push({
    path: 'lib/core/notifications/notification_service.dart',
    contents: `import 'package:flutter/foundation.dart';
import 'local_notification_service.dart';
import 'models/notification_payload.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  String? _fcmToken;
  bool _hasPermission = false;

  String? get fcmToken => _fcmToken;
  bool get hasPermission => _hasPermission;

  Future<void> initialize({
    required void Function(NotificationPayload) onNotificationTapped,
  }) async {
    debugPrint('[NotificationService] Initializing Push Notifications for ${ctx.name}...');
    await LocalNotificationService.instance.initialize(onTapped: onNotificationTapped);
    await requestPermissions();
    await _fetchDeviceToken();
  }

  Future<bool> requestPermissions() async {
    debugPrint('[NotificationService] Requesting notification permissions...');
    // Requests POST_NOTIFICATIONS on Android 13+ and alert/sound/badge on iOS
    _hasPermission = true;
    return _hasPermission;
  }

  Future<String?> _fetchDeviceToken() async {
    // Generate or retrieve mock/real device push registration token
    _fcmToken = 'mock_fcm_token_\${DateTime.now().millisecondsSinceEpoch}';
    debugPrint('[NotificationService] Device Push Token: \$_fcmToken');
    return _fcmToken;
  }

  Future<void> subscribeToTopic(String topic) async {
    debugPrint('[NotificationService] Subscribed to topic: \$topic');
  }

  Future<void> unsubscribeFromTopic(String topic) async {
    debugPrint('[NotificationService] Unsubscribed from topic: \$topic');
  }
}
`,
  });

  return files;
}
