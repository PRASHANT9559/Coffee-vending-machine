import type { StudioConfig } from '@swati/schema';
import { buildContext } from './context';
import { assemblePlan } from './plan';
import type { GeneratedFile, GenerateResult } from './types';
import type { ExportedScreen } from './templates/screenDart';

/**
 * Pure generator function: StudioConfig in -> real file tree + summary out.
 * Optionally accepts custom screens from the visual screen builder.
 */
export function generateProject(
  config: StudioConfig,
  screens?: ExportedScreen[]
): GenerateResult {
  const context = buildContext(config);
  if (screens && screens.length > 0) {
    context.screens = screens;
  }

  const files: GeneratedFile[] = assemblePlan(context);

  const directoriesSet = new Set<string>();
  let totalBytes = 0;

  for (const file of files) {
    totalBytes += file.contents.length;
    const parts = file.path.split('/');
    if (parts.length > 1) {
      parts.pop(); // remove filename
      directoriesSet.add(parts.join('/'));
    }
  }

  const summary = {
    files: files.length,
    directories: Array.from(directoriesSet).sort(),
    packages: context.packages.length,
    estimatedSizeKb: Math.ceil(totalBytes / 1024),
  };

  return {
    files,
    summary,
    context,
  };
}
