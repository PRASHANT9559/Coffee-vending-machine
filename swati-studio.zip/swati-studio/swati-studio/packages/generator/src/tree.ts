import type { GeneratedFile, TreeNode } from './types';

export function buildTree(files: GeneratedFile[]): TreeNode {
  const root: TreeNode = {
    name: 'root',
    path: '',
    isFile: false,
    children: [],
  };

  for (const file of files) {
    const parts = file.path.split('/').filter(Boolean);
    let current = root;

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      const isLast = i === parts.length - 1;
      const currentPath = parts.slice(0, i + 1).join('/');

      let existing = current.children.find((child) => child.name === part);

      if (!existing) {
        existing = {
          name: part,
          path: currentPath,
          isFile: isLast,
          children: [],
        };
        current.children.push(existing);
      }

      current = existing;
    }
  }

  // Sort recursively: directories first, then alphabetical
  function sortNode(node: TreeNode) {
    node.children.sort((a, b) => {
      if (a.isFile !== b.isFile) {
        return a.isFile ? 1 : -1;
      }
      return a.name.localeCompare(b.name);
    });
    for (const child of node.children) {
      if (!child.isFile) {
        sortNode(child);
      }
    }
  }

  sortNode(root);
  return root;
}
