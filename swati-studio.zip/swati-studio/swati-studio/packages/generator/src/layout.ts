import type { GenContext } from './types';

export interface ArchitectureLayout {
  homeFiles: {
    controllerPath: string;
    pagePath: string;
    modelPath: string;
  };
  featureFolder: (featureName: string) => {
    presentation: string;
    domain: string;
    data: string;
  };
  directories: string[];
}

export function layoutFor(ctx: GenContext): ArchitectureLayout {
  const arch = ctx.architecture;

  if (arch === 'clean') {
    return {
      homeFiles: {
        pagePath: 'lib/presentation/pages/home_page.dart',
        controllerPath: 'lib/presentation/controllers/home_controller.dart',
        modelPath: 'lib/domain/entities/home_entity.dart',
      },
      featureFolder: (f: string) => ({
        presentation: `lib/presentation/${f}`,
        domain: `lib/domain/${f}`,
        data: `lib/data/${f}`,
      }),
      directories: [
        'lib/core/constants',
        'lib/core/network',
        'lib/core/theme',
        'lib/core/widgets',
        'lib/data/datasources',
        'lib/data/models',
        'lib/data/repositories',
        'lib/domain/entities',
        'lib/domain/repositories',
        'lib/domain/usecases',
        'lib/presentation/controllers',
        'lib/presentation/pages',
        'lib/presentation/widgets',
        'test',
      ],
    };
  }

  if (arch === 'ddd') {
    return {
      homeFiles: {
        pagePath: 'lib/presentation/home/home_page.dart',
        controllerPath: 'lib/application/home/home_service.dart',
        modelPath: 'lib/domain/home/home_aggregate.dart',
      },
      featureFolder: (f: string) => ({
        presentation: `lib/presentation/${f}`,
        domain: `lib/domain/${f}`,
        data: `lib/infrastructure/${f}`,
      }),
      directories: [
        'lib/core/theme',
        'lib/core/widgets',
        'lib/domain/home',
        'lib/application/home',
        'lib/infrastructure/home',
        'lib/presentation/home',
        'test',
      ],
    };
  }

  if (arch === 'mvvm') {
    return {
      homeFiles: {
        pagePath: 'lib/views/home_view.dart',
        controllerPath: 'lib/view_models/home_view_model.dart',
        modelPath: 'lib/models/home_model.dart',
      },
      featureFolder: (f: string) => ({
        presentation: `lib/views/${f}`,
        domain: `lib/view_models/${f}`,
        data: `lib/models/${f}`,
      }),
      directories: [
        'lib/core/theme',
        'lib/core/widgets',
        'lib/models',
        'lib/views',
        'lib/view_models',
        'lib/services',
        'test',
      ],
    };
  }

  if (arch === 'layer_first' || arch === 'mvc') {
    return {
      homeFiles: {
        pagePath: 'lib/views/home_view.dart',
        controllerPath: 'lib/controllers/home_controller.dart',
        modelPath: 'lib/models/home_model.dart',
      },
      featureFolder: (f: string) => ({
        presentation: `lib/views/${f}`,
        domain: `lib/models/${f}`,
        data: `lib/controllers/${f}`,
      }),
      directories: [
        'lib/core/theme',
        'lib/core/widgets',
        'lib/models',
        'lib/views',
        'lib/controllers',
        'lib/services',
        'test',
      ],
    };
  }

  // Default: feature_first
  return {
    homeFiles: {
      pagePath: 'lib/features/home/presentation/home_page.dart',
      controllerPath: 'lib/features/home/presentation/home_controller.dart',
      modelPath: 'lib/features/home/domain/home_model.dart',
    },
    featureFolder: (f: string) => ({
      presentation: `lib/features/${f}/presentation`,
      domain: `lib/features/${f}/domain`,
      data: `lib/features/${f}/data`,
    }),
    directories: [
      'lib/config',
      'lib/core/constants',
      'lib/core/network',
      'lib/core/theme',
      'lib/core/widgets',
      'lib/features/home/presentation',
      'lib/features/home/domain',
      'lib/features/home/data',
      'test',
    ],
  };
}
