import {
  serializeConfig,
  generateSqlMigration,
  generateMermaidErd,
  type DatabaseDesignSchema,
} from '@swati/schema';
import { layoutFor } from './layout';
import { templateAnalysisOptions } from './templates/analysisOptions';
import { templateApiClient } from './templates/apiClientDart';
import { templateAppDart } from './templates/appDart';
import { templateAppRoutes } from './templates/appRoutesDart';
import {
  templateFeaturePage,
  templateHomeController,
  templateHomeModel,
  templateHomePage,
} from './templates/featureDart';
import { templateMainDart } from './templates/mainDart';
import { templateNavigationWidget } from './templates/navigationDart';
import { templateNavScreen } from './templates/navScreenDart';
import { templatePubspec } from './templates/pubspec';
import { templateReadme } from './templates/readme';
import { generateAllScreensDart } from './templates/screenDart';
import { templateWidgetTest } from './templates/testDart';
import { templateAppTheme, templateDesignTokens } from './templates/themeDart';
import { templateAuthFiles } from './templates/authDart';
import { templateEnvironmentFiles } from './templates/envDart';
import { templateCicdFiles } from './templates/cicdYaml';
import { templateRbacFiles } from './templates/rbacDart';
import { templateDesignTokenExports } from './templates/tokenExports';
import { templateI18nFiles } from './templates/i18nDart';
import { templateOnboardingFiles } from './templates/onboardingDart';
import { templateMonetizationFiles } from './templates/monetizationDart';
import { templateSecurityFiles } from './templates/securityDart';
import { templateAnalyticsFiles } from './templates/analyticsDart';
import { templateDeepLinkingFiles } from './templates/deepLinkingDart';
import { templateDeploymentFiles } from './templates/deploymentFiles';
import { templateOfflineFiles } from './templates/offlineDart';
import { templateTestingFiles } from './templates/testingDart';
import { templateVcsFiles } from './templates/vcsFiles';
import { templateCrudFiles } from './templates/crudDart';
import { templatePushNotificationFiles } from './templates/pushNotificationsDart';
import { templateRemoteConfigFiles } from './templates/remoteConfigDart';
import { templateBackendScaffold } from './templates/backendScaffold';
import { templateComplianceFiles } from './templates/complianceFiles';
import { templateUiStatesFiles } from './templates/uiStatesDart';
import { templateBrandingFiles } from './templates/brandingFiles';
import { templateMockDataFiles } from './templates/mockDataDart';
import { templateResponsiveFiles } from './templates/responsiveDart';
import { templatePerfBudgetFiles } from './templates/perfBudgetFiles';
import { templateAutoDocsFiles } from './templates/autoDocsFiles';
import { templateConfigAsCodeFiles } from './templates/configAsCode';
import {
  templateAppButton,
  templateAppCard,
  templateAppTextField,
} from './templates/widgetsDart';
import type { GeneratedFile, GenContext } from './types';

export function assemblePlan(ctx: GenContext): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const layout = layoutFor(ctx);

  // Configuration Manifest & Tooling
  files.push({
    path: 'pubspec.yaml',
    contents: templatePubspec(ctx),
  });

  files.push({
    path: 'analysis_options.yaml',
    contents: templateAnalysisOptions(),
  });

  files.push({
    path: 'README.md',
    contents: templateReadme(ctx),
  });

  files.push({
    path: 'swati-studio.config.json',
    contents: serializeConfig(ctx.rawConfig),
  });

  // Flutter Core
  files.push({
    path: 'lib/main.dart',
    contents: templateMainDart(ctx),
  });

  files.push({
    path: 'lib/app.dart',
    contents: templateAppDart(ctx),
  });

  // Core Theme
  files.push({
    path: 'lib/core/theme/design_tokens.dart',
    contents: templateDesignTokens(ctx),
  });

  files.push({
    path: 'lib/core/theme/app_theme.dart',
    contents: templateAppTheme(ctx),
  });

  // Core Network
  files.push({
    path: 'lib/core/network/api_client.dart',
    contents: templateApiClient(ctx),
  });

  // Core Shared Widgets
  files.push({
    path: 'lib/core/widgets/app_button.dart',
    contents: templateAppButton(ctx),
  });

  files.push({
    path: 'lib/core/widgets/app_card.dart',
    contents: templateAppCard(ctx),
  });

  files.push({
    path: 'lib/core/widgets/app_text_field.dart',
    contents: templateAppTextField(ctx),
  });

  // Navigation Widget & Routes
  files.push({
    path: 'lib/core/widgets/app_navigation.dart',
    contents: templateNavigationWidget(ctx),
  });

  files.push({
    path: 'lib/config/app_routes.dart',
    contents: templateAppRoutes(ctx),
  });

  // Dynamic Navigation Screens (1 screen per button with matching AppBar title)
  const navItems = ctx.navigationItems && ctx.navigationItems.length > 0
    ? ctx.navigationItems
    : [
        { id: '1', name: 'Home', title: 'Home', icon: 'Home', route: '/home' },
        { id: '2', name: 'Search', title: 'Search', icon: 'Search', route: '/search' },
        { id: '3', name: 'Profile', title: 'Profile', icon: 'User', route: '/profile' },
      ];

  for (const item of navItems) {
    const slug = item.name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    files.push({
      path: `lib/features/${slug}/${slug}_screen.dart`,
      contents: templateNavScreen(item, ctx),
    });
  }

  // Uploaded Database File Asset (if user provided one)
  if (ctx.databaseFile) {
    files.push({
      path: `assets/db/${ctx.databaseFile.name}`,
      contents: ctx.databaseFile.contentBase64
        ? Buffer.from(ctx.databaseFile.contentBase64, 'base64').toString('utf-8')
        : `-- Swati Studio Imported Database: ${ctx.databaseFile.name}\n-- Format: ${ctx.databaseFile.extension}\n-- Size: ${ctx.databaseFile.size} bytes\n`,
    });
  }

  // Architecture-based Home Module
  files.push({
    path: layout.homeFiles.pagePath,
    contents: templateHomePage(ctx),
  });

  files.push({
    path: layout.homeFiles.controllerPath,
    contents: templateHomeController(ctx),
  });

  files.push({
    path: layout.homeFiles.modelPath,
    contents: templateHomeModel(ctx),
  });

  // Selected Features
  for (const featureId of ctx.features) {
    const featurePaths = layout.featureFolder(featureId);
    files.push({
      path: `${featurePaths.presentation}/${featureId}_page.dart`,
      contents: templateFeaturePage(featureId, featureId.replace(/_/g, ' ')),
    });
  }

  // Custom Screens from Visual Screen Builder
  if (ctx.screens && ctx.screens.length > 0) {
    const screenFiles = generateAllScreensDart(ctx.screens, ctx);
    files.push(...screenFiles);
  }

  // Smoke Test
  files.push({
    path: 'test/widget_test.dart',
    contents: templateWidgetTest(ctx),
  });

  // Enterprise: Auth Flow Builder (Feature 3)
  files.push(...templateAuthFiles(ctx));

  // Enterprise: Multi-Environment Flavors (Feature 6)
  files.push(...templateEnvironmentFiles(ctx));

  // Enterprise: CI/CD Pipeline Generator (Feature 7)
  files.push(...templateCicdFiles(ctx));

  // Enterprise: Role-Based Access Control (Feature 8)
  files.push(...templateRbacFiles(ctx));

  // Enterprise: Design Token Exports (Feature 16)
  files.push(...templateDesignTokenExports(ctx));

  // Enterprise: Internationalization Setup (Feature 11)
  files.push(...templateI18nFiles(ctx));

  // Enterprise: Onboarding Flow Builder (Feature 9)
  files.push(...templateOnboardingFiles(ctx));

  // Enterprise: Monetization & In-App Purchases (Feature 10)
  files.push(...templateMonetizationFiles(ctx));

  // Enterprise: Security & Compliance Configuration (Feature 12)
  files.push(...templateSecurityFiles(ctx));

  // Enterprise: Analytics & Crash Reporting (Feature 13)
  files.push(...templateAnalyticsFiles(ctx));

  // Enterprise: Deep Linking & App Links (Feature 14)
  files.push(...templateDeepLinkingFiles(ctx));

  // Enterprise: Deployment & Store Listing (Feature 15)
  files.push(...templateDeploymentFiles(ctx));

  // Enterprise: Offline-First Architecture (Feature 17)
  files.push(...templateOfflineFiles(ctx));

  // Enterprise: Comprehensive Testing Strategy (Feature 21)
  files.push(...templateTestingFiles(ctx));

  // Enterprise: Version Control Auto-Setup & Community Templates (Feature 22)
  files.push(...templateVcsFiles(ctx));

  // Feature 28: Database Schema Designer
  const defaultDbSchema: DatabaseDesignSchema = {
    version: '20261103000000',
    tables: [
      {
        name: 'users',
        enableRls: true,
        columns: [
          { name: 'id', type: 'uuid', isPrimary: true, defaultValue: 'gen_random_uuid()' },
          { name: 'email', type: 'text', isUnique: true },
          { name: 'name', type: 'text' },
          { name: 'role', type: 'text', defaultValue: "'user'" },
          { name: 'created_at', type: 'timestamp', defaultValue: 'now()' },
        ],
      },
      {
        name: 'products',
        enableRls: true,
        columns: [
          { name: 'id', type: 'uuid', isPrimary: true, defaultValue: 'gen_random_uuid()' },
          { name: 'name', type: 'text' },
          { name: 'price', type: 'numeric', defaultValue: '0' },
          { name: 'category', type: 'text' },
          { name: 'image_url', type: 'text', nullable: true },
          { name: 'in_stock', type: 'boolean', defaultValue: 'true' },
          { name: 'created_at', type: 'timestamp', defaultValue: 'now()' },
        ],
      },
      {
        name: 'orders',
        enableRls: true,
        columns: [
          { name: 'id', type: 'uuid', isPrimary: true, defaultValue: 'gen_random_uuid()' },
          { name: 'user_id', type: 'uuid', foreignKeyTable: 'users', foreignKeyColumn: 'id' },
          { name: 'total', type: 'numeric', defaultValue: '0' },
          { name: 'status', type: 'text', defaultValue: "'pending'" },
          { name: 'created_at', type: 'timestamp', defaultValue: 'now()' },
        ],
      },
      {
        name: 'order_items',
        columns: [
          { name: 'id', type: 'uuid', isPrimary: true, defaultValue: 'gen_random_uuid()' },
          { name: 'order_id', type: 'uuid', foreignKeyTable: 'orders', foreignKeyColumn: 'id' },
          { name: 'product_id', type: 'uuid', foreignKeyTable: 'products', foreignKeyColumn: 'id' },
          { name: 'quantity', type: 'integer', defaultValue: '1' },
        ],
      },
    ],
  };

  files.push({
    path: 'supabase/migrations/20261103000000_init_schema.sql',
    contents: generateSqlMigration(defaultDbSchema),
  });

  files.push({
    path: 'docs/erd.mmd',
    contents: generateMermaidErd(defaultDbSchema),
  });

  // Feature 29: CRUD Scaffolder
  files.push(...templateCrudFiles(ctx));

  // Feature 30: Push Notification Setup
  files.push(...templatePushNotificationFiles(ctx));

  // Feature 31: Remote Config & Maintenance Mode
  files.push(...templateRemoteConfigFiles(ctx));

  // Feature 32: Backend Scaffold Generator
  files.push(...templateBackendScaffold(ctx));

  // Feature 33: Legal & Store Compliance Kit
  files.push(...templateComplianceFiles(ctx));

  // Feature 34: Standard UI States Kit
  files.push(...templateUiStatesFiles(ctx));

  // Feature 35: App Icon, Splash & Branding Generator
  files.push(...templateBrandingFiles(ctx));

  // Feature 36: Mock Data & Fake Server
  files.push(...templateMockDataFiles(ctx));

  // Feature 37: Accessibility & Responsive Layouts
  files.push(...templateResponsiveFiles(ctx));

  // Feature 38: App Size & Performance Budget
  files.push(...templatePerfBudgetFiles(ctx));

  // Feature 39: Auto Documentation Generator
  files.push(...templateAutoDocsFiles(ctx));

  // Feature 40: Headless CLI Mode & Config-as-Code
  files.push(...templateConfigAsCodeFiles(ctx));

  return files;
}
