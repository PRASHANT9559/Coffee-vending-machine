import { describe, expect, it } from 'vitest';
import { defaultConfig } from '@swati/schema';
import { buildTree, generateProject } from './index';

describe('Project Generator Engine', () => {
  it('generates a full project structure with default config', () => {
    const config = defaultConfig();
    const result = generateProject(config);

    expect(result.files.length).toBeGreaterThan(15);
    expect(result.summary.files).toBe(result.files.length);
    expect(result.summary.packages).toBeGreaterThan(0);

    const paths = result.files.map((f) => f.path);
    expect(paths).toContain('pubspec.yaml');
    expect(paths).toContain('analysis_options.yaml');
    expect(paths).toContain('README.md');
    expect(paths).toContain('swati-studio.config.json');
    expect(paths).toContain('lib/main.dart');
    expect(paths).toContain('lib/app.dart');
    expect(paths).toContain('lib/core/theme/app_theme.dart');
    expect(paths).toContain('lib/core/theme/design_tokens.dart');
    expect(paths).toContain('test/widget_test.dart');
  });

  it('updates dependencies in pubspec.yaml based on selected features', () => {
    const config = defaultConfig();
    config['backend.provider'] = 'supabase';
    config['features.selected'] = ['camera', 'payments'];

    const result = generateProject(config);
    const pubspec = result.files.find((f) => f.path === 'pubspec.yaml')?.contents ?? '';

    expect(pubspec).toContain('supabase_flutter:');
    expect(pubspec).toContain('camera:');
    expect(pubspec).toContain('flutter_stripe:');
  });

  it('adapts folder layout according to architecture selection', () => {
    const configClean = defaultConfig();
    configClean['architecture.pattern'] = 'clean';
    const cleanResult = generateProject(configClean);
    const cleanPaths = cleanResult.files.map((f) => f.path);

    expect(cleanPaths).toContain('lib/presentation/pages/home_page.dart');
    expect(cleanPaths).toContain('lib/presentation/controllers/home_controller.dart');
    expect(cleanPaths).toContain('lib/domain/entities/home_entity.dart');

    const configFeatureFirst = defaultConfig();
    configFeatureFirst['architecture.pattern'] = 'feature_first';
    const ffResult = generateProject(configFeatureFirst);
    const ffPaths = ffResult.files.map((f) => f.path);

    expect(ffPaths).toContain('lib/features/home/presentation/home_page.dart');
  });

  it('buildTree creates a hierarchical tree node representation', () => {
    const files = [
      { path: 'pubspec.yaml', contents: '' },
      { path: 'lib/main.dart', contents: '' },
      { path: 'lib/core/theme/app_theme.dart', contents: '' },
    ];

    const tree = buildTree(files);
    expect(tree.children.length).toBe(2); // lib/ and pubspec.yaml

    const libNode = tree.children.find((c) => c.name === 'lib');
    expect(libNode).toBeDefined();
    expect(libNode?.isFile).toBe(false);

    const pubspecNode = tree.children.find((c) => c.name === 'pubspec.yaml');
    expect(pubspecNode).toBeDefined();
    expect(pubspecNode?.isFile).toBe(true);
  });
});
