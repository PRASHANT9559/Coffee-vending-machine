import type { StudioConfig } from '@swati/schema';
import type { GeneratedFile, GenerateResult } from '../types';
import type { ExportedScreen } from '../templates/screenDart';

export type TargetFramework = 'flutter' | 'react-native' | 'nextjs';

export interface TargetGeneratorOptions {
  config: StudioConfig;
  screens?: ExportedScreen[];
  target: TargetFramework;
}
