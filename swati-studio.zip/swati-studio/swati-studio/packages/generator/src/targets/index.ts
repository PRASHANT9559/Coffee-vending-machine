import type { StudioConfig } from '@swati/schema';
import type { GenerateResult } from '../types';
import type { ExportedScreen } from '../templates/screenDart';
import { generateProject } from '../generator';
import { generateNextJsProject } from './nextjs';
import { generateReactNativeProject } from './react-native';
import type { TargetFramework } from './types';

export * from './types';
export * from './nextjs';
export * from './react-native';

/**
 * Unified Multi-Target Generator.
 * Supports generating:
 * - Flutter (Production Dart, MaterialApp, named routes, ThemeTokens, architecture)
 * - Next.js (TypeScript, Tailwind CSS, App Router, responsive page layout)
 * - React Native (Expo, TypeScript, React Navigation Native Stack)
 */
export function generateTargetProject(
  config: StudioConfig,
  target: TargetFramework = 'flutter',
  screens?: ExportedScreen[]
): GenerateResult {
  switch (target) {
    case 'nextjs':
      return generateNextJsProject(config, screens);
    case 'react-native':
      return generateReactNativeProject(config, screens);
    case 'flutter':
    default:
      return generateProject(config, screens);
  }
}
