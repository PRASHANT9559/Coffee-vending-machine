import type { StudioConfig } from '@swati/schema';
import type { GeneratedFile, GenerateResult } from '../../types';
import type { ExportedScreen } from '../../templates/screenDart';
import { buildContext } from '../../context';

export function generateReactNativeProject(
  config: StudioConfig,
  screens?: ExportedScreen[]
): GenerateResult {
  const ctx = buildContext(config);
  const files: GeneratedFile[] = [];

  const pkgName = String(config['project.packageName'] || 'swati-expo-app')
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '-');
  const projName = String(config['project.name'] || 'My React Native App');

  // 1. package.json
  files.push({
    path: 'package.json',
    contents: JSON.stringify(
      {
        name: pkgName,
        version: '1.0.0',
        scripts: {
          start: 'expo start',
          android: 'expo start --android',
          ios: 'expo start --ios',
          web: 'expo start --web',
        },
        dependencies: {
          expo: '~52.0.0',
          'expo-status-bar': '~2.0.0',
          react: '18.3.1',
          'react-native': '0.76.5',
          'react-native-safe-area-context': '4.12.0',
          'react-native-screens': '~4.4.0',
          '@react-navigation/native': '^7.0.0',
          '@react-navigation/native-stack': '^7.0.0',
        },
        devDependencies: {
          '@babel/core': '^7.25.0',
          '@types/react': '~18.3.12',
          typescript: '^5.3.3',
        },
        private: true,
      },
      null,
      2
    ),
  });

  // 2. app.json
  files.push({
    path: 'app.json',
    contents: JSON.stringify(
      {
        expo: {
          name: projName,
          slug: pkgName,
          version: '1.0.0',
          orientation: 'portrait',
          userInterfaceStyle: 'automatic',
          newArchEnabled: true,
          splash: {
            resizeMode: 'contain',
            backgroundColor: ctx.hexColor || '#ffffff',
          },
          ios: { supportsTablet: true },
          android: {
            adaptiveIcon: {
              backgroundColor: ctx.hexColor || '#ffffff',
            },
          },
        },
      },
      null,
      2
    ),
  });

  // 3. tsconfig.json
  files.push({
    path: 'tsconfig.json',
    contents: JSON.stringify(
      {
        extends: 'expo/tsconfig.base',
        compilerOptions: {
          strict: true,
        },
      },
      null,
      2
    ),
  });

  // 4. App.tsx with Stack Navigator & Screen Builder screens
  const screenList = screens && screens.length > 0 ? screens : [
    {
      id: 'screen-home',
      name: 'HomeScreen',
      route: '/',
      isInitial: true,
      components: [],
    },
  ];

  const screenImports = screenList
    .map(
      (s) =>
        `import { ${s.name.replace(/[^a-zA-Z0-9]/g, '')}Screen } from './src/screens/${s.name.replace(/[^a-zA-Z0-9]/g, '')}Screen';`
    )
    .join('\n');

  const stackScreens = screenList
    .map(
      (s) =>
        `        <Stack.Screen name="${s.name.replace(/[^a-zA-Z0-9]/g, '')}" component={${s.name.replace(/[^a-zA-Z0-9]/g, '')}Screen} options={{ title: '${s.name}' }} />`
    )
    .join('\n');

  files.push({
    path: 'App.tsx',
    contents: `import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
${screenImports}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <Stack.Navigator
        initialRouteName="${screenList[0].name.replace(/[^a-zA-Z0-9]/g, '')}"
        screenOptions={{
          headerStyle: { backgroundColor: '${ctx.hexColor || '#4F46E5'}' },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
${stackScreens}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
`,
  });

  // 5. Generate screen files in src/screens/
  for (const screen of screenList) {
    const sName = screen.name.replace(/[^a-zA-Z0-9]/g, '');
    files.push({
      path: `src/screens/${sName}Screen.tsx`,
      contents: `import React from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity } from 'react-native';

export function ${sName}Screen({ navigation }: any) {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>${screen.name}</Text>
      <Text style={styles.subtitle}>Route: ${screen.route}</Text>

      ${screen.components
        .map((c) => {
          if (c.type === 'button') {
            const dest = c.props.targetRoute
              ? screenList.find((s) => s.route === c.props.targetRoute)?.name.replace(/[^a-zA-Z0-9]/g, '')
              : null;
            return `<TouchableOpacity
        style={styles.button}
        onPress={() => ${dest ? `navigation.navigate('${dest}')` : `alert('${c.props.label || 'Action'} tapped!')`}}
      >
        <Text style={styles.buttonText}>${c.props.label || 'Button'}</Text>
      </TouchableOpacity>`;
          }
          if (c.type === 'card' || c.type === 'stat_card') {
            return `<View style={styles.card}>
        <Text style={styles.cardTitle}>${c.props.title || c.name}</Text>
        ${c.props.subtitle || c.props.value ? `<Text style={styles.cardText}>${c.props.subtitle || c.props.value}</Text>` : ''}
      </View>`;
          }
          return `<View style={styles.widget}>
        <Text style={styles.widgetTitle}>${c.props.title || c.props.label || c.props.text || c.name}</Text>
      </View>`;
        })
        .join('\n      ')}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 16 },
  title: { fontSize: 22, fontWeight: 'bold', color: '#0f172a', marginBottom: 4 },
  subtitle: { fontSize: 12, color: '#64748b', marginBottom: 16 },
  button: {
    backgroundColor: '${ctx.hexColor || '#4F46E5'}',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 12,
    alignItems: 'center',
    marginVertical: 6,
  },
  buttonText: { color: '#ffffff', fontWeight: 'bold', fontSize: 15 },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 14,
    padding: 16,
    marginVertical: 6,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  cardTitle: { fontSize: 16, fontWeight: 'bold', color: '#1e293b' },
  cardText: { fontSize: 13, color: '#64748b', marginTop: 4 },
  widget: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 12,
    marginVertical: 4,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  widgetTitle: { fontSize: 14, color: '#334155' },
});
`,
    });
  }

  // 6. README.md
  files.push({
    path: 'README.md',
    contents: `# ${projName}

Generated by Swati Studio Multi-Target Generator (React Native / Expo Target).

## Run the App

\`\`\`bash
npm install
npx expo start
\`\`\`
`,
  });

  const directoriesSet = new Set<string>();
  let totalBytes = 0;
  for (const file of files) {
    totalBytes += file.contents.length;
    const parts = file.path.split('/');
    if (parts.length > 1) {
      parts.pop();
      directoriesSet.add(parts.join('/'));
    }
  }

  return {
    files,
    summary: {
      files: files.length,
      directories: Array.from(directoriesSet).sort(),
      packages: 7,
      estimatedSizeKb: Math.ceil(totalBytes / 1024),
    },
    context: ctx,
  };
}
