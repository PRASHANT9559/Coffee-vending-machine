import type { NavigationItem, StudioConfig, UploadedDatabaseFile } from '@swati/schema';
import {
  architectures,
  backends,
  componentCategories,
  databases,
  featureList,
  stateManagers,
  themeColors,
} from '@swati/schema';
import type { GenContext, GenPackage } from './types';

const STATE_PACKAGES: Record<string, string[]> = {
  riverpod: ['flutter_riverpod: ^2.6.1'],
  bloc: ['flutter_bloc: ^8.1.6', 'equatable: ^2.0.7'],
  provider: ['provider: ^6.1.2'],
  getx: ['get: ^4.6.6'],
  mobx: ['flutter_mobx: ^2.3.0', 'mobx: ^2.3.0'],
};

const BACKEND_PACKAGES: Record<string, string[]> = {
  supabase: ['supabase_flutter: ^2.8.0'],
  firebase: ['firebase_core: ^3.8.0', 'firebase_auth: ^5.3.3', 'cloud_firestore: ^5.5.0'],
  appwrite: ['appwrite: ^12.0.4'],
  pocketbase: ['pocketbase: ^0.19.0'],
  rust: ['dio: ^5.7.0'],
  fastapi: ['dio: ^5.7.0'],
  django: ['dio: ^5.7.0'],
  nodejs: ['dio: ^5.7.0'],
  laravel: ['dio: ^5.7.0'],
  custom: ['dio: ^5.7.0'],
  none: [],
};

const DB_PACKAGES: Record<string, string[]> = {
  sqlite: ['sqflite: ^2.4.1', 'path: ^1.9.0'],
  isar: ['isar: ^3.1.0+1', 'isar_flutter_libs: ^3.1.0+1', 'path_provider: ^2.1.5'],
  hive: ['hive: ^2.2.3', 'hive_flutter: ^1.1.0'],
  drift: ['drift: ^2.22.0', 'sqlite3_flutter_libs: ^0.5.26', 'path_provider: ^2.1.5', 'path: ^1.9.0'],
  postgresql: ['postgres: ^3.2.1'],
  mysql: ['mysql1: ^0.20.0'],
  mongodb: ['mongo_dart: ^0.10.1'],
  redis: ['dart_redis: ^0.4.0'],
  supabase: ['supabase_flutter: ^2.8.0'],
};

const FEATURE_PACKAGES: Record<string, string[]> = {
  authentication: ['flutter_secure_storage: ^9.2.2', 'crypto: ^3.0.6'],
  ai: ['google_generative_ai: ^0.4.6'],
  notifications: ['flutter_local_notifications: ^17.2.4'],
  localization: ['intl: ^0.19.0'],
  offline: ['connectivity_plus: ^6.1.1'],
  camera: ['camera: ^0.11.0+2', 'image_picker: ^1.1.2'],
  maps: ['google_maps_flutter: ^2.10.0', 'geolocator: ^13.0.2'],
  payments: ['flutter_stripe: ^11.4.0'],
  pdf: ['pdf: ^3.11.1', 'printing: ^5.13.2'],
  qr_scanner: ['mobile_scanner: ^6.0.2'],
  deep_linking: ['app_links: ^6.3.2'],
  background_services: ['workmanager: ^0.5.2'],
  analytics: ['firebase_analytics: ^11.3.5'],
  crash_reporting: ['firebase_crashlytics: ^4.2.1'],
  push_notifications: ['firebase_messaging: ^15.1.5'],
  biometrics: ['local_auth: ^2.3.0'],
  passkeys: ['passkeys: ^1.3.1'],
  social_login: ['google_sign_in: ^6.2.2', 'sign_in_with_apple: ^6.1.4'],
  cloud_sync: ['connectivity_plus: ^6.1.1'],
  voice_input: ['speech_to_text: ^7.0.0'],
  bluetooth: ['flutter_blue_plus: ^1.34.5'],
  nfc: ['nfc_manager: ^3.3.0'],
};

export function buildContext(config: StudioConfig): GenContext {
  const projectName = String(config['project.name'] ?? 'My Flutter App').trim();
  const packageName = String(config['project.packageName'] ?? 'my_flutter_app')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '_');
  const description = String(config['project.description'] ?? 'A beautiful Flutter application').trim();
  const organization = String(config['project.organization'] ?? 'com.example').trim();
  const version = String(config['project.version'] ?? '1.0.0').trim();
  const license = String(config['project.license'] ?? 'MIT').trim();

  const uiStyle = String(config['frontend.uiStyle'] ?? 'glassmorphism');
  const aestheticCombo = String(config['frontend.aestheticCombo'] ?? 'midnight_glass');
  const themeMode = String(config['frontend.themeMode'] ?? 'dark');
  const themeColor = String(config['frontend.themeColor'] ?? 'indigo');
  const customColor = String(config['frontend.customColor'] ?? '#6366f1');

  const themeOption = themeColors.find((t) => t.id === themeColor);
  const hexColor = themeColor === 'custom' ? customColor : (themeOption?.accent ?? '#6366f1');

  const font = String(config['frontend.font'] ?? 'Inter');
  const borderRadius = Number(config['frontend.borderRadius'] ?? 12);
  const spacing = String(config['frontend.spacing'] ?? 'normal');
  const animation = String(config['frontend.animation'] ?? 'smooth');

  const navigationStyle = String(config['navigation.style'] ?? 'bottom_nav');
  const navigationItems = Array.isArray(config['navigation.items'])
    ? (config['navigation.items'] as NavigationItem[])
    : [
        { id: 'nav-home', name: 'Home', icon: 'Home', route: '/home', title: 'Home' },
        { id: 'nav-search', name: 'Search', icon: 'Search', route: '/search', title: 'Search' },
        { id: 'nav-profile', name: 'Profile', icon: 'User', route: '/profile', title: 'Profile' },
      ];

  const databaseFile = config['database.file'] as UploadedDatabaseFile | undefined;

  const backend = String(config['backend.provider'] ?? 'supabase');
  const backendName = backends.find((b) => b.id === backend)?.name ?? backend;

  const database = String(config['database.engine'] ?? 'sqlite');
  const databaseName = databases.find((d) => d.id === database)?.name ?? database;

  const architecture = String(config['architecture.pattern'] ?? 'feature_first');
  const architectureName = architectures.find((a) => a.id === architecture)?.name ?? architecture;

  const stateManager = String(config['state.manager'] ?? 'riverpod');
  const stateName = stateManagers.find((s) => s.id === stateManager)?.name ?? stateManager;

  const features = Array.isArray(config['features.selected']) ? (config['features.selected'] as string[]) : [];
  const components = Array.isArray(config['components.selected']) ? (config['components.selected'] as string[]) : [];

  // Deduplicate and aggregate all pub packages
  const packageMap = new Map<string, string>();

  // State packages
  for (const entry of STATE_PACKAGES[stateManager] ?? []) {
    const [name, ver] = entry.split(': ');
    packageMap.set(name.trim(), ver?.trim() ?? 'any');
  }

  // Backend packages
  for (const entry of BACKEND_PACKAGES[backend] ?? []) {
    const [name, ver] = entry.split(': ');
    packageMap.set(name.trim(), ver?.trim() ?? 'any');
  }

  // Database packages
  for (const entry of DB_PACKAGES[database] ?? []) {
    const [name, ver] = entry.split(': ');
    packageMap.set(name.trim(), ver?.trim() ?? 'any');
  }

  // Feature packages
  for (const f of features) {
    for (const entry of FEATURE_PACKAGES[f] ?? []) {
      const [name, ver] = entry.split(': ');
      packageMap.set(name.trim(), ver?.trim() ?? 'any');
    }
  }

  // Component packages
  if (components.includes('charts')) {
    packageMap.set('fl_chart', '^0.69.2');
  }

  const packages: GenPackage[] = [];
  packageMap.forEach((ver, name) => {
    packages.push({ name, version: ver });
  });

  return {
    projectName,
    packageName,
    description,
    organization,
    version,
    license,
    uiStyle,
    aestheticCombo,
    themeMode,
    themeColor,
    customColor,
    hexColor,
    font,
    borderRadius,
    spacing,
    animation,
    navigationStyle,
    navigationItems,
    databaseFile,
    backend,
    backendName,
    database,
    databaseName,
    architecture,
    architectureName,
    stateManager,
    stateName,
    features,
    components,
    packages,
    folders: [],
    rawConfig: config,
    environmentFlavor: String(config['project.environmentFlavor'] ?? 'single'),
    cicdPlatform: String(config['project.cicdPlatform'] ?? 'github_actions'),
    locale: String(config['project.locale'] ?? 'en'),
    authMethods: Array.isArray(config['auth.methods'])
      ? (config['auth.methods'] as string[])
      : ['email_password', 'google_oauth', 'biometric'],
    authScreens: Array.isArray(config['auth.screens'])
      ? (config['auth.screens'] as string[])
      : ['login', 'register', 'forgot_password'],
    enableRbac: Boolean(config['security.enableRbac']),
  };
}
