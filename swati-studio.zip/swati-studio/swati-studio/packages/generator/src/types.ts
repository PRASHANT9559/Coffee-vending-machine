import type { NavigationItem, StudioConfig, UploadedDatabaseFile } from '@swati/schema';
import type { ExportedScreen } from './templates/screenDart';

export interface GeneratedFile {
  path: string;
  contents: string;
}

export interface GenPackage {
  name: string;
  version?: string;
  isDev?: boolean;
}

export interface GenContext {
  projectName: string;
  packageName: string;
  description: string;
  organization: string;
  version: string;
  license: string;
  uiStyle: string;
  aestheticCombo: string;
  themeMode: string;
  themeColor: string;
  customColor: string;
  hexColor: string;
  font: string;
  borderRadius: number;
  spacing: string;
  animation: string;
  navigationStyle: string;
  navigationItems: NavigationItem[];
  databaseFile?: UploadedDatabaseFile;
  backend: string;
  backendName: string;
  database: string;
  databaseName: string;
  architecture: string;
  architectureName: string;
  stateManager: string;
  stateName: string;
  features: string[];
  components: string[];
  packages: GenPackage[];
  folders: string[];
  rawConfig: StudioConfig;
  screens?: ExportedScreen[];
  targetFramework?: 'flutter' | 'react-native' | 'nextjs';
  environmentFlavor?: string;
  cicdPlatform?: string;
  locale?: string;
  authMethods?: string[];
  authScreens?: string[];
  enableRbac?: boolean;
}

export interface GenerateSummary {
  files: number;
  directories: string[];
  packages: number;
  estimatedSizeKb: number;
}

export interface GenerateResult {
  files: GeneratedFile[];
  summary: GenerateSummary;
  context: GenContext;
}

export interface TreeNode {
  name: string;
  path: string;
  isFile: boolean;
  children: TreeNode[];
}
