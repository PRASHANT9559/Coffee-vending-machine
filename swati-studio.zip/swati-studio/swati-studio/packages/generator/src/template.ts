/**
 * Simple, zero-dependency string interpolation engine.
 * Replaces `{{key}}` placeholders with values from a dictionary.
 */
export function renderTemplate(template: string, vars: Record<string, unknown>): string {
  return template.replace(/\{\{([a-zA-Z0-9_.-]+)\}\}/g, (match, key: string) => {
    const val = vars[key];
    if (val === undefined || val === null) {
      return '';
    }
    if (Array.isArray(val)) {
      return val.join('\n');
    }
    return String(val);
  });
}
