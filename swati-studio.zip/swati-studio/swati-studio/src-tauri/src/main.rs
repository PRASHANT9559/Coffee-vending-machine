#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    swati_studio_lib::run()
}
