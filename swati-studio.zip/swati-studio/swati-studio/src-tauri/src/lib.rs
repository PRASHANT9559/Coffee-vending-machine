mod commands;
mod error;

use error::Result;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![
            commands::write_project,
            commands::default_output_dir,
            commands::detect_toolchains,
            commands::save_draft,
            commands::load_draft,
            commands::pick_output_dir,
            commands::open_path,
            commands::reveal_path,
            commands::run_flutter_create,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Swati Studio");
}

pub use error::Error;
pub type AppResult<T> = Result<T>;
