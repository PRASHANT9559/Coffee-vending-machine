use std::fs::{self, File};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::Command;

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Manager};
use tauri_plugin_dialog::DialogExt;
use tauri_plugin_opener::OpenerExt;

use crate::error::{Error, Result};

/// A single file produced by the TypeScript generator.
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GeneratedFile {
    pub path: String,
    pub contents: String,
}

/// Result of a generation run.
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WriteResult {
    pub ok: bool,
    pub path: String,
    pub files: usize,
    pub message: String,
}

/// Versions of the toolchains found on this machine.
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolchainReport {
    pub flutter: Option<String>,
    pub dart: Option<String>,
    pub node: Option<String>,
    pub rustc: Option<String>,
}

fn sanitize_component(value: &str) -> String {
    let cleaned: String = value
        .chars()
        .map(|c| if c.is_alphanumeric() || c == '-' || c == '_' { c } else { '_' })
        .collect();
    let trimmed = cleaned.trim_matches('_').to_string();
    if trimmed.is_empty() {
        "project".to_string()
    } else {
        trimmed
    }
}

/// Rejects paths that try to escape the output directory.
fn safe_relative_path(root: &Path, relative: &str) -> Result<PathBuf> {
    let mut path = root.to_path_buf();
    for part in relative.split('/') {
        if part.is_empty() || part == "." {
            continue;
        }
        if part == ".." {
            return Err(Error::Invalid(format!(
                "refusing to write outside the project folder: {relative}"
            )));
        }
        path.push(part);
    }
    Ok(path)
}

fn version_of(program: &str, args: &[&str]) -> Option<String> {
    let output = Command::new(program).args(args).output().ok()?;
    if !output.status.success() {
        return None;
    }
    let text = String::from_utf8_lossy(&output.stdout);
    let line = text.lines().next()?.trim().to_string();
    if line.is_empty() {
        None
    } else {
        Some(line)
    }
}

/// Writes the generated project to disk and optionally zips it.
#[tauri::command]
pub async fn write_project(
    app: AppHandle,
    files: Vec<GeneratedFile>,
    output_dir: String,
    project_name: String,
    create_zip: bool,
) -> Result<WriteResult> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| Error::Invalid(format!("no app data dir: {e}")))?;

    let base = if output_dir.trim().is_empty() {
        root.join("generated-projects")
    } else {
        PathBuf::from(output_dir.trim())
    };

    let project = sanitize_component(&project_name);
    let project_dir = base.join(&project);

    fs::create_dir_all(&project_dir)?;

    let mut written = 0usize;
    for file in &files {
        let target = safe_relative_path(&project_dir, &file.path)?;
        if let Some(parent) = target.parent() {
            fs::create_dir_all(parent)?;
        }
        fs::write(&target, file.contents.as_bytes())?;
        written += 1;
    }

    let mut message = format!("{written} files written to {}", project_dir.display());
    let mut result_path = project_dir.display().to_string();

    if create_zip {
        let zip_path = base.join(format!("{project}.zip"));
        zip_directory(&project_dir, &zip_path)?;
        message.push_str(&format!(" · archive at {}", zip_path.display()));
        result_path = zip_path.display().to_string();
    }

    Ok(WriteResult {
        ok: true,
        path: result_path,
        files: written,
        message,
    })
}

/// Creates a zip archive of a directory.
fn zip_directory(source: &Path, destination: &Path) -> Result<()> {
    if let Some(parent) = destination.parent() {
        fs::create_dir_all(parent)?;
    }
    let file = File::create(destination)?;
    let mut zip = zip::ZipWriter::new(file);
    let options = zip::write::SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated);

    for entry in walk(source)? {
        let relative = entry
            .strip_prefix(source)
            .map_err(|e| Error::Invalid(e.to_string()))?
            .to_string_lossy()
            .replace('\\', "/");
        if relative.is_empty() {
            continue;
        }
        if entry.is_dir() {
            let name = format!("{relative}/");
            zip.add_directory(name, options)?;
        } else {
            zip.start_file(relative, options)?;
            let bytes = fs::read(&entry)?;
            zip.write_all(&bytes)?;
        }
    }

    zip.finish()?;
    Ok(())
}

/// Depth first walk that skips hidden folders such as `.git`.
fn walk(root: &Path) -> Result<Vec<PathBuf>> {
    let mut out = Vec::new();
    let mut stack = vec![root.to_path_buf()];

    while let Some(dir) = stack.pop() {
        let entries = fs::read_dir(&dir)?;
        for entry in entries {
            let entry = entry?;
            let path = entry.path();
            let name = entry.file_name().to_string_lossy().to_string();
            if name.starts_with('.') && name != ".gitignore" {
                continue;
            }
            if path.is_dir() {
                out.push(path.clone());
                stack.push(path);
            } else {
                out.push(path);
            }
        }
    }

    out.sort();
    Ok(out)
}

/// Default folder where projects are written.
#[tauri::command]
pub async fn default_output_dir(app: AppHandle) -> Option<String> {
    let root = app.path().app_data_dir().ok()?;
    Some(root.join("generated-projects").display().to_string())
}

/// Detects Flutter, Dart, Node and Rust toolchains.
#[tauri::command]
pub async fn detect_toolchains() -> Result<ToolchainReport> {
    Ok(ToolchainReport {
        flutter: version_of("flutter", &["--version"]),
        dart: version_of("dart", &["--version"]),
        node: version_of("node", &["--version"]),
        rustc: version_of("rustc", &["--version"]),
    })
}

/// Persists the wizard draft inside the app data directory.
#[tauri::command]
pub async fn save_draft(app: AppHandle, name: String, content: String) -> Result<bool> {
    let dir = app
        .path()
        .app_data_dir()
        .map_err(|e| Error::Invalid(format!("no app data dir: {e}")))?;
    fs::create_dir_all(&dir)?;
    let target = dir.join(sanitize_component(&name));
    fs::write(&target, content.as_bytes())?;
    Ok(true)
}

/// Reads a previously saved draft.
#[tauri::command]
pub async fn load_draft(app: AppHandle, name: String) -> Result<Option<String>> {
    let dir = app
        .path()
        .app_data_dir()
        .map_err(|e| Error::Invalid(format!("no app data dir: {e}")))?;
    let target = dir.join(sanitize_component(&name));
    if !target.exists() {
        return Ok(None);
    }
    Ok(Some(fs::read_to_string(target)?))
}

/// Opens the native folder picker.
#[tauri::command]
pub async fn pick_output_dir(app: AppHandle) -> Option<String> {
    let (tx, rx) = std::sync::mpsc::channel();
    app.dialog().file().pick_folder(move |path| {
        let _ = tx.send(path);
    });

    tauri::async_runtime::spawn_blocking(move || rx.recv().ok().flatten())
        .await
        .ok()
        .flatten()
        .and_then(|path| path.into_path().ok())
        .map(|path| path.display().to_string())
}

/// Opens a file or folder with the system default application.
#[tauri::command]
pub async fn open_path(app: AppHandle, path: String) -> Result<bool> {
    app.opener().open_path(path, None::<&str>)?;
    Ok(true)
}

/// Reveals a file in the system file explorer.
#[tauri::command]
pub async fn reveal_path(app: AppHandle, path: String) -> Result<bool> {
    app.opener().reveal_item_in_dir(path)?;
    Ok(true)
}

/// Runs `flutter create` inside the generated folder so the real
/// android/ios platform folders are produced.
#[tauri::command]
pub async fn run_flutter_create(
    directory: String,
    organization: String,
    project_name: String,
) -> Result<String> {
    let dir = PathBuf::from(directory.trim());
    fs::create_dir_all(&dir)?;

    let output = Command::new("flutter")
        .arg("create")
        .arg("--org")
        .arg(organization)
        .arg("--project-name")
        .arg(sanitize_component(&project_name))
        .arg(".")
        .current_dir(&dir)
        .output()?;

    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();

    if !output.status.success() {
        return Err(Error::Invalid(format!(
            "flutter create failed: {}{}",
            stdout.trim(),
            stderr.trim()
        )));
    }

    Ok(stdout)
}
